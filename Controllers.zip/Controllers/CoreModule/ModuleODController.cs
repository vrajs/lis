using Kwicle.Data.Contracts.CoreModule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.CoreModule
{
    [Route("odata")]
    public class ModuleODController : BaseODController
    {
        #region Variables        
        private IModuleRepository _ModuleRepository;
        #endregion

        #region Ctor        
        public ModuleODController(IModuleRepository ModuleRepository)
        {
            _ModuleRepository = ModuleRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Module")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetModules()
        {
            var Query = _ModuleRepository.GetModule(null);
            return Ok(Query);
        }
    }
}
