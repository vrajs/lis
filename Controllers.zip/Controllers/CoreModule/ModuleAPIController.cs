using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel;
using Kwicle.Data.Contracts.CoreModule;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Modules.CoreModule
{
    
    [Route("api/Module")]
    public class ModuleAPIController : BaseAPIController
    {
        private readonly IModuleRepository _moduleRepository;
        private ILogger<ModuleAPIController> _logger;
        public ModuleAPIController(IModuleRepository moduleRepository, ILogger<ModuleAPIController> logger)
        {
            _moduleRepository = moduleRepository;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetKeyValue")]
        public IActionResult GetKeyValue()
        {
            try
            {
                List<KeyVal<int,string>> keyValuePairs = _moduleRepository.GetKeyValue();
                _logger.LogInformation(new EventId(1), "GetKeyValue Succeded");
                return Ok(keyValuePairs);
            }
            catch (Exception ex)
            {
                _logger.LogError(new EventId(1, "ModuleController"), "Error while GetKeyValue {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
