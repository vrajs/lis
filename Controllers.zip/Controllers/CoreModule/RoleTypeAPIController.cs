using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.CoreModule;
using AutoMapper;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.CoreModule
{
    [Route("api/RoleType")]
    public class RoleTypeAPIController : BaseAPIController
    {
        private readonly IRoleTypeRepository _roleTypeRepository;
        private IMapper _mapper;
        private ILogger<RoleTypeAPIController> _logger;

        public RoleTypeAPIController(IRoleTypeRepository roleTypeRepository, IMapper mapper, ILogger<RoleTypeAPIController> logger)
        {
            _roleTypeRepository = roleTypeRepository;
            _mapper = mapper;
            _logger = logger;
        }


        [HttpGet("GetRoleType")]
        public IActionResult GetRoleType()
        {
            var keyValList = _roleTypeRepository.GetRoleType();
            return Ok(keyValList);
        }
    }
}
