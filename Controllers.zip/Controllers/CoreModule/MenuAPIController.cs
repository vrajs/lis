using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.CoreModule;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.CoreModule
{

    [Route("api/Menu")]
    public class MenuAPIController : BaseAPIController
    {
        private IMenuRepository _MenuRepository;
        public MenuAPIController(IMenuRepository menuRepository)
        {
            _MenuRepository = menuRepository;
        }

        [HttpGet]
        [Route("GetMenu")]
        public IActionResult GetMenu()
        {
            var res = _MenuRepository.GetMenu();
            return Ok(res);
        }
    }
}
