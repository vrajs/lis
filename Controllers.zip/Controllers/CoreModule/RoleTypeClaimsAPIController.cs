using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.CoreModule;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Service.ViewModels;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.CoreModule
{
    [Route("api/RoleTypeClaims")]
    public class RoleTypeClaimsAPIController : BaseAPIController
    {
        private readonly IRoleTypeClaimsRepository _roleTypeClaimsRepository;
        private IMapper _mapper;
        private ILogger<RoleTypeClaimsAPIController> _logger;

        public RoleTypeClaimsAPIController(IRoleTypeClaimsRepository roleTypeClaimsRepository, IMapper mapper, ILogger<RoleTypeClaimsAPIController> logger)
        {
            _roleTypeClaimsRepository = roleTypeClaimsRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet("GetRoleTypeClaims")]
        public IActionResult GetRoleTypeClaims()//short roleTypeID
        {
            var permissionList = _roleTypeClaimsRepository.GetRoleTypeClaim();
            return Ok(_mapper.Map<List<RoleTypeClaimViewModel>>(permissionList));
        }
    }
}
