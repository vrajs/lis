using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Kwicle.API.Models;
using Kwicle.Filters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;
using Kwicle.API.Controllers;

namespace Kwicle.Service.Controllers
{
    [Route("api/Clinics/{UID}/Providers")]
    [ValidateModel]
    //[ApiVersion("1.0")]
    //[ApiVersion("1.1")]
    public class OldProvidersController : BaseAPIController
    {
        protected ILogger<OldProvidersController> _logger;
        protected IMapper _mapper;
        protected IOldProviderRepository _providerRepository;
        private IClinicRepository _clinicRepository;
        protected UserManager<KwicleUser> _userMgr;

        public OldProvidersController(
            IOldProviderRepository providerRepository,
            IClinicRepository clinicRepository,
          ILogger<OldProvidersController> logger,
          IMapper mapper,
          UserManager<KwicleUser> userMgr)
        {
            _providerRepository = providerRepository;
            _clinicRepository = clinicRepository;
            _logger = logger;
            _mapper = mapper;
            _userMgr = userMgr;
        }

        [HttpGet]
        //[MapToApiVersion("1.0")]
        public IActionResult Get(string UID, bool includeProcedures = false)
        {
            var Providers = includeProcedures ? _providerRepository.GetProvidersByUIDWithProcedures(UID) : _providerRepository.GetProvidersByUID(UID);

            return Ok(_mapper.Map<IEnumerable<ProviderModel>>(Providers));
        }

        [HttpGet("{id}", Name = "OldProviderGet")]
        public IActionResult Get(string UID, int id, bool includeProcedures = false)
        {
            var Provider = includeProcedures ? _providerRepository.GetProviderWithProcedures(id) : _providerRepository.GetProvider(id);
            if (Provider == null) return NotFound();
            if (Provider.Clinic.UID != UID) return BadRequest("Provider not in specified Clinic");

            return Ok(_mapper.Map<ProviderModel>(Provider));
        }

        [HttpPost]
        //[Authorize]
        public async Task<IActionResult> Post(string UID, [FromBody]ProviderModel model)
        {
            try
            {
                var Clinic = _clinicRepository.GetClinicByUID(UID);
                if (Clinic == null) return BadRequest("Could not find Clinic");

                var Provider = _mapper.Map<OldProvider>(model);
                Provider.Clinic = Clinic;

                var kwicleUser = await _userMgr.FindByNameAsync(this.User.Identity.Name);
                if (kwicleUser != null)
                {
                    Provider.User = kwicleUser;

                    _providerRepository.Add(Provider);

                    if (await _providerRepository.SaveAllAsync())
                    {
                        var url = Url.Link("OldProviderGet", new { UID = Clinic.UID, id = Provider.ProviderID });
                        return Created(url, _mapper.Map<ProviderModel>(Provider));
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while adding Provider: {ex}");
            }

            return BadRequest("Could not add new Provider");
        }

        [HttpPut("{id}")]
        //[Authorize]
        public async Task<IActionResult> Put(string UID,
          int id,
          [FromBody] ProviderModel model)
        {
            try
            {
                var Provider = _providerRepository.GetProvider(id);
                if (Provider == null) return NotFound();
                if (Provider.Clinic.UID != UID) return BadRequest("Provider and Clinic do not match");

                if (Provider.User.UserName != this.User.Identity.Name) return Forbid();

                _mapper.Map(model, Provider);

                if (await _providerRepository.SaveAllAsync())
                {
                    return Ok(_mapper.Map<ProviderModel>(Provider));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider: {ex}");
            }

            return BadRequest("Could not update Provider");
        }

        [HttpDelete("{id}")]
        // [Authorize]
        public async Task<IActionResult> Delete(string UID, int id)
        {
            try
            {
                var Provider = _providerRepository.GetProvider(id);
                if (Provider == null) return NotFound();
                if (Provider.Clinic.UID != UID) return BadRequest("Provider and Clinic do not match");

                if (Provider.User.UserName != this.User.Identity.Name) return Forbid();

                _providerRepository.Delete(Provider);

                if (await _providerRepository.SaveAllAsync())
                {
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider: {ex}");
            }

            return BadRequest("Could not delete Provider");
        }
    }
}
