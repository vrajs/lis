using System;
using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.OData.Routing.Controllers;

namespace Kwicle.Service.Controllers
{
    [Authorize(AuthenticationSchemes = IdentityServerAuthenticationDefaults.AuthenticationScheme)]
    public class BaseODController : ODataController
    {
        static string ZoneId = "Eastern Standard Time";

        public DateTime TodaysDate => System.TimeZoneInfo.ConvertTime(DateTime.Now, System.TimeZoneInfo.Local, System.TimeZoneInfo.FindSystemTimeZoneById(ZoneId));

        public string UserName => User.Identity.Name;
    }
}
