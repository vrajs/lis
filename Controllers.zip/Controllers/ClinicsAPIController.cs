using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.API.Models;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;
using Kwicle.Filters;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers
{

    [EnableCors("AnyGET")]
    [Route("api/Clinics")]
    [ValidateModel]
    public class ClinicsAPIController : BaseAPIController
    {
        private ILogger<ClinicsAPIController> _logger;
        private IClinicRepository _clinicRepository;
        private IMapper _mapper;

        public ClinicsAPIController(IClinicRepository clinicRepository,
          ILogger<ClinicsAPIController> logger,
          IMapper mapper)
        {
            _clinicRepository = clinicRepository;
            _logger = logger;
            _mapper = mapper;
        }
        //[SafeQueryableAttribute]
        
        [HttpGet("")]
        public IActionResult Get()
        {
            var Clinics = _clinicRepository.GetAllClinics();            
            return Json(_mapper.Map<IEnumerable<ClinicModel>>(Clinics));
        }

        [HttpGet("{UID}", Name = "ClinicGet")]
        public IActionResult Get(string UID, bool includeProviders = false)
        {
            try
            {
                Clinic Clinic = null;

                if (includeProviders) Clinic = _clinicRepository.GetClinicByUIDWithProviders(UID);
                else Clinic = _clinicRepository.GetClinicByUID(UID);

                if (Clinic == null) return NotFound($"Clinic {UID} was not found");

                return Json(_mapper.Map<ClinicModel>(Clinic));
            }
            catch(Exception ex)
            {
                return Json(ex.Message);
            }

            
        }

                
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]ClinicModel model)
        {
            try
            {
                _logger.LogInformation("Creating a new Clinic");

                var Clinic = _mapper.Map<Clinic>(model);

                await _clinicRepository.AddAsync(Clinic);
                if (!_clinicRepository.DbState.IsValid)
                {
                    _logger.LogError("Could not save Clinic to the database");
                    _clinicRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return Json(BadRequest(this.ModelState));
                }
                else
                {
                    var newUri = Url.Link("ClinicGet", new { UID = Clinic.UID });
                    return Json(Created( newUri, _mapper.Map<ClinicModel>(Clinic)));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while saving Clinic: {ex}");
            }

            return Json(BadRequest());

        }
        
        [HttpPut("{UID}")]
        public async Task<IActionResult> Put(string UID, [FromBody] ClinicModel model)
        {
            try
            {
                var oldClinic = _clinicRepository.GetClinicByUID(UID);
                if (oldClinic == null) return NotFound($"Could not find a Clinic with an UID of {UID}");

                _mapper.Map(model, oldClinic);

                if (await _clinicRepository.SaveAllAsync())
                {
                    return Json(Ok(_mapper.Map<ClinicModel>(oldClinic)));
                }
            }
            catch (Exception)
            {

            }

            return Json(BadRequest("Couldn't update Clinic"));
        }

        [HttpDelete("{UID}")]
        public async Task<IActionResult> Delete(string UID)
        {
            try
            {
                var oldClinic = _clinicRepository.GetClinicByUID(UID);
                if (oldClinic == null) return NotFound($"Could not find Clinic with UID of {UID}");

                _clinicRepository.Delete(oldClinic);
                if (await _clinicRepository.SaveAllAsync())
                {
                    return Json(Ok(_mapper.Map<ClinicModel>(oldClinic)));
                }
            }
            catch (Exception)
            {
            }

            return Json(BadRequest("Could not delete Clinic"));
        }

    }
}






