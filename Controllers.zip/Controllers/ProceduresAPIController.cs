using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Kwicle.API.Models;
using Kwicle.Filters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;
using Kwicle.API.Controllers;

namespace Kwicle.Service.Controllers
{
    [Route("api/Clinics/{UID}/Providers/{ProviderId}/Procedures")]
    [ValidateModel]
    public class ProceduresAPIController : BaseAPIController
    {
        private ILogger<ProceduresAPIController> _logger;
        private IMapper _mapper;
        private IProcedureRepository _procedureRepository;
        protected IOldProviderRepository _providerRepository;
        private IMemoryCache _cache;

        public ProceduresAPIController(
            IProcedureRepository procedureRepository,
            IOldProviderRepository providerRepository,
            ILogger<ProceduresAPIController> logger,
            IMapper mapper,
            IMemoryCache cache)
        {
            _procedureRepository = procedureRepository;
            _providerRepository = providerRepository;
            _logger = logger;
            _mapper = mapper;
            _cache = cache;
        }

        [HttpGet]
        public IActionResult Get(string UID, int ProviderId)
        {
            var Procedures = _procedureRepository.GetProcedures(ProviderId);

            if (Procedures.Any(t => t.Provider.Clinic.UID != UID)) return BadRequest("Invalid Procedures for the Provider selected");

            return Ok(_mapper.Map<IEnumerable<ProcedureModel>>(Procedures));
        }

        [HttpGet("{id}", Name = "GetProcedure")]
        public IActionResult Get(string UID, int ProviderId, int id)
        {
            if (Request.Headers.ContainsKey("If-None-Match"))
            {
                var oldETag = Request.Headers["If-None-Match"].First();
                if (_cache.Get($"Procedure-{id}-{oldETag}") != null)
                {
                    return StatusCode((int)HttpStatusCode.NotModified);
                }
            }

            var Procedure = _procedureRepository.GetProcedure(id);

            if (Procedure.Provider.ProviderID != ProviderId || Procedure.Provider.Clinic.UID != UID) return BadRequest("Invalid Procedure for the Provider selected");

            AddETag(Procedure);

            return Ok(_mapper.Map<ProcedureModel>(Procedure));
        }

        private void AddETag(Procedure Procedure)
        {
            var etag = Convert.ToBase64String(Procedure.RowVersion);
            Response.Headers.Add("ETag", etag);
            _cache.Set($"Procedure-{Procedure.ProcedureID}-{etag}", Procedure);
        }

        [HttpPost()]
        public async Task<IActionResult> Post(string UID, int ProviderId, [FromBody] ProcedureModel model)
        {
            try
            {
                var Provider = _providerRepository.GetProvider(ProviderId);
                if (Provider != null)
                {
                    var Procedure = _mapper.Map<Procedure>(model);

                    Procedure.Provider = Provider;
                    _procedureRepository.Add(Procedure);

                    if (await _procedureRepository.SaveAllAsync())
                    {
                        AddETag(Procedure);
                        return Created(Url.Link("GetProcedure", new { UID = UID, ProviderId = ProviderId, id = Procedure.ProcedureID }), _mapper.Map<ProcedureModel>(Procedure));
                    }
                }

            }
            catch (Exception ex)
            {

                _logger.LogError($"Failed to save new Procedure: {ex}");
            }

            return BadRequest("Failed to save new Procedure");
        }

        [HttpPut("{id}", Name = "UpdateProcedure")]
        public async Task<IActionResult> Put(string UID, int ProviderId, int id, [FromBody] ProcedureModel model)
        {
            try
            {
                var Procedure = _procedureRepository.GetProcedure(id);
                if (Procedure == null) return NotFound();

                if (Request.Headers.ContainsKey("If-Match"))
                {
                    var etag = Request.Headers["If-Match"].First();
                    if (etag != Convert.ToBase64String(Procedure.RowVersion))
                    {
                        return StatusCode((int)HttpStatusCode.PreconditionFailed);
                    }
                }

                _mapper.Map(model, Procedure);

                if (await _procedureRepository.SaveAllAsync())
                {
                    AddETag(Procedure);
                    return Ok(_mapper.Map<ProcedureModel>(Procedure));
                }

            }
            catch (Exception ex)
            {

                _logger.LogError($"Failed to update Procedure: {ex}");
            }

            return BadRequest("Failed to update Procedure");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string UID, int ProviderId, int id)
        {
            try
            {
                var Procedure = _procedureRepository.GetProcedure(id);
                if (Procedure == null) return NotFound();

                if (Request.Headers.ContainsKey("If-Match"))
                {
                    var etag = Request.Headers["If-Match"].First();
                    if (etag != Convert.ToBase64String(Procedure.RowVersion))
                    {
                        return StatusCode((int)HttpStatusCode.PreconditionFailed);
                    }
                }

                _procedureRepository.Delete(Procedure);

                if (await _procedureRepository.SaveAllAsync())
                {
                    return Ok();
                }

            }
            catch (Exception ex)
            {

                _logger.LogError($"Failed to delete Procedure: {ex}");
            }

            return BadRequest("Failed to delete Procedure");
        }

    }
}
