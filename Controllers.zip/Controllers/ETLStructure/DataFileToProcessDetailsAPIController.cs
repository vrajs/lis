﻿using Kwicle.Data.Contracts.ETLStructure;
using Kwicle.Business.Interfaces.ETLStructure;
using Kwicle.Core.CustomModel.ETLStructure;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using AutoMapper;

namespace Kwicle.Service.Controllers.ETLStructure
{
    [Route("api/DataFileToProcessDetails")]
    public class DataFileToProcessDetailsAPIController : BaseAPIController
    {
        private ILogger<DataFileToProcessDetailsAPIController> _logger;
        private readonly IDataFileToProcessDetailsRepository _dataFileToProcessDetailsRepository;
        private readonly IDataFileToProcessDetailsService _dataFileToProcessDetailsService;
        private IMapper _mapper;

        public DataFileToProcessDetailsAPIController(IDataFileToProcessDetailsRepository dataFileToProcessDetailsRepository, ILogger<DataFileToProcessDetailsAPIController> logger, IMapper mapper, IDataFileToProcessDetailsService dataFileToProcessDetailsService)
        {
            _logger = logger;
            _mapper = mapper;
            _dataFileToProcessDetailsRepository = dataFileToProcessDetailsRepository;
            _dataFileToProcessDetailsService = dataFileToProcessDetailsService;
        }

        [HttpGet]
        [Route("GetDataFileToProcessDetails")]
        public ActionResult GetDataFileToProcessDetails()
        {
            try
            {
                var result = _dataFileToProcessDetailsService.GetAllDataFileToProcessDetails();
                if (result == null) return NotFound($"DataFileToProcessDetails was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
    }
}
