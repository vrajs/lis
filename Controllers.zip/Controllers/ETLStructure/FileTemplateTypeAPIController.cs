﻿using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.AspNetCore.Authorization;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;
using Kwicle.Business.Interfaces.ETLStructure;
using Kwicle.Core.CustomModel.ETLStructure;
using AutoMapper;
using Newtonsoft.Json;
using Kwicle.Core.Entities;

namespace Kwicle.Service.Controllers.ETLStructure
{
    //[Produces("application/json")]
    [Route("api/FileTemplateType")]
    public class FileTemplateTypeAPIController : BaseAPIController
    {
        private ILogger<FileTemplateTypeAPIController> _logger;
        private readonly IFileTemplateTypeRepository _fileTemplateTypeRepository;
        private readonly IFileTemplateTypeService _fileTemplateTypeService;
        private IMapper _mapper;

        public FileTemplateTypeAPIController(IFileTemplateTypeRepository fileTemplateTypeRepository, ILogger<FileTemplateTypeAPIController> logger, IMapper mapper, IFileTemplateTypeService fileTemplateTypeService)
        {
            _logger = logger;
            _mapper = mapper;
            _fileTemplateTypeRepository = fileTemplateTypeRepository;
            _fileTemplateTypeService = fileTemplateTypeService;
        }

        [HttpGet]
        [Route("GetFileTemplateTypes")]
        public ActionResult GetFileTemplateType()
        {
            try
            {
                var result = _fileTemplateTypeService.GetAllFileTemplateType();
                if (result == null) return NotFound($"FileTemplateType was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        /// <summary>
        /// Get member enrollment List
        /// </summary>
        /// <param name="searchModelString"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetFileTemplateDetails")]
        public async Task<IActionResult> GetFileTemplateDetails(string searchModelString)
        {
            FileTemplateTypeSearchModel searchModel = JsonConvert.DeserializeObject<FileTemplateTypeSearchModel>(searchModelString);
            var objList = await _fileTemplateTypeService.GetFileTemplateDetails(searchModel);
            return Ok(objList);
        }
        /// <summary>
        /// Get File Data from it's table according to fileCode
        /// </summary>
        /// <param name="fileCode"></param>
        /// <param name="dataFileToProcessDetailsID"></param>
        /// <returns>File Data</returns>
        [HttpGet]
        [Route("GetFileData")]
        public async Task<IActionResult> GetFileData(string fileCode, int dataFileToProcessDetailsID)
        {
            var data = default(object);
            switch (fileCode)
            {
                case FileCodeConstants.FullEnrollment:
                    data = await _fileTemplateTypeRepository.GetEnrollmentFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.LossOfSubsidy:
                    data = await _fileTemplateTypeRepository.GetLossOfSubsidyFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.LTIResident:
                    data = await _fileTemplateTypeRepository.GetLTIResidentFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.TRR:
                    data = await _fileTemplateTypeRepository.GetTRRDetailFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.OEC:
                    data = await _fileTemplateTypeRepository.GetOECFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.NoRx:
                    data = await _fileTemplateTypeRepository.GetNoRxFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MPWRD:
                    data = await _fileTemplateTypeRepository.GetMPWRDFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MMSR:
                    data = await _fileTemplateTypeRepository.GetMMSRDetailFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MembershipDetail:
                    data = await _fileTemplateTypeRepository.GetMembershipFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX94T:
                    data = await _fileTemplateTypeRepository.GetMARxT94FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX93T:
                    data = await _fileTemplateTypeRepository.GetMARxT93FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX92T:
                    data = await _fileTemplateTypeRepository.GetMARxT92FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX81T:
                    data = await _fileTemplateTypeRepository.GetMARxT81FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX80T:
                    data = await _fileTemplateTypeRepository.GetMARxT80FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX79T:
                    data = await _fileTemplateTypeRepository.GetMARxT79FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX78T:
                    data = await _fileTemplateTypeRepository.GetMARxT78FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX77T:
                    data = await _fileTemplateTypeRepository.GetMARxT77FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX76T:
                    data = await _fileTemplateTypeRepository.GetMARxT76FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX75T:
                    data = await _fileTemplateTypeRepository.GetMARxT75FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX74T:
                    data = await _fileTemplateTypeRepository.GetMARxT74FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX73T:
                    data = await _fileTemplateTypeRepository.GetMARxT73FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX72T:
                    data = await _fileTemplateTypeRepository.GetMARxT72FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX51T:
                    data = await _fileTemplateTypeRepository.GetMARxT51FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MARX61T:
                    data = await _fileTemplateTypeRepository.GetMARxT61FileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.MAMS:
                    data = await _fileTemplateTypeRepository.GetMAMSFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.ListDataDPremium:
                    data = await _fileTemplateTypeRepository.GetLisPartDPremiumFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.LISHIST:
                    data = await _fileTemplateTypeRepository.GetLisHistFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.LEP:
                    data = await _fileTemplateTypeRepository.GetLEPDetailFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.BEQRes:
                    data = await _fileTemplateTypeRepository.GetBeqResponseFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.BEQ:
                    data = await _fileTemplateTypeRepository.GetBeqRequestFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                case FileCodeConstants.AgentBrokerCompensation:
                    data = await _fileTemplateTypeRepository.GetAgentCompFileData(dataFileToProcessDetailsID);
                    return Ok(data);

                default:
                    return Ok();
            }
            // objList = await _fileTemplateTypeService.GetFileTemplateDetails(searchModel);
        }

        [HttpGet]
        [Route("GetCMSFileTypes")]
        public async Task<IActionResult> GetCMSFileType()
        {
            try
            {
                var result = await _fileTemplateTypeService.GetCMSFileType();
                if (result == null) return NotFound($"CMS File Type was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
    }
}
