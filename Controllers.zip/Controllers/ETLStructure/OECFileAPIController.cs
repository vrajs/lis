﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.ETLStructure;
using Kwicle.Core.Common;
using Kwicle.Core.Common.OECFile;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.ETLStructure
{
    //[Produces("application/json")]
    [Route("api/OECFile")]
    public class OECFileAPIController : BaseAPIController
    {
        private ILogger<OECFileAPIController> _logger;
        private readonly IOECFileUploadService _OECFileUploadService;
        private IMapper _mapper;
        private IConfiguration _config;

        public OECFileAPIController(ILogger<OECFileAPIController> logger, IMapper mapper, IOECFileUploadService OECFileUploadService, IConfiguration iConfig)
        {
            _logger = logger;
            _mapper = mapper;
            _OECFileUploadService = OECFileUploadService;
            _config = iConfig;
        }


        [HttpPost, DisableRequestSizeLimit]
        [Route("OECFileUpload")]
        public async Task<IActionResult> OECFileUpload([FromBody] FileModel fileModel)
        {
            try
            {
                OECFileProcessModel OECFileProcessModel = new OECFileProcessModel();

                OECFileProcessModel = await _OECFileUploadService.CheckOECFileUpload(fileModel);

                if (OECFileProcessModel != null && string.IsNullOrEmpty(OECFileProcessModel.ErrorMessage))
                {
                    return Ok(OECFileProcessModel);
                }
                else
                {
                    return BadRequest(OECFileProcessModel != null ? OECFileProcessModel.ErrorMessage : "File has been not uploaded.");
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

        [HttpPost, DisableRequestSizeLimit]
        [Route("OECFileProcessCheckStatus")]
        public async Task<IActionResult> OECFileProcessCheckStatus([FromBody] OECFileProcessModel OECFileProcessModel)
        {
            try
            {
                OECLayoutFileData OECLayoutFileData = await _OECFileUploadService.OECFileProcessCheckRunStatus(OECFileProcessModel);

                if (OECLayoutFileData != null)
                {
                    return Ok(OECLayoutFileData);
                }
                else
                {
                    return BadRequest("Data has been not found.");
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

        [HttpPost, DisableRequestSizeLimit]
        [Route("OECActualLoadData")]
        public IActionResult OECActualLoadData([FromBody] OECFileProcessModel OECFileProcessModel)
        {
            try
            {
                _OECFileUploadService.OECActualLoadData(OECFileProcessModel);

                return Ok("Data has been successfully load");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }
    }
}
