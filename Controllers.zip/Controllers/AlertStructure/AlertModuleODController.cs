using Kwicle.Data.Contracts.Alert;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.AlertStructure
{
    [Route("odata")]
    public class AlertModuleODController : BaseODController
    {
        #region Variables        
        private IAlertModuleRepository _AlertModuleRepository;
        #endregion
        public AlertModuleODController(IAlertModuleRepository AlertModuleRepository)
        {
            _AlertModuleRepository = AlertModuleRepository;    
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Alert")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetAlertData(int AlertDataID,int SourceModuleID)
        {
            var Query = _AlertModuleRepository.GetAlertModule(null, SourceModuleID, null,AlertDataID);
            return Ok(Query);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberAlerts")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberAlerts(string FamilyCode)
        {
            var alertCodesQuery = _AlertModuleRepository.GetMemberAlerts(FamilyCode);
            return Ok(alertCodesQuery);
        }
    }
}
