using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Alert;
using Kwicle.Core.Entities.AlertStructure;
using Kwicle.Data.Contracts.Alert;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Alert;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.AlertStructure
{
    [Route("api/Alert")]
    public class AlertModuleAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<AlertModuleAPIController> _logger;
        private IAlertModuleRepository _AlertModuleRepository;
        private IAlertModuleService _AlertModuleService;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public AlertModuleAPIController(ILogger<AlertModuleAPIController> logger, IAlertModuleRepository AlertModuleRepository, IMapper mapper, IAlertModuleService alertModuleService)
        {
            _logger = logger;
            _mapper = mapper;
            _AlertModuleRepository = AlertModuleRepository;
            _AlertModuleService = alertModuleService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var alertModuleRes = _AlertModuleRepository.GetAllAlertModule();
                if (!_AlertModuleRepository.DbState.IsValid)
                {
                    _AlertModuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<AlertModuleViewModel>>(alertModuleRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting Alerts : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "AlertGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var alertModule = _AlertModuleRepository.GetById(id);
                if (alertModule == null) return NotFound($"AlertModule {id} was not Found");
                if (!_AlertModuleRepository.DbState.IsValid)
                {
                    _AlertModuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<AlertModuleViewModel>(alertModule));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting AlertModule : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]AlertModuleViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var alertModule = _mapper.Map<AlertModule>(model);
                alertModule.CreatedDate = base.TodaysDate;
                alertModule.CreatedBy = base.UserName;
                alertModule.RecordStatus = (byte)(RecordStatus.Active);
                alertModule.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _AlertModuleService.CheckIfExists(alertModule);
                
                if (!_AlertModuleService.BusinessState.IsValid)
                {
                    _AlertModuleService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    //return BadRequest(ModelState);
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }


                _AlertModuleRepository.Add(alertModule);
                if (!_AlertModuleRepository.DbState.IsValid)
                {
                    _AlertModuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("AlertGet", new { id = alertModule.AlertModuleID });
                _logger.LogInformation("New AlertModule Created");
                return Created(newUri, alertModule.AlertModuleID);

            }
            catch (Exception ex)
            {

                _logger.LogError("Error while saving AlertModule : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]AlertModuleViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldAlertModule = _AlertModuleRepository.GetById(model.AlertModuleID);

                if (oldAlertModule == null) return NotFound($"Could not find a AlertModule with an AlertModuleID of {model.AlertModuleID}");

                _mapper.Map(model, oldAlertModule);
                oldAlertModule.UpdatedBy = base.UserName;
                oldAlertModule.UpdatedDate = base.TodaysDate;
                _AlertModuleRepository.Update(oldAlertModule);
                if (!_AlertModuleRepository.DbState.IsValid)
                {
                    _AlertModuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.AlertModuleID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating AlertModule :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _AlertModuleRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting AlertModule : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberAlerts/{FamilyCode}")]
        public IActionResult GetMembersAlerts(string FamilyCode)
        {
            try
            {
                List<AlertModuleViewModel> alertsList = _AlertModuleRepository.GetMemberAlerts(FamilyCode).ToList();
                return Ok(alertsList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
