using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Common;
using Kwicle.API.Controllers;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/tradingpartner")]
    public class TradingPartnerAPIController : BaseAPIController
    {
        #region Variables    
        private IEdiTpRepositories _IEdiTpRepositories;        
        private IMapper _mapper;
        #endregion

        public TradingPartnerAPIController(IEdiTpRepositories IEdiTpRepositories, IMapper mapper)
        {
            _IEdiTpRepositories = IEdiTpRepositories;
            _mapper = mapper;
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageEDITradingPartnerPolicy)]
        public IActionResult Post([FromBody]TradingPartnerModel model)
        {
            TradingPartner entity = _mapper.Map<TradingPartner>(model);            
            entity.RecordStatus = (int)RecordStatus.Active;
            entity.RecordStatusChangeComment = RecordStatus.Active.ToString();
            entity.CreatedBy = base.UserName;
            entity.CreatedDate = base.TodaysDate;
            entity.EffectiveDate = base.TodaysDate;
            short Tid = _IEdiTpRepositories.SaveTradingPartnerDetail(entity);
            return Created(string.Empty,Tid);
        }
        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageEDITradingPartnerPolicy)]
        public async Task<IActionResult> Put([FromBody]TradingPartnerModel model)
        {
            try
            {
                var objentity = _IEdiTpRepositories.GetTradingPartnerByTId(model.TradingPartnerId);
                if (objentity == null) { return NotFound($"Could not find TradingPartner with UID of"); }
                _mapper.Map(model, objentity);                
                objentity.UpdatedBy = base.UserName;
                objentity.UpdatedDate = base.TodaysDate;
                if (await _IEdiTpRepositories.SaveAllAsync())
                {
                    return Ok(objentity.TradingPartnerId);
                }
            }
            catch (Exception)
            {
                return BadRequest("Couldn't update TradingPartner");
            }
            return BadRequest("Couldn't update TradingPartner");
        }
        [HttpGet]
        [Route("GetTradingPartnerByTId/{TradingPartnerId}")]
        [Authorize(Policy = Authorization.Policies.ViewEDITradingPartnerPolicy)]
        public IActionResult Get(short TradingPartnerId)
        {
            TradingPartner entity = _IEdiTpRepositories.GetTradingPartnerByTId(TradingPartnerId);
            return Ok(_mapper.Map<TradingPartnerModel>(entity));
        }

        [HttpGet]
        [Route("GetddlTradingPartnerList/{TranType}/{FileType}")]
        [Authorize(Policy = Authorization.Policies.ViewEDITradingPartnerPolicy)]
        public IActionResult GetddlTradingPartnerList(string TranType, string FileType)
        {
            return Ok(_IEdiTpRepositories.GetddlTradingPartnerList(TranType,FileType));
        }        
    }
}
