using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/Element")]
    public class ElementAPIController : BaseAPIController
    {
        private readonly ILogger<ElementAPIController> _logger;
        private readonly IElementRepositories _elementRepositories;
        public ElementAPIController(ILogger<ElementAPIController> logger,IElementRepositories elementRepositories)
        {
            _logger = logger;
            _elementRepositories = elementRepositories;
        }        

        [HttpPut]
        public IActionResult Put([FromBody]Element model)
        {
            try
            {
                var element = _elementRepositories.GetById(model.ElementID);
                element.MappedElementDescription = model.MappedElementDescription;
                element.MappedType = model.MappedType;
                element.Comments = model.Comments;
                element.ElementDescription = model.ElementDescription;
                element.ChildElementID = model.ChildElementID;
                _elementRepositories.Update(element);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while DataFileConfiguration: {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
