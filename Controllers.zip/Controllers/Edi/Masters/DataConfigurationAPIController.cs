using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Common;
using Microsoft.Extensions.Configuration;
using Kwicle.Data.Contracts.Common;
using Kwicle.Core.CustomModel.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/DataConfiguration")]
    public class DataConfigurationAPIController : BaseAPIController
    {
        #region Variables    
        private ILogger<DataConfigurationAPIController> _logger;
        private IEdiTpRepositories _IEdiTpRepositories;
        private IMapper _mapper;
        private IConfiguration _configuration;
        private readonly ICommonCodeRepository _ICommonCodeRepository;

        List<DuelTransactionModel> isDuelTransationIds = new List<DuelTransactionModel>() {
                    new DuelTransactionModel {
                            FileTypeId = 9331, // 276
                            TranTypeId = 9324, // Inbound
                            DependedFileTypeId = 9332, // 277
                            DependedTranTypeId = 9325 // Outbound
                                },
                    new DuelTransactionModel {
                            FileTypeId =9328, // 270
                            TranTypeId = 9324,// Inbound
                            DependedFileTypeId = 9329, // 271
                            DependedTranTypeId = 9325 // Outbound
                                },
                };

        #endregion
        public DataConfigurationAPIController(IEdiTpRepositories IEdiTpRepositories, IMapper mapper
            , ILogger<DataConfigurationAPIController> logger, IConfiguration configuration, ICommonCodeRepository ICommonCodeRepository)
        {
            _IEdiTpRepositories = IEdiTpRepositories;
            _logger = logger;
            _mapper = mapper;
            _configuration = configuration;
            _ICommonCodeRepository = ICommonCodeRepository;
        }

        private DataFileConfiguration FillData(DataFileConfiguration objentity)
        {
            objentity.CreatedDate = base.TodaysDate;
            objentity.CreatedBy = base.UserName;
            objentity.RecordStatus = (int)RecordStatus.Active;
            objentity.RecordStatusChangeComment = RecordStatus.Active.ToString();
            objentity.ComponentSeperator = ":";
            objentity.SegmentSeparator = "~";
            objentity.FieldSeparator = "*";
            objentity.Isa01AuthInfoQual = "00";
            objentity.Isa02AuthInfo = "          ";
            objentity.Isa03SecurityInfoQual = "00";
            objentity.Isa04SecurityInfo = "          ";
            objentity.Isa05SenderIdqual = "ZZ";
            objentity.Isa07ReceiverIdqual = "01";
            objentity.Isa14AckRequested = "1";
            //objentity.Isa15UsageIndicator = "T";
            objentity.ComponentSeperator = ":";
            objentity.Nm109Submitter1000A = objentity.Gs02AppSenderCode = objentity.Isa06SenderId.ToString().Trim();
            objentity.Nm109Receiver1000B = objentity.Gs03AppReceiverCode = objentity.Isa08ReceiverId.ToString().Trim();
            var objfolderpath = _configuration.GetValue<string>("EDIFilePath:path");
            if (objfolderpath != null)
            {
                var a = _IEdiTpRepositories.GetTradingPartnerByTId(objentity.TradingPartnerId);
                var o = new MultipleValueRequestModel();
                o.CodeTypeIds = new short[] { 94, 95 };
                var data = _ICommonCodeRepository.GetCommonCodesByCodeTypeIds(o);
                string trantypename = data.Where(b => b.CommonCodeID == objentity.TranTypeId).Select(c => c.ShortName).SingleOrDefault();
                string filetypename = data.Where(b => b.CommonCodeID == objentity.FileTypeId).Select(c => c.ShortName).SingleOrDefault();

                string ReceivePath = objfolderpath + a.TradingPartnerName + "\\" + trantypename + "-" + filetypename + "\\";
                string TradingPartnerpath = objfolderpath + "DEST_" + a.TradingPartnerName + "\\" + trantypename + "-" + filetypename + "\\";

                objentity.AckPath = objfolderpath + a.TradingPartnerName + "\\" + "ACK999";
                objentity.Ack2Path = objfolderpath + a.TradingPartnerName + "\\" + "ACK277CA";
                objentity.ProcessPath = TradingPartnerpath;
                objentity.ReceivePath = ReceivePath;
                objentity.SentPath = ReceivePath + "SentPath";
                objentity.ErrorPath = TradingPartnerpath + "Error";
            }

            return objentity;
        }
        // POST api/values
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]DataConfigurationModel model)
        {
            try
            {

                _logger.LogInformation("Creating a new DataFileConfiguration");
                DataFileConfiguration objentity = _mapper.Map<DataFileConfiguration>(model);
                if (_IEdiTpRepositories.CheckDuplicateDataConfig(model))
                {
                    return BadRequest("Duplicate record exist! Please select unique filetypeid and Trantypeid!");
                }

                objentity = FillData(objentity);

                short DId = await _IEdiTpRepositories.SaveDataConfigurationDetail(objentity);
                if (!_IEdiTpRepositories.DbState.IsValid)
                {
                    _logger.LogError("Could not save to the database");
                    _IEdiTpRepositories.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                else
                {
                    if (isDuelTransationIds.Where(i => i.FileTypeId == objentity.FileTypeId && i.TranTypeId == objentity.TranTypeId).Count() > 0)
                    {
                        var Tran = isDuelTransationIds.FirstOrDefault(i => i.FileTypeId == objentity.FileTypeId && i.TranTypeId == objentity.TranTypeId);
                        model.TranTypeId = Tran.DependedTranTypeId;
                        model.FileTypeId = Tran.DependedFileTypeId;
                        model.Isa06SenderId = objentity.Isa08ReceiverId;
                        model.Isa08ReceiverId = objentity.Isa06SenderId;
                        DataFileConfiguration DuelTran = _mapper.Map<DataFileConfiguration>(model);                        
                        if (!_IEdiTpRepositories.CheckDuplicateDataConfig(model))
                        {
                            DuelTran = FillData(DuelTran);
                            await _IEdiTpRepositories.SaveDataConfigurationDetail(DuelTran);
                        }
                    }

                    return Created(string.Empty, DId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while DataFileConfiguration: {ex}");
                return BadRequest(ex.Message);
            }            
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]DataConfigurationModel model)
        {
            try
            {
                var objentity = _IEdiTpRepositories.GetDataFileConfigurationById(model.DataFileConfigurationID);
                objentity.Nm109Submitter1000A = objentity.Gs02AppSenderCode = objentity.Isa06SenderId.ToString().Trim();
                objentity.Nm109Receiver1000B = objentity.Gs03AppReceiverCode = objentity.Isa08ReceiverId.ToString().Trim();
                if (_IEdiTpRepositories.CheckDuplicateDataConfig(model))
                {
                    return BadRequest("Duplicate record exist! Please select unique filetypeid and Trantypeid!");
                }

                _mapper.Map(model, objentity);
                objentity.UpdatedBy = base.UserName;
                objentity.UpdatedDate = base.TodaysDate;
                var objfolderpath = _configuration.GetValue<string>("EDIFilePath:path");
                if (objfolderpath != null)
                {
                    var a = _IEdiTpRepositories.GetTradingPartnerByTId(model.TradingPartnerId);
                    var o = new MultipleValueRequestModel();
                    o.CodeTypeIds = new short[] { 94, 95 };
                    var data = _ICommonCodeRepository.GetCommonCodesByCodeTypeIds(o);
                    string trantypename = data.Where(b => b.CommonCodeID == objentity.TranTypeId).Select(c => c.ShortName).SingleOrDefault();
                    string filetypename = data.Where(b => b.CommonCodeID == objentity.FileTypeId).Select(c => c.ShortName).SingleOrDefault();
                    string ReceivePath = objfolderpath + a.TradingPartnerName + "\\" + trantypename + "-" + filetypename + "\\";
                    string TradingPartnerpath = objfolderpath + "DEST_" + a.TradingPartnerName + "\\" + trantypename + "-" + filetypename + "\\";

                    objentity.AckPath = objfolderpath + a.TradingPartnerName + "\\" + "ACK999";
                    objentity.Ack2Path = objfolderpath + a.TradingPartnerName + "\\" + "ACK277CA";
                    objentity.ProcessPath = TradingPartnerpath;
                    objentity.ReceivePath = ReceivePath;
                    objentity.SentPath = TradingPartnerpath + "SentPath";
                    objentity.ErrorPath = TradingPartnerpath + "Error";
                }
                _IEdiTpRepositories.UpdateConfigurationDetail(objentity);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while DataFileConfiguration: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                var objentity = _IEdiTpRepositories.GetDataFileConfigurationById(id);
                objentity.UpdatedBy = base.UserName;
                objentity.UpdatedDate = base.TodaysDate;
                objentity.RecordStatus = (int)RecordStatus.Deleted;
                objentity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                _IEdiTpRepositories.UpdateConfigurationDetail(objentity);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while DataFileConfiguration: {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
