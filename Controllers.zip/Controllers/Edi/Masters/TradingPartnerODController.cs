using Microsoft.AspNetCore.Mvc;
using Kwicle.Service.Filters;
using Kwicle.Data.Contracts.EDI;
using System.Linq;
using AutoMapper.QueryableExtensions;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Business.Interfaces.EDI;
using AutoMapper;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("odata")]
    public class TradingPartnerODController : BaseODController
    {
        #region Variables           
        private readonly IEdiTpRepositories _IEdiTpRepositories;
        private readonly IPlanBenefitConfigurationServices _planBenefitConfigurationServices;
        private readonly IEdiOutBoundConfigurationService _ediOutBoundConfigurationService;
        private IMapper _mapper;
        #endregion

        #region Constructor
        public TradingPartnerODController(IEdiTpRepositories EdiTpRepositories, IPlanBenefitConfigurationServices planBenefitConfigurationServices, IEdiOutBoundConfigurationService ediOutBoundConfigurationService,IMapper mapper)
        {
            _IEdiTpRepositories = EdiTpRepositories;
            _planBenefitConfigurationServices = planBenefitConfigurationServices;
            _ediOutBoundConfigurationService = ediOutBoundConfigurationService;
            _mapper = mapper;
        }
        #endregion

        #region Method
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("TradingPartners")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewEDITradingPartnerPolicy)]
        public IActionResult GetTradingPartners()
        {
            // var TradingPartnerListQuery =_context.TradingPartner.SelectMany(m => m.DataFileConfiguration).AsQueryable();
            //var TradingPartnerListQuery = _IEdiTpRepositories.GetTradingPartnerList();
            var TradingPartnerListQuery = _IEdiTpRepositories.GetTradingPartnerList();
            var final = TradingPartnerListQuery.ProjectTo<TradingPartnerListModel>(_mapper.ConfigurationProvider);            
            return Ok(final);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("TradingPartnerBenefitConfiguration")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetTradingPartnerBenefitConfiguration()
        {
            var TradingPartnerBenefitConfigurationList = _planBenefitConfigurationServices.GetPlanBenefitCode();
            return Ok(TradingPartnerBenefitConfigurationList);
        }

        
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetMappingSource")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetMappingSource()
        {
            var MappingSource = _ediOutBoundConfigurationService.GetMappingSource();
            return Ok(MappingSource);
        }

        
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetOutboundMappingConfiguration")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetOutboundMappingConfiguration()
        {
            //var MappingSource = _ediOutBoundConfigurationService.GetMappingSource();
            //return Ok(MappingSource);

            var MappingConfiguration = _ediOutBoundConfigurationService.GetOutboundConfiguration();
            return Ok(MappingConfiguration);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetElement")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetElement()
        {
            var Element = _ediOutBoundConfigurationService.GetElement();
            return Ok(Element);
        }
        #endregion

    }
}
