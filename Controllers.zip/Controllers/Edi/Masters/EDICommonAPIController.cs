using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Business.Interfaces.EDI;

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/EDICommon")]
    public class EDICommonAPIController : BaseAPIController
    {
        #region Variables    
        private ILogger<EDICommonAPIController> _logger;
        private IEDICommonServices _IEDICommonServices;
        private IEdi277CAServices _edi277CAServices;
        private IMapper _mapper;
        #endregion

        public EDICommonAPIController(IEDICommonServices IEDICommonServices, IEdi277CAServices edi277CAServices, IMapper mapper, ILogger<EDICommonAPIController> logger)
        {
            _IEDICommonServices = IEDICommonServices;
            _edi277CAServices = edi277CAServices;
            _logger = logger;
            _mapper = mapper;
        }

        [HttpPost]
        [Route("GetDocument")]
        public IActionResult GetDocument([FromBody]MemberAlertDocumentDownload objDownload)
        {
            try
            {
                var Data = _IEDICommonServices.GetDocument(objDownload.DocumentID, objDownload.DownloadType);
                string strFilename = string.Empty;
                string strDownloadPath = string.Empty;
                string strErrorMsg = string.Empty;
                byte[] objbyte = null;
                switch (objDownload.DownloadType)
                {
                    case "ACKLevel1":
                        strFilename = Data.strFileName + ".999";

                        strDownloadPath = Data.ACKLevel1 + "\\" + strFilename;

                        break;
                    case "ACKLevel2":
                        strFilename = Data.strFileName + ".277CA";

                        strDownloadPath = Data.Ack2Path + "\\" + strFilename;

                        _edi277CAServices.GenerateClaimStatusAck(Data.Ack2Path, strFilename, Data.x12_document_id.Value, objDownload.ClaimID);
                        // Generate the EDI 277CA Files.
                        strFilename = Data.strFileName + ".277CA";
                        break;
                    default:
                        strDownloadPath = Data.strFilePath + "\\" + Data.strFileName;
                        strFilename = Data.strFileName;
                        break;
                }
                if (System.IO.File.Exists(strDownloadPath))
                {
                    objbyte = System.IO.File.ReadAllBytes(strDownloadPath);
                }
                else { strErrorMsg = "File not found!"; }

                MemberAlertDocumentResponse objRes = new MemberAlertDocumentResponse();
                objRes.strFilename = strFilename;
                objRes.strFilebyte = objbyte;
                objRes.strErrorMsg = strErrorMsg;
                return Ok(objRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error While Download the Document: {ex}");
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetEDIDisplayData/{id}")]
        public IActionResult GetEDIDisplayData(int id)
        {
            try
            {
                string strxml = _IEDICommonServices.GetEDIFIleData(id);
                return Ok(strxml);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while Displaying EDI Data: {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
