using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/TradingPartnerBenefitConfiguration")]
    public class TradingPartnerBenefitConfigurationAPIController : BaseAPIController
    {
        private readonly IPlanBenefitConfigurationServices _planBenefitConfigurationServices;
        private readonly ITradingPartnerBenefitConfigurationRepositories _tradingPartnerBenefitConfigurationRepositories;
        private IMapper _mapper;
        public TradingPartnerBenefitConfigurationAPIController(IPlanBenefitConfigurationServices planBenefitConfigurationServices, ITradingPartnerBenefitConfigurationRepositories tradingPartnerBenefitConfigurationRepositories,
            IMapper mapper)
        {
            _planBenefitConfigurationServices = planBenefitConfigurationServices;
            _tradingPartnerBenefitConfigurationRepositories = tradingPartnerBenefitConfigurationRepositories;
            _mapper = mapper;
        }

        [HttpPost]
        public IActionResult Post([FromBody]TradingPartnerBenefitConfigurationModel tradingPartnerBenefitConfigurationModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                TradingPartnerBenefitConfiguration entity = _mapper.Map<TradingPartnerBenefitConfiguration>(tradingPartnerBenefitConfigurationModel);

                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _tradingPartnerBenefitConfigurationRepositories.Add(entity);
            }
            catch 
            {
                return BadRequest(ConstError.SystemError);
            }
            return Ok();
        }

        [HttpPut]
        public IActionResult Put([FromBody]TradingPartnerBenefitConfigurationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                TradingPartnerBenefitConfiguration entity = _tradingPartnerBenefitConfigurationRepositories.GetById(model.TradingPartnerBenefitConfigurationId);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;                
                _tradingPartnerBenefitConfigurationRepositories.Update(entity);
            }
            catch 
            {
                return BadRequest(ConstError.SystemError);
            }
            return Ok();
        }
    }    

}
