using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.EDI.Custom;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/FileNamingConvention")]
    public class FileNamingConventionAPIController : BaseAPIController
    {
        // GET: /<controller>/
        #region Variables    
        private ILogger<DataConfigurationAPIController> _logger;
        private IEdiTpRepositories _IEdiTpRepositories;
        private IMapper _mapper;
        #endregion
        public FileNamingConventionAPIController(IEdiTpRepositories IEdiTpRepositories, IMapper mapper
            , ILogger<DataConfigurationAPIController> logger)
        {
            _IEdiTpRepositories = IEdiTpRepositories;
            _logger = logger;
            _mapper = mapper;
        }
        [HttpGet]
        [Route("{FileNamingConventionID}")]
        public IActionResult Get(short FileNamingConventionID)
        {
            var objentity = _IEdiTpRepositories.GetFileNamingConventionById(FileNamingConventionID);
            var result = _mapper.Map<FileNamingConventionModel>(objentity);
            return Ok(result);
        }
        [HttpPost]
        public IActionResult Post([FromBody]FileNamingConventionModel model)
        {
            try
            {
                // _logger.LogInformation("Creating a new FileNamingConventionModel");
                FileNamingConvention objentity = _mapper.Map<FileNamingConvention>(model);
                // objentity.DateTimeFormat = "";
                objentity.CreatedDate = DateTime.Now;
                short Id = _IEdiTpRepositories.SaveFileNamingConventionDetail(objentity, model.DataFileConfigurationId);
                if (!_IEdiTpRepositories.DbState.IsValid)
                {
                    _logger.LogError("Could not save Clinic to the database");
                    _IEdiTpRepositories.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                else
                {
                    return Created(string.Empty,Id);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while DataFileConfiguration Clinic: {ex}");
            }
            return BadRequest();
        }

        [HttpPut]
        public IActionResult Put([FromBody]FileNamingConventionModel model)
        {
            try
            {
                FileNamingConvention olddata = _IEdiTpRepositories.GetFileNamingConventionById(model.FileNamingConventionID);

                olddata.Prefix = model.Prefix;
                olddata.DateTimeFormat = model.DateTimeFormat;
                olddata.RandomNumber = model.RandomNumber;
                olddata.TPName = model.TPName;
                olddata.FileType = model.FileType;
                olddata.FileExtension = model.FileExtension;
                olddata.NameSeparator = model.NameSeparator;

                // _mapper.Map(model.FileNamingSequenceModel, olddata.FileNamingSequence.ToList());
                olddata.FileNamingSequence = _IEdiTpRepositories.GetlistFileNamingSequenceId(model.FileNamingConventionID);
                foreach (var item in model.FileNamingSequenceModel)
                {

                    FileNamingSequence obj =  
                       olddata.FileNamingSequence.Where(a => a.ColumnName == item.ColumnName).FirstOrDefault();
                    obj.SequenceNumber = item.SequenceNumber;
                    //_mapper.Map(item, obj);
                }

                _IEdiTpRepositories.UpdateFileNamingConvention(olddata);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while FileNamingConventionModel: {ex}");
            }
            return BadRequest("Couldn't update TradingPartner");
        }
        [HttpDelete]
        [Route("{FileNamingConventionID}/{DataFileConfigurationId}")]
        public IActionResult Delete(short FileNamingConventionID, short DataFileConfigurationId)
        {
            try
            {
                FileNamingConvention olddata = _IEdiTpRepositories.GetFileNamingConventionById(FileNamingConventionID);
                if (olddata != null)
                {
                    _IEdiTpRepositories.DeleteFileNamingConvention(DataFileConfigurationId,olddata);
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while FileNamingConvention {ex}");
            }
            return BadRequest("Couldn't Delete FileNamingConvention");
        }
    }
}
