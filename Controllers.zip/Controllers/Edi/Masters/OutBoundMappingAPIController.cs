using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("api/OutBoundMapping")]
    public class OutBoundMappingAPIController : BaseAPIController
    {
        private readonly IEdiOutBoundConfigurationService _ediOutBoundConfigurationService;
        private readonly IEdiOutBoundConfiguration _ediOutBoundConfiguration;
        private readonly IElementRepository _elementRepository;

        public OutBoundMappingAPIController(IEdiOutBoundConfigurationService ediOutBoundConfigurationService, IEdiOutBoundConfiguration ediOutBoundConfiguration, IElementRepository elementRepository)
        {
            _ediOutBoundConfigurationService = ediOutBoundConfigurationService;
            _ediOutBoundConfiguration = ediOutBoundConfiguration;
            _elementRepository = elementRepository;
        }

        [HttpGet]
        [Route("GetViewSchema")]
        public IActionResult GetViewSchema()
        {
            try
            {
                var ViewSchema = _ediOutBoundConfigurationService.GetViewSchemaInfo();
                return Ok(ViewSchema);
            }
            catch
            {
                return BadRequest(ConstError.SystemError);
            }
        }

        [HttpGet]
        [Route("GetTableSchema")]
        public IActionResult GetTableSchema()
        {
            try
            {
                var TableSchema = _ediOutBoundConfigurationService.GetTableSchemaInfo();
                return Ok(TableSchema);
            }
            catch
            {
                return BadRequest(ConstError.SystemError);
            }
        }


        [HttpPost]
        public IActionResult AddMapping([FromBody]OutboundMappingconfiguration Mapping)
        {
            Mapping.UpdatedBy = Mapping.CreatedBy = UserName;
            Mapping.UpdatedDate = Mapping.CreatedDate = TodaysDate;
            Mapping.RecordStatus = (byte)RecordStatus.Active;


            List<OutboundMappingconfiguration> OutboundMappingconfigurations = new List<OutboundMappingconfiguration>();
            var Elements = _elementRepository.GetByPredicate(e => e.ChildElementID == Mapping.ElementID);
            foreach (var Element in Elements)
            {
                if (_ediOutBoundConfiguration.GetByPredicate(e => e.ElementID == Element.ElementID && e.DataFileConfigurationID == Mapping.DataFileConfigurationID).ToList().Count == 0)
                {
                    var mappingSource = _ediOutBoundConfigurationService.GetMappingSource().FirstOrDefault(e => e.ElementID == Element.ElementID);
                    OutboundMappingconfigurations.Add(new OutboundMappingconfiguration
                    {
                        CreatedBy = UserName,
                        UpdatedBy = UserName,
                        CreatedDate = TodaysDate,
                        UpdatedDate = TodaysDate,
                        RecordStatus = (byte)RecordStatus.Active,
                        DataFileConfigurationID = Mapping.DataFileConfigurationID,
                        ElementID = Element.ElementID,
                        DestinationField = Element.ElementValue,
                        SourceField = mappingSource == null ? "" : mappingSource.ElementValue
                    });
                }
            }

            OutboundMappingconfigurations.Add(Mapping);

            _ediOutBoundConfiguration.AddRange(OutboundMappingconfigurations.ToArray());

            return Ok();
        }


        [HttpPut]
        public IActionResult UpdateMapping([FromBody]OutboundMappingconfiguration Mapping)
        {
            try
            {
                var MappingUpdate = _ediOutBoundConfiguration.GetById(Mapping.OutboundMappingconfigurationID);

                MappingUpdate.UpdatedBy = UserName;
                MappingUpdate.UpdatedDate = TodaysDate;
                MappingUpdate.SourceField = Mapping.SourceField;

                _ediOutBoundConfiguration.Update(MappingUpdate);
            }
            catch
            {
                return BadRequest(ConstError.SystemError);
            }
            return Ok();
        }

    }
}
