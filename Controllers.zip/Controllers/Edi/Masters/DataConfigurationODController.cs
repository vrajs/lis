using Kwicle.Data.Contracts.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Extensions.Logging;
using System;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.Masters
{
    [Route("odata")]
    public class DataConfigurationODController : BaseODController
    {
        #region Variables
        private readonly ILogger<DataConfigurationODController> _logger;
        private IEdiTpRepositories _IEdiTpRepositories;
        //private readonly Data.KwicleContext _context;
        #endregion
        #region Constructor
        public DataConfigurationODController(ILogger<DataConfigurationODController> logger,IEdiTpRepositories EdiTpRepositories)
        {
            _logger = logger;
            _IEdiTpRepositories = EdiTpRepositories;
        }
        #endregion
        #region Method

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("DataConfigurations")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetDataConfigurations(short TradingPartnerId)
        {
            try
            {
                var TradingPartnerListQuery = _IEdiTpRepositories.GetDataConfigByTId(TradingPartnerId);
                return Ok(TradingPartnerListQuery);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Threw exception while DataFileConfiguration: {ex}");
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
