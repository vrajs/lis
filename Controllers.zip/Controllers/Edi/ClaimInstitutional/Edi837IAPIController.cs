using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimInstitutional
{
    [Route("api/Edi837I")]
    public class Edi837IAPIController : BaseAPIController
    {
        private ILogger<Edi837IAPIController> _logger;
        private readonly IEdi837IServices _edi837IServices;
        private IMapper _mapper;
        public Edi837IAPIController(ILogger<Edi837IAPIController> logger, IEdi837IServices edi837IServices, IMapper mapper)
        {
            _logger = logger;
            _edi837IServices = edi837IServices;
            _mapper = mapper;
        }
        [HttpPut]
        [Route("SaveClaimDetailOverview")]
        public IActionResult SaveClaimDetailOverview([FromBody]vwClaimIEditDetail objClaimEditDetail)
        {
            try
            {
                var objentity = _edi837IServices.GetClaimInstitutional(objClaimEditDetail.ClaimInstitutionalID);
                _mapper.Map(objClaimEditDetail, objentity);
                //_edi837IServices.SaveClaimDetail(objentity);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting EDI Institutional Claim Error : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        [Route("AddClaimServiceline")]
        public IActionResult AddClaimServiceline([FromBody]ServiceLineI objClaimServiceLine)
        {
            try
            {
                var objentity = _mapper.Map<ClaimInstitutionalServices>(objClaimServiceLine);
                _edi837IServices.AddClaimDetailServiceLine(objentity);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Adding Institutioanl Claim Service : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("SaveClaimDetailServiceLine")]
        public IActionResult SaveClaimDetailServiceLine([FromBody]ServiceLineI objClaimServiceLine)
        {
            try
            {
                var objentity = _edi837IServices.GetClaimInstitutionalServices(objClaimServiceLine.ClaimInstitutionalID, objClaimServiceLine.ID);
                var objsavedata = _mapper.Map(objClaimServiceLine, objentity);
                objsavedata.UpdatedBy = base.UserName;
                objsavedata.UpdatedDate = base.TodaysDate;
                bool val = _edi837IServices.SaveClaimDetailServiceLine(objsavedata);
                return Ok(val);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Updating EDI Institutional service Line : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
