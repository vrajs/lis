using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities.EDI.Custom;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimInstitutional
{
    [Route("api/Edi837IUpload")]
    public class Edi837IUploadAPIController : BaseAPIController
    {
        private ILogger<Edi837IUploadAPIController> _logger;
        private readonly IEdi837IServices _edi837IServices;
        private readonly IEdiTradingPartnerServices _ediTradingPartnerServices;
        private readonly IEdiClaimService _ediClaimService;
        private readonly IEdiFileProcessServices _ediFileProcessServices;
        private IMapper _mapper;

        public Edi837IUploadAPIController(ILogger<Edi837IUploadAPIController> logger, IEdi837IServices edi837IServices, IEdiTradingPartnerServices ediTradingPartnerServices,
            IEdiClaimService ediClaimService, IEdiFileProcessServices ediFileProcessServices, IMapper mapper)
        {
            _logger = logger;
            _edi837IServices = edi837IServices;
            _mapper = mapper;
            _ediTradingPartnerServices = ediTradingPartnerServices;
            _ediClaimService = ediClaimService;
            _ediFileProcessServices = ediFileProcessServices;
        }

        [HttpPost]
        [Route("GetEDI837IFiles/{TradingPartnerId}")]
        public async Task<IActionResult> Parsh837I(IFormFile file, short TradingPartnerId)
        {
            string Response = string.Empty;
            string FileContent = string.Empty;
            try
            {
                using (var Reader = new StreamReader(file.OpenReadStream()))
                {
                    FileContent = await Reader.ReadToEndAsync();
                }
                EDIUploadFile UploadFile = new EDIUploadFile
                {
                    FileContent = FileContent,
                    FileName = file.FileName,
                    CreatedBy = base.UserName,
                    Filetype = "837I"
                };
                var TP = _ediTradingPartnerServices.GetTradingPartnerDetails(TradingPartnerId);
                Response = _edi837IServices.Parse837I(TP, UploadFile);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving calimI ServiceLine : {0}", ex);
                return BadRequest(ConstError.InvalidFile);
            }
            return Ok(Response);
        }

        [HttpPost]
        [Route("ClaimInstitutionalDelete")]
        public IActionResult DeleteFileClaim([FromBody]List<int> Files)
        {
            try
            {
                return Json(_edi837IServices.DeleteClaimByFileID(Files, base.UserName, base.TodaysDate));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Deletting Institutional File : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetClaimDetailById/{ClaimOid}")]
        public IActionResult GetClaimDetailById(int ClaimOid)
        {
            try
            {
                var ClaimDetail = _edi837IServices.GetClaimInstitutional(ClaimOid);
                return Ok(_mapper.Map<vwClaimIEditDetail>(ClaimDetail));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Deletting Institutional File : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("SaveClaimDetailOverview")]
        public IActionResult SaveClaimDetailOverview([FromBody]vwClaimIEditDetail objClaimEditDetail)
        {
            try
            {
                var objentity = _edi837IServices.GetClaimInstitutional(objClaimEditDetail.ClaimInstitutionalID);
                _mapper.Map(objClaimEditDetail, objentity);
                objentity.UpdatedBy = base.UserName;
                objentity.UpdatedDate = base.TodaysDate;
                objentity.ClaimStatus = 0;
                _edi837IServices.SaveClaimDetail(objentity, objClaimEditDetail.isApplySameFix);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Saving Institutional Claim : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("SubmitEDIClaimIToHPS")]
        public IActionResult SubmitEDIClaimToHPS()
        {
            try
            {
                _ediClaimService.SubmitEDIClaimInstitutionalToHPS();
                _ediFileProcessServices.UploadFile();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Saving Institutional Claim : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetInstitutionalClaimError/{ClaimInstitutionalId}")]
        public IActionResult GetProfessionalClaimError(int ClaimInstitutionalId)
        {
            try
            {
                var ClaimError = _edi837IServices.GetInstitutionalClaimError(ClaimInstitutionalId);
                return Ok(ClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Saving Institutional Claim : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetInstitutionalClaimErrorHistory/{ClaimInstitutionalId}")]
        public IActionResult GetProfessionalClaimErrorHistory(int ClaimInstitutionalId)
        {
            try
            {
                var ClaimError = _edi837IServices.GetInstitutionalClaimErrorHistory(ClaimInstitutionalId);
                return Ok(ClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Saving Institutional Claim : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
