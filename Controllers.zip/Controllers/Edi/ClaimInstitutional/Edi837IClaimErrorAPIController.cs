using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimProfessional
{
    [EnableCors("AnyGET")]
    [Route("api/Edi837IClaimError")]
    public class Edi837IClaimErrorAPIController : BaseAPIController
    {
        private ILogger<Edi837IClaimErrorAPIController> _logger;
        public IEdi837IErrorServices _edi837IErrorServices;
        public Edi837IClaimErrorAPIController(ILogger<Edi837IClaimErrorAPIController> logger, IEdi837IErrorServices edi837IErrorServices)
        {
            _logger = logger;
            _edi837IErrorServices = edi837IErrorServices;
        }
        [HttpGet]
        [Route("GetMemberById/{memberid}")]
        public IActionResult GetMemberById(int memberid)
        {
            try
            {
                var objmember = _edi837IErrorServices.GetMemberById(memberid);
                return Ok(objmember);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting Member : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetproviderById/{providerid}")]
        public IActionResult GetproviderById(int providerid)
        {
            try
            {
                var objprovider = _edi837IErrorServices.GetproviderById(providerid);
                return Ok(objprovider);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting provider : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetInstitutionalClaimError/{ClaimInstitutionalId}/{ErrorCode}")]
        public IActionResult GetInstitutionalClaimError(int ClaimInstitutionalId, string ErrorCode)
        {
            try
            {
                var ClaimError = _edi837IErrorServices.GetInstitutionalClaimError(ClaimInstitutionalId, ErrorCode);
                return Ok(ClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting EDI Institutional Claim Error : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("UpdateClaimInstitutionalError")]
        public IActionResult UpdateClaimInstitutionalError([FromBody]vwClaimProfessionalErrorModel objModel)
        {
            try
            {
                _edi837IErrorServices.UpdateClaimInstitutionalError(objModel);
                return Ok(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Update Claim Institutional : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetMemberInstitutionalByClaimId/{ClaimInstitutionalId}")]
        public IActionResult GetMemberInstitutionalByClaimId(int ClaimInstitutionalId)
        {
            try
            {
                var objmember = _edi837IErrorServices.GetMemberInstitutionalByClaimId(ClaimInstitutionalId);
                return Ok(objmember);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting EDI Institutional Claim Error : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetInstitutionalClaimErrorByClaimId/{ClaimInstitutionalId}")]
        public IActionResult GetInstitutionalClaimErrorByClaimId(int ClaimInstitutionalId)
        {
            try
            {
                var objClaimError = _edi837IErrorServices.GetInstitutionalClaimErrorByClaimId(ClaimInstitutionalId);
                return Ok(objClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting EDI Institutional Claim Error : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
