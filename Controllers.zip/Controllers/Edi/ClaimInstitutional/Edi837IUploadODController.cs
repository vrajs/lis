using System;
using System.Linq;
using AutoMapper;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimInstitutional
{
    [Route("odata")]
    public class Edi837IUploadODController : BaseODController
    {
        private readonly IMapper _mapper;
        private readonly IEdi837IServices _edi837IServices;
        private readonly IEdi837IErrorServices _edi837IErrorServices;
        private readonly IEDI837IDiagCodeRepository _IEDI837IDiagCodeRepository;
        private readonly IEDI837IServiceLineRepository _IEDI837IServiceLineRepository;
        public Edi837IUploadODController(IMapper mapper,
            IEdi837IServices edi837IServices,
            IEDI837IDiagCodeRepository IEDI837IDiagCodeRepository,
            IEDI837IServiceLineRepository IEDI837IServiceLineRepository,
            IEdi837IErrorServices edi837IErrorServices)
        {
            _mapper = mapper;
            _edi837IServices = edi837IServices;
            _IEDI837IDiagCodeRepository = IEDI837IDiagCodeRepository;
            _IEDI837IServiceLineRepository = IEDI837IServiceLineRepository;
            _edi837IErrorServices = edi837IErrorServices;
        }
        [HttpGet]
        [ConvertUrlToOdataV4]        
        [Route("EDI837IUploadFilesList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEdi837IFilesList()
        {           
            var Files = _edi837IServices.GetEdi837IFilesList();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]        
        [Route("EDI837IUploadClaimsList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEdi837IClaimsList()
        {
            var Files = _edi837IServices.GetEdi837IClaimsList();
            return Ok(Files);
        }
        [HttpGet]
        [ConvertUrlToOdataV4]        
        [Route("EDI837IInstitutionalDiagnosisCode")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetInstitutionalDiagnosisCode(int claimid , string categoryids)
        {
            InstitutionalDiagnosisCodeParam objparam = new InstitutionalDiagnosisCodeParam();
            objparam.ClaimInstitutionalID = claimid;
            objparam.categoryids = categoryids.Split(',').Select(Int32.Parse).ToArray();
            var Files = _IEDI837IDiagCodeRepository.GetInstitutionalDiagnosisCode(objparam);
            return Ok(Files);
        }
        [HttpGet]
        [ConvertUrlToOdataV4]        
        [Route("EDI837IServiceLine")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All,HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetServiceLine(int Claimid)
        {
            var obj = _IEDI837IServiceLineRepository.GetServiceLine(Claimid);         
            return Ok(obj);
        }
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetInstitutionalClaimErrors")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetInstitutionalClaimErrors()
        {
            var claimErrorlist = _edi837IErrorServices.GetInstitutionalClaimErrors();
            return Ok(claimErrorlist);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetInstitutionalErrorClaims")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetInstitutionalErrorClaims()
        {
            var ClaimError = _edi837IErrorServices.GetInstitutionalErrorClaim();
            return Ok(ClaimError);
        }
    }
}
