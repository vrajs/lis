using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Edi.ClaimInstitutional
{
    [Route("api/EDI837IDiagCode")]
    public class EDI837IDiagCodeAPIController : BaseAPIController
    {
        private ILogger<EDI837IDiagCodeAPIController> _logger;
        private IMapper _mapper;
        private IEDI837IDiagCodeRepository _IEDI837IDiagCodeRepository;
        public EDI837IDiagCodeAPIController(IEDI837IDiagCodeRepository IEDI837IDiagCodeRepository,
                                         ILogger<EDI837IDiagCodeAPIController> logger,
                                         IMapper mapper)
        {
            _logger = logger;
            _IEDI837IDiagCodeRepository = IEDI837IDiagCodeRepository;
            _mapper = mapper;
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]vwInstitutionalDiagnosisCode model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                if (_IEDI837IDiagCodeRepository.CheckDuplicateDiag(model))
                {
                    return BadRequest("Duplicate find");
                }
                else
                {
                    var claimDiagnosis = _mapper.Map<InstitutionalDiagnosisCode>(model);
                    claimDiagnosis.RecordStatus = (int)RecordStatus.Active;
                    claimDiagnosis.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    _IEDI837IDiagCodeRepository.Add(claimDiagnosis);
                    if (!_IEDI837IDiagCodeRepository.DbState.IsValid)
                    {
                        _IEDI837IDiagCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return Json(BadRequest(ModelState));
                    }
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimDiagnosis : {0}", ex);
                return BadRequest(ConstError.InvalidFile);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]vwInstitutionalDiagnosisCode model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                if (_IEDI837IDiagCodeRepository.CheckDuplicateDiag(model))
                {
                    return BadRequest("Duplicate find");
                }
                else
                {
                    var claimDiagnosis = _IEDI837IDiagCodeRepository.GetById(model.InstitutionalDiagnosisCodeId);
                    _mapper.Map(model, claimDiagnosis);
                    _IEDI837IDiagCodeRepository.Update(claimDiagnosis);
                    if (!_IEDI837IDiagCodeRepository.DbState.IsValid)
                    {
                        _IEDI837IDiagCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimDiagnosis : {0}", ex);
                return BadRequest(ConstError.SystemError);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
#pragma warning disable CS0612 // Type or member is obsolete
                _IEDI837IDiagCodeRepository.DeleteById(id);
#pragma warning restore CS0612 // Type or member is obsolete
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimDiagnosis : {0}", ex);
                return BadRequest(ConstError.SystemError);
            }
        }
    }
}
