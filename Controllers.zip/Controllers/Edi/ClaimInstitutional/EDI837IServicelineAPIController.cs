using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Edi.ClaimInstitutional
{
    [Route("api/EDI837IServiceline")]
    public class EDI837IServicelineAPIController : BaseAPIController
    {
        private ILogger<EDI837IServicelineAPIController> _logger;
        private IMapper _mapper;
        private IEDI837IServiceLineRepository _IEDI837IServiceLineRepository;
        public EDI837IServicelineAPIController(IEDI837IServiceLineRepository IEDI837IServiceLineRepository,
                                         ILogger<EDI837IServicelineAPIController> logger,
                                         IMapper mapper)
        {
            _logger = logger;
            _IEDI837IServiceLineRepository = IEDI837IServiceLineRepository;
            _mapper = mapper;
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]vwClaimIServiceLine model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                //if (_IEDI837IServiceLineRepository.CheckDuplicateDiag(model))
                //{
                //    return Json(BadRequest("Duplicate find"));
                //}
                //else
                {
                    var obj = _mapper.Map<ClaimInstitutionalServices>(model);
                    obj.RecordStatus = (int)RecordStatus.Active;
                    obj.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    obj.CreatedDate = base.TodaysDate;
                    obj.CreatedBy = base.UserName;
                    _IEDI837IServiceLineRepository.Add(obj);
                    if (!_IEDI837IServiceLineRepository.DbState.IsValid)
                    {
                        _IEDI837IServiceLineRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return Json(BadRequest(ModelState));
                    }
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving calimI ServiceLine : {0}", ex);
                return BadRequest(ConstError.SystemError);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]vwClaimIServiceLine model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                //if (_IEDI837IDiagCodeRepository.CheckDuplicateDiag(model))
                //{
                //    return Json(BadRequest("Duplicate find"));
                //}
                //else
                {
                    var obj = _IEDI837IServiceLineRepository.GetById(model.ID);
                    obj.UpdatedDate = base.TodaysDate;
                    obj.UpdatedBy = base.UserName;
                    _mapper.Map(model, obj);
                    _IEDI837IServiceLineRepository.Update(obj);
                    if (!_IEDI837IServiceLineRepository.DbState.IsValid)
                    {
                        _IEDI837IServiceLineRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                    return Created(string.Empty, true);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving calimI ServiceLine : {0}", ex);
                return BadRequest(ConstError.SystemError);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IEDI837IServiceLineRepository.DeleteById(id);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting calimI ServiceLine : {0}", ex);
                return BadRequest(ConstError.SystemError);
            }
        }
    }
}
