using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimProfessional
{
    [Route("api/Edi837PUpload")]
    public class Edi837PUploadAPIController : BaseAPIController
    {
        private readonly ILogger<Edi837PUploadAPIController> _logger;
        private readonly IEdi837PServices _edi837Services;
        private readonly IEdiTradingPartnerServices _ediTradingPartnerServices;
        private readonly IEdiClaimService _ediClaimService;
        private readonly IEdiFileProcessServices _ediFileProcessServices;
        private readonly IEdi837PErrorServices _edi837PErrorServices;
        private IMapper _mapper;

        public Edi837PUploadAPIController(ILogger<Edi837PUploadAPIController> logger, IEdi837PServices edi837PServices, IEdiTradingPartnerServices ediTradingPartnerServices,
            IMapper mapper, IEdiClaimService ediClaimService, IEdiFileProcessServices ediFileProcessServices, IEdi837PErrorServices edi837PErrorServices)
        {
            _logger = logger;
            _edi837Services = edi837PServices;
            _ediTradingPartnerServices = ediTradingPartnerServices;
            _mapper = mapper;
            _ediClaimService = ediClaimService;
            _ediFileProcessServices = ediFileProcessServices;
            _edi837PErrorServices = edi837PErrorServices;
        }

        [HttpPost]
        [Route("GetEDI837PFiles/{DataFileConfigurationID}")]
        public async Task<IActionResult> Parsh837P(IFormFile file, short DataFileConfigurationID)
        {
            string response;
            string FileContent = string.Empty;
            try
            {                
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    FileContent = await reader.ReadToEndAsync();
                }
                EDIUploadFile objEDI837IFile = new EDIUploadFile
                {
                    FileContent = FileContent,
                    FileName = file.FileName,
                    CreatedBy = base.UserName,
                    Filetype = "837P"
                };
                var TP = _ediTradingPartnerServices.GetTradingPartnerDetails(DataFileConfigurationID);
                response = _edi837Services.Parse837P(TP, objEDI837IFile);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Uploading EDI 837 File: {0}", ex);
                return BadRequest(ConstError.InvalidFile);
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("GetFileData/{x12DocumentID}")]
        public IActionResult GetFileData(int x12DocumentID)
        {
            List<string> response;
            try
            {
                response = _edi837Services.GetFileData(x12DocumentID);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Generatting EDI 837 File: {0}", ex);
                return BadRequest(ex.Message);
            }

        }


        [HttpGet]
        [Route("GetFileProcessHistory/{x12DocumentID}")]
        public IActionResult GetFileProcessHistory(int x12DocumentID)
        {
            try
            {
                var FileHistory = _edi837Services.GetFileHistory(x12DocumentID);
                return Ok(FileHistory);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Getting Professional File History: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("ClaimProfessionalDelete")]
        public IActionResult DeleteFileClaim([FromBody]List<int> Files)
        {
            try
            {
                return Ok(_edi837Services.DeleteClaimByFileID(Files, base.UserName, base.TodaysDate));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Deletting EDI 837 File: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetClaimDetailById/{ClaimOid}")]
        public IActionResult GetClaimDetailById(int ClaimOid)
        {
            try
            {
                var ClaimDetail = _edi837Services.GetClaimProfessional(ClaimOid);
                return Ok(_mapper.Map<vwClaimEditDetail>(ClaimDetail));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Generatting Professional claim Detail: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("SaveClaimDetailOverview")]
        public IActionResult SaveClaimDetailOverview([FromBody]vwClaimEditDetail objClaimEditDetail)
        {
            try
            {
                var objentity = _edi837Services.GetClaimProfessional(objClaimEditDetail.ClaimProfessionalId);
                _mapper.Map(objClaimEditDetail, objentity);
                objentity.UpdatedBy = base.UserName;
                objentity.UpdatedDate = base.TodaysDate;
                objentity.ClaimStatus = 0;
                _edi837Services.SaveClaimDetail(objentity, objClaimEditDetail.isApplySameFix);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Updatting EDI Professioan Claim Detail: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProfessionalClaimError/{ClaimProfessionalId}")]
        public IActionResult GetProfessionalClaimError(int ClaimProfessionalId)
        {
            try
            {
                var ClaimError = _edi837PErrorServices.GetProfessionalClaimError(ClaimProfessionalId);
                return Ok(ClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Generatting Professaion claim Errors: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProfessionalClaimErrorHistory/{ClaimProfessionalId}")]
        public IActionResult GetProfessionalClaimErrorHistory(int ClaimProfessionalId)
        {
            try
            {
                var ClaimError = _edi837PErrorServices.GetProfessionalClaimErrorHistory(ClaimProfessionalId);
                return Ok(ClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Generatting Professional Claim Error History: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("AddClaimServiceline")]
        public IActionResult AddClaimServiceline([FromBody]ServiceLine objClaimServiceLine)
        {
            try
            {
                var objentity = _mapper.Map<ClaimProfessionalServices>(objClaimServiceLine);
                _edi837Services.AddClaimDetailServiceLine(objentity);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Adding Professional Service Line: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("SaveClaimDetailServiceLine")]
        public IActionResult SaveClaimDetailServiceLine([FromBody]ServiceLine objClaimServiceLine)
        {
            try
            {
                var objentity = _edi837Services.GetClaimProfessionalServices(objClaimServiceLine.ClaimProfessionalId, objClaimServiceLine.Mtab_x12_837_services_oid);
                var objsavedata = _mapper.Map(objClaimServiceLine, objentity);
                objsavedata.UpdatedBy = base.UserName;
                objsavedata.UpdatedDate = base.TodaysDate;
                bool val = _edi837Services.SaveClaimDetailServiceLine(objsavedata);
                return Ok(val);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Updatting Professional Service Line: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("DeleteClaimDetailServiceLine/{serviceid}")]
        public IActionResult DeleteClaimDetailServiceLine(int serviceid)
        {
            try
            {
                var objsavedata = _edi837Services.GetClaimProfessionalServices(0, ServiceId: serviceid);
                objsavedata.UpdatedBy = base.UserName;
                objsavedata.UpdatedDate = base.TodaysDate;
                objsavedata.RecordStatus = (int)RecordStatus.Deleted;
                bool val = _edi837Services.SaveClaimDetailServiceLine(objsavedata);
                return Ok(val);
            }
            catch
            {
                return BadRequest(ConstError.SystemError);
            }
        }

        [HttpGet]
        [Route("GetCMS1500pdf/{CLaimID}")]
        public IActionResult GetCMS1500pdf(int CLaimID)
        {
            var obyte = _edi837Services.GetCMS1500Data(CLaimID);
            return Ok(obyte);
        }


        [HttpGet]
        [Route("SubmitEDIClaimToHPS")]
        public IActionResult SubmitEDIClaimToHPS()
        {
            _ediClaimService.SubmitEDIClaimToHPS();
            _ediFileProcessServices.UploadFile();
            return Ok();
        }

    }


}
