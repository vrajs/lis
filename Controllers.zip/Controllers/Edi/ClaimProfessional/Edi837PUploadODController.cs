using AutoMapper;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using System.Linq;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimProfessional
{
    [Route("odata")]
    public class Edi837PUploadODController : BaseODController
    {
        private readonly IEdi837PServices _edi837Services;
        public IEdi837PErrorServices _edi837PErrorServices;
        private IMapper _mapper;
        public Edi837PUploadODController(IEdi837PServices edi837Services, IMapper mapper, IEdi837PErrorServices edi837PErrorServices)
        {
            _edi837Services = edi837Services;
            _mapper = mapper;
            _edi837PErrorServices = edi837PErrorServices;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI837PUploadFiles")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEdi837PFiles()
        {
            var Files = _edi837Services.GetEdi837P();
            return Ok(Files);
        }
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI837PUploadClaims")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEdi837PClaims()
        {
            var Files = _edi837Services.GetEdi837PClaims();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDIClaimServiceLine")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult Get837PServiceLine(int Claimid, int ServiceId)
        {
            var Files = _edi837Services.GetClaimServiceLine(Claimid, ServiceId);
            // var obj = _mapper.Map<IQueryable<ServiceLine>>(Files);
            return Ok(Files);
        }

        #region Encounter
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetEncounterFilelist")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetEncounterFilelist()
        {
            var Files = _edi837Services.GetEncounterFileList();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetEncounterClaimList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetEncounterClaimList()
        {

            var Encounters = _edi837Services.GetEncounterClaimList();
            return Ok(Encounters);
        }
        #endregion


        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetProfessionalClaimErrors")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetProfessionalClaimErrors()
        {        
            var Files = _edi837PErrorServices.GetProfessionalClaimErrors();
            return Ok(Files);
        }
                
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetProfessionalErrorClaims")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetProfessionalErrorClaims()
        {
            var ClaimError = _edi837PErrorServices.GetProfessionalErrorClaim();
            return Ok(ClaimError);
        }
    }
}
