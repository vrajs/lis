using Microsoft.AspNetCore.Mvc;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Kwicle.API.Controllers;
using System.Linq;
using Kwicle.Core.Common;
using System;
using Microsoft.Extensions.Logging;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimProfessional
{
    [EnableCors("AnyGET")]
    [Route("api/Edi837P")]
    public class Edi837PAPIController : BaseAPIController
    {

        private readonly ILogger<Edi837PAPIController> _logger;
        private readonly IEdi837PServices _edi837PServices;

        public Edi837PAPIController(ILogger<Edi837PAPIController> logger,IEdi837PServices edi837PServices)
        {
            _logger = logger;
            _edi837PServices = edi837PServices;
        }

        [HttpPost]
        [Route("GenerateEDI837P")]
        public IActionResult GenerateEDI837Professional([FromBody]int X12DocumentID)
        {
            try
            {
                _edi837PServices.GenerateEncounterData(X12DocumentID);
                return Created(string.Empty, X12DocumentID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Generatting EDI 837 File: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{X12DocumentID}")]
        public IActionResult DeleteFileClaim(int X12DocumentID)
        {
            try
            {
                return Ok(_edi837PServices.DeleteEncounterFile(X12DocumentID, base.UserName, base.TodaysDate));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Generatting EDI 837 File: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
