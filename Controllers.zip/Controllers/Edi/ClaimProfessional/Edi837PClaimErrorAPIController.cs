using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Common.Utility;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimProfessional
{
    [EnableCors("AnyGET")]
    [Route("api/Edi837PClaimError")]
    public class Edi837PClaimErrorAPIController : BaseAPIController
    {
        private readonly ILogger<Edi837PClaimErrorAPIController> _logger;
        private readonly IEdi837PErrorServices _edi837PErrorServices;
        public Edi837PClaimErrorAPIController(ILogger<Edi837PClaimErrorAPIController> logger, IEdi837PErrorServices edi837PErrorServices)
        {
            _logger = logger;
            _edi837PErrorServices = edi837PErrorServices;
        }
        [HttpGet]
        [Route("GetMemberById/{memberid}")]
        public IActionResult GetMemberById(int memberid)
        {
            try
            {
                var objmember = _edi837PErrorServices.GetMemberById(memberid);
                return Ok(objmember);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Member By ID: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetproviderById/{providerid}")]
        public IActionResult GetproviderById(int providerid)
        {
            try
            {
                var objprovider = _edi837PErrorServices.GetproviderById(providerid);
                return Ok(objprovider);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Provider By ID: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetProfessionalClaimError/{ClaimProfessionalId}/{ErrorCode}")]
        public IActionResult GetProfessionalClaimError(int ClaimProfessionalId, string ErrorCode)
        {
            try
            {
                var ClaimError = _edi837PErrorServices.GetProfessionalClaimError(ClaimProfessionalId, ErrorCode);
                return Ok(ClaimError);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Professional Claim Error By ID: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("UpdateClaimProfessionalError")]
        public IActionResult UpdateClaimProfessionalError([FromBody]vwClaimProfessionalErrorModel objModel)
        {
            try
            {
                _edi837PErrorServices.UpdateClaimProfessionalError(objModel);
                return Ok(true);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI Professional Claim Error By ID: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetMemberProfessionalByClaimId/{Claimid}")]
        public IActionResult GetMemberProfessionalByClaimId(int Claimid)
        {
            try
            {
                var objmember = _edi837PErrorServices.GetMemberProfessionalByClaimId(Claimid);
                return Ok(objmember);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while EDI GetMemberProfessionalByClaimId: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetProfessionalClaimErrorByClaimId/{Claimid}")]
        public IActionResult GetProfessionalClaimErrorByClaimId(int Claimid)
        {
            try
            {
                var objmember = _edi837PErrorServices.GetProfessionalClaimErrorByClaimId(Claimid);
                return Ok(objmember);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while GetProfessionalClaimErrorByClaimId: {0}", ex);
                return BadRequest(ex.Message);
            }
        }



    }
}
