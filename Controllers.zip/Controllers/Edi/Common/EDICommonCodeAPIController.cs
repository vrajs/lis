using System;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel.Common;
using Newtonsoft.Json;
using Kwicle.Data.Contracts.EDI.Common;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.EDI.Common
{
    [Route("api/EDICommonCode")]
    public class EDICommonCodeAPIController : BaseAPIController
    {
        private readonly ILogger<EDICommonCodeAPIController> _logger;
        private readonly IEDICommonCodeRepository _IEDICommonCodeRepository;
        public EDICommonCodeAPIController(ILogger<EDICommonCodeAPIController> logger,IEDICommonCodeRepository IEDICommonCodeRepository)
        {
            _logger = logger;
            _IEDICommonCodeRepository = IEDICommonCodeRepository;
        }

        // GET: api/values
        [HttpGet("{CodeTypeId}/{FetchingTypeId}")]
        public IActionResult GetByCodeTypeId(Int16 CodeTypeId, Int16 FetchingTypeId = 0)
        {
            try
            {
                var commonCodes = _IEDICommonCodeRepository.GetCommonCodesByCodeTypeId(CodeTypeId, FetchingTypeId);
                return Ok(commonCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Generating EDI Code by type: {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpGet]
        [Route("GetCodeByTypeIds")]
        public IActionResult GetByCodeTypeIds(string jsonObject)
        {
            try
            {
                MultipleValueRequestModel request = JsonConvert.DeserializeObject<MultipleValueRequestModel>(jsonObject);
                var commonCodes = _IEDICommonCodeRepository.GetCommonCodesByCodeTypeIds(request);
                return Ok(commonCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Generating EDI Code by type id: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetKeyAsCodeByCodeTypeId/{CodeTypeId}/{FetchingTypeId}")]
        public IActionResult GetCommonCodesKeyAsCodeByCodeTypeId(Int16 CodeTypeId, Int16 FetchingTypeId = 0)
        {
            try
            {
                var commonCodes = _IEDICommonCodeRepository.GetCommonCodesKeyAsCodeByCodeTypeId(CodeTypeId, FetchingTypeId);
                return Ok(commonCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Generating EDI Code by type id and fetching type: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //[HttpGet("GetCommonCodeConfigurationByCodeTypeId/{PageId}/{CodeTypeId}")]
        //public IActionResult GetCommonCodeConfigurationByCodeTypeId(string PageId,int CodeTypeId)
        //{
        //    var commonCodesConfiguration = _IEDICommonCodeRepository.GetCommonCodeConfigurationByCodeTypeId(PageId, CodeTypeId);
        //    return Json(commonCodesConfiguration);
        //}
    }
}
