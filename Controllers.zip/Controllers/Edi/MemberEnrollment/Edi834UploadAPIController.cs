using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.StructureModel;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Edi.MemberEnrollment
{
    [Route("api/Edi834Upload")]
    public class Edi834UploadAPIController : BaseAPIController
    {
        private readonly ILogger<Edi834UploadAPIController> _logger;
        private readonly IEdiTradingPartnerServices _ediTradingPartnerServices;
        private readonly IEdi834Services _edi834Services;
        private readonly IEDIFileParsing _ediFileParsing;
        private IMapper _mapper;


        public Edi834UploadAPIController(ILogger<Edi834UploadAPIController> logger, IEdiTradingPartnerServices ediTradingPartnerServices,
            IEdi834Services edi834Services, IEDIFileParsing ediFileParsing, IMapper mapper)
        {
            _logger = logger;
            _ediTradingPartnerServices = ediTradingPartnerServices;
            _edi834Services = edi834Services;
            _ediFileParsing = ediFileParsing;
            _mapper = mapper;
        }

        //[HttpDelete("DeleteMemeberInbound/{X12_Document_id}")]
        //public IActionResult DeleteMemeberInbound(int X12_Document_id)
        //{
        //    try
        //    {
        //        _edi834Services.DeleteMemeberInbound(X12_Document_id);
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Error while Deletting Member Enrollment Inbound: {ex}");
        //        return BadRequest(ex.Message);
        //    }
        //}

        [HttpPost]
        [Route("ParseEDI834Files/{DataFileConfigurationID}")]
        public async Task<IActionResult> Parse834(IFormFile File, short DataFileConfigurationID)
        {
            string Response = string.Empty;
            string FileContent = string.Empty;
            try
            {
                using (var reader = new StreamReader(File.OpenReadStream()))
                {
                    FileContent = await reader.ReadToEndAsync();
                }

                var TP = _ediTradingPartnerServices.GetTradingPartnerDetails(DataFileConfigurationID);

                EDIUploadFile UploadFile = new EDIUploadFile
                {
                    FileContent = FileContent,
                    FileName = File.FileName,
                    CreatedBy = base.UserName,
                    Filetype = TP.CurTradingPartner.Module_Name
                };

                _ediFileParsing.SetCurTradingPartnerDetails(TP);

                var Errors = _ediFileParsing.BasicValidation(UploadFile.FileContent);

                if (!string.IsNullOrEmpty(Errors)) { return Ok(Errors); }

                _ediFileParsing.Generatfile(UploadFile.FileContent, UploadFile.FileName);

                var Validate = _ediFileParsing.ValidateEDI(UploadFile.FileContent);

                if (Validate.isValidate)
                {
                    var InterChnageList = _ediFileParsing.ParseMultiple(UploadFile);

                    foreach (var Interchange in InterChnageList)
                    {
                        var struct834 = Interchange.Transform<Structure834.Interchange>(Interchange.Serialize(true));

                        var EDIDocModel = _mapper.Map<EDIDocumentParseModel>(struct834);

                        EDIDocModel.x12_content = UploadFile.FileContent;

                        EDIDocModel.TradingPartnerId = TP.CurTradingPartner.TradingPartnerId.ToString();

                        EDIDocModel.DataFileConfigurationID = TP.CurTradingPartner.DataFileConfigurationID.ToString();

                        var ValidateModel = _ediFileParsing.ValidateDocumentAndParse(EDIDocModel);

                        if (ValidateModel != null && ValidateModel.X12DocumentId != 0)
                        {
                            //update doc
                            _ediFileParsing.UpdateDocument(ValidateModel.X12DocumentId, UploadFile);

                            var TransactionList = _mapper.Map<IEnumerable<X12Transaction>>(struct834.Transaction);

                            var MemberBenefitEnrollments = _mapper.Map<List<X12834BenefitEnrollmentHeader>>(struct834.Transaction);

                            for (int i = 0; i < TransactionList.Count(); i++)
                            {
                                EDIDocModel.X12InterchangeId = ValidateModel.X12InterChangeId;

                                var Transaction = TransactionList.ElementAtOrDefault(i);

                                Transaction.X12FunctionalGroupId = ValidateModel.X12FunctionalGroupId;

                                int TransactionId = _ediFileParsing.ValidateTransaction(EDIDocModel, Transaction);

                                if (TransactionId != 0)
                                {
                                    var MemberBenefitEnrollment = MemberBenefitEnrollments.ElementAtOrDefault(i);

                                    MemberBenefitEnrollment.X12TransactionId = TransactionId;

                                    MemberBenefitEnrollment.X12DocumentId = ValidateModel.X12DocumentId;

                                    MemberBenefitEnrollment.CreatedDate = base.TodaysDate;

                                    MemberBenefitEnrollment.CreatedBy = base.UserName;

                                    MemberBenefitEnrollment.RecordStatus = (int)RecordStatus.Active;

                                    MemberBenefitEnrollment.X12834BenefitEnrollment.ToList().ForEach(e =>
                                    {
                                        e.CreatedDate = base.TodaysDate;
                                        e.CreatedBy = base.UserName;
                                    });

                                    _edi834Services.SaveX12BenefitEnrollment(MemberBenefitEnrollment);
                                }
                            }
                        }
                        else
                        {
                            Response = _ediFileParsing.GetErrorMessage(ValidateModel.Errormsg);
                        }

                    }
                }
                else
                {
                    var x12_document_uid = _ediFileParsing.AddErrorDocumentDetail(UploadFile, Validate.Error);
                    _ediFileParsing.AddFileHistory(x12_document_uid, UploadFile.CreatedBy, (int)FileProcessHistoryFileStatus.FileReceived, (int)FileProcessHistoryStatus.Done);
                    _ediFileParsing.AddFileHistory(x12_document_uid, UploadFile.CreatedBy, (int)FileProcessHistoryFileStatus.ApplyBasicValidation, (int)FileProcessHistoryStatus.Done);
                    _ediFileParsing.AddFileHistory(x12_document_uid, UploadFile.CreatedBy, (int)FileProcessHistoryFileStatus.ApplyHippaValidation, (int)FileProcessHistoryStatus.Failed);
                }
                _ediFileParsing.GenerateAckFile(Validate.EDI999Content, UploadFile.FileName + ".999");

            }
            catch (Exception ex)
            {
                return BadRequest(ConstError.SystemError);
            }
            return Ok(Response);
        }

        [HttpGet]
        [Route("GetMemberEnrollment/{ElementId}")]
        public IActionResult GetMemberEnrollment(int ElementId)
        {
            try
            {
                return Ok(_edi834Services.GetMemberEnrollment(ElementId));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while Deletting Member Enrollment Inbound: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("DeleteMemeberInbound")]
        public IActionResult DeleteMemeberInbound([FromBody]List<int> FileIds)
        {
            try
            {
                _edi834Services.DeleteMemeberInbound(FileIds);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while Deletting Member Enrollment Inbound: {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
