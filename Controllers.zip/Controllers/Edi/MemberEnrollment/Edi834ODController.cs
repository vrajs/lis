using Kwicle.Business.Interfaces.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.MemberEnrollment
{
    [Route("odata")]
    public class Edi834ODController : BaseODController
    {
        private readonly IEdi834Services _edi834Services;
        public Edi834ODController(IEdi834Services edi834Services)
        {
            _edi834Services = edi834Services;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI834Files")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult EDI834Files()
        {
            var Files = _edi834Services.EDI834Files();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI834MemberSummary")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult EDI834Member()
        {
            var Files = _edi834Services.Edi834MemberDetail();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI834MemberInboundSummary")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEDI834MemberImport()
        {
            var MemberSummary = _edi834Services.Edi834InboundMemberDetail();
            return Ok(MemberSummary);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI834MemberListMemberSummary")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult EDI834MemberListMemberSummary()
        {
            var Files = _edi834Services.EDI834MemberListMemberSummary();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetMemberEnrollmentProvider")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetMemberEnrollmentProvider()
        {
            var Provider = _edi834Services.GetMemberEnrollmentProvider();
            return Ok(Provider);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetMemberEnrollmentCOB")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetMemberEnrollmentCOB()
        {
            var Provider = _edi834Services.GetMemberEnrollmentCOB();
            return Ok(Provider);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetMemberEnrollmentCoverage")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetMemberEnrollmentCoverage()
        {
            var Provider = _edi834Services.GetMemberEnrollmentCoverage();
            return Ok(Provider);
        }
        
    }
}
