using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.MemberEnrollment
{
    [Route("api/Edi834")]
    public class Edi834APIController : BaseAPIController
    {
        private readonly IEdi834Services _edi834Services;
        public Edi834APIController(IEdi834Services edi834Services)
        {
            _edi834Services = edi834Services;
        }

        [HttpGet]
        public IActionResult ImportMemberEnrollmentDetail()
        {

            return Ok();
        }

        [HttpGet]
        [Route("Generate834MemberEnrollment/{x12DocumentId}")]
        public IActionResult GenerateFile(int x12DocumentId)
        {
            _edi834Services.GenerateMemberEnrollment(x12DocumentId);
            return Ok();
        }

        [HttpGet]
        [Route("Import834MemberEnrollment/{DataFileConfigurationID}")]
        public IActionResult Import834MemberEnrollment(short DataFileConfigurationID)
        {
            var x12DocumentId = _edi834Services.ImportMemberEnrollmentDetail(DataFileConfigurationID, base.UserName);
            if (x12DocumentId != 0)
            {
                _edi834Services.GenerateMemberEnrollment(x12DocumentId);
                return Ok();
            }
            else
            {
                return BadRequest("No Member found to selected Trading Partner");
            }

        }

        [HttpPost]
        [Route("MemberEnrollmentDelete")]
        public IActionResult Delete([FromBody]List<int> Files)
        {
            _edi834Services.Delete(Files);
            return Ok();
        }

        [HttpGet]
        [Route("GetMemberEnrollmentErrors/{MemberEnrollmentID}")]
        public IActionResult GetMemberEnrollmentErrors(int MemberEnrollmentID)
        {
            var objerrorlist = _edi834Services.GetMemberEnrollmentErrors(MemberEnrollmentID);
            return Ok(objerrorlist);
        }
    }
}
