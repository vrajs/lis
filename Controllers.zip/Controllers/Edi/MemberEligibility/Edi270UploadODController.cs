using Kwicle.Business.Interfaces.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Edi.MemberEligibility
{
    [Route("odata")]
    public class Edi270UploadODController : BaseODController
    {
        private IEdi270Services _edi270Services;
        public Edi270UploadODController(IEdi270Services edi270Services)
        {
            _edi270Services = edi270Services;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI270UploadFiles")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEDI270UploadFiles()
        {
            var Files = _edi270Services.GetEDI270UploadFiles();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI270Summary")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEdi837PClaims()
        {
            var ClaimSummary = _edi270Services.GetEDI270Summary();
            return Ok(ClaimSummary);
        }
    }
}
