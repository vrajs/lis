using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimProfessional
{
    [Route("api/Edi270Upload")]
    public class Edi270UploadAPIController : BaseAPIController
    {
        private readonly IEdi270Services _edi270Services;
        private readonly IEdiTradingPartnerServices _ediTradingPartnerServices;
        private readonly IEdiClaimService _ediClaimService;
        private readonly IEdiFileProcessServices _ediFileProcessServices;
        //private readonly IEdi270ErrorServices _edi270ErrorServices;
        private readonly IEdi271Services _edi271Services;
        private IMapper _mapper;

        public Edi270UploadAPIController(IEdi270Services edi270Services,
            IEdiTradingPartnerServices ediTradingPartnerServices,
            IMapper mapper, IEdiClaimService ediClaimService,
            IEdiFileProcessServices ediFileProcessServices,
            IEdi271Services edi271Services
            //IEdi270ErrorServices edi270ErrorServices
            )
        {
            _edi270Services = edi270Services;
            _ediTradingPartnerServices = ediTradingPartnerServices;
            _mapper = mapper;
            _ediClaimService = ediClaimService;
            _ediFileProcessServices = ediFileProcessServices;
            _edi271Services = edi271Services;
            //_edi837PErrorServices = edi837PErrorServices;
        }

        [HttpPost]
        [Route("ParseEDI270Files/{DataFileConfigurationID}")]
        public async Task<IActionResult> Parse270(IFormFile file, short DataFileConfigurationID)
        {
            string response;
            string FileContent = string.Empty;
            try
            {                
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    FileContent = await reader.ReadToEndAsync();
                }
                EDIUploadFile objEDI837IFile = new EDIUploadFile
                {
                    FileContent = FileContent,
                    FileName = file.FileName,
                    CreatedBy = base.UserName,
                    Filetype = "270"
                };
                var TP = _ediTradingPartnerServices.GetTradingPartnerDetails(DataFileConfigurationID);
                response = _edi270Services.Parse270(TP, objEDI837IFile);
                int x12DocumentId = 0;
                x12DocumentId = _edi270Services.Getx12documentid();

                if (x12DocumentId != 0)
                {
                    _edi271Services.ImportEDI271Data(x12DocumentId);
                    _edi271Services.GenerateResponse(x12DocumentId);
                }

            }
            catch
            {
                return BadRequest(ConstError.SystemError);
            }
            return Ok(response);
        }

        [HttpPost]
        [Route("EligibilityCheck")]
        public IActionResult EligibilityCheck([FromBody]string content)
        {
            string response;
            try
            {
                short DataFileConfigurationID = 52;
                string contentAsString = content;
                EDIUploadFile objEDI837IFile = new EDIUploadFile();
                objEDI837IFile.FileContent = contentAsString;
                objEDI837IFile.FileName = "";
                objEDI837IFile.CreatedBy = base.UserName;
                objEDI837IFile.Filetype = "270";
                var TP = _ediTradingPartnerServices.GetTradingPartnerDetails(DataFileConfigurationID);
                response = _edi270Services.Parse270(TP, objEDI837IFile);
                int x12DocumentId = 0;
                x12DocumentId = _edi270Services.Getx12documentid();

                if (x12DocumentId != 0)
                {
                    _edi271Services.ImportEDI271Data(x12DocumentId);
                    response = _edi271Services.GenerateResponse(x12DocumentId);
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ConstError.SystemError);
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("GetFileData/{x12DocumentID}")]
        public IActionResult GetFileData(int x12DocumentID)
        {
            List<string> response;
            try
            {
                response = null;
                // response = _edi270Services.GetFileData(x12DocumentID);
            }
            catch
            {
                return BadRequest("Could not find data");
            }
            return Ok(response);
        }


        [HttpGet]
        [Route("GetFileProcessHistory/{x12DocumentID}")]
        public IActionResult GetFileProcessHistory(int x12DocumentID)
        {
            var FileHistory = "";
            //var FileHistory = _edi837Services.GetFileHistory(x12DocumentID);
            return Ok(FileHistory);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFileClaim(int id)
        {
            return Ok();
            //return Ok(_edi837Services.DeleteClaimByFileID(id, base.UserName, base.TodaysDate));
        }


        [HttpGet]
        [Route("GetProfessionalClaimError/{ClaimProfessionalId}")]
        public IActionResult GetProfessionalClaimError(int ClaimProfessionalId)
        {
            //  var ClaimError = _edi837PErrorServices.GetProfessionalClaimError(ClaimProfessionalId);
            return Ok("");
        }

        [HttpGet]
        [Route("GetProfessionalClaimErrorHistory/{ClaimProfessionalId}")]
        public IActionResult GetProfessionalClaimErrorHistory(int ClaimProfessionalId)
        {
            // var ClaimError = _edi837PErrorServices.GetProfessionalClaimErrorHistory(ClaimProfessionalId);
            return Ok("");
        }

        [HttpGet]
        [Route("SubmitEDIClaimToHPS")]
        public IActionResult SubmitEDIClaimToHPS()
        {
            _ediClaimService.SubmitEDIClaimToHPS();
            _ediFileProcessServices.UploadFile();
            return Ok();
        }

    }


}
