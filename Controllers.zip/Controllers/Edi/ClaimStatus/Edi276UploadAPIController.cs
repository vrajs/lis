using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Microsoft.AspNetCore.Http;
using System.IO;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Common.Utility;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimStatus
{
    [Route("api/Edi276Upload")]
    public class Edi276UploadAPIController : BaseAPIController
    {
        private readonly ILogger<Edi276UploadAPIController> _logger;
        private readonly IEdi276Services _edi276Services;
        private readonly IEdi277Services _edi277Services;
        private readonly IEdiTradingPartnerServices _ediTradingPartnerServices;
        public Edi276UploadAPIController(ILogger<Edi276UploadAPIController> logger, IEdi276Services edi276Services, IEdiTradingPartnerServices ediTradingPartnerServices, IEdi277Services edi277Services)
        {
            _logger = logger;
            _edi276Services = edi276Services;
            _ediTradingPartnerServices = ediTradingPartnerServices;
            _edi277Services = edi277Services;
        }

        [HttpPost]
        [Route("GetEDI276Files/{DataFileConfigurationID}")]
        public async Task<IActionResult> Parsh837P(IFormFile file, short DataFileConfigurationID)
        {
            string response = string.Empty;
            string FileContent = string.Empty;
            try
            {
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    FileContent = await reader.ReadToEndAsync();
                }
                EDIUploadFile objEDI276File = new EDIUploadFile
                {
                    FileContent = FileContent,
                    FileName = file.FileName,
                    CreatedBy = base.UserName,
                    Filetype = "276"
                };
                var TP = _ediTradingPartnerServices.GetTradingPartnerDetails(DataFileConfigurationID);
                int x12DocumentID = 0;
                response = _edi276Services.Parse276(TP, objEDI276File);
                x12DocumentID = _edi276Services.Getx12documentid();
                if (x12DocumentID != 0)
                {
                    // Import data 
                    _edi277Services.ImportEDI277Data(x12DocumentID);
                    // Generate the File
                    _edi277Services.GenerateClaimStatusResponse(x12DocumentID);
                }

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Generating EDI 276 File: {0}", ex);
                return BadRequest(ConstError.SystemError);
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("Generate277ClaimStatusResponse/{x12DocumentId}")]
        public IActionResult Generate277ClaimStatusResponse(int x12DocumentId)
        {
            try
            {
                var stredi277 = _edi277Services.GenerateClaimStatusResponse(x12DocumentId);
                return Ok(stredi277);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Generating EDI 276 File: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("Sent276Request")]
        public IActionResult Sent276Request([FromBody]string FileContent)
        {
            return Ok("File Generted");
        }
    }
}
