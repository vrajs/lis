using Kwicle.Business.Interfaces.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimStatus
{
    [Route("odata")]
    public class Edi276UploadODController : BaseODController
    {
        private IEdi276Services _edi276Services;
        public Edi276UploadODController(IEdi276Services edi276Services)
        {
            _edi276Services = edi276Services;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        //[Route("api/EDI276UploadFiles")]
        [Route("EDI276UploadFiles")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEDI276UploadFiles()
        {
            var Files = _edi276Services.GetEDI276UploadFiles();
            return Ok(Files);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]        
        [Route("EDI276ClaimSummary")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEdi837PClaims()
        {
            var ClaimSummary = _edi276Services.GetEDI276ClaimSummary();
            return Ok(ClaimSummary);
        }
    }
}
