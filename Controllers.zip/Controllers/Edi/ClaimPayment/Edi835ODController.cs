using Kwicle.Business.Interfaces.EDI;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Edi.ClaimPayment
{
    [Route("odata")]
    public class Edi835ODController: BaseODController
    {
        public readonly IEdi835RemittanceServices _edi835RemittanceServices;

        public Edi835ODController(IEdi835RemittanceServices edi835RemittanceServices)
        {
            _edi835RemittanceServices = edi835RemittanceServices;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI835Check")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult EDI835Check()
        {
            var Files = _edi835RemittanceServices.GetEdi835Check();
            return Ok(Files);
        }
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EDI835CheckClaimSummary")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult EDI835CheckClaimSummary()
        {
            var Files = _edi835RemittanceServices.GetEdi835CheckClaimSummary();
            return Ok(Files);
        }
    }
}
