using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.EDI;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI.RemittanceAdvice;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Edi.ClaimPayment
{
    [Route("api/Edi835")]
    public class Edi835APIController : BaseAPIController
    {
        private ILogger<Edi835APIController> _logger;
        private readonly IEdi835RemittanceServices _edi835RemittanceServices;
        private readonly IEdi835RemittanceRepositories _edi835RemittanceRepositories;
        private readonly IEdi835RemittanceCheckRepositories _edi835RemittanceCheckRepositories;
        public Edi835APIController(ILogger<Edi835APIController> logger, IEdi835RemittanceServices edi835RemittanceServices, IEdi835RemittanceRepositories edi835RemittanceRepositories, IEdi835RemittanceCheckRepositories edi835RemittanceCheckRepositories)
        {
            _logger = logger;
            _edi835RemittanceServices = edi835RemittanceServices;
            _edi835RemittanceRepositories = edi835RemittanceRepositories;
            _edi835RemittanceCheckRepositories = edi835RemittanceCheckRepositories;
        }

        [HttpGet]
        [Route("Generate835Remittance/{DataFileConfigurationID}")]
        public IActionResult GenerateFile(int DataFileConfigurationID)
        {
            try
            {
                ImportRemittanceAdviceModel objModel = new ImportRemittanceAdviceModel
                {
                    DataFileConfigurationID = DataFileConfigurationID,
                    CreatedBy = base.UserName,
                    CreatedDate = base.TodaysDate
                };
                var x12documentid = _edi835RemittanceServices.GetRemittanceAdvice(objModel);
                _edi835RemittanceServices.GenerateElectronicRemittance(x12documentid);
                return Ok();
            }
            catch(Exception ex)
            {
                _logger.LogError("Error while Getting EDI 835 Files : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _edi835RemittanceServices.DeleteDocument(id);
                List<RemittanceAdviceCheck> entity = _edi835RemittanceCheckRepositories.GetByPredicate(x => x.X12DocumentId == id).ToList();
                entity.ForEach(item =>
                {
                    item.RecordStatus = (int)RecordStatus.Deleted;
                    _edi835RemittanceCheckRepositories.Update(item);
                });

                if (!_edi835RemittanceCheckRepositories.DbState.IsValid)
                {
                    _edi835RemittanceCheckRepositories.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Deletting EDI 835 Files : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
