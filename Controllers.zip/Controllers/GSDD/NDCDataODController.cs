using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.GSDD;
using Kwicle.Service.Filters;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Common;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.GSDD
{
    [Route("odata")]
    public class NDCDataODController : BaseODController
    {
        #region Variables  
        private INDCDataRepository _INDCDataRepository;
        private INDCCodeRepository _INDCCodeRepository;

        #endregion

        #region Constructor

        public NDCDataODController(INDCDataRepository INDCDataRepository, INDCCodeRepository INDCCodeRepository)
        {
            _INDCDataRepository = INDCDataRepository;
            _INDCCodeRepository = INDCCodeRepository;
        }

        #endregion

        //[HttpGet]
        //[ConvertUrlToOdataV4]
        //[Route("NDCData")]
        //[EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        //public IActionResult GetClaimNDCData()
        //{
        //    var claimNDCData = _INDCDataRepository.GetClaimNDCData;
        //    return Ok(claimNDCData);
        //}

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("NDCData")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimNDCData()
        {
            var claimNDCData = _INDCCodeRepository.GetNDCCodes((int)ClinicalCodeType.NDC9);
            return Ok(claimNDCData);
        }
    }
}
