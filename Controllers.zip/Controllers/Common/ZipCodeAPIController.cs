using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Common
{
    [Route("api/ZipCode")]
    public class ZipCodeAPIController : BaseAPIController
    {
        private readonly IZipCodeRepository _ZipCodeRepository;
        private IMapper _mapper;
        private ILogger<ZipCodeAPIController> _logger;
        private readonly IZipCodeService _zipCodeService;
        public ZipCodeAPIController(IZipCodeRepository ZipCodeRepository, IMapper mapper, ILogger<ZipCodeAPIController> logger, IZipCodeService zipCodeService)
        {
            _ZipCodeRepository = ZipCodeRepository;
            _mapper = mapper;
            _logger = logger;
            _zipCodeService = zipCodeService;
        }

        [HttpGet]
        [Route("GetCounties")]
        public ActionResult GetCounties()
        {
            var counties = this._ZipCodeRepository.GetCounties().ToList();
            if (!this._ZipCodeRepository.DbState.IsValid)
            {
                this._ZipCodeRepository.DbState.ErrorMessages.ForEach((errorMessage) =>
                {
                    ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(counties);
        }

        // GET: api/ZipCode/GetStates
        [HttpGet]
        [Route("GetStates")]
        public ActionResult GetStates()
        {
            var states = this._ZipCodeRepository.GetStates().ToList();
            if (!this._ZipCodeRepository.DbState.IsValid)
            {
                this._ZipCodeRepository.DbState.ErrorMessages.ForEach((errorMessage) =>
                {
                    ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(states);
        }

        // GET: api/ZipCode/GetStates
        [HttpGet]
        [Route("GetCountries")]
        public ActionResult GetCountries()
        {
            var countries = this._ZipCodeRepository.GetCountries().ToList();
            if (!this._ZipCodeRepository.DbState.IsValid)
            {
                this._ZipCodeRepository.DbState.ErrorMessages.ForEach((errorMessage) =>
                {
                    ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(countries);
        }
        
        [HttpGet("{id}", Name = "ZipCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewZipCodesPolicy)]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _ZipCodeRepository.GetById(Id);
                if (result == null) return NotFound($"ZipCode {Id} was not found");
                return Ok(_mapper.Map<ZipCodeModel>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddZipCodesPolicy)]
        public IActionResult Post([FromBody]ZipCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var zipCodeEntity = _mapper.Map<ZipCode>(model);
                zipCodeEntity.StateFullName = _ZipCodeRepository.GetStates().Where(x => x.Key == zipCodeEntity.State).FirstOrDefault().Value;
                zipCodeEntity.CreatedDate = base.TodaysDate;
                zipCodeEntity.CreatedBy = base.UserName;
                zipCodeEntity.RecordStatus = (int)RecordStatus.Active;
                zipCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _zipCodeService.CheckIfExists(zipCodeEntity);

                if (!_zipCodeService.BusinessState.IsValid)
                {
                    _zipCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _ZipCodeRepository.Add(zipCodeEntity);
                var newUri = Url.Link("ZipCodeGet", new { id = zipCodeEntity.ZipCodeID });
                _logger.LogInformation("New Zip Code Created ");
                return Created(newUri, _mapper.Map<ZipCodeModel>(zipCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Zip Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateZipCodesPolicy)]
        public IActionResult Put([FromBody] ZipCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                ZipCode entity = _ZipCodeRepository.GetById(model.ZipCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                //entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, (DateTime)entity.DMERuralStartDate, (DateTime)entity.DMERuralEndDate);
                //entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, (DateTime)entity.DMERuralStartDate, (DateTime)entity.DMERuralEndDate).ToString();

                _zipCodeService.CheckIfExists(entity);
                if (!_zipCodeService.BusinessState.IsValid)
                {
                    _zipCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _ZipCodeRepository.Update(entity);
                if (!_ZipCodeRepository.DbState.IsValid)
                {
                    _ZipCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Zip Code updated : {0}", entity.ZipCodeID);
                return Ok(entity.ZipCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Zip Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        public IActionResult Delete(int Id)
        {
            try
            {
                _ZipCodeRepository.DeleteById(Id, base.UserName, base.TodaysDate);
                if (!_ZipCodeRepository.DbState.IsValid)
                {
                    _ZipCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing Zip Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]      
        [Route("GetZipCodeBySearchValue/{serachValue}")]        
        public async Task<IActionResult> GetZipCodeBySearchValue([FromQuery]string searchValue)
        {
            try
            {
                var result = await _ZipCodeRepository.GetZipCodesFromView(searchValue);
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
    }
}

