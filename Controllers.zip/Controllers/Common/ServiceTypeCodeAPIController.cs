using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel;
using Kwicle.Data.Contracts.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Common
{
   
    [Route("api/ServiceTypeCode")]
    public class ServiceTypeCodeAPIController : BaseAPIController
    {
        private readonly IServiceTypeCodeRepository _ServiceTypeCodeRepository;
        public ServiceTypeCodeAPIController(IServiceTypeCodeRepository serviceTypeCodeRepository)
        {
            _ServiceTypeCodeRepository = serviceTypeCodeRepository;
        }

        [HttpGet]
        [Route("GetKeyValue")]
        public IActionResult Get()
        {
            List<KeyVal<short,string>> serviceCodeTypes = _ServiceTypeCodeRepository.GetKeyVal();
            if (!_ServiceTypeCodeRepository.DbState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return Ok(serviceCodeTypes);
        }
    }
}
