using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net;
using Kwicle.Business.Interfaces.Common;
using System.Collections.Generic;
using Kwicle.Core.CustomModel;
using Microsoft.AspNetCore.Authorization;
using Kwicle.Data;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Common
{
    [Route("api/CommonCode")]
    public class CommonCodeAPIController : BaseAPIController
    {
        #region Variables

        private readonly ICommonCodeRepository _CommonCodeRepository;
        private IMapper _mapper;
        private ILogger<CommonCodeAPIController> _logger;
        private readonly ICommonCodeService _CommonCodeService;
        private readonly KwicleContext _Context;

        #endregion

        #region Ctor        

        public CommonCodeAPIController(ICommonCodeRepository CommonCodeRepository, IMapper mapper, ILogger<CommonCodeAPIController> logger, ICommonCodeService CommonCodeService, KwicleContext Context)
        {
            _CommonCodeRepository = CommonCodeRepository;
            _mapper = mapper;
            _logger = logger;
            _CommonCodeService = CommonCodeService;
            _Context = Context;
        }

        #endregion

        // GET: api/values
        [HttpGet("{CodeTypeId}/{FetchingTypeId}")]
        public IActionResult GetByCodeTypeId(Int16 CodeTypeId, Int16 FetchingTypeId = 0)
        {
            var commonCodes = _CommonCodeRepository.GetCommonCodesByCodeTypeId(CodeTypeId, FetchingTypeId);
            return Json(commonCodes);
        }


        [HttpGet("GetCommonCodeByCodeTypeId/{CodeTypeId}")]
        public async Task<IActionResult> GetCommonCodeByCodeTypeId(Int16 CodeTypeId)
        {
            try
            {
                var result = await _CommonCodeRepository.GetCommonCodeByCodeTypeId(CodeTypeId);
                return Ok(_mapper.Map<List<CommonCode>>(result));                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }                       
        }

        [HttpGet]
        [Route("GetCodeByTypeIds")]
        public IActionResult GetByCodeTypeIds(string jsonObject)
        {
            MultipleValueRequestModel request = JsonConvert.DeserializeObject<MultipleValueRequestModel>(jsonObject);
            var commonCodes = _CommonCodeRepository.GetCommonCodesByCodeTypeIds(request);
            return Json(commonCodes);
        }

        [HttpGet("GetKeyAsCodeByCodeTypeId/{CodeTypeId}/{FetchingTypeId}")]
        public IActionResult GetCommonCodesKeyAsCodeByCodeTypeId(Int16 CodeTypeId, Int16 FetchingTypeId = 0)
        {
            var commonCodes = _CommonCodeRepository.GetCommonCodesKeyAsCodeByCodeTypeId(CodeTypeId, FetchingTypeId);
            return Json(commonCodes);
        }

        [HttpGet("GetCommonCodeConfigurationByCodeTypeId/{PageId}/{CodeTypeId}")]
        public IActionResult GetCommonCodeConfigurationByCodeTypeId(string PageId, int CodeTypeId)
        {
            var commonCodesConfiguration = _CommonCodeRepository.GetCommonCodeConfigurationByCodeTypeId(PageId, CodeTypeId);
            return Json(commonCodesConfiguration);
        }


        [HttpGet("GetMaxDisplayOrderByCodeTypeId/{CodeTypeId}")]
        public IActionResult GetMaxDisplayOrderByCodeTypeId(int CodeTypeId)
        {
            var result = _CommonCodeRepository.GetByPredicate(x => x.CodeTypeID == CodeTypeId).OrderBy(x => x.DisplayOrder).ToList();
            int maxDisplayOrder = 0;
            if (result.Count > 0)
            {
                maxDisplayOrder = result.Max(x => x.DisplayOrder);
            }
            return Json(maxDisplayOrder);
        }



        [HttpGet("{id}", Name = "CommonCodeGet")]
        //[Authorize(Policy = Authorization.Policies.ViewCommonCodePolicy)]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _CommonCodeRepository.GetById(Id);
                if (result == null) return NotFound($"CommonCode {Id} was not found");
                return Ok(_mapper.Map<CommonCode>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        //[Authorize(Policy = Authorization.Policies.AddCommonCodePolicy)]
        public IActionResult Post([FromBody]CommonCode CommonCodeEntity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                bool isSuccess = true;
                string response = "";
                var executionStrategy = _Context.Database.CreateExecutionStrategy();
                executionStrategy.Execute(() =>
                {
                    using (var dbContextTransaction = _Context.Database.BeginTransaction())
                    {
                        try
                        {
                            //var CommonCodeEntity = _mapper.Map<CommonCode>(model);
                            //int lastCommonCodeID = _CommonCodeRepository.GetByPredicate(x => x.ControlTypeID == CommonCodeEntity.ControlTypeID).Max(y => y.CommonCodeID);
                            int lastCommonCodeID = _CommonCodeRepository.GetByPredicateIgnoreQueryFilters(null).Max(y => y.CommonCodeID);
                            CommonCodeEntity.CommonCodeID = lastCommonCodeID > 0 ? (lastCommonCodeID + 1) : 1;
                            CommonCodeEntity.CreatedDate = base.TodaysDate;
                            CommonCodeEntity.CreatedBy = base.UserName;
                            CommonCodeEntity.TermDate = CommonCodeEntity.TermDate.Date == DateTime.MinValue.Date ? DateTime.MaxValue.Date : CommonCodeEntity.TermDate.Date;
                            CommonCodeEntity.RecordStatus = CommonCodeEntity.RecordStatus > 0 ? CommonCodeEntity.RecordStatus : (byte)Utility.GetRecordStatus(base.TodaysDate, (DateTime)CommonCodeEntity.EffectiveDate, (DateTime)CommonCodeEntity.TermDate);
                            CommonCodeEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, (DateTime)CommonCodeEntity.EffectiveDate, (DateTime)CommonCodeEntity.TermDate).ToString();
                            CommonCodeEntity.RowVersion = BitConverter.GetBytes(DateTime.UtcNow.Ticks);                        

                            _CommonCodeService.CheckIfExistsForInsert(CommonCodeEntity);

                            if (!_CommonCodeService.BusinessState.IsValid)
                            {
                                _CommonCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                                });

                                isSuccess = false;
                                response = this.ModelState.ToString();
                                //return BadRequest(ModelState);
                            }

                            _CommonCodeRepository.Add(CommonCodeEntity);
                            dbContextTransaction.Commit();

                            var newUri = Url.Link("CommonCodeGet", new { id = CommonCodeEntity.CommonCodeID });
                            _logger.LogInformation("New Common Code Created ");

                            isSuccess = true;
                            response = newUri;

                            //return Created(newUri, _mapper.Map<CommonCodeModel>(CommonCodeEntity));
                        }
                        catch (Exception e)
                        {
                            dbContextTransaction.Rollback();
                            isSuccess = false;
                            response = e.Message;
                            //return BadRequest(e.Message);
                        }
                    }
                });
                if(isSuccess)
                {
                    return new OkObjectResult(response);
                }
                else
                {
                    return BadRequest(response);
                }
                
                //return response;
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Common Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        //[Authorize(Policy = Authorization.Policies.UpdateCommonCodePolicy)]
        public IActionResult Put([FromBody] CommonCode model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                CommonCode entity = _CommonCodeRepository.GetById(model.CommonCodeID);
                //_mapper.Map(model, entity);
                entity.CommonCodeID = model.CommonCodeID;
                entity.Code = model.Code;
                entity.ShortName = model.ShortName;
                entity.CodeTypeID = model.CodeTypeID;
                entity.ControlTypeID = model.ControlTypeID;
                entity.DisplayOrder = model.DisplayOrder;
                entity.EffectiveDate = model.EffectiveDate;
                entity.CharValue = model.CharValue;
                entity.NumericValue = model.NumericValue;
                entity.OtherValue = model.OtherValue;
                entity.LongDescription = model.LongDescription;
                entity.RowVersion = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.TermDate = entity.TermDate.Date == DateTime.MinValue.Date ? DateTime.MaxValue.Date : entity.TermDate.Date;
                entity.RecordStatus = model.RecordStatus>0? model.RecordStatus: (byte)Utility.GetRecordStatus(base.TodaysDate, (DateTime)model.EffectiveDate, (DateTime)model.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, (DateTime)model.EffectiveDate, (DateTime)model.TermDate).ToString();

                _CommonCodeService.CheckIfExists(entity);
                if (!_CommonCodeService.BusinessState.IsValid)
                {
                    _CommonCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _CommonCodeRepository.Update(entity);
                if (!_CommonCodeRepository.DbState.IsValid)
                {
                    _CommonCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Common Code updated : {0}", entity.CommonCodeID);
                return Ok(entity.CommonCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Common Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        public IActionResult Delete(int Id)
        {
            try
            {
                _CommonCodeRepository.DeleteById(Id, base.UserName, base.TodaysDate);
                if (!_CommonCodeRepository.DbState.IsValid)
                {
                    _CommonCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing Common Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("ManageDisplayOrder")]
        public IActionResult ManageDisplayOrder([FromBody]List<KeyVal<int, short>> dataList)
        {
            List<CommonCode> listToUpdate = new List<CommonCode>();
            if (dataList.Count > 0)
            {
                try
                {
                    foreach (var model in dataList)
                    {
                        CommonCode entity = _CommonCodeRepository.GetById(model.Key);
                        //_mapper.Map(model, entity);
                        entity.DisplayOrder = model.Value;
                        entity.RowVersion = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
                        entity.UpdatedDate = base.TodaysDate;
                        entity.UpdatedBy = base.UserName;

                        listToUpdate.Add(entity);
                    }


                    //_CommonCodeRepository.Update(entity);
                    _CommonCodeRepository.BulkUpdate(listToUpdate);
                    if (!_CommonCodeRepository.DbState.IsValid)
                    {
                        _CommonCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }
                    //_logger.LogInformation("Common Code updated : {0}", entity.CommonCodeID);

                }
                catch (Exception ex)
                {
                    _logger.LogError("Error while updating Common Code : {0}", ex);
                    return BadRequest(ex.Message);
                }
            }

            return Ok();
        }
    }
}

