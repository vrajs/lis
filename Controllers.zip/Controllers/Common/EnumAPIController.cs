using Kwicle.API.Controllers;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using System.Reflection;

namespace Kwicle.Service.Controllers.Common
{    
    [Route("api/Enum")]
    public class EnumAPIController : BaseAPIController
    {

        #region API Methods
        /// <summary>
        /// Method is use for get Enum by name.
        /// </summary>
        /// <returns>List Of KeyVal<Int16, string></returns>
        [HttpGet]
        [Route("GetByName/{enumName}")]
        public IActionResult GetByName(string enumName)
        {
            List<KeyVal<int, string>> result = GetKeyValueListOfEnum(enumName);

            return Json(result);
        }
        #endregion

        #region Private Methods
        private List<KeyVal<int, string>> GetKeyValueListOfEnum(string enumName)
        {
            List<KeyVal<int, string>> items = new List<KeyVal<int, string>>();
            if (enumName == "NumericFilterType")
            {
                items = Enum.GetValues(typeof(NumericFilterType)).Cast<NumericFilterType>().Select(x => new KeyVal<int, string>() { Key = (int)x, Value = EnumerationExtension.Description(x) }).ToList();
            }
            else if (enumName == "StringFilterType")
            {
                items = Enum.GetValues(typeof(StringFilterType)).Cast<StringFilterType>().Select(x => new KeyVal<int, string>() { Key = (int)x, Value = EnumerationExtension.Description(x) }).ToList();
            }
            else if (enumName == "ParNonParType")
            {
                items = Enum.GetValues(typeof(ParNonParType)).Cast<ParNonParType>().Select(x => new KeyVal<int, string>() { Key = (int)x, Value = EnumerationExtension.Description(x) }).ToList();
            }
            else if (enumName == "RoundToType")
            {
                items = Enum.GetValues(typeof(RoundToType)).Cast<RoundToType>().Select(x => new KeyVal<int, string>() { Key = (int)x, Value = EnumerationExtension.Description(x) }).ToList();
            }
            return items;
        }
        #endregion
    }
}
