using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Service.Filters;
using Kwicle.Data.Contracts.Common;
using Microsoft.AspNetCore.OData.Query;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Common
{
    [Route("odata")]
    public class ZipCodeODataController : BaseODController
    {
        private readonly IZipCodeRepository _ZipCodeRepository;

        public ZipCodeODataController(IZipCodeRepository ZipCodeRepository)
        {
            _ZipCodeRepository = ZipCodeRepository;
        }

        // GET: odata/ZipCodeOData
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ZipCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetZipCodes()
        {
            var Queryable = _ZipCodeRepository.GetZipCodes();
            return Ok(Queryable);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Counties")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult Get()
        {
            var countiesQueryable = _ZipCodeRepository.GetCounties();
            return Ok(countiesQueryable);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Cities")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCities()
        {
            try
            {
                var citiesQueryable = _ZipCodeRepository.GetCities();
                //var data = citiesQueryable.ToList();
                return Ok(citiesQueryable);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("States")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetStates()
        {
            //start migration from 2.1 to 3.1
            //var Queryable = _ZipCodeRepository.GetZipCodes()
            var Queryable = _ZipCodeRepository.GetZipCodes().ToList();
            //end migration from 2.1 to 3.1
            var state = Queryable.GroupBy(g => g.StateFullName).Select(x => x.FirstOrDefault());
            return Ok(state);
        }


    }
}
