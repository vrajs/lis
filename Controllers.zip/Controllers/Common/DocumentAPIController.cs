using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities.CommonStructure;
using Kwicle.Data.Contracts.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Common
{
    [Produces("application/json")]
    [Route("api/Document")]
    public class DocumentAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<DocumentAPIController> _logger;
        private readonly IDocumentRepository _documentRepository;
        private readonly IDocumentService _documentService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public DocumentAPIController(IDocumentRepository documentRepository, ILogger<DocumentAPIController> logger, IMapper mapper, IDocumentService _documentService)
        {
            _logger = logger;
            _documentRepository = documentRepository;
            _mapper = mapper;
            this._documentService = _documentService;

        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetDocument")]
        public IActionResult GetDocument(short id)
        {
            try
            {
                var result = _documentRepository.GetById(id);
                if (result == null) return NotFound($"Document with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]DocumentModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Document entity = _mapper.Map<Document>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)RecordStatus.Active;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _documentService.CheckIfExists(entity);
                if (!_documentService.BusinessState.IsValid)
                {
                    _documentService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _documentRepository.Add(entity);

                if (!_documentRepository.DbState.IsValid)
                {
                    _documentRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("GetDocument", new { id = entity.DocumentID });
                _logger.LogInformation("New document created");
                return Created(newUri, _mapper.Map<DocumentModel>(entity));

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving document : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _documentRepository.DeleteById(id, base.UserName, base.TodaysDate);
                //_documentRepository.Update(entity);
                if (!_documentRepository.DbState.IsValid)
                {
                    _documentRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing document : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("GetContents")]
        public IActionResult GetContents([FromBody]int Id)
        {
            try
            {
                Document objDocument = _documentRepository.GetById(Id);
                if (objDocument == null)                
                    return NotFound($"File not found");
                if (string.IsNullOrEmpty(objDocument.RelativeFilePath))
                    return NotFound($"File not found");

                var fileData = _documentService.GetFileContents(objDocument.RelativeFilePath);
                if (fileData == null)
                    return NotFound($"File not found");
                else
                    return Ok(fileData);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        #endregion methods
    }
}
