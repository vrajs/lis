using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Common;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Common
{
    [Route("api/ProductType")]
    public class ProductTypeAPIController : BaseAPIController
    {
        private readonly IProductTypeRepository _IProductTypeRepository;
        public ProductTypeAPIController(IProductTypeRepository IProductTypeRepository)
        {
            _IProductTypeRepository = IProductTypeRepository;
        }
        // GET: api/ProductType
        [Route("GetKeyValue")]
        [HttpGet]

        public IActionResult Get()
        {
            var productTypes = _IProductTypeRepository.GetAllKeyVal();
            if (!_IProductTypeRepository.DbState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return Json(productTypes);
        }


    }
}
