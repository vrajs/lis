using Kwicle.Data.Contracts.Common;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Common
{
    [Route("odata")]
    public class CommonCodeODController : BaseODController
    {
        private ICommonCodeRepository _commonCodeRepository;

        public CommonCodeODController(ICommonCodeRepository commonCodeRepository)
        {
            _commonCodeRepository = commonCodeRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetCommonCodeList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCommonCodeList(int CodeTypeID)
        {
            try
            {
                var query = _commonCodeRepository.GetCommonCodeList(CodeTypeID);
                return Ok(query);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
    }
}
