using System.Linq;
using Kwicle.Data.Contracts.Common;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Common
{
    [Route("odata")]
    public class ProductTypeODController : BaseODController
    {
        private readonly IProductTypeRepository _productTypeRepository;

        public ProductTypeODController(IProductTypeRepository productTypeRepository)
        {
            _productTypeRepository = productTypeRepository;
        }

        // GET: odata/ProductTypes
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ProductTypes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetProductTypes()
        {
            var Queryable = _productTypeRepository.GetAllKeyVal();
            return Ok(Queryable);
        }
    }
}
