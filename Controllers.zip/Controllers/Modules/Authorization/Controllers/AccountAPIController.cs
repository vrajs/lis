using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities;
using Kwicle.Service.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Collections.Generic;
using Kwicle.Service.ViewModels;
using Kwicle.Data.Contracts;
using System.Linq;
using Kwicle.Core.Common;
using System;
using Kwicle.Service.Helpers;
using System.IO;
using Kwicle.Core.Interfaces;
using System.Web;
using Microsoft.Extensions.Configuration;
using Kwicle.Core.Implementations;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Data.Contracts.Masters;
using System.Globalization;
using Microsoft.AspNetCore.Http;
using System.Text;

namespace Kwicle.Controllers
{
    [Route("api/Account")]
    public class AccountAPIController : BaseAPIController
    {
        private readonly IAccountManager _accountManager;
        private readonly IAuthorizationService _authorizationService;
        private readonly IUserDataAuthorizationService _userDataAuthorizationService;
        private readonly IUserDataAuthorizationRepository _userDataAuthorizationRepository;
        private readonly IMapper _mapper;

        private const string GetUserByIdActionName = "GetUserById";
        private const string GetRoleByIdActionName = "GetRoleById";

        private readonly IEmailService _emailService;
        private readonly IConfiguration _configuration;

        public AccountAPIController(IAccountManager accountManager, IAuthorizationService authorizationService, IEmailService emailService, IConfiguration configuration, IUserDataAuthorizationService userDataAuthorizationService, IUserDataAuthorizationRepository userDataAuthorizationRepository,IMapper mapper)
        {
            _accountManager = accountManager;
            _authorizationService = authorizationService;
            _emailService = emailService;
            _configuration = configuration;
            _userDataAuthorizationService = userDataAuthorizationService;
            _userDataAuthorizationRepository = userDataAuthorizationRepository;
            _mapper = mapper;
        }

        [HttpGet("users/me")]
        [Produces(typeof(UserViewModel))]
        public async Task<IActionResult> GetCurrentUser()
        {
            return await GetUserByUserName(this.User.Identity.Name);
        }


        [HttpGet("users/{id}", Name = GetUserByIdActionName)]
        [Produces(typeof(UserViewModel))]
        public async Task<IActionResult> GetUserById(string id)
        {
            //if (!(await _authorizationService.AuthorizeAsync(this.User, id, AccountManagementOperations.Read)).Succeeded)
            //    return new ChallengeResult();
            UserViewModel userVM = await GetUserViewModelHelper(id);
            UserDataAuthorizationModel udam = _userDataAuthorizationRepository.GetByUserID(userVM.Id);
            if (udam != null)
            {
                userVM.DataPreferenceByID = udam.DataPreferenceByID;
                userVM.DataPreferenceIDs = udam.DataPreferenceIDs;
            }            
            if (userVM != null)
                return Ok(userVM);
            else
                return NotFound(id);
        }


        [HttpGet("users/username/{userName}")]
        [Produces(typeof(UserViewModel))]
        public async Task<IActionResult> GetUserByUserName(string userName)
        {
            KwicleUser appUser = await _accountManager.GetUserByUserNameAsync(userName);

            if (!(await _authorizationService.AuthorizeAsync(this.User, appUser?.Id ?? "", AccountManagementOperations.Read)).Succeeded)
                return new ChallengeResult();

            if (appUser == null)
                return NotFound(userName);

            return await GetUserById(appUser.Id);
        }


        private async Task<UserViewModel> GetUserViewModelHelper(string userId)
        {
            var userAndRoles = await _accountManager.GetUserAndRolesAsync(userId);
            if (userAndRoles == null)
                return null;
            
            var userVM = _mapper.Map<UserViewModel>(userAndRoles.Item1);
            userVM.Roles = userAndRoles.Item2;

            return userVM;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody]UserEditViewModel model)
        {            
                if (ModelState.IsValid)
                {
                    if (model == null)
                        return BadRequest($"{nameof(model)} cannot be null");

                    KwicleUser appUser = _mapper.Map<KwicleUser>(model);
                    //start migration 2.1 to 3.1
                    appUser.Id = Guid.NewGuid().ToString();
                    //end migration 2.1 to 3.1
                    appUser.CreatedDate = base.TodaysDate;
                    appUser.CreatedBy = base.UserName;
                    appUser.RecordStatus = (int)RecordStatus.Active;
                    appUser.RecordStatusChangeComment = RecordStatus.Active.ToString();

                    var result = await _accountManager.CreateUserAsync(appUser, model.Roles, model.NewPassword);
                    if (result.Item1)
                    {
                        UserViewModel userVM = await GetUserViewModelHelper(appUser.Id);

                        //user and role creation success then save UserDataAuthorization
                        if (model.DataPreferenceByID > 0)
                        {
                            UserDataAuthorizationModel udam = new UserDataAuthorizationModel();
                            udam.UserID = userVM.Id;
                            udam.UserName = userVM.UserName;
                            udam.CreatedDate = base.TodaysDate;
                            udam.CreatedBy = base.UserName;
                            udam.OrganizationID = base.OrganizationID;
                            udam.DataPreferenceByID = model.DataPreferenceByID;
                            udam.DataPreferenceIDs = model.DataPreferenceIDs;
                            _userDataAuthorizationService.SaveUserDataAuthorization(udam);
                            if (!_userDataAuthorizationService.BusinessState.IsValid)
                            {
                                _userDataAuthorizationService.BusinessState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        //End
                        return CreatedAtAction(GetUserByIdActionName, new { id = userVM.Id }, userVM);
                    }

                    foreach (var error in result.Item2)
                    {
                        ModelState.AddModelError("Error", error);
                    }
                }

                return BadRequest(ModelState);                    
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromBody] UserEditViewModel user)
        {
            KwicleUser appUser = await _accountManager.GetUserByIdAsync(user.Id);
            string[] currentRoles = appUser != null ? (await _accountManager.GetUserRolesAsync(appUser)).ToArray() : null;

            if (ModelState.IsValid)
            {
                if (user == null)
                    return BadRequest($"{nameof(user)} cannot be null");

                //if (!string.IsNullOrWhiteSpace(user.Id) && id != user.Id)
                //    return BadRequest("Conflicting user id in parameter and model data");

                if (appUser == null)
                    return NotFound(user.Id);


                //if (Utilities.GetUserId(this.User) == user.Id && string.IsNullOrWhiteSpace(user.CurrentPassword))
                //{
                //    if (!string.IsNullOrWhiteSpace(user.NewPassword))
                //        return BadRequest("Current password is required when changing your own password");
                //}


                bool isValid = true;

                //if (Utilities.GetUserId(this.User) == user.Id && (appUser.UserName != user.UserName || !string.IsNullOrWhiteSpace(user.NewPassword)))
                //{
                //    if (!await _accountManager.CheckPasswordAsync(appUser, user.CurrentPassword))
                //    {
                //        isValid = false;
                //        ModelState.AddModelError("Error", "The username / password couple is invalid.");
                //    }
                //}

                if (isValid)
                {
                    _mapper.Map<UserViewModel, KwicleUser>(user, appUser);
                    appUser.UpdatedDate = base.TodaysDate;
                    appUser.UpdatedBy = base.UserName;
                    appUser.RecordStatusChangeComment = "Updated";
                    var result = await _accountManager.UpdateUserAsync(appUser, user.Roles);
                    if (result.Item1)
                    {
                        //if (!string.IsNullOrWhiteSpace(user.NewPassword))
                        //{
                        //    if (!string.IsNullOrWhiteSpace(user.CurrentPassword))
                        //        result = await _accountManager.UpdatePasswordAsync(appUser, user.CurrentPassword, user.NewPassword);
                        //}
                        //user and role creation success then save UserDataAuthorization
                        if (user.DataPreferenceByID > 0)
                        {
                            UserDataAuthorizationModel udam = new UserDataAuthorizationModel();
                            udam.UserID = appUser.Id;
                            udam.UserName = appUser.UserName;
                            udam.CreatedDate = base.TodaysDate;
                            udam.CreatedBy = base.UserName;
                            udam.OrganizationID = base.OrganizationID;
                            udam.DataPreferenceByID = user.DataPreferenceByID;
                            udam.DataPreferenceIDs = user.DataPreferenceIDs;
                            _userDataAuthorizationService.SaveUserDataAuthorization(udam);
                            if (!_userDataAuthorizationService.BusinessState.IsValid)
                            {
                                _userDataAuthorizationService.BusinessState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        else
                        {
                            _userDataAuthorizationRepository.DeleteByUserID(appUser.Id);
                            if (!_userDataAuthorizationRepository.DbState.IsValid)
                            {
                                _userDataAuthorizationRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        //End
                        if (result.Item1)
                            return Ok(appUser.Id.ToString());
                    }

                    foreach (var error in result.Item2)
                    {
                        ModelState.AddModelError("Error", error);
                    }
                }
            }

            return BadRequest(ModelState);
        }

        [HttpPost("UpdateUserProfile")]
        public async Task<IActionResult> UpdateUserProfile([FromBody] UserEditViewModel user)
        {
            KwicleUser appUser = await _accountManager.GetUserByIdAsync(user.Id);
            string[] currentRoles = appUser != null ? (await _accountManager.GetUserRolesAsync(appUser)).ToArray() : null;

            if (ModelState.IsValid)
            {
                if (user == null)
                    return BadRequest($"{nameof(user)} cannot be null");

                if (appUser == null)
                    return NotFound(user.Id);

                _mapper.Map<UserViewModel, KwicleUser>(user, appUser);
                //if (!string.IsNullOrEmpty(user.Image))
                //{
                //    appUser.Image = Encoding.ASCII.GetBytes(user.Image);
                //}                
                appUser.UpdatedDate = base.TodaysDate;
                appUser.UpdatedBy = base.UserName;
                appUser.RecordStatusChangeComment = "Updated";
                var result = await _accountManager.UpdateUserAsync(appUser, user.Roles);
                if (result.Item1)
                {
                    if (result.Item1)
                        return Ok(appUser.Id.ToString());
                }

                foreach (var error in result.Item2)
                {
                    ModelState.AddModelError("Error", error);
                }
            }
            return BadRequest(ModelState);
        }

        [HttpPut("ResetPassword")]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword([FromBody] CreateChangePasswordViewModel model)
        {
            KwicleUser appUser = await _accountManager.GetUserByUserNameAsync(model.UserName);

            if (model == null)
                return BadRequest($"{nameof(model)} cannot be null");

            //if (!string.IsNullOrWhiteSpace(user.Id) && id != user.Id)
            //    return BadRequest("Conflicting user id in parameter and model data");
            if (appUser.IsActiveDirectoryUser == true)
                return BadRequest("This functionality only available for form based user.");

            if (appUser == null)
                return NotFound(model.UserName);

            if (!string.IsNullOrWhiteSpace(model.NewPassword))
            {
                var resetToken = model.ResetToken.Replace('$', '%');
                var result = await _accountManager.ResetPasswordAsync(appUser, System.Net.WebUtility.UrlDecode(resetToken), model.NewPassword);
                if (result.Item1)
                    return Ok(appUser.Id.ToString());


                foreach (var error in result.Item2)
                {
                    ModelState.AddModelError("Error", error);
                }
            }
            return BadRequest(ModelState);
        }

        [HttpPut("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] CreateChangePasswordViewModel model)
        {
            KwicleUser appUser = await _accountManager.GetUserByIdAsync(model.Id);
            if (model == null)
                return BadRequest($"{nameof(model)} cannot be null");

            if (appUser == null)
                return NotFound(model.UserName);

            if (appUser.IsActiveDirectoryUser == true)
                return BadRequest("This functionality only available for form based user.");

            if (!string.IsNullOrWhiteSpace(model.CurrentPassword) && !string.IsNullOrWhiteSpace(model.NewPassword))
            {
                var result = await _accountManager.UpdatePasswordAsync(appUser, model.CurrentPassword, model.NewPassword);
                if (result.Item1)
                    return Ok(appUser.Id.ToString());


                foreach (var error in result.Item2)
                {
                    ModelState.AddModelError("Error", error);
                }
            }
            return BadRequest(ModelState);
        }

        [HttpPost("CreatePasswordEmail")]
        public async Task<ActionResult> CreatePasswordEmail([FromBody] UserEditViewModel user)
        {
            try
            {
                KwicleUser appUser = await _accountManager.GetUserByIdAsync(user.Id);

                if (user == null)
                    return BadRequest($"{nameof(user)} cannot be null");

                if (appUser == null)
                    return NotFound(user.Id);

                string changePasswordHtml = string.Empty;
                using (var templateService = new TemplateService("Email\\CreatePassword.html", TemplateFileFormat.HTML, base.ZoneId))
                {
                    //read file
                    changePasswordHtml = await templateService.ReadFile();
                }
                string resetToken = await _accountManager.GeneratePasswordResetTokenAsync(appUser);

                string callbackUrl = $"{_configuration["Keys:AuthorityUrl"]}create-password?resettoken={System.Net.WebUtility.UrlEncode(resetToken).Replace('%', '$')}&username={HttpUtility.UrlEncode(user.UserName)}&type={HttpUtility.UrlEncode(user.PasswordType)}";

                string emailMessage = changePasswordHtml
                    .Replace("{fullName}", appUser.FullName)
                    .Replace("{applicationName}", _configuration["Keys:ApplicationName"])
                    .Replace("{userName}", appUser.UserName)
                    .Replace("{email}", appUser.Email)
                    .Replace("{createdDate}", appUser.CreatedDate.ToString("MM/dd/yyyy hh:mm:ss tt"))
                    .Replace("{linkValidDate}", appUser.CreatedDate.AddHours(Convert.ToDouble(_configuration["Keys:PasswordResetTokenLifetimeHours"])).ToString("MM/dd/yyyy hh:mm:ss tt"))
                    .Replace("{url}", callbackUrl);

                string[] receipt = { appUser.Email };
                await _emailService.SendEmailAsync(receipt, "Create Password", emailMessage);

                return Ok("Registration Successful. E-mail has been sent to registered user.");
            }
            catch (FileNotFoundException fileNotFoundException)
            {
                return BadRequest(fileNotFoundException.ToString());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost("ForgotOrResetPasswordEmail")]
        [AllowAnonymous]
        public async Task<ActionResult> ForgotOrResetPasswordEmail([FromBody] UserEditViewModel user)
        {
            try
            {
                KwicleUser appUser = user.PasswordType == "reset" ? await _accountManager.GetUserByIdAsync(user.Id) : await _accountManager.GetUserByUserNameAsync(user.UserName);

                if (user == null)
                    return BadRequest($"{nameof(user)} cannot be null");

                if (appUser == null)
                    return NotFound($"User with username : {user.UserName} not found.");

                if (appUser.IsActiveDirectoryUser == true)
                {
                    return BadRequest("This functionality only available for form based user.");
                }

                string changePasswordHtml = string.Empty;
                using (var templateService = new TemplateService("Email\\Forgot_ResetPassword.html", TemplateFileFormat.HTML, base.ZoneId))
                {
                    //read file
                    changePasswordHtml = await templateService.ReadFile();
                }
                string resetToken = await _accountManager.GeneratePasswordResetTokenAsync(appUser);

                string callbackUrl = $"{_configuration["Keys:AuthorityUrl"]}create-password?resettoken={System.Net.WebUtility.UrlEncode(resetToken).Replace('%', '$')}&username={HttpUtility.UrlEncode(appUser.UserName)}&type={HttpUtility.UrlEncode(user.PasswordType)}";

                string emailMessage = changePasswordHtml
                    .Replace("{passwordType}", user.PasswordType)
                    .Replace("{fullName}", appUser.FullName)
                    .Replace("{linkValidDate}", DateTime.Now.AddHours(Convert.ToDouble(_configuration["Keys:PasswordResetTokenLifetimeHours"])).ToString("MM/dd/yyyy hh:mm:ss tt"))
                    .Replace("{url}", callbackUrl);

                string[] receipt = { appUser.Email };
                TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                await _emailService.SendEmailAsync(receipt, textInfo.ToTitleCase(user.PasswordType) + " Password", emailMessage);

                return Ok(user.PasswordType == "recover" ? "Please check your registered email to recover the password." : "E-mail with reset link has been sent to the user.");
            }
            catch (FileNotFoundException fileNotFoundException)
            {
                return BadRequest(fileNotFoundException.ToString());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpGet("users")]
        [Produces(typeof(UserViewModel))]
        public async Task<IActionResult> GetUsers()
        {
            var usersAndRoles = await _accountManager.GetUsersAndRolesAsync();

            List<UserViewModel> usersVM = new List<UserViewModel>();

            foreach (var item in usersAndRoles)
            {
                var userVM = _mapper.Map<UserViewModel>(item.Item1);
                userVM.Roles = item.Item2;
                userVM.RoleNames = string.Join(",", item.Item2);
                usersVM.Add(userVM);
            }

            return Ok(usersVM);
        }


        [HttpPut("users/EnableDisableUser/{id}")]
        public async Task<IActionResult> EnableDisableUser(string id)
        {
            KwicleUser appUser = await this._accountManager.GetUserByIdAsync(id);

            if (appUser == null)
                return NotFound(id);

            appUser.IsEnabled = !appUser.IsEnabled;
            var result = await _accountManager.UpdateUserAsync(appUser);

            if (result.Item1)
            {
                return Ok();
            }
            foreach (var error in result.Item2)
            {
                ModelState.AddModelError("Error", error);
            }

            //if (!result.Item1)
            //    throw new Exception("The following errors occurred whilst unblocking user: " + string.Join(", ", result.Item2));

            return BadRequest(ModelState);
        }

        #region Role

        [HttpGet("GetRoles")]
        [Produces(typeof(List<RoleViewModel>))]
        public async Task<IActionResult> GetRoles()
        {
            var roles = await _accountManager.GetRolesAsync();
            return Ok(_mapper.Map<List<RoleViewModel>>(roles));
        }

        [HttpGet("roles/{id}", Name = GetRoleByIdActionName)]
        [Produces(typeof(RoleViewModel))]
        public async Task<IActionResult> GetRoleById(string id)
        {
            var appRole = await _accountManager.GetRoleByIdAsync(id);

            //if (!(await _authorizationService.AuthorizeAsync(this.User, appRole?.Name ?? "", AccountManagementOperations.Read)).Succeeded)
            //    return new ChallengeResult();

            if (appRole == null)
                return NotFound(id);

            RoleViewModel roleVM = await GetRoleViewModelHelper(id);

            if (roleVM != null)
                return Ok(roleVM);
            else
                return NotFound(id);
        }

        [HttpPut("roles/{id}")]
        public async Task<IActionResult> UpdateRole(string id, [FromBody] RoleViewModel role)
        {
            if (ModelState.IsValid)
            {
                if (role == null)
                    return BadRequest($"{nameof(role)} cannot be null");

                if (!string.IsNullOrWhiteSpace(role.Id) && id != role.Id)
                    return BadRequest("Conflicting role id in parameter and model data");



                KwicleRole appRole = await _accountManager.GetRoleByIdAsync(id);

                if (appRole == null)
                    return NotFound(id);


                _mapper.Map<RoleViewModel, KwicleRole>(role, appRole);
                appRole.UpdatedDate = base.TodaysDate;
                appRole.UpdatedBy = base.UserName;
                appRole.RecordStatusChangeComment = "Updated";

                var result = await _accountManager.UpdateRoleAsync(appRole, role.Permissions?.Select(p => p.ClaimValue).ToArray());
                if (result.Item1)
                    return Ok(appRole.Id);

                foreach (var error in result.Item2)
                {
                    ModelState.AddModelError("Error", error);
                }

            }

            return BadRequest(ModelState);
        }

        [HttpPost("roles")]
        public async Task<IActionResult> CreateRole([FromBody] RoleViewModel role)
        {
            if (ModelState.IsValid)
            {
                if (role == null)
                    return BadRequest($"{nameof(role)} cannot be null");


                KwicleRole appRole = _mapper.Map<KwicleRole>(role);
                appRole.CreatedDate = base.TodaysDate;
                appRole.CreatedBy = base.UserName;
                appRole.RecordStatus = (int)RecordStatus.Active;
                appRole.RecordStatusChangeComment = RecordStatus.Active.ToString();

                var result = await _accountManager.CreateRoleAsync(appRole, role.Permissions?.Select(p => p.ClaimValue).ToArray());
                if (result.Item1)
                {
                    RoleViewModel roleVM = await GetRoleViewModelHelper(appRole.Id);
                    return CreatedAtAction(GetRoleByIdActionName, new { id = roleVM.Id }, roleVM);
                }

                foreach (var error in result.Item2)
                {
                    ModelState.AddModelError("Error", error);
                }
            }

            return BadRequest(ModelState);
        }

        [HttpDelete("roles/{id}")]
        [Produces(typeof(RoleViewModel))]
        public async Task<IActionResult> DeleteRole(string id)
        {
            if (!await _accountManager.TestCanDeleteRoleAsync(id))
                return BadRequest("Role cannot be deleted. Remove all users from this role and try again");


            RoleViewModel roleVM = null;
            KwicleRole appRole = await this._accountManager.GetRoleByIdAsync(id);

            if (appRole != null)
                roleVM = await GetRoleViewModelHelper(appRole.Id);


            if (roleVM == null)
                return NotFound(id);

            var result = await this._accountManager.DeleteRoleAsync(appRole);
            if (!result.Item1)
                throw new Exception("The following errors occurred whilst deleting role: " + string.Join(", ", result.Item2));


            return Ok(roleVM);
        }



        //[HttpGet("permissions")]
        //[Produces(typeof(List<PermissionViewModel>))]
        //public IActionResult GetAllPermissions()
        //{
        //    return Ok(Mapper.Map<List<PermissionViewModel>>(ApplicationPermissions.AllPermissions));
        //}

        private async Task<RoleViewModel> GetRoleViewModelHelper(string roleId)
        {
            var role = await _accountManager.GetRoleAndClaimsAsync(roleId);
            if (role != null)
                return _mapper.Map<RoleViewModel>(role);

            return null;
        }
        #endregion

    }
}
