using IdentityServer4.Extensions;
using IdentityServer4.Models;
using IdentityServer4.Services;
using Kwicle.Core.Entities;
using Microsoft.AspNetCore.Identity;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Modules.Authorization
{
    public class ProfileService : IProfileService
    {
        private readonly UserManager<KwicleUser> _userManager;
        private readonly IUserClaimsPrincipalFactory<KwicleUser> _claimsFactory;

        public ProfileService(UserManager<KwicleUser> userManager, IUserClaimsPrincipalFactory<KwicleUser> claimsFactory)
        {
            _userManager = userManager;
            _claimsFactory = claimsFactory;
        }

        public async Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            var sub = context.Subject.GetSubjectId();
            var user = await _userManager.FindByIdAsync(sub);
            var principal = await _claimsFactory.CreateAsync(user);

            var claims = principal.Claims.ToList();
            claims = claims.Where(claim => context.RequestedClaimTypes.Contains(claim.Type)).ToList();

            if (user.JobTitle != null)
                claims.Add(new System.Security.Claims.Claim(PropertyConstants.JobTitle, user.JobTitle));

            if (user.FullName != null)
                claims.Add(new System.Security.Claims.Claim(PropertyConstants.FullName, user.FullName));

            if (user.Configuration != null)
                claims.Add(new System.Security.Claims.Claim(PropertyConstants.Configuration, user.Configuration));

            context.IssuedClaims = claims;
        }


        public async Task IsActiveAsync(IsActiveContext context)
        {
            var sub = context.Subject.GetSubjectId();
            var user = await _userManager.FindByIdAsync(sub);

            context.IsActive = (user != null) && user.IsEnabled;
        }
    }
}
