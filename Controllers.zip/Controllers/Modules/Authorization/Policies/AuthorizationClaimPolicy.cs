﻿using Kwicle.Core.Entities;
using Kwicle.Service.Policies;
using Microsoft.AspNetCore.Authorization;
using Auth = Kwicle.Service;
using AppPermissions = Kwicle.Core.ApplicationPermissions;
using Polly;

namespace Kwicle.Service.Controllers.Modules.Authorization.Policies
{
    public static class AuthorizationClaimPolicy
    {
        public static void AuthorizationClaimPolicies(this AuthorizationOptions options)
        {            
            options.AddPolicy(Auth.Authorization.Policies.ViewAllUsersPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.ViewUsers));
            options.AddPolicy(Auth.Authorization.Policies.ManageAllUsersPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.ManageUsers));
            options.AddPolicy(Auth.Authorization.Policies.ViewAllRolesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.ViewRoles));
            options.AddPolicy(Auth.Authorization.Policies.ViewRoleByRoleNamePolicy, policy => policy.Requirements.Add(new ViewRoleAuthorizationRequirement()));
            options.AddPolicy(Auth.Authorization.Policies.ManageAllRolesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.ManageRoles));
            options.AddPolicy(Auth.Authorization.Policies.AssignAllowedRolesPolicy, policy => policy.Requirements.Add(new AssignRolesAuthorizationRequirement()));
            
            options.AddPolicy(Auth.Authorization.Policies.AddCPTCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddCPTCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateCPTCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateCPTCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewCPTCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewCPTCode));

            options.AddPolicy(Auth.Authorization.Policies.AddICDCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddICDCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateICDCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateICDCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewICDCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewICDCode));

            options.AddPolicy(Auth.Authorization.Policies.AddRevenueCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddRevenueCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateRevenueCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateRevenueCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewRevenueCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewRevenueCode));

            options.AddPolicy(Auth.Authorization.Policies.AddDRGCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddDRGCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateDRGCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateDRGCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewDRGCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewDRGCode));

            options.AddPolicy(Auth.Authorization.Policies.AddPlaceOfServicePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddPlaceOfService));
            options.AddPolicy(Auth.Authorization.Policies.UpdatePlaceOfServicePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdatePlaceOfService));
            options.AddPolicy(Auth.Authorization.Policies.ViewPlaceOfServicePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewPlaceOfService));

            options.AddPolicy(Auth.Authorization.Policies.AddNDCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddNDCCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateNDCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateNDCCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewNDCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewNDCCode));

            options.AddPolicy(Auth.Authorization.Policies.AddHCCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddHCCCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateHCCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateHCCCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewHCCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewHCCCode));

            options.AddPolicy(Auth.Authorization.Policies.AddZipCodesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddZipCodes));
            options.AddPolicy(Auth.Authorization.Policies.UpdateZipCodesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateZipCodes));
            options.AddPolicy(Auth.Authorization.Policies.ViewZipCodesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewZipCodes));

            options.AddPolicy(Auth.Authorization.Policies.AddHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddHomeGrownCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateHomeGrownCode));
            options.AddPolicy(Auth.Authorization.Policies.DeleteHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteHomeGrownCode));
            options.AddPolicy(Auth.Authorization.Policies.ViewHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewHomeGrownCode));
            options.AddPolicy(Auth.Authorization.Policies.AddCustomerSettingPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddCustomerSetting));
            options.AddPolicy(Auth.Authorization.Policies.UpdateCustomerSettingPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateCustomerSetting));
            options.AddPolicy(Auth.Authorization.Policies.ViewCustomerSettingPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewCustomerSetting));

            options.AddPolicy(Auth.Authorization.Policies.ViewTimelyFilingPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewTimelyFiling));
            options.AddPolicy(Auth.Authorization.Policies.ManageTimelyFilingPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageTimelyFiling));
            options.AddPolicy(Auth.Authorization.Policies.DeleteTimelyFilingPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteTimelyFiling));

            options.AddPolicy(Auth.Authorization.Policies.ViewInterestQuickPayPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewInterestQuickPay));
            options.AddPolicy(Auth.Authorization.Policies.ManageInterestQuickPayPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageInterestQuickPay));
            options.AddPolicy(Auth.Authorization.Policies.DeleteInterestQuickPayPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteInterestQuickPay));

            options.AddPolicy(Auth.Authorization.Policies.ViewUCRFeeSchedulePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewUCRFeeSchedule));
            options.AddPolicy(Auth.Authorization.Policies.AddUCRFeeSchedulePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddUCRFeeSchedule));
            options.AddPolicy(Auth.Authorization.Policies.UpdateUCRFeeSchedulePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateUCRFeeSchedule));
            options.AddPolicy(Auth.Authorization.Policies.DeleteUCRFeeScedulePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteUCRFeeSchedule));
            options.AddPolicy(Auth.Authorization.Policies.CopyUCRFeeSchedulePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToCopyUCRFeeSchedule));

            options.AddPolicy(Auth.Authorization.Policies.ViewModifierDiscountGroupPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewModifierDiscountGroup));
            options.AddPolicy(Auth.Authorization.Policies.ManageModifierDiscountGroupPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageModifierDiscountGroup));
            options.AddPolicy(Auth.Authorization.Policies.DeleteModifierDiscountGroupPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteModifierDiscountGroup));

            options.AddPolicy(Auth.Authorization.Policies.ViewCapitationPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewCapitation));
            options.AddPolicy(Auth.Authorization.Policies.ManageCapitationPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageCapitation));
            options.AddPolicy(Auth.Authorization.Policies.DeleteCapitationPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteCapitation));

            options.AddPolicy(Auth.Authorization.Policies.ViewFeeScheduleLimitsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewFeeScheduleLimits));
            options.AddPolicy(Auth.Authorization.Policies.ManageFeeScheduleLimitsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageFeeScheduleLimits));
            options.AddPolicy(Auth.Authorization.Policies.DeleteFeeScheduleLimitsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteFeeScheduleLimits));

            options.AddPolicy(Auth.Authorization.Policies.ViewCommonCodeDisplayConfigurationPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewCommonCodeDisplayConfiguration));
            options.AddPolicy(Auth.Authorization.Policies.UpdateCommonCodeDisplayConfigurationPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateCommonCodeDisplayConfiguration));
            options.AddPolicy(Auth.Authorization.Policies.AddCommonCodeDisplayConfigurationPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddCommonCodeDisplayConfiguration));


            options.AddPolicy(Auth.Authorization.Policies.ViewCommonCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewCommonCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateCommonCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateCommonCode));
            options.AddPolicy(Auth.Authorization.Policies.AddCommonCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddCommonCode));

            options.AddPolicy(Auth.Authorization.Policies.ViewAgeCategoriesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewAgeCategoies));
            options.AddPolicy(Auth.Authorization.Policies.ManageAgeCategoriesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageAgeCatergoies));
            options.AddPolicy(Auth.Authorization.Policies.DeleteAgeCategoriesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteAgeCategories));

            options.AddPolicy(Auth.Authorization.Policies.ViewRegionsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewRegion));
            options.AddPolicy(Auth.Authorization.Policies.ManageRegionsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageRegion));
            options.AddPolicy(Auth.Authorization.Policies.DeleteRegionsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteRegion));


            options.AddPolicy(Auth.Authorization.Policies.ViewRegionsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewRegion));
            options.AddPolicy(Auth.Authorization.Policies.ManageRegionsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageRegion));
            options.AddPolicy(Auth.Authorization.Policies.DeleteRegionsPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteRegion));

            options.AddPolicy(Auth.Authorization.Policies.ViewZipCodesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewZipCodes));
            options.AddPolicy(Auth.Authorization.Policies.UpdateZipCodesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateZipCodes));
            options.AddPolicy(Auth.Authorization.Policies.AddZipCodesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddZipCodes));

            options.AddPolicy(Auth.Authorization.Policies.ViewNDCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewNDCCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateNDCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateNDCCode));
            options.AddPolicy(Auth.Authorization.Policies.AddNDCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddNDCCode));

            options.AddPolicy(Auth.Authorization.Policies.ViewHCCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewHCCCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateHCCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateHCCCode));
            options.AddPolicy(Auth.Authorization.Policies.AddHCCCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddHCCCode));

            options.AddPolicy(Auth.Authorization.Policies.ViewAnesthesiaCodeUnitPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewAnesthesiaCodeUnit));
            options.AddPolicy(Auth.Authorization.Policies.ManageAnesthesiaCodeUnitPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageAnesthesiaCodeUnit));
            options.AddPolicy(Auth.Authorization.Policies.DeleteAnesthesiaCodeUnitPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteAnesthesiaCodeUnit));

            options.AddPolicy(Auth.Authorization.Policies.ViewAnesthesiaCodeUnitPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewAnesthesiaCodeUnit));
            options.AddPolicy(Auth.Authorization.Policies.ManageAnesthesiaCodeUnitPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageAnesthesiaCodeUnit));
            options.AddPolicy(Auth.Authorization.Policies.DeleteAnesthesiaCodeUnitPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteAnesthesiaCodeUnit));

            options.AddPolicy(Auth.Authorization.Policies.ViewAnesthesiaConversionFactorPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewAnesthesiaConversionFactor));
            options.AddPolicy(Auth.Authorization.Policies.ManageAnesthesiaConversionFactorPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageAnesthesiaConversionFactor));
            options.AddPolicy(Auth.Authorization.Policies.DeleteAnesthesiaConversionFactorPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteAnesthesiaConversionFactor));

            options.AddPolicy(Auth.Authorization.Policies.ViewAnesthesiaRegionRatesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewAnesthesiaRegionRates));
            options.AddPolicy(Auth.Authorization.Policies.ManageAnesthesiaRegionRatesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageAnesthesiaRegionRates));
            options.AddPolicy(Auth.Authorization.Policies.DeleteAnesthesiaRegionRatesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteAnesthesiaRegionRates));

            options.AddPolicy(Auth.Authorization.Policies.ViewAnesthesiaRegionRatesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewAnesthesiaRegionRates));
            options.AddPolicy(Auth.Authorization.Policies.ManageAnesthesiaRegionRatesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageAnesthesiaRegionRates));
            options.AddPolicy(Auth.Authorization.Policies.DeleteAnesthesiaRegionRatesPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteAnesthesiaRegionRates));

            options.AddPolicy(Auth.Authorization.Policies.ViewHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewHomeGrownCode));
            options.AddPolicy(Auth.Authorization.Policies.AddHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddHomeGrownCode));
            options.AddPolicy(Auth.Authorization.Policies.DeleteHomeGrownCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteHomeGrownCode));

            options.AddPolicy(Auth.Authorization.Policies.ViewRBRVSCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewRBRVSCode));
            options.AddPolicy(Auth.Authorization.Policies.AddRBRVSCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddRBRVSCode));
            options.AddPolicy(Auth.Authorization.Policies.DeleteRBRVSCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteRBRVSCode));
            options.AddPolicy(Auth.Authorization.Policies.UpdateRBRVSCodePolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateRBRVSCode));

            options.AddPolicy(Auth.Authorization.Policies.ViewRBRVSPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewRBRVS));
            options.AddPolicy(Auth.Authorization.Policies.AddRBRVSPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddRBRVS));
            options.AddPolicy(Auth.Authorization.Policies.DeleteRBRVSPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteRBRVS));
            options.AddPolicy(Auth.Authorization.Policies.UpdateRBRVSPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateRBRVS));

            options.AddPolicy(Auth.Authorization.Policies.ViewLocalityPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewLocality));
            options.AddPolicy(Auth.Authorization.Policies.AddLocalityPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddLocality));
            options.AddPolicy(Auth.Authorization.Policies.DeleteLocalityPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteLocality));
            options.AddPolicy(Auth.Authorization.Policies.UpdateLocalityPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateLocality));

            options.AddPolicy(Auth.Authorization.Policies.ViewGPCIPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewGPCI));
            options.AddPolicy(Auth.Authorization.Policies.AddGPCIPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToAddGPCI));
            options.AddPolicy(Auth.Authorization.Policies.DeleteGPCIPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteGPCI));
            options.AddPolicy(Auth.Authorization.Policies.UpdateGPCIPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToUpdateGPCI));


            options.AddPolicy(Auth.Authorization.Policies.ViewEDITradingPartnerPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToViewEDITradingPartner));
            options.AddPolicy(Auth.Authorization.Policies.ManageEDITradingPartnerPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToManageEDITradingPartner));
            options.AddPolicy(Auth.Authorization.Policies.DeleteEDITradingPartnerPolicy, policy => policy.RequireClaim(ClaimConstants.Permission, AppPermissions.PermissionToDeleteEDITradingPartner));


            //options.AddPolicy(Policy.Kwicle, policy =>
            //{
            //    policy.RequireClaim(PolicyType.scope, ApiConstants.KwicleApi);
            //});

            options.AddPolicy(Auth.Authorization.Policies.GoldKidneyGETPolicy, policy => policy.RequireScope(GoldKidneyScopes.GET));
            options.AddPolicy(Auth.Authorization.Policies.GoldKidneyPOSTPolicy, policy => policy.RequireScope(GoldKidneyScopes.POST));
            options.AddPolicy(Auth.Authorization.Policies.GoldKidneyPUTPolicy, policy => policy.RequireScope(GoldKidneyScopes.PUT));
            options.AddPolicy(Auth.Authorization.Policies.GoldKidneyDELETEPolicy, policy => policy.RequireScope(GoldKidneyScopes.DELETE));

        }
    }
}
