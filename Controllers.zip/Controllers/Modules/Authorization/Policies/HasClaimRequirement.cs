using Kwicle.Core.Entities;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Modules.Authorization.Policies
{
    public class HasClaimRequirement : IAuthorizationRequirement
    {
        //public string Issuer { get; }
        //public string ClaimType { get; set; }
        public string ClaimValue { get; set; }
        //public string Scope { get; }

        public HasClaimRequirement(string claimValue)
        {
            //ClaimType = claimType ?? throw new ArgumentNullException(nameof(claimType));
            ClaimValue = claimValue ?? throw new ArgumentNullException(nameof(claimValue));
        }
    }

    public class HasClaimHandler : AuthorizationHandler<HasClaimRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, HasClaimRequirement requirement)
        {
            //// If user does not have the scope claim, get out of here
            //if (!context.User.HasClaim(c => c.Type == ClaimConstants.Permission))
            //    return Task.CompletedTask;

            //// Split the scopes string into an array
            ////var scopes = context.User.FindFirst(c => c.Type == ClaimConstants.Permission && c.Value == requirement.Scope).Value.Split(' ');
            //var scopes = context.User.FindAll(c => c.Type == ClaimConstants.Permission);

            //// Succeed if the scope array contains the required scope
            //if (scopes.Any(s => s.Value == requirement.Scope))
            //    context.Succeed(requirement);

            //return Task.FromResult(Execute());
            if (context.User != null)
            {
                var matchingClaims =
                    context.User.Claims.Any(c => string.Equals(c.Type, ClaimConstants.Permission, StringComparison.OrdinalIgnoreCase)
                                            && string.Equals(c.Value, requirement.ClaimValue, StringComparison.Ordinal));

                if (matchingClaims)
                {
                    context.Succeed(requirement);
                }
            }            
            return Task.CompletedTask;
        }

        //private HttpResponseMessage Execute()
        //{
        //    HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
        //    response.ReasonPhrase = "Unauthorize";            
        //    return response;
        //}
    }    
}
