using Kwicle.Service.Policies;

namespace Kwicle.Service.Authorization
{
    public class Policies
    {
        public const string ViewAllUsersPolicy = "View All Users";
        public const string ManageAllUsersPolicy = "Manage All Users";
        public const string ViewAllRolesPolicy = "View All Roles";
        public const string ViewRoleByRoleNamePolicy = "View Role by RoleName";
        public const string ManageAllRolesPolicy = "Manage All Roles";
        public const string AssignAllowedRolesPolicy = "Assign Allowed Roles";

        public const string ViewFeeScheduleLimitsPolicy = "View Fee Scedule Limits";
        public const string ManageFeeScheduleLimitsPolicy = "Manage Fee Scedule Limits";
        public const string DeleteFeeScheduleLimitsPolicy = "Delete Fee Scedule Limits";

        public const string ViewUCRFeeSchedulePolicy = "View UCR Fee Schedule";
        public const string AddUCRFeeSchedulePolicy = "Add UCR Fee Schedule";
        public const string UpdateUCRFeeSchedulePolicy = "Update UCR Fee Schedule";
        public const string DeleteUCRFeeScedulePolicy = "Delete UCR Fee Schedule";
        public const string CopyUCRFeeSchedulePolicy = "Copy UCR Fee Schedule";

        public const string ViewRBRVSCodePolicy = "View RBRVS Code";
        public const string AddRBRVSCodePolicy = "Add RBRVS Code";
        public const string UpdateRBRVSCodePolicy = "Update RBRVS Code";
        public const string DeleteRBRVSCodePolicy = "Delete RBRVS Code";

        public const string ViewRBRVSPolicy = "View RBRVS";
        public const string AddRBRVSPolicy = "Add RBRVS";
        public const string UpdateRBRVSPolicy = "Update RBRVS";
        public const string DeleteRBRVSPolicy = "Delete RBRVS";

        public const string ViewGPCIPolicy = "View GPCI";
        public const string AddGPCIPolicy = "Add GPCI";
        public const string UpdateGPCIPolicy = "Update GPCI";
        public const string DeleteGPCIPolicy = "Delete GPCI";

        public const string ViewLocalityPolicy = "View Locality";
        public const string AddLocalityPolicy = "Add Locality";
        public const string UpdateLocalityPolicy = "Update Locality";
        public const string DeleteLocalityPolicy = "Delete Locality";

        public const string ViewAgeCategoriesPolicy = "View Age Categories";
        public const string ManageAgeCategoriesPolicy = "Add/Update Age Categories";
        //public const string UpdateAgeCategoriesPolicy = "Update Age Categories";
        public const string DeleteAgeCategoriesPolicy = "Delete Age Categories";

        public const string ViewAnesthesiaRegionRatesPolicy = "View Anesthesia Region Rates";
        public const string ManageAnesthesiaRegionRatesPolicy = "Add/Update Anesthesia Region Rates";
        //public const string UpdateAnesthesiaRegionRatesPolicy = "Update Anesthesia Region Rates";
        public const string DeleteAnesthesiaRegionRatesPolicy = "Delete Anesthesia Region Rates";

        public const string ViewTimelyFilingPolicy = "View Timely Filing";
        public const string ManageTimelyFilingPolicy = "Add/Update Timely Filing";
        //public const string UpdateTimelyFilingPolicy = "Update Timely Filing";
        public const string DeleteTimelyFilingPolicy = "Delete Timely Filing";

        public const string ViewInterestQuickPayPolicy = "View Interest/Quick Pay";
        public const string ManageInterestQuickPayPolicy = "Add/Update Interest/Quick Pay";
        //public const string UpdateInterestQuickPayPolicy = "Update Interest/Quick Pay";
        public const string DeleteInterestQuickPayPolicy = "Delete Interest/Quick Pay";

        public const string ViewModifierDiscountGroupPolicy = "View Modifier Discount Group";
        public const string ManageModifierDiscountGroupPolicy = "Add/Update Modifier Discount Group";
        //public const string UpdateModifierDiscountGroupPolicy = "Update Modifier Discount Group";
        public const string DeleteModifierDiscountGroupPolicy = "Delete Modifier Discount Group";

        public const string ViewCapitationPolicy = "View Capitation";
        public const string ManageCapitationPolicy = "Add/Update Capitation";
        //public const string UpdateCapitationPolicy = "Update Capitation";
        public const string DeleteCapitationPolicy = "Delete Capitation";

        public const string ViewEDITradingPartnerPolicy = "View EDI - Trading Partner";
        public const string ManageEDITradingPartnerPolicy = "Add/Update EDI - Trading Partner";
        //public const string UpdateEDITradingPartnerPolicy = "Update EDI - Trading Partner";
        public const string DeleteEDITradingPartnerPolicy = "Delete EDI - Trading Partner";

        public const string ViewRegionsPolicy = "View Regions";
        public const string ManageRegionsPolicy = "Add/Update Regions";
        //public const string UpdateRegionsPolicy = "Update Regions";
        public const string DeleteRegionsPolicy = "Delete Regions";

        public const string ViewAnesthesiaConversionFactorPolicy = "View Anesthesia Conversion Factor";
        public const string ManageAnesthesiaConversionFactorPolicy = "Add/Update Anesthesia Conversion Factor";
        //public const string UpdateAnesthesiaConversionFactorPolicy = "Update Anesthesia Conversion Factor";
        public const string DeleteAnesthesiaConversionFactorPolicy = "Delete Anesthesia Conversion Factor";

        public const string ViewAnesthesiaCodeUnitPolicy = "View Anesthesia Code Unit";
        public const string ManageAnesthesiaCodeUnitPolicy = "Add/Update Anesthesia Code Unit";
        //public const string UpdateAnesthesiaCodeUnitPolicy = "Update Anesthesia Code Unit";
        public const string DeleteAnesthesiaCodeUnitPolicy = "Delete Anesthesia Code Unit";

        public const string ViewCPTCodePolicy = "View CPT Code";
        public const string AddCPTCodePolicy = "Add CPT Code";
        public const string UpdateCPTCodePolicy = "Update CPT Code";

        public const string ViewICDCodePolicy = "View ICD Code";
        public const string AddICDCodePolicy = "Add ICD Code";
        public const string UpdateICDCodePolicy = "Update ICD Code";

        public const string ViewRevenueCodePolicy = "View Revenue Code";
        public const string AddRevenueCodePolicy = "Add Revenue Code";
        public const string UpdateRevenueCodePolicy = "Update Revenue Code";

        public const string ViewDRGCodePolicy = "View DRG Code";
        public const string AddDRGCodePolicy = "Add DRG Code";
        public const string UpdateDRGCodePolicy = "Update DRG Code";

        public const string ViewPlaceOfServicePolicy = "View Place Of Service";
        public const string AddPlaceOfServicePolicy = "Add Place Of Service";
        public const string UpdatePlaceOfServicePolicy = "Update Place Of Service";

        public const string ViewNDCCodePolicy = "View NDC Code";
        public const string AddNDCCodePolicy = "Add NDC Code";
        public const string UpdateNDCCodePolicy = "Update NDC Code";

        public const string ViewHCCCodePolicy = "View HCC Code";
        public const string AddHCCCodePolicy = "Add HCC Code";
        public const string UpdateHCCCodePolicy = "Update HCC Code";

        public const string ViewZipCodesPolicy = "View Zip Codes";
        public const string AddZipCodesPolicy = "Add Zip Codes";
        public const string UpdateZipCodesPolicy = "Update Zip Codes";

        public const string ViewHomeGrownCodePolicy = "View Home Grown Code";
        public const string AddHomeGrownCodePolicy = "Add Home Grown Code";
        public const string UpdateHomeGrownCodePolicy = "Update Home Grown Code";
        public const string DeleteHomeGrownCodePolicy = "Delete Home Grown Code";

        public const string ViewCustomerSettingPolicy = "View Customer Setting";
        public const string AddCustomerSettingPolicy = "Add Customer Setting";
        public const string UpdateCustomerSettingPolicy = "Update Customer Setting";

        public const string ViewCodeTypePolicy = "View Code Type";
        
        public const string ViewCommonCodePolicy = "View Common Code";
        public const string AddCommonCodePolicy = "Add Common Code";
        public const string UpdateCommonCodePolicy = "Update Common Code";

        public const string ViewCommonCodeDisplayConfigurationPolicy = "View Common Code Display Configuration";
        public const string AddCommonCodeDisplayConfigurationPolicy = "Add Common Code Display Configuration";
        public const string UpdateCommonCodeDisplayConfigurationPolicy = "Update Common Code Display Configuration";

        public const string ViewFileTemplateType = "View File Template Type";


        public const string GoldKidneyGETPolicy = "Gold Kidney GET";
        public const string GoldKidneyPOSTPolicy = "Gold Kidney POST";
        public const string GoldKidneyPUTPolicy = "Gold Kidney PUT";
        public const string GoldKidneyDELETEPolicy = "Gold Kidney DELETE";
    }


    public static class AccountManagementOperations
    {
        public const string CreateOperationName = "Create";
        public const string ReadOperationName = "Read";
        public const string UpdateOperationName = "Update";
        public const string DeleteOperationName = "Delete";

        public static UserAccountAuthorizationRequirement Create = new UserAccountAuthorizationRequirement(CreateOperationName);
        public static UserAccountAuthorizationRequirement Read = new UserAccountAuthorizationRequirement(ReadOperationName);
        public static UserAccountAuthorizationRequirement Update = new UserAccountAuthorizationRequirement(UpdateOperationName);
        public static UserAccountAuthorizationRequirement Delete = new UserAccountAuthorizationRequirement(DeleteOperationName);
    }
}
