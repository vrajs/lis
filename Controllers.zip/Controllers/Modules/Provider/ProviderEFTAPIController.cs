using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Provider;
using AutoMapper;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderEFT")]
    public class ProviderEFTAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderEFTAPIController> _logger;
        private IProviderEFTRepository _ProviderEFTRepository;
        private IProviderEFTService _providerEFTService;
        private IMapper _mapper;
        #endregion

        #region Ctor  
        public ProviderEFTAPIController(IProviderEFTRepository ProviderEFTRepository, ILogger<ProviderEFTAPIController> logger, IMapper mapper, IProviderEFTService providerEFTService)
        {
            _logger = logger;
            _ProviderEFTRepository = ProviderEFTRepository;
            _providerEFTService = providerEFTService;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var eftResult = _ProviderEFTRepository.GetProviderEFT(null, null);
                return Ok(eftResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider EFT: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderEFTGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerEFT = _ProviderEFTRepository.GetById(id);
                if (providerEFT == null) return NotFound($"Provider EFT {id} was not found");
                return Ok(providerEFT);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider EFT: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderEFTByProviderId/{ProviderId}")]
        public IActionResult GetProviderEFTByProviderId(int ProviderId)
        {
            try
            {
                var providerEFT = _ProviderEFTRepository.GetProviderEFT(ProviderId, null);
                if (providerEFT == null) return NotFound($"Provider EFT was not found");
                return Ok(providerEFT);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider EFT: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderEFTByProviderIdAccountTypeID/{ProviderId}/{AccountTypeID}")]
        public IActionResult GetProviderEFTByProviderIdAccountTypeID(int ProviderId, int AccountTypeID)
        {
            try
            {
                var providerEFT = _ProviderEFTRepository.GetProviderEFT(ProviderId, AccountTypeID);
                if (providerEFT == null) return NotFound($"Provider EFT was not found");
                return Ok(providerEFT);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider EFT: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderEFTViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var providerEFT = _mapper.Map<ProviderEFT>(model);
                providerEFT.CreatedDate = base.TodaysDate;
                providerEFT.CreatedBy = base.UserName;
                providerEFT.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, providerEFT.EffectiveDate, providerEFT.TermDate);
                providerEFT.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, providerEFT.EffectiveDate, providerEFT.TermDate).ToString();

                // Check exist record condition in group
                _providerEFTService.CheckIfExists(providerEFT);
                if (!_providerEFTService.BusinessState.IsValid)
                {
                    _providerEFTService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderEFTRepository.Add(providerEFT);
                if (!_ProviderEFTRepository.DbState.IsValid)
                {
                    _ProviderEFTRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ProviderEFTGet", new { id = providerEFT.ProviderEFTID });
                _logger.LogInformation("New Provider EFT Created ");
                return Created(newUri, _mapper.Map<ProviderEFTViewModel>(providerEFT));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider EFT : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]ProviderEFTViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _ProviderEFTRepository.GetById(model.ProviderEFTID);
                if (entity == null) return NotFound($"Could not find Provider EFT with an ProviderEFTID of {model.ProviderEFTID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                // Check exist record condition in group
                _providerEFTService.CheckIfExists(entity);
                if (!_providerEFTService.BusinessState.IsValid)
                {
                    _providerEFTService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderEFTRepository.Update(entity);
                if (!_ProviderEFTRepository.DbState.IsValid)
                {
                    _ProviderEFTRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider EFT updated  : {0}", entity.ProviderEFTID);
                return Ok(model.ProviderEFTID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider EFT :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _ProviderEFTRepository.DeleteById(id);
                if (!_ProviderEFTRepository.DbState.IsValid)
                {
                    _ProviderEFTRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider EFT : {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
