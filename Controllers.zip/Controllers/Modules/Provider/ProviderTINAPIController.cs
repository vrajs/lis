using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Provider;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderTIN")]
    public class ProviderTINAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderTINAPIController> _logger;
        private IProviderTINRepository _ProviderTINRepository;
        private IProviderTINService _ProviderTINService;
        private IMapper _mapper;
        #endregion

        #region Ctor  
        public ProviderTINAPIController(IProviderTINRepository ProviderTINRepository, IProviderTINService ProviderTINService, ILogger<ProviderTINAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _ProviderTINRepository = ProviderTINRepository;
            _ProviderTINService = ProviderTINService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var tinResult = _ProviderTINRepository.GetProviderTIN(null, null);
                return Ok(tinResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider TINs: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderTINGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerTIN = _ProviderTINRepository.GetById(id);
                if (providerTIN == null) return NotFound($"Provider TIN {id} was not found");
                return Ok(providerTIN);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider TIN: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderTINByProviderId/{ProviderId}")]
        public IActionResult GetProviderTINByProviderId(int ProviderId)
        {
            try
            {
                var providerTIN = _ProviderTINRepository.GetProviderTIN(ProviderId, null);
                if (providerTIN == null) return NotFound($"Provider TIN was not found");
                return Ok(providerTIN);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider TIN: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderTINByProviderIdTINTypeID/{ProviderId}/{TINTypeID}")]
        public IActionResult GetProviderTINByProviderIdTINTypeID(int ProviderId, int TINTypeID)
        {
            try
            {
                var providerTIN = _ProviderTINRepository.GetProviderTIN(ProviderId, TINTypeID);
                if (providerTIN == null) return NotFound($"Provider TIN was not found");
                return Ok(providerTIN);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider TIN: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderTINViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var providerTIN = _mapper.Map<ProviderTIN>(model);
                providerTIN.CreatedDate = base.TodaysDate;
                providerTIN.CreatedBy = base.UserName;
                providerTIN.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, providerTIN.EffectiveDate, providerTIN.TermDate);
                providerTIN.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, providerTIN.EffectiveDate, providerTIN.TermDate).ToString();

                _ProviderTINService.CheckIfExist(providerTIN);
                if (!_ProviderTINService.BusinessState.IsValid)
                {
                    _ProviderTINService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderTINRepository.Add(providerTIN);
                if (!_ProviderTINRepository.DbState.IsValid)
                {
                    _ProviderTINRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ProviderTINGet", new { id = providerTIN.ProviderTINID });
                _logger.LogInformation("New Provider TIN Created ");
                return Created(newUri, _mapper.Map<ProviderTINViewModel>(providerTIN));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider TIN : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]ProviderTINViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _ProviderTINRepository.GetById(model.ProviderTINID);
                if (entity == null) return NotFound($"Could not find Provider TIN with an ProviderTINID of {model.ProviderTINID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _ProviderTINService.CheckIfExist(entity);
                if (!_ProviderTINService.BusinessState.IsValid)
                {
                    _ProviderTINService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderTINRepository.Update(entity);
                if (!_ProviderTINRepository.DbState.IsValid)
                {
                    _ProviderTINRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider TIN updated  : {0}", entity.ProviderTINID);
                return Ok(model.ProviderTINID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider TIN :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _ProviderTINRepository.DeleteById(id);
                if (!_ProviderTINRepository.DbState.IsValid)
                {
                    _ProviderTINRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider TIN : {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
