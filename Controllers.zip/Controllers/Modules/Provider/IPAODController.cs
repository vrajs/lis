using Kwicle.Core.Common;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("odata")]
    public class IPAODController : BaseODController
    {
        #region Property        
        private IIPARepository _IIPARepository;
        #endregion

        #region Constructor        
        public IPAODController(IIPARepository ipaRepository)
        {
            _IIPARepository = ipaRepository;
        }
        #endregion

        #region Methods
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("IPAs")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetIPAs(int filterStatus)
        {
            IQueryable<vwIPA> ipaListQuery = null;
            if (filterStatus == (int)FilterStatus.Active)
            {
                ipaListQuery = _IIPARepository.GetIPAs().Where(x => x.RecordStatus == (int)RecordStatus.Active);
            }
            if (filterStatus == (int)FilterStatus.All)
            {
                ipaListQuery = _IIPARepository.GetIPAs().Where(x => (x.RecordStatus == (int)RecordStatus.Active || x.RecordStatus == (int)RecordStatus.Termed || x.RecordStatus == (int)RecordStatus.InActive));
            }
            return Ok(ipaListQuery);
        }
        #endregion
    }
}
