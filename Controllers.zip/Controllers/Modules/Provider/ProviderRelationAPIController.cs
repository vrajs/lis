using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderRelation")]
    public class ProviderRelationAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderRelationAPIController> _logger;
        private IProviderRelationRepository _IProviderRelationRepository;
        private IProviderRelationService _IProviderRelationService;
        private IMapper _mapper;
        #endregion

        #region Ctor  
        public ProviderRelationAPIController(IProviderRelationRepository IProviderRelationRepository, ILogger<ProviderRelationAPIController> logger, IMapper mapper, IProviderRelationService IProviderRelationService)
        {
            _logger = logger;
            _IProviderRelationRepository = IProviderRelationRepository;
            _IProviderRelationService = IProviderRelationService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var providerRelationResult = _IProviderRelationRepository.GetProviderRelation(null, null);
                return Ok(providerRelationResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider Relation: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderRelationGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerRelation = _IProviderRelationRepository.GetById(id);
                if (providerRelation == null) return NotFound($"Provider Relation {id} was not found");
                return Ok(_mapper.Map<ProviderRelationModel>(providerRelation));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider Relation: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderRelationByParentProviderId/{ParentProviderID}")]
        public IActionResult GetProviderRelationByParentProviderId(int ParentProviderID)
        {
            try
            {
                var providerRelation = _IProviderRelationRepository.GetProviderRelation(ParentProviderID, null);
                if (providerRelation == null) return NotFound($"Provider Relation was not found");
                return Ok(providerRelation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider Relation: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderRelationByRelatedProviderId/{RelatedProviderID}")]
        public IActionResult GetProviderRelationByRelatedProviderId(int RelatedProviderID)
        {
            try
            {
                var providerRelation = _IProviderRelationRepository.GetProviderRelation(null, RelatedProviderID);
                if (providerRelation == null) return NotFound($"Provider Relation was not found");
                return Ok(providerRelation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider Relation: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderRelationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var providerRelation = _mapper.Map<ProviderRelation>(model);
                providerRelation.CreatedDate = base.TodaysDate;
                providerRelation.CreatedBy = base.UserName;
                providerRelation.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, providerRelation.EffectiveDate, providerRelation.TermDate);
                providerRelation.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, providerRelation.EffectiveDate, providerRelation.TermDate).ToString();

                _IProviderRelationService.CheckIfExist(providerRelation);
                if (!_IProviderRelationService.BusinessState.IsValid)
                {
                    _IProviderRelationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IProviderRelationRepository.Add(providerRelation);
                if (!_IProviderRelationRepository.DbState.IsValid)
                {
                    _IProviderRelationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("providerRelationGet", new { id = providerRelation.ProviderRelationID });
                _logger.LogInformation("New Provider Relation Created ");
                return Created(newUri, _mapper.Map<ProviderRelationModel>(providerRelation));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider Relation : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]ProviderRelationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IProviderRelationRepository.GetById(model.ProviderRelationID);
                if (entity == null) return NotFound($"Could not find Provider Relation with an ProviderRelationID of {model.ProviderRelationID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderRelationService.CheckIfExist(entity);
                if (!_IProviderRelationService.BusinessState.IsValid)
                {
                    _IProviderRelationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IProviderRelationRepository.Update(entity);
                if (!_IProviderRelationRepository.DbState.IsValid)
                {
                    _IProviderRelationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider Relation updated  : {0}", entity.ProviderRelationID);
                return Ok(entity.ProviderRelationID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider Relation :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IProviderRelationRepository.DeleteById(id);
                if (!_IProviderRelationRepository.DbState.IsValid)
                {
                    _IProviderRelationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider Relation : {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
