using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Web.Controllers.Modules.Provider
{
    [Route("api/ProviderEligibility")]
    public class ProviderEligibilityAPIController : BaseAPIController
    {
        private readonly IProviderRepository _IProviderRepository;
        private readonly IProviderEligibilityRepository _IProviderEligibilityRepository;
        private readonly IProviderEligibilityService _IProviderEligibilityService;
        private IMapper _mapper;
        private ILogger<ProviderEligibilityAPIController> _logger;

        public ProviderEligibilityAPIController(IProviderRepository IProviderRepository, IProviderEligibilityRepository IProviderEligibilityRepository, IMapper mapper, ILogger<ProviderEligibilityAPIController> logger
            , IProviderEligibilityService IProviderEligibilityService)
        {
            _IProviderRepository = IProviderRepository;
            _IProviderEligibilityRepository = IProviderEligibilityRepository;
            _mapper = mapper;
            _logger = logger;
            _IProviderEligibilityService = IProviderEligibilityService;
        }

        [HttpGet("GetByProvider/{providerID}")]
        public IActionResult GetByProvider(int providerID)
        {
            try
            {
                var providerEligibility = (from n in _IProviderEligibilityRepository.GetByPredicate(i => i.ProviderID == providerID)
                                           select n).OrderByDescending(o => o.TermDate).ToList();
                return Ok(_mapper.Map<List<ProviderEligibilityModel>>(providerEligibility));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Provider eligibilities {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetByProvider/{providerID}/{providerEligigbilityID}")]
        public IActionResult GetByProvider(int providerID, int providerEligigbilityID)
        {
            try
            {
                var providerEligibility = (from n in _IProviderEligibilityRepository.GetByPredicate(i => i.ProviderID == providerID && i.ProviderEligibilityID != providerEligigbilityID)
                                           select n).OrderByDescending(o => o.TermDate).ToList();
                return Ok(_mapper.Map<List<ProviderEligibilityModel>>(providerEligibility));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Provider eligibilities {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "ProviderEligibilityGet")]
        public IActionResult Get(int id)
        {
            try
            {
                ProviderEligibility providerEligibility = _IProviderEligibilityRepository.GetById(id);
                if (providerEligibility == null) return NotFound($"Provider eligibility {id} was not found");
                //return Ok(_mapper.Map<ProviderEligibilityModel>(providerEligibility));
                return Ok(providerEligibility);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] ProviderEligibilityModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ProviderEligibility entity = _mapper.Map<ProviderEligibility>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                //_IProviderEligibilityService.CheckIfExist(entity);
                //if (!_IProviderEligibilityService.BusinessState.IsValid)
                //{
                //    _IProviderEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                //    {
                //        ModelState.AddModelError(businessState.Key, businessState.Value);
                //    });
                //    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                //}

                _IProviderEligibilityRepository.Add(entity);
                if (!_IProviderEligibilityRepository.DbState.IsValid)
                {
                    _IProviderEligibilityRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                //update latest eligibilityid in provider table
                Core.Entities.ProviderStructure.Provider provider = _IProviderRepository.GetById(model.ProviderID);
                provider.ProviderEligibilityID = entity.ProviderEligibilityID;
                _IProviderRepository.Update(provider);
                if (!_IProviderRepository.DbState.IsValid)
                {
                    _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("ProviderEligibilityGet", new { id = entity.ProviderEligibilityID });
                _logger.LogInformation("Provider eligibility Created ");
                return Created(newUri, _mapper.Map<ProviderEligibilityModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider eligibility : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody] ProviderEligibilityModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IProviderEligibilityRepository.GetById(model.ProviderEligibilityID);
                if (entity == null) return NotFound($"Could not find provider eligibility with a ProviderID of {model.ProviderID}");

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderEligibilityService.CheckIfExist(entity, true);
                if (!_IProviderEligibilityService.BusinessState.IsValid)
                {
                    _IProviderEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IProviderEligibilityRepository.Update(entity);
                if (!_IProviderEligibilityRepository.DbState.IsValid)
                {
                    _IProviderEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider eligibility updated  : {0}", entity.ProviderEligibilityID);
                return Ok(model.ProviderEligibilityID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider Eligibility :{ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                bool ifExistInProvider = _IProviderRepository.GetByPredicate(x => x.ProviderEligibilityID == id).Any();
                if (ifExistInProvider)
                {
                    return StatusCode((int)HttpStatusCode.NotAcceptable, "You can not delete current eligibility of provider.");
                }
                _IProviderEligibilityRepository.DeleteById(id);
                if (!_IProviderEligibilityRepository.DbState.IsValid)
                {
                    _IProviderEligibilityRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok();

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing provider eligibility : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetMaxProvEligId/{providerId}")]
        public int GetMaxProvEligId(int providerId)
        {
            var res = _IProviderEligibilityRepository.GetMaxProvEligId(providerId);
            return res;
        }
    }
}
