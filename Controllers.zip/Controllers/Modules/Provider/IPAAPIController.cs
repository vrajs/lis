using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/IPA")]
    public class IPAAPIController : BaseAPIController
    {
        private readonly IIPARepository _IIPARepository;
        private IMapper _mapper;
        private ILogger<IPAAPIController> _logger;

        public IPAAPIController(IIPARepository IIPARepository, IMapper mapper, ILogger<IPAAPIController> logger)
        {
            _IIPARepository = IIPARepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            var ipaList = _IIPARepository.GetByPredicate(null);
            return Ok(_mapper.Map<List<IPAModel>>(ipaList));
        }

        [HttpGet("GetView/{id}")]
        public IActionResult GetView(int id)
        {
            try
            {
                //var benefitHeader = _IProviderRepository.GetBenefits().Single(x => x.BenefitHeaderID == id);                
                //if (benefitHeader == null) return NotFound($"Benefit {id} was not found");
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "IPAGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var ipa = _IIPARepository.GetById(id);
                if (ipa == null) return NotFound($"IPA with {id} was not found");
                return Ok(_mapper.Map<IPAModel>(ipa));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]IPAModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                IPA entity = _mapper.Map<IPA>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IIPARepository.Add(entity);

                if (!_IIPARepository.DbState.IsValid)
                {
                    _IIPARepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("IPAGet", new { id = entity.IPAID });
                _logger.LogInformation("New IPA Created");
                return Created(newUri, _mapper.Map<IPAModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving IPA : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5 int id, 
        [HttpPut]
        public IActionResult Put([FromBody]IPAModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                IPA entity = _IIPARepository.GetById(model.IPAID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IIPARepository.Update(entity);
                if (!_IIPARepository.DbState.IsValid)
                {
                    _IIPARepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("IPA Updated : {0}", entity.IPAID);
                return Ok(entity.IPAID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating IPA : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IIPARepository.DeleteById(id);
                if (!_IIPARepository.DbState.IsValid)
                {
                    _IIPARepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing IPA : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
