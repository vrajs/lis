using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Provider;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderContract")]
    public class ProviderContractAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderTINAPIController> _logger;
        private IProviderContractRepository _ProviderContractRepository;
        private IMapper _mapper;
        private IProviderContractService _ProviderContractService;
        #endregion

        #region Ctor  
        public ProviderContractAPIController(IProviderContractRepository ProviderContractRepository, ILogger<ProviderTINAPIController> logger, IMapper mapper, IProviderContractService ProviderContractService)
        {
            _logger = logger;
            _ProviderContractRepository = ProviderContractRepository;
            _mapper = mapper;
            _ProviderContractService = ProviderContractService;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var tinResult = _ProviderContractRepository.GetGroupContract(null, null);
                return Ok(tinResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider Contracts: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderContractGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerContract = _ProviderContractRepository.GetGroupContract(null, id);
                if (providerContract == null) return NotFound($"Provider Contract {id} was not found");
                return Ok(providerContract);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderContractByProviderId/{ProviderId}")]
        public IActionResult GetProviderContractByProviderId(int ProviderId)
        {
            try
            {
                var providerContract = _ProviderContractRepository.GetGroupContract(ProviderId, null);
                if (providerContract == null) return NotFound($"Provider Contract was not found");
                return Ok(providerContract);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderContractDropDownByProviderID/{ProviderId}")]
        public IActionResult GetProviderContractDropDownByProviderID(int ProviderId)
        {
            try
            {
                var groupProviderContract = _ProviderContractRepository.GetProviderContract(ProviderId);
                if (groupProviderContract == null) return NotFound($"Group Provider Contract was not found");
                return Ok(groupProviderContract);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Group Provider Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderContractModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ProviderContract entity = _mapper.Map<ProviderContract>(model);
                entity.FeeScheduleHeader = null;
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                if (entity.ProviderContractLobs.Count > 0)
                {
                    entity.ProviderContractLobs.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                if (entity.ProviderContractInterest.Count > 0)
                {
                    entity.ProviderContractInterest.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                if (entity.ProviderContractTimelyFiling.Count > 0)
                {
                    entity.ProviderContractTimelyFiling.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                // Check exist record condition in group
                _ProviderContractService.CheckIfExistInGroup(entity);
                if (!_ProviderContractService.BusinessState.IsValid)
                {
                    _ProviderContractService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderContractRepository.Add(entity);

                if (!_ProviderContractRepository.DbState.IsValid)
                {
                    _ProviderContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("ProviderContractGet", new { id = entity.ProviderContractID });
                _logger.LogInformation("New Provider Contract Created");
                return Created(newUri, _mapper.Map<ProviderContractModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ProviderContractModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldProviderContract = _ProviderContractRepository.GetById(model.ProviderContractID);
                if (oldProviderContract == null) return NotFound($"Could not find a Provider Contract with an ProviderContractID of {model.ProviderContractID}");

                _mapper.Map(model, oldProviderContract);
                oldProviderContract.FeeScheduleHeader = null;
                oldProviderContract.UpdatedDate = base.TodaysDate;
                oldProviderContract.UpdatedBy = base.UserName;
                oldProviderContract.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldProviderContract.EffectiveDate, oldProviderContract.TermDate);
                oldProviderContract.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldProviderContract.EffectiveDate, oldProviderContract.TermDate).ToString();

                if (oldProviderContract.ProviderContractLobs.Count > 0)
                {
                    oldProviderContract.ProviderContractLobs.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                if (oldProviderContract.ProviderContractInterest.Count > 0)
                {
                    oldProviderContract.ProviderContractInterest.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                if (oldProviderContract.ProviderContractTimelyFiling.Count > 0)
                {
                    oldProviderContract.ProviderContractTimelyFiling.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                // Check exist record condition in group
                _ProviderContractService.CheckIfExistInGroup(oldProviderContract);
                if (!_ProviderContractService.BusinessState.IsValid)
                {
                    _ProviderContractService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderContractRepository.Update(oldProviderContract);

                if (!_ProviderContractRepository.DbState.IsValid)
                {
                    _ProviderContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                return Ok(model.ProviderContractID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Provider Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _ProviderContractRepository.DeleteById(id);
                if (!_ProviderContractRepository.DbState.IsValid)
                {
                    _ProviderContractRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider Contract : {ex}");
                return BadRequest(ex.Message);
            }
        }        
    }
}
