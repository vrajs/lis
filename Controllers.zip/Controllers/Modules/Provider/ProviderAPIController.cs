using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Business.Interfaces.Provider;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.View;
using Microsoft.AspNetCore.Authorization;
using Kwicle.Core.Entities.ProviderStructure;
using System.Net;
using Kwicle.Core.Entities.AlertStructure;
using Kwicle.Data.Contracts.Alert;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Web.Controllers.Modules.Provider
{
    [Route("api/Provider")]
    public class ProviderAPIController : BaseAPIController
    {
        private readonly IProviderRepository _IProviderRepository;
        private readonly IProviderLanguageRepository _IProviderLanguageRepository;
        private readonly IProviderEligibilityRepository _providerEligibilityRepository;
        private readonly IProviderService _IProviderService;
        private readonly IProviderEligibilityService _providerEligibilityService;
        private IMapper _mapper;
        private ILogger<ProviderAPIController> _logger;
        private readonly IViewRepository _ViewRepository;
        private readonly IProviderSpecialtyRepository _providerSpecialtyRepository;
        private readonly IProviderNoteRepository _providerNoteRepository;
        private readonly IProviderLocationRepository _providerLocationRepository;
        private readonly IProviderContractRepository _providerContractRepository;
        private readonly IProviderCodeRepository _providerCodeRepository;
        private readonly IAlertModuleRepository _alertModuleRepository;

        public ProviderAPIController(IProviderRepository IProviderRepository, IProviderLanguageRepository IProviderLanguageRepository, IProviderEligibilityRepository providerEligibilityRepository, IProviderService IProviderService, IProviderEligibilityService providerEligibilityService, IMapper mapper, ILogger<ProviderAPIController> logger, IViewRepository viewRepository, IProviderSpecialtyRepository providerSpecialtyRepository, IProviderNoteRepository providerNoteRepository, IProviderLocationRepository providerLocationRepository, IProviderContractRepository providerContractRepository, IProviderCodeRepository providerCodeRepository, IAlertModuleRepository alertModuleRepository)
        {
            _IProviderRepository = IProviderRepository;
            _mapper = mapper;
            _logger = logger;
            _IProviderService = IProviderService;
            _IProviderLanguageRepository = IProviderLanguageRepository;
            _providerEligibilityRepository = providerEligibilityRepository;
            _providerEligibilityService = providerEligibilityService;
            _ViewRepository = viewRepository;
            _providerSpecialtyRepository = providerSpecialtyRepository;
            _providerNoteRepository = providerNoteRepository;
            _providerLocationRepository = providerLocationRepository;
            _providerContractRepository = providerContractRepository;
            _providerCodeRepository = providerCodeRepository;
            _alertModuleRepository = alertModuleRepository;
        }


        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            var providerList = _IProviderRepository.GetByPredicate(null);
            return Ok(providerList.ToList());
        }

        [HttpGet("GetView/{id}")]
        public IActionResult GetView(int id)
        {
            try
            {
                var provider = _IProviderRepository.GetView(id);
                if (provider == null) return NotFound($"Provider with {id} was not found");
                return Ok(provider);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var provider = _IProviderRepository.GetById(id);
                //var provider = _IProviderRepository.GetByPredicate(x=>x.ProviderID==id);
                provider.ProviderLanguage = _IProviderLanguageRepository.GetByProviderID(id);
                //provider.ProviderEligibility = _providerEligibilityRepository.GetByProviderID(id);
                if (provider == null) return NotFound($"Provider with {id} was not found");
                return Ok(provider);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] ProviderViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Core.Entities.ProviderStructure.Provider entity = _mapper.Map<Core.Entities.ProviderStructure.Provider>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (int)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                if (entity.ProviderLanguage.Count > 0)
                {
                    entity.ProviderLanguage.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; x.RecordStatusChangeComment = RecordStatus.Active.ToString(); });
                }

                //var elModel = model.ProviderEligibility;
                //var eligibilityEntity = new ProviderEligibility();
                var eligibilityEntity = _mapper.Map<ProviderEligibility>(model.ProviderEligibility);

                eligibilityEntity.CreatedDate = base.TodaysDate;
                eligibilityEntity.CreatedBy = base.UserName;
                eligibilityEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, eligibilityEntity.EffectiveDate, eligibilityEntity.TermDate);
                eligibilityEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, eligibilityEntity.EffectiveDate, eligibilityEntity.TermDate).ToString();

                
                //if (eligibilityEntity.TermDate != null && eligibilityEntity.TermDate.Date != DateTime.MaxValue.Date)
                //{
                //    var TermDate = Convert.ToDateTime(eligibilityEntity.TermDate);
                //    if (eligibilityEntity.TermReasonId == null || eligibilityEntity.TermReasonId == 0)
                //    {
                //        return BadRequest("Plz Select Term Reason");
                //    }
                //}
                if ((!string.IsNullOrEmpty(entity.NPI)) && entity.IsPerson == true && entity.ProviderTypeID == (int)ProviderType.Provider)
                {
                    _IProviderService.checkProviderNPIValidity(entity.NPI);
                    if (!_IProviderService.BusinessState.IsValid)
                    {
                        _IProviderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                    }
                }

                _IProviderService.CheckIfExists(entity);
                if (!_IProviderService.BusinessState.IsValid)
                {
                    _IProviderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IProviderRepository.Add(entity);
                if (!_IProviderRepository.DbState.IsValid)
                {
                    _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        if (error.Value.Contains("duplicate"))
                        {
                            this.ModelState.AddModelError("Cannot Add Record", "Duplicate Record");
                        }
                        else
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        }
                    });
                    return BadRequest(this.ModelState);
                }

                eligibilityEntity.ProviderID = entity.ProviderID;
                _providerEligibilityRepository.Add(eligibilityEntity);
                if (!_providerEligibilityRepository.DbState.IsValid)
                {
                    _providerEligibilityRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                //if (eligibilityEntity.RecordStatus == (byte)RecordStatus.Active)
                //{
                entity.ProviderEligibilityID = eligibilityEntity.ProviderEligibilityID;
                _IProviderRepository.Update(entity);
                if (!_IProviderRepository.DbState.IsValid)
                {
                    _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                //}               

                var newUri = Url.Link("ProviderGet", new { id = entity.ProviderID });
                _logger.LogInformation("New Provider Created");
                //return Created(newUri, _mapper.Map<ProviderViewModel>(entity));
                return Created(newUri, new { entity.ProviderID, eligibilityEntity.ProviderEligibilityID });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5 int id, 
        //[HttpPut]
        //public IActionResult Put([FromBody]ProviderViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    try
        //    {
        //        Core.Entities.ProviderStructure.Provider entity = _IProviderRepository.GetById(model.ProviderID);
        //        _mapper.Map(model, entity);
        //        entity.UpdatedDate = base.TodaysDate;
        //        entity.UpdatedBy = base.UserName;
        //        entity.RecordStatusChangeComment = "Updated";

        //        if (entity.ProviderLanguage.Count > 0)
        //        {
        //            entity.ProviderLanguage.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; x.RecordStatusChangeComment = RecordStatus.Active.ToString(); });
        //        }

        //        #region Eligibility
        //        //if (model.ProviderEligibility != null)
        //        //{
        //        //    ProviderEligibility elModel = model.ProviderEligibility.Single();
        //        //    if (elModel.ProviderEligibilityID > 0)
        //        //    {
        //        //        var eligibilityEntity = _providerEligibilityRepository.GetById(elModel.ProviderEligibilityID);
        //        //        _mapper.Map(elModel, eligibilityEntity);

        //        //        eligibilityEntity.UpdatedBy = base.UserName;
        //        //        eligibilityEntity.UpdatedDate = base.TodaysDate;
        //        //        eligibilityEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, elModel.EffectiveDate, elModel.TermDate);
        //        //        eligibilityEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, elModel.EffectiveDate, elModel.TermDate).ToString();

        //        //        _providerEligibilityService.CheckIfExist(eligibilityEntity);
        //        //        if (!_providerEligibilityService.BusinessState.IsValid)
        //        //        {
        //        //            _providerEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
        //        //            {
        //        //                ModelState.AddModelError(businessState.Key, businessState.Value);
        //        //            });
        //        //            return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
        //        //        }
        //        //        _providerEligibilityRepository.Update(eligibilityEntity);
        //        //        if (!_providerEligibilityRepository.DbState.IsValid)
        //        //        {
        //        //            _providerEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
        //        //            {
        //        //                ModelState.AddModelError(businessState.Key, businessState.Value);
        //        //            });
        //        //            return BadRequest(ModelState);
        //        //        }
        //        //    }
        //        //    else
        //        //    {
        //        //        ProviderEligibility eligibilityEntity = _mapper.Map<ProviderEligibility>(elModel);
        //        //        eligibilityEntity.CreatedDate = base.TodaysDate;
        //        //        eligibilityEntity.CreatedBy = base.UserName;
        //        //        eligibilityEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, elModel.EffectiveDate, elModel.TermDate);
        //        //        eligibilityEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, elModel.EffectiveDate, elModel.TermDate).ToString();

        //        //        _providerEligibilityService.CheckIfExist(eligibilityEntity);
        //        //        if (!_providerEligibilityService.BusinessState.IsValid)
        //        //        {
        //        //            _providerEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
        //        //            {
        //        //                ModelState.AddModelError(businessState.Key, businessState.Value);
        //        //            });
        //        //            return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
        //        //        }

        //        //        _providerEligibilityRepository.Add(eligibilityEntity);
        //        //        if (!_providerEligibilityRepository.DbState.IsValid)
        //        //        {
        //        //            _providerEligibilityRepository.DbState.ErrorMessages.ForEach((error) =>
        //        //            {
        //        //                this.ModelState.AddModelError(error.Key, error.Value);
        //        //            });
        //        //            return BadRequest(this.ModelState);
        //        //        }

        //        //        if (eligibilityEntity.RecordStatus == (byte)RecordStatus.Active)
        //        //        {
        //        //            entity.ProviderEligibilityID = eligibilityEntity.ProviderEligibilityID;
        //        //        }
        //        //    }
        //        //}
        //        #endregion

        //        _IProviderRepository.Update(entity);
        //        if (!_IProviderRepository.DbState.IsValid)
        //        {
        //            _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
        //            {
        //                this.ModelState.AddModelError(error.Key, error.Value);
        //            });
        //            return BadRequest(this.ModelState);
        //        }                

        //        _logger.LogInformation("Provider Updated : {0}", entity.ProviderID);
        //        return Ok(entity.ProviderID);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError("Error while updating Provider : {0}", ex);
        //        return BadRequest(ex.Message);
        //    }
        //}

        [HttpPut]
        public IActionResult Put([FromBody] ProviderViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Core.Entities.ProviderStructure.Provider entity = _IProviderRepository.GetById(model.ProviderID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatusChangeComment = "Updated";

                var elModel = model.ProviderEligibility;
                var eligibilityEntity = new ProviderEligibility();
                if (elModel.ProviderEligibilityID > 0)
                {
                    eligibilityEntity = _providerEligibilityRepository.GetById(elModel.ProviderEligibilityID);
                    _mapper.Map(elModel, eligibilityEntity);
                    eligibilityEntity.UpdatedBy = base.UserName;
                    eligibilityEntity.UpdatedDate = base.TodaysDate;
                    eligibilityEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, eligibilityEntity.EffectiveDate, eligibilityEntity.TermDate);
                    eligibilityEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, eligibilityEntity.EffectiveDate, eligibilityEntity.TermDate).ToString();
                }
                else
                {
                    eligibilityEntity = _mapper.Map<ProviderEligibility>(elModel);
                    eligibilityEntity.CreatedDate = base.TodaysDate;
                    eligibilityEntity.CreatedBy = base.UserName;
                    eligibilityEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, eligibilityEntity.EffectiveDate, eligibilityEntity.TermDate);
                    eligibilityEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, eligibilityEntity.EffectiveDate, eligibilityEntity.TermDate).ToString();
                    eligibilityEntity.ProviderID = entity.ProviderID;
                }
                //if (eligibilityEntity.TermDate != null && eligibilityEntity.TermDate.Date != DateTime.MaxValue.Date)
                //{
                //    var TermDate = Convert.ToDateTime(eligibilityEntity.TermDate);
                //    if (eligibilityEntity.TermReasonId == null || eligibilityEntity.TermReasonId == 0)
                //    {
                //        return BadRequest("Plz Select Term Reason");
                //    }
                //}
                _providerEligibilityService.CheckIfExist(eligibilityEntity, true);
                if (!_providerEligibilityService.BusinessState.IsValid)
                {
                    _providerEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                var existedLang = _IProviderLanguageRepository.GetLangByProviderId(model.ProviderID);
                if (entity.ProviderLanguage.Count > 0)
                {
                    var commonLang = (from inlang in existedLang
                                      join entty in model.ProviderLanguage on inlang.LanguageID equals entty.LanguageID
                                      select inlang.LanguageID).ToList();
                    foreach (var lang in commonLang)
                    {
                        var item = entity.ProviderLanguage.Where(x => x.LanguageID == lang && x.ProviderLanguageID == 0).FirstOrDefault();
                        entity.ProviderLanguage.Remove(item);
                    }
                    var notCommonLang = (from inlang in existedLang
                                         where !commonLang.Contains(inlang.LanguageID)
                                         select inlang.LanguageID).ToList();
                    foreach (var lang in notCommonLang)
                    {
                        var item = entity.ProviderLanguage.Where(x => x.LanguageID == lang && x.ProviderLanguageID != 0).FirstOrDefault();//.RecordStatus=3;
                        if (item != null)
                        {
                            item.RecordStatus = (byte)RecordStatus.Deleted;
                            item.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                            item.UpdatedBy = base.UserName;
                            item.UpdatedDate = base.TodaysDate;
                        }
                    }
                    entity.ProviderLanguage.Where(x => x.RecordStatus == 0).ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; x.RecordStatusChangeComment = RecordStatus.Active.ToString(); });
                }

                _IProviderRepository.Update(entity);
                if (!_IProviderRepository.DbState.IsValid)
                {
                    _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                #region Eligibility
                if (elModel.ProviderEligibilityID > 0)
                {
                    _providerEligibilityRepository.Update(eligibilityEntity);
                    if (!_providerEligibilityRepository.DbState.IsValid)
                    {
                        _providerEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                }
                else
                {
                    _providerEligibilityRepository.Add(eligibilityEntity);
                    if (!_providerEligibilityRepository.DbState.IsValid)
                    {
                        _providerEligibilityRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    if (eligibilityEntity.RecordStatus == (byte)RecordStatus.Active)
                    {
                        entity.ProviderEligibilityID = eligibilityEntity.ProviderEligibilityID;

                        _IProviderRepository.Update(entity);
                        if (!_IProviderRepository.DbState.IsValid)
                        {
                            _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }
                #endregion

                _logger.LogInformation("Provider Updated : {0}", entity.ProviderID);
                return Ok(new { entity.ProviderID, entity.ProviderEligibilityID });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Provider : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IProviderRepository.DeleteById(id);
                if (!_IProviderRepository.DbState.IsValid)
                {
                    _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing provider : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderLocation/{ProviderID}")]
        public IActionResult GetProviderLocation(int ProviderID)
        {
            var list = _IProviderRepository.GetProviderLocation(ProviderID);
            if (list == null) return NotFound($"Provider location was not found");
            return Ok(list);
        }

        [HttpGet]
        [Route("GetProviderContract/{ProviderID}")]
        public IActionResult GetProviderContract(int ProviderID)
        {
            var list = _IProviderRepository.GetProviderContract(ProviderID);
            if (list == null) return NotFound($"Provider contract was not found");
            return Ok(list);
        }

        [HttpGet]
        [Route("CheckProviderData/{identifierTypeID}/{identifierCode}")]
        public IActionResult CheckProviderData(int identifierTypeID, string identifierCode)
        {
            try
            {
                var query = _IProviderRepository.CheckProviderData(identifierTypeID, identifierCode);
                return Ok(query.AsQueryable().Cast<object>().Any());
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while fetching data : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetClaimProvider")]
        public IActionResult GetClaimProvider(string SearchText, DateTime ClaimDOSFrom, DateTime ClaimDOSTo)
        {
            try
            {
                List<ProviderLookupModel> providers = _ViewRepository.ProviderLookups.Where(e =>
                                                        (ClaimDOSFrom >= e.EffectiveDate && ClaimDOSTo <= e.TermDate
                                                         && ClaimDOSFrom >= e.PREffectiveDate && ClaimDOSTo <= e.PRTermDate
                                                         && ClaimDOSFrom >= e.GroupEffectiveDate && ClaimDOSTo <= e.GroupTermDate
                                                         && (e.ProviderCode.ToLower() == SearchText.ToLower() || e.ProviderName.ToLower() == SearchText.ToLower() || e.ProviderNPI.ToLower() == SearchText.ToLower())
                                                        )
                                                        ||
                                                        ((e.ProviderCode.ToLower() == SearchText.ToLower() || e.ProviderName.ToLower() == SearchText.ToLower() || e.ProviderNPI.ToLower() == SearchText.ToLower())
                                                          && (e.ProviderEligibilityID == null || e.ProviderRelationID == null || e.GroupEligibilityID == null))
                                                        ).ToList();
                return Ok(providers);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetClaimFacility")]
        public IActionResult GetClaimFacility(string SearchText, DateTime ClaimDOSFrom, DateTime ClaimDOSTo)
        {
            try
            {
                List<vwFacilityLookup> facilitys = _ViewRepository.FacilityLookups.Where(e =>
                                         (ClaimDOSFrom >= e.EffectiveDate && ClaimDOSTo <= e.TermDate && ClaimDOSFrom >= e.PREffectiveDate && ClaimDOSTo <= e.PRTermDate && ClaimDOSFrom >= e.GroupEffectiveDate && ClaimDOSTo <= e.GroupTermDate && (e.FacilityCode.ToLower() == SearchText.ToLower() || e.FacilityName.ToLower() == SearchText.ToLower() || e.FacilityNPI.ToLower() == SearchText.ToLower()))
                                         ||
                                         ((e.FacilityCode.ToLower() == SearchText.ToLower() || e.FacilityName.ToLower() == SearchText.ToLower() || e.FacilityNPI.ToLower() == SearchText.ToLower()) && (!e.FacilityEligibilityID.HasValue || !e.GroupEligibilityID.HasValue || !e.ProviderRelationID.HasValue))).ToList();
                return Ok(facilitys);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("GetDataFromNPPES")]
        public IActionResult GetDataFromNPPES(NPPESRequestParam model)
        {
            try
            {
                var result = _IProviderService.GetDataFromNPPES(model);
                if (result.result_count > 0)
                {
                    return Ok(_mapper.Map<Core.Entities.ProviderStructure.Provider>(result));
                }
                return Ok(new Core.Entities.ProviderStructure.Provider());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("CheckProviderConfigurationHasData/{providerID}")]
        public IActionResult CheckProviderConfigurationHasData(int providerID)
        {
            var res = _IProviderRepository.CheckProviderConfigurationHasData(providerID);
            return Ok(res);
        }

        [HttpGet]
        [Route("CheckGroupConfigurationHasData/{providerID}")]
        public IActionResult CheckGroupConfigurationHasData(int providerID)
        {
            var res = _IProviderRepository.CheckGroupConfigurationHasData(providerID);
            return Ok(res);
        }

        [HttpGet]
        [Route("CreateGroupFromProvider/{providerID}")]
        public IActionResult CreateGroupFromProvider(int providerID)
        {
            //var result = _IProviderRepository.CreateGroupFromProvider(providerID);
            var objProvider = _IProviderRepository.GetById(providerID);
            Core.Entities.ProviderStructure.Provider groupProvider = new Core.Entities.ProviderStructure.Provider();
            if (objProvider != null)
            {
                //                groupProvider = objProvider;
                //               groupProvider.ProviderID = 0;
                groupProvider.ProviderTypeID = (int)GroupType.Group;
                //                groupProvider.UpdatedBy = null;
                //                groupProvider.UpdatedDate = null;

                groupProvider.ProviderCode = DateTime.Now.ToString("yyMMddHHmmss");
                groupProvider.ProviderEligibilityID = objProvider.ProviderEligibilityID;
                groupProvider.LastName = objProvider.LastName;
                groupProvider.NPI = objProvider.NPI;
                groupProvider.PrimaryEmail = objProvider.PrimaryEmail;
                groupProvider.SecondaryEmail = objProvider.SecondaryEmail;
                groupProvider.Phone = objProvider.Phone;
                groupProvider.Fax = objProvider.Fax;
                groupProvider.CreatedDate = base.TodaysDate;
                groupProvider.CreatedBy = base.UserName;
                groupProvider.RecordStatus = (byte)RecordStatus.Active;
                groupProvider.RecordStatusChangeComment = RecordStatus.Active.ToString();
                groupProvider.Ethnicity = string.Empty;
                groupProvider.Fax = string.Empty;
                groupProvider.FirstName = string.Empty;
                groupProvider.Gender = string.Empty;
                groupProvider.IsFreezed = (byte)0;
                groupProvider.IsPCP = false;
                groupProvider.IsPerson = false;
                groupProvider.IsProviderWatch = false;
                groupProvider.IsSpecialist = false;
                groupProvider.MaxMemberCount = (short)0;
                groupProvider.MiddleName = string.Empty;
                groupProvider.Prefix = string.Empty;
                groupProvider.Race = string.Empty;
                groupProvider.SSN = string.Empty;
                groupProvider.Suffix = string.Empty;
                groupProvider.Title = string.Empty;


                _IProviderRepository.Add(groupProvider);
                if (!_IProviderRepository.DbState.IsValid)
                {
                    _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        if (error.Value.Contains("duplicate"))
                        {
                            this.ModelState.AddModelError("Cannot Add Record", "This group already exists");
                        }
                        else
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        }
                    });
                    return BadRequest(this.ModelState);
                }


                //provider eligibiliy
                var providerEligibilityList = _providerEligibilityRepository.GetByPredicate(x => x.ProviderID == providerID).ToList();
                if (providerEligibilityList != null)
                {
                    foreach (var obj in providerEligibilityList)
                    {
                        ProviderEligibility newObj = new ProviderEligibility();
                        newObj.ProviderEligibilityID = 0;
                        newObj.ProviderID = groupProvider.ProviderID;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.ProviderEligibilityCode = obj.ProviderEligibilityCode;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.TermDate = obj.TermDate;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        _providerEligibilityRepository.Add(newObj);
                        if (!_providerEligibilityRepository.DbState.IsValid)
                        {
                            _providerEligibilityRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }

                        //Update provider
                        if (objProvider.ProviderEligibilityID == obj.ProviderEligibilityID)
                        {
                            groupProvider.ProviderEligibilityID = newObj.ProviderEligibilityID;

                            _IProviderRepository.Update(groupProvider);
                            if (!_IProviderRepository.DbState.IsValid)
                            {
                                _IProviderRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                    }
                }

                //provider specialty
                var providerSpecialtyList = _providerSpecialtyRepository.GetByPredicate(x => x.ProviderID == providerID).ToList();
                if (providerSpecialtyList != null)
                {
                    foreach (var obj in providerSpecialtyList)
                    {
                        ProviderSpecialty newObj = new ProviderSpecialty();
                        //newObj = obj;
                        newObj.ProviderSpecialtyID = 0;
                        newObj.ProviderID = groupProvider.ProviderID;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.IsFreezed = obj.IsFreezed;
                        newObj.IsPrimarySpecialty = obj.IsPrimarySpecialty;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.SpecialtyID = obj.SpecialtyID;
                        newObj.TermDate = obj.TermDate;

                        _providerSpecialtyRepository.Add(newObj);
                        if (!_providerSpecialtyRepository.DbState.IsValid)
                        {
                            _providerSpecialtyRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }


                //Reference
                var providerCodeList = _providerCodeRepository.GetByPredicate(x => x.ProviderID == providerID).ToList();
                if (providerCodeList != null)
                {
                    foreach (var obj in providerCodeList)
                    {
                        ProviderCode newObj = new ProviderCode();
                        //newObj = obj;
                        newObj.ProviderCodeID = 0;
                        newObj.ProviderID = groupProvider.ProviderID;
                        newObj.CodeName = obj.CodeName;
                        newObj.CodeTypeID = obj.CodeTypeID;
                        newObj.CodeValue = obj.CodeValue;
                        newObj.ControlTypeID = obj.ControlTypeID;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.IsFreezed = obj.IsFreezed;
                        newObj.ProviderID = obj.ProviderID;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.TermDate = obj.TermDate;

                        _providerCodeRepository.Add(newObj);
                        if (!_providerCodeRepository.DbState.IsValid)
                        {
                            _providerCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }

                // Alert
                var providerAlertList = _alertModuleRepository.GetByPredicate(x => x.AlertDataID == providerID && x.SourceModuleID == 804).ToList();
                if (providerAlertList != null)
                {
                    foreach (var obj in providerAlertList)
                    {
                        AlertModule newObj = new AlertModule();
                        //newObj = obj;
                        newObj.AlertModuleID = 0;
                        newObj.AlertDataID = groupProvider.ProviderID;
                        newObj.SourceModuleID = obj.SourceModuleID;
                        newObj.AddedSource = obj.AddedSource;
                        newObj.AlertCode = obj.AlertCode;
                        newObj.AlertCodeID = obj.AlertCodeID;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        newObj.DestinationModuleID = obj.DestinationModuleID;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.IsFreezed = obj.IsFreezed;
                        newObj.LoadComment = obj.LoadComment;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.TermDate = obj.TermDate;


                        _alertModuleRepository.Add(newObj);
                        if (!_alertModuleRepository.DbState.IsValid)
                        {
                            _alertModuleRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }
                //provider Note
                var providerNoteList = _providerNoteRepository.GetByPredicate(x => x.ProviderID == providerID).ToList();
                if (providerNoteList != null)
                {
                    foreach (var obj in providerNoteList)
                    {
                        ProviderNote newObj = new ProviderNote();
                        //newObj = obj;
                        newObj.ProviderNoteID = 0;
                        newObj.ProviderID = groupProvider.ProviderID;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.IsFreezed = obj.IsFreezed;
                        newObj.LongDescription = obj.LongDescription;
                        newObj.NoteDate = obj.NoteDate;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.ShortDescription = obj.ShortDescription;
                        newObj.TermDate = obj.TermDate;


                        _providerNoteRepository.Add(newObj);
                        if (!_providerNoteRepository.DbState.IsValid)
                        {
                            _providerNoteRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }


                //Provider location
                var providerLocationList = _providerLocationRepository.GetByPredicate(x => x.ProviderID == providerID).ToList();
                if (providerLocationList != null)
                {
                    foreach (var obj in providerLocationList)
                    {
                        ProviderLocation newObj = new ProviderLocation();
                        //newObj = obj;
                        newObj.ProviderLocationID = 0;
                        newObj.ProviderID = groupProvider.ProviderID;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.GroupID = obj.GroupID;
                        newObj.IsFreezed = obj.IsFreezed;
                        newObj.LocationID = obj.LocationID;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.TermDate = obj.TermDate;


                        _providerLocationRepository.Add(newObj);
                        if (!_providerLocationRepository.DbState.IsValid)
                        {
                            _providerLocationRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }

                //Provider Contract
                var providerContractList = _providerContractRepository.GetByPredicate(x => x.ProviderID == providerID).ToList();
                if (providerContractList != null)
                {
                    foreach (var obj in providerContractList)
                    {
                        ProviderContract newObj = new ProviderContract();
                        //newObj = obj;
                        newObj.ProviderContractID = 0;
                        newObj.ProviderID = groupProvider.ProviderID;
                        newObj.ContractHeaderID = obj.ContractHeaderID;
                        newObj.CreatedBy = base.UserName;
                        newObj.CreatedDate = base.TodaysDate;
                        newObj.EffectiveDate = obj.EffectiveDate;
                        newObj.FeeScheduleHeaderID = obj.FeeScheduleHeaderID;
                        newObj.IsCapitated = obj.IsCapitated;
                        newObj.IsExcludeFromSequestration = obj.IsExcludeFromSequestration;
                        newObj.IsFreezed = obj.IsFreezed;
                        newObj.ModifierDiscountGroupID = obj.ModifierDiscountGroupID;
                        newObj.NetworkID = obj.NetworkID;
                        newObj.ProviderStatusID = obj.ProviderStatusID;
                        newObj.RecordStatus = obj.RecordStatus;
                        newObj.RecordStatusChangeComment = obj.RecordStatusChangeComment;
                        newObj.TermDate = obj.TermDate;

                        _providerContractRepository.Add(newObj);
                        if (!_providerContractRepository.DbState.IsValid)
                        {
                            _providerContractRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }
            }
            return Ok(new { groupProvider.ProviderID, groupProvider.ProviderEligibilityID });
        }
    }
}
