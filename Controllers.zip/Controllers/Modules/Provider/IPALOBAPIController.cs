using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/IPALOB")]
    public class IPALOBAPIController : BaseAPIController
    {
        private readonly IIPALOBRepository _IIPALOBRepository;
        private readonly ILogger<IPALOBAPIController> _logger;
        private readonly IIPALOBService _IIPALOBService;
        private IMapper _mapper;
        public IPALOBAPIController(IIPALOBRepository IIPALOBRepository, ILogger<IPALOBAPIController> logger, IMapper mapper, IIPALOBService IIPALOBService)
        {
            _IIPALOBRepository = IIPALOBRepository;
            _logger = logger;
            _mapper = mapper;
            _IIPALOBService = IIPALOBService;
        }

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var ipaLobResult = _IIPALOBRepository.GetByPredicate(null);
                return Ok(ipaLobResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all ipaLob list: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "IPALOBGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var ipaLob = _IIPALOBRepository.GetById(id);
                if (ipaLob == null) return NotFound($"IpaLob {id} was not found");
                return Ok(_mapper.Map<IPALOBModel>(ipaLob));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} IpaLob: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetIpaLobByIPAID/{ipaID}")]
        public IActionResult GetIpaLobByIPAID(int ipaID)
        {
            try
            {
                var ipaLobList = _IIPALOBRepository.GetIpaLobByIPAID(ipaID).ToList();
                if (ipaLobList == null) return NotFound($"Ipa Lob list was not found");
                return Ok(ipaLobList);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Ipa Lob list: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]IPALOBModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var ipaLob = _mapper.Map<IPALOB>(model);
                ipaLob.CreatedDate = base.TodaysDate;
                ipaLob.CreatedBy = base.UserName;
                ipaLob.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, ipaLob.EffectiveDate, ipaLob.TermDate);
                ipaLob.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, ipaLob.EffectiveDate, ipaLob.TermDate).ToString();

                _IIPALOBService.CheckIfExist(ipaLob);
                if (!_IIPALOBService.BusinessState.IsValid)
                {
                    _IIPALOBService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }


                _IIPALOBRepository.Add(ipaLob);
                if (!_IIPALOBRepository.DbState.IsValid)
                {
                    _IIPALOBRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("IPALOBGet", new { id = ipaLob.IPALOBID });
                _logger.LogInformation("New Ipa Lob Created ");
                return Created(newUri, _mapper.Map<IPALOBModel>(ipaLob));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Ipa Lob : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]IPALOBModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IIPALOBRepository.GetById(model.IPALOBID);
                if (entity == null) return NotFound($"Could not find Lob with an IPA of {model.IPALOBID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IIPALOBRepository.Update(entity);
                if (!_IIPALOBRepository.DbState.IsValid)
                {
                    _IIPALOBRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Ipa Lob updated  : {0}", entity.IPALOBID);
                return Ok(entity.IPALOBID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Ipa Lob :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IIPALOBRepository.DeleteById(id);
                if (!_IIPALOBRepository.DbState.IsValid)
                {
                    _IIPALOBRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Ipa Lob : {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
