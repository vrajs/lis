using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Data.Contracts.View;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("odata")]
    public class ProviderODController : BaseODController
    {
        #region Property        
        private IProviderRepository _IProviderRepository;
        private IProviderLanguageRepository _IProviderLanguageRepository;
        private IViewRepository _IViewRepository;
        private IProviderRelationRepository _IProviderRelationRepository;
        private readonly IProviderSpecialtyRepository _ProviderSpecialtyRepository;
        byte activeStatus = (byte)RecordStatus.Active;
        byte termedStatus = (byte)RecordStatus.Termed;
        byte inActiveStatus = (byte)RecordStatus.InActive;
        byte deletedStatus = (byte)RecordStatus.Deleted;
        #endregion

        #region Constructor        
        public ProviderODController(IProviderRepository providerRepository, IViewRepository viewRepository, IProviderRelationRepository providerRelationRepository, IProviderLanguageRepository providerLanguageRepository,
            IProviderSpecialtyRepository providerSpecialtyRepository)
        {
            _IProviderRepository = providerRepository;
            _IViewRepository = viewRepository;
            _IProviderRelationRepository = providerRelationRepository;
            _IProviderLanguageRepository = providerLanguageRepository;
            _ProviderSpecialtyRepository = providerSpecialtyRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimReferringPhysicians")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimReferringPhysicians()
        {
            var query = _IProviderRepository.GetClaimReferringPhysician();
            return Ok(query);
        }


        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Providers")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetProviders(byte filterStatus, string advancefilters)
        {
            ProviderSearchModel providerFilter = JsonConvert.DeserializeObject<ProviderSearchModel>(advancefilters);
          
            // For multiple specilty
            List<int> specialityset = new List<int>();
            if (!(string.IsNullOrEmpty(providerFilter.SpecialtyIDs)))
            {
                specialityset = providerFilter.SpecialtyIDs.Split(',').Select(Int32.Parse).ToList();
            }

            // For multiple language
            List<int> lanagaugeset = new List<int>();
            if (!(string.IsNullOrEmpty(providerFilter.LanguageIDs)))
            {
                lanagaugeset = providerFilter.LanguageIDs.Split(',').Select(Int32.Parse).ToList();
            }

            IQueryable<vwProviderList> providerListQuery = null;

            if (filterStatus == (byte)FilterStatus.Active)
            {               
                providerListQuery = _IProviderRepository.GetProviders().Where(x => x.RecordStatus == activeStatus);
            }
            else if (filterStatus == (byte)FilterStatus.All)
            {             
                providerListQuery = _IProviderRepository.GetProviders().Where(x => x.RecordStatus != deletedStatus);
            }

            providerListQuery = providerListQuery.Where(x => providerFilter.ProviderTypeIDs.Contains(x.ProviderTypeID));
            // filter over tin
            if (providerFilter.TINNumber.HasValue)
            {
                if (!providerFilter.ProviderTypeIDs.Any(i => i == (int)GroupType.Group))
                {
                    
                    providerListQuery = _IProviderRepository.GetProviderRelation().Where(x => x.RecordStatus == activeStatus && x.TINNumber.ToString().Contains(providerFilter.TINNumber.ToString())).Select(s => new vwProviderList
                    {
                        ProviderID = s.ProviderID,
                        ProviderCode = s.ProviderCode,
                        FirstName = s.FirstName,
                        FullName = s.FullName,
                        DOB = s.DOB,
                        Gender = s.Gender,
                        SSN = s.SSN,
                        NPI = s.NPI,
                        Phone = s.Phone,
                        Fax = s.Fax,
                        PrimaryEmail = s.PrimaryEmail,
                        TINNumber = s.TINNumber
                    });

                }
                else
                {
                    providerListQuery = providerListQuery.Where(x => x.TINNumber.ToString().Contains(providerFilter.TINNumber.ToString()));
                }
            }

            if (!string.IsNullOrEmpty(providerFilter.FullName))
            {
                providerListQuery = providerListQuery.Where(i => i.FullName.Contains(providerFilter.FullName) || i.FirstName.Contains(providerFilter.FullName) || i.LastName.Contains(providerFilter.FullName));
            }

            if (!string.IsNullOrEmpty(providerFilter.NPI))
            {
                providerListQuery = providerListQuery.Where(i => i.NPI.Contains(providerFilter.NPI));
            }

            if (!string.IsNullOrEmpty(providerFilter.ProviderCode))
            {
                providerListQuery = providerListQuery.Where(i => i.ProviderCode.Contains(providerFilter.ProviderCode));
            }
            //Get Provider's which has specialityset
            // filter over specilty
            List<int> providerIds = new List<int>();
            if (specialityset.Count > 0 && !specialityset.Contains(0))
            {
                var specialtyProviderIds = _ProviderSpecialtyRepository.GetByPredicate(i => specialityset.Contains(i.SpecialtyID)).GroupBy(x => x.ProviderID).Select(x => x.Key).ToList();
                providerIds.AddRange(specialtyProviderIds);
                
            }

            // filter over language
            if (lanagaugeset.Count > 0 && !lanagaugeset.Contains(0))
            {
                var languageProviderIds = _IProviderLanguageRepository.GetByPredicate(i => lanagaugeset.Contains(i.LanguageID)).GroupBy(x => x.ProviderID).Select(x => x.Key).ToList();
                providerIds.AddRange(languageProviderIds);
            }

            if (Convert.ToBoolean(providerIds.Count))
            {
                var providerIdsFilter = providerIds.Distinct();
                providerListQuery = providerListQuery.Where(r => providerIdsFilter.Contains(r.ProviderID));
            }
            

            //var data = providerListQuery.GroupBy(x => new  {  x.ProviderID,  x.ProviderCode,  x.FirstName,  x.FullName, x.DOB,  x.Gender,  x.SSN,  x.NPI,  x.Phone,  x.Fax, x.PrimaryEmail,  x.TINNumber})
            ////{ x.ProviderID, x.ProviderTypeID, x.ProviderCode, x.Title, x.FirstName, x.MiddleName, x.LastName, x.Suffix, x.FullName, x.DOB, x.Gender, x.SSN, x.NPI, x.Phone, x.Fax, x.PrimaryEmail, x.SecondaryEmail, x.CredentialStatusID, x.IsPCP, x.IsSpecialist, x.IsProviderWatch, x.IsPerson, x.Race, x.Ethnicity, x.MaxMemberCount, x.ProviderEligibilityID, x.RecordStatus, x.TINNumber })
            //    .Select(x => new vwProvider
            //    {
            //        ProviderID = x.Key.ProviderID,
            //        ProviderCode = x.Key.ProviderCode,
            //        FirstName = x.Key.FirstName,
            //        FullName = x.Key.FullName,
            //        DOB = x.Key.DOB,
            //        Gender = x.Key.Gender,
            //        SSN = x.Key.SSN,
            //        NPI = x.Key.NPI,
            //        Phone = x.Key.Phone,
            //        Fax = x.Key.Fax,
            //        PrimaryEmail = x.Key.PrimaryEmail,
            //        TINNumber = x.Key.TINNumber,
            //        //Languages = string.Join(",", x.Select(y => !string.IsNullOrEmpty(y.Language) ? y.Language : "")),
            //        //SpecialtyNames = string.Join(",", x.Select(y => !string.IsNullOrEmpty(y.SpecialtyName) ? y.SpecialtyName : "")),
            //        //Language = "",
            //        //CredentialStatusID = 0,
            //        //Ethnicity = "",                 
            //        //IsPCP = false,
            //        //IsPerson = false,
            //        //IsProviderWatch = false,
            //        //IsSpecialist = false,
            //        //LastName = "",
            //        //MaxMemberCount =0,
            //        //MiddleName = "",
            //        //ProviderEligibilityID = 0,
            //        //ProviderLanguageID = 0,
            //        //ProviderSpecialtyID = 0,
            //        //Race = "",
            //        //RecordStatus = x.Key.RecordStatus,
            //        //SecondaryEmail = "",
            //        //SpecialtyName = "",
            //        //Suffix = "",
            //        //Title =""
            //    });

            ////var list = data.ToList();
            //var data = from n in providerListQuery
            //           select n;
            return Ok(providerListQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BindProviders")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult BindProviders(int filterStatus, string providerTypeIDs)
        {
            IQueryable<vwProviderList> providerListQuery = null;
            List<int> providerTypeSet = new List<int>();
            if (!(string.IsNullOrEmpty(providerTypeIDs)))
            {
                providerTypeSet = providerTypeIDs.Split(',').Select(Int32.Parse).ToList();
            }
            if (filterStatus == (int)FilterStatus.Active)
            {
                providerListQuery = _IProviderRepository.GetProviders().Where(x => x.RecordStatus == activeStatus);
            }
            else if (filterStatus == (int)FilterStatus.All)
            {
                providerListQuery = _IProviderRepository.GetProviders().Where(x => (x.RecordStatus == activeStatus || x.RecordStatus ==termedStatus || x.RecordStatus == inActiveStatus));
            }
            if (providerTypeSet.Count > 0)
            {
                providerListQuery = providerListQuery.Where(y => providerTypeSet.Contains(y.ProviderTypeID));
            }

            //var data = from x in providerListQuery
            //               //.GroupBy(x => new { x.ProviderID, x.ProviderCode, x.FirstName, x.FullName, x.DOB, x.Gender, x.SSN, x.NPI, x.Phone, x.Fax, x.PrimaryEmail, x.TINNumber, x.LastName, x.Title })
            //           group x by new { x.ProviderID, x.ProviderCode, x.FirstName, x.FullName, x.DOB, x.Gender, x.SSN, x.NPI, x.Phone, x.Fax, x.PrimaryEmail, x.TINNumber, x.LastName, x.Title, x.Language } into x
            //           //join lang in (from y in _IProviderLanguageRepository.GetByPredicate(null)
            //           //              group y by y.ProviderID into g
            //           //              select new
            //           //              {
            //           //                  ProviderID = g.Key,
            //           //                  Language = string.Join(",", g.Select(a => a.Language))
            //           //              }) on x.Key.ProviderID equals lang.ProviderID into langdata
            //           //from lang in langdata.DefaultIfEmpty()                       
            //           select new vwProvider
            //           {
            //               ProviderID = x.Key.ProviderID,
            //               ProviderCode = x.Key.ProviderCode,
            //               FirstName = x.Key.FirstName,
            //               LastName = x.Key.LastName != null ? x.Key.LastName : string.Empty,
            //               Title = x.Key.Title,
            //               FullName = x.Key.FullName,
            //               DOB = x.Key.DOB,
            //               Gender = x.Key.Gender,
            //               SSN = x.Key.SSN,
            //               NPI = x.Key.NPI,
            //               Phone = x.Key.Phone,
            //               Fax = x.Key.Fax,
            //               PrimaryEmail = x.Key.PrimaryEmail,
            //               TINNumber = x.Key.TINNumber,
            //               //Languages = lang != null ? lang.Language : string.Empty
            //               Languages = string.Join(",", x.Select(y => !string.IsNullOrEmpty(y.Language) ? y.Language : null))
            //               //SpecialtyNames = string.Join(",", x.Select(y => !string.IsNullOrEmpty(y.SpecialtyName) ? y.SpecialtyName : null)),                    
            //           };

            return Ok(providerListQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ProviderLookup")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetProviderLookup(DateTime? ClaimDOSFrom, DateTime? ClaimDOSTo)
        {
            IQueryable<ProviderLookupModel> query;
            if (ClaimDOSFrom != null && ClaimDOSTo != null)
                query = _IViewRepository.ProviderLookups.Where(e => (ClaimDOSFrom >= e.EffectiveDate && ClaimDOSTo <= e.TermDate && ClaimDOSFrom >= e.PREffectiveDate && ClaimDOSTo <= e.PRTermDate && ClaimDOSFrom >= e.GroupEffectiveDate && ClaimDOSTo <= e.GroupTermDate) || (e.ProviderEligibilityID == null || e.GroupID == null || e.ProviderRelationID == null || e.GroupEligibilityID == null)).AsQueryable();
            else
                query = _IViewRepository.ProviderLookups.AsQueryable();

            return Ok(query);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("FacilityLookUp")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetFacilityLookUp(DateTime? ClaimDOSFrom, DateTime? ClaimDOSTo)
        {
            IQueryable<vwFacilityLookup> query;
            if (ClaimDOSFrom != null && ClaimDOSTo != null)
                query = _IViewRepository.FacilityLookups.Where(e =>
                                         (ClaimDOSFrom >= e.EffectiveDate && ClaimDOSTo <= e.TermDate && ClaimDOSFrom >= e.PREffectiveDate && ClaimDOSTo <= e.PRTermDate && ClaimDOSFrom >= e.GroupEffectiveDate && ClaimDOSTo <= e.GroupTermDate)
                                         ||
                                         (!e.FacilityEligibilityID.HasValue || !e.GroupEligibilityID.HasValue || !e.ProviderRelationID.HasValue)).AsQueryable();
            else
                query = _IViewRepository.FacilityLookups.AsQueryable();

            return Ok(query);
        }
    }
}
