using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderNote")]
    public class ProviderNoteAPIController : BaseAPIController
    {
        private readonly IProviderNoteRepository _IProviderNoteRepository;
        private IMapper _mapper;
        private ILogger<ProviderNoteAPIController> _logger;

        public ProviderNoteAPIController(IProviderNoteRepository IProviderNoteRepository, IMapper mapper, ILogger<ProviderNoteAPIController> logger)
        {
            _IProviderNoteRepository = IProviderNoteRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet("GetByProvider/{providerID}")]
        public IActionResult GetByProvider(int providerID)
        {
            try
            {
                var providerNotes = (from n in _IProviderNoteRepository.GetByPredicate(i => i.ProviderID == providerID)
                                     select n).OrderByDescending(x=>x.TermDate).ToList();
                return Ok(_mapper.Map<List<ProviderNoteModel>>(providerNotes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Provider Notes {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}", Name = "ProviderNoteGet")]
        public IActionResult Get(int id)
        {
            try
            {
                ProviderNote providerNote = _IProviderNoteRepository.GetById(id);
                if (providerNote == null) return NotFound($"Provider Note {id} was not found");
                return Ok(_mapper.Map<ProviderNoteModel>(providerNote));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderNoteModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ProviderNote entity = _mapper.Map<ProviderNote>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderNoteRepository.Add(entity);
                if (!_IProviderNoteRepository.DbState.IsValid)
                {
                    _IProviderNoteRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("ProviderNoteGet", new { id = entity.ProviderNoteID });
                _logger.LogInformation("Provider Note Created ");
                return Created(newUri, _mapper.Map<ProviderNoteModel>(entity));

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider Note : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody] ProviderNoteModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IProviderNoteRepository.GetById(model.ProviderNoteID);
                if (entity == null) return NotFound($"Could not find provider note with a ProviderID of {model.ProviderID}");

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderNoteRepository.Update(entity);
                if (!_IProviderNoteRepository.DbState.IsValid)
                {
                    _IProviderNoteRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider Note updated  : {0}", entity.ProviderNoteID);
                return Ok(model.ProviderNoteID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider Note :{ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IProviderNoteRepository.DeleteById(id);
                if (!_IProviderNoteRepository.DbState.IsValid)
                {
                    _IProviderNoteRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing provider note : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
