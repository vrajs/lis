using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.Common;
using Kwicle.Common.Utility;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/GroupProviderContract")]
    public class GroupProviderContractAPIController : BaseAPIController
    {
        private readonly IGroupProviderContractRepository _IGroupProviderContractRepository;
        private readonly IGroupProviderContractService _IGroupProviderContractService;
        private IMapper _mapper;
        private ILogger<GroupProviderContractAPIController> _logger;

        public GroupProviderContractAPIController(IGroupProviderContractRepository IGroupProviderContractRepository, IGroupProviderContractService IGroupProviderContractService, IMapper mapper, ILogger<GroupProviderContractAPIController> logger)
        {
            _IGroupProviderContractRepository = IGroupProviderContractRepository;
            _IGroupProviderContractService = IGroupProviderContractService;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var result = _IGroupProviderContractRepository.GetByPredicate(null);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider Contracts: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "GroupProviderContractGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerContract = _IGroupProviderContractRepository.GetById(id);
                if (providerContract == null) return NotFound($"Group Provider Contract {id} was not found");
                return Ok(providerContract);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Group Provider Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetGroupProviderContract/{GroupID}/{ProviderContractID}")]
        public IActionResult GetGroupProviderContract(int GroupID, int? ProviderContractID = null)
        {
            try
            {
                var groupProviderContract = _IGroupProviderContractRepository.GetGroupProviderContract(GroupID, ProviderContractID);
                if (groupProviderContract == null) return NotFound($"Group Provider Contract not found");
                return Ok(groupProviderContract);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific Group Provider Contracts: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]GroupProviderContractModel[] model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                GroupProviderContract[] entity = _mapper.Map<GroupProviderContract[]>(model);
                if (entity.Length > 0)
                {
                    entity.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; x.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, x.EffectiveDate, x.TermDate);
                        x.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, x.EffectiveDate, x.TermDate).ToString();
                    });
                }

                _IGroupProviderContractService.CheckIfProviderLinkWithContract(entity.ToList());
                if (!_IGroupProviderContractService.BusinessState.IsValid)
                {
                    _IGroupProviderContractService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IGroupProviderContractRepository.AddRange(entity);
                if (!_IGroupProviderContractRepository.DbState.IsValid)
                {
                    _IGroupProviderContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _logger.LogInformation("New Group Provider Contract Created");
                return Created("", _mapper.Map<GroupProviderContractModel[]>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Group Provider Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]GroupProviderContractModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IGroupProviderContractRepository.GetById(model.GroupProviderContractID);
                if (entity == null) return NotFound($"Could not find a Group Provider Contract with an GroupProviderContractID of {model.GroupProviderContractID}");

                _mapper.Map(model, entity);                
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                List<GroupProviderContract> lst = new List<GroupProviderContract>();
                lst.Add(entity);
                _IGroupProviderContractService.CheckIfProviderLinkWithContract(lst);
                if (!_IGroupProviderContractService.BusinessState.IsValid)
                {
                    _IGroupProviderContractService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IGroupProviderContractRepository.Update(entity);
                if (!_IGroupProviderContractRepository.DbState.IsValid)
                {
                    _IGroupProviderContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                return Ok(model.ProviderContractID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Group Provider Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IGroupProviderContractRepository.DeleteById(id);
                if (!_IGroupProviderContractRepository.DbState.IsValid)
                {
                    _IGroupProviderContractRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Group Provider Contract : {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("Terminate")]
        public IActionResult Terminate([FromBody]GroupProviderContractTerminateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                _IGroupProviderContractRepository.DeleteOrTermGroupProviderContract(model.GroupId, model.ProviderContractId, base.UserName, base.TodaysDate, model.TermDate, (byte)RecordStatus.Termed, model.TermReason);

                if (!_IGroupProviderContractRepository.DbState.IsValid)
                {
                    _IGroupProviderContractRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.GroupId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while terminating GroupProviderContract: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
