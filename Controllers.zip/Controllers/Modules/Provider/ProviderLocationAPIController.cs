using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Provider;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderLocation")]
    public class ProviderLocationAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderLocationAPIController> _logger;
        private IProviderLocationRepository _ProviderLocationRepository;
        private IMapper _mapper;
        private IProviderLocationService _ProviderLocationService;
        #endregion

        #region Ctor  
        public ProviderLocationAPIController(IProviderLocationRepository ProviderLocationRepository, ILogger<ProviderLocationAPIController> logger, IMapper mapper, IProviderLocationService ProviderLocationService)
        {
            _logger = logger;
            _ProviderLocationRepository = ProviderLocationRepository;
            _mapper = mapper;
            _ProviderLocationService = ProviderLocationService;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var providerLocationResult = _ProviderLocationRepository.GetProviderLocation(null, null);
                return Ok(providerLocationResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider Location: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderLocationGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerLocation = _ProviderLocationRepository.GetById(id);
                if (providerLocation == null) return NotFound($"Provider Location {id} was not found");
                return Ok(providerLocation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider Location: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderLocationByProviderId/{ProviderId}")]
        public IActionResult GetProviderLocationByProviderId(int ProviderId)
        {
            try
            {
                var providerLocation = _ProviderLocationRepository.GetProviderLocation(ProviderId, null);
                if (providerLocation == null) return NotFound($"Provider Location was not found");
                return Ok(providerLocation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider Location: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetGroupProviderLocationByGroupID/{GroupID}/{GroupLocationID}")]
        public IActionResult GetGroupProviderLocationByGroupID(int GroupID, int? GroupLocationID = null)
        {
            try
            {
                var providerLocation = _ProviderLocationRepository.GetGroupProviderLocation(GroupID, GroupLocationID);
                if (providerLocation == null) return NotFound($"Group Provider Location was not found");
                return Ok(providerLocation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Group Provider Location: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetProviderLocationByLocationId/{LocationId}")]
        public IActionResult GetProviderLocationByLocationId(int LocationId)
        {
            try
            {
                var providerLocation = _ProviderLocationRepository.GetProviderLocation(null, LocationId);
                if (providerLocation == null) return NotFound($"Provider Location was not found");
                return Ok(providerLocation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider Location: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderLocationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var providerLocation = _mapper.Map<ProviderLocation>(model);
                providerLocation.CreatedDate = base.TodaysDate;
                providerLocation.CreatedBy = base.UserName;
                providerLocation.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, providerLocation.EffectiveDate, providerLocation.TermDate);
                providerLocation.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, providerLocation.EffectiveDate, providerLocation.TermDate).ToString();

                // Check exist record condition in group
                _ProviderLocationService.CheckIfExistInGroup(providerLocation);
                if (!_ProviderLocationService.BusinessState.IsValid)
                {
                    _ProviderLocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                // Check exist record condition in all group
                //_ProviderLocationService.CheckIfExistInAll(providerLocation);
                //if (!_ProviderLocationService.BusinessState.IsValid)
                //{
                //    _ProviderLocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                //    {
                //        ModelState.AddModelError(businessState.Key, businessState.Value);
                //    });
                //    return BadRequest(ModelState);
                //}

                _ProviderLocationRepository.Add(providerLocation);
                if (!_ProviderLocationRepository.DbState.IsValid)
                {
                    _ProviderLocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ProviderLocationGet", new { id = providerLocation.ProviderLocationID });
                _logger.LogInformation("New Provider Location Created ");
                return Created(newUri, _mapper.Map<ProviderLocationModel>(providerLocation));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider Location : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]ProviderLocationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _ProviderLocationRepository.GetById(model.ProviderLocationID);
                if (entity == null) return NotFound($"Could not find Provider Location with an ProviderLocationID of {model.ProviderLocationID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                // Check exist record condition in group
                if (entity.GroupID == null || entity.GroupID == 0)
                {
                    _ProviderLocationService.CheckIfExistInGroup(entity);
                    if (!_ProviderLocationService.BusinessState.IsValid)
                    {
                        _ProviderLocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                    }
                }
                if (entity.GroupID > 0)
                {
                    List<ProviderLocation> lst = new List<ProviderLocation>();
                    lst.Add(entity);
                    _ProviderLocationService.CheckIfProviderLinkWithLocation(lst);
                    if (!_ProviderLocationService.BusinessState.IsValid)
                    {
                        _ProviderLocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                    }
                }

                // Check exist record condition in all group
                //_ProviderLocationService.CheckIfExistInAll(entity);
                //if (!_ProviderLocationService.BusinessState.IsValid)
                //{
                //    _ProviderLocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                //    {
                //        ModelState.AddModelError(businessState.Key, businessState.Value);
                //    });
                //    return BadRequest(ModelState);
                //}

                _ProviderLocationRepository.Update(entity);
                if (!_ProviderLocationRepository.DbState.IsValid)
                {
                    _ProviderLocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider Location updated  : {0}", entity.ProviderLocationID);
                return Ok(entity.ProviderLocationID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider Location :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _ProviderLocationRepository.DeleteById(id);
                if (!_ProviderLocationRepository.DbState.IsValid)
                {
                    _ProviderLocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider Location : {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("AddGroupProviderLocation")]
        public IActionResult AddGroupProviderLocation([FromBody]ProviderLocationModel[] groupProviderLocationList)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ProviderLocation[] entity = _mapper.Map<ProviderLocation[]>(groupProviderLocationList);
                if (entity.Length > 0)
                {
                    entity.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; x.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, x.EffectiveDate, x.TermDate);
                        x.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, x.EffectiveDate, x.TermDate).ToString();
                    });
                }

                _ProviderLocationService.CheckIfProviderLinkWithLocation(entity.ToList());
                if (!_ProviderLocationService.BusinessState.IsValid)
                {
                    _ProviderLocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ProviderLocationRepository.AddRange(entity);
                if (!_ProviderLocationRepository.DbState.IsValid)
                {
                    _ProviderLocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Group Provider Location Created ");
                return Created("", _mapper.Map<ProviderLocationModel[]>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Group Provider Location : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("DeleteOrTermGroupProviderLocation")]
        public IActionResult DeleteOrTermGroupProviderLocation([FromBody] ProviderLocationTerminateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                _ProviderLocationRepository.DeleteOrTermGroupProviderLocation(model.GroupID, model.LocationID, base.TodaysDate, base.UserName, model.RecordStatus, model.RecordStatusChangeComment, model.TermDate);
                if (!_ProviderLocationRepository.DbState.IsValid)
                {
                    _ProviderLocationRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(model);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while terminating Group Provider Location : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

    }
}
