using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Common.Utility;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderCode")]
    public class ProviderCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderCodeAPIController> _logger;
        private IProviderCodeRepository _providerCodeRepository;
        private IProviderCodeService _providerCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor  
        public ProviderCodeAPIController(IProviderCodeRepository providerCodeRepository, ILogger<ProviderCodeAPIController> logger, IMapper mapper, IProviderCodeService providerCodeService)
        {
            _logger = logger;
            _providerCodeRepository = providerCodeRepository;
            _mapper = mapper;
            _providerCodeService = providerCodeService;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var referenceResult = _providerCodeRepository.GetProviderCode(null, null);
                return Ok(referenceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider Code: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderCodeGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerCode = _providerCodeRepository.GetById(id);
                if (providerCode == null) return NotFound($"Provider Code {id} was not found");
                return Ok(providerCode);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider Code: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet]
        [Route("GetProviderCodeByProviderId/{ProviderId}/{CodeTypeId}")]
        public IActionResult GetProviderCodeByProviderId(int ProviderId, int? CodeTypeId)
        {
            try
            {
                var providerCode = _providerCodeRepository.GetProviderCode(ProviderId, CodeTypeId);
                if (providerCode == null) return NotFound($"Provider Code was not found");
                return Ok(providerCode);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider Code: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var providerCode = _mapper.Map<ProviderCode>(model);
                providerCode.CreatedDate = base.TodaysDate;
                providerCode.CreatedBy = base.UserName;
                providerCode.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, providerCode.EffectiveDate, providerCode.TermDate);
                providerCode.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, providerCode.EffectiveDate, providerCode.TermDate).ToString();

                // Check exist record condition in group
                _providerCodeService.CheckIfExists(providerCode);
                if (!_providerCodeService.BusinessState.IsValid)
                {
                    _providerCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _providerCodeRepository.Add(providerCode);
                if (!_providerCodeRepository.DbState.IsValid)
                {
                    _providerCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ProviderCodeGet", new { id = providerCode.ProviderCodeID });
                _logger.LogInformation("New Provider Code Created ");
                return Created(newUri, _mapper.Map<ProviderCodeViewModel>(providerCode));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider Code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]ProviderCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _providerCodeRepository.GetById(model.ProviderCodeID);
                if (entity == null) return NotFound($"Could not find Provider Code with an ProviderCodeID of {model.ProviderCodeID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                // Check exist record condition in group
                _providerCodeService.CheckIfExists(entity);
                if (!_providerCodeService.BusinessState.IsValid)
                {
                    _providerCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _providerCodeRepository.Update(entity);
                if (!_providerCodeRepository.DbState.IsValid)
                {
                    _providerCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider Code updated  : {0}", entity.ProviderCodeID);
                return Ok(model.ProviderCodeID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider Code :{ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _providerCodeRepository.DeleteById(id);
                if (!_providerCodeRepository.DbState.IsValid)
                {
                    _providerCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider Code : {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
