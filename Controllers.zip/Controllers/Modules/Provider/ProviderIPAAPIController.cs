using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Business.Interfaces.Provider;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderIPA")]
    public class ProviderIPAAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ProviderIPAAPIController> _logger;
        private IProviderIPARepository _IProviderIPARepository;
        private IProviderIPAService _IProviderIPAService;
        private IMapper _mapper;
        #endregion

        #region Ctor  
        public ProviderIPAAPIController(IProviderIPARepository IProviderIPARepository, ILogger<ProviderIPAAPIController> logger, IMapper mapper, IProviderIPAService IProviderIPAService)
        {
            _logger = logger;
            _IProviderIPARepository = IProviderIPARepository;
            _IProviderIPAService = IProviderIPAService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var providerIPAResult = _IProviderIPARepository.GetProviderIPA(null, null);
                return Ok(providerIPAResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Provider IPA: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ProviderIPAGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var providerIPA = _IProviderIPARepository.GetById(id);
                if (providerIPA == null) return NotFound($"Provider IPA {id} was not found");
                return Ok(_mapper.Map<ProviderIPAModel>(providerIPA));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Provider IPA: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("getByProviderId/{providerID}")]
        public IActionResult getByProviderId(int providerID)
        {
            try
            {
                var providerIPA = _IProviderIPARepository.GetProviderIPA(providerID, null);
                if (providerIPA == null) return NotFound($"Provider IPA was not found");
                return Ok(providerIPA);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Provider IPA: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("getByIPAId/{ipaid}")]
        public IActionResult getByIPAId(int ipaid)
        {
            try
            {
                var providerIPA = _IProviderIPARepository.GetProviderIPA(null, ipaid);
                if (providerIPA == null) return NotFound($"IPA's provider was not found");
                return Ok(providerIPA);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting IPA Provider: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderIPAModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var providerIPA = _mapper.Map<ProviderIPA>(model);
                providerIPA.CreatedDate = base.TodaysDate;
                providerIPA.CreatedBy = base.UserName;
                providerIPA.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, providerIPA.EffectiveDate, providerIPA.TermDate);
                providerIPA.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, providerIPA.EffectiveDate, providerIPA.TermDate).ToString();

                _IProviderIPAService.CheckIfExist(providerIPA);
                if (!_IProviderIPAService.BusinessState.IsValid)
                {
                    _IProviderIPAService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                _IProviderIPARepository.Add(providerIPA);
                if (!_IProviderIPARepository.DbState.IsValid)
                {
                    _IProviderIPARepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("providerIPAGet", new { id = providerIPA.ProviderIPAID });
                _logger.LogInformation("New Provider IPA Created ");
                return Created(newUri, _mapper.Map<ProviderIPAModel>(providerIPA));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider IPA : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]ProviderIPAModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IProviderIPARepository.GetById(model.ProviderIPAID);
                if (entity == null) return NotFound($"Could not find Provider IPA with an ProviderIPAID of {model.ProviderIPAID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderIPAService.CheckIfExist(entity);
                if (!_IProviderIPAService.BusinessState.IsValid)
                {
                    _IProviderIPAService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                _IProviderIPARepository.Update(entity);
                if (!_IProviderIPARepository.DbState.IsValid)
                {
                    _IProviderIPARepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider IPA updated  : {0}", entity.ProviderIPAID);
                return Ok(entity.ProviderIPAID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider IPA :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IProviderIPARepository.DeleteById(id);
                if (!_IProviderIPARepository.DbState.IsValid)
                {
                    _IProviderIPARepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Provider IPA : {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
