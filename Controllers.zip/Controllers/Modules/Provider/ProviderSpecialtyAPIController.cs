using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Business.Interfaces.Provider;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderSpecialty")]
    public class ProviderSpecialtyAPIController : BaseAPIController
    {
        private readonly IProviderSpecialtyRepository _IProviderSpecialtyRepository;
        private readonly IProviderSpecialtyService _IProviderSpecialtyService;
        private IMapper _mapper;
        private ILogger<ProviderSpecialtyAPIController> _logger;

        public ProviderSpecialtyAPIController(IProviderSpecialtyRepository IProviderSpecialtyRepository, IProviderSpecialtyService IProviderSpecialtyService, IMapper mapper, ILogger<ProviderSpecialtyAPIController> logger)
        {
            _IProviderSpecialtyRepository = IProviderSpecialtyRepository;
            _IProviderSpecialtyService = IProviderSpecialtyService;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet("GetByProvider/{providerID}")]
        public IActionResult GetByProvider(int providerID)
        {
            try
            {
                var providerSpecialties = _IProviderSpecialtyRepository.GetByProvider(providerID).ToList();
                return Ok(providerSpecialties);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Provider Specialties {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}", Name = "ProviderSpecialtyGet")]
        public IActionResult Get(int id)
        {
            try
            {
                ProviderSpecialty providerSpecialty = _IProviderSpecialtyRepository.GetById(id);
                if (providerSpecialty == null) return NotFound($"Provider specialty {id} was not found");
                return Ok(_mapper.Map<ProviderSpecialtyModel>(providerSpecialty));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ProviderSpecialtyModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ProviderSpecialty entity = _mapper.Map<ProviderSpecialty>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderSpecialtyService.CheckIfExist(entity);
                if (!_IProviderSpecialtyService.BusinessState.IsValid)
                {
                    _IProviderSpecialtyService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                bool checkIfExistIsPrimary = false;
                if (entity.IsPrimarySpecialty == true)
                {
                    checkIfExistIsPrimary = _IProviderSpecialtyService.CheckIfExistIsPrimary(entity.ProviderID, entity.ProviderSpecialtyID);
                }
                _IProviderSpecialtyRepository.Add(entity, checkIfExistIsPrimary);
                if (!_IProviderSpecialtyRepository.DbState.IsValid)
                {
                    _IProviderSpecialtyRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("ProviderSpecialtyGet", new { id = entity.ProviderSpecialtyID });
                _logger.LogInformation("Provider Specialty Created ");
                return Created(newUri, _mapper.Map<ProviderSpecialtyModel>(entity));

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Provider Specialty : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody] ProviderSpecialtyModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IProviderSpecialtyRepository.GetById(model.ProviderSpecialtyID);
                if (entity == null) return NotFound($"Could not find provider specialty with a ProviderID of {model.ProviderID}");

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IProviderSpecialtyService.CheckIfExist(entity);
                if (!_IProviderSpecialtyService.BusinessState.IsValid)
                {
                    _IProviderSpecialtyService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                bool checkIfExistIsPrimary = false;
                if (entity.IsPrimarySpecialty == true)
                {
                    checkIfExistIsPrimary = _IProviderSpecialtyService.CheckIfExistIsPrimary(entity.ProviderID, entity.ProviderSpecialtyID);
                }
                _IProviderSpecialtyRepository.Update(entity, checkIfExistIsPrimary);
                if (!_IProviderSpecialtyRepository.DbState.IsValid)
                {
                    _IProviderSpecialtyRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Provider specialty updated  : {0}", entity.ProviderSpecialtyID);
                return Ok(model.ProviderSpecialtyID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Provider specialty :{ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IProviderSpecialtyRepository.DeleteById(id);
                if (!_IProviderSpecialtyRepository.DbState.IsValid)
                {
                    _IProviderSpecialtyRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing provider specialty : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("CheckIfExistIsPrimary/{providerID}/{providerSpecialtyID}")]
        public IActionResult CheckIfExistIsPrimary(int providerID, int providerSpecialtyID)
        {
            try
            {
                bool res = _IProviderSpecialtyService.CheckIfExistIsPrimary(providerID, providerSpecialtyID);
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Detail {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
