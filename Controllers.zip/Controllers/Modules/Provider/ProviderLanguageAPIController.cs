using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Provider;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Provider
{
    [Route("api/ProviderLanguage")]
    public class ProviderLanguageAPIController : BaseAPIController
    {
        private readonly IProviderLanguageRepository _providerLanguageRepository;
        private IMapper _mapper;
        private ILogger<ProviderLanguageAPIController> _logger;

        public ProviderLanguageAPIController(IProviderLanguageRepository providerLanguageRepository, IMapper mapper, ILogger<ProviderLanguageAPIController> logger)
        {
            _providerLanguageRepository = providerLanguageRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet("GetByProviderID/{providerID}")]
        public IActionResult GetByProviderID(int providerID)
        {
            try
            {
                var providerLanguages = _providerLanguageRepository.GetByProviderID(providerID);
                if (providerLanguages == null) return NotFound($"Languages for Provider {providerID} was not found");
                return Ok(providerLanguages);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
