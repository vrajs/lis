using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.OrganizationRule;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeader")]
    public class RuleHeaderAPIController : BaseAPIController
    {
        private ILogger<RuleHeaderAPIController> _Logger;
        private readonly IRuleHeaderRepository _RuleHeaderRepository;
        private readonly IRuleHeaderService _RuleHeaderService;
        public RuleHeaderAPIController(IRuleHeaderRepository RuleHeaderRepository, ILogger<RuleHeaderAPIController> Logger, IRuleHeaderService RuleHeaderService) 
        {
            _RuleHeaderRepository = RuleHeaderRepository;
            _Logger = Logger;
            _RuleHeaderService = RuleHeaderService;
        }

        //// GET: api/RuleHeader
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET api/RuleHeader/5
        [HttpGet("{id}", Name = "RuleHeaderGet")]
        public IActionResult Get(short id)
        {
            try
            {
                var ruleHeader= _RuleHeaderRepository.GetById(id);
                return Ok(ruleHeader);
            }
            catch (Exception ex)
            {
                _Logger.LogError(ex, $"Error while performing Get api/RuleHeader/Get Id = {id}");
                return BadRequest($"Error while performing Get api/RuleHeader/Get Id = {id}");
            }
        }

        // POST api/RuleHeader
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeader ruleHeader)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    ruleHeader.CreatedDate = base.TodaysDate;
                    ruleHeader.CreatedBy = base.UserName;
                    ruleHeader.TermDate = ruleHeader.TermDate == null ? DateTime.MaxValue : ruleHeader.TermDate;
                    ruleHeader.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, ruleHeader.EffectiveDate, (DateTime)(ruleHeader.TermDate == null ? DateTime.MaxValue : ruleHeader.TermDate));
                    ruleHeader.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, ruleHeader.EffectiveDate, (DateTime)(ruleHeader.TermDate == null ? DateTime.MaxValue : ruleHeader.TermDate)).ToString();
                    
                    _RuleHeaderService.CheckDuplicate(ruleHeader);
                    if (!_RuleHeaderService.BusinessState.IsValid)
                    {
                        _RuleHeaderService.BusinessState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    _RuleHeaderRepository.Add(ruleHeader);
                    if (!_RuleHeaderRepository.DbState.IsValid)
                    {
                        _RuleHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }
                    var newUri = Url.Link("RuleHeaderGet", new { id = ruleHeader.RuleHeaderID });
                    _Logger.LogInformation("New Rule Header Created");
                    return Created(newUri, ruleHeader.RuleHeaderID);

                }
                catch (Exception ex)
                {

                    _Logger.LogError("Error while saving rule header : {0}", ex);
                    return BadRequest(ex.ToErrorMessage());
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/RuleHeader/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeader ruleHeader)
        {
            ModelState.Remove("TermDate");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                ruleHeader.UpdatedDate = base.TodaysDate;
                ruleHeader.UpdatedBy = base.UserName;
                ruleHeader.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, ruleHeader.EffectiveDate, (DateTime)(ruleHeader.TermDate == null ? DateTime.MaxValue : ruleHeader.TermDate));
                ruleHeader.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, ruleHeader.EffectiveDate, (DateTime)(ruleHeader.TermDate == null ? DateTime.MaxValue : ruleHeader.TermDate)).ToString();
                ruleHeader.TermDate = ruleHeader.TermDate != null ? ruleHeader.TermDate : DateTime.MaxValue;

                _RuleHeaderService.CheckDuplicate(ruleHeader);
                if (!_RuleHeaderService.BusinessState.IsValid)
                {
                    _RuleHeaderService.BusinessState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _RuleHeaderRepository.Update(ruleHeader);
                if (!_RuleHeaderRepository.DbState.IsValid)
                {
                    _RuleHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _Logger.LogInformation("Rule Header Updated");
                return Ok(ruleHeader.RuleHeaderID);
            }
            catch (Exception ex)
            {

                _Logger.LogError("Error while updating rule header : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/RuleHeader/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
               _RuleHeaderRepository.DeleteById(id);
                if (!_RuleHeaderRepository.DbState.IsValid)
                {
                    _RuleHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _Logger.LogError("Error while removing provider : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
