using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderClaimAddress")]
    public class RuleHeaderClaimAddressAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderClaimAddressAPIController> _logger;
        private IRuleHeaderClaimAddressRepository _IRuleHeaderClaimAddressRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderClaimAddressAPIController(ILogger<RuleHeaderClaimAddressAPIController> logger, IRuleHeaderClaimAddressRepository IRuleHeaderClaimAddressRepository, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderClaimAddressRepository = IRuleHeaderClaimAddressRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderClaimAddressGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderClaimAddress = _IRuleHeaderClaimAddressRepository.GetById(id);
                if (RuleHeaderClaimAddress == null) return NotFound($"RuleHeaderClaimAddress {id} was not Found");
                if (!_IRuleHeaderClaimAddressRepository.DbState.IsValid)
                {
                    _IRuleHeaderClaimAddressRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderClaimAddressViewModel>(RuleHeaderClaimAddress));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderClaimAddress : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderClaimAddressViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderClaimAddressModel = _mapper.Map<RuleHeaderClaimAddress>(model);
                RuleHeaderClaimAddressModel.CreatedDate = base.TodaysDate;
                RuleHeaderClaimAddressModel.CreatedBy = base.UserName;

                RuleHeaderClaimAddressModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderClaimAddressModel.EffectiveDate, RuleHeaderClaimAddressModel.TermDate);
                RuleHeaderClaimAddressModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderClaimAddressModel.EffectiveDate, RuleHeaderClaimAddressModel.TermDate).ToString();

                _IRuleHeaderClaimAddressRepository.Add(RuleHeaderClaimAddressModel);
                if (!_IRuleHeaderClaimAddressRepository.DbState.IsValid)
                {
                    _IRuleHeaderClaimAddressRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderClaimAddressGet", new { id = RuleHeaderClaimAddressModel.RuleHeaderClaimAddressID });
                _logger.LogInformation("New RuleHeaderClaimAddress Created");
                return Created(newUri, RuleHeaderClaimAddressModel.RuleHeaderClaimAddressID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderClaimAddress : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderClaimAddressViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderClaimAddress = _IRuleHeaderClaimAddressRepository.GetById(model.RuleHeaderClaimAddressID);

                if (oldRuleHeaderClaimAddress == null) return NotFound($"Could not find a RuleHeaderClaimAddress with an RuleHeaderClaimAddressID of {model.RuleHeaderClaimAddressID}");

                _mapper.Map(model, oldRuleHeaderClaimAddress);
                oldRuleHeaderClaimAddress.UpdatedBy = base.UserName;
                oldRuleHeaderClaimAddress.UpdatedDate = base.TodaysDate;

                oldRuleHeaderClaimAddress.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderClaimAddress.EffectiveDate, oldRuleHeaderClaimAddress.TermDate);
                oldRuleHeaderClaimAddress.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderClaimAddress.EffectiveDate, oldRuleHeaderClaimAddress.TermDate).ToString();

                _IRuleHeaderClaimAddressRepository.Update(oldRuleHeaderClaimAddress);
                if (!_IRuleHeaderClaimAddressRepository.DbState.IsValid)
                {
                    _IRuleHeaderClaimAddressRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderClaimAddressID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderClaimAddress :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderClaimAddressRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderClaimAddress : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
    }
