using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderMessageODController : BaseODController
    {
        private readonly IRuleHeaderMessageRepository _RuleHeaderMessageRepository;

        public RuleHeaderMessageODController(IRuleHeaderMessageRepository RuleHeaderMessageRepository)
        {
            _RuleHeaderMessageRepository = RuleHeaderMessageRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaderMessageByMessageType")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaderMessageByMessageType(short RuleHeaderID, byte MessageTypeID)
        {
            var query = _RuleHeaderMessageRepository.GetRuleHeaderMessageByMessageType(RuleHeaderID, MessageTypeID);
            return Ok(query);
        }
    }
}
