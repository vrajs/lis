using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderTimelyFiling")]
    public class RuleHeaderTimelyFilingAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderTimelyFilingAPIController> _logger;
        private IRuleHeaderTimelyFiling _IRuleHeaderTimelyFiling;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderTimelyFilingAPIController(ILogger<RuleHeaderTimelyFilingAPIController> logger,IRuleHeaderTimelyFiling IRuleHeaderTimelyFiling, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderTimelyFiling = IRuleHeaderTimelyFiling;
            _mapper = mapper;
           
        }
        #endregion

        #region API Methods
       
        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderTimelyFilingGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderTimelyFiling = _IRuleHeaderTimelyFiling.GetById(id);
                if (RuleHeaderTimelyFiling == null) return NotFound($"RuleHeaderTimelyFiling {id} was not Found");
                if (!_IRuleHeaderTimelyFiling.DbState.IsValid)
                {
                    _IRuleHeaderTimelyFiling.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderTimelyFilingViewModel>(RuleHeaderTimelyFiling));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderTimelyFiling : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderTimelyFilingViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderTimelyFilingModel = _mapper.Map<RuleHeaderTimelyFiling>(model);
                RuleHeaderTimelyFilingModel.CreatedDate = base.TodaysDate;
                RuleHeaderTimelyFilingModel.CreatedBy = base.UserName;

                RuleHeaderTimelyFilingModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderTimelyFilingModel.EffectiveDate, RuleHeaderTimelyFilingModel.TermDate);
                RuleHeaderTimelyFilingModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderTimelyFilingModel.EffectiveDate, RuleHeaderTimelyFilingModel.TermDate).ToString();

                _IRuleHeaderTimelyFiling.Add(RuleHeaderTimelyFilingModel);
                if (!_IRuleHeaderTimelyFiling.DbState.IsValid)
                {
                    _IRuleHeaderTimelyFiling.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderTimelyFilingGet", new { id = RuleHeaderTimelyFilingModel.RuleHeaderTimelyFilingID });
                _logger.LogInformation("New RuleHeaderTimelyFiling Created");
                return Created(newUri, RuleHeaderTimelyFilingModel.RuleHeaderTimelyFilingID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderTimelyFiling : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderTimelyFilingViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderTimelyFiling = _IRuleHeaderTimelyFiling.GetById(model.RuleHeaderTimelyFilingID);

                if (oldRuleHeaderTimelyFiling == null) return NotFound($"Could not find a RuleHeaderTimelyFiling with an RuleHeaderTimelyFilingID of {model.RuleHeaderTimelyFilingID}");

                _mapper.Map(model, oldRuleHeaderTimelyFiling);
                oldRuleHeaderTimelyFiling.UpdatedBy = base.UserName;
                oldRuleHeaderTimelyFiling.UpdatedDate = base.TodaysDate;

                oldRuleHeaderTimelyFiling.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderTimelyFiling.EffectiveDate, oldRuleHeaderTimelyFiling.TermDate);
                oldRuleHeaderTimelyFiling.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderTimelyFiling.EffectiveDate, oldRuleHeaderTimelyFiling.TermDate).ToString();

                _IRuleHeaderTimelyFiling.Update(oldRuleHeaderTimelyFiling);
                if (!_IRuleHeaderTimelyFiling.DbState.IsValid)
                {
                    _IRuleHeaderTimelyFiling.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderTimelyFilingID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderTimelyFiling :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderTimelyFiling.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderTimelyFiling : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }

}


