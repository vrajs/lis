using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderModifierDiscountODController : BaseODController
    {
        private readonly IRuleHeaderModifierDiscountRepository _RuleHeaderModifierDiscountRepository;

        public RuleHeaderModifierDiscountODController(IRuleHeaderModifierDiscountRepository RuleHeaderModifierDiscountRepository)
        {
            _RuleHeaderModifierDiscountRepository = RuleHeaderModifierDiscountRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaderModifierDiscounts")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaderModifierDiscounts(short RuleHeaderID)
        {
            var query = _RuleHeaderModifierDiscountRepository.GetRuleHeaderModifierDiscounts(RuleHeaderID);
            return Ok(query);
        }
    }
}
