using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderModifierDiscount")]
    public class RuleHeaderModifierDiscountAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderModifierDiscountAPIController> _logger;
        private IRuleHeaderModifierDiscountRepository _IRuleHeaderModifierDiscountRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderModifierDiscountAPIController(ILogger<RuleHeaderModifierDiscountAPIController> logger, IRuleHeaderModifierDiscountRepository IRuleHeaderModifierDiscountRepository, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderModifierDiscountRepository = IRuleHeaderModifierDiscountRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderModifierDiscountGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderModifierDiscount = _IRuleHeaderModifierDiscountRepository.GetById(id);
                if (RuleHeaderModifierDiscount == null) return NotFound($"RuleHeaderModifierDiscount {id} was not Found");
                if (!_IRuleHeaderModifierDiscountRepository.DbState.IsValid)
                {
                    _IRuleHeaderModifierDiscountRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderModifierDiscountViewModel>(RuleHeaderModifierDiscount));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderModifierDiscount : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderModifierDiscountViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderModifierDiscountModel = _mapper.Map<RuleHeaderModifierDiscount>(model);
                RuleHeaderModifierDiscountModel.CreatedDate = base.TodaysDate;
                RuleHeaderModifierDiscountModel.CreatedBy = base.UserName;

                RuleHeaderModifierDiscountModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderModifierDiscountModel.EffectiveDate, RuleHeaderModifierDiscountModel.TermDate);
                RuleHeaderModifierDiscountModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderModifierDiscountModel.EffectiveDate, RuleHeaderModifierDiscountModel.TermDate).ToString();

                _IRuleHeaderModifierDiscountRepository.Add(RuleHeaderModifierDiscountModel);
                if (!_IRuleHeaderModifierDiscountRepository.DbState.IsValid)
                {
                    _IRuleHeaderModifierDiscountRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderModifierDiscountGet", new { id = RuleHeaderModifierDiscountModel.RuleHeaderModifierDiscountID });
                _logger.LogInformation("New RuleHeaderModifierDiscount Created");
                return Created(newUri, RuleHeaderModifierDiscountModel.RuleHeaderModifierDiscountID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderModifierDiscount : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderModifierDiscountViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderModifierDiscount = _IRuleHeaderModifierDiscountRepository.GetById(model.RuleHeaderModifierDiscountID);

                if (oldRuleHeaderModifierDiscount == null) return NotFound($"Could not find a RuleHeaderModifierDiscount with an RuleHeaderModifierDiscountID of {model.RuleHeaderModifierDiscountID}");

                _mapper.Map(model, oldRuleHeaderModifierDiscount);
                oldRuleHeaderModifierDiscount.UpdatedBy = base.UserName;
                oldRuleHeaderModifierDiscount.UpdatedDate = base.TodaysDate;

                oldRuleHeaderModifierDiscount.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderModifierDiscount.EffectiveDate, oldRuleHeaderModifierDiscount.TermDate);
                oldRuleHeaderModifierDiscount.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderModifierDiscount.EffectiveDate, oldRuleHeaderModifierDiscount.TermDate).ToString();

                _IRuleHeaderModifierDiscountRepository.Update(oldRuleHeaderModifierDiscount);
                if (!_IRuleHeaderModifierDiscountRepository.DbState.IsValid)
                {
                    _IRuleHeaderModifierDiscountRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderModifierDiscountID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderModifierDiscount :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderModifierDiscountRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderModifierDiscount : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
