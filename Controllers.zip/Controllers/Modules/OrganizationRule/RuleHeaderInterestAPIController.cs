using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderInterest")]
    public class RuleHeaderInterestAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderInterestAPIController> _logger;
        private IRuleHeaderInterestRepository _IRuleHeaderInterestRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderInterestAPIController(ILogger<RuleHeaderInterestAPIController> logger, IRuleHeaderInterestRepository IRuleHeaderInterestRepository, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderInterestRepository = IRuleHeaderInterestRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderInterestGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderInterest = _IRuleHeaderInterestRepository.GetById(id);
                if (RuleHeaderInterest == null) return NotFound($"RuleHeaderInterest {id} was not Found");
                if (!_IRuleHeaderInterestRepository.DbState.IsValid)
                {
                    _IRuleHeaderInterestRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderInterestViewModel>(RuleHeaderInterest));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderInterest : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderInterestViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderInterestModel = _mapper.Map<RuleHeaderInterest>(model);
                RuleHeaderInterestModel.CreatedDate = base.TodaysDate;
                RuleHeaderInterestModel.CreatedBy = base.UserName;

                RuleHeaderInterestModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderInterestModel.EffectiveDate, RuleHeaderInterestModel.TermDate);
                RuleHeaderInterestModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderInterestModel.EffectiveDate, RuleHeaderInterestModel.TermDate).ToString();

                _IRuleHeaderInterestRepository.Add(RuleHeaderInterestModel);
                if (!_IRuleHeaderInterestRepository.DbState.IsValid)
                {
                    _IRuleHeaderInterestRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderInterestGet", new { id = RuleHeaderInterestModel.RuleHeaderInterestID });
                _logger.LogInformation("New RuleHeaderInterest Created");
                return Created(newUri, RuleHeaderInterestModel.RuleHeaderInterestID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderInterest : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderInterestViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderInterest = _IRuleHeaderInterestRepository.GetById(model.RuleHeaderInterestID);

                if (oldRuleHeaderInterest == null) return NotFound($"Could not find a RuleHeaderInterest with an RuleHeaderInterestID of {model.RuleHeaderInterestID}");

                _mapper.Map(model, oldRuleHeaderInterest);
                oldRuleHeaderInterest.UpdatedBy = base.UserName;
                oldRuleHeaderInterest.UpdatedDate = base.TodaysDate;

                oldRuleHeaderInterest.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderInterest.EffectiveDate, oldRuleHeaderInterest.TermDate);
                oldRuleHeaderInterest.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderInterest.EffectiveDate, oldRuleHeaderInterest.TermDate).ToString();

                _IRuleHeaderInterestRepository.Update(oldRuleHeaderInterest);
                if (!_IRuleHeaderInterestRepository.DbState.IsValid)
                {
                    _IRuleHeaderInterestRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderInterestID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderInterest :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderInterestRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderInterest : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
