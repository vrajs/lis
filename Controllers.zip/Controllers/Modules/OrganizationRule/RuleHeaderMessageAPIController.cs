using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderMessage")]
    public class RuleHeaderMessageAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderMessageAPIController> _logger;
        private IRuleHeaderMessageRepository _IRuleHeaderMessageRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderMessageAPIController(ILogger<RuleHeaderMessageAPIController> logger, IRuleHeaderMessageRepository IRuleHeaderMessageRepository, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderMessageRepository = IRuleHeaderMessageRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderMessageGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderMessage = _IRuleHeaderMessageRepository.GetById(id);
                if (RuleHeaderMessage == null) return NotFound($"RuleHeaderMessage {id} was not Found");
                if (!_IRuleHeaderMessageRepository.DbState.IsValid)
                {
                    _IRuleHeaderMessageRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderMessageViewModel>(RuleHeaderMessage));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderMessage : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //[HttpGet]
        //[Route("GetRuleHeaderMessageByMessageType/{RuleHeaderID}/{MessageTypeID}")]
        //public IActionResult GetRuleHeaderMessageByMessageType(short RuleHeaderID, byte MessageTypeID)
        //{
        //    try
        //    {
        //        var RuleHeaderMessage = _IRuleHeaderMessageRepository.GetRuleHeaderMessageByMessageType(RuleHeaderID, MessageTypeID);
        //        if (RuleHeaderMessage == null) return NotFound($"RuleHeaderMessage {MessageTypeID} was not Found");
        //        if (!_IRuleHeaderMessageRepository.DbState.IsValid)
        //        {
        //            _IRuleHeaderMessageRepository.DbState.ErrorMessages.ForEach((businessState) =>
        //            {
        //                ModelState.AddModelError(businessState.Key, businessState.Value);
        //            });
        //            return BadRequest(ModelState);
        //        }
        //        return Ok(RuleHeaderMessage);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError("Error while Getting RuleHeaderMessage : {0}", ex);
        //        return BadRequest(ex.Message);
        //    }
        //}

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderMessageViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderMessageModel = _mapper.Map<RuleHeaderMessage>(model);
                RuleHeaderMessageModel.CreatedDate = base.TodaysDate;
                RuleHeaderMessageModel.CreatedBy = base.UserName;

                RuleHeaderMessageModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderMessageModel.EnglishMessageEffectiveDate, RuleHeaderMessageModel.EnglishMessageTermDate);
                RuleHeaderMessageModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderMessageModel.EnglishMessageEffectiveDate, RuleHeaderMessageModel.EnglishMessageTermDate).ToString();

                _IRuleHeaderMessageRepository.Add(RuleHeaderMessageModel);
                if (!_IRuleHeaderMessageRepository.DbState.IsValid)
                {
                    _IRuleHeaderMessageRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderMessageGet", new { id = RuleHeaderMessageModel.RuleHeaderMessageID });
                _logger.LogInformation("New RuleHeaderMessage Created");
                return Created(newUri, RuleHeaderMessageModel.RuleHeaderMessageID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderMessage : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderMessageViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderMessage = _IRuleHeaderMessageRepository.GetById(model.RuleHeaderMessageID);

                if (oldRuleHeaderMessage == null) return NotFound($"Could not find a RuleHeaderMessage with an RuleHeaderMessageID of {model.RuleHeaderMessageID}");

                _mapper.Map(model, oldRuleHeaderMessage);
                oldRuleHeaderMessage.UpdatedBy = base.UserName;
                oldRuleHeaderMessage.UpdatedDate = base.TodaysDate;

                oldRuleHeaderMessage.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderMessage.EnglishMessageEffectiveDate, oldRuleHeaderMessage.EnglishMessageTermDate);
                oldRuleHeaderMessage.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderMessage.EnglishMessageEffectiveDate, oldRuleHeaderMessage.EnglishMessageTermDate).ToString();

                _IRuleHeaderMessageRepository.Update(oldRuleHeaderMessage);
                if (!_IRuleHeaderMessageRepository.DbState.IsValid)
                {
                    _IRuleHeaderMessageRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderMessageID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderMessage :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderMessageRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderMessage : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
    }
