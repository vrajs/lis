using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderTimelyFilingODController : BaseODController
    {
        private readonly IRuleHeaderTimelyFiling _RuleHeaderTimelyFiling;

        public RuleHeaderTimelyFilingODController(IRuleHeaderTimelyFiling RuleHeaderTimelyFiling)
        {
            _RuleHeaderTimelyFiling = RuleHeaderTimelyFiling;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaderTimelyFilings")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaderTimelyFilings([FromQuery]short RuleHeaderID)
        {
            var query = _RuleHeaderTimelyFiling.GetRuleHeaderTimelyFilings(RuleHeaderID);
            return Ok(query);
        }
    }
}
