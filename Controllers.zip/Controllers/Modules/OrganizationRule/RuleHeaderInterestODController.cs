using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderInterestODController : BaseODController
    {
        private readonly IRuleHeaderInterestRepository _RuleHeaderInterestRepository;

        public RuleHeaderInterestODController(IRuleHeaderInterestRepository RuleHeaderInterestRepository)
        {
            _RuleHeaderInterestRepository = RuleHeaderInterestRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaderInterests")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaderInterests(short RuleHeaderID)
        {
            var query = _RuleHeaderInterestRepository.GetRuleHeaderInterests(RuleHeaderID);
            return Ok(query);
        }
    }
}
