using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Data.Contracts.View;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderODController : BaseODController
    {
        private readonly IViewRepository _ViewRepository;

        public RuleHeaderODController(IViewRepository ViewRepository)
        {
            _ViewRepository = ViewRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaders")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaders()
        {
            var deletedFlag = (byte)RecordStatus.Deleted;
            var invalidFlag = (byte)RecordStatus.VoidOrInvalid;
            var query = _ViewRepository.GetRuleHeaders.Where(i => i.RecordStatus != deletedFlag && i.RecordStatus != invalidFlag);
            return Ok(query);
        }
    }
}
