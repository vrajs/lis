using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderFeeSchedule")]
    public class RuleHeaderFeeScheduleAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderFeeScheduleAPIController> _logger;
        private IRuleHeaderFeeScheduleRepository _IRuleHeaderFeeScheduleRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderFeeScheduleAPIController(ILogger<RuleHeaderFeeScheduleAPIController> logger, IRuleHeaderFeeScheduleRepository IRuleHeaderFeeScheduleRepository, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderFeeScheduleRepository = IRuleHeaderFeeScheduleRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderFeeScheduleGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderFeeSchedule = _IRuleHeaderFeeScheduleRepository.GetById(id);
                if (RuleHeaderFeeSchedule == null) return NotFound($"RuleHeaderFeeSchedule {id} was not Found");
                if (!_IRuleHeaderFeeScheduleRepository.DbState.IsValid)
                {
                    _IRuleHeaderFeeScheduleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderFeeScheduleViewModel>(RuleHeaderFeeSchedule));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderFeeSchedule : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderFeeScheduleViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderFeeScheduleModel = _mapper.Map<RuleHeaderFeeSchedule>(model);
                RuleHeaderFeeScheduleModel.CreatedDate = base.TodaysDate;
                RuleHeaderFeeScheduleModel.CreatedBy = base.UserName;

                RuleHeaderFeeScheduleModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderFeeScheduleModel.EffectiveDate, RuleHeaderFeeScheduleModel.TermDate);
                RuleHeaderFeeScheduleModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderFeeScheduleModel.EffectiveDate, RuleHeaderFeeScheduleModel.TermDate).ToString();

                _IRuleHeaderFeeScheduleRepository.Add(RuleHeaderFeeScheduleModel);
                if (!_IRuleHeaderFeeScheduleRepository.DbState.IsValid)
                {
                    _IRuleHeaderFeeScheduleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderFeeScheduleGet", new { id = RuleHeaderFeeScheduleModel.RuleHeaderFeeScheduleID });
                _logger.LogInformation("New RuleHeaderFeeSchedule Created");
                return Created(newUri, RuleHeaderFeeScheduleModel.RuleHeaderFeeScheduleID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderFeeSchedule : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderFeeScheduleViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderFeeSchedule = _IRuleHeaderFeeScheduleRepository.GetById(model.RuleHeaderFeeScheduleID);

                if (oldRuleHeaderFeeSchedule == null) return NotFound($"Could not find a RuleHeaderFeeSchedule with an RuleHeaderFeeScheduleID of {model.RuleHeaderFeeScheduleID}");

                _mapper.Map(model, oldRuleHeaderFeeSchedule);
                oldRuleHeaderFeeSchedule.UpdatedBy = base.UserName;
                oldRuleHeaderFeeSchedule.UpdatedDate = base.TodaysDate;

                oldRuleHeaderFeeSchedule.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderFeeSchedule.EffectiveDate, oldRuleHeaderFeeSchedule.TermDate);
                oldRuleHeaderFeeSchedule.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderFeeSchedule.EffectiveDate, oldRuleHeaderFeeSchedule.TermDate).ToString();

                _IRuleHeaderFeeScheduleRepository.Update(oldRuleHeaderFeeSchedule);
                if (!_IRuleHeaderFeeScheduleRepository.DbState.IsValid)
                {
                    _IRuleHeaderFeeScheduleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderFeeScheduleID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderFeeSchedule :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderFeeScheduleRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderFeeSchedule : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }

}

