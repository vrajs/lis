using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("api/RuleHeaderCapitation")]
    public class RuleHeaderCapitationAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RuleHeaderCapitationAPIController> _logger;
        private IRuleHeaderCapitationRepository _IRuleHeaderCapitationRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RuleHeaderCapitationAPIController(ILogger<RuleHeaderCapitationAPIController> logger, IRuleHeaderCapitationRepository IRuleHeaderCapitationRepository, IMapper mapper)
        {
            _logger = logger;
            _IRuleHeaderCapitationRepository = IRuleHeaderCapitationRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "RuleHeaderCapitationGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var RuleHeaderCapitation = _IRuleHeaderCapitationRepository.GetById(id);
                if (RuleHeaderCapitation == null) return NotFound($"RuleHeaderCapitation {id} was not Found");
                if (!_IRuleHeaderCapitationRepository.DbState.IsValid)
                {
                    _IRuleHeaderCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RuleHeaderCapitationViewModel>(RuleHeaderCapitation));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RuleHeaderCapitation : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderCapitationViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var RuleHeaderCapitationModel = _mapper.Map<RuleHeaderCapitation>(model);
                RuleHeaderCapitationModel.CreatedDate = base.TodaysDate;
                RuleHeaderCapitationModel.CreatedBy = base.UserName;

                RuleHeaderCapitationModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, RuleHeaderCapitationModel.EffectiveDate, RuleHeaderCapitationModel.TermDate);
                RuleHeaderCapitationModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, RuleHeaderCapitationModel.EffectiveDate, RuleHeaderCapitationModel.TermDate).ToString();

                _IRuleHeaderCapitationRepository.Add(RuleHeaderCapitationModel);
                if (!_IRuleHeaderCapitationRepository.DbState.IsValid)
                {
                    _IRuleHeaderCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderCapitationGet", new { id = RuleHeaderCapitationModel.RuleHeaderCapitationID });
                _logger.LogInformation("New RuleHeaderCapitation Created");
                return Created(newUri, RuleHeaderCapitationModel.RuleHeaderCapitationID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving RuleHeaderCapitation : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderCapitationViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldRuleHeaderCapitation = _IRuleHeaderCapitationRepository.GetById(model.RuleHeaderCapitationID);

                if (oldRuleHeaderCapitation == null) return NotFound($"Could not find a RuleHeaderCapitation with an RuleHeaderCapitationID of {model.RuleHeaderCapitationID}");

                _mapper.Map(model, oldRuleHeaderCapitation);
                oldRuleHeaderCapitation.UpdatedBy = base.UserName;
                oldRuleHeaderCapitation.UpdatedDate = base.TodaysDate;

                oldRuleHeaderCapitation.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderCapitation.EffectiveDate, oldRuleHeaderCapitation.TermDate);
                oldRuleHeaderCapitation.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldRuleHeaderCapitation.EffectiveDate, oldRuleHeaderCapitation.TermDate).ToString();

                _IRuleHeaderCapitationRepository.Update(oldRuleHeaderCapitation);
                if (!_IRuleHeaderCapitationRepository.DbState.IsValid)
                {
                    _IRuleHeaderCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.RuleHeaderCapitationID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating RuleHeaderCapitation :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IRuleHeaderCapitationRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RuleHeaderCapitation : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
    }
