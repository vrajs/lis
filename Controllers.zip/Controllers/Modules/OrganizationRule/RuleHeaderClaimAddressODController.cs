using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderClaimAddressODController : BaseODController
    {
        private readonly IRuleHeaderClaimAddressRepository _RuleHeaderClaimAddressRepository;

        public RuleHeaderClaimAddressODController(IRuleHeaderClaimAddressRepository RuleHeaderClaimAddressRepository)
        {
            _RuleHeaderClaimAddressRepository = RuleHeaderClaimAddressRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaderClaimAddress")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaderClaimAddresss(short RuleHeaderID)
        {
            var query = _RuleHeaderClaimAddressRepository.GetRuleHeaderClaimAddress(RuleHeaderID);
            return Ok(query);
        }
    }
}
