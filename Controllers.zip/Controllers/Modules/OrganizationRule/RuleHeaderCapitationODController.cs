using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Route("odata")]
    public class RuleHeaderCapitationODController : BaseODController
    {
        private readonly IRuleHeaderCapitationRepository _RuleHeaderCapitationRepository;

        public RuleHeaderCapitationODController(IRuleHeaderCapitationRepository RuleHeaderCapitationRepository)
        {
            _RuleHeaderCapitationRepository = RuleHeaderCapitationRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetRuleHeaderCapitations")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRuleHeaderCapitations(short RuleHeaderID)
        {
            var query = _RuleHeaderCapitationRepository.GetRuleHeaderCapitations(RuleHeaderID);
            return Ok(query);
        }
    }
}
