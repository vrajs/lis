using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.OrganizationRule;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json;

namespace Kwicle.Service.Controllers.Modules.OrganizationRule
{
    [Produces("application/json")]
    [Route("api/RuleHeaderEditRule")]
    public class RuleHeaderEditRuleAPIController : BaseAPIController
    {
        #region Property
        private IRuleHeaderEditRuleRepository _RuleHeaderEditRuleRepository;
        private IDBFieldRepository _DBFieldRepository;
        private IMapper _Mapper;
        private ILogger<RuleHeaderEditRuleAPIController> _Logger;
        private IRuleHeaderEditRuleCriteriaService _RuleHeaderEditRuleCriteriaService;
        #endregion

        #region Constructor
        public RuleHeaderEditRuleAPIController(ILogger<RuleHeaderEditRuleAPIController> logger, IMapper mapper, IRuleHeaderEditRuleRepository ruleHeaderEditRuleRepository, IDBFieldRepository dbFieldRepository, IRuleHeaderEditRuleCriteriaService ruleHeaderEditRuleCriteriaService)
        {
            _RuleHeaderEditRuleRepository = ruleHeaderEditRuleRepository;
            _Mapper = mapper;
            _Logger = logger;
            _DBFieldRepository = dbFieldRepository;
            _RuleHeaderEditRuleCriteriaService = ruleHeaderEditRuleCriteriaService;
        }
        #endregion

        #region Get Methods
        [HttpGet]
        [Route("GetCategory/{RuleHeaderID}")]
        public IActionResult GetCategory(short ruleHeaderID)
        {
            List<RuleHeaderEditRuleCategoryViewModel> catItems = _RuleHeaderEditRuleRepository.GetCategory(ruleHeaderID);
            return Ok(catItems);
        }

        [HttpGet]
        [Route("GetEdits/{RuleHeaderID}/{Category}")]
        public IActionResult GetEdits(short ruleHeaderID, string category)
        {
            List<RuleHeaderEditRuleViewModel> catItems = _RuleHeaderEditRuleRepository.GetEdits(ruleHeaderID, category);
            return Ok(catItems);
        }

        [HttpGet]
        [Route("GetByID/{RuleHeaderID}/{EditCodeID}")]
        public IActionResult GetByID(short ruleHeaderID, int editCodeID)
        {
            try
            {
                RuleHeaderEditRuleViewModel model = _RuleHeaderEditRuleRepository.GetByID(editCodeID, ruleHeaderID);
                if (model == null)
                    return NoContent();
                else
                    model.EditCodeCriterias = JsonConvert.DeserializeObject<List<RuleHeaderEditRuleCriteriaViewModel>>((model.CriteriaJson == null) ? "[]" : model.CriteriaJson);

                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "RuleHeaderEditRuleGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var entity = _RuleHeaderEditRuleRepository.GetById(id);
                if (entity == null) return NoContent();
                if (!_RuleHeaderEditRuleRepository.DbState.IsValid)
                {
                    _RuleHeaderEditRuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok(_Mapper.Map<RuleHeaderEditRuleViewModel>(entity));
            }
            catch (Exception ex)
            {
                _Logger.LogError("Error while Getting Edit Rule : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Post & Put & Delete Methods
        [HttpPost]
        public IActionResult Post([FromBody]RuleHeaderEditRuleViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _Mapper.Map<RuleHeaderEditRule>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                RuleHeaderEditRuleCriteria criteriaEntity = null;
                if (model.IsFreezed == (byte)FreezedStatus.NotFreezed)
                {
                    // Generate Criteria Entity
                    criteriaEntity = _RuleHeaderEditRuleCriteriaService.GenerateCriteriaWithSQLQuery(model);
                    criteriaEntity.CreatedDate = base.TodaysDate;
                    criteriaEntity.CreatedBy = base.UserName;
                    criteriaEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                    criteriaEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                }

                model.RuleHeaderEditRuleID = _RuleHeaderEditRuleRepository.InsertOrUpdate(entity, criteriaEntity);
                if (!_RuleHeaderEditRuleRepository.DbState.IsValid)
                {
                    _RuleHeaderEditRuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RuleHeaderEditRuleGet", new { id = entity.RuleHeaderEditRuleID });
                _Logger.LogInformation("New Edit Rule Created");
                return Created(newUri, entity.RuleHeaderEditRuleID);
            }
            catch (Exception ex)
            {
                _Logger.LogError("Exception thrown while saving Edit Rule : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]RuleHeaderEditRuleViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldEntity = _RuleHeaderEditRuleRepository.GetById(model.RuleHeaderEditRuleID);
                if (oldEntity == null) return NoContent();
                _Mapper.Map(model, oldEntity);
                oldEntity.UpdatedDate = base.TodaysDate;
                oldEntity.UpdatedBy = base.UserName;
                oldEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldEntity.EffectiveDate, oldEntity.TermDate);
                oldEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldEntity.EffectiveDate, oldEntity.TermDate).ToString();

                RuleHeaderEditRuleCriteria criteriaEntity = null;
                if (model.IsFreezed == (byte)FreezedStatus.NotFreezed)
                {
                    // Generate Criteria Entity
                    criteriaEntity = _RuleHeaderEditRuleCriteriaService.GenerateCriteriaWithSQLQuery(model);
                    criteriaEntity.UpdatedDate = base.TodaysDate;
                    criteriaEntity.UpdatedBy = base.UserName;
                    criteriaEntity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldEntity.EffectiveDate, oldEntity.TermDate);
                    criteriaEntity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldEntity.EffectiveDate, oldEntity.TermDate).ToString();
                }

                model.RuleHeaderEditRuleID = _RuleHeaderEditRuleRepository.InsertOrUpdate(oldEntity, criteriaEntity);
                if (!_RuleHeaderEditRuleRepository.DbState.IsValid)
                {
                    _RuleHeaderEditRuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok(model.RuleHeaderEditRuleID);

            }
            catch (Exception ex)
            {
                _Logger.LogError($"Exception thrown while updating Edit Rule :{ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{RuleHeaderEditRuleID}")]
        public IActionResult Delete(int ruleHeaderEditRuleID)
        {
            try
            {
                _RuleHeaderEditRuleRepository.Delete(ruleHeaderEditRuleID, base.UserName, base.TodaysDate);
                if (!_RuleHeaderEditRuleRepository.DbState.IsValid)
                {
                    _RuleHeaderEditRuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok(ruleHeaderEditRuleID);
            }
            catch (Exception ex)
            {
                _Logger.LogError("Error while deleting Edit Rule: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Enable Or Disable Edit
        [HttpGet]
        [Route("EnableDiableEdit/{RuleHeaderEditRuleID}/{IsEnabled}")]
        public IActionResult EnableDiableEdit(int ruleHeaderEditRuleID, bool isEnabled)
        {
            try
            {
                RuleHeaderEditRule oldEntity = _RuleHeaderEditRuleRepository.GetById(ruleHeaderEditRuleID);
                oldEntity.IsEnabled = isEnabled;
                oldEntity.UpdatedDate = base.TodaysDate;
                oldEntity.UpdatedBy = base.UserName;
                _RuleHeaderEditRuleRepository.Update(oldEntity);
                if (!_RuleHeaderEditRuleRepository.DbState.IsValid)
                {
                    _RuleHeaderEditRuleRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok(ruleHeaderEditRuleID);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
