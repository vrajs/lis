using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimUBCodes")]
    public class ClaimUBCodesAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimUBCodesAPIController> _logger;
        private IClaimUBCodesRepository _ClaimUBCodesRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimUBCodesAPIController(ILogger<ClaimUBCodesAPIController> logger, IClaimUBCodesRepository ClaimUBCodesRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimUBCodesRepository = ClaimUBCodesRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var claimUBCodesRes = _ClaimUBCodesRepository.GetAllClaimUBCodes();
                if (!_ClaimUBCodesRepository.DbState.IsValid)
                {
                    _ClaimUBCodesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimUBCodesViewModel>>(claimUBCodesRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimUBCodes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimUBCodesGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var claimUBCodes = _ClaimUBCodesRepository.GetById(id);
                if (claimUBCodes == null) return NotFound($"ClaimUBCodes {id} was not Found");
                if (!_ClaimUBCodesRepository.DbState.IsValid)
                {
                    _ClaimUBCodesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimUBCodesViewModel>(claimUBCodes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimUBCodes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimUBCodesViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var claimUBCodes = _mapper.Map<ClaimUBCodes>(model);
                claimUBCodes.CreatedDate = base.TodaysDate;
                claimUBCodes.CreatedBy = base.UserName;
                claimUBCodes.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, claimUBCodes.FromDate, claimUBCodes.ToDate);
                claimUBCodes.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, claimUBCodes.FromDate, claimUBCodes.ToDate).ToString();

                _ClaimUBCodesRepository.Add(claimUBCodes);
                if (!_ClaimUBCodesRepository.DbState.IsValid)
                {
                    _ClaimUBCodesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimUBCodesGet", new { id = claimUBCodes.ClaimUBCodesID });
                _logger.LogInformation("New ClaimUBCodes Created");
                return Created(newUri, claimUBCodes.ClaimUBCodesID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimUBCodes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimUBCodesViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimUBCodes = _ClaimUBCodesRepository.GetById(model.ClaimUBCodesID);

                if (oldClaimUBCodes == null) return NotFound($"Could not find a ClaimUBCodes with an ClaimUBCodesID of {model.ClaimUBCodesID}");

                _mapper.Map(model, oldClaimUBCodes);
                oldClaimUBCodes.UpdatedBy = base.UserName;
                oldClaimUBCodes.UpdatedDate = base.TodaysDate;
                oldClaimUBCodes.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldClaimUBCodes.FromDate, oldClaimUBCodes.ToDate);
                oldClaimUBCodes.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldClaimUBCodes.FromDate, oldClaimUBCodes.ToDate).ToString();

                _ClaimUBCodesRepository.Update(oldClaimUBCodes);
                if (!_ClaimUBCodesRepository.DbState.IsValid)
                {
                    _ClaimUBCodesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.ClaimUBCodesID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimUBCodes :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimUBCodesRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimUBCodes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
