using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Claim;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/RefundNote")]
    public class RefundNoteAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundNoteAPIController> _logger;
        private IRefundNoteRepository _RefundNoteRepository;
        private IRefundNoteService _RefundNoteService;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RefundNoteAPIController(ILogger<RefundNoteAPIController> logger, IClaimHeaderRepository ClaimHeaderRepository, IRefundNoteRepository RefundNoteRepository, IMapper mapper, IRefundNoteService IRefundNoteService)
        {
            _logger = logger;
            _RefundNoteRepository = RefundNoteRepository;
            _mapper = mapper;
            _RefundNoteService = IRefundNoteService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var RefundNoteRes = _RefundNoteRepository.GetAllRefundNote();
                if (!_RefundNoteRepository.DbState.IsValid)
                {
                    _RefundNoteRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<RefundNoteViewModel>>(RefundNoteRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundNote : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RefundNoteGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var RefundNote = _RefundNoteRepository.GetById(id);
                if (RefundNote == null) return NotFound($"RefundNote {id} was not Found");
                if (!_RefundNoteRepository.DbState.IsValid)
                {
                    _RefundNoteRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RefundNoteViewModel>(RefundNote));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundNote : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  RefundNoteViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<RefundNote>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                //Check Business logic
                _RefundNoteService.CheckBusinessLogicWhileInsertOrUpdate(entity);
                if (!_RefundNoteService.BusinessState.IsValid)
                {
                    _RefundNoteService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                // Insert Data
                _RefundNoteRepository.Add(entity);
                if (!_RefundNoteRepository.DbState.IsValid)
                {
                    _RefundNoteRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RefundNoteGet", new { id = entity.RefundNoteID });
                _logger.LogInformation("New Refund Received Created");
                return Created(newUri, _mapper.Map<RefundNoteViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Refund Received : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]  RefundNoteViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = _RefundNoteRepository.GetById(model.RefundNoteID);
                if (entity == null) return NoContent();

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                //Check Business logic
                _RefundNoteService.CheckBusinessLogicWhileInsertOrUpdate(entity);
                if (!_RefundNoteService.BusinessState.IsValid)
                {
                    _RefundNoteService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }


                // Update data
                _RefundNoteRepository.Update(entity);
                if (!_RefundNoteRepository.DbState.IsValid)
                {
                    _RefundNoteRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RefundNoteViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Refund Received: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _RefundNoteRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RefundNote : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
