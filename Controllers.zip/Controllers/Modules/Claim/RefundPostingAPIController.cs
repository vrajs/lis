using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/RefundPosting")]
    public class RefundPostingAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundPostingAPIController> _logger;
        private IRefundPostingRepository _RefundPostingRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RefundPostingAPIController(ILogger<RefundPostingAPIController> logger, IClaimHeaderRepository ClaimHeaderRepository, IRefundPostingRepository RefundPostingRepository, IMapper mapper)
        {
            _logger = logger;
            _RefundPostingRepository = RefundPostingRepository;
            _mapper = mapper;
            _ClaimHeaderRepository = ClaimHeaderRepository;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var RefundPostingRes = _RefundPostingRepository.GetAllRefundPosting();
                if (!_RefundPostingRepository.DbState.IsValid)
                {
                    _RefundPostingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<RefundPostingViewModel>>(RefundPostingRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundPosting : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RefundPostingGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var RefundPosting = _RefundPostingRepository.GetById(id);
                if (RefundPosting == null) return NotFound($"RefundPosting {id} was not Found");
                if (!_RefundPostingRepository.DbState.IsValid)
                {
                    _RefundPostingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<RefundPostingViewModel>(RefundPosting));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundPosting : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  RefundPostingViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<RefundPosting>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)(RecordStatus.Active);
                entity.RecordStatusChangeComment = Convert.ToString(RecordStatus.Active);

                // Insert Data
                _RefundPostingRepository.Add(entity);
                if (!_RefundPostingRepository.DbState.IsValid)
                {
                    _RefundPostingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RefundPostingGet", new { id = entity.RefundPostingID });
                _logger.LogInformation("New Refund Received Created");
                return Created(newUri, _mapper.Map<RefundPostingViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Refund Received : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]  RefundPostingViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = _RefundPostingRepository.GetById(model.RefundPostingID);
                if (entity == null) return NoContent();

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                // Update data
                _RefundPostingRepository.Update(entity);
                if (!_RefundPostingRepository.DbState.IsValid)
                {
                    _RefundPostingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RefundPostingViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Refund Received: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _RefundPostingRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RefundPosting : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
