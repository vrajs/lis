using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Data.Contracts.Masters;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimOtherInsurance")]
    public class ClaimOtherInsuranceAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimOtherInsuranceAPIController> _logger;
        private IClaimOtherInsuranceRepository _ClaimOtherInsuranceRepository;
        private IMapper _mapper;
        private IMemberCOBRepository _IMemberCOBRepository;
        private ICommonClinicalCodeService _CommonClinicalCodeService;

        #endregion

        #region Ctor
        public ClaimOtherInsuranceAPIController(ILogger<ClaimOtherInsuranceAPIController> logger, ICommonClinicalCodeService CommonClinicalCodeService, IMemberCOBRepository MemberCOBRepository, IClaimOtherInsuranceRepository ClaimOtherInsuranceRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimOtherInsuranceRepository = ClaimOtherInsuranceRepository;
            _mapper = mapper;
            _IMemberCOBRepository = MemberCOBRepository;
            _CommonClinicalCodeService = CommonClinicalCodeService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var ClaimOtherInsuranceRes = _ClaimOtherInsuranceRepository.GetAllClaimOtherInsurance();
                if (!_ClaimOtherInsuranceRepository.DbState.IsValid)
                {
                    _ClaimOtherInsuranceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimOtherInsuranceViewModel>>(ClaimOtherInsuranceRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimOtherInsurance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimOtherInsuranceGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var ClaimOtherInsurance = _ClaimOtherInsuranceRepository.GetById(id);
                if (ClaimOtherInsurance == null) return NotFound($"ClaimOtherInsurance {id} was not Found");
                if (!_ClaimOtherInsuranceRepository.DbState.IsValid)
                {
                    _ClaimOtherInsuranceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimOtherInsuranceViewModel>(ClaimOtherInsurance));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimOtherInsurance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimOtherInsuranceViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var ClaimOtherInsuranceModel = _mapper.Map<ClaimOtherInsurance>(model);
                ClaimOtherInsuranceModel.CreatedDate = base.TodaysDate;
                ClaimOtherInsuranceModel.CreatedBy = base.UserName;

                ClaimOtherInsuranceModel.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, ClaimOtherInsuranceModel.DOSFrom, ClaimOtherInsuranceModel.DOSTo);
                ClaimOtherInsuranceModel.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, ClaimOtherInsuranceModel.DOSFrom, ClaimOtherInsuranceModel.DOSTo).ToString();
                //if (ClaimOtherInsurance.ServiceLineNumber != 0) { 
                //var lineNo = _ClaimOtherInsuranceRepository.GetByPredicate(i => i.ClaimHeaderID == ClaimOtherInsurance.ClaimHeaderID && i.ServiceLineNumber != 0).LastOrDefault();
                //var obj = (lineNo != null) ? (ClaimOtherInsurance.ServiceLineNumber=(short)(lineNo.ServiceLineNumber+1 != ClaimOtherInsurance.ServiceLineNumber? lineNo.ServiceLineNumber + 1: ClaimOtherInsurance.ServiceLineNumber)) : 0;
                //}

                ClaimOtherInsuranceModel = _ClaimOtherInsuranceRepository.GetInsuranceID(model.MemberID, ClaimOtherInsuranceModel);
                if (ClaimOtherInsuranceModel.InsuranceCarrierID.Equals(0) || ClaimOtherInsuranceModel.InsuranceCarrierID.Equals(null))
                {
                    return BadRequest("Given Member dont have any InsuranceCarrier");
                }
                if (!string.IsNullOrEmpty(model.ProcedureCode))
                {
                    var cpt2code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT2, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var cpt4code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT4, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var hcpcscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.HCPCS, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    if (!(cpt2code) && !(cpt4code) && !(hcpcscode))
                    {
                        return BadRequest("Invalid Procedure Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.POSCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.POS, model.POSCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid POS Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.RevenueCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.UBRevenue, model.RevenueCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid Revenue Code");
                    }
                }

                _ClaimOtherInsuranceRepository.Add(ClaimOtherInsuranceModel);
                if (!_ClaimOtherInsuranceRepository.DbState.IsValid)
                {
                    _ClaimOtherInsuranceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimOtherInsuranceGet", new { id = ClaimOtherInsuranceModel.ClaimOtherInsuranceID });
                _logger.LogInformation("New ClaimOtherInsurance Created");
                return Created(newUri, ClaimOtherInsuranceModel.ClaimOtherInsuranceID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimOtherInsurance : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimOtherInsuranceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimOtherInsurance = _ClaimOtherInsuranceRepository.GetById(model.ClaimOtherInsuranceID);

                if (oldClaimOtherInsurance == null) return NotFound($"Could not find a ClaimOtherInsurance with an ClaimOtherInsuranceID of {model.ClaimOtherInsuranceID}");

                _mapper.Map(model, oldClaimOtherInsurance);
                oldClaimOtherInsurance.UpdatedBy = base.UserName;
                oldClaimOtherInsurance.UpdatedDate = base.TodaysDate;
                oldClaimOtherInsurance.DOSFrom = oldClaimOtherInsurance.DOSFrom.Date;
                oldClaimOtherInsurance.DOSTo = oldClaimOtherInsurance.DOSTo.Date;
                oldClaimOtherInsurance.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldClaimOtherInsurance.DOSFrom, oldClaimOtherInsurance.DOSTo);
                oldClaimOtherInsurance.RecordStatusChangeComment = (string)Utility.GetRecordStatus(base.TodaysDate, oldClaimOtherInsurance.DOSFrom, oldClaimOtherInsurance.DOSTo).ToString();
                //oldClaimOtherInsurance.SourceInsuranceName = string.Empty;
                //var lineNo = _ClaimOtherInsuranceRepository.GetByPredicate(i=>i.ClaimHeaderID==oldClaimOtherInsurance.ClaimHeaderID && i.ServiceLineNumber!=0).LastOrDefault();
                //var obj= (lineNo != null) ? (oldClaimOtherInsurance.ServiceLineNumber = (short)(oldClaimOtherInsurance.ServiceLineNumber == -1 ? lineNo.ServiceLineNumber + 1 : oldClaimOtherInsurance.ServiceLineNumber)) : (oldClaimOtherInsurance.ServiceLineNumber=1);
                if (!string.IsNullOrEmpty(model.ProcedureCode))
                {
                    var cpt2code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT2, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var cpt4code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT4, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var hcpcscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.HCPCS, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    if (!(cpt2code) && !(cpt4code) && !(hcpcscode))
                    {
                        return BadRequest("Invalid Procedure Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.POSCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.POS, model.POSCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid POS Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.RevenueCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.UBRevenue, model.RevenueCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid Revenue Code");
                    }
                }

                _ClaimOtherInsuranceRepository.Update(oldClaimOtherInsurance);
                if (!_ClaimOtherInsuranceRepository.DbState.IsValid)
                {
                    _ClaimOtherInsuranceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.ClaimOtherInsuranceID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimOtherInsurance :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimOtherInsuranceRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimOtherInsurance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
