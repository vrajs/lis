using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimNotes")]
    public class ClaimNotesAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimNotesAPIController> _logger;
        private IClaimNotesRepository _ClaimNotesRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimNotesAPIController(ILogger<ClaimNotesAPIController> logger, IClaimHeaderRepository ClaimHeaderRepository, IClaimNotesRepository ClaimNotesRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimNotesRepository = ClaimNotesRepository;
            _ClaimHeaderRepository = ClaimHeaderRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods

        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var claimNoteRes = _ClaimNotesRepository.GetAllClaimNotes();
                if (!_ClaimNotesRepository.DbState.IsValid)
                {
                    _ClaimNotesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimNotesViewModel>>(claimNoteRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimNotess : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimNotesGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var claimNote = _ClaimNotesRepository.GetById(id);
                if (claimNote == null) return NotFound($"ClaimNotes {id} was not Found");
                if (!_ClaimNotesRepository.DbState.IsValid)
                {
                    _ClaimNotesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimNotesViewModel>(claimNote));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimNotes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimNotesViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var claimNote = _mapper.Map<ClaimNotes>(model);
                claimNote.CreatedDate = base.TodaysDate;
                claimNote.CreatedBy = base.UserName;
                claimNote.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, claimNote.EffectiveDate, claimNote.TermDate);
                claimNote.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, claimNote.EffectiveDate, claimNote.TermDate).ToString();
                claimNote.NoteDate = base.TodaysDate;

                var memberID = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == claimNote.ClaimHeaderID).FirstOrDefault().MemberID;
                claimNote.MemberID = memberID;

                _ClaimNotesRepository.Add(claimNote);
                if (!_ClaimNotesRepository.DbState.IsValid)
                {
                    _ClaimNotesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimNotesGet", new { id = claimNote.ClaimNotesID });
                _logger.LogInformation("New ClaimNotes Created");
                return Created(newUri, claimNote.ClaimNotesID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimNotes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion

    }
}
