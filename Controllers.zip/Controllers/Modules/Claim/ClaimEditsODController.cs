using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimEditsODController : BaseODController
    {
        #region Variables        
        private IClaimEditsRepository _ClaimEditsRepository;
        #endregion

        #region Ctor        
        public ClaimEditsODController(IClaimEditsRepository ClaimEditsRepository)
        {
            _ClaimEditsRepository = ClaimEditsRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimEdits")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, EnsureStableOrdering = false)]
        public IActionResult GetClaimEdits(long ClaimHeaderID)
        {
            var ClaimEditsQuery = _ClaimEditsRepository.GetClaimEdits(ClaimHeaderID);
            return Ok(ClaimEditsQuery);
        }
    }
}
