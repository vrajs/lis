using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Claim;
using Kwicle.Data.Contracts.Masters;
using System.Net;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimDiagnosis")]
    public class ClaimDiagnosisAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimDiagnosisAPIController> _logger;
        private IClaimDiagnosisRepository _ClaimDiagnosisRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IClaimDiagnosisService _ClaimDiagnosisService;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimDiagnosisAPIController(ILogger<ClaimDiagnosisAPIController> logger, IClaimDiagnosisService ClaimDiagnosisService, IClaimHeaderRepository ClaimHeaderRepository, IClaimDiagnosisRepository ClaimDiagnosisRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimDiagnosisRepository = ClaimDiagnosisRepository;
            _mapper = mapper;
            _ClaimHeaderRepository = ClaimHeaderRepository;
            _ClaimDiagnosisService = ClaimDiagnosisService;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var claimDiagnosisRes = _ClaimDiagnosisRepository.GetAllClaimDiagnosis();
                if (!_ClaimDiagnosisRepository.DbState.IsValid)
                {
                    _ClaimDiagnosisRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimDiagnosisViewModel>>(claimDiagnosisRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimDiagnosis : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimDiagnosisGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var claimDiagnosis = _ClaimDiagnosisRepository.GetById(id);
                if (claimDiagnosis == null) return NotFound($"ClaimDiagnosis {id} was not Found");
                if (!_ClaimDiagnosisRepository.DbState.IsValid)
                {
                    _ClaimDiagnosisRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimDiagnosisViewModel>(claimDiagnosis));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimDiagnosis : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] ClaimDiagnosisViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var claimDiagnosis = _mapper.Map<ClaimDiagnosis>(model);
                claimDiagnosis.CreatedDate = base.TodaysDate;
                claimDiagnosis.CreatedBy = base.UserName;
                claimDiagnosis.RecordStatus = (byte)(RecordStatus.Active);
                claimDiagnosis.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _ClaimDiagnosisService.MaxDiagnosisCodeValidation(claimDiagnosis.ClaimHeaderID);

                claimDiagnosis.DiagnosisPointer = _ClaimDiagnosisService.ClaimDiagnosisPointer(model);

                _ClaimDiagnosisService.CheckCodesEffective(model);
                if (!_ClaimDiagnosisService.BusinessState.IsValid)
                {
                    _ClaimDiagnosisService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                    //return BadRequest(ModelState);
                }
                var result = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == claimDiagnosis.ClaimHeaderID);
                var memberID = result != null ? result.FirstOrDefault().MemberID : 0;
                claimDiagnosis.MemberID = memberID;
                _ClaimDiagnosisRepository.Add(claimDiagnosis);
                if (!_ClaimDiagnosisRepository.DbState.IsValid)
                {
                    _ClaimDiagnosisRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimDiagnosisGet", new { id = claimDiagnosis.ClaimDiagnosisID });
                _logger.LogInformation("New ClaimDiagnosis Created");
                return Created(newUri, claimDiagnosis.ClaimDiagnosisID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimDiagnosis : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody] ClaimDiagnosisViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimDiagnosis = _ClaimDiagnosisRepository.GetById(model.ClaimDiagnosisID);

                if (oldClaimDiagnosis == null) return NotFound($"Could not find a ClaimDiagnosis with an ClaimDiagnosisID of {model.ClaimDiagnosisID}");

                _mapper.Map(model, oldClaimDiagnosis);
                oldClaimDiagnosis.UpdatedBy = base.UserName;
                oldClaimDiagnosis.UpdatedDate = base.TodaysDate;
                var memberID = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == oldClaimDiagnosis.ClaimHeaderID).FirstOrDefault().MemberID;
                oldClaimDiagnosis.MemberID = memberID;

                oldClaimDiagnosis.DiagnosisPointer = _ClaimDiagnosisService.ClaimDiagnosisPointer(model);

                _ClaimDiagnosisService.CheckCodesEffective(model);
                if (!_ClaimDiagnosisService.BusinessState.IsValid)
                {
                    _ClaimDiagnosisService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                    //return BadRequest(ModelState);
                }

                _ClaimDiagnosisRepository.Update(oldClaimDiagnosis);
                if (!_ClaimDiagnosisRepository.DbState.IsValid)
                {
                    _ClaimDiagnosisRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.ClaimDiagnosisID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimDiagnosis :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimDiagnosisRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimDiagnosis : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetClaimDiagnosis/{ClaimHeaderID}")]
        public IActionResult GetClaimDiagnosis(int claimHeaderID)
        {
            var diagnosisList = _ClaimDiagnosisRepository.GetClaimDiagnosis(claimHeaderID).ToList();
            return Ok(diagnosisList);
        }
        #endregion
    }
}
