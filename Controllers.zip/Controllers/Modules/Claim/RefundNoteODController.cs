using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    //[EnableCors("AnyGet")]
    [Route("odata")]
    public class RefundNoteODController : BaseODController
    {
        #region Variables        
        private IRefundNoteRepository _RefundNoteRepository;
        #endregion

        #region Ctor        
        public RefundNoteODController(IRefundNoteRepository RefundNoteRepository)
        {
            _RefundNoteRepository = RefundNoteRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RefundNote")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetRefundNote(int RefundRequestID)
        {
            var RefundNoteQuery = _RefundNoteRepository.GetRefundNote(RefundRequestID);
            return Ok(RefundNoteQuery);
        }

    }
}
