using System;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Kwicle.Core.Common;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimDiagnosisODController : BaseODController
    {
        #region Variables        
        private IClaimDiagnosisRepository _ClaimDiagnosisRepository;
        #endregion

        #region Ctor        
        public ClaimDiagnosisODController(IClaimDiagnosisRepository ClaimDiagnosisRepository)
        {
            _ClaimDiagnosisRepository = ClaimDiagnosisRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimDiagnosis")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimDiagnosis(long ClaimHeaderID)
        {
            var ClaimDiagnosisQuery = _ClaimDiagnosisRepository.GetClaimDiagnosis(ClaimHeaderID);
            return Ok(ClaimDiagnosisQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimDiagnosisProcedure")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimDiagnosisProcedure(long ClaimHeaderID)
        {
            var ClaimDiagnosisProcedureQuery = _ClaimDiagnosisRepository.GetClaimDiagnosisProcedure(ClaimHeaderID);
            return Ok(ClaimDiagnosisProcedureQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("DiagnosisGetBYClaimHeaderID")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetBYClaimHeaderID(long ClaimHeaderID)
        {
            try
            {
                var claimDiagnosis = _ClaimDiagnosisRepository.GetByPredicate(p => p.ClaimHeaderID == ClaimHeaderID && p.RecordStatus == (byte)RecordStatus.Active);
                if (claimDiagnosis == null) return NotFound($"ClaimDiagnosis ClaimHeaderID {ClaimHeaderID} was not Found");
                if (!_ClaimDiagnosisRepository.DbState.IsValid)
                {
                    _ClaimDiagnosisRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(claimDiagnosis);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
