using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    //[EnableCors("AnyGet")]
    [Route("odata")]
    public class RefundReceivedODController : BaseODController
    {
        #region Variables        
        private IRefundReceivedRepository _RefundReceivedRepository;
        #endregion

        #region Ctor        
        public RefundReceivedODController(IRefundReceivedRepository RefundReceivedRepository)
        {
            _RefundReceivedRepository = RefundReceivedRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RefundReceived")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetRefundReceived(int RefundRequestID)
        {
            var RefundReceivedQuery = _RefundReceivedRepository.GetRefundReceived(RefundRequestID);
            return Ok(RefundReceivedQuery);
        }

    }
}
