using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimEOBEOP")]
    public class ClaimEOBEOPAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimEOBEOPAPIController> _logger;
        private IClaimEOBEOPRepository _ClaimEOBEOPRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimEOBEOPAPIController(ILogger<ClaimEOBEOPAPIController> logger, IClaimEOBEOPRepository ClaimEOBEOPRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimEOBEOPRepository = ClaimEOBEOPRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var ClaimEOBEOPRes = _ClaimEOBEOPRepository.GetAllClaimEOBEOP();
                if (!_ClaimEOBEOPRepository.DbState.IsValid)
                {
                    _ClaimEOBEOPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimEOBEOPViewModel>>(ClaimEOBEOPRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimEOBEOP : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimEOBEOPGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var ClaimEOBEOP = _ClaimEOBEOPRepository.GetById(id);
                if (ClaimEOBEOP == null) return NotFound($"ClaimEOBEOP {id} was not Found");
                if (!_ClaimEOBEOPRepository.DbState.IsValid)
                {
                    _ClaimEOBEOPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimEOBEOPViewModel>(ClaimEOBEOP));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimEOBEOP : {0}", ex);
                return BadRequest(ex.Message);
            }
        }




        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimEOBEOPViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var ClaimEOBEOP = _mapper.Map<ClaimEOBEOP>(model);
                ClaimEOBEOP.CreatedDate = base.TodaysDate;
                ClaimEOBEOP.CreatedBy = base.UserName;
                ClaimEOBEOP.RecordStatus = (byte)RecordStatus.Active;
                ClaimEOBEOP.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _ClaimEOBEOPRepository.Add(ClaimEOBEOP);
                if (!_ClaimEOBEOPRepository.DbState.IsValid)
                {
                    _ClaimEOBEOPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimEOBEOPGet", new { id = ClaimEOBEOP.ClaimEOBEOPID });
                _logger.LogInformation("New ClaimEOBEOP Created");
                return Created(newUri, ClaimEOBEOP.ClaimEOBEOPID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimEOBEOP : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimEOBEOPViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimEOBEOP = _ClaimEOBEOPRepository.GetById(model.ClaimEOBEOPID);

                if (oldClaimEOBEOP == null) return NotFound($"Could not find a ClaimEOBEOP with an ClaimEOBEOPID of {model.ClaimEOBEOPID}");

                _mapper.Map(model, oldClaimEOBEOP);
                oldClaimEOBEOP.UpdatedBy = base.UserName;
                oldClaimEOBEOP.UpdatedDate = base.TodaysDate;

                _ClaimEOBEOPRepository.Update(oldClaimEOBEOP);
                if (!_ClaimEOBEOPRepository.DbState.IsValid)
                {
                    _ClaimEOBEOPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.ClaimEOBEOPID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimEOBEOP :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimEOBEOPRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimEOBEOP : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
