using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    //[EnableCors("AnyGet")]
    [Route("odata")]
    public class RefundLetterODController : BaseODController
    {
        #region Variables        
        private IRefundLetterRepository _RefundLetterRepository;
        #endregion

        #region Ctor        
        public RefundLetterODController(IRefundLetterRepository RefundLetterRepository)
        {
            _RefundLetterRepository = RefundLetterRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RefundLetterHistory")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetRefundLetterHistory(int RefundRequestID)
        {
            var letterHistoryQuery = _RefundLetterRepository.GetRefundLetterHistory(RefundRequestID);
            return Ok(letterHistoryQuery);
        }

    }
}
