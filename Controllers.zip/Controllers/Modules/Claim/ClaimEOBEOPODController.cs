using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimEOBEOPODController : BaseODController
    {
        #region Variables        
        private IClaimEOBEOPRepository _ClaimEOBEOPRepository;
        #endregion

        #region Ctor        
        public ClaimEOBEOPODController(IClaimEOBEOPRepository ClaimEOBEOPRepository)
        {
            _ClaimEOBEOPRepository = ClaimEOBEOPRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimEOBEOP")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimEOBEOP(long ClaimHeaderID, int EOBEOPTypeID)
        {
            var ClaimEOBEOPQuery = _ClaimEOBEOPRepository.GetClaimEOBEOP(ClaimHeaderID, EOBEOPTypeID);
            return Ok(ClaimEOBEOPQuery);
        }
    }
}
