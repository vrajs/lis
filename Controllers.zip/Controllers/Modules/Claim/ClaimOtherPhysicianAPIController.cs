using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimOtherPhysician")]
    public class ClaimOtherPhysicianAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimOtherPhysicianAPIController> _logger;
        private IClaimOtherPhysicianRepository _ClaimOtherPhysicianRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimOtherPhysicianAPIController(ILogger<ClaimOtherPhysicianAPIController> logger, IClaimOtherPhysicianRepository ClaimOtherPhysicianRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimOtherPhysicianRepository = ClaimOtherPhysicianRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var claimOtherPhysicianRes = _ClaimOtherPhysicianRepository.GetAllClaimOtherPhysician();
                if (!_ClaimOtherPhysicianRepository.DbState.IsValid)
                {
                    _ClaimOtherPhysicianRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimOtherPhysicianViewModel>>(claimOtherPhysicianRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimOtherPhysician : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimOtherPhysicianGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var claimOtherPhysician = _ClaimOtherPhysicianRepository.GetById(id);
                if (claimOtherPhysician == null) return NotFound($"ClaimOtherPhysician {id} was not Found");
                if (!_ClaimOtherPhysicianRepository.DbState.IsValid)
                {
                    _ClaimOtherPhysicianRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<ClaimOtherPhysicianViewModel>(claimOtherPhysician));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimOtherPhysician : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimOtherPhysicianViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var claimOtherPhysician = _mapper.Map<ClaimOtherPhysician>(model);
                claimOtherPhysician.CreatedDate = base.TodaysDate;
                claimOtherPhysician.CreatedBy = base.UserName;
                claimOtherPhysician.RecordStatus = (byte)(RecordStatus.Active);
                claimOtherPhysician.RecordStatusChangeComment = RecordStatus.Active.ToString();
                _ClaimOtherPhysicianRepository.Add(claimOtherPhysician);
                if (!_ClaimOtherPhysicianRepository.DbState.IsValid)
                {
                    _ClaimOtherPhysicianRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimOtherPhysicianGet", new { id = claimOtherPhysician.ClaimOtherPhysicianID });
                _logger.LogInformation("New ClaimOtherPhysician Created");
                return Created(newUri, claimOtherPhysician.ClaimOtherPhysicianID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimOtherPhysician : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimOtherPhysicianViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimOtherPhysician = _ClaimOtherPhysicianRepository.GetById(model.ClaimOtherPhysicianID);

                if (oldClaimOtherPhysician == null) return NotFound($"Could not find a ClaimOtherPhysician with an ClaimOtherPhysicianID of {model.ClaimOtherPhysicianID}");

                _mapper.Map(model, oldClaimOtherPhysician);
                oldClaimOtherPhysician.UpdatedBy = base.UserName;
                oldClaimOtherPhysician.UpdatedDate = base.TodaysDate;


                _ClaimOtherPhysicianRepository.Update(oldClaimOtherPhysician);
                if (!_ClaimOtherPhysicianRepository.DbState.IsValid)
                {
                    _ClaimOtherPhysicianRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.ClaimOtherPhysicianID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimOtherPhysician :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimOtherPhysicianRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimOtherPhysician : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
