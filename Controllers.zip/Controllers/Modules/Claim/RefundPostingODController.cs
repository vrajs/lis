using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    //[EnableCors("AnyGet")]
    [Route("odata")]
    public class RefundPostingODController : BaseODController
    {
        #region Variables        
        private IRefundPostingRepository _RefundPostingRepository;
        #endregion

        #region Ctor        
        public RefundPostingODController(IRefundPostingRepository RefundPostingRepository)
        {
            _RefundPostingRepository = RefundPostingRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RefundPosting")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetRefundPosting(int RefundRequestID)
        {
            var RefundPostingQuery = _RefundPostingRepository.GetRefundPosting(RefundRequestID);
            return Ok(RefundPostingQuery);
        }

    }
}
