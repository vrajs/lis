using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Data.Repositories.View;
using Kwicle.Data.Contracts.View;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/RefundLetter")]
    public class RefundLetterAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundLetterAPIController> _logger;
        private IRefundLetterRepository _RefundLetterRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        private IViewRepository _ViewRepository;
        #endregion

        #region Ctor
        public RefundLetterAPIController(ILogger<RefundLetterAPIController> logger, IViewRepository viewRepository, IClaimHeaderRepository ClaimHeaderRepository, IRefundLetterRepository RefundLetterRepository, IMapper mapper)
        {
            _logger = logger;
            _RefundLetterRepository = RefundLetterRepository;
            _mapper = mapper;
            _ClaimHeaderRepository = ClaimHeaderRepository;
            _ViewRepository = viewRepository;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var RefundLetterRes = _RefundLetterRepository.GetAllRefundLetter();
                if (!_RefundLetterRepository.DbState.IsValid)
                {
                    _RefundLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<RefundLetterViewModel>>(RefundLetterRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundLetter : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RefundLetterGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var RefundLetter = _RefundLetterRepository.GetById(id);
                if (RefundLetter == null) return NotFound($"RefundLetter {id} was not Found");
                if (!_RefundLetterRepository.DbState.IsValid)
                {
                    _RefundLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RefundLetterViewModel>(RefundLetter));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundLetter : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("Letter")]
        public IActionResult GetRefundLetter(int RefundRequestID, int RefundRequestClaimID)
        {
            var refundLetterQuery = _ViewRepository.GetClaimRefundLetter.Where(x => x.RefundRequestID == RefundRequestID && x.RefundRequestClaimID == RefundRequestClaimID);
            return Ok(refundLetterQuery);
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  RefundLetterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<RefundLetter>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)(RecordStatus.Active);
                entity.RecordStatusChangeComment = Convert.ToString(RecordStatus.Active);

                // Insert Data
                _RefundLetterRepository.Add(entity);
                if (!_RefundLetterRepository.DbState.IsValid)
                {
                    _RefundLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RefundLetterGet", new { id = entity.RefundLetterID });
                _logger.LogInformation("New Refund Received Created");
                return Created(newUri, _mapper.Map<RefundLetterViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Refund Received : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]  RefundLetterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = _RefundLetterRepository.GetById(model.RefundLetterID);
                if (entity == null) return NoContent();

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                // Update data
                _RefundLetterRepository.Update(entity);
                if (!_RefundLetterRepository.DbState.IsValid)
                {
                    _RefundLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Json(Ok(_mapper.Map<RefundLetterViewModel>(entity)));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Refund Received: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _RefundLetterRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RefundLetter : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
