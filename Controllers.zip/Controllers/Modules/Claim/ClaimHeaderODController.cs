using Microsoft.AspNetCore.Mvc;
using Kwicle.Service.Filters;
using Kwicle.Data.Contracts.View;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimHeaderODController : BaseODController
    {
        #region Variables  
        private IViewRepository _IViewRepository;
        #endregion

        #region Constructor

        public ClaimHeaderODController(IViewRepository IViewRepository)
        {
            _IViewRepository = IViewRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetClaimList()
        {
            var query = _IViewRepository.ClaimList;
            return Ok(query);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimLoockup")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetClaimLoockup()
        {
            var query = _IViewRepository.ClaimLoockups;
            return Ok(query);
        }
    }
}
