using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimReferenceODController : BaseODController
    {
        #region Variables        
        private IClaimReferenceRepository _ClaimReferenceRepository;
        #endregion

        #region Ctor        
        public ClaimReferenceODController(IClaimReferenceRepository ClaimReferenceRepository)
        {
            _ClaimReferenceRepository = ClaimReferenceRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimReference")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimReference(long ClaimHeaderID)
        {
            var ClaimReferenceQuery = _ClaimReferenceRepository.GetClaimReference(ClaimHeaderID);
            return Ok(ClaimReferenceQuery);
        }
    }
}
