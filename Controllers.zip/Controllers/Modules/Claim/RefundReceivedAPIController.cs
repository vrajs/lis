using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/RefundReceived")]
    public class RefundReceivedAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundReceivedAPIController> _logger;
        private IRefundReceivedRepository _RefundReceivedRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RefundReceivedAPIController(ILogger<RefundReceivedAPIController> logger, IClaimHeaderRepository ClaimHeaderRepository, IRefundReceivedRepository RefundReceivedRepository, IMapper mapper)
        {
            _logger = logger;
            _RefundReceivedRepository = RefundReceivedRepository;
            _mapper = mapper;
            _ClaimHeaderRepository = ClaimHeaderRepository;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var RefundReceivedRes = _RefundReceivedRepository.GetAllRefundReceived();
                if (!_RefundReceivedRepository.DbState.IsValid)
                {
                    _RefundReceivedRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<RefundReceivedViewModel>>(RefundReceivedRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundReceived : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RefundReceivedGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var RefundReceived = _RefundReceivedRepository.GetById(id);
                if (RefundReceived == null) return NotFound($"RefundReceived {id} was not Found");
                if (!_RefundReceivedRepository.DbState.IsValid)
                {
                    _RefundReceivedRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RefundReceivedViewModel>(RefundReceived));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting RefundReceived : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  RefundReceivedViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<RefundReceived>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)(RecordStatus.Active);
                entity.RecordStatusChangeComment = Convert.ToString(RecordStatus.Active);

                // Insert Data
                _RefundReceivedRepository.Add(entity);
                if (!_RefundReceivedRepository.DbState.IsValid)
                {
                    _RefundReceivedRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("RefundReceivedGet", new { id = entity.RefundReceivedID });
                _logger.LogInformation("New Refund Received Created");
                return Created(newUri, _mapper.Map<RefundReceivedViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Refund Received : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]  RefundReceivedViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = _RefundReceivedRepository.GetById(model.RefundReceivedID);
                if (entity == null) return NoContent();

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                // Update data
                _RefundReceivedRepository.Update(entity);
                if (!_RefundReceivedRepository.DbState.IsValid)
                {
                    _RefundReceivedRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<RefundReceivedViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Refund Received: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _RefundReceivedRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting RefundReceived : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetAllRefundReceived/{RefundRequestID}")]
        public IActionResult GetAllRefundReceived(int RefundRequestID)
        {
            var query = _RefundReceivedRepository.GetRefundReceived(RefundRequestID);
            List<RefundReceivedViewModel> items = query.ToList();
            return Json(items);
        }
        #endregion
    }
}
