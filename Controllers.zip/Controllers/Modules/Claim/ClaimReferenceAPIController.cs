using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimReference")]
    public class ClaimReferenceAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimReferenceAPIController> _logger;
        private IClaimReferenceRepository _ClaimReferenceRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimReferenceAPIController(ILogger<ClaimReferenceAPIController> logger, IClaimHeaderRepository ClaimHeaderRepository, IClaimReferenceRepository ClaimReferenceRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimReferenceRepository = ClaimReferenceRepository;
            _mapper = mapper;
            _ClaimHeaderRepository = ClaimHeaderRepository;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var claimReferenceRes = _ClaimReferenceRepository.GetAllClaimReference();
                if (!_ClaimReferenceRepository.DbState.IsValid)
                {
                    _ClaimReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimReferenceViewModel>>(claimReferenceRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimReference : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimReferenceGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var claimReference = _ClaimReferenceRepository.GetById(id);
                if (claimReference == null) return NotFound($"ClaimReference {id} was not Found");
                if (!_ClaimReferenceRepository.DbState.IsValid)
                {
                    _ClaimReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimReferenceViewModel>(claimReference));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimReference : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimReferenceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var claimReference = _mapper.Map<ClaimReference>(model);
                claimReference.CreatedDate = base.TodaysDate;
                claimReference.CreatedBy = base.UserName;
                claimReference.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, claimReference.EffectiveDate, claimReference.TermDate);
                claimReference.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, claimReference.EffectiveDate, claimReference.TermDate).ToString();

                var memberID = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == claimReference.ClaimHeaderID).FirstOrDefault().MemberID;
                claimReference.MemberID = memberID;

                _ClaimReferenceRepository.Add(claimReference);
                if (!_ClaimReferenceRepository.DbState.IsValid)
                {
                    _ClaimReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimReferenceGet", new { id = claimReference.ClaimReferenceID });
                _logger.LogInformation("New ClaimReference Created");
                return Created(newUri, claimReference.ClaimReferenceID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimReference : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimReferenceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimReference = _ClaimReferenceRepository.GetById(model.ClaimReferenceID);

                if (oldClaimReference == null) return NotFound($"Could not find a ClaimReference with an ClaimReferenceID of {model.ClaimReferenceID}");

                _mapper.Map(model, oldClaimReference);
                oldClaimReference.UpdatedBy = base.UserName;
                oldClaimReference.UpdatedDate = base.TodaysDate;
                oldClaimReference.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldClaimReference.EffectiveDate, oldClaimReference.TermDate);
                oldClaimReference.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldClaimReference.EffectiveDate, oldClaimReference.TermDate).ToString();

                var memberID = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == oldClaimReference.ClaimHeaderID).FirstOrDefault().MemberID;
                oldClaimReference.MemberID = memberID;

                _ClaimReferenceRepository.Update(oldClaimReference);
                if (!_ClaimReferenceRepository.DbState.IsValid)
                {
                    _ClaimReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.ClaimReferenceID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimReference :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimReferenceRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimReference : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
