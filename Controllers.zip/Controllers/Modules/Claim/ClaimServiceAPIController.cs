using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Claim;
using Kwicle.Data.Contracts.Masters;
using System.Net;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimService")]
    public class ClaimServiceAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimServiceAPIController> _logger;
        private IClaimServiceRepository _ClaimServiceRepository;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        private ICommonAuditActions _ICommonAuditActions;
        private IClaimEOBEOPRepository _IClaimEOBEOPRepository;
        private ICommonClinicalCodeService _CommonClinicalCodeService;
        private IClaimServiceTermContractService _ClaimServiceTermContractService;
        private IClaimEditsRepository _ClaimEditsRepository;
        private IEditCodeRepository _IEditCodeRepository;
        #endregion

        #region Ctor
        public ClaimServiceAPIController(ILogger<ClaimServiceAPIController> logger, ICommonClinicalCodeService CommonClinicalCodeService, IClaimEOBEOPRepository ClaimEOBEOPRepository, ICommonAuditActions CommonAuditActions, IClaimServiceRepository ClaimServiceRepository, IClaimHeaderRepository ClaimHeaderRepository, IMapper mapper, IClaimServiceTermContractService ClaimServiceTermContractService, IClaimEditsRepository ClaimEditsRepository, IEditCodeRepository EditCodeRepository)
        {
            _logger = logger;
            _ClaimServiceRepository = ClaimServiceRepository;
            _mapper = mapper;
            _ClaimHeaderRepository = ClaimHeaderRepository;
            _ICommonAuditActions = CommonAuditActions;
            _IClaimEOBEOPRepository = ClaimEOBEOPRepository;
            _CommonClinicalCodeService = CommonClinicalCodeService;
            _ClaimServiceTermContractService=ClaimServiceTermContractService;
            _ClaimEditsRepository = ClaimEditsRepository;
            _IEditCodeRepository = EditCodeRepository;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var ClaimServiceRes = _ClaimServiceRepository.GetAllClaimService();
                if (!_ClaimServiceRepository.DbState.IsValid)
                {
                    _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimServiceViewModel>>(ClaimServiceRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimService : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimServiceGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var ClaimService = _ClaimServiceRepository.GetById(id);
                if (ClaimService == null) return NotFound($"ClaimService {id} was not Found");
                if (!_ClaimServiceRepository.DbState.IsValid)
                {
                    _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimServiceViewModel>(ClaimService));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimService : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("GetDollarValues")]
        public IActionResult PostDollarValues([FromBody]DollarsCalculationModel model)
        {
            var amtModel = _ClaimServiceRepository.GetDollarValues(model);
            if (!_ClaimServiceRepository.DbState.IsValid)
            {
                _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) => {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Json(amtModel);
        }

        [HttpGet]
        [Route("GetServiceContract")]
        public IActionResult GetServiceContract(int lOBID, DateTime dosFrom, DateTime dosTo)
        {
            var ServiceContract = _ClaimServiceRepository.GetServiceContract(lOBID, dosFrom, dosTo);
           
            if (!_ClaimServiceRepository.DbState.IsValid)
            {
                _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) => {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(ServiceContract);
        }

        [HttpGet]
        [Route("GetAnesthesiaUnit")]
        public IActionResult GetAnesthesiaUnit(string Code,int lOBID, DateTime DosFrom, DateTime DosTo)
        {
            var isAnesthesiaCode = _ClaimServiceRepository.AnesthesiaUnit(Code, lOBID, DosFrom, DosTo);

            if (!_ClaimServiceRepository.DbState.IsValid)
            {
                _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) => {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
            }
            return Ok(isAnesthesiaCode);
        }

        [HttpGet]
        [Route("GetAnesthesiaCalculatedAmount")]
        public IActionResult GetAnesthesiaCalculatedAmount(long ClaimHeaderID, int Unit, DateTime DosFrom, DateTime DosTo)
        {
            try
            {
                var amount = _ClaimServiceRepository.AnesthesiaCalculatedValue(ClaimHeaderID,Unit, DosFrom, DosTo);
                if (!_ClaimServiceRepository.DbState.IsValid)
                {
                    _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) => {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                return Ok(amount);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting AnesthesiaCalculatedAmount : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("GetClaimBenefits")]
        public IActionResult GetClaimBenefits(int MemberEligibilityID, byte MemberAge,int FormTypeID, DateTime DosFrom, DateTime DosTo, [FromBody] KeyValuePair<int, string>[] Codes)
        {
            var benefits = _ClaimServiceTermContractService.GetClaimBenefits(MemberEligibilityID, MemberAge, FormTypeID, Codes, DosFrom, DosTo);

            if (!_ClaimServiceTermContractService.BusinessState.IsValid)
            {
                _ClaimServiceTermContractService.BusinessState.ErrorMessages.ForEach((businessState) => {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
            }
            return Ok(benefits);
        }

        [HttpPost]
        [Route("GetServiceTermContract")]
        public IActionResult GetServiceTermContract(long ClaimHeaderID, string MemberGender, byte MemberAge, long? ServiceLineID, int ContractID, DateTime DosFrom, DateTime DosTo, [FromBody] KeyValuePair<int, string>[] Code)
        {
            var modelTermContract = ContractID > 0 ? _ClaimServiceTermContractService.GetContractTermFeeschedule(ContractID, MemberGender, MemberAge, Code, DosFrom, DosTo):null;
            if (!_ClaimServiceTermContractService.BusinessState.IsValid)
            {
                _ClaimServiceTermContractService.BusinessState.ErrorMessages.ForEach((businessState) => {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
            }
            
            if (modelTermContract != null) { 
                var claimService = _ClaimServiceRepository.GetByPredicate(x => x.ProviderContractTermID == modelTermContract.TermHeaderID && (!ServiceLineID.HasValue || x.ClaimServiceID != ServiceLineID) && x.ProviderContractTermID != 0 && x.RecordStatus != (int)RecordStatus.Deleted && x.ClaimHeaderID == ClaimHeaderID);
                if (claimService.Any()) {
                    modelTermContract = _ClaimServiceTermContractService.CalculateAllowableVisitType(modelTermContract, ServiceLineID, ClaimHeaderID, DosFrom, DosTo);
                }
            }
            return Ok(modelTermContract);
        }

        [HttpPost]
        [Route("GetServiceFeeSchedule")]
        public IActionResult GetServiceFeeSchedule(int ContractID, DateTime DosFrom, DateTime DosTo, [FromBody] KeyValuePair<int, string>[] Code)
        {
            var ServiceFeeSchedule =ContractID>0? _ClaimServiceRepository.GetServiceFeeSchedule(ContractID, Code, DosFrom, DosTo):null;

            if (!_ClaimServiceRepository.DbState.IsValid)
            {
                _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) => {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(ServiceFeeSchedule);
        }
        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimServiceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var claimService = _mapper.Map<ClaimService>(model);
                claimService.CreatedDate = base.TodaysDate;
                claimService.CreatedBy = base.UserName;
                claimService.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, claimService.DOSFrom, claimService.DOSTo);
                claimService.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, claimService.DOSFrom, claimService.DOSTo).ToString();

                claimService.MemberID = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == claimService.ClaimHeaderID).FirstOrDefault().MemberID;

                #region Claim Billed Amount Business Rules 
                var billedHeaderAmt = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == claimService.ClaimHeaderID).FirstOrDefault().BilledAmount;
                var sumBilledAmt = _ClaimServiceRepository.GetByPredicate(i => i.ClaimHeaderID == claimService.ClaimHeaderID && i.RecordStatus != (byte)RecordStatus.Deleted).Sum(x => x.BilledAmount);
                var totalBilledAmt = claimService.BilledAmount + sumBilledAmt;
                if (totalBilledAmt > billedHeaderAmt)
                {
                    return BadRequest($"Billed Amount should be equal or less than ${billedHeaderAmt - sumBilledAmt}");
                }
                #endregion

                var lineNo = _ClaimServiceRepository.GetByPredicate(i => i.ClaimHeaderID == claimService.ClaimHeaderID && i.LineNumber != 0).AsEnumerable().LastOrDefault();
                var obj = (lineNo != null) ? (claimService.LineNumber = (short)(lineNo.LineNumber + 1 != claimService.LineNumber ? lineNo.LineNumber + 1 : claimService.LineNumber)) : 1;
                claimService.LineNumber = (short)obj;
                model.LineNumber = (short)obj;

                if (!string.IsNullOrEmpty(model.ProcedureCode))
                {
                    var cpt2code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT2, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var cpt4code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT4, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var hcpcscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.HCPCS, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    if (!(cpt2code) && !(cpt4code) && !(hcpcscode))
                    {
                        return BadRequest("Invalid Procedure Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.POSCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.POS, model.POSCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid POS Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.RevenueCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.UBRevenue, model.RevenueCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid Revenue Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.RUGSCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.RUGS, model.RUGSCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid RUGS Code");
                    }
                }


                _ClaimServiceRepository.Add(claimService);
                if (!_ClaimServiceRepository.DbState.IsValid)
                {
                    _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                if (!string.IsNullOrEmpty(model.Code))
                {
                    #region EOBEOP ADD
                    EOBEOPAddUpdate(model);
                    if (!_IClaimEOBEOPRepository.DbState.IsValid)
                    {
                        _IClaimEOBEOPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                    #endregion
                }

                //if (!string.IsNullOrEmpty(model.EditCode)) {
                //    this.ADDEdits(model);
                //}

                var newUri = Url.Link("ClaimServiceGet", new { id = claimService.ClaimServiceID });
                _logger.LogInformation("New ClaimService Created");
                return Created(newUri, claimService.ClaimServiceID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimService : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimServiceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                int action = 0;
                var oldClaimService = _ClaimServiceRepository.GetById(model.ClaimServiceID);
                if (oldClaimService == null) return NotFound($"Could not find a ClaimService with an ClaimServiceID of {model.ClaimServiceID}");
                var revenueCode = model.RevenueCode == null ? "" : model.RevenueCode;
                if (oldClaimService.ProcedureCode != model.ProcedureCode || oldClaimService.RevenueCode != revenueCode)
                {
                    action = (int)Actions.ProcedureorRevCodeUpdate;
                }

                _mapper.Map(model, oldClaimService);
                oldClaimService.UpdatedBy = base.UserName;
                oldClaimService.UpdatedDate = base.TodaysDate;
                oldClaimService.DOSFrom = oldClaimService.DOSFrom.Date;
                oldClaimService.DOSTo = oldClaimService.DOSTo.Date;
                oldClaimService.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldClaimService.DOSFrom, oldClaimService.DOSTo);
                oldClaimService.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldClaimService.DOSFrom, oldClaimService.DOSTo).ToString();

                oldClaimService.MemberID = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == oldClaimService.ClaimHeaderID).FirstOrDefault().MemberID;

                #region Claim Billed Amount Business Rules 
                var billedHeaderAmt = _ClaimHeaderRepository.GetByPredicate(i => i.ClaimHeaderID == oldClaimService.ClaimHeaderID).FirstOrDefault().BilledAmount;
                var sumBilledAmt = _ClaimServiceRepository.GetByPredicate(i => i.ClaimHeaderID == oldClaimService.ClaimHeaderID && i.RecordStatus != (byte)RecordStatus.Deleted
                && i.ClaimServiceID != oldClaimService.ClaimServiceID).Sum(x => x.BilledAmount);
                var totalBilledAmt = oldClaimService.BilledAmount + sumBilledAmt;
                if (totalBilledAmt > billedHeaderAmt)
                {
                    return BadRequest($"Billed Amount should be equal or less than ${billedHeaderAmt - sumBilledAmt}");
                }
                #endregion


                if (!string.IsNullOrEmpty(model.ProcedureCode))
                {
                    var cpt2code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT2, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var cpt4code = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.CPT4, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    var hcpcscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.HCPCS, model.ProcedureCode, model.DOSFrom, model.DOSTo);
                    if (!(cpt2code) && !(cpt4code) && !(hcpcscode))
                    {
                        return BadRequest("Invalid Procedure Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.POSCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.POS, model.POSCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid POS Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.RevenueCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.UBRevenue, model.RevenueCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid Revenue Code");
                    }
                }

                if (!string.IsNullOrEmpty(model.RUGSCode))
                {
                    var poscode = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective((int)ClinicalCodeType.RUGS, model.RUGSCode, model.DOSFrom, model.DOSTo);
                    if (!(poscode))
                    {
                        return BadRequest("Invalid RUGS Code");
                    }
                }


                _ClaimServiceRepository.Update(oldClaimService);
                if (!_ClaimServiceRepository.DbState.IsValid)
                {
                    _ClaimServiceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                if (!string.IsNullOrEmpty(model.Code))
                {
                    #region EOBEOP ADD
                    EOBEOPAddUpdate(model);
                    if (!_IClaimEOBEOPRepository.DbState.IsValid)
                    {
                        _IClaimEOBEOPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                    #endregion
                }

                #region Audit Actions Insertion
                if (action != 0)
                {
                    ClaimAudit modelAudit = new ClaimAudit();
                    modelAudit.ClaimHeaderID = model.ClaimHeaderID;
                    modelAudit.UserInitials = base.UserName;
                    modelAudit.CreatedDate = base.TodaysDate;

                    _ICommonAuditActions.ActionsAdd(oldClaimService);
                }
                if (!_ICommonAuditActions.BusinessState.IsValid)
                {
                    _ICommonAuditActions.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                #endregion

                //if (!string.IsNullOrEmpty(model.EditCode))
                //{
                //    this.ADDEdits(model);
                //}
                return Ok(model.ClaimServiceID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimService :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimServiceRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimService : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        private void EOBEOPAddUpdate(ClaimServiceViewModel model)
        {
            _IClaimEOBEOPRepository.AddEOBEOP(model, base.UserName, (int)EOBEOPType.EOB);
            _IClaimEOBEOPRepository.AddEOBEOP(model, base.UserName, (int)EOBEOPType.EOP);
        }

        //private IActionResult ADDEdits(ClaimServiceViewModel model)
        //{
        //    var editCodes = _IEditCodeRepository.GetEditCode(model.EditCode).FirstOrDefault();
        //    ClaimEdits edits = new ClaimEdits();
        //    edits.ClaimEditsID = 0;
        //    edits.ClaimHeaderID = model.ClaimHeaderID;
        //    edits.ClaimLineID = model.LineNumber;
        //    edits.Edit = editCodes.Code;
        //    edits.Comments = "";
        //    edits.OutcomeReason = "";
        //    edits.EditDescription = editCodes.CodeName;
        //    edits.EditStatusCode = Convert.ToString(editCodes.DefaultOutComeCodeID);
        //    edits.RecordStatus = (byte)RecordStatus.Active;
        //    edits.RecordStatusChangeComment = RecordStatus.Active.ToString();
        //    edits.CreatedDate = base.TodaysDate;
        //    edits.CreatedBy = base.UserName;
        //    var cnt = _ClaimEditsRepository.GetByPredicate(x => x.Edit == model.EditCode && x.ClaimHeaderID == model.ClaimHeaderID && x.ClaimLineID == model.LineNumber && x.RecordStatus != (int)RecordStatus.Deleted).Count();
        //    if (cnt == 0)
        //    {
        //        _ClaimEditsRepository.Add(edits);
        //        if (!_ClaimEditsRepository.DbState.IsValid)
        //        {
        //            _ClaimEditsRepository.DbState.ErrorMessages.ForEach((businessState) =>
        //            {
        //                ModelState.AddModelError(businessState.Key, businessState.Value);
        //            });
        //            return BadRequest(ModelState);
        //        }
        //        return Ok(edits.ClaimEditsID);
        //    }
        //    else return Ok();
        //}
        #endregion
    }
}
