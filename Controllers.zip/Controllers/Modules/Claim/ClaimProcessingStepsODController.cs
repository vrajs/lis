using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimProcessingStepsODController : BaseODController
    {
        #region Variables        
        private IClaimProcessingStepsRepository _ClaimProcessingStepsRepository;
        #endregion

        #region Ctor        
        public ClaimProcessingStepsODController(IClaimProcessingStepsRepository ClaimProcessingStepsRepository)
        {
            _ClaimProcessingStepsRepository = ClaimProcessingStepsRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimProcessingSteps")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimProcessingSteps(long ClaimHeaderID)
        {
            var ClaimProcessingStepsQuery = _ClaimProcessingStepsRepository.GetClaimProcessingSteps(ClaimHeaderID);
            return Ok(ClaimProcessingStepsQuery);
        }
    }
}
