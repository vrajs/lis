using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimProviderNPIODController : BaseODController
    {
        #region Variables        
        private IClaimProviderNPIRepository _ClaimProviderNPIRepository;
        #endregion

        #region Ctor        
        public ClaimProviderNPIODController(IClaimProviderNPIRepository ClaimProviderNPIRepository)
        {
            _ClaimProviderNPIRepository = ClaimProviderNPIRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimProviderNPI")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimProviderNPI()
        {
            var ClaimProviderNPIQuery = _ClaimProviderNPIRepository.GetClaimProviderNPI();
            return Ok(ClaimProviderNPIQuery);
        }
    }
}
