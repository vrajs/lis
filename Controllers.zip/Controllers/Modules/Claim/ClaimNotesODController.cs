using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimNotesODController : BaseODController
    {
        #region Variables        
        private IClaimNotesRepository _IClaimNotesRepository;
        #endregion

        #region Ctor        
        public ClaimNotesODController(IClaimNotesRepository IClaimNotesRepository)
        {
            _IClaimNotesRepository = IClaimNotesRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimNotes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimNotes(long ClaimHeaderID)
        {
            var ClaimNotesQuery = _IClaimNotesRepository.GetClaimNotes(ClaimHeaderID);
            return Ok(ClaimNotesQuery);
        }
    }
}
