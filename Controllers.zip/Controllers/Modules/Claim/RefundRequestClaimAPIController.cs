using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/RefundRequestClaim")]
    public class RefundRequestClaimAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundRequestClaimAPIController> _logger;
        private IRefundRequestClaimRepository _RefundRequestClaimRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RefundRequestClaimAPIController(ILogger<RefundRequestClaimAPIController> logger, IRefundRequestClaimRepository refundRequestClaimRepository, IMapper mapper)
        {
            _logger = logger;
            _RefundRequestClaimRepository = refundRequestClaimRepository;
            _mapper = mapper;
        }
        #endregion


        #region API Methods
        [HttpGet("GetAllClaims/{RefundRequestID}")]
        public IActionResult Get(int RefundRequestID)
        {
            List<RefundRequestClaimViewModel> items = _RefundRequestClaimRepository.GetAllClaims(RefundRequestID);
            return Json(items);
        }
        #endregion
    }
}
