using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimOtherInsuranceODController : BaseODController
    {
        #region Variables        
        private IClaimOtherInsuranceRepository _ClaimOtherInsuranceRepository;
        #endregion

        #region Ctor        
        public ClaimOtherInsuranceODController(IClaimOtherInsuranceRepository ClaimOtherInsuranceRepository)
        {
            _ClaimOtherInsuranceRepository = ClaimOtherInsuranceRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimOtherInsurance")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimOtherInsurance(long ClaimHeaderID)
        {
            var ClaimOtherInsuranceQuery = _ClaimOtherInsuranceRepository.GetClaimOtherInsurance(ClaimHeaderID);
            return Ok(ClaimOtherInsuranceQuery);
        }
    }
}
