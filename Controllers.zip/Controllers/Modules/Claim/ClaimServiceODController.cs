using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimServiceODController : BaseODController
    {
        #region Variables        
        private IClaimServiceRepository _ClaimServiceRepository;
        #endregion

        #region Ctor        
        public ClaimServiceODController(IClaimServiceRepository ClaimServiceRepository)
        {
            _ClaimServiceRepository = ClaimServiceRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimService")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimService(long ClaimHeaderID)
        {
            var ClaimServiceQuery = _ClaimServiceRepository.GetClaimService(ClaimHeaderID);
            return Ok(ClaimServiceQuery);
        }

    }
}
