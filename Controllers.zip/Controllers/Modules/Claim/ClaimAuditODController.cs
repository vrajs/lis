using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimAuditODController : BaseODController
    {
        #region Variables        
        private IClaimAuditRepository _ClaimAuditRepository;
        #endregion

        #region Ctor        
        public ClaimAuditODController(IClaimAuditRepository ClaimAuditRepository)
        {
            _ClaimAuditRepository = ClaimAuditRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimAudit")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimAudit(long ClaimHeaderID)
        {
            var ClaimAuditQuery = _ClaimAuditRepository.GetClaimAudit(ClaimHeaderID);
            return Ok(ClaimAuditQuery);
        }
    }
}
