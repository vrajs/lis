using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimEdits")]
    public class ClaimEditsAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimEditsAPIController> _logger;
        private IClaimEditsRepository _ClaimEditsRepository;
        private IMapper _mapper;
        private ICommonAuditActions _ICommonAuditActions;
        #endregion

        #region Ctor
        public ClaimEditsAPIController(ILogger<ClaimEditsAPIController> logger, ICommonAuditActions CommonAuditActions, IClaimEditsRepository ClaimEditsRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimEditsRepository = ClaimEditsRepository;
            _mapper = mapper;
            _ICommonAuditActions = CommonAuditActions;

        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var ClaimEditsRes = _ClaimEditsRepository.GetAllClaimEdits();
                if (!_ClaimEditsRepository.DbState.IsValid)
                {
                    _ClaimEditsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<ClaimEditsViewModel>>(ClaimEditsRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimEdits : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClaimEditsGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var ClaimEdits = _ClaimEditsRepository.GetById(id);
                if (ClaimEdits == null) return NotFound($"ClaimEdits {id} was not Found");
                if (!_ClaimEditsRepository.DbState.IsValid)
                {
                    _ClaimEditsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<ClaimEditsViewModel>(ClaimEdits));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting ClaimEdits : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClaimEditsViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var ClaimEdits = _mapper.Map<ClaimEdits>(model);
                ClaimEdits.CreatedDate = base.TodaysDate;
                ClaimEdits.CreatedBy = base.UserName;
                ClaimEdits.RecordStatus = (byte)RecordStatus.Active;
                ClaimEdits.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _ClaimEditsRepository.Add(ClaimEdits);
                if (!_ClaimEditsRepository.DbState.IsValid)
                {
                    _ClaimEditsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("ClaimEditsGet", new { id = ClaimEdits.ClaimEditsID });
                _logger.LogInformation("New ClaimEdits Created");
                return Created(newUri, ClaimEdits.ClaimEditsID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ClaimEdits : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClaimEditsViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldClaimEdits = _ClaimEditsRepository.GetById(model.ClaimEditsID);

                if (oldClaimEdits == null) return NotFound($"Could not find a ClaimEdits with an ClaimEditsID of {model.ClaimEditsID}");

                _mapper.Map(model, oldClaimEdits);
                oldClaimEdits.UpdatedBy = base.UserName;
                oldClaimEdits.UpdatedDate = base.TodaysDate;

                _ClaimEditsRepository.Update(oldClaimEdits);
                if (!_ClaimEditsRepository.DbState.IsValid)
                {
                    _ClaimEditsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                _ICommonAuditActions.ActionsAdd(oldClaimEdits);
                if (!_ICommonAuditActions.BusinessState.IsValid)
                {
                    _ICommonAuditActions.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok(model.ClaimEditsID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating ClaimEdits :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            try
            {
                _ClaimEditsRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting ClaimEdits : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
