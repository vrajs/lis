using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimOtherPhysicianODController : BaseODController
    {
        #region Variables        
        private IClaimOtherPhysicianRepository _ClaimOtherPhysicianRepository;
        #endregion

        #region Ctor        
        public ClaimOtherPhysicianODController(IClaimOtherPhysicianRepository ClaimOtherPhysicianRepository)
        {
            _ClaimOtherPhysicianRepository = ClaimOtherPhysicianRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimOtherPhysician")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimOtherPhysician(long ClaimHeaderID)
        {
            var ClaimOtherPhysicianQuery = _ClaimOtherPhysicianRepository.GetClaimOtherPhysician(ClaimHeaderID);
            return Ok(ClaimOtherPhysicianQuery);
        }
    }
}
