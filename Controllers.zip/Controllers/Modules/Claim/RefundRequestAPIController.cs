using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Common.Utility;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Implementations;

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/RefundRequest")]
    public class RefundRequestAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundRequestAPIController> _logger;
        private IRefundRequestRepository _RefundRequestRepository;
        private IMapper _mapper;
        private IRefundLetterRepository _RefundLetterRepository;
        private ITemplateRepository _TemplateRepository;
        private IRefundRequestClaimRepository _RefundRequestClaimRepository;
        private ISystemSettingRepository _systemSettingRepository;


        #endregion

        #region Ctor
        public RefundRequestAPIController(ILogger<RefundRequestAPIController> logger, IRefundRequestClaimRepository refundRequestClaimRepository, IRefundLetterRepository RefundLetterRepository, ITemplateRepository templateRepository, IRefundRequestRepository refundRequestRepository, IMapper mapper, ISystemSettingRepository systemSettingRepository)
        {
            _logger = logger;
            _RefundRequestRepository = refundRequestRepository;
            _RefundLetterRepository = RefundLetterRepository;
            _mapper = mapper;
            _TemplateRepository = templateRepository;
            _RefundRequestClaimRepository = refundRequestClaimRepository;
            _systemSettingRepository = systemSettingRepository;
        }
        #endregion

        #region API Methods
        [HttpGet("{id}", Name = "GetByID")]
        public IActionResult Get(int id)
        {
            try
            {
                RefundRequestViewModel model = _RefundRequestRepository.GetByID(id);
                if (model == null) return NoContent();
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting refund request : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        //async Task<IActionResult> Post
        public IActionResult Post([FromBody] RefundRequestViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<RefundRequest>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)(RecordStatus.Active);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                // Set active status into refund claims
                entity.RefundRequestClaims.ToList().ForEach(e => { e.CreatedBy = base.UserName; e.CreatedDate = base.TodaysDate; e.RecordStatus = (byte)(RecordStatus.Active); e.RecordStatusChangeComment = RecordStatus.Active.ToString(); });

                // Store Date
                entity = _RefundRequestRepository.InsertUpdateRefund(entity);

                if (!_RefundRequestRepository.DbState.IsValid)
                {
                    _RefundRequestRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                model = _RefundRequestRepository.GetByID(entity.RefundRequestID);

                #region Refund Letter Generation
                if (model.IsGenerateLetter) {
                    var refundRequestClaimLst = _RefundRequestClaimRepository.GetByPredicate(x => x.RefundRequestID == entity.RefundRequestID && x.RecordStatus == (int)RecordStatus.Active).ToList();
                    foreach (var r in refundRequestClaimLst)
                    {
                        this.SaveRefundLetter(entity, r.RefundRequestClaimID);
                    }
                }

                #endregion

                //SquenceNo update
                var settingObj = _systemSettingRepository.GetByPredicate(x => x.SettingCode == "RefundSeqNo").FirstOrDefault();
                if(settingObj!= null)
                {
                    settingObj.NumericValue = entity.RefundRequestID;
                    settingObj.UpdatedBy = base.UserName;
                    settingObj.UpdatedDate = base.TodaysDate;
                    _systemSettingRepository.Update(settingObj);
                }


                var newUri = Url.Link("GetByID", new { id = entity.RefundRequestID });
                _logger.LogInformation("New refund request created");
                return Created(newUri, model);
            }
            catch (Exception ex)
            {

                _logger.LogError("Error while creating refund request : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]RefundRequestViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _RefundRequestRepository.GetById(model.RefundRequestID);

                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;

                // Set UpdatedBy,UpdatedDate value into refund claims
                entity.RefundRequestClaims.Where(e => e.RefundRequestClaimID != 0).ToList().ForEach(e => { e.UpdatedBy = base.UserName; e.UpdatedDate = base.TodaysDate; });

                // Store Date
                entity = _RefundRequestRepository.InsertUpdateRefund(entity);

                if (!_RefundRequestRepository.DbState.IsValid)
                {
                    _RefundRequestRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                model = _RefundRequestRepository.GetByID(model.RefundRequestID);

                #region Refund Letter Generation
                if (!_RefundLetterRepository.GetByPredicate(p => p.RefundRequestID == model.RefundRequestID && p.RecordStatus != (byte)RecordStatus.Deleted).Any() && model.IsGenerateLetter)
                {

                    var refundRequestClaimLst = _RefundRequestClaimRepository.GetByPredicate(x => x.RefundRequestID == entity.RefundRequestID && x.RecordStatus != (byte)RecordStatus.Deleted).ToList();
                    foreach (var r in refundRequestClaimLst)
                    {
                        this.SaveRefundLetter(entity, r.RefundRequestClaimID);
                    }


                }
                else if (_RefundLetterRepository.GetByPredicate(p => p.RefundRequestID == model.RefundRequestID && p.RecordStatus != (byte)RecordStatus.Deleted).Any() && !model.IsGenerateLetter)
                {
                    var refundRequestLetterLst = _RefundLetterRepository.GetByPredicate(x => x.RefundRequestID == entity.RefundRequestID && x.RecordStatus != (byte)RecordStatus.Deleted).ToList();
                    foreach (var r in refundRequestLetterLst)
                    {
                        _RefundLetterRepository.DeleteById(r.RefundLetterID, base.UserName, base.TodaysDate);
                    }
                }
                #endregion
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating refund request :{ex}");
                return BadRequest(ex.Message);
            }
        }


        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                RefundRequestViewModel model = _RefundRequestRepository.GetByID(id);
                var entity = _mapper.Map<RefundRequest>(model);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)(RecordStatus.Deleted);
                entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                // Update delete status into refund claims
                entity.RefundRequestClaims.ToList().ForEach(e => { e.UpdatedBy = base.UserName; e.UpdatedDate = base.TodaysDate; e.RecordStatus = (byte)(RecordStatus.Deleted); e.RecordStatusChangeComment = RecordStatus.Deleted.ToString(); });

                // Store Date
                entity = _RefundRequestRepository.InsertUpdateRefund(entity);

                if (!_RefundRequestRepository.DbState.IsValid)
                {
                    _RefundRequestRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok(entity.RefundRequestID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting refund request :{ex}");
                return BadRequest(ex.Message);
            }
        }

        //async Task<IActionResult>
        private IActionResult SaveRefundLetter(RefundRequest model,int refundRequestClaimID)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                string letterType = "";
                var entity = new RefundLetter();
                entity.RefundRequestID = model.RefundRequestID;
                entity.LetterTypeID = (int)RefundLetterType.SecondRequest;
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.LetterDate = model.RequestDate;
                switch (entity.LetterTypeID)
                {
                    case (int)RefundLetterType.Initial:
                        letterType = RefundLetterTypeConst.Initial.ToString();
                        break;
                    case (int)RefundLetterType.SecondRequest:
                        letterType = RefundLetterTypeConst.SecondRequest.ToString();
                        break;
                    case (int)RefundLetterType.FollowUP:
                        letterType = RefundLetterTypeConst.FollowUP.ToString();
                        break;
                    default:
                        letterType = "";
                        break;
                }
                entity.DocumentNo = $"{ letterType }{ entity.RefundRequestID.ToString()}_{ refundRequestClaimID }";

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)(RecordStatus.Active);
                entity.RecordStatusChangeComment = Convert.ToString(RecordStatus.Active);
                entity.LetterHTMLContent = $"{ entity.DocumentNo }.{ "html"}";
                #region TemplateSaving
                //int templateTypeId = (int)TemplateType.Letter;
                //int templateSubTypeId = (int)TemplateSubTypeEnum.RefundLetter;

                //var template = _TemplateRepository.GetTemplate(templateTypeId, templateSubTypeId, "Refund Letter");
                //var fileFormat = template.FileFormat.ToEnum<TemplateFileFormat>();
                //TemplateFileFormat templateFileFormat = template.FileFormat.ToEnum<TemplateFileFormat>();


                //    var placeHolderKeyVal = _TemplateRepository.GetPlaceholderDictionary(template.TemplateID, refundRequestClaimID);
                //    var dictionary = placeHolderKeyVal.ToDictionary(x => x.Key, x => x.Value);

                //    var relativeFilePath = $"{ entity.DocumentNo }.{ template.FileFormat}";
                //    entity.LetterHTMLContent = relativeFilePath;
                //    using (var templateService = new TemplateService(template.RelativeFilePath, templateFileFormat, base.ZoneId))
                //    {
                //        var fileContents = await templateService.ReadFile();
                //        var renderedContents = templateService.RenderTemplate(dictionary);
                //        var filePath = $"{ApplicationVariables.LetterOutputBasePath}{entity.LetterHTMLContent}";
                //        await templateService.SaveFile(filePath);
                //    }
                #endregion
                // Insert Data
                _RefundLetterRepository.Add(entity);
                if (!_RefundLetterRepository.DbState.IsValid)
                {
                    _RefundLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(entity.RefundLetterID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Refund Letter : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
