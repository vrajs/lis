using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.View;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class RefundODController : BaseODController
    {

        #region Variables        
        private IViewRepository _IViewRepository;
        #endregion

        #region Ctor        
        public RefundODController(IViewRepository ViewRepository)
        {
            _IViewRepository = ViewRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RefundList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRefundList()
        {
            var refundlistQuery = _IViewRepository.GetClaimRefundList;
            return Ok(refundlistQuery);
        }
    }
}
