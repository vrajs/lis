using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("odata")]
    public class ClaimUBCodesODController : BaseODController
    {
        #region Variables        
        private IClaimUBCodesRepository _ClaimUBCodesRepository;
        #endregion

        #region Ctor        
        public ClaimUBCodesODController(IClaimUBCodesRepository ClaimUBCodesRepository)
        {
            _ClaimUBCodesRepository = ClaimUBCodesRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClaimUBCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetClaimUBCodes(long ClaimHeaderID)
        {
            var ClaimUBCodesQuery = _ClaimUBCodesRepository.GetClaimUBCodes(ClaimHeaderID);
            return Ok(ClaimUBCodesQuery);
        }
    }
}
