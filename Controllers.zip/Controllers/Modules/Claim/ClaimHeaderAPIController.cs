using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Common.Utility;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.View;

namespace Kwicle.Service.Controllers.Modules.Claim
{
    [Route("api/ClaimHeader")]
    public class ClaimHeaderAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ClaimHeaderAPIController> _logger;
        private IClaimHeaderRepository _ClaimHeaderRepository;
        private IMapper _mapper;
        private IViewRepository _ViewRepository;
        private ICommonAuditActions _ICommonAuditActions;
        private IClaimServiceRepository _ClaimServiceRepository;
        private IClaimDiagnosisRepository _ClaimDiagnosisRepository;
        #endregion

        #region Ctor
        public ClaimHeaderAPIController(ILogger<ClaimHeaderAPIController> logger, ICommonAuditActions CommonAuditActions, IClaimHeaderRepository claimHeaderRepository, IMapper mapper, IViewRepository viewRepository, IClaimServiceRepository claimServiceRepository, IClaimDiagnosisRepository claimDiagnosisRepository)
        {
            _logger = logger;
            _ClaimHeaderRepository = claimHeaderRepository;
            _mapper = mapper;
            _ViewRepository = viewRepository;
            _ICommonAuditActions = CommonAuditActions;
            _ClaimServiceRepository = claimServiceRepository;
            _ClaimDiagnosisRepository = claimDiagnosisRepository;
        }
        #endregion

        #region API Methods
        [HttpGet("{id}", Name = "GetClaimByID")]
        public IActionResult Get(long id)
        {
            try
            {
                ClaimHeader entity = _ClaimHeaderRepository.GetClaimByID(id);
                if (entity == null) return NoContent();
                return Ok(_mapper.Map<ClaimHeaderViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting Claim : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] ClaimHeaderInsertUpdateViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<ClaimHeader>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)(RecordStatus.Active);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();
                if (entity.FormTypeID == (int)ClaimType.Pharmacy)
                {
                    entity.DOSTo = DateTime.MaxValue;
                }

                // Store Data
                entity.ClaimHeaderID = _ClaimHeaderRepository.InsertUpdateClaim(entity, model.ClaimEditsCodes);

                if (!_ClaimHeaderRepository.DbState.IsValid)
                {
                    _ClaimHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                _ICommonAuditActions.ActionsAdd(entity, (int)Actions.Add);
                if (!_ICommonAuditActions.BusinessState.IsValid)
                {
                    _ICommonAuditActions.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                // Calculate Claim Age
                model = _mapper.Map<ClaimHeaderInsertUpdateViewModel>(entity);
                model.ClaimAge = CommonUtil.ClaimAge(entity.ReceivedDate);

                var newUri = Url.Link("GetClaimByID", new { id = entity.ClaimHeaderID });
                _logger.LogInformation("New claim created");
                return Created(newUri, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while creating claim : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]ClaimHeaderInsertUpdateViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                int actionMember = 0;
                int actionProvider = 0;
                var entity = _ClaimHeaderRepository.GetById(model.ClaimHeaderID);
                if (entity == null) return NoContent();
                if (entity.MemberID != model.MemberID)
                {
                    actionMember = (int)Actions.UpdateMember;
                }
                if (entity.ProviderID != model.ProviderID)
                {
                    actionProvider = (int)Actions.UpdateProvider;
                }

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                if (entity.FormTypeID == (int)ClaimType.Pharmacy)
                {
                    entity.DOSTo = DateTime.MaxValue;
                }

                entity.ClaimHeaderID = _ClaimHeaderRepository.InsertUpdateClaim(entity, model.ClaimEditsCodes);
                if (!_ClaimHeaderRepository.DbState.IsValid)
                {
                    _ClaimHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                #region Audit Actions Insertion
                if (actionMember != 0)
                {
                    _ICommonAuditActions.ActionsAdd(entity, actionMember, Actions.UpdateMember.Description());
                }
                if (actionProvider != 0)
                {
                    _ICommonAuditActions.ActionsAdd(entity, actionProvider, Actions.UpdateProvider.Description());
                }
                if (!_ICommonAuditActions.BusinessState.IsValid)
                {
                    _ICommonAuditActions.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                #endregion

                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating claim :{ex}");
                return BadRequest(ex.Message);
            }
        }


        [HttpGet]
        [Route("GenerateClaimNumber")]
        public IActionResult GenerateClaimNumber(DateTime ReceivedDate, int ClaimSourceID)
        {
            try
            {
                string ClaimNumber = _ClaimHeaderRepository.GenerateClaimNumber(ReceivedDate, ClaimSourceID);

                if (!_ClaimHeaderRepository.DbState.IsValid)
                {
                    _ClaimHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(ClaimNumber);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Generating Claim Number: {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        // DELETE api/values/5
        [HttpDelete("{ClaimHeaderID}/{ClaimDeleteReason}")]
        public IActionResult Delete(long ClaimHeaderID, string ClaimDeleteReason)
        {
            try
            {
                var entity = _ClaimHeaderRepository.GetClaimByID(ClaimHeaderID);
                entity.RecordStatus = (int)RecordStatus.Deleted;
                entity.RecordStatusChangeComment = ClaimDeleteReason;
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                entity.ClaimHeaderID = _ClaimHeaderRepository.InsertUpdateClaim(entity);

                if (!_ClaimHeaderRepository.DbState.IsValid)
                {
                    _ClaimHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                #region Audit Actions Insertion
                if (entity.ClaimHeaderID != 0)
                {
                    _ICommonAuditActions.ActionsAdd(entity, (int)Actions.ClaimDeleted, Actions.ClaimDeleted.Description());
                }
                if (!_ICommonAuditActions.BusinessState.IsValid)
                {
                    _ICommonAuditActions.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                #endregion

                return Ok(ClaimHeaderID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting claim :{ex}");
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetClaimByClaimNumber/{ClaimNumber}")]
        public IActionResult GetClaimByClaimNumber(string ClaimNumber)
        {
            try
            {
                ClaimHeaderViewModel model = _ClaimHeaderRepository.GetClaimByClaimNumber(ClaimNumber);
                if (model != null)
                {
                    var memberInfo = _ViewRepository.MemberLookups.FirstOrDefault(f => f.MemberID == model.MemberID && f.MemberEligibilityID == model.MemberEligibilityID);
                    model.lOBID = memberInfo != null ? memberInfo.LOBID : 0;
                }
                else
                {
                    return NoContent();
                }

                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetClaimForRefund/{ClaimNumber}")]
        public IActionResult GetClaimForRefund(string ClaimNumber)
        {
            try
            {
                vwClaimLoockup model = _ViewRepository.ClaimLoockups.Where(e => e.ClaimNumber == ClaimNumber).FirstOrDefault();
                if (model == null) return NoContent();
                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet]
        [Route("CheckClaimHasRequireInfoForAdjudication/{ClaimHeaderID}")]
        public IActionResult CheckClaimHasRequireInfoForAdjudication(long ClaimHeaderID)
        {
            try
            {
                // Check claim has diagnosis or not
                var claimDiagnosis = _ClaimDiagnosisRepository.GetClaimDiagnosis(ClaimHeaderID).ToList();
                if (claimDiagnosis.Count == 0)
                    return Ok(false);

                // Check claim has service line or not
                var claimServiceLines = _ClaimServiceRepository.GetByPredicate(e => e.ClaimHeaderID == ClaimHeaderID && e.RecordStatus != (byte)RecordStatus.Deleted).ToList();
                if (claimServiceLines.Count == 0)
                    return Ok(false);

                return Ok(true);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
