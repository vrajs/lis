using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/ClinicalCodeGroupDetail")]
    public class ClinicalCodeGroupDetailAPIController : BaseAPIController
    {
        private readonly IClinicalCodeGroupDetailService _IClinicalCodeGroupDetailService;
        private readonly IClinicalCodeGroupDetailRepository _IClinicalCodeGroupDetailRepository;
        private IMapper _mapper;
        private ILogger<ClinicalCodeGroupDetailAPIController> _logger;
        public ClinicalCodeGroupDetailAPIController(IClinicalCodeGroupDetailService IClinicalCodeGroupDetailService, IClinicalCodeGroupDetailRepository IClinicalCodeGroupDetailRepository, IMapper mapper, ILogger<ClinicalCodeGroupDetailAPIController> logger)
        {
            _IClinicalCodeGroupDetailService = IClinicalCodeGroupDetailService;
            _IClinicalCodeGroupDetailRepository = IClinicalCodeGroupDetailRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET: api/values
        [HttpGet("{ClinicalCodeSubGroupID}")]
        public IActionResult Get(short ClinicalCodeSubGroupID)
        {
            var result = _IClinicalCodeGroupDetailRepository.GetClinicalCodeGroupDetail(ClinicalCodeSubGroupID).ToList();
            return Ok(result);
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ClinicalCodeGroupDetailGet")]
        public string Get(int id)
        {
            return "value";
        }

        [HttpGet("GetClinicalCodeGroupDetailKeyVal/{ClinicalCodeSubGroupID}")]
        public IActionResult GetClinicalCodeGroupDetailKeyVal(short ClinicalCodeSubGroupID)
        {
            var res = _IClinicalCodeGroupDetailRepository.GetClinicalCodeGroupDetailKeyVal(ClinicalCodeSubGroupID);
            return Ok(res);
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClinicalCodeGroupDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ClinicalCodeGroupDetail entity = _mapper.Map<ClinicalCodeGroupDetail>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IClinicalCodeGroupDetailService.CheckUniqueSubCategoryName(entity);
                if (!_IClinicalCodeGroupDetailService.BusinessState.IsValid)
                {
                    _IClinicalCodeGroupDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                _IClinicalCodeGroupDetailRepository.Add(entity);
                if (!_IClinicalCodeGroupDetailRepository.DbState.IsValid)
                {
                    _IClinicalCodeGroupDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("ClinicalCodeGroupDetailGet", new { id = entity.ClinicalCodeGroupDetailID });
                _logger.LogInformation("New Detail created");
                return Created(newUri, _mapper.Map<ClinicalCodeGroupDetail>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Group detail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]ClinicalCodeGroupDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ClinicalCodeGroupDetail entity = _IClinicalCodeGroupDetailRepository.GetById(model.ClinicalCodeGroupDetailID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IClinicalCodeGroupDetailRepository.Update(entity);
                if (!_IClinicalCodeGroupDetailRepository.DbState.IsValid)
                {
                    _IClinicalCodeGroupDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Group Detail Updated : {0}", entity.ClinicalCodeGroupDetailID);
                return Ok(entity.ClinicalCodeGroupDetailID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Group Detail: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("DeleteClinicalCodeGroupDetail/{id}")]
        //[HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            //ClinicalCodeGroupDetail entity = _IClinicalCodeGroupDetailRepository.GetByPredicate(x => x.ClinicalCodeGroupDetailID == id, new System.Linq.Expressions.Expression<Func<ClinicalCodeGroupDetail, object>>[] { x => x. }).Single();
            ClinicalCodeGroupDetail entity = _IClinicalCodeGroupDetailRepository.GetById(id);
            entity.RecordStatus = (int)RecordStatus.Deleted;
            entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
            _IClinicalCodeGroupDetailRepository.Update(entity);

            if (!_IClinicalCodeGroupDetailRepository.DbState.IsValid)
            {
                _IClinicalCodeGroupDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(id);
        }
    }
}
