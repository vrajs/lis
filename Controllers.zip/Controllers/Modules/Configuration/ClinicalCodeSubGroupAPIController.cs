using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/ClinicalCodeSubGroup")]
    public class ClinicalCodeSubGroupAPIController : BaseAPIController
    {
        private readonly IClinicalCodeSubGroupRepository _IClinicalCodeSubGroupRepository;
        private IMapper _mapper;
        private ILogger<ClinicalCodeSubGroupAPIController> _logger;
        public ClinicalCodeSubGroupAPIController(IClinicalCodeSubGroupRepository IClinicalCodeSubGroupRepository, IMapper mapper, ILogger<ClinicalCodeSubGroupAPIController> logger)
        {
            _IClinicalCodeSubGroupRepository = IClinicalCodeSubGroupRepository;
            _mapper = mapper;
            _logger = logger;
        }


        [HttpGet]
        [Route("GetClinicalCodeSubGroup/{ClinicalCodeGroupID}")]
        public IActionResult GetClinicalCodeSubGroup(short ClinicalCodeGroupID)
        {
            var res = _IClinicalCodeSubGroupRepository.GetClinicalCodeSubGroup(ClinicalCodeGroupID);
            return Ok(res);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]ClinicalCodeSubGroup model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                model.CreatedDate = base.TodaysDate;
                model.CreatedBy = base.UserName;

                _IClinicalCodeSubGroupRepository.Add(model);
                if (!_IClinicalCodeSubGroupRepository.DbState.IsValid)
                {
                    _IClinicalCodeSubGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _logger.LogInformation("Clinical Code sub Group created: {0}", model.ClinicalCodeSubGroupID);
                return Ok(model.ClinicalCodeSubGroupID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Clinicalcodesub group : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
