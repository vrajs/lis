using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitCode")]
    public class BenefitCodeAPIController : BaseAPIController
    {

        #region Variables
        private ILogger<BenefitCodeAPIController> _logger;
        private IBenefitCodeRepository _benefitCodeRepository;
        private ICommonClinicalCodeService _commonClinicalCodeService;
        private IBenefitCodeService _benefitCodeService;
        private IMapper _mapper;       
        #endregion

        #region Ctor        
        public BenefitCodeAPIController(IBenefitCodeRepository benefitCodeRepository, ICommonClinicalCodeService commonClinicalCodeService, ILogger<BenefitCodeAPIController> logger, IMapper mapper, IBenefitCodeService benefitCodeService)
        {
            _logger = logger;
            _benefitCodeRepository = benefitCodeRepository;
            _mapper = mapper;
            _commonClinicalCodeService = commonClinicalCodeService;
            _benefitCodeService = benefitCodeService;           
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var benefitCodesRes = _benefitCodeRepository.GetAllBenefitCodes();
            return Ok(_mapper.Map<IEnumerable<BenefitCodeViewModel>>(benefitCodesRes));
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitCodeGet")]
        public IActionResult Get(int id)
        {
            var benefitCode = _benefitCodeRepository.GetById(id);
            if (benefitCode == null) return NotFound($"Benefit Code {id} was not found");
            return Ok(_mapper.Map<BenefitCodeViewModel>(benefitCode));
        }

        [HttpGet]
        [Route("GetBenefitCodeByBenefitHeaderId/{BenefitHeaderId}")]
        public IActionResult GetBenefitCodeByBenefitHeaderId(int BenefitHeaderId)
        {
            var benefitCodesRes = _benefitCodeRepository.GetBenefitCodeByBenefitHeaderId(BenefitHeaderId);
            return Ok(_mapper.Map<IEnumerable<BenefitCodeViewModel>>(benefitCodesRes));
        }

        [HttpGet("[action]/{BenefitHeaderId}/{ClinicalCodeTypeId}")]
        public IActionResult GetBenefitCodeByClinicalCodeTypeId(int BenefitHeaderId, int ClinicalCodeTypeId)
        {
            var benefitCodesRes = _benefitCodeRepository.GetBenefitCodeByClinicalCodeTypeId(BenefitHeaderId, ClinicalCodeTypeId);
            return Ok(_mapper.Map<IEnumerable<BenefitCodeViewModel>>(benefitCodesRes));
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var benefitCode = _mapper.Map<BenefitCodes>(model);
                benefitCode.CreatedDate = base.TodaysDate;
                benefitCode.CreatedBy = base.UserName;
                benefitCode.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, benefitCode.EffectiveDate,benefitCode.TermDate);
                benefitCode.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, benefitCode.EffectiveDate, benefitCode.TermDate).ToString();

                _commonClinicalCodeService.CheckCodeValidity(benefitCode.ClinicalCodeTypeID, benefitCode.MinCode, benefitCode.MaxCode, benefitCode.EffectiveDate, benefitCode.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }


                //if (benefitCode.ClinicalCodeTypeID == (int)ClinicalCodeType.POS)
                //    if (_commonClinicalCodeService.CheckCommonClinicalCode(benefitCode.ClinicalCodeTypeID, benefitCode.MinCode) == false)
                //        this.ModelState.AddModelError("MinCodeNotFound", $"Code {benefitCode.MinCode} was not found");


                //if (benefitCode.ClinicalCodeTypeID == (int)ClinicalCodeType.POS)
                //    if (_commonClinicalCodeService.CheckCommonClinicalCode(benefitCode.ClinicalCodeTypeID, benefitCode.MinCode, benefitCode.EffectiveDate) == false)
                //        return NotFound($"Effective date should between effective and term date of code {benefitCode.MinCode}");

                //if (_commonClinicalCodeService.CheckCommonClinicalCode(benefitCode.ClinicalCodeTypeID, benefitCode.MinCode) == false)
                //    this.ModelState.AddModelError("MinCodeNotFound", $"Code {benefitCode.MinCode} was not found");

                //if (_commonClinicalCodeService.CheckCommonClinicalCode(benefitCode.ClinicalCodeTypeID, benefitCode.MinCode, benefitCode.EffectiveDate) == false)
                //    return NotFound($"Effective date should between effective and term date of min code {benefitCode.MinCode} was not found </br>");

                //if (_commonClinicalCodeService.CheckCommonClinicalCode(benefitCode.ClinicalCodeTypeID, benefitCode.MaxCode) == false)
                //    this.ModelState.AddModelError("MaxCodeNotFound", $"Max Code {benefitCode.MaxCode} was not found");


                //if (_commonClinicalCodeService.CheckCommonClinicalCode(benefitCode.ClinicalCodeTypeID, benefitCode.MaxCode, benefitCode.EffectiveDate) == false)
                //    return NotFound($"Effective date should between effective and term date of max code {benefitCode.MaxCode} was not found");



                _benefitCodeService.CheckIfCodeExist(benefitCode);
                if (!_benefitCodeService.BusinessState.IsValid)
                {
                    _benefitCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _benefitCodeRepository.Add(benefitCode);
                if (!_benefitCodeRepository.DbState.IsValid)
                {
                    _benefitCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("BenefitCodeGet", new { id = benefitCode.BenefitCodeID });
                _logger.LogInformation("New Benefit Code Created ");
                return Created(newUri, _mapper.Map<BenefitCodeViewModel>(benefitCode));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Benefit Code : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]BenefitCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                StringBuilder sb = new StringBuilder();
                var oldBenefitCode = _benefitCodeRepository.GetById(model.BenefitCodeID);
                if (oldBenefitCode == null) return NotFound($"Could not find a Benefit Code with an BenefitCodeID of {model.BenefitCodeID}");

                _mapper.Map(model, oldBenefitCode);
                oldBenefitCode.UpdatedBy = base.UserName;
                oldBenefitCode.UpdatedDate = base.TodaysDate;
                oldBenefitCode.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldBenefitCode.EffectiveDate, oldBenefitCode.TermDate);
                oldBenefitCode.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldBenefitCode.EffectiveDate, oldBenefitCode.TermDate).ToString();

                //if (oldBenefitCode.ClinicalCodeTypeID == (int)ClinicalCodeType.POS)
                //    if (_commonClinicalCodeService.CheckCommonClinicalCode(oldBenefitCode.ClinicalCodeTypeID, oldBenefitCode.MinCode) == false)
                //        return NotFound($"Code {oldBenefitCode.MinCode} was not found");

                //if (_commonClinicalCodeService.CheckCommonClinicalCode(oldBenefitCode.ClinicalCodeTypeID, oldBenefitCode.MinCode) == false)
                //    sb.Append($"Min Code {oldBenefitCode.MinCode} was not found </br>");


                //if (_commonClinicalCodeService.CheckCommonClinicalCode(oldBenefitCode.ClinicalCodeTypeID, oldBenefitCode.MaxCode) == false)
                //    sb.Append($"Max Code {oldBenefitCode.MaxCode} was not found");

                //if (sb.Length > 0) return NotFound(sb.ToString());


                _commonClinicalCodeService.CheckCodeValidity(oldBenefitCode.ClinicalCodeTypeID, oldBenefitCode.MinCode, oldBenefitCode.MaxCode, oldBenefitCode.EffectiveDate, oldBenefitCode.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _benefitCodeService.CheckIfCodeExist(oldBenefitCode);
                if (!_benefitCodeService.BusinessState.IsValid)
                {
                    _benefitCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _benefitCodeRepository.Update(oldBenefitCode);
                if (!_benefitCodeRepository.DbState.IsValid)
                {
                    _benefitCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(model.BenefitCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Benefit Code: {ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _benefitCodeRepository.DeleteById(id);
            return Ok(id);
        }

        [HttpDelete]
        public IActionResult DeleteByReason(DeleteModel deleteModel)
        {
            _benefitCodeRepository.DeleteByReason(deleteModel);
            return Ok(deleteModel);
        }
        #endregion
    }
}
