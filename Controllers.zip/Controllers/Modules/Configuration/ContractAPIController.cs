using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/Contract")]
    public class ContractAPIController : BaseAPIController
    {
        private readonly IContractRepository _IContractRepository;
        private readonly IContractClaimTypeRepository _IContractClaimTypeRepository;
        private IMapper _mapper;
        private ILogger<ContractAPIController> _logger;
        private readonly ICapitationHeaderRepository _capitationHeaderRepository;
        public ContractAPIController(IContractRepository IContractRepository, IMapper mapper, ILogger<ContractAPIController> logger, IContractClaimTypeRepository IContractClaimTypeRepository, ICapitationHeaderRepository capitationHeaderRepository)
        {
            _IContractRepository = IContractRepository;
            _IContractClaimTypeRepository = IContractClaimTypeRepository;
            _mapper = mapper;
            _logger = logger;
            _capitationHeaderRepository = capitationHeaderRepository;
        }

        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var res = _IContractRepository.GetByPredicate(null).ToList();
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Term {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ContractGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var contract = _IContractRepository.GetById(id);
                contract.ContractClaimType = _IContractClaimTypeRepository.GetByContractID(contract.ContractID);
                if (contract == null) return NotFound($"Contract {id} was not found");
                //if(contract!= null && contract.CapitationID > 0)
                //{
                //    var capitation = _capitationHeaderRepository.GetById(contract.CapitationID);
                //    contract.ContractCode = capitation != null ? capitation.CapitationCode : null;
                //}
                return Ok(_mapper.Map<Contract>(contract));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Term api/values/5
        [HttpGet]
        [Route("GetContractViewById/{id}")]
        public IActionResult GetContractViewById(int id)
        {
            try
            {
                var contractView = _IContractRepository.GetContracts().Where(x => x.ContractHeaderID == id).SingleOrDefault();

                if (contractView == null) return NotFound($"Contract View {id} was not found");

                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(contractView);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]Contract model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Contract entity = _mapper.Map<Contract>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.TermDate = model.TermDate.ToTermDate();
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                if (entity.ContractClaimType.Count > 0)
                {
                    entity.ContractClaimType.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                _IContractRepository.Add(entity);
                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("ContractGet", new { id = entity.ContractID });
                _logger.LogInformation("New Contract created");
                return Created(newUri, entity.ContractID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]Contract model)
        {
            model.TermDate = model.TermDate.ToTermDate();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Contract entity = _IContractRepository.GetById(model.ContractID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                if (entity.ContractClaimType.Count > 0)
                {
                    entity.ContractClaimType.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                _IContractRepository.Update(entity);
                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Contract Updated : {0}", entity.ContractID);
                return Ok(entity.ContractID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IContractRepository.DeleteOrTermContract(id, base.UserName, base.TodaysDate, (byte)RecordStatus.Deleted, RecordStatus.Deleted.ToString(), null);

                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // Term api/values/5
        [HttpPut]
        [Route("TerminateContract/{id}")]
        public IActionResult TerminateContract(int id, [FromBody]TerminateContractTermModel model)
        {

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                _IContractRepository.DeleteOrTermContract(id, base.UserName, base.TodaysDate, (byte)RecordStatus.Termed, model.TermReason, model.TermDate);

                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while terminating Contract: {ex}");
                return BadRequest(ex.Message);
            }
        }

        //Copy Contract        
        [HttpPost]
        [Route("CopyContract")]
        public IActionResult CopyContract([FromBody]CopyContractTermModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var contract = _IContractRepository.GetByPredicate(x => x.ContractID == model.ContractId, x => x.ContractClaimType).SingleOrDefault();

                Contract entity = new Contract();
                entity.ContractCode = model.ContractCode;
                entity.ContractName = model.ContractName;
                entity.ContractDescription = contract.ContractDescription;
                entity.CapitationID = contract.CapitationID;
                entity.AnesConversionFactorID = contract.AnesConversionFactorID;
                entity.EffectiveDate = model.EffectiveDate;
                entity.TermDate = !model.TermDate.HasValue ? DateTime.MaxValue.Date : model.TermDate.Value;
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.UpdatedDate = null;
                entity.UpdatedBy = null;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = "Contract Copy";
                contract.ContractClaimType.ToList().ForEach(x =>
                {
                    entity.ContractClaimType.Add(new ContractClaimType() { ClaimTypeID = x.ClaimTypeID, CreatedDate = base.TodaysDate, CreatedBy = base.UserName });
                });

                _IContractRepository.Add(entity, string.Join(",", model.TermHeaderIds));

                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("ContractGet", new { id = entity.ContractID });
                _logger.LogInformation("Contract Copied ");

                return Created(newUri, entity.ContractID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while copying Contract : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
