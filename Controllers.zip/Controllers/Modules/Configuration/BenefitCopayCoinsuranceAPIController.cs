using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitCopayCoinsurance")]
    public class BenefitCopayCoinsuranceAPIController : BaseAPIController
    {
        #region Variables
        private IMapper _mapper;
        private ILogger<BenefitCopayCoinsuranceAPIController> _logger;
        private readonly IBenefitCopayCoinsuranceRepository _IBenefitCopayCoinsuranceRepository;
        #endregion

        #region Ctor    
        public BenefitCopayCoinsuranceAPIController(IMapper mapper, ILogger<BenefitCopayCoinsuranceAPIController> logger, IBenefitCopayCoinsuranceRepository IBenefitCopayCoinsuranceRepository)
        {
            _mapper = mapper;
            _logger = logger;
            _IBenefitCopayCoinsuranceRepository = IBenefitCopayCoinsuranceRepository;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var benefitCopayCoinsuranceRes = _IBenefitCopayCoinsuranceRepository.GetAllBenefitCopayCoinsurance();
            return Ok(_mapper.Map<IEnumerable<BenefitCopayCoinsuranceModel>>(benefitCopayCoinsuranceRes));
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitCopayCoinsuranceGet")]
        public IActionResult Get(int id)
        {
            var benefitCopayCoinsurance = _IBenefitCopayCoinsuranceRepository.GetById(id);
            if (benefitCopayCoinsurance == null) return NotFound($"Benefit CopayCoinsurance {id} was not found");
            return Ok(_mapper.Map<BenefitCopayCoinsuranceModel>(benefitCopayCoinsurance));
        }

        [HttpGet]
        [Route("GetBenefitCopayCoinsuranceByBenefitHeaderId/{BenefitHeaderId}")]
        public IActionResult GetBenefitCodeByBenefitHeaderId(int BenefitHeaderId)
        {
            var benefitCopayCoinsuranceRes = _IBenefitCopayCoinsuranceRepository.GetBenefitCopayCoinsuranceByBenefitHeaderId(BenefitHeaderId);
            return Ok(_mapper.Map<BenefitCopayCoinsuranceModel>(benefitCopayCoinsuranceRes));
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitCopayCoinsuranceModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<BenefitCopayCoinsurance>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                _IBenefitCopayCoinsuranceRepository.Add(entity);

                if (!_IBenefitCopayCoinsuranceRepository.DbState.IsValid)
                {
                    _IBenefitCopayCoinsuranceRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("BenefitCopayCoinsuranceGet", new { id = entity.BenefitCopayCoinsuranceID });
                _logger.LogInformation("New Benefit Copay Coinsurance Created ");
                return Created(newUri, _mapper.Map<BenefitCopayCoinsurance>(entity));

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Benefit Copay Coinsurance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]BenefitCopayCoinsuranceModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _IBenefitCopayCoinsuranceRepository.GetById(model.BenefitCopayCoinsuranceID);
                if (entity == null) return NotFound($"Could not find a Benefit CopayCoinsurance with an BenefitCopayCoinsuranceID of {entity.BenefitCopayCoinsuranceID}");

                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _IBenefitCopayCoinsuranceRepository.Update(entity);
                if (!_IBenefitCopayCoinsuranceRepository.DbState.IsValid)
                {
                    _IBenefitCopayCoinsuranceRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Benefit CopayCoinsurance Updated : {0}", entity.BenefitCopayCoinsuranceID);
                return Ok(entity.BenefitCopayCoinsuranceID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Benefit CopayCoinsurance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _IBenefitCopayCoinsuranceRepository.DeleteById(id);
            return Ok(id);
        }
        #endregion
    }
}
