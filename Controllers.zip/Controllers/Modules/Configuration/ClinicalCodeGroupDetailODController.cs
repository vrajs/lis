using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class ClinicalCodeGroupDetailODController : BaseODController
    {
        #region Variables        
        private IClinicalCodeGroupDetailRepository _IClinicalCodeGroupDetailRepository;
        #endregion

        #region Ctor        
        public ClinicalCodeGroupDetailODController(IClinicalCodeGroupDetailRepository clinicalCodeGroupDetailRepository)
        {
            _IClinicalCodeGroupDetailRepository = clinicalCodeGroupDetailRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ClinicalCodeGroupDetails")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetClinicalCodeGroupDetails(short ClinicalCodeSubGroupID)
        {
            var benefitcodeQuery = _IClinicalCodeGroupDetailRepository.GetClinicalCodeGroupDetail(ClinicalCodeSubGroupID);
            return Ok(benefitcodeQuery);
        }
    }
}
