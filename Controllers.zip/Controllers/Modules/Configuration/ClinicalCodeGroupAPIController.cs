using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Core.Entities.BenefitStructure;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/ClinicalCodeGroup")]
    public class ClinicalCodeGroupAPIController : BaseAPIController
    {
        private readonly IClinicalCodeGroupRepository _IClinicalCodeGroupRepository;
        private IMapper _mapper;
        private ILogger<ClinicalCodeGroupAPIController> _logger;
        public ClinicalCodeGroupAPIController(IClinicalCodeGroupRepository IClinicalCodeGroupRepository, IMapper mapper, ILogger<ClinicalCodeGroupAPIController> logger)
        {
            _IClinicalCodeGroupRepository = IClinicalCodeGroupRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET: api/values
        [HttpGet]
        [Route("GetClinicalCodeGroup")]
        public IActionResult GetClinicalCodeGroup()
        {
            var res = _IClinicalCodeGroupRepository.GetClinicalCodeGroup();
            return Ok(res);
        }


        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }
                
        [HttpPost]
        public IActionResult Post([FromBody]ClinicalCodeGroup model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                model.CreatedDate = base.TodaysDate;
                model.CreatedBy = base.UserName;
                _IClinicalCodeGroupRepository.Add(model);
                if (!_IClinicalCodeGroupRepository.DbState.IsValid)
                {
                    _IClinicalCodeGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _logger.LogInformation("Clinical Code Group created: {0}", model.ClinicalCodeGroupID);
                return Ok(model.ClinicalCodeGroupID);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Clinicalcode group : {0}", ex);
                return BadRequest(ex.Message);
            }
        }              

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
