using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/TermPayment")]
    public class TermPaymentAPIController : BaseAPIController
    {

        #region Variables
        private ILogger<TermPaymentAPIController> _logger;
        private ITermPaymentRepository _termPaymentRepository;
        private IMapper _mapper;
        private ITermPaymentService _termPaymentService;
        #endregion

        #region Ctor
        public TermPaymentAPIController(ILogger<TermPaymentAPIController> logger, ITermPaymentRepository termPaymentRepository, IMapper mapper, ITermPaymentService termPaymentService)
        {
            _logger = logger;
            _termPaymentRepository = termPaymentRepository;
            _mapper = mapper;
            _termPaymentService = termPaymentService;
        }
        #endregion


        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var termPaymentsRes = _termPaymentRepository.GetTermPayment(null, null);
                return Ok(termPaymentsRes.ToList());
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "TermPaymentGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var termPayment = _termPaymentRepository.GetById(id);
                if (termPayment == null) return NotFound($"Term Payment {id} was not found");
                return Ok(_mapper.Map<TermPaymentModel>(termPayment));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetTermPaymentByTermHeaderID/{TermHeaderId}/{PaymentTypeId}")]
        public IActionResult GetTermPaymentByTermHeaderID(int TermHeaderId, int? PaymentTypeId)
        {
            try
            {
                var termLimitRes = _termPaymentRepository.GetTermPayment(TermHeaderId, PaymentTypeId);
                if (!_termPaymentRepository.DbState.IsValid)
                {
                    _termPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(termLimitRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting TermHeaderId {TermHeaderId} Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetActiveTermPaymentByTermHeaderID/{TermHeaderId}")]
        public IActionResult GetTermPaymentByTermHeaderID(int TermHeaderId)
        {
            try
            {
                var termLimitRes = _termPaymentRepository.GetTermPayment(TermHeaderId, null);
                termLimitRes = termLimitRes.Where(i => DateTime.Now.Date >= i.EffectiveDate.Date && (!i.TermDate.HasValue || DateTime.Now.Date <= i.TermDate));

                if (!_termPaymentRepository.DbState.IsValid)
                {
                    _termPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(termLimitRes.ToList());
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting TermHeaderId {TermHeaderId} Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetTermPaymentHistoryByTermHeaderID/{TermHeaderId}")]
        public IActionResult GetTermPaymentHistoryByTermHeaderID(int TermHeaderId)
        {
            try
            {
                var termLimitRes = _termPaymentRepository.GetTermPaymentHistory(TermHeaderId);
                if (!_termPaymentRepository.DbState.IsValid)
                {
                    _termPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(termLimitRes.ToList());
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting TermHeaderId {TermHeaderId} Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]TermPaymentModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var termPayment = _mapper.Map<TermPayment>(model);
                termPayment.CreatedDate = base.TodaysDate;
                termPayment.CreatedBy = base.UserName;
                termPayment.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, termPayment.EffectiveDate, termPayment.TermDate);
                termPayment.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, termPayment.EffectiveDate, termPayment.TermDate).ToString();

                _termPaymentService.CheckIfExists(termPayment);
                if (!_termPaymentService.BusinessState.IsValid)
                {
                    _termPaymentService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _termPaymentService.CheckPayemetTermByEffectiveDateIfExist(termPayment);
                if (!_termPaymentService.BusinessState.IsValid)
                {
                    _termPaymentService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _termPaymentRepository.Add(termPayment);
                if (!_termPaymentRepository.DbState.IsValid)
                {
                    _termPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("TermPaymentGet", new { id = termPayment.TermPaymentID });
                _logger.LogInformation("New Term Payment Created ");
                return Created(newUri, _mapper.Map<TermPaymentModel>(termPayment));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Term Payment : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]TermPaymentModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var oldTermPayment = _termPaymentRepository.GetById(model.TermPaymentID);
                if (oldTermPayment == null) return NotFound($"Could not find a Term Payment with an TermPaymentID of {model.TermPaymentID}");

                _mapper.Map(model, oldTermPayment);
                oldTermPayment.UpdatedBy = base.UserName;
                oldTermPayment.UpdatedDate = base.TodaysDate;
                oldTermPayment.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldTermPayment.EffectiveDate, oldTermPayment.TermDate);
                oldTermPayment.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldTermPayment.EffectiveDate, oldTermPayment.TermDate).ToString();

                _termPaymentService.CheckPayemetTermByEffectiveDateIfExist(oldTermPayment);
                if (!_termPaymentService.BusinessState.IsValid)
                {
                    _termPaymentService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _termPaymentRepository.Update(oldTermPayment);
                if (!_termPaymentRepository.DbState.IsValid)
                {
                    _termPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(model.TermPaymentID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _termPaymentRepository.DeleteById(id);
                if (!_termPaymentRepository.DbState.IsValid)
                {
                    _termPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Term Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
