using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class BenefitCodeODController : BaseODController
    {

        #region Variables        
        private IBenefitCodeRepository _IBenefitCodeRepository;
        #endregion

        #region Ctor        
        public BenefitCodeODController(IBenefitCodeRepository benefitCodeRepository)
        {
            _IBenefitCodeRepository = benefitCodeRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BenefitCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetBenefitCodes(int BenefitHeaderId, int? ClinicalCodeTypeId)
        {
            var benefitcodeQuery = _IBenefitCodeRepository.GetBenefitCodes(BenefitHeaderId, ClinicalCodeTypeId ?? 0);
            return Ok(benefitcodeQuery);
        }
    }
}
