using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Core.Common;
using System.Linq.Expressions;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Business.Implementation.Configuration;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/TermServiceGroup")]
    public class TermServiceGroupAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<TermServiceGroupAPIController> _logger;
        private ITermServiceGroupsRepository _TermServiceGroupsRepository;
        private IMapper _mapper;
        private ITermServiceGroupService _TermServiceGroupService;
        #endregion

        #region Ctor        
        public TermServiceGroupAPIController(ITermServiceGroupsRepository TermServiceGroupsRepository, ILogger<TermServiceGroupAPIController> logger, IMapper mapper, ITermServiceGroupService TermServiceGroupService)
        {
            _logger = logger;
            _TermServiceGroupsRepository = TermServiceGroupsRepository;
            _mapper = mapper;
            _TermServiceGroupService = TermServiceGroupService;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            return Ok();
        }

        [HttpGet]
        [Route("GetTermServiceGroupByTermHeaderId/{TermHeaderId}")]
        public IActionResult GetTermServiceGroupByTermHeaderId(int TermHeaderId)
        {
            try
            {
                var termServiceGroupsRes = _TermServiceGroupsRepository.GetTermServiceGroupsByTermHeaderId(TermHeaderId).ToList();
                if (!_TermServiceGroupsRepository.DbState.IsValid)
                {
                    _TermServiceGroupsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(termServiceGroupsRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting TermHeaderId {TermHeaderId} Term Service Group: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "TermServiceGroupGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var termServiceGroup = _TermServiceGroupsRepository.GetByPredicate(x => x.TermServiceGroupID == id, x => x.ClinicalCodeGroup, y => y.ClinicalCodeSubGroup, z => z.ClinicalCodeGroupDetail).Single();
                if (termServiceGroup == null) return NotFound($"Term Service Group {id} was not found");
                if (!_TermServiceGroupsRepository.DbState.IsValid)
                {
                    _TermServiceGroupsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<TermCodeViewModel>(termServiceGroup));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Term Service Group: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]TermServiceGroupModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                TermServiceGroup entity = _mapper.Map<TermServiceGroup>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _TermServiceGroupService.CheckIfServiceGroupExist(entity);
                if (!_TermServiceGroupService.BusinessState.IsValid)
                {
                    _TermServiceGroupService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                _TermServiceGroupService.CheckGroupValidity(entity.ClinicalCodeGroupDetailID ?? 0, entity.EffectiveDate, entity.TermDate);
                if (!_TermServiceGroupService.BusinessState.IsValid)
                {
                    _TermServiceGroupService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _TermServiceGroupsRepository.Add(entity);
                if (!_TermServiceGroupsRepository.DbState.IsValid)
                {
                    _TermServiceGroupsRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("TermServiceGroupGet", new { id = entity.TermServiceGroupID });
                _logger.LogInformation("New Term Service Group created");
                return Created(newUri, _mapper.Map<TermServiceGroupModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Term Service Group : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]TermServiceGroupModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _TermServiceGroupsRepository.GetById(model.TermServiceGroupID);
                if (entity == null) return NotFound($"Could not find term service group with an TermServiceGroupID of {model.TermServiceGroupID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _TermServiceGroupService.CheckIfServiceGroupExist(entity);
                if (!_TermServiceGroupService.BusinessState.IsValid)
                {
                    _TermServiceGroupService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                _TermServiceGroupService.CheckGroupValidity(entity.ClinicalCodeGroupDetailID ?? 0, entity.EffectiveDate, entity.TermDate);
                if (!_TermServiceGroupService.BusinessState.IsValid)
                {
                    _TermServiceGroupService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _TermServiceGroupsRepository.Update(entity);
                if (!_TermServiceGroupsRepository.DbState.IsValid)
                {
                    _TermServiceGroupsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Term service groups updated  : {0}", entity.TermServiceGroupID);
                return Ok(model.TermServiceGroupID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Term Service Group :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _TermServiceGroupsRepository.DeleteById(id);
                if (!_TermServiceGroupsRepository.DbState.IsValid)
                {
                    _TermServiceGroupsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Term Service Group: {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
