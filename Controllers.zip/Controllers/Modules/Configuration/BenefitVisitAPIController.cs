using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitVisit")]
    public class BenefitVisitAPIController : BaseAPIController
    {
        private readonly IBenefitVisitRepository _IBenefitVisitRepository;
        private IMapper _mapper;
        private ILogger<BenefitVisitAPIController> _logger;

        public BenefitVisitAPIController(IBenefitVisitRepository IBenefitVisitRepository, IMapper mapper, ILogger<BenefitVisitAPIController> logger)
        {
            _IBenefitVisitRepository = IBenefitVisitRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitVisitGet")]
        public IActionResult Get(int id)
        {
            var benefitVisit = _IBenefitVisitRepository.GetByBenefitHeaderID(id).SingleOrDefault();
            //if (benefitVisit == null) return NotFound($"Benefit Visit detail {id} was not found");
            return Ok(_mapper.Map<BenefitVisitModel>(benefitVisit));
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitVisitModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                BenefitVisit entity = _mapper.Map<BenefitVisit>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                //save benefitvisitsharelimit
                if (model.ShareBenefitHeaderID.Length > 0)
                {
                    foreach (var item in model.ShareBenefitHeaderID)
                    {
                        entity.BenefitVisitLimitShares.Add(new BenefitVisitLimitShare { BenefitVisitID = entity.BenefitVisitID, BenefitHeaderID = int.Parse(item), CreatedBy = base.UserName, CreatedDate = base.TodaysDate, RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate), RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString() });
                    }
                }
                _IBenefitVisitRepository.Add(entity);
                if (!_IBenefitVisitRepository.DbState.IsValid)
                {
                    _IBenefitVisitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("BenefitVisitGet", new { id = entity.BenefitVisitID });
                _logger.LogInformation("New Benefit Visit created");
                return Created(newUri, _mapper.Map<BenefitVisitModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Benefit visit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values
        [HttpPut]
        public IActionResult Put([FromBody]BenefitVisitModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                BenefitVisit entity = _IBenefitVisitRepository.GetByPredicate(x => x.BenefitVisitID == model.BenefitVisitID, new System.Linq.Expressions.Expression<Func<BenefitVisit, object>>[] { x => x.BenefitVisitLimitShares }).Single();
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                //save benefitvisitsharelimit
                if (model.ShareBenefitHeaderID.Length > 0)
                {
                    foreach (var item in model.ShareBenefitHeaderID)
                    {
                        entity.BenefitVisitLimitShares.Add(new BenefitVisitLimitShare { BenefitVisitID = entity.BenefitVisitID, BenefitHeaderID = int.Parse(item), CreatedBy = base.UserName, CreatedDate = base.TodaysDate, RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate), RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString() });
                    }
                }
                _IBenefitVisitRepository.Update(entity);
                if (!_IBenefitVisitRepository.DbState.IsValid)
                {
                    _IBenefitVisitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Benefit visit Updated : {0}", entity.BenefitVisitID);
                return Ok(entity.BenefitVisitID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Benefit visit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //not required 
        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            BenefitVisit entity = _IBenefitVisitRepository.GetByPredicate(x => x.BenefitVisitID == id, new System.Linq.Expressions.Expression<Func<BenefitVisit, object>>[] { x => x.BenefitVisitLimitShares }).Single();
            entity.RecordStatus = (int)RecordStatus.Deleted;
            entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
            if (entity.BenefitVisitLimitShares.Count > 0)
            {
                entity.BenefitVisitLimitShares.ToList().ForEach(x => { x.RecordStatus = (int)RecordStatus.Deleted; x.RecordStatusChangeComment = RecordStatus.Deleted.ToString(); });
            }
            _IBenefitVisitRepository.Update(entity);

            if (!_IBenefitVisitRepository.DbState.IsValid)
            {
                _IBenefitVisitRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }

            return Ok(id);
        }
    }
}
