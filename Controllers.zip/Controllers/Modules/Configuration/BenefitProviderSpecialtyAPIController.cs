using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Configuration;
using AutoMapper;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitProviderSpecialty")]
    public class BenefitProviderSpecialtyAPIController : BaseAPIController 
    {
        private readonly IBenefitProviderSpecialtyRepository _IBenefitProviderSpecialtyRepository;
        private IMapper _mapper;
        private ILogger<BenefitProviderSpecialtyAPIController> _logger;

        public BenefitProviderSpecialtyAPIController(IBenefitProviderSpecialtyRepository IBenefitProviderSpecialtyRepository, IMapper mapper, ILogger<BenefitProviderSpecialtyAPIController> logger)
        {
            _IBenefitProviderSpecialtyRepository = IBenefitProviderSpecialtyRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet("GetByBenefitHeaderID/{benefitHeaderID}")]
        public IActionResult GetByBenefitHeaderID(int benefitHeaderID)
        {
            try
            {
                var benefitProviderSpecialties = _IBenefitProviderSpecialtyRepository.GetByBenefitHeaderID(benefitHeaderID);
                if (benefitProviderSpecialties == null) return NotFound($"benefitProviderSpecialties for benefit {benefitHeaderID} was not found");
                return Ok(benefitProviderSpecialties);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
