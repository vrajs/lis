using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/TermHeader")]
    public class TermHeaderAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<TermHeaderAPIController> _logger;
        private IMapper _mapper;
        private readonly ITermHeaderRepository _ITermHeaderRepository;
        private readonly ITermProviderSpecialtyRepository _ITermProviderSpecialtyRepository;
        private readonly IContractRepository _IContractRepository;
        private readonly ITermHeaderService _ITermHeaderService;
        #endregion

        #region Ctor        
        public TermHeaderAPIController(ILogger<TermHeaderAPIController> logger, IMapper mapper, ITermHeaderRepository ITermHeaderRepository, ITermProviderSpecialtyRepository ITermProviderSpecialtyRepository, IContractRepository IContractRepository, ITermHeaderService ITermHeaderService)
        {
            _logger = logger;
            _mapper = mapper;
            _ITermHeaderRepository = ITermHeaderRepository;
            _ITermProviderSpecialtyRepository = ITermProviderSpecialtyRepository;
            _IContractRepository = IContractRepository;
            _ITermHeaderService = ITermHeaderService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var res = _ITermHeaderRepository.GetAllTerm(null, null).ToList();
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Term {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "TermHeaderGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var res = _ITermHeaderRepository.GetAllTerm(id, null).SingleOrDefault();
                if (res == null) return NotFound($"Term Header {id} was not found");
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Term {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetTermByContractID/{id}")]
        public IActionResult GetBenefitCodeByBenefitHeaderId(int id)
        {
            try
            {
                var res = _ITermHeaderRepository.GetAllTerm(null, id).ToList();
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Term {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("CheckTermConfigurationHasData/{id}")]
        public IActionResult CheckTermConfigurationHasData(int id)
        {
            try
            {
                var res = _ITermHeaderRepository.CheckTermConfigurationHasData(id);
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting TermConfigurationHasData {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]TermHeaderViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                TermHeader entity = _mapper.Map<TermHeader>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                if (entity.TermProviderSpecialty.Count > 0)
                {
                    entity.TermProviderSpecialty.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                _ITermHeaderService.CheckTermHeaderBetweenContract(entity);

                if (!_ITermHeaderService.BusinessState.IsValid)
                {
                    _ITermHeaderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _ITermHeaderRepository.Add(entity);

                if (!_ITermHeaderRepository.DbState.IsValid)
                {
                    _ITermHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("TermHeaderGet", new { id = entity.TermHeaderID });
                _logger.LogInformation("New Term Created");
                return Created(newUri, _mapper.Map<TermHeaderViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Term : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]TermHeaderViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldTermHeader = _ITermHeaderRepository.GetById(model.TermHeaderID);
                if (oldTermHeader == null) return NotFound($"Could not find a Term Header with an TermHeaderID of {model.TermHeaderID}");

                _mapper.Map(model, oldTermHeader);
                oldTermHeader.UpdatedDate = base.TodaysDate;
                oldTermHeader.UpdatedBy = base.UserName;
                oldTermHeader.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldTermHeader.EffectiveDate, oldTermHeader.TermDate);
                oldTermHeader.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldTermHeader.EffectiveDate, oldTermHeader.TermDate).ToString();

                if (oldTermHeader.TermProviderSpecialty.Count > 0)
                {
                    oldTermHeader.TermProviderSpecialty.ToList().ForEach(x => { x.UpdatedDate = base.TodaysDate; x.UpdatedBy = base.UserName; });
                }

                _ITermHeaderService.CheckTermHeaderBetweenContract(oldTermHeader);

                if (!_ITermHeaderService.BusinessState.IsValid)
                {
                    _ITermHeaderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }


                _ITermHeaderRepository.Update(oldTermHeader);

                if (!_ITermHeaderRepository.DbState.IsValid)
                {
                    _ITermHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                return Ok(model.TermHeaderID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Term : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _ITermHeaderRepository.DeleteOrTermTermHeader(id, base.UserName, base.TodaysDate, null, (byte)RecordStatus.Deleted, RecordStatus.Deleted.ToString());

                if (!_ITermHeaderRepository.DbState.IsValid)
                {
                    _ITermHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Term Header: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // Term api/values/5
        [HttpPut]
        [Route("TerminateTerm/{id}")]
        public IActionResult TerminateTerm(int id, [FromBody]TerminateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                _ITermHeaderRepository.DeleteOrTermTermHeader(id, base.UserName, base.TodaysDate, model.TermDate, (byte)RecordStatus.Termed, model.TermReason);

                if (!_ITermHeaderRepository.DbState.IsValid)
                {
                    _ITermHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while terminating Term: {ex}");
                return BadRequest(ex.Message);
            }
        }

        //Copy Term        
        [HttpPost]
        [Route("CopyTerm")]
        public IActionResult CopyTerm([FromBody]TermHeaderViewModel model)
        {
            //if (!ModelState.IsValid)
            //    return BadRequest(ModelState);

            try
            {
                var termId = _ITermHeaderRepository.CopyTerm(model, base.UserName, base.TodaysDate);

                if (!_ITermHeaderRepository.DbState.IsValid)
                {
                    _ITermHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("TermHeaderGet", new { id = termId });
                _logger.LogInformation("Term Copied ");

                return Created(newUri, termId);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while copying Term : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //Copy Terms from existing contracts
        [HttpPost]
        [Route("CopyAllTerms")]
        public IActionResult CopyAllTerms([FromBody]CopyAllTermModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                _IContractRepository.CopyContract(model.ContractId, string.Join(",", model.TermHeaderIds), model.EffectiveDate, base.UserName, base.TodaysDate,model.TermDate);

                if (!_IContractRepository.DbState.IsValid)
                {
                    _IContractRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _logger.LogInformation("All Terms Copied");
                return Created(string.Empty, "All Terms Copied Successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while copying All Term : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
