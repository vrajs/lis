using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/HealthPlanDeductible")]
    public class HealthPlanDeductibleAPIController : BaseAPIController
    {
        private readonly IHealthPlanDeductibleRepository _IHealthPlanDeductibleRepository;
        private IMapper _mapper;
        private ILogger<HealthPlanDeductibleAPIController> _logger;

        public HealthPlanDeductibleAPIController(IHealthPlanDeductibleRepository IHealthPlanDeductibleRepository, IMapper mapper, ILogger<HealthPlanDeductibleAPIController> logger)
        {
            _IHealthPlanDeductibleRepository = IHealthPlanDeductibleRepository;
            _mapper = mapper;
            _logger = logger;
        }

        //GET: api/values
        [HttpGet]
        [Route("{fromPage}/{planOrBenefitID}")]
        public IActionResult Get(string fromPage, int planOrBenefitID)
        {
            var result = _IHealthPlanDeductibleRepository.GetDeductibleOopByPlanOrBenefitID(fromPage, planOrBenefitID).ToList();
            return Ok(result);
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "DeductibleGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var deductible = _IHealthPlanDeductibleRepository.GetById(id);
                if (deductible == null) return NotFound($"Benefit {id} was not found");
                return Ok(deductible);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]HealthPlanDeductible model)
        {
            ModelState.Remove(nameof(model.TermDate));
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                HealthPlanDeductible entity = _mapper.Map<HealthPlanDeductible>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.TermDate = model.TermDate.ToTermDate();
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                _IHealthPlanDeductibleRepository.Add(entity);

                if (!_IHealthPlanDeductibleRepository.DbState.IsValid)
                {
                    _IHealthPlanDeductibleRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("DeductibleGet", new { id = entity.HealthPlanDeductibleID });
                _logger.LogInformation("Deductible/Max OOP created");
                return Created(newUri, entity);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving deductible : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values
        [HttpPut]
        public IActionResult Put([FromBody]HealthPlanDeductible model)
        {
            ModelState.Remove(nameof(model.TermDate));
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                HealthPlanDeductible entity = _IHealthPlanDeductibleRepository.GetById(model.HealthPlanDeductibleID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.TermDate = model.TermDate.ToTermDate();
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();                
                _IHealthPlanDeductibleRepository.Update(entity);
                if (!_IHealthPlanDeductibleRepository.DbState.IsValid)
                {
                    _IHealthPlanDeductibleRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Deductible Updated : {0}", entity.HealthPlanDeductibleID);
                return Ok(entity.HealthPlanDeductibleID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Deductible : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            HealthPlanDeductible entity = _IHealthPlanDeductibleRepository.GetById(id);
            entity.UpdatedDate = base.TodaysDate;
            entity.UpdatedBy = base.UserName;
            entity.RecordStatus = (int)RecordStatus.Deleted;
            entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();

            _IHealthPlanDeductibleRepository.Update(entity);

            if (!_IHealthPlanDeductibleRepository.DbState.IsValid)
            {
                _IHealthPlanDeductibleRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(id);
        }
    }
}
