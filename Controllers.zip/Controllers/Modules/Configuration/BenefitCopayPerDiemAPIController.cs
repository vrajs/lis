using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitCopayPerDiem")]

    public class BenefitCopayPerDiemAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<BenefitCopayPerDiemAPIController> _logger;
        private IBenefitCopayPerDiemRepository _BenefitCopayPerDiemRepository;
        private IBenefitCopayPerDiemService _BenefitCopayPerDiemService;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public BenefitCopayPerDiemAPIController(ILogger<BenefitCopayPerDiemAPIController> logger, IBenefitCopayPerDiemRepository BenefitCopayPerDiemRepository, IMapper mapper, IBenefitCopayPerDiemService BenefitCopayPerDiemService)
        {
            _logger = logger;
            _BenefitCopayPerDiemRepository = BenefitCopayPerDiemRepository;
            _BenefitCopayPerDiemService = BenefitCopayPerDiemService;
            _mapper = mapper;
        }
        #endregion

        #region API Methods

        // GET: api/values
        [HttpGet("")]

        public IActionResult Get()
        {
            try
            {
                var benefitCopayPerDiemRes = _BenefitCopayPerDiemRepository.GetAllBenefitCopayPerDiem();
                if (!_BenefitCopayPerDiemRepository.DbState.IsValid)
                {
                    _BenefitCopayPerDiemRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<IEnumerable<BenefitCopayPerDiemViewModel>>(benefitCopayPerDiemRes));
            }
            catch (Exception ex)
            {

                _logger.LogError("Error while Getting BenefitCopayPerDiem : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitCopayPerDiemGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var benefitCopayPerDeim = _BenefitCopayPerDiemRepository.GetById(id);
                if (benefitCopayPerDeim == null) return NotFound($"BenefitCopayPerDiem {id} was not Found");
                if (!_BenefitCopayPerDiemRepository.DbState.IsValid)
                {
                    _BenefitCopayPerDiemRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<BenefitCopayPerDiemViewModel>(benefitCopayPerDeim));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting BenefitCopayPerDiem : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        [HttpGet]
        [Route("GetBenefitCopayPerDiemHeaderId/{BenefitHeaderId}")]
        public IActionResult GetCopayPerDiemByBenefitHeaderId(int BenefitHeaderId)
        {
            try
            {
                var benefitCopayPerDeimRes = _BenefitCopayPerDiemRepository.GetBenefitCopayPerDiem(BenefitHeaderId);
                if (!_BenefitCopayPerDiemRepository.DbState.IsValid)
                {
                    _BenefitCopayPerDiemRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<IEnumerable<BenefitCopayPerDiemViewModel>>(benefitCopayPerDeimRes));

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting BenefitCopayPerDiem : {0}", ex);
                return BadRequest(ex.Message);
            }

        }
        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitCopayPerDiemViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var benefitCopayPerDeim = _mapper.Map<BenefitCopayPerDiem>(model);
                benefitCopayPerDeim.CreatedDate = base.TodaysDate;
                benefitCopayPerDeim.CreatedBy = base.UserName;
                benefitCopayPerDeim.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, benefitCopayPerDeim.EffectiveDate, benefitCopayPerDeim.TermDate);
                benefitCopayPerDeim.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, benefitCopayPerDeim.EffectiveDate, benefitCopayPerDeim.TermDate).ToString();

                _BenefitCopayPerDiemService.CheckIfBenefitCopayPerDiemExist(benefitCopayPerDeim);
                if (!_BenefitCopayPerDiemService.BusinessState.IsValid)
                {
                    _BenefitCopayPerDiemService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                _BenefitCopayPerDiemRepository.Add(benefitCopayPerDeim);
                if (!_BenefitCopayPerDiemRepository.DbState.IsValid)
                {
                    _BenefitCopayPerDiemRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("BenefitCopayPerDiemGet", new { id = benefitCopayPerDeim.BenefitCopayPerDiemID });
                _logger.LogInformation("New BenefitCopayPerDiem Created");
                return Created(newUri, _mapper.Map<BenefitCopayPerDiemViewModel>(benefitCopayPerDeim));

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving BenefitCopayPerDiem : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]BenefitCopayPerDiemViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldBenefitCopayPerDeim = _BenefitCopayPerDiemRepository.GetById(model.BenefitCopayPerDiemID);
                if (oldBenefitCopayPerDeim == null) return NotFound($"Could not find a BenefitCopayPerDeim with an BenefitCopayPerDiemID of {model.BenefitCopayPerDiemID}");

                _mapper.Map(model, oldBenefitCopayPerDeim);
                oldBenefitCopayPerDeim.UpdatedBy = base.UserName;
                oldBenefitCopayPerDeim.UpdatedDate = base.TodaysDate;
                oldBenefitCopayPerDeim.EffectiveDate = model.EffectiveDate.Date;
                oldBenefitCopayPerDeim.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldBenefitCopayPerDeim.EffectiveDate, oldBenefitCopayPerDeim.TermDate);
                oldBenefitCopayPerDeim.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldBenefitCopayPerDeim.EffectiveDate, oldBenefitCopayPerDeim.TermDate).ToString();

                _BenefitCopayPerDiemService.CheckIfBenefitCopayPerDiemExist(oldBenefitCopayPerDeim);
                if (!_BenefitCopayPerDiemService.BusinessState.IsValid)
                {
                    _BenefitCopayPerDiemService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                _BenefitCopayPerDiemRepository.Update(oldBenefitCopayPerDeim);
                if (!_BenefitCopayPerDiemRepository.DbState.IsValid)
                {
                    _BenefitCopayPerDiemRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.BenefitCopayPerDiemID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating BenefitCopayPerDeim :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _BenefitCopayPerDiemRepository.DeleteById(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting BenefitCopayPerDiem : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
