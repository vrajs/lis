using AutoMapper;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class BenefitCopayPerDiemODController : BaseODController
    {
        #region Variables       
        private IBenefitCopayPerDiemRepository _IBenefitCopayPerDiemRepository;
        #endregion

        #region Ctor
        public BenefitCopayPerDiemODController(IBenefitCopayPerDiemRepository IBenefitCopayPerDiemRepository, IMapper mapper)
        {
            _IBenefitCopayPerDiemRepository = IBenefitCopayPerDiemRepository;
        }
        #endregion

        #region API Methods

        // GET: api/values
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BenefitCopayPerDiems")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetBenefitCopayPerDiems(int BenefitHeaderId)
        {
            var benefitCopayPerDiemQuery = _IBenefitCopayPerDiemRepository.GetBenefitCopayPerDiem(BenefitHeaderId);
            return Ok(benefitCopayPerDiemQuery);
        }
        #endregion

    }
}
