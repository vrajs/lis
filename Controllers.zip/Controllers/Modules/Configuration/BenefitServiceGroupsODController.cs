using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class BenefitServiceGroupsODController : BaseODController
    {
        #region Variables     

        private IBenefitServiceGroupsRepository _IBenefitServiceGroupsRepository;

        #endregion

        #region Constructor

        public BenefitServiceGroupsODController(IBenefitServiceGroupsRepository IBenefitServiceGroupsRepository)
        {
            _IBenefitServiceGroupsRepository = IBenefitServiceGroupsRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BenefitServiceGroups")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetBenefitServiceGroups(int BenefitHeaderID)
        {
            var benefitCopayPerDiemQuery = _IBenefitServiceGroupsRepository.GetBenefitServiceGroupsByBenefitHeaderId(BenefitHeaderID);
            return Ok(benefitCopayPerDiemQuery);
        }
    }
}
