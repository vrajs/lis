using Kwicle.Core.Common;
using Kwicle.Data.Contracts.View;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class TermHeaderOdataController : BaseODController
    {
        #region Variables        
        private IViewRepository _IViewRepository;
        #endregion

        #region Ctor        
        public TermHeaderOdataController(IViewRepository IViewRepository)
        {
            _IViewRepository = IViewRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Terms")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetTerms(int ContractId, byte? filterStatus)
        {
            var termsQuery = _IViewRepository.Terms.Where(i => i.RecordStatus != (int)RecordStatus.Deleted);

            if (filterStatus.HasValue && filterStatus != (int)FilterStatus.All)
            {
                termsQuery = termsQuery.Where(i => i.RecordStatus == filterStatus.Value);
            }
            if (ContractId > 0)
            {
                termsQuery = termsQuery.Where(i => i.ContractID == ContractId);
            }
            return Ok(termsQuery.ToList());
        }
    }
}
