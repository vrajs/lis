using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class TermCodeODController : BaseODController
    {
        #region Variables        
        private ITermCodeRepository _termcodeRepository;
        #endregion

        #region Ctor        
        public TermCodeODController(ITermCodeRepository termcodeRepository)
        {
            _termcodeRepository = termcodeRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("TermCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetTermCodes(int TermHeaderId, int? ClinicalCodeTypeId)
        {
            var termcodeQuery = _termcodeRepository.GetTermCodes(TermHeaderId, ClinicalCodeTypeId ?? 0);
            return Ok(termcodeQuery);
        }
    }
}
