﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/UserDataAuthorization")]    
    public class UserDataAuthorizationAPIController : BaseAPIController
    {
        private readonly IUserDataAuthorizationService _userDataAuthorizationService;
        private readonly IUserDataAuthorizationRepository _userDataAuthorizationRepository;
        private ILogger<UserDataAuthorizationAPIController> _logger;
        private IMapper _mapper;        

        public UserDataAuthorizationAPIController(ILogger<UserDataAuthorizationAPIController> logger,
            IMapper mapper, IUserDataAuthorizationService userDataAuthorizationService,
            IUserDataAuthorizationRepository userDataAuthorizationRepository)            
        {            
            _logger = logger;
            _mapper = mapper;         
            _userDataAuthorizationRepository = userDataAuthorizationRepository;
            _userDataAuthorizationService = userDataAuthorizationService;
        }

        [HttpPost]
        public IActionResult Post([FromBody] UserDataAuthorizationModel model)
        {

            if (model.DataPreferenceByID > 0)
            {                
                model.UserID = model.UserID;
                model.UserName = UserName;
                model.CreatedDate = TodaysDate;
                model.CreatedBy = UserName;
                model.OrganizationID = OrganizationID;
                model.DataPreferenceByID = model.DataPreferenceByID;
                model.DataPreferenceIDs = model.DataPreferenceIDs;

                _userDataAuthorizationService.SaveUserDataAuthorization(model);

                if (!_userDataAuthorizationService.BusinessState.IsValid)
                {
                    _userDataAuthorizationService.BusinessState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
            }

            return Ok(model.UserID);
        }

        [HttpPut]
        public IActionResult Put([FromBody] UserDataAuthorizationModel model)
        {
            if (model.DataPreferenceByID > 0)
            {
                UserDataAuthorizationModel udam = new UserDataAuthorizationModel();
                udam.UserID = model.UserID;
                udam.UserName = UserName;
                udam.CreatedDate = TodaysDate;
                udam.CreatedBy = UserName;
                udam.OrganizationID = OrganizationID;
                udam.DataPreferenceByID = model.DataPreferenceByID;
                udam.DataPreferenceIDs = model.DataPreferenceIDs;
                _userDataAuthorizationService.SaveUserDataAuthorization(udam);
                if (!_userDataAuthorizationService.BusinessState.IsValid)
                {
                    _userDataAuthorizationService.BusinessState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
            }
            else
            {
                _userDataAuthorizationRepository.DeleteByUserID(model.UserID);
                if (!_userDataAuthorizationRepository.DbState.IsValid)
                {
                    _userDataAuthorizationRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
            }

            return Ok();
        }
    }
}
