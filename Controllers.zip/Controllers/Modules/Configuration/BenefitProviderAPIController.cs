using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Configuration;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Business.Interfaces.Configuration;
using System.Net;
using Kwicle.Business.Interfaces.Provider;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitProvider")]
    public class BenefitProviderAPIController : BaseAPIController
    {
        private readonly IBenefitProviderRepository _IBenefitProviderRepository;
        private readonly IBenefitProviderService _IBenefitProviderService;
        private readonly IProviderService _IProviderService;
        private IMapper _mapper;
        private ILogger<BenefitProviderAPIController> _logger;

        public BenefitProviderAPIController(IBenefitProviderRepository IBenefitProviderRepository, IBenefitProviderService IBenefitProviderService, IProviderService IProviderService, IMapper mapper, ILogger<BenefitProviderAPIController> logger)
        {
            _IBenefitProviderRepository = IBenefitProviderRepository;
            _IBenefitProviderService = IBenefitProviderService;
            _IProviderService = IProviderService;
            _mapper = mapper;
            _logger = logger;
        }

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var benefitProvider = _IBenefitProviderRepository.GetByPredicate(null);
            return Ok(_mapper.Map<IEnumerable<BenefitProviderModel>>(benefitProvider));
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitProviderGet")]
        public IActionResult Get(int id)
        {
            var benefitProvider = _IBenefitProviderRepository.GetById(id);
            if (benefitProvider == null) return NotFound($"Benefit Provider {id} was not found");
            return Ok(_mapper.Map<BenefitProviderModel>(benefitProvider));
        }

        [HttpGet]
        [Route("GetBenefitProviderByBenefitHeaderId/{BenefitHeaderId}")]
        public IActionResult GetBenefitProviderByBenefitHeaderId(int BenefitHeaderId)
        {
            var benefitProviders = _IBenefitProviderRepository.GetBenefitProviderByBenefitHeaderId(BenefitHeaderId);
            return Ok(_mapper.Map<IEnumerable<BenefitProviderModel>>(benefitProviders));
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitProviderModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var benefitProvider = _mapper.Map<BenefitProvider>(model);
                benefitProvider.CreatedDate = base.TodaysDate;
                benefitProvider.CreatedBy = base.UserName;
                benefitProvider.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, benefitProvider.EffectiveDate, benefitProvider.TermDate);
                benefitProvider.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, benefitProvider.EffectiveDate, benefitProvider.TermDate).ToString();

                _IBenefitProviderService.CheckIfExist(benefitProvider);
                if (!_IBenefitProviderService.BusinessState.IsValid)
                {
                    _IBenefitProviderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IProviderService.CheckProviderDataValidity(benefitProvider.IdentifierTypeID, benefitProvider.IdentifierCode);
                if (!_IProviderService.BusinessState.IsValid)
                {
                    _IProviderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IBenefitProviderRepository.Add(benefitProvider);
                if (!_IBenefitProviderRepository.DbState.IsValid)
                {
                    _IBenefitProviderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("BenefitProviderGet", new { id = benefitProvider.BenefitProviderID });
                _logger.LogInformation("New Benefit Provider Created ");
                return Created(newUri, _mapper.Map<BenefitProviderModel>(benefitProvider));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Benefit Provider : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]BenefitProviderModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldBenefitProvider = _IBenefitProviderRepository.GetById(model.BenefitProviderID);
                if (oldBenefitProvider == null) return NotFound($"Could not find a Benefit Provider with an BenefitProviderID of {model.BenefitProviderID}");

                _mapper.Map(model, oldBenefitProvider);
                oldBenefitProvider.UpdatedBy = base.UserName;
                oldBenefitProvider.UpdatedDate = base.TodaysDate;
                oldBenefitProvider.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldBenefitProvider.EffectiveDate, oldBenefitProvider.TermDate);
                oldBenefitProvider.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldBenefitProvider.EffectiveDate, oldBenefitProvider.TermDate).ToString();

                _IBenefitProviderService.CheckIfExist(oldBenefitProvider);
                if (!_IBenefitProviderService.BusinessState.IsValid)
                {
                    _IBenefitProviderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IProviderService.CheckProviderDataValidity(oldBenefitProvider.IdentifierTypeID, oldBenefitProvider.IdentifierCode);
                if (!_IProviderService.BusinessState.IsValid)
                {
                    _IProviderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IBenefitProviderRepository.Update(oldBenefitProvider);
                if (!_IBenefitProviderRepository.DbState.IsValid)
                {
                    _IBenefitProviderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Benefi Provider Updated : {0}", oldBenefitProvider.BenefitProviderID);
                return Ok(model.BenefitProviderID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Benefit Provider: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _IBenefitProviderRepository.DeleteById(id);
            return Ok(id);
        }
        #endregion
    }
}
