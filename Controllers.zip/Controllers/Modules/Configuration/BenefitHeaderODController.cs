using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class BenefitHeaderODController : BaseODController
    {
        #region Variables     

        private IBenefitHeaderRepository _IBenefitHeaderRepository;

        #endregion

        #region Constructor

        public BenefitHeaderODController(IBenefitHeaderRepository IBenefitHeaderRepository)
        {
            _IBenefitHeaderRepository = IBenefitHeaderRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BenefitHeaders")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetBenefitHeaders(int healthPlanId, bool isInclude, int filterStatus)
        {
            IQueryable<GetBenefitModel> benefitListQuery = null;
            if (healthPlanId == 0)
            {
                if (filterStatus == (int)FilterStatus.Active)
                {
                    benefitListQuery = _IBenefitHeaderRepository.GetBenefits().Where(x => x.RecordStatus == (int)RecordStatus.Active);
                }
                if (filterStatus == (int)FilterStatus.All)
                {
                    benefitListQuery = _IBenefitHeaderRepository.GetBenefits().Where(x => x.RecordStatus != (int)RecordStatus.Deleted);
                }
            }
            else
            {
                //if (filterStatus == (int)FilterStatus.Active)
                //{
                //    benefitListQuery = _IBenefitHeaderRepository.GetBenefits(healthPlanId, isInclude).Where(i => i.RecordStatus == (int)RecordStatus.Active);
                //}
                //if (filterStatus == (int)FilterStatus.All)
                //{
                //    benefitListQuery = _IBenefitHeaderRepository.GetBenefits(healthPlanId, isInclude).Where(i => i.RecordStatus == (int)RecordStatus.Active || i.RecordStatus == (int)RecordStatus.Termed || i.RecordStatus == (int)RecordStatus.InActive);
                //}
                benefitListQuery = _IBenefitHeaderRepository.GetBenefits(healthPlanId, isInclude).Where(i => i.RecordStatus != (byte)RecordStatus.Deleted);
            }
            return Ok(benefitListQuery);
        }
    }
}
