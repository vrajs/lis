using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Text;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/TermCode")]
    public class TermCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<TermCodeAPIController> _logger;
        private ITermCodeRepository _termCodeRepository;
        private ICommonClinicalCodeService _commonClinicalCodeService;
        private ITermCodeService _termCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor  
        public TermCodeAPIController(ITermCodeRepository termCodeRepository, ICommonClinicalCodeService commonClinicalCodeService, ILogger<TermCodeAPIController> logger, IMapper mapper, ITermCodeService termCodeService)
        {
            _logger = logger;
            _termCodeRepository = termCodeRepository;
            _mapper = mapper;
            _commonClinicalCodeService = commonClinicalCodeService;
            _termCodeService = termCodeService;
        }
        #endregion


        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var termCodesRes = _termCodeRepository.GetAllTermCodes(null, null);
                return Ok(termCodesRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Term Code: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "TermCodeGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var termCode = _termCodeRepository.GetById(id);
                if (termCode == null) return NotFound($"Term Code {id} was not found");
                return Ok(_mapper.Map<TermCodeViewModel>(termCode));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Term Code: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]TermCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                StringBuilder sb = new StringBuilder();
                var termCode = _mapper.Map<TermCodes>(model);
                termCode.CreatedDate = base.TodaysDate;
                termCode.CreatedBy = base.UserName;
                termCode.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, termCode.EffectiveDate, termCode.TermDate);
                termCode.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, termCode.EffectiveDate, termCode.TermDate).ToString();

                //if (termCode.ClinicalCodeTypeID == (int)ClinicalCodeType.POS)
                //    if (_commonClinicalCodeService.CheckCommonClinicalCode(termCode.ClinicalCodeTypeID, termCode.MinCode) == false)
                //        return NotFound($"Code {termCode.MinCode} was not found");

                //if (_commonClinicalCodeService.CheckCommonClinicalCode(termCode.ClinicalCodeTypeID, termCode.MinCode) == false)
                //    sb.Append($"Min Code {termCode.MinCode} was not found </br>");


                //if (_commonClinicalCodeService.CheckCommonClinicalCode(termCode.ClinicalCodeTypeID, termCode.MaxCode) == false)
                //    sb.Append($"Max Code {termCode.MaxCode} was not found");

                //if (sb.Length > 0) return NotFound(sb.ToString());

                _commonClinicalCodeService.CheckCodeValidity(termCode.ClinicalCodeTypeID, termCode.MinCode, termCode.MaxCode, termCode.EffectiveDate, termCode.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }


                _termCodeService.CheckIfCodeExist(termCode);
                if (!_termCodeService.BusinessState.IsValid)
                {
                    _termCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _termCodeRepository.Add(termCode);
                if (!_termCodeRepository.DbState.IsValid)
                {
                    _termCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("TermCodeGet", new { id = termCode.TermCodesID });
                _logger.LogInformation("New Term Code Created ");
                return Created(newUri, _mapper.Map<TermCodeViewModel>(termCode));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Term Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]TermCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                StringBuilder sb = new StringBuilder();
                var oldTermCode = _termCodeRepository.GetById(model.TermCodesID);
                if (oldTermCode == null) return NotFound($"Could not find a Term Code with an TermCodesID of {model.TermCodesID}");

                _mapper.Map(model, oldTermCode);
                oldTermCode.UpdatedBy = base.UserName;
                oldTermCode.UpdatedDate = base.TodaysDate;
                oldTermCode.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldTermCode.EffectiveDate, oldTermCode.TermDate);
                oldTermCode.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldTermCode.EffectiveDate, oldTermCode.TermDate).ToString();

                //if (oldTermCode.ClinicalCodeTypeID == (int)ClinicalCodeType.POS)
                //    if (_commonClinicalCodeService.CheckCommonClinicalCode(oldTermCode.ClinicalCodeTypeID, oldTermCode.MinCode) == false)
                //        return NotFound($"Code {oldTermCode.MinCode} was not found");

                //if (_commonClinicalCodeService.CheckCommonClinicalCode(oldTermCode.ClinicalCodeTypeID, oldTermCode.MinCode) == false)
                //    sb.Append($"Min Code {oldTermCode.MinCode} was not found </br>");


                //if (_commonClinicalCodeService.CheckCommonClinicalCode(oldTermCode.ClinicalCodeTypeID, oldTermCode.MaxCode) == false)
                //    sb.Append($"Max Code {oldTermCode.MaxCode} was not found");

                //if (sb.Length > 0) return NotFound(sb.ToString());

                _commonClinicalCodeService.CheckCodeValidity(oldTermCode.ClinicalCodeTypeID, oldTermCode.MinCode, oldTermCode.MaxCode, oldTermCode.EffectiveDate, oldTermCode.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _termCodeService.CheckIfCodeExist(oldTermCode);
                if (!_termCodeService.BusinessState.IsValid)
                {
                    _termCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _termCodeRepository.Update(oldTermCode);
                if (!_termCodeRepository.DbState.IsValid)
                {
                    _termCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(model.TermCodesID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Term Code: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _termCodeRepository.DeleteById(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Term Code: {ex}");
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
