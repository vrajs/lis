using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Core.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/TermLimit")]
    public class TermLimitAPIController : BaseAPIController
    {
        private readonly ITermLimitRepository _ITermLimitRepository;
        private IMapper _mapper;
        private ILogger<TermLimitAPIController> _logger;

        public TermLimitAPIController(ITermLimitRepository ITermLimitRepository, IMapper mapper, ILogger<TermLimitAPIController> logger)
        {
            _ITermLimitRepository = ITermLimitRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "TermLimitGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var termLimit = _ITermLimitRepository.GetById(id);
                if (termLimit == null) return NotFound($"Term Limit {id} was not found");
                if (!_ITermLimitRepository.DbState.IsValid)
                {
                    _ITermLimitRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<TermLimitModel>(termLimit));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Term Limit: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetTermLimitByTermHeaderID/{TermHeaderId}")]
        public IActionResult GetTermLimitByTermHeaderID(int TermHeaderId)
        {
            try
            {
                var termLimitRes = _ITermLimitRepository.GetTermLimitByTermHeaderID(TermHeaderId).OrderByDescending(x=>x.TermLimitID).LastOrDefault();
                if (!_ITermLimitRepository.DbState.IsValid)
                {
                    _ITermLimitRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(termLimitRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting TermHeaderId {TermHeaderId} Term Limit: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]TermLimitModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                TermLimit entity = _mapper.Map<TermLimit>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                _ITermLimitRepository.Add(entity);
                if (!_ITermLimitRepository.DbState.IsValid)
                {
                    _ITermLimitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("TermLimitGet", new { id = entity.TermLimitID });
                _logger.LogInformation("New Term Limit created");
                return Created(newUri, _mapper.Map<TermLimitModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Term Limit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]TermLimitModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                TermLimit entity = _ITermLimitRepository.GetById(model.TermLimitID);
                if (entity == null) return NotFound($"Could not find term limit with an TermLimitID of {model.TermLimitID}");
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                _ITermLimitRepository.Update(entity);
                if (!_ITermLimitRepository.DbState.IsValid)
                {
                    _ITermLimitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Term Limit Updated : {0}", entity.TermLimitID);
                return Ok(entity.TermLimitID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Term Limit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _ITermLimitRepository.DeleteById(id);
                if (!_ITermLimitRepository.DbState.IsValid)
                {
                    _ITermLimitRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Term Limit : {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
