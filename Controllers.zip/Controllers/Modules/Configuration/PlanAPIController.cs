using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860
using System.Linq;
using System.Net;

namespace Kwicle.Service.Controllers.Modules.Configuration
{

    [Route("api/Plan")]
    public class PlanAPIController : BaseAPIController
    {
        private readonly IPlanRepository _IPlanRepository;
        private readonly IPlanService _IPlanService;
        private readonly IBenefitHeaderRepository _IBenefitHeaderRepository;
        private IMapper _mapper;
        private ILogger<PlanAPIController> _logger;
        private readonly IBenefitHeaderHealthPlanRepository _BenefitHeaderHealthPlanRepository;
        public PlanAPIController(IPlanRepository IPlanRepository, IMapper mapper, ILogger<PlanAPIController> logger, IBenefitHeaderRepository IBenefitHeaderRepository, IPlanService IPlanService, IBenefitHeaderHealthPlanRepository BenefitHeaderHealthPlanRepository)
        {
            _IPlanRepository = IPlanRepository;
            _mapper = mapper;
            _logger = logger;
            _IBenefitHeaderRepository = IBenefitHeaderRepository;
            _IPlanService = IPlanService;
            _BenefitHeaderHealthPlanRepository = BenefitHeaderHealthPlanRepository;
        }

        [Route("GetPlanKeyVal")]
        [HttpGet]
        public IActionResult Get(int? companyId = null,int? subCompanyId=null, int? lobId=null)
        {
            try
            {
                var planQuery = from n in _IPlanRepository.GetByPredicate(i => (companyId.HasValue ? i.CompanyID == companyId : true) && (subCompanyId.HasValue ? i.SubCompanyID == subCompanyId : true)
                                && (lobId.HasValue ? i.LobID == lobId : true))
                                select new KeyVal<int, string>()
                                {
                                    Key = n.HealthPlanID,
                                    Value = n.PlanName
                                };
                var plans = planQuery.ToList();
                return Ok(plans);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in getting Plan {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}", Name = "PlanGet")]
        public IActionResult Get(int id)
        {
            try
            {
                HealthPlan plan = _IPlanRepository.GetById(id);
                if (plan == null) return NotFound($"Plan {id} was not found");
                return Ok(plan);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }
        [Route("GetReadonly/{Id}")]
        [HttpGet()]
        public IActionResult GetReadonly(int Id)
        {
            try
            {
                GetPlanModel plan = _IPlanRepository.GetPlans().Single(i => i.HealthPlanID == Id);
                if (plan == null) return NotFound($"Plan {Id} was not found");
                return Ok(plan);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]HealthPlan model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _IPlanService.CheckDuplicate(model);
            if (!_IPlanService.BusinessState.IsValid)
            {
                _IPlanService.BusinessState.ErrorMessages.ForEach((errorMessage) =>
                {

                    this.ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                });

                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
            }
            try
            {
                model.CreatedDate = base.TodaysDate;
                model.CreatedBy = base.UserName;
                model.TermDate = model.TermDate.ToTermDate();
                model.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate);
                model.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate).ToString();

                _IPlanRepository.Add(model);
                if (!_IPlanRepository.DbState.IsValid)
                {
                    _IPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("PlanGet", new { id = model.HealthPlanID });
                _logger.LogInformation("New Health Plan Created ");
                return Created(newUri, model);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Health Plan : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody] HealthPlan model)
        {

            _IPlanService.CheckDuplicate(model);
            if (!_IPlanService.BusinessState.IsValid)
            {
                _IPlanService.BusinessState.ErrorMessages.ForEach((errorMessage) =>
                {

                    this.ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                });

                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
            }

            model.TermDate = model.TermDate.ToTermDate();
            model.UpdatedDate = base.TodaysDate;
            model.UpdatedBy = base.UserName;
            model.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate);
            model.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate).ToString();

            _IPlanRepository.Update(model);

            if (!_IPlanRepository.DbState.IsValid)
            {
                _IPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(model);

        }

        [Route("AddPlanBenefits")]
        [HttpPut]
        public IActionResult AddPlanBenefits([FromBody]AddPlanBenefitsModel addPlanBenefitsModel)
        {
            try
            {
                List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans = new List<BenefitHeaderHealthPlan>();
                BenefitHeaderHealthPlan benefitHeaderHealthPlan;
                addPlanBenefitsModel.BenefitHeaderIds.ForEach((benefit) =>
                {
                    benefitHeaderHealthPlan = new BenefitHeaderHealthPlan()
                    {
                        BenefitHeaderID = benefit,
                        CreatedBy = base.UserName,
                        CreatedDate = base.TodaysDate,
                        EffectiveDate = addPlanBenefitsModel.EffectiveDate,
                        HealthPlanID = addPlanBenefitsModel.HealthPlanId,
                        IsFreezed = 0,
                        RecordStatus = 0,
                        RecordStatusChangeComment = "",
                        TermDate = DateTime.MaxValue
                    };

                    benefitHeaderHealthPlans.Add(benefitHeaderHealthPlan);
                });
                _BenefitHeaderHealthPlanRepository.BulkInsert(benefitHeaderHealthPlans);

                //_IPlanRepository.AddBenefitsToPlan(addPlanBenefitsModel.HealthPlanId, addPlanBenefitsModel.BenefitHeaderIds, addPlanBenefitsModel.EffectiveDate, base.UserName, base.TodaysDate);
                if (!_BenefitHeaderHealthPlanRepository.DbState.IsValid)
                {
                    _BenefitHeaderHealthPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(addPlanBenefitsModel.HealthPlanId);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while adding benefits to plan : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [Route("RemoveOrTermPlanBenefits")]
        [HttpPut]
        public IActionResult RemoveOrTermPlanBenefits([FromBody]TermPlanBenefitsModel termPlanBenefitsModel)
        {
            try
            {
                _IPlanRepository.RemoveOrTermPlanBenefit(termPlanBenefitsModel.HealthPlanId, termPlanBenefitsModel.BenefitHeaderIds, base.TodaysDate, base.UserName, termPlanBenefitsModel.RecordStatus, termPlanBenefitsModel.RecordStatusChangeReason, termPlanBenefitsModel.TermDate);
                if (!_IPlanRepository.DbState.IsValid)
                {
                    _IPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(termPlanBenefitsModel.HealthPlanId);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing or terming benefits to plan : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [Route("RemovePlanBenefit/HealthPlanID/{HealthPlanID}/BenefitHeaderID/{BenefitHeaderID}")]
        [HttpDelete]
        public IActionResult RemovePlanBenefit(int HealthPlanID, int BenefitHeaderID)
        {
            try
            {

                _IPlanRepository.RemovePlanBenefit(HealthPlanID, BenefitHeaderID, base.TodaysDate, base.UserName, "Removed from Plan", 3);
                if (!_IPlanRepository.DbState.IsValid)
                {
                    _IPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(new { HealthPlanID = HealthPlanID, BenefitHeaderID = BenefitHeaderID });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while adding benefits to plan : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [Route("CopyHealthPlan")]
        [HttpPatch]
        public IActionResult CopyHealthPlan([FromBody]CopyPlanModel model)
        {
            int createdHealthPlanID = -1;

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                createdHealthPlanID = _IPlanRepository.CopyHealthPlan(model.PlanId, model.PlanCode, model.PlanName, string.Join(",", model.BenefitHeaderIds), model.ApprovalStatusID, model.EffectiveDate, base.UserName, base.TodaysDate, model.ApprovalDate, model.TermDate);
                if (!_IPlanRepository.DbState.IsValid)
                {
                    _IPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("PlanGet", new { id = createdHealthPlanID });
                _logger.LogInformation("Health Plan Copied ");

                return Created(newUri, createdHealthPlanID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while copying plan : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {

            _IPlanRepository.Delete(id, base.TodaysDate, base.UserName, (byte)RecordStatus.Deleted, RecordStatus.Deleted.ToString());
            if (!_IPlanRepository.DbState.IsValid)
            {
                _IPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(id);
        }

        [HttpPut]
        [Route("TerminatePlan")]
        public IActionResult TerminatePlan([FromBody]TerminateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                _IPlanRepository.Delete(model.Id, base.TodaysDate, base.UserName, (byte)RecordStatus.Termed, model.TermReason, model.TermDate);

                if (!_IPlanRepository.DbState.IsValid)
                {
                    _IPlanRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while terminating Plan: {ex}");
                return BadRequest(ex.Message);
            }
        }

        //CheckPlanConfigurationHasData
        [HttpGet]
        [Route("CheckPlanConfigurationHasData/{healthPlanID}")]
        public IActionResult CheckPlanConfigurationHasData(int healthPlanID)
        {
            var res = _IPlanRepository.CheckPlanConfigurationHasData(healthPlanID);
            return Ok(res);
        }
    }
}
