using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitServiceGroups")]
    public class BenefitServiceGroupsAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<BenefitServiceGroupsAPIController> _logger;
        private IBenefitServiceGroupsRepository _BenefitServiceGroupsRepository;
        private IBenefitServiceGroupsService _BenefitServiceGroupsService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public BenefitServiceGroupsAPIController(IBenefitServiceGroupsRepository BenefitServiceGroupsRepository, ILogger<BenefitServiceGroupsAPIController> logger, IMapper mapper, IBenefitServiceGroupsService BenefitServiceGroupsService)
        {
            _logger = logger;
            _BenefitServiceGroupsRepository = BenefitServiceGroupsRepository;
            _BenefitServiceGroupsService = BenefitServiceGroupsService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitServiceGroupGet")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitServiceGroupModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                BenefitServiceGroup entity = _mapper.Map<BenefitServiceGroup>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _BenefitServiceGroupsService.CheckIfServiceGroupExist(entity);
                if (!_BenefitServiceGroupsService.BusinessState.IsValid)
                {
                    _BenefitServiceGroupsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                _BenefitServiceGroupsService.CheckGroupValidity(entity.ClinicalCodeGroupDetailID ?? 0, entity.EffectiveDate, entity.TermDate);
                if (!_BenefitServiceGroupsService.BusinessState.IsValid)
                {
                    _BenefitServiceGroupsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _BenefitServiceGroupsRepository.Add(entity);
                if (!_BenefitServiceGroupsRepository.DbState.IsValid)
                {
                    _BenefitServiceGroupsRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("BenefitServiceGroupGet", new { id = entity.BenefitServiceGroupID });
                _logger.LogInformation("New Benefit Service Group created");
                return Created(newUri, _mapper.Map<BenefitServiceGroup>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving service group : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpPut()]
        public IActionResult Put([FromBody]BenefitServiceGroupModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _BenefitServiceGroupsRepository.GetById(model.BenefitServiceGroupID);
                if (entity == null) return NotFound($"Could not find benefit service group with an BenefitServiceGroupID of {model.BenefitServiceGroupID}");

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _BenefitServiceGroupsService.CheckIfServiceGroupExist(entity);
                if (!_BenefitServiceGroupsService.BusinessState.IsValid)
                {
                    _BenefitServiceGroupsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                if (entity.ClinicalCodeGroupDetailID > 0)
                {
                    _BenefitServiceGroupsService.CheckGroupValidity(entity.ClinicalCodeGroupDetailID ?? 0, entity.EffectiveDate, entity.TermDate);
                    if (!_BenefitServiceGroupsService.BusinessState.IsValid)
                    {
                        _BenefitServiceGroupsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                    }
                }

                _BenefitServiceGroupsRepository.Update(entity);
                if (!_BenefitServiceGroupsRepository.DbState.IsValid)
                {
                    _BenefitServiceGroupsRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Benefit service groups updated  : {0}", entity.BenefitServiceGroupID);
                return Ok(model.BenefitServiceGroupID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating BenefitCopayPerDeim :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            BenefitServiceGroup entity = _BenefitServiceGroupsRepository.GetById(id);
            entity.RecordStatus = (int)RecordStatus.Deleted;
            entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();

            _BenefitServiceGroupsRepository.Update(entity);

            if (!_BenefitServiceGroupsRepository.DbState.IsValid)
            {
                _BenefitServiceGroupsRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(id);
        }
    }
}
