using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("odata")]
    public class PlanODataController : BaseODController
    {
        private readonly IPlanRepository _IPlanRepository;

        public PlanODataController(IPlanRepository IPlanRepository)
        {
            _IPlanRepository = IPlanRepository;
        }
        // GET: api/values
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Plans")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetPlans(int? LobID,int? benefitHeaderID, bool isInclude)
        {
            var plans = (object)null;
            if (LobID != null)
            {
                plans = _IPlanRepository.GetPlans().Where(e => e.LobID == LobID);
            }
            else if(benefitHeaderID.HasValue)
            {
                plans = _IPlanRepository.GetPlans(benefitHeaderID.Value, isInclude);
            }
            else
            {
                plans = _IPlanRepository.GetPlans();
            }
            return Ok(plans);
        }

        // GET: api/values
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ActivePlansForMemberEligibility")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetActivePlansForMemberEligibility()
        {
            var plans = (object)null;
            
            plans = _IPlanRepository.GetActivePlansForMemberEligibility();

            return Ok(plans);
        }
    }
}
