using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Business.Interfaces.Configuration;
using System.Net;

namespace Kwicle.Service.Controllers.Modules.Configuration
{

    [Route("api/BenefitHeaderHealthPlan")]
    public class BenefitHeaderHealthPlanAPIController : BaseAPIController
    {
        #region Variables
        private readonly IBenefitHeaderHealthPlanRepository _BenefitHeaderHealthPlanRepository;
        private readonly IBenefitHeaderHealthPlanService _benefitHeaderHealthPlanService;
        private ILogger<BenefitHeaderHealthPlanAPIController> _logger;
        #endregion

        #region Ctor
        public BenefitHeaderHealthPlanAPIController(IBenefitHeaderHealthPlanRepository BenefitHeaderHealthPlanRepository, ILogger<BenefitHeaderHealthPlanAPIController> logger, IBenefitHeaderHealthPlanService benefitHeaderHealthPlanService)
        {
            _BenefitHeaderHealthPlanRepository = BenefitHeaderHealthPlanRepository;
            _logger = logger;
            _benefitHeaderHealthPlanService = benefitHeaderHealthPlanService;
        }
        #endregion

        #region Http Methods
        [HttpPost]
        public ActionResult Save([FromBody]List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans)
        {
            try
            {
                foreach(var obj in benefitHeaderHealthPlans)
                {
                    _benefitHeaderHealthPlanService.CheckValidity(obj);
                    if (!_benefitHeaderHealthPlanService.BusinessState.IsValid)
                    {
                        _benefitHeaderHealthPlanService.BusinessState.ErrorMessages.ForEach((error) => {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                    }
                }

                _BenefitHeaderHealthPlanRepository.BulkInsert(benefitHeaderHealthPlans);
                //_IPlanRepository.AddBenefitsToPlan(addPlanBenefitsModel.HealthPlanId, addPlanBenefitsModel.BenefitHeaderIds, addPlanBenefitsModel.EffectiveDate, base.UserName, base.TodaysDate);
                if (!_BenefitHeaderHealthPlanRepository.DbState.IsValid)
                {
                    _BenefitHeaderHealthPlanRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in saving Benefit Header Health Plan {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        //[HttpPut]
        //public ActionResult Update([FromBody]List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans)
        //{
        //    try
        //    {
        //        _BenefitHeaderHealthPlanRepository.BulkUpdate(benefitHeaderHealthPlans);
        //        if (!_BenefitHeaderHealthPlanRepository.DbState.IsValid)
        //        {
        //            _BenefitHeaderHealthPlanRepository.DbState.ErrorMessages.ForEach((error) =>
        //            {
        //                this.ModelState.AddModelError(error.Key, error.Value);
        //            });
        //            return BadRequest(this.ModelState);
        //        }
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {

        //        _logger.LogError("Error in updating Benefit Header Health Plan {0}", ex);
        //        return BadRequest(ex.ToErrorMessage());
        //    }
        //}
        [Route("HealthPlan/{healthPlanId}/BenefitHeader/{benefitHeaderId}")]
        [HttpDelete]
        public ActionResult Delete(int healthPlanId, int benefitHeaderId)
        {
            try
            {
                BenefitHeaderHealthPlan entity = _BenefitHeaderHealthPlanRepository.Delete(healthPlanId, benefitHeaderId, base.UserName, base.TodaysDate);
                if (!_BenefitHeaderHealthPlanRepository.DbState.IsValid)
                {
                    _BenefitHeaderHealthPlanRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                else
                {
                    if (entity == null) return NoContent();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting health plan benefit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [Route("RemoveOrTermPlanBenefits")]
        [HttpPut]
        public ActionResult Term([FromBody]BenefitHeaderHealthPlanTermModel benefitHeaderHealthPlanTermModel)
        {
            try
            {
                _BenefitHeaderHealthPlanRepository.BulkTerm(benefitHeaderHealthPlanTermModel);
                return Ok();
            }
            catch (Exception ex)
            {

                _logger.LogError("Error in term Benefit Header Health Plan ", ex);
                return BadRequest(ex.ToErrorMessage());
            }


        }

        [Route("ConfigureBenefitProrityForClaim")]
        [HttpPost]
        public ActionResult ConfigureBenefitProrityForClaim([FromBody]ConfigureBenefitProrityForClaimViewModel model)
        {
            try
            {
                _BenefitHeaderHealthPlanRepository.ConfigureBenefitProrityForClaim(model.HealthPlanID, model.ListBenefit, base.UserName, base.TodaysDate);
                if (!_BenefitHeaderHealthPlanRepository.DbState.IsValid)
                {
                    _BenefitHeaderHealthPlanRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in configuring benefit priority for claim", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
        #endregion
    }
}
