using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Configuration;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Configuration
{
    [Route("api/BenefitHeader")]
    public class BenefitHeaderAPIController : BaseAPIController
    {
        private readonly IBenefitHeaderRepository _IBenefitHeaderRepository;
        private readonly IBenefitProviderSpecialtyRepository _IBenefitProviderSpecialtyRepository;
        private readonly IPlanRepository _IPlanRepository;
        private readonly IBenefitHeaderService _IBenefitHeaderService;
        private IMapper _mapper;
        private ILogger<BenefitHeaderAPIController> _logger;

        public BenefitHeaderAPIController(IBenefitHeaderRepository IBenefitHeaderRepository, IBenefitProviderSpecialtyRepository IBenefitProviderSpecialtyRepository, IPlanRepository IPlanRepository, IMapper mapper, ILogger<BenefitHeaderAPIController> logger, IBenefitHeaderService IBenefitHeaderService)
        {
            _IBenefitHeaderRepository = IBenefitHeaderRepository;
            _IBenefitProviderSpecialtyRepository = IBenefitProviderSpecialtyRepository;
            _IPlanRepository = IPlanRepository;
            _IBenefitHeaderService = IBenefitHeaderService;
            _mapper = mapper;
            _logger = logger;
        }


        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            var benefitList = _IBenefitHeaderRepository.GetBenefits();
            return Ok(benefitList.ToList());
        }

        [HttpGet("GetView/{id}")]
        public IActionResult GetView(int id)
        {
            try
            {
                var benefitHeader = _IBenefitHeaderRepository.GetBenefits().Single(x => x.BenefitHeaderID == id);
                if (benefitHeader == null) return NotFound($"Benefit {id} was not found");
                return Ok(benefitHeader);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "BenefitHeaderGet")]
        public IActionResult Get(int id)
        {
            try
            {
                //BenefitViewModel benefitHeader = _IBenefitHeaderRepository.GetByID(id);
                var benefitHeader = _IBenefitHeaderRepository.GetById(id);
                benefitHeader.BenefitProviderSpecialties = _IBenefitProviderSpecialtyRepository.GetByBenefitHeaderID(benefitHeader.BenefitHeaderID);
                //var benefitHeader = _IBenefitHeaderRepository.GetByPredicate(x=>x.BenefitHeaderID == id, new System.Linq.Expressions.Expression<Func<BenefitHeader, object>>[] {x=>x.BenefitProviderSpecialties}).Single();
                if (benefitHeader == null) return NotFound($"Benefit {id} was not found");
                return Ok(benefitHeader);
                //return Ok(_mapper.Map<BenefitHeader>(benefitHeader));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]BenefitHeader model)
        {
            //model.TermDate = model.TermDate.ToTermDate();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                BenefitHeader entity = _mapper.Map<BenefitHeader>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.TermDate = model.TermDate.ToTermDate();
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                //check if benefit has Health Plan then add companyid and subcompany id for perticular benefit
                //if (model.HealthPlanID > 0) {
                //    HealthPlan plan = _IPlanRepository.GetById(model.HealthPlanID);
                //    entity.CompanyID = plan.CompanyID;
                //    entity.SubCompanyID = plan.SubCompanyID;                    
                //}             


                if (entity.BenefitProviderSpecialties.Count > 0)
                {
                    entity.BenefitProviderSpecialties.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }

                // Check duplicate benefit Code
                _IBenefitHeaderService.CheckDuplicate(model.BenefitHeaderID, model.BenefitCode, model.EffectiveDate, model.TermDate);
                if (!_IBenefitHeaderService.BusinessState.IsValid)
                {
                    _IBenefitHeaderService.BusinessState.ErrorMessages.ForEach((errorMessage) =>
                    {
                        this.ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _IBenefitHeaderRepository.Add(entity);

                if (!_IBenefitHeaderRepository.DbState.IsValid)
                {
                    _IBenefitHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("BenefitHeaderGet", new { id = entity.BenefitHeaderID });
                _logger.LogInformation("New Benefit Created");
                return Created(newUri, _mapper.Map<GetBenefitModel>(entity));                
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Benefit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5 int id, 
        [HttpPut]
        public IActionResult Put([FromBody]BenefitHeader model)
        {
            //ModelState.SetModelValue("TermDate", model.TermDate.ToTermDate());
            ModelState.Remove("TermDate");
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                BenefitHeader entity = _IBenefitHeaderRepository.GetById(model.BenefitHeaderID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.TermDate = model.TermDate.ToTermDate();
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                //check if benefit has Health Plan then add companyid and subcompany id for perticular benefit
                //if (model.HealthPlanID > 0)
                //{
                //    HealthPlan plan = _IPlanRepository.GetById(model.HealthPlanID);
                //    entity.CompanyID = plan.CompanyID;
                //    entity.SubCompanyID = plan.SubCompanyID;
                //}

                if (entity.BenefitProviderSpecialties.Count > 0)
                {
                    entity.BenefitProviderSpecialties.ToList().ForEach(x => { x.CreatedDate = base.TodaysDate; x.CreatedBy = base.UserName; });
                }


                // Check duplicate benefit Code
                _IBenefitHeaderService.CheckDuplicate(model.BenefitHeaderID, model.BenefitCode, model.EffectiveDate, model.TermDate);
                if (!_IBenefitHeaderService.BusinessState.IsValid)
                {
                    _IBenefitHeaderService.BusinessState.ErrorMessages.ForEach((errorMessage) =>
                    {

                        this.ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _IBenefitHeaderRepository.Update(entity);
                if (!_IBenefitHeaderRepository.DbState.IsValid)
                {
                    _IBenefitHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Benefit Updated : {0}", entity.BenefitHeaderID);
                return Ok(_mapper.Map<GetBenefitModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Benefit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _IBenefitHeaderService.CheckIfAssociatedWithPlan(id);
                if (!_IBenefitHeaderService.BusinessState.IsValid)
                {
                    _IBenefitHeaderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _IBenefitHeaderRepository.RemoveBenefit(id, base.TodaysDate, base.UserName, (byte)RecordStatus.Deleted, RecordStatus.Deleted.ToString(), null, null);
                if (!_IBenefitHeaderRepository.DbState.IsValid)
                {
                    _IBenefitHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing benefits : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //get benefitname list exluding current benefit ..use in visit tab 
        [HttpGet("GetBenefitNames/{benefitHeaderID}")]
        public IActionResult GetBenefitNames(int benefitHeaderID)
        {
            var benefitNames = _IBenefitHeaderRepository.GetBenefitNames(benefitHeaderID);
            return Ok(benefitNames);
        }

        //copy benefit        
        [HttpPost]
        [Route("CopyBenefit/{copayCoinsuranceID}")]
        public IActionResult CopyBenefit(int copayCoinsuranceID, [FromBody]GetBenefitModel model)
        {
            int createdBenefitHeaderID = -1;
            try
            {
                // Check duplicate benefit Code
                _IBenefitHeaderService.CheckDuplicate(model.BenefitHeaderID, model.BenefitCode, model.EffectiveDate, model.TermDate.HasValue ? model.TermDate.Value : DateTime.MaxValue);
                if (!_IBenefitHeaderService.BusinessState.IsValid)
                {
                    _IBenefitHeaderService.BusinessState.ErrorMessages.ForEach((errorMessage) =>
                    {
                        this.ModelState.AddModelError(errorMessage.Key, errorMessage.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                createdBenefitHeaderID = _IBenefitHeaderRepository.CopyBenefit(model, copayCoinsuranceID, base.UserName, base.TodaysDate);
                if (!_IBenefitHeaderRepository.DbState.IsValid)
                {
                    _IBenefitHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                var newUri = Url.Link("BenefitHeaderGet", new { id = createdBenefitHeaderID });
                _logger.LogInformation("Benefit Copied ");
                return Created(newUri, createdBenefitHeaderID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while copying Benefit : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //CheckBenefitConfigurationHasData
        [HttpGet]
        [Route("CheckBenefitConfigurationHasData/{benefitHeaderID}")]
        public IActionResult CheckBenefitConfigurationHasData(int benefitHeaderID)
        {
            var res = _IBenefitHeaderRepository.CheckBenefitConfigurationHasData(benefitHeaderID);
            return Ok(res);
        }

        // Term api/values/5
        [HttpPut]
        [Route("TerminateBenefit")]
        public IActionResult TerminateBenefit([FromBody]TerminateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                //_IBenefitHeaderService.CheckIfAssociatedWithPlan(model.Id);
                //if (!_IBenefitHeaderService.BusinessState.IsValid)
                //{
                //    _IBenefitHeaderService.BusinessState.ErrorMessages.ForEach((businessState) =>
                //    {
                //        ModelState.AddModelError(businessState.Key, businessState.Value);
                //    });
                //    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                //}

                _IBenefitHeaderRepository.RemoveBenefit(model.Id, base.TodaysDate, base.UserName, (byte)RecordStatus.Termed, RecordStatus.Termed.ToString(), model.TermDate, model.TermReason);

                if (!_IBenefitHeaderRepository.DbState.IsValid)
                {
                    _IBenefitHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while terminating Benefit: {ex}");
                return BadRequest(ex.Message);
            }
        }

    }
}
