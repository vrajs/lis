using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberNote")]
    public class MemberNoteAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<MemberNoteAPIController> _logger;
        private IMemberNotesRepository _MemberNotesRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public MemberNoteAPIController(ILogger<MemberNoteAPIController> logger, IMemberNotesRepository MemberNotesRepository, IMapper mapper)
        {
            _logger = logger;
            _MemberNotesRepository = MemberNotesRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods

        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var memberNoteRes = _MemberNotesRepository.GetAllMemberNotes();
                if (!_MemberNotesRepository.DbState.IsValid)
                {
                    _MemberNotesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberNotesViewModel>>(memberNoteRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberNotes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "MemberNotesGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var memberNote = _MemberNotesRepository.GetById(id);
                if (memberNote == null) return NotFound($"MemberNotes {id} was not Found");
                if (!_MemberNotesRepository.DbState.IsValid)
                {
                    _MemberNotesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberNotesViewModel>(memberNote));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberNotes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MemberNotesViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberNote = _mapper.Map<MemberNote>(model);
                memberNote.CreatedDate = base.TodaysDate;
                memberNote.CreatedBy = base.UserName;
                memberNote.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberNote.EffectiveDate, memberNote.TermDate);
                memberNote.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberNote.EffectiveDate, memberNote.TermDate).ToString();
                memberNote.NoteDate = base.TodaysDate;

                _MemberNotesRepository.Add(memberNote);
                if (!_MemberNotesRepository.DbState.IsValid)
                {
                    _MemberNotesRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberNotesGet", new { id = memberNote.MemberNoteID });
                _logger.LogInformation("New MemberNotes Created");
                return Created(newUri, _mapper.Map<MemberNotesViewModel>(memberNote));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving MemberNotes : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberNotes/{FamilyCode}")]
        public IActionResult GetMemberNotes(string FamilyCode)
        {
            try
            {
                List<MemberNotesViewModel> notesList = _MemberNotesRepository.GetMemberNotes(FamilyCode).ToList();
                return Ok(notesList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
