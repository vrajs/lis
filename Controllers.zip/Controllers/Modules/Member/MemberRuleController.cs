﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Modules.Member
{

    [Route("api/[controller]")]
    [ApiController]
    public class MemberRuleController : BaseAPIController
    
    {
            private IMemberRuleRepository _memberRuleRepository;
            private IMapper _mapper;
            private ILogger<MemberRuleController> _logger;
            private IConfiguration _config;
            public MemberRuleController(IMemberRuleRepository memberRuleRepository,IMapper mapper,ILogger<MemberRuleController> logger,IConfiguration iConfig)
            {
                _memberRuleRepository = memberRuleRepository;
                _mapper = mapper;
                _logger = logger;
                _config = iConfig;
            }


        [Route("GetMemberRuleById")]
        [HttpGet]
        public async Task<IActionResult> GetMemberRuleById(string sepReasonCodeId)
        {
            try
            {

                var result = await _memberRuleRepository.GetMemberRuleById(Convert.ToInt32(sepReasonCodeId));
                return Ok(_mapper.Map<List<MemberRuleViewModel>>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }

}
