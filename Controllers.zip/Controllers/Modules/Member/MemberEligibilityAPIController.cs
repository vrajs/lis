using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Member;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberEligibility")]
    public class MemberEligibilityAPIController : BaseAPIController
    {

        #region Variables
        private IMemberEligibilityService _IMemberEligibilityService;
        private ILogger<MemberEligibilityAPIController> _logger;
        private IMemberEligibilityRepository _MemberEligibilityRepository;
        private IMapper _mapper;
        private IMemberRepository _MemberRepository;
        #endregion

        #region Constructor
        public MemberEligibilityAPIController(ILogger<MemberEligibilityAPIController> logger, IMemberEligibilityRepository MemberEligibilityRepository, IMapper mapper, IMemberEligibilityService IMemberEligibilityService, IMemberRepository IMemberRepository)
        {
            _logger = logger;
            _MemberEligibilityRepository = MemberEligibilityRepository;
            _mapper = mapper;
            _IMemberEligibilityService = IMemberEligibilityService;
            _MemberRepository = IMemberRepository;
        }
        #endregion

        #region API Methods
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var memberEligibilityRes = _MemberEligibilityRepository.GetAllMemberEligibility();
                if (!_MemberEligibilityRepository.DbState.IsValid)
                {
                    _MemberEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberEligibilityViewModel>>(memberEligibilityRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberEligibility : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "MemberEligibilityGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var memberEligibility = _MemberEligibilityRepository.GetById(id);
                if (memberEligibility == null) return NoContent();
                if (!_MemberEligibilityRepository.DbState.IsValid)
                {
                    _MemberEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberEligibilityViewModel>(memberEligibility));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberEligibility : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]MemberEligibilityViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberEligibility = _mapper.Map<MemberEligibility>(model);
                memberEligibility.CreatedDate = base.TodaysDate;
                memberEligibility.CreatedBy = base.UserName;

                _IMemberEligibilityService.CheckMemberEligibility(memberEligibility);
                if (!_IMemberEligibilityService.BusinessState.IsValid)
                {
                    _IMemberEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                if ((memberEligibility.RecordStatus != (byte)RecordStatus.Pend) || (memberEligibility.RecordStatus != (byte)RecordStatus.Cancel) || (memberEligibility.RecordStatus != (byte)RecordStatus.VoidOrInvalid))
                {
                    memberEligibility.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberEligibility.EffectiveDate, memberEligibility.TermDate);
                    memberEligibility.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberEligibility.EffectiveDate, memberEligibility.TermDate).ToString();
                }
                else
                {
                    memberEligibility.RecordStatusChangeComment = Convert.ToInt32(memberEligibility.RecordStatus).ToEnum<RecordStatus>().ToString();
                }

                _MemberEligibilityRepository.Add(memberEligibility);
                if (!_MemberEligibilityRepository.DbState.IsValid)
                {
                    _MemberEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                // Logic for update member eligibility ID
                var entMember = _MemberRepository.GetById(memberEligibility.MemberID);
                var entMostResuntEle = _MemberEligibilityRepository.GetMostRecentEligibility(memberEligibility.MemberID);
                if (entMember != null && entMostResuntEle != null && entMember.MemberEligibilityID != entMostResuntEle.MemberEligibilityID)
                {
                    entMember.MemberEligibilityID = entMostResuntEle.MemberEligibilityID;
                    entMember.UpdatedBy = base.UserName;
                    entMember.UpdatedDate = base.TodaysDate;
                    _MemberRepository.Update(entMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }

                var newUri = Url.Link("MemberEligibilityGet", new { id = memberEligibility.MemberEligibilityID });
                _logger.LogInformation("New MemberEligibility Created");
                return Created(newUri, _mapper.Map<MemberEligibilityViewModel>(memberEligibility));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving MemberEligibility : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]MemberEligibilityViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldMemberEligibility = _MemberEligibilityRepository.GetById(model.MemberEligibilityID);

                if (oldMemberEligibility == null) return NotFound($"Could not find a MemberEligibility with an MemberEligibilityID of {model.MemberEligibilityID}");

                /* AddDays(1) Added temporary due to date issue IgGrid */

                _mapper.Map(model, oldMemberEligibility);
                oldMemberEligibility.UpdatedBy = base.UserName;
                oldMemberEligibility.UpdatedDate = base.TodaysDate;

                _IMemberEligibilityService.CheckMemberEligibility(oldMemberEligibility);
                if (!_IMemberEligibilityService.BusinessState.IsValid)
                {
                    _IMemberEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                oldMemberEligibility.RecordStatusChangeComment = Convert.ToInt32(oldMemberEligibility.RecordStatus).ToEnum<RecordStatus>().ToString();

                _MemberEligibilityRepository.Update(oldMemberEligibility);
                if (!_MemberEligibilityRepository.DbState.IsValid)
                {
                    _MemberEligibilityRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                // Logic for update member eligibility ID
                var entMember = _MemberRepository.GetById(oldMemberEligibility.MemberID);
                var entMostResuntEle = _MemberEligibilityRepository.GetMostRecentEligibility(oldMemberEligibility.MemberID);
                if (entMember != null && entMostResuntEle != null && entMember.MemberEligibilityID != entMostResuntEle.MemberEligibilityID)
                {
                    entMember.MemberEligibilityID = entMostResuntEle.MemberEligibilityID;
                    entMember.UpdatedBy = base.UserName;
                    entMember.UpdatedDate = base.TodaysDate;
                    _MemberRepository.Update(entMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }

                return Ok(model);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating MemberCodeRef :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}/{memberID}")]
        public IActionResult Delete(int id, int memberID)
        {
            try
            {
                int totalActiveElegibility = _MemberEligibilityRepository.GetByPredicate(e => e.MemberID == memberID && e.RecordStatus != (byte)RecordStatus.Deleted).Count();
                if (totalActiveElegibility == 1)
                {
                    return BadRequest("Eligibility information is required. Unable to delete eligibility record.");
                }

                // Logic for delete eligibility
                _MemberEligibilityRepository.DeleteById(id, base.UserName, base.TodaysDate);

                // Logic for update member eligibility ID
                var entMember = _MemberRepository.GetByPredicate(e => e.MemberID == memberID).FirstOrDefault();
                var entMostResuntEle = _MemberEligibilityRepository.GetMostRecentEligibility(entMember.MemberID);
                if (entMember != null && entMostResuntEle != null && entMember.MemberEligibilityID != entMostResuntEle.MemberEligibilityID)
                {
                    entMember.MemberEligibilityID = entMostResuntEle.MemberEligibilityID;
                    entMember.UpdatedBy = base.UserName;
                    entMember.UpdatedDate = base.TodaysDate;
                    _MemberRepository.Update(entMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }

                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting MemberEligibility : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetSelfMemberPrimaryEligibility/{MemberID}")]
        public IActionResult GetSelfMemberPrimaryEligibility(int MemberID)
        {
            try
            {
                MemberEligibilityViewModel model = _MemberEligibilityRepository.GetSelfMemberPrimaryEligibility(MemberID);
                if (model == null) return NoContent();
                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetMemberEligibilityByID/{MemberEligibilityID}")]
        public IActionResult GetMemberEligibilityByID(int MemberEligibilityID)
        {
            try
            {
                MemberEligibilityViewModel model = _MemberEligibilityRepository.GetByID(MemberEligibilityID);
                if (model == null) return NoContent();
                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetTotalEligibilityCount/{FamilyCode}")]
        public IActionResult GetTotalEligibilityCount(string FamilyCode)
        {
            try
            {
                int TotalEligibility = _MemberEligibilityRepository.GetTotalEligibilityCount(FamilyCode);
                return Ok(TotalEligibility);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetAllMemberActiveEligibility/{FamilyCode}")]
        public IActionResult GetAllMemberActiveEligibility(string FamilyCode)
        {
            try
            {
                List<MemberEligibilityViewModel> items = _MemberEligibilityRepository.GetAllMemberActiveEligibility(FamilyCode);
                return Ok(items);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetEligibilityStatusByCoverageType/{MemberID}/{CoverageTypeID}")]
        public IActionResult GetAllMemberActiveEligibility(int MemberID, int CoverageTypeID)
        {
            try
            {
                MemberEligibility item = _MemberEligibilityRepository.GetByPredicate(m => m.MemberID == MemberID && m.CoverageTypeID == CoverageTypeID && m.RecordStatus != (int)RecordStatus.Deleted).FirstOrDefault();
                if (item == null) return NoContent();
                return Ok(item);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetEligibilityCount/{MemberID}")]
        public IActionResult GetEligibilityCount(int MemberID)
        {
            int totalEligibility = _MemberEligibilityRepository.GetByPredicate(m => m.MemberID == MemberID && m.RecordStatus != (int)RecordStatus.Deleted).Count();

            return Ok(totalEligibility);
        }
        #endregion
    }
}
