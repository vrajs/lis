using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberDiscloserInfo")]
    public class MemberDiscloserInfoAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<MemberDiscloserInfoAPIController> _logger;
        private IMemberDiscloserInfoRepository _MemberDiscloserInfoRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public MemberDiscloserInfoAPIController(ILogger<MemberDiscloserInfoAPIController> logger, IMemberDiscloserInfoRepository MemberDiscloserInfoRepository, IMapper mapper)
        {
            _logger = logger;
            _MemberDiscloserInfoRepository = MemberDiscloserInfoRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var memberDiscloserInfoRes = _MemberDiscloserInfoRepository.GetAllMemberDiscloserInfo();
                if (!_MemberDiscloserInfoRepository.DbState.IsValid)
                {
                    _MemberDiscloserInfoRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberDiscloserInfoViewModel>>(memberDiscloserInfoRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberDiscloserInfo : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "MemberDiscloserInfoGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var memberDiscloserInfo = _MemberDiscloserInfoRepository.GetById(id);
                if (memberDiscloserInfo == null) return NotFound($"MemberDiscloserInfo {id} was not Found");
                if (!_MemberDiscloserInfoRepository.DbState.IsValid)
                {
                    _MemberDiscloserInfoRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberDiscloserInfoViewModel>(memberDiscloserInfo));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberDiscloserInfo : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MemberDiscloserInfoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberDiscloserInfo = _mapper.Map<MemberDiscloserInfo>(model);
                memberDiscloserInfo.CreatedDate = base.TodaysDate;
                memberDiscloserInfo.CreatedBy = base.UserName;
                memberDiscloserInfo.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberDiscloserInfo.DiscloseInfoStartTime, memberDiscloserInfo.DiscloseInfoEndTime);
                memberDiscloserInfo.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberDiscloserInfo.DiscloseInfoStartTime, memberDiscloserInfo.DiscloseInfoEndTime).ToString();


                _MemberDiscloserInfoRepository.Add(memberDiscloserInfo);
                if (!_MemberDiscloserInfoRepository.DbState.IsValid)
                {
                    _MemberDiscloserInfoRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberDiscloserInfoGet", new { id = memberDiscloserInfo.MemberDiscloserInfoID });
                _logger.LogInformation("New MemberDiscloserInfo Created");
                return Created(newUri, _mapper.Map<MemberDiscloserInfoViewModel>(memberDiscloserInfo));

            }
            catch (Exception ex)
            {

                _logger.LogError("Error while saving MemberDiscloserInfo : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]MemberDiscloserInfoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldMemberDiscloserInfo = _MemberDiscloserInfoRepository.GetById(model.MemberDiscloserInfoID);
                if (oldMemberDiscloserInfo == null) return Json(NotFound($"Could not find a MemberDiscloserInfo with an MemberDiscloserInfoID of {model.MemberDiscloserInfoID}"));

                _mapper.Map(model, oldMemberDiscloserInfo);
                oldMemberDiscloserInfo.UpdatedBy = base.UserName;
                oldMemberDiscloserInfo.UpdatedDate = base.TodaysDate;
                oldMemberDiscloserInfo.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldMemberDiscloserInfo.DiscloseInfoStartTime, oldMemberDiscloserInfo.DiscloseInfoEndTime);
                oldMemberDiscloserInfo.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldMemberDiscloserInfo.DiscloseInfoStartTime, oldMemberDiscloserInfo.DiscloseInfoEndTime).ToString();

                _MemberDiscloserInfoRepository.Update(oldMemberDiscloserInfo);
                if (!_MemberDiscloserInfoRepository.DbState.IsValid)
                {
                    _MemberDiscloserInfoRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating MemberDiscloserInfo :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberDiscloserInfoRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting MemberDiscloserInfo : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberDiscloserInfoByPHI/{FamilyCode}/{DisclosePersonalHealthID}")]
        public IActionResult GetMemberDiscloserInfoByPHI(string FamilyCode, int DisclosePersonalHealthID)
        {
            try
            {
                List<MemberDiscloserInfoViewModel> discloserInfoList = _MemberDiscloserInfoRepository.GetMemberDiscloserInfoByPHI(FamilyCode, DisclosePersonalHealthID);
                return Json(discloserInfoList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetTotalDiscloserInfoCount/{FamilyCode}")]
        public IActionResult GetTotalDiscloserInfoCount(string FamilyCode)
        {
            try
            {
                int TotalContact = _MemberDiscloserInfoRepository.GetMemberDiscloserInfoByPHI(FamilyCode, -1).ToList().Count;
                return Ok(TotalContact);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
