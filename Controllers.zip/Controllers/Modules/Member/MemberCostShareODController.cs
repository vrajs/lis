using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberCostShareODController : BaseODController
    {
        #region Variables        
        private IMemberCostShareRepository _MemberCostShareRepository;
        #endregion

        #region Ctor        
        public MemberCostShareODController(IMemberCostShareRepository MemberCostShareRepository)
        {
            _MemberCostShareRepository = MemberCostShareRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberCostShare")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberCostShare(string FamilyCode)
        {
            var MemberCostShareQuery = _MemberCostShareRepository.GetMemberCostShare(FamilyCode);
            return Ok(MemberCostShareQuery);
        }
    }
}
