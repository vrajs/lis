using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberContactODController : BaseODController
    {
        #region Variables        
        private IMemberContactRepository _IMemberContactRepository;
        #endregion

        #region Ctor        
        public MemberContactODController(IMemberContactRepository IMemberContactRepository)
        {
            _IMemberContactRepository = IMemberContactRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberContact")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberContact(int MemberId)
        {
            var MemberContactQuery = _IMemberContactRepository.GetMemberContact(MemberId);
            return Ok(MemberContactQuery);
        }
    }
}
