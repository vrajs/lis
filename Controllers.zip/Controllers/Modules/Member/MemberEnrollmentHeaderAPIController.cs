﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.Implementations;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

using System.Text;
using System.Web;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberEnrollmentHeader")]
    [ApiController]
    public class MemberEnrollmentHeaderAPIController : BaseAPIController
    {
        private readonly IMemberEnrollmentHeaderService _memberEnrollmentHeaderService;
        private readonly IMemberEnrollmentHeaderRepository _memberEnrollmentHeaderRepository;
        private IMapper _mapper;
        private ILogger<MemberEnrollmentHeaderAPIController> _logger;
        private IConfiguration _config;
        public MemberEnrollmentHeaderAPIController(IMapper mapper, ILogger<MemberEnrollmentHeaderAPIController> logger, IMemberEnrollmentHeaderService memberEnrollmentHeaderService, IMemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository, IConfiguration iConfig)
        {
            _memberEnrollmentHeaderService = memberEnrollmentHeaderService;
            _memberEnrollmentHeaderRepository = memberEnrollmentHeaderRepository;
            _mapper = mapper;
            _logger = logger;
            _config = iConfig;
        }

        [Route("GetEnrollmentHeaderByMBI")]
        [HttpPost]
        public async Task<IActionResult> GetEnrollmentHeaderByMBI([FromBody] MemberPreEnrollmentViewModel model)
        {
            try
            {
                var preEnrollmentEntity = _mapper.Map<MemberEnrollmentHeader>(model);
                var result = await _memberEnrollmentHeaderRepository.GetPreEnrollmentHeaderByMBI(preEnrollmentEntity);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Pre-Enrollment : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "EnrollmentMember")]
        public IActionResult Get(int id)
        {
            try
            {
                var result = _memberEnrollmentHeaderRepository.GetById(id);
                if (result == null) return NoContent();
                return Ok(_mapper.Map<MemberPreEnrollmentViewModel>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Save Member Enrollment Details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        //[Authorize(Policy = Authorization.Policies.AddZipCodesPolicy)]
        public async Task<IActionResult> Post([FromBody] MemberEnrollmentViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                model.CreatedDate = base.TodaysDate;
                model.CreatedBy = base.UserName;
                int memberEnrollmentHeaderID = await _memberEnrollmentHeaderRepository.InsertEnrollmentHeader(model);
                if (!_memberEnrollmentHeaderRepository.DbState.IsValid)
                {
                    _memberEnrollmentHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                model.MemberID = memberEnrollmentHeaderID;
                var newUri = Url.Link("EnrollmentMember", new { id = memberEnrollmentHeaderID });
                _logger.LogInformation("New Enrollment Member Created");
                return Created(newUri, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Enrollment Header: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Update Member Enrollment Details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateMemberEmrollmentHeader")]
        //[Authorize(Policy = Authorization.Policies.AddZipCodesPolicy)]
        public async Task<IActionResult> UpdateMemberEmrollmentHeader([FromBody] MemberEnrollmentViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                model.UpdatedDate = base.TodaysDate;
                model.UpdatedBy = base.UserName;
                int memberEnrollmentHeaderID = await _memberEnrollmentHeaderRepository.UpdateEnrollmentHeader(model);
                if (!_memberEnrollmentHeaderRepository.DbState.IsValid)
                {
                    _memberEnrollmentHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("EnrollmentMember", new { id = memberEnrollmentHeaderID });
                _logger.LogInformation("Enrollment Member Updated");
                return Created(newUri, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Enrollment Header: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        //[HttpPut]
        ////[Authorize(Policy = Authorization.Policies.AddZipCodesPolicy)]
        //public async Task<IActionResult> Put([FromForm] MemberPreEnrollmentViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    try
        //    {
        //        List<MemberEnrollmentHeaderAttachmentViewModel> attachmentList = new List<MemberEnrollmentHeaderAttachmentViewModel>();
        //        var uploadedEnrollAttachmentFiles = Request.Form.Files;

        //        //string fileStorePath = Path.Combine("", "UploadProviderFiles");
        //        string fileStorePath = "E:/Gaurav/Work/HPS/Pre-Enrollment/Documents/" + model.TrackingID;

        //        if (uploadedEnrollAttachmentFiles.Count > 0)
        //        {
        //            for (int i = 0; i < uploadedEnrollAttachmentFiles.Count; i++)
        //            {
        //                MemberEnrollmentHeaderAttachmentViewModel attachmentModel = new MemberEnrollmentHeaderAttachmentViewModel();

        //                string UploadedFile = string.Empty;
        //                var postedFile = uploadedEnrollAttachmentFiles[i];
        //                var FileName = postedFile.FileName;
        //                string FileExtension = Path.GetExtension(FileName);
        //                var FileNameWithoutExtension = Path.GetFileNameWithoutExtension(FileName);
        //                var NewFileName = FileNameWithoutExtension + "_" + Convert.ToString(DateTime.Now.Ticks) + FileExtension;

        //                if (!CommonUtil.allowedExtensions().Any(x => x == FileExtension))
        //                {
        //                    return Ok("Extension is not allowed");
        //                }

        //                if (!Directory.Exists(fileStorePath))
        //                {
        //                    Directory.CreateDirectory(fileStorePath);
        //                }

        //                UploadedFile = Path.Combine(fileStorePath, NewFileName);

        //                attachmentModel.FileName = NewFileName;
        //                attachmentModel.FileLocation = fileStorePath;
        //                attachmentModel.MemberPreEnrollmentID = model.MemberEnrollmentHeaderID;
        //                attachmentModel.EffectiveDate = base.TodaysDate;
        //                attachmentModel.CreatedDate = base.TodaysDate;
        //                attachmentModel.TermDate = DateTime.MaxValue.Date;
        //                attachmentModel.CreatedBy = base.UserName;
        //                attachmentModel.RecordStatus = (int)RecordStatus.Active;
        //                attachmentModel.RecordStatusChangeComment = RecordStatus.Active.ToString();

        //                attachmentList.Add(attachmentModel);

        //                using (FileStream stream = new FileStream(UploadedFile, FileMode.Create))
        //                {
        //                    postedFile.CopyTo(stream);
        //                }
        //            }
        //        }

        //        var preEnrollmentAttachmentEntity = _mapper.Map<List<MemberEnrollmentHeaderAttachment>>(attachmentList);

        //        MemberEnrollmentHeader preEnrollmentEntity = _memberEnrollmentHeaderRepository.GetById(model.MemberEnrollmentHeaderID);
        //        _mapper.Map(model, preEnrollmentEntity);
        //        preEnrollmentEntity.IsCompareWithCMS = true;
        //        preEnrollmentEntity.CreatedDate = base.TodaysDate;
        //        preEnrollmentEntity.CreatedBy = base.UserName;
        //        preEnrollmentEntity.RecordStatus = (int)RecordStatus.Active;
        //        preEnrollmentEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

        //        //remove below static line at last;
        //        preEnrollmentEntity.TrackingID = "GK00000000001";
        //        preEnrollmentEntity.MemberID = "GK00000000001";

        //        if (preEnrollmentEntity != null && preEnrollmentAttachmentEntity != null)
        //        {
        //            preEnrollmentEntity.MemberEnrollmentHeaderAttachment = preEnrollmentAttachmentEntity;
        //        }

        //        //await _memberEnrollmentHeaderRepository.AddAsync(preEnrollmentEntity);
        //        await _memberEnrollmentHeaderRepository.UpdateAsync(preEnrollmentEntity);

        //        if (!_memberEnrollmentHeaderRepository.DbState.IsValid)
        //        {
        //            _memberEnrollmentHeaderRepository.DbState.ErrorMessages.ForEach((error) =>
        //            {
        //                this.ModelState.AddModelError(error.Key, error.Value);
        //            });
        //            return BadRequest(this.ModelState);
        //        }

        //        _logger.LogInformation("Pre-Enrollment Updated: {0}", preEnrollmentEntity.MemberEnrollmentHeaderID);

        //        return Ok(preEnrollmentEntity.MemberEnrollmentHeaderID);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError("Error while saving Pre-Enrollment : {0}", ex);
        //        return BadRequest(ex.Message);
        //    }
        //}

        /// <summary>
        /// Get member enrollment List
        /// </summary>
        /// <param name="searchModelString"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetMemberEnrollmentHeader")]
        public async Task<IActionResult> GetMemberEnrollmentHeader(string searchModelString)
        {
            MemberEnrollmentSearchModel searchModel = JsonConvert.DeserializeObject<MemberEnrollmentSearchModel>(searchModelString);
            var MemberEnrollmentList = await _memberEnrollmentHeaderRepository.GetMemberEnrollmentHeader(searchModel);
            return Ok(MemberEnrollmentList);
        }
        /// <summary>
        /// Get member Audit History 
        /// </summary>
        /// <param memberId="memberId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetMemberAuditHistory")]
        public async Task<IActionResult> GetMemberAuditHistory(int memberId)
        {
            var memberAuditHistoryList = await _memberEnrollmentHeaderRepository.GetMemberAuditHistory(memberId);
            return Ok(memberAuditHistoryList);
        }
        /// <summary>
        /// Get Audit History 
        /// </summary>
        /// <param AuditHistoryFilterModel="auditHistoryFilterModel"></param>
        /// <returns>lst of AuditHistorys</returns>
        [HttpPost]
        [Route("GetAuditHistory")]
        public async Task<IActionResult> GetAuditHistory(AuditHistoryFilterModel auditHistoryFilterModel)
        {
            var auditHistoryList = await _memberEnrollmentHeaderRepository.GetAuditHistory(auditHistoryFilterModel);
            return Ok(auditHistoryList);
        }

        /// <summary>
        /// Get member enrollment data by member Id
        /// </summary>
        /// <param name="MemberEnrollmentHeaderID"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetMemberEnrollmentHeaderById")]
        public async Task<IActionResult> GetMemberEnrollmentHeaderById(int MemberEnrollmentHeaderID)
        {
            var MemberEnrollmentData = await _memberEnrollmentHeaderRepository.GetMemberEnrollmentHeaderById(MemberEnrollmentHeaderID);
            return Ok(MemberEnrollmentData);
        }
        /// <summary>
        /// Get ApplicationStatusId by member Id
        /// </summary>
        /// <param name="MemberEnrollmentHeaderID"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetApplicationStatusId")]
        public async Task<IActionResult> GetApplicationStatusId(int MemberEnrollmentHeaderID)
        {
            var MemberEnrollmentData = await _memberEnrollmentHeaderRepository.GetMemberEnrollmentHeaderById(MemberEnrollmentHeaderID);
            return Ok(MemberEnrollmentData.ApplicationStatusID);
        }

        [HttpGet]
        [Route("GetSepReasonCodeById")]
        public async Task<IActionResult> GetSepReasonCodeById(string ElectionTypeCodeId)
        {
            try
            {

                var result = await _memberEnrollmentHeaderRepository.GetSepReasonCodeById(Convert.ToInt32(ElectionTypeCodeId));
                return Ok(_mapper.Map<List<SEPReasonCodeViewModel>>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}