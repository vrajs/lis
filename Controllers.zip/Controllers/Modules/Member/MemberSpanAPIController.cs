﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Implementation.Member;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Kwicle.Data.Repositories.Member;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberSpan")]
    [ApiController]
    public class MemberSpanAPIController : BaseAPIController
    {
        private readonly IMemberSpanRepository _memberSpanRepository;
        private readonly IMemberSpanService _memberSpanService;
        private IMapper _mapper;
        private ILogger<MemberSpanAPIController> _logger;
        public MemberSpanAPIController(IMapper mapper,
            ILogger<MemberSpanAPIController> logger,
            IMemberSpanRepository memberSpanRepository,
            IMemberSpanService memberSpanService)
        {
            _mapper = mapper;
            _logger = logger;
            _memberSpanRepository = memberSpanRepository;
            _memberSpanService = memberSpanService;
        }

        /// <summary>
        /// Get Member Span by MemberSpanID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            try
            {
                var result = _memberSpanRepository.GetById(Id);
                if (result == null) return NoContent();
                return Ok(_mapper.Map<MemberSpanViewModel>(result));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Member Span : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Get Member Span By Member ID
        /// </summary>
        /// <param name="MemberID"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetMemberSpanByMemberId/{MemberID}")]
        public async Task<IActionResult> GetMemberSpanByMemberId(int MemberID)
        {
            try
            {
                List<MemberSpanListViewModel> result = await _memberSpanService.GetMemberSpanByMemberId(MemberID);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Member Span : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Save Member Span
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] MemberSpanViewModel model)
        {
            try
            {
                MemberSpan memberSpans = _mapper.Map<MemberSpanViewModel, MemberSpan>(model);
                memberSpans.CreatedBy = base.UserName;
                memberSpans.CreatedDate = base.TodaysDate;
                memberSpans = await _memberSpanService.SaveMemberSpan(memberSpans);

                return Ok(memberSpans);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving member span : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Member Span
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] MemberSpanViewModel model)
        {
            try
            {
                MemberSpan entity = _memberSpanRepository.GetById(model.MemberSpanID);
                if(entity == null) return NoContent();
                _mapper.Map(model, entity);
                //entity = _mapper.Map<MemberSpanViewModel, MemberSpan>(model);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                //await _memberSpanRepository.UpdateAsync(entity);
                entity = await _memberSpanService.UpdateMemberSpan(entity);

                return Ok(entity.MemberSpanID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating member span : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
