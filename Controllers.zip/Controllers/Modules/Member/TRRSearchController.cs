﻿using AutoMapper;
using Kwicle.Business.Interfaces.ETLStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/[controller]")]
    [ApiController]

    public class TRRSearchController : ControllerBase
    {
        private readonly ITRRFalloutsRepository _TRRFalloutsRespository;
        private readonly ITRRFalloutsService _tRRFalloutsService;
        private IMapper _mapper;
        private ILogger<MemberTransactionAPIController> _logger;
        private IConfiguration _config;
        public TRRSearchController(IMapper mapper,
            ILogger<MemberTransactionAPIController> logger,
            ITRRFalloutsRepository TRRFalloutsRespository,
            ITRRFalloutsService tRRFalloutsService,
            IConfiguration iConfig)
        {
            _TRRFalloutsRespository = TRRFalloutsRespository;
            _tRRFalloutsService = tRRFalloutsService;
            _mapper = mapper;
            _logger = logger;
            _config = iConfig;
        }

        /// <summary>
        /// Get TRR Search
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetTRRSearch")]
        public async Task<IActionResult> GetTRRSearch(MemberTRRSearchModel searchModel)
        {
            try
            {
                var TRRFalloutsList = await _tRRFalloutsService.GetTRRFalloutsAsync(searchModel);
                if (TRRFalloutsList == null) return NoContent();
                return Ok(TRRFalloutsList);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

        /// <summary>
        /// Update TRR Update
        /// </summary>
        /// <param name="updateModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateTRRFalloutStatus")]
        public async Task<IActionResult> UpdateTRRFalloutStatus(MemberTRRUpdateModel updateModel)
        {
            try
            {
                var result = await _tRRFalloutsService.UpdateFalloutStatusAsync(updateModel);
                return Ok(result);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

    }
}
