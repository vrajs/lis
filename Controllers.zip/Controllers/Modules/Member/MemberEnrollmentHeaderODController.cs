﻿using AutoMapper;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Newtonsoft.Json;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]    
    public class MemberEnrollmentHeaderODController : BaseODController
    {
        
        private readonly IMemberEnrollmentHeaderRepository _memberEnrollmentHeaderRepository;
        private IMapper _mapper;
        private ILogger<MemberEnrollmentHeaderODController> _logger;

        public MemberEnrollmentHeaderODController(IMapper mapper, ILogger<MemberEnrollmentHeaderODController> logger, IMemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository)
        {           
            _memberEnrollmentHeaderRepository = memberEnrollmentHeaderRepository;
            _mapper = mapper;
            _logger = logger;
        }

        //[HttpGet]
        //[ConvertUrlToOdataV4]
        //[Route("GetMemberEnrollmentHeader")]
        //[EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //public async Task<IActionResult> GetMemberEnrollmentHeader(string searchModelString)
        //{
        //    MemberEnrollmentSearchModel searchModel = JsonConvert.DeserializeObject<MemberEnrollmentSearchModel>(searchModelString);
        //    var Queryable = await _memberEnrollmentHeaderRepository.GetMemberEnrollmentHeader(searchModel);
        //    return Ok(Queryable);
        //}
    }
}
