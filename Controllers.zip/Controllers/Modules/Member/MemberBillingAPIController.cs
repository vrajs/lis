using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Business.Interfaces.Common;
using System.Net;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberBilling")]
    public class MemberBillingAPIController : BaseAPIController
    {

        #region Variables
        private ILogger<MemberBillingAPIController> _logger;
        private IMemberBillingRepository _MemberBillingRepository;
        private IMapper _mapper;
        private IMemberBillingService _IMemberBillingService;
        #endregion

        #region Ctor
        public MemberBillingAPIController(ILogger<MemberBillingAPIController> logger, IMemberBillingRepository MemberBillingRepository, IMapper mapper, IMemberBillingService IMemberBillingService)
        {
            _logger = logger;
            _MemberBillingRepository = MemberBillingRepository;
            _mapper = mapper;
            _IMemberBillingService = IMemberBillingService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var memberBillingRes = _MemberBillingRepository.GetAllMemberBilling();
                if (!_MemberBillingRepository.DbState.IsValid)
                {
                    _MemberBillingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberBillingViewModel>>(memberBillingRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberBilling : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "MemberBillingGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var memberBilling = _MemberBillingRepository.GetById(id);
                if (memberBilling == null) return NotFound($"MemberBilling {id} was not Found");
                if (!_MemberBillingRepository.DbState.IsValid)
                {
                    _MemberBillingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberBillingViewModel>(memberBilling));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberBilling : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MemberBillingViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberBilling = _mapper.Map<MemberBilling>(model);
                memberBilling.CreatedDate = base.TodaysDate;
                memberBilling.CreatedBy = base.UserName;

                _IMemberBillingService.CheckMemberBilling(model);
                if (!_IMemberBillingService.BusinessState.IsValid)
                {
                    _IMemberBillingService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    //return BadRequest(ModelState);
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }
                memberBilling.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberBilling.EffectiveDate, memberBilling.TermDate);
                memberBilling.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberBilling.EffectiveDate, memberBilling.TermDate).ToString();

                _MemberBillingRepository.Add(memberBilling);
                if (!_MemberBillingRepository.DbState.IsValid)
                {
                    _MemberBillingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberBillingGet", new { id = memberBilling.MemberBillingID });
                _logger.LogInformation("New MemberBilling Created");
                return Created(newUri, memberBilling.MemberBillingID);
            }
            catch (Exception ex)
            {

                _logger.LogError("Error while saving MemberBilling : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]MemberBillingViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldMemberBilling = _MemberBillingRepository.GetById(model.MemberBillingID);

                if (oldMemberBilling == null) return NotFound($"Could not find a MemberBilling with an MemberBillingID of {model.MemberBillingID}");

                _mapper.Map(model, oldMemberBilling);
                oldMemberBilling.UpdatedBy = base.UserName;
                oldMemberBilling.UpdatedDate = base.TodaysDate;

                _IMemberBillingService.CheckMemberBilling(model);
                if (!_IMemberBillingService.BusinessState.IsValid)
                {
                    _IMemberBillingService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                oldMemberBilling.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldMemberBilling.EffectiveDate, oldMemberBilling.TermDate);
                oldMemberBilling.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldMemberBilling.EffectiveDate, oldMemberBilling.TermDate).ToString();

                _MemberBillingRepository.Update(oldMemberBilling);
                if (!_MemberBillingRepository.DbState.IsValid)
                {
                    _MemberBillingRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.MemberBillingID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating MemberBilling :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberBillingRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting MemberBilling : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberBilling/{FamilyCode}")]
        public IActionResult GetMemberBilling(string FamilyCode)
        {
            try
            {
                List<MemberBillingViewModel> mbillingList = _MemberBillingRepository.GetMemberBilling(FamilyCode).ToList();
                return Ok(mbillingList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
