using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Member;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Common;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberCOB")]
    public class MemberCOBAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<MemberCOBAPIController> _logger;
        private readonly IMemberCOBRepository _MemberCOBRepository;
        #endregion

        #region Constructor
        public MemberCOBAPIController(IMapper mapper, ILogger<MemberCOBAPIController> logger, IMemberCOBRepository memberCOBRepository)
        {
            this._mapper = mapper;
            this._logger = logger;
            this._MemberCOBRepository = memberCOBRepository;
        }
        #endregion

        #region Api Methods
        [HttpGet("{id}", Name = "MemberCOBGet")]
        public IActionResult Get(int id)
        {
            try
            {
                MemberCOB eMemberCOB = _MemberCOBRepository.GetById(id);
                if (eMemberCOB == null) return NoContent();
                return Ok(_mapper.Map<MemberCOBViewModel>(eMemberCOB));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  MemberCOBViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<MemberCOB>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _MemberCOBRepository.Add(entity);
                if (!_MemberCOBRepository.DbState.IsValid)
                {
                    _MemberCOBRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberCOBGet", new { id = entity.MemberCOBID });
                _logger.LogInformation("New Member COB Created");
                return Created(newUri, _mapper.Map<MemberCOBViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving member COB : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]  MemberCOBViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var oldCOB = _MemberCOBRepository.GetById(model.MemberCOBID);
                if (oldCOB == null) return NoContent();

                _mapper.Map(model, oldCOB);
                oldCOB.UpdatedBy = base.UserName;
                oldCOB.UpdatedDate = base.TodaysDate;
                oldCOB.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldCOB.EffectiveDate, oldCOB.TermDate);
                oldCOB.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldCOB.EffectiveDate, oldCOB.TermDate).ToString();

                _MemberCOBRepository.Update(oldCOB);
                if (!_MemberCOBRepository.DbState.IsValid)
                {
                    _MemberCOBRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberCOBViewModel>(oldCOB));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating member COB: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberCOBRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting member COB : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberCOB/{FamilyCode}")]
        public IActionResult GetMemberCOB(string FamilyCode)
        {
            try
            {
                List<MemberCOBViewModel> mCOBList = _MemberCOBRepository.GetMemberCOB(FamilyCode);
                if (mCOBList == null) return NoContent();
                return Ok(mCOBList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
