﻿using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Mvc;
namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberEnrollmentMarx")]
    [ApiController]
    public class MemberEnrollmentMarxAPIController : BaseAPIController
    {

        private readonly IMemberEnrollmentMarxRepository _memberEnrollmentMarxRepository;
        private ILogger<MemberEnrollmentMarxAPIController> _logger;
        private IConfiguration _config;
        private readonly ICmsAzureDataFactoryService _MemberBEQService;

        public MemberEnrollmentMarxAPIController(//IMapper mapper,            
            ILogger<MemberEnrollmentMarxAPIController> logger,
            IMemberEnrollmentMarxRepository memberEnrollmentMarxRepository,
            ICmsAzureDataFactoryService MemberBEQService,
            IConfiguration iConfig)
        {

            _memberEnrollmentMarxRepository = memberEnrollmentMarxRepository;
            _MemberBEQService = MemberBEQService;
            //_mapper = mapper;
            _logger = logger;
            _config = iConfig;

        }

        [HttpPost]
        [Route("GenerateMarxFiles")]
        public async Task<IActionResult> GenerateMarxFiles(MemberGenerateBeqFiles MarxFilesModel)
        {
            try
            {
                string strRunId = await _MemberBEQService.TriggerAzureDataFactoryAsync(MarxFilesModel);
                return Ok(strRunId);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet]
        [Route("CheckMarxStatus")]
        public async Task<IActionResult> CheckMarxStatus(string strRunId, string PipelineName)
        {
            try
            {
                string strFileStatus = await _MemberBEQService.GetPipelineStatusAsync(strRunId);
                return Ok(strFileStatus);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetPipelineName")]
        public async Task<IActionResult> GetPipelineName(int tranTypeId)
        {
            try
            {
                var strPipeLine = await _memberEnrollmentMarxRepository.GetPipelineName(tranTypeId);
                return Ok(strPipeLine);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]

        [Route("GetMemberEnrollmentMarxFiles")]
        public async Task<IActionResult> GetMemberEnrollmentMarxFiles([FromBody] MemberEnrollmentSearchModel mdlSearch)
        {
            try
            {
                var MarxFileGenerationList = await _memberEnrollmentMarxRepository.GetMemberEnrollmentMarxFiles(mdlSearch);
                return Ok(MarxFileGenerationList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
