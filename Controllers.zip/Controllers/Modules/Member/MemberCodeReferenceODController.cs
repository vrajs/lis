using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberCodeReferenceODController : BaseODController
    {
        #region Variables        
        private IMemberCodeReferenceRepository _MemberCodeReferenceRepository;
        #endregion

        #region Ctor        
        public MemberCodeReferenceODController(IMemberCodeReferenceRepository MemberCodeReferenceRepository)
        {
            _MemberCodeReferenceRepository = MemberCodeReferenceRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberCodeReference")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberCodeReference(string FamilyCode)
        {
            var MemberCodeQuery = _MemberCodeReferenceRepository.GetMemberCodeRef(FamilyCode);
            return Ok(MemberCodeQuery);
        }
    }
}
