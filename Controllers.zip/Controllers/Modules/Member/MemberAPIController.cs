using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Member;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.View;
using Kwicle.Business.Interfaces.Member;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/Member")]
    public class MemberAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<MemberAPIController> _logger;
        private readonly IMemberRepository _MemberRepository;
        private readonly IViewRepository _ViewRepository;
        private IMemberEligibilityService _IMemberEligibilityService;
        private IMemberEligibilityRepository _MemberEligibilityRepository;
        #endregion

        #region Constructor
        public MemberAPIController(IMapper mapper, ILogger<MemberAPIController> logger, IMemberEligibilityRepository MemberEligibilityRepository, IMemberEligibilityService IMemberEligibilityService, IMemberRepository memberRepository, IViewRepository viewRepository)
        {
            this._mapper = mapper;
            this._logger = logger;
            this._MemberRepository = memberRepository;
            this._ViewRepository = viewRepository;
            this._IMemberEligibilityService = IMemberEligibilityService;
            this._MemberEligibilityRepository = MemberEligibilityRepository;
        }
        #endregion

        #region Api Methods
        [HttpGet("{id}", Name = "MemberGet")]
        public IActionResult Get(int id)
        {
            try
            {
                Kwicle.Core.Entities.MemberStructure.Member eMember = _MemberRepository.GetById(id);
                if (eMember == null) return NoContent();
                return Ok(_mapper.Map<MemberViewModel>(eMember));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  MemberViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                // Logic of Member Entity
                var memberEntity = _mapper.Map<Kwicle.Core.Entities.MemberStructure.Member>(model);
                memberEntity.CreatedDate = base.TodaysDate;
                memberEntity.CreatedBy = base.UserName;
                memberEntity.RecordStatus = (int)RecordStatus.Active;
                memberEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                // Logic of Member Eligibility Entity
                model.MemberEligibilityInfo.MemberID = model.MemberID;
                model.MemberEligibilityInfo.MemberCode = model.MemberCode;
                var memberEligibility = _mapper.Map<MemberEligibility>(model.MemberEligibilityInfo);
                memberEligibility.CreatedDate = base.TodaysDate;
                memberEligibility.CreatedBy = base.UserName;
                memberEligibility.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberEligibility.EffectiveDate, memberEligibility.TermDate);
                memberEligibility.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberEligibility.EffectiveDate, memberEligibility.TermDate).ToString();

                // Logic of check business rule
                _IMemberEligibilityService.CheckMemberEligibility(memberEligibility);
                if (!_IMemberEligibilityService.BusinessState.IsValid)
                {
                    _IMemberEligibilityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                // Logic of insert new member
                model.MemberCode = _MemberRepository.Insert(memberEntity, memberEligibility);
                if (!_MemberRepository.DbState.IsValid)
                {
                    _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                model = _MemberRepository.GetMemberForView(model.MemberCode);

                var newUri = Url.Link("MemberGet", new { id = memberEntity.MemberID });
                _logger.LogInformation("New Member Created");
                return Created(newUri, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Member : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]  MemberViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var oldMember = _MemberRepository.GetById(model.MemberID);
                if (oldMember == null) return NoContent();
                model.MemberEligibilityID = oldMember.MemberEligibilityID;
                model.MemberContactID = oldMember.MemberContactID;
                _mapper.Map(model, oldMember);
                oldMember.UpdatedBy = base.UserName;
                oldMember.UpdatedDate = base.TodaysDate;

                _MemberRepository.Update(oldMember);
                if (!_MemberRepository.DbState.IsValid)
                {
                    _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                model = _MemberRepository.GetMemberForView(model.MemberCode);

                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Member: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberForView/{MemberCode}")]
        public IActionResult GetMemberForView(string MemberCode)
        {
            try
            {
                MemberViewModel model = _MemberRepository.GetMemberForView(MemberCode);
                if (model == null) return NoContent();
                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberByCode/{MemberCode}")]
        public IActionResult GetMemberByCode(string MemberCode)
        {
            try
            {
                MemberViewModel model = _MemberRepository.GetMember(MemberCode);
                if (model == null) return NoContent();
                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetDependentMembers/{FamilyCode}")]
        public IActionResult GetDependentMembers(string FamilyCode)
        {
            try
            {
                List<MemberViewModel> depedents = _MemberRepository.GetDependentMember(FamilyCode);
                return Json(depedents);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetClaimMember")]
        public IActionResult GetClaimMemberByCode(string SearchText, DateTime ClaimDOSFrom, DateTime ClaimDOSTo)
        {
            try
            {
                List<MemberLookupViewModel> members = _ViewRepository.MemberLookups.Where(e =>
                                                (ClaimDOSFrom >= e.EffectiveDate && ClaimDOSTo <= e.TermDate && (e.MemberCode.ToLower() == SearchText.ToLower() || e.MemberName.ToLower() == SearchText.ToLower()))
                                                ||
                                                ((e.MemberCode.ToLower() == SearchText.ToLower() || e.MemberName.ToLower() == SearchText.ToLower()) && e.MemberEligibilityID == null)).ToList();
                return Ok(members);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting Member: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
