﻿using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Member;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/OECLayout")]
    public class OECLayoutAPIController : BaseAPIController
    {
        private ILogger<OECLayoutAPIController> _logger;
        private readonly IOECLayoutService _OECLayoutService;
        private IMapper _mapper;
        private IConfiguration _config;

        public OECLayoutAPIController(ILogger<OECLayoutAPIController> logger, IMapper mapper, IOECLayoutService OECLayoutService, IConfiguration iConfig)
        {
            _logger = logger;
            _mapper = mapper;
            _OECLayoutService = OECLayoutService;
            _config = iConfig;
        }

        [HttpGet]
        [Route("GetAllOECLayoutById")]
        public ActionResult GetAllOECLayoutByDataFileToProcessDetailsID(int DataFileToProcessDetailsID)
        {
            try
            {
                var result = _OECLayoutService.GetAllOECLayoutByDataFileToProcessDetailsID(DataFileToProcessDetailsID);
                if (result == null) return NotFound($"OECLayout was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
    }
}
