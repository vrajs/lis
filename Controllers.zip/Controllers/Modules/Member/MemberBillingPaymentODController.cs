using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberBillingPaymentODController : BaseODController
    {
        #region Property        
        private IMemberBillingPaymentRepository _IMemberBillingPaymentRepository;
        #endregion

        #region Constructor        
        public MemberBillingPaymentODController(IMemberBillingPaymentRepository memberBillingPaymentRepository)
        {
            _IMemberBillingPaymentRepository = memberBillingPaymentRepository;
        }
        #endregion

        #region Odata Methods
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberBillingPayments")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberBillingPayments(string FamilyCode, int AccountTypeID)
        {
            var query = _IMemberBillingPaymentRepository.GetMemberBillingPayment(FamilyCode, AccountTypeID);
            return Ok(query);
        }
        #endregion
    }
}
