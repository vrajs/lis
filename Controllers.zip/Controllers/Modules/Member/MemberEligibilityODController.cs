using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberEligibilityODController : BaseODController
    {
        #region Variables        
        private IMemberEligibilityRepository _IMemberEligibilityRepository;
        #endregion

        #region Ctor        
        public MemberEligibilityODController(IMemberEligibilityRepository IMemberEligibilityRepository)
        {
            _IMemberEligibilityRepository = IMemberEligibilityRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberEligibility")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberEligibility(string FamilyCode)
        {
            var MemberEligibilityQuery = _IMemberEligibilityRepository.GetMemberEligibility(FamilyCode);
            return Ok(MemberEligibilityQuery);
        }
    }
}
