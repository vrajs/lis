using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Common.Utility;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberContact")]
    public class MemberContactAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<MemberContactAPIController> _logger;
        private IMemberContactRepository _MemberContactRepository;
        private IMapper _mapper;
        private readonly IMemberContactsService _IMemberContactsService;
        private IMemberRepository _MemberRepository;
        #endregion

        #region Ctor
        public MemberContactAPIController(ILogger<MemberContactAPIController> logger, IMemberContactRepository MemberContactRepository, IMapper mapper, IMemberContactsService IMemberContactsService, IMemberRepository IMemberRepository)
        {
            _logger = logger;
            _MemberContactRepository = MemberContactRepository;
            _mapper = mapper;
            _IMemberContactsService = IMemberContactsService;
            _MemberRepository = IMemberRepository;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var memberContactRes = _MemberContactRepository.GetAllMemberContact();
                if (!_MemberContactRepository.DbState.IsValid)
                {
                    _MemberContactRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberContactViewModel>>(memberContactRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberContact : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "MemberContactGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var memberContact = _MemberContactRepository.GetById(id);
                if (memberContact == null) return NotFound($"MemberContact {id} was not Found");
                if (!_MemberContactRepository.DbState.IsValid)
                {
                    _MemberContactRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberContactViewModel>(memberContact));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberContact : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MemberContactViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberContact = _mapper.Map<MemberContact>(model);
                memberContact.CreatedDate = base.TodaysDate;
                memberContact.CreatedBy = base.UserName;

                _IMemberContactsService.CheckMemberContacts(memberContact);
                if (!_IMemberContactsService.BusinessState.IsValid)
                {
                    _IMemberContactsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                memberContact.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberContact.EffectiveDate, memberContact.TermDate);
                memberContact.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberContact.EffectiveDate, memberContact.TermDate).ToString();

                _MemberContactRepository.Add(memberContact);
                if (!_MemberContactRepository.DbState.IsValid)
                {
                    _MemberContactRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var updateMember = _MemberContactRepository.GetByPredicate(i => i.MemberID == memberContact.MemberID && i.RecordStatus == (int)RecordStatus.Active && i.ContactTypeID == (int)ContactType.Mailing).FirstOrDefault();
                if (updateMember != null)
                {
                    var oldMember = _MemberRepository.GetById(updateMember.MemberID);
                    if (oldMember == null) return NoContent();
                    oldMember.MemberContactID = updateMember.MemberContactID;
                    oldMember.UpdatedDate = base.TodaysDate;
                    oldMember.UpdatedBy = base.UserName;

                    _MemberRepository.Update(oldMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }
                else if (updateMember == null && memberContact.ContactTypeID == 6405)
                {
                    var oldMember = _MemberRepository.GetById(memberContact.MemberID);
                    if (oldMember == null) return NoContent();
                    oldMember.MemberContactID = null;
                    _MemberRepository.Update(oldMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }

                var newUri = Url.Link("MemberContactGet", new { id = memberContact.MemberContactID });
                _logger.LogInformation("New MemberContact Created");
                return Created(newUri, _mapper.Map<MemberContactViewModel>(memberContact));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving MemberContact : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]MemberContactViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldMemberContact = _MemberContactRepository.GetById(model.MemberContactID);

                if (oldMemberContact == null) return NotFound($"Could not find a MemberContact with an MemberContactID of {model.MemberContactID}");

                _mapper.Map(model, oldMemberContact);
                oldMemberContact.UpdatedBy = base.UserName;
                oldMemberContact.UpdatedDate = base.TodaysDate;

                _IMemberContactsService.CheckMemberContacts(oldMemberContact);
                if (!_IMemberContactsService.BusinessState.IsValid)
                {
                    _IMemberContactsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                oldMemberContact.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldMemberContact.EffectiveDate, oldMemberContact.TermDate);
                oldMemberContact.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldMemberContact.EffectiveDate, oldMemberContact.TermDate).ToString();

                _MemberContactRepository.Update(oldMemberContact);
                if (!_MemberContactRepository.DbState.IsValid)
                {
                    _MemberContactRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var updateMember = _MemberContactRepository.GetByPredicate(i => i.MemberID == oldMemberContact.MemberID && i.RecordStatus == (int)RecordStatus.Active && i.ContactTypeID == (int)ContactType.Mailing).FirstOrDefault();
                if (updateMember != null)
                {
                    var oldMember = _MemberRepository.GetById(updateMember.MemberID);
                    if (oldMember == null) return NoContent();
                    oldMember.MemberContactID = updateMember.MemberContactID;
                    oldMember.UpdatedDate = base.TodaysDate;
                    oldMember.UpdatedBy = base.UserName;

                    _MemberRepository.Update(oldMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }
                else if (updateMember == null && oldMemberContact.ContactTypeID == 6405)
                {
                    var oldMember = _MemberRepository.GetById(oldMemberContact.MemberID);
                    if (oldMember == null) return NoContent();
                    oldMember.MemberContactID = null;
                    _MemberRepository.Update(oldMember);
                    if (!_MemberRepository.DbState.IsValid)
                    {
                        _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });

                        return BadRequest(ModelState);
                    }
                }
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating MemberContact :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var oldMemberContact = _MemberContactRepository.GetById(id);

                if(oldMemberContact != null && oldMemberContact.RecordStatus == (int)RecordStatus.Active && oldMemberContact.ContactTypeID == (int)ContactType.Mailing)
                {
                    var oldMember = _MemberRepository.GetById(oldMemberContact.MemberID);

                    if (oldMember != null && oldMember.MemberID == oldMemberContact.MemberID && oldMember.MemberContactID == oldMemberContact.MemberContactID)
                    {
                        oldMember.MemberContactID = null;
                        oldMember.UpdatedDate = base.TodaysDate;
                        oldMember.UpdatedBy = base.UserName;

                        _MemberRepository.Update(oldMember);
                        if (!_MemberRepository.DbState.IsValid)
                        {
                            _MemberRepository.DbState.ErrorMessages.ForEach((businessState) =>
                            {
                                ModelState.AddModelError(businessState.Key, businessState.Value);
                            });

                            return BadRequest(ModelState);
                        }
                    }
                }

                _MemberContactRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting MemberContact : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberContactByType/{FamilyCode}/{ContactTypeID}")]
        public IActionResult GetMemberContactByType(string FamilyCode, int ContactTypeID)
        {
            try
            {
                List<MemberContactViewModel> contactsList = _MemberContactRepository.GetMemberContactByType(FamilyCode, ContactTypeID);
                return Json(contactsList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetTotalContactCount/{MemberID}")]
        public IActionResult GetTotalContactCount(int MemberID)
        {
            try
            {
                int TotalContact = _MemberContactRepository.GetByPredicate(e => e.MemberID == MemberID && e.RecordStatus != (int)RecordStatus.Deleted).ToList().Count;
                return Ok(TotalContact);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetActiveMailingContact/{MemberID}")]
        public IActionResult GetActiveMailingContact(int MemberID)
        {
            try
            {
                MemberContactViewModel activeMailingContact = _MemberContactRepository.GetMemberActiveMailingContact(MemberID);
                if (activeMailingContact == null) return NoContent();

                return Ok(activeMailingContact);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
