using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberCOBLetterODController : BaseODController
    {
        #region Property        
        private IMemberCOBLetterRepository _IMemberCOBLetterRepository;
        #endregion

        #region Constructor        
        public MemberCOBLetterODController(IMemberCOBLetterRepository memberCOBLetterRepository)
        {
            _IMemberCOBLetterRepository = memberCOBLetterRepository;
        }
        #endregion

        #region Odata Methods
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberCOBLetters")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult MemberCOBLetters(string FamilyCode)
        {
            var query = _IMemberCOBLetterRepository.GetMemberCOBLetter(FamilyCode);
            return Ok(query);
        }
        #endregion
    }
}
