using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Member;
using Kwicle.Data.Contracts.Masters;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Common.Utility;

using Kwicle.Core.Implementations;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Business.Interfaces.Masters;

namespace Kwicle.Service.Controllers.Modules.Member
{


    [Route("api/MemberCOBLetter")]
    public class MemberCOBLetterAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<MemberCOBLetterAPIController> _logger;
        private readonly IMemberCOBLetterRepository _MemberCOBLetterRepository;
        private ITemplateRepository _TemplateRepository;
        private IMemberRepository _MemberRepository;
        private IMemberCOBRepository _MemberCOBRepository;
        #endregion

        #region Constructor
        public MemberCOBLetterAPIController(IMapper mapper, ILogger<MemberCOBLetterAPIController> logger, IMemberCOBLetterRepository memberCOBLetterRepository,
            ITemplateRepository templateRepository, IMemberRepository memberRepository, IMemberCOBRepository memberCOBRepository
            )
        {
            this._mapper = mapper;
            this._logger = logger;
            this._MemberCOBLetterRepository = memberCOBLetterRepository;
            this._TemplateRepository = templateRepository;
            this._MemberRepository = memberRepository;
            this._MemberCOBRepository = memberCOBRepository;
        }
        #endregion

        #region Api Methods
        [HttpGet("{id}", Name = "MemberCOBLetterGet")]
        public IActionResult Get(int id)
        {
            try
            {
                MemberCOBLetter eMemberCOBLetter = _MemberCOBLetterRepository.GetById(id);
                if (eMemberCOBLetter == null) return NoContent();
                return Json(_mapper.Map<MemberCOBLetterViewModel>(eMemberCOBLetter));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]  MemberCOBLetterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<MemberCOBLetter>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (int)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                int templateTypeId = (int)TemplateType.Letter;
                int templateSubTypeId = (int)TemplateSubTypeEnum.COBLetter;

                var template = _TemplateRepository.GetTemplate(templateTypeId, templateSubTypeId, "COB Questionnaire");
                var fileFormat = template.FileFormat.ToEnum<TemplateFileFormat>();
                MemberCOB cobEntity = _MemberCOBRepository.GetById(entity.MemberCOBID);
                TemplateFileFormat templateFileFormat = template.FileFormat.ToEnum<TemplateFileFormat>();
                var placeHolderKeyVal = _TemplateRepository.GetPlaceholderDictionary(template.TemplateID, cobEntity.MemberID);
                var dictionary = placeHolderKeyVal.ToDictionary(x => x.Key, x => x.Value);
                var relativeFilePath = $"{ cobEntity.MemberID.ToString() }_{ DateTime.Now.ToString("HH_mm_ss")}.{ template.FileFormat}";
                entity.RelativeFilePath = relativeFilePath;
                using (var templateService = new TemplateService(template.RelativeFilePath, templateFileFormat, base.ZoneId))
                {
                    var fileContents = await templateService.ReadFile();
                    var renderedContents = templateService.RenderTemplate(dictionary);
                    var filePath = $"{ApplicationVariables.RootPath}{ApplicationVariables.LetterOutputBasePath}{entity.RelativeFilePath}";
                    await templateService.SaveFile(filePath);
                }

                _MemberCOBLetterRepository.Add(entity);
                if (!_MemberCOBLetterRepository.DbState.IsValid)
                {
                    _MemberCOBLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberCOBLetterGet", new { id = entity.MemberCOBID });
                _logger.LogInformation("New COB letter created");
                return Created(newUri, _mapper.Map<MemberCOBLetterViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving COB letter: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]  MemberCOBLetterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var oldCOBLetter = _MemberCOBLetterRepository.GetById(model.MemberCOBLetterID);
                if (oldCOBLetter == null) return NoContent();

                _mapper.Map(model, oldCOBLetter);
                oldCOBLetter.UpdatedBy = base.UserName;
                oldCOBLetter.UpdatedDate = base.TodaysDate;

                _MemberCOBLetterRepository.Update(oldCOBLetter);
                if (!_MemberCOBLetterRepository.DbState.IsValid)
                {
                    _MemberCOBLetterRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberCOBLetterViewModel>(oldCOBLetter));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating member COB letter: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberCOBLetterRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting member COB letter: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion


        #region Common Methods
        private string GetCOBLetterTemplateWithFilledValue(MemberCOBLetter entity)
        {
            //// Get & Set COB Letter Template
            //Template temEntity = _TemplateRepository.GetById(entity.TemplateID);
            //string HTMLTemplate = string.Empty;
            //HTMLTemplate = temEntity.HtmltemplateContent;

            //// Get COB Information
            //MemberCOB cobEntity = _MemberCOBRepository.GetById(entity.MemberCOBID);

            //// Get Member Information to generate COB letter.
            //MemberInfoForCOBLetterViewModel memInfo = _MemberRepository.GetMemberInfoForCOBLetter(cobEntity.MemberID);

            //// Replace {{Today}} 
            //HTMLTemplate = HTMLTemplate.Replace("{{Today}}", base.TodaysDate.ToString("MM/dd/yyyy"));

            //// Replace {{PolicyholdersName}}
            //HTMLTemplate = HTMLTemplate.Replace("{{PolicyholdersName}}", memInfo.DisplayName);

            //// Replace {{Today}} 
            //HTMLTemplate = HTMLTemplate.Replace("{{PolicyholdersMailingAddress}}", memInfo.MailingAddress);

            //// Replace {{Today}} 
            //HTMLTemplate = HTMLTemplate.Replace("{{Today}}", base.TodaysDate.ToString("MM/dd/yyyy"));


            //// Replace {{PolicyholdersCity}}, {{PolicyholdersState}}, {{PolicyholdersZip}}
            //HTMLTemplate = HTMLTemplate.Replace("{{PolicyholdersCity}}", memInfo.City).Replace("{{PolicyholdersState}}", memInfo.State).Replace("{{PolicyholdersZip}}", memInfo.Zip);

            //// Replace {{Today}} 
            //HTMLTemplate = HTMLTemplate.Replace("{{PlanName}}", memInfo.PlanName);

            //return HTMLTemplate;

            return string.Empty;
        }
        #endregion
    }
}
