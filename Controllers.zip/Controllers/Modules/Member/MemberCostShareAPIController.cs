using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Business.Interfaces.Common;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberCostShare")]
    public class MemberCostShareAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<MemberCostShareAPIController> _logger;
        private IMemberCostShareRepository _MemberCostShareRepository;
        private IMapper _mapper;
        private IMemberCostShareService _IMemberCostShareService;
        #endregion

        #region Ctor
        public MemberCostShareAPIController(ILogger<MemberCostShareAPIController> logger, IMemberCostShareRepository MemberCostShareRepository, IMapper mapper, IMemberCostShareService IMemberCostShareService)
        {
            _logger = logger;
            _MemberCostShareRepository = MemberCostShareRepository;
            _mapper = mapper;
            _IMemberCostShareService = IMemberCostShareService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var MemberCostShareRes = _MemberCostShareRepository.GetAllMemberCostShare();
                if (!_MemberCostShareRepository.DbState.IsValid)
                {
                    _MemberCostShareRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberCostShareViewModel>>(MemberCostShareRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberCostShare : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "MemberCostShareGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var MemberCostShare = _MemberCostShareRepository.GetById(id);
                if (MemberCostShare == null) return NotFound($"MemberCostShare {id} was not Found");
                if (!_MemberCostShareRepository.DbState.IsValid)
                {
                    _MemberCostShareRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberCostShareViewModel>(MemberCostShare));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberCostShare : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MemberCostShareViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberCostShare = _mapper.Map<MemberCostShare>(model);
                memberCostShare.CreatedDate = base.TodaysDate;
                memberCostShare.CreatedBy = base.UserName;

                _IMemberCostShareService.CheckMemberCostShares(memberCostShare);
                if (!_IMemberCostShareService.BusinessState.IsValid)
                {
                    _IMemberCostShareService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                memberCostShare.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberCostShare.EffectiveDate, memberCostShare.TermDate);
                memberCostShare.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberCostShare.EffectiveDate, memberCostShare.TermDate).ToString();

                _MemberCostShareRepository.Add(memberCostShare);
                if (!_MemberCostShareRepository.DbState.IsValid)
                {
                    _MemberCostShareRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberCostShareGet", new { id = memberCostShare.MemberCostShareID });
                _logger.LogInformation("New MemberCostShare Created");
                return Created(newUri, memberCostShare.MemberCostShareID);

            }
            catch (Exception ex)
            {

                _logger.LogError("Error while saving MemberCostShareRef : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]MemberCostShareViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldMemberCostShareRef = _MemberCostShareRepository.GetById(model.MemberCostShareID);

                if (oldMemberCostShareRef == null) return NotFound($"Could not find a MemberCostShare with an MemberContactID of {model.MemberCostShareID}");


                _mapper.Map(model, oldMemberCostShareRef);
                oldMemberCostShareRef.UpdatedBy = base.UserName;
                oldMemberCostShareRef.UpdatedDate = base.TodaysDate;

                _IMemberCostShareService.CheckMemberCostShares(oldMemberCostShareRef);
                if (!_IMemberCostShareService.BusinessState.IsValid)
                {
                    _IMemberCostShareService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                oldMemberCostShareRef.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldMemberCostShareRef.EffectiveDate, oldMemberCostShareRef.TermDate);
                oldMemberCostShareRef.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldMemberCostShareRef.EffectiveDate, oldMemberCostShareRef.TermDate).ToString();

                _MemberCostShareRepository.Update(oldMemberCostShareRef);
                if (!_MemberCostShareRepository.DbState.IsValid)
                {
                    _MemberCostShareRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.MemberCostShareID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating MemberCostShare :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberCostShareRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting MemberCostShare : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberCostShare/{FamilyCode}")]
        public IActionResult GetMemberCostShare(string FamilyCode)
        {
            try
            {
                List<MemberCostShareViewModel> costShareList = _MemberCostShareRepository.GetMemberCostShare(FamilyCode).ToList();
                return Ok(costShareList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
