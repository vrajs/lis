using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberBillingODController : BaseODController
    {
        #region Variables        
        private IMemberBillingRepository _MemberBillingRepository;
        #endregion

        #region Ctor        
        public MemberBillingODController(IMemberBillingRepository MemberBillingRepository)
        {
            _MemberBillingRepository = MemberBillingRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberBilling")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberBilling(string FamilyCode)
        {
            var MemberBillingQuery = _MemberBillingRepository.GetMemberBilling(FamilyCode);
            return Ok(MemberBillingQuery);
        }
    }
}
