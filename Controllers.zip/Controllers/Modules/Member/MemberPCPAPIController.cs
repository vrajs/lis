using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Member;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Member;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberPCP")]
    public class MemberPCPAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<MemberPCPAPIController> _logger;
        private readonly IMemberPCPRepository _MemberPCPRepository;
        private IMemberPCPService _MemberPCPService;
        #endregion

        #region Constructor
        public MemberPCPAPIController(IMapper mapper, ILogger<MemberPCPAPIController> logger, IMemberPCPRepository memberPCPRepository, IMemberPCPService memberPCPService)
        {
            this._mapper = mapper;
            this._logger = logger;
            this._MemberPCPRepository = memberPCPRepository;
            this._MemberPCPService = memberPCPService;
        }
        #endregion

        #region Api Methods
        [HttpGet("{id}", Name = "MemberPCPGet")]
        public IActionResult Get(int id)
        {
            try
            {
                MemberPCP entity = _MemberPCPRepository.GetById(id);
                if (entity == null) return NoContent();
                return Ok(_mapper.Map<MemberPCPViewModel>(entity));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  MemberPCPViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _mapper.Map<MemberPCP>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                if (_MemberPCPRepository.GetByPredicate(p => p.MemberID == model.MemberID && p.PCPID == model.PCPID && p.RecordStatus != (int)RecordStatus.Deleted).Any())
                {
                    return BadRequest("PCP already assigned. Only one active entry per PCP allowed.");

                }
                if (entity.IsPrimary)
                {
                    //Check Business logic
                    _MemberPCPService.CheckBusinessLogicWhileInsertOrUpdate(entity);
                    if (!_MemberPCPService.BusinessState.IsValid)
                    {
                        _MemberPCPService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                }

                // Insert Data
                _MemberPCPRepository.Add(entity);
                if (!_MemberPCPRepository.DbState.IsValid)
                {
                    _MemberPCPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberPCPGet", new { id = entity.MemberPCPID });
                _logger.LogInformation("New Member PCP Created");
                return Created(newUri, _mapper.Map<MemberPCPViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Member PCP : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]  MemberPCPViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = _MemberPCPRepository.GetById(model.MemberPCPID);
                if (entity == null) return NoContent();

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                // Set Record Status Based On Effective & TermDate
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                if (_MemberPCPRepository.GetByPredicate(p => p.MemberID == model.MemberID && p.MemberPCPID != model.MemberPCPID && p.PCPID == model.PCPID && p.RecordStatus != (int)RecordStatus.Deleted).Any())
                {
                    return BadRequest("PCP already assigned. Only one active entry per PCP allowed.");

                }
                if (entity.IsPrimary)
                {
                    //Check Business logic
                    _MemberPCPService.CheckBusinessLogicWhileInsertOrUpdate(entity);
                    if (!_MemberPCPService.BusinessState.IsValid)
                    {
                        _MemberPCPService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return BadRequest(ModelState);
                    }
                }

                // Update data
                _MemberPCPRepository.Update(entity);
                if (!_MemberPCPRepository.DbState.IsValid)
                {
                    _MemberPCPRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberPCPViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Member PCP: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberPCPRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting Member PCP: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMemberPCPProviderAndLocation/{FamilyCode}")]
        public IActionResult GetMemberPCPProviderAndLocation(string FamilyCode)
        {
            try
            {
                List<MemberPCPProviderAndLocationViewModel> list = _MemberPCPRepository.GetMemberPCPProviderAndLocation(FamilyCode);
                return Json(list);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetPrimaryActivePCP/{MemberID}")]
        public IActionResult GetMemberPrimaryActivePCP(int MemberID)
        {
            try
            {
                MemberPCPViewModel activePrimaryPCP = _MemberPCPRepository.GetPrimaryActivePCP(MemberID);
                if (activePrimaryPCP == null) return NoContent();
                return Ok(activePrimaryPCP);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
