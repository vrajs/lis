﻿using AutoMapper;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/TRRDetailLayout")]
    [ApiController]
    public class TRRDetailLayoutAPIController : ControllerBase
    {
        private readonly ITRRDetailLayoutRepository _TRRDetailLayoutRepository;
        private IMapper _mapper;
        private ILogger<MemberTransactionAPIController> _logger;
        private IConfiguration _config;
        public TRRDetailLayoutAPIController(IMapper mapper,
            ILogger<MemberTransactionAPIController> logger,
            ITRRDetailLayoutRepository memberTransactionRepository,
            IConfiguration iConfig)
        {
            _TRRDetailLayoutRepository = memberTransactionRepository;
            _mapper = mapper;
            _logger = logger;
            _config = iConfig;
        }

        /// <summary>
        /// Get TRR Detail Layout by Id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _TRRDetailLayoutRepository.GetById(Id);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Get All TRR Detail Layout by Member Id
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetTRRDetailLayoutByMemberId/{memberId}")]
        public async Task<IActionResult> GetTRRDetailLayoutByMemberId(int memberId)
        {
            try
            {
                var result = await _TRRDetailLayoutRepository.GetTRRDetailLayoutByMemberId(memberId);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
