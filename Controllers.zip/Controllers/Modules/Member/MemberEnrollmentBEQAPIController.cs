﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.Implementations;
using Kwicle.Data;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Polly;
using System.Text;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberEnrollmentBEQ")]
    [ApiController]
    public class MemberEnrollmentBEQAPIController : BaseAPIController
    {
        private readonly ICmsAzureDataFactoryService _memberEnrollmentBEQService;
        private readonly IMemberEnrollmentBEQRepository _memberEnrollmentBEQRepository;
        private readonly IFaasHttpClient _faasHttpClient;
        private IMapper _mapper;
        private ILogger<MemberEnrollmentBEQAPIController> _logger;
        private IConfiguration _config;
        private readonly KwicleContext _Context;

        public MemberEnrollmentBEQAPIController(IMapper mapper,
            ILogger<MemberEnrollmentBEQAPIController> logger,
            ICmsAzureDataFactoryService memberEnrollmentBEQService,
            IMemberEnrollmentBEQRepository memberEnrollmentBEQRepository,
            IConfiguration iConfig,
            IFaasHttpClient faasHttpClient, KwicleContext Context)
        {
            _memberEnrollmentBEQService = memberEnrollmentBEQService;
            _memberEnrollmentBEQRepository = memberEnrollmentBEQRepository;
            _mapper = mapper;
            _logger = logger;
            _config = iConfig;
            _faasHttpClient = faasHttpClient;
            _Context = Context;
        }

        [HttpPost]

        [Route("GetBEQResponse")]
        public async Task<IActionResult> GetBEQResponse([FromBody] MemberBEQRequestModel model)
        {
            try
            {
                await _faasHttpClient.GetCMSDataAsync(model);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPost]
        [Route("GetBEQResponseWorkArround")]
        public async Task<IActionResult> GetBEQResponseWorkArround([FromBody] MemberBEQRequestModel model)
        {
            try
            {
                MemberBEQResponseModel jsonBEQ = await _faasHttpClient.GetCMSDataAsync(model);
                //jsonBEQ.RawJson = json;
                // jsonBEQ.UserId = "1cdf9213-e0be-4228-8147-79a2f3551f53";
                MemberPreEnrollmentViewModel res = new MemberPreEnrollmentViewModel();
                res.ApplicationStatusID = 0;

                if (jsonBEQ != null)
                {
                    res.LastName = jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.lastName;
                    res.FirstName = jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.firstName;
                    res.MiddleInitial = jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.middleInitial;
                    res.PermanentAddressCity = jsonBEQ.data.beneficiaryProfile.BEQ[0].residenceAddress[0].city;
                    res.PermanentAddressState = jsonBEQ.data.beneficiaryProfile.BEQ[0].residenceAddress[0].postalStateCode;
                    res.PermanentAddressZip = jsonBEQ.data.beneficiaryProfile.BEQ[0].residenceAddress[0].zipCode;

                    if (jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.gender == "1/M")
                        res.GenderID = 10002;
                    else if (jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.gender == "2/F")
                        res.GenderID = 10003;
                    else
                        res.GenderID = 10004;

                    res.IsESRD = jsonBEQ.data.beneficiaryProfile.BEQ[0].esrdCoverage[0].esrdIndicator;

                    res.ApplicationStatusID = jsonBEQ.StatusCode;
                    if (!string.IsNullOrEmpty(jsonBEQ.data.beneficiaryProfile.BEQ[0].partB_EntitlementPeriods[0].startDate))
                    {

                        var startDt = Convert.ToDateTime(jsonBEQ.data.beneficiaryProfile.BEQ[0].partB_EntitlementPeriods[0].startDate);
                        res.MedicarePartBEffectiveDate = startDt;
                    }
                    else
                        res.MedicarePartBEffectiveDate = null;
                    if (!string.IsNullOrEmpty(jsonBEQ.data.beneficiaryProfile.BEQ[0].partA_EntitlementPeriods[0].startDate))
                    {

                        var startDt = Convert.ToDateTime(jsonBEQ.data.beneficiaryProfile.BEQ[0].partA_EntitlementPeriods[0].startDate);
                        res.MedicarePartAEffectiveDate = startDt;
                    }
                    else
                        res.MedicarePartAEffectiveDate = null;
                    res.IsEGHP = jsonBEQ.data.beneficiaryProfile.BEQ[0].currentEnrollmentPeriods[0].isEmployerGroupHealthPlan;
                    res.IsEnrolledInStateMedicaId = jsonBEQ.data.beneficiaryProfile.BEQ[0].hasMedicaid;
                    res.PermanentAddressState = jsonBEQ.data.beneficiaryProfile.BEQ[0].stateCounty[0].ssaState;
                    res.PermanentAddressCounty = jsonBEQ.data.beneficiaryProfile.BEQ[0].stateCounty[0].ssaCounty;
                }

                var CmsResp = JsonConvert.SerializeObject(res);
                return Ok(CmsResp);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPost]
        [AllowAnonymous]
        [Route("ReceiveResponse")]
        public IActionResult ReceiveResponse([FromBody] MemberBEQResponseModel model)

        {
            try
            {
                //var json1=HttpUtility.UrlEncode(model.RawJson);

                using (HttpActionService httpActionService = HttpActionService.CreateHttpActionService())
                {
                    var rawjson = model.RawJson;
                    var jsonBEQ = JsonConvert.DeserializeObject<MemberBEQResponseModel>(rawjson);
                    MemberPreEnrollmentViewModel res = new MemberPreEnrollmentViewModel();
                    res.ApplicationStatusID = 0;
                    res.LastName = jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.lastName;
                    res.FirstName = jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.firstName;
                    res.MiddleInitial = jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.middleInitial;
                    res.PermanentAddressCity = jsonBEQ.data.beneficiaryProfile.BEQ[0].residenceAddress[0].city;
                    res.PermanentAddressState = jsonBEQ.data.beneficiaryProfile.BEQ[0].residenceAddress[0].postalStateCode;
                    res.PermanentAddressZip = jsonBEQ.data.beneficiaryProfile.BEQ[0].residenceAddress[0].zipCode;

                    if (jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.gender == "1/M")
                        res.GenderID = 10002;
                    else if (jsonBEQ.data.beneficiaryProfile.BEQ[0].beneficiaryInformation.gender == "2/F")
                        res.GenderID = 10003;
                    else
                        res.GenderID = 10004;

                    res.IsESRD = jsonBEQ.data.beneficiaryProfile.BEQ[0].esrdCoverage[0].esrdIndicator;

                    res.ApplicationStatusID = jsonBEQ.StatusCode;
                    if (!string.IsNullOrEmpty(jsonBEQ.data.beneficiaryProfile.BEQ[0].partB_EntitlementPeriods[0].startDate))
                    {

                        var startDt = Convert.ToDateTime(jsonBEQ.data.beneficiaryProfile.BEQ[0].partB_EntitlementPeriods[0].startDate);
                        res.MedicarePartBEffectiveDate = startDt;
                    }
                    else
                        res.MedicarePartBEffectiveDate = null;
                    if (!string.IsNullOrEmpty(jsonBEQ.data.beneficiaryProfile.BEQ[0].partA_EntitlementPeriods[0].startDate))
                    {

                        var startDt = Convert.ToDateTime(jsonBEQ.data.beneficiaryProfile.BEQ[0].partA_EntitlementPeriods[0].startDate);
                        res.MedicarePartAEffectiveDate = startDt;
                    }
                    else
                        res.MedicarePartAEffectiveDate = null;
                    res.IsEGHP = jsonBEQ.data.beneficiaryProfile.BEQ[0].currentEnrollmentPeriods[0].isEmployerGroupHealthPlan;
                    res.IsEnrolledInStateMedicaId = jsonBEQ.data.beneficiaryProfile.BEQ[0].hasMedicaid;
                    res.PermanentAddressState = jsonBEQ.data.beneficiaryProfile.BEQ[0].stateCounty[0].ssaState;
                    res.PermanentAddressCounty = jsonBEQ.data.beneficiaryProfile.BEQ[0].stateCounty[0].ssaCounty;
                    var json = JsonConvert.SerializeObject(res);
                    string beaconUrl = _config.GetValue<string>("BeaconServerUrl");

                    var remoteNotificationServiceUrl = beaconUrl + "/api/SignalR/SendSignalROrPushNotificationJsonToUserID?UserID=" + model.UserId + "&json=" + json + "&fromUserGUID=''";
                    var webRequest1 = new HttpRequestMessage(HttpMethod.Post, remoteNotificationServiceUrl)
                    {
                        Content = new StringContent("{ 'key': 'value' }", Encoding.UTF8, "application/json")
                    };
                    HttpClient client = new HttpClient();
                    var resp = client.Send(webRequest1);

                }
                MemberPreEnrollmentViewModel result1 = new MemberPreEnrollmentViewModel();
                return Ok(_mapper.Map<MemberPreEnrollmentViewModel>(result1));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }

        }

        [HttpPost]
        [Route("InsertMemberPreEnrollment")]
        public async Task<IActionResult> InsertMemberPreEnrollment([FromForm] MemberPreEnrollmentTableViewModel model)
        {
            var uploadedEnrollAttachmentFiles = Request.Form.Files;
            string fileStorePath = _config.GetSection("ContainerName").Value;
            List<MemberPreEnrollmentAttachmentViewModel> attachmentList = new();

            var containerResult = await _faasHttpClient.CreateContainer(_config.GetSection("ContainerName").Value);

            if (uploadedEnrollAttachmentFiles.Count > 0)
            {
                for (int i = 0; i < uploadedEnrollAttachmentFiles.Count; i++)
                {
                    MemberPreEnrollmentAttachmentViewModel attachmentModel = new();

                    //BlobDataModel blobModel = new()
                    //{
                    //    ContainerName = _config.GetSection("ContainerName").Value,
                    //    FolderName = $"{model.MBI}/{model.AttachmentTypeName}",
                    //    FileUpload = uploadedEnrollAttachmentFiles[i],
                    //    MetaDataJson = string.Empty
                    //};

                    //var blobResult = await _faasHttpClient.CreateBlob(blobModel);
                    //var postedFile = uploadedEnrollAttachmentFiles[i];

                    //if (!CommonUtil.allowedExtensions().Any(x => x == Path.GetExtension(postedFile.FileName)))
                    //{
                    //    return Ok("Extension is not allowed");
                    //}

                    //attachmentModel.FileName = blobResult.Substring(blobResult.LastIndexOf("/") + 1);
                    attachmentModel.FileLocation = $"{fileStorePath}/{model.MBI}/{model.AttachmentTypeName}";
                    attachmentModel.MemberPreEnrollmentID = null;
                    attachmentModel.CreatedDate = base.TodaysDate;
                    attachmentModel.CreatedBy = base.UserName;
                    attachmentModel.RecordStatus = (int)RecordStatus.Active;
                    attachmentModel.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    attachmentList.Add(attachmentModel);

                }
            }

            var preEnrollmentAttachmentEntity = _mapper.Map<List<MemberPreEnrollmentAttachment>>(attachmentList);
            //var preEnrollmentAttachmentEntity = attachmentList;

            model.ApplicationStatusID = 1;
            model.MemberPreEnrollmentSourceID = 1;
            var memberEnrollmentModel = _mapper.Map<MemberPreEnrollment>(model);

            //remove at the end
            memberEnrollmentModel.EffectiveDate = DateTime.Now;
            memberEnrollmentModel.DOB = DateTime.Now;
            memberEnrollmentModel.MedicarePartAEffectiveDate = DateTime.Now;
            memberEnrollmentModel.MedicarePartBEffectiveDate = DateTime.Now;
            memberEnrollmentModel.ReceiptDate = DateTime.Now;

            if (memberEnrollmentModel != null && memberEnrollmentModel != null)
            {
                memberEnrollmentModel.MemberPreEnrollmentAttachment = preEnrollmentAttachmentEntity;
            }

            memberEnrollmentModel.CreatedBy = base.UserName;
            memberEnrollmentModel.CreatedDate = base.TodaysDate;
            memberEnrollmentModel.RecordStatusChangeComment = "Active";

            await _memberEnrollmentBEQRepository.AddAsync(memberEnrollmentModel);

            //  await _memberEnrollmentBEQRepository.InsertMemberPreEnrollment(memberEnrollmentModel);

            if (!_memberEnrollmentBEQRepository.DbState.IsValid)
            {
                _memberEnrollmentBEQRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }

            _logger.LogInformation("Pre-Enrollment Updated: {0}", memberEnrollmentModel.MemberPreEnrollmentID);
            return Ok();
        }

        [HttpGet]
        [Route("GetMemberPreEnrollmentByMBI")]
        public IActionResult GetMemberPreEnrollmentByMBI(string MBI)
        {
            var member = _memberEnrollmentBEQRepository.GetMemberByMBI(MBI);
            if (member != null)
                return Ok(member);
            else
                return Ok();
        }

        [HttpPost]
        [Route("InsertMemberPreEnrollmentFinal")]
        public async Task<int> InsertMemberPreEnrollmentFinal([FromBody] MemberPreEnrollmentTableViewModel model)

        {

            model.MemberID = 0;
            model.MemberPreEnrollmentSourceID = 1;
            var memberEnrollmentModel = _mapper.Map<MemberPreEnrollmentTableViewModel>(model);
            memberEnrollmentModel.CreatedDate = base.TodaysDate;
            memberEnrollmentModel.CreatedBy = base.UserName;
            var memberId = await _memberEnrollmentBEQRepository.InsertMemberPreEnrollmentFinal(memberEnrollmentModel);

            (from p in _Context.OtherDocuments
             where p.MemberID == 0
             select p).ToList().ForEach(x => x.MemberID = memberId);
            (from p in _Context.OtherNotes
             where p.MemberID == 0
             select p).ToList().ForEach(x => x.MemberID = memberId);

            _Context.SaveChanges();

            return memberId;
        }

        [HttpPost]
        [Route("GenerateBeqFiles")]
        public async Task<IActionResult> GenerateBeqFiles(MemberGenerateBeqFiles model)
        {
            try
            {
                string strRunId = await _memberEnrollmentBEQService.TriggerAzureDataFactoryAsync(model);
                return Ok(strRunId);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("GetMemberEnrollmentBEQFiles")]
        public async Task<IActionResult> GetMemberEnrollmentBEQFiles([FromBody] MemberEnrollmentSearchModel model)
        {
            try
            {
                var memberListWithBEQReadyStatus = await _memberEnrollmentBEQRepository.GetMemberEnrollmentBEQFiles(model);
                return Ok(memberListWithBEQReadyStatus);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("CheckStatus")]
        public async Task<string> CheckStatus(string strRunId)
        {
            try
            {
                string strFileStatus = await _memberEnrollmentBEQService.GetPipelineStatusAsync(strRunId);
                return strFileStatus;

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [HttpGet]
        [Route("GetBEQRequestByDetailLayoutID/{BEQRequestDetailLayoutID}")]
        public async Task<IActionResult> GetBEQRequestByDetailLayoutID(int BEQRequestDetailLayoutID)
        {
            try
            {
                var result = await _memberEnrollmentBEQRepository.GetBEQRequestByDetailLayoutID(BEQRequestDetailLayoutID);

                if (result == null) return NoContent();

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetMemberBEQByMemberId/{memberId}")]
        public async Task<IActionResult> GetMemberBEQByMemberId(int memberId)
        {
            try
            {
                var result = await _memberEnrollmentBEQRepository.GetMemberBEQByMemberId(memberId);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetMemberPreEnrollmentByMemberID/{memberID}")]
        public async Task<IActionResult> GetMemberPreEnrollmentByMemberID(int memberID)
        {
            try
            {
                var result = await _memberEnrollmentBEQRepository.GetMemberPreEnrollmentByMemberID(memberID);
                if (result == null) return NoContent();
                return Ok(_mapper.Map<MemberPreEnrollmentTableViewModel>(result));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Member Pre Enrollment : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}








