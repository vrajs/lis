using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Business.Interfaces.Common;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberCodeReference")]
    public class MemberCodeReferenceAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<MemberCodeReferenceAPIController> _logger;
        private IMemberCodeReferenceRepository _MemberCodeReferenceRepository;
        private IMapper _mapper;
        private IMemberReferenceService _IMemberReferenceService;
        #endregion

        #region Ctor
        public MemberCodeReferenceAPIController(ILogger<MemberCodeReferenceAPIController> logger, IMemberCodeReferenceRepository MemberCodeReferenceRepository, IMapper mapper, IMemberReferenceService IMemberReferenceService)
        {
            _logger = logger;
            _MemberCodeReferenceRepository = MemberCodeReferenceRepository;
            _mapper = mapper;
            _IMemberReferenceService = IMemberReferenceService;
        }
        #endregion

        #region API Methods
        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var memberCodeRes = _MemberCodeReferenceRepository.GetAllMemberCodeRef();
                if (!_MemberCodeReferenceRepository.DbState.IsValid)
                {
                    _MemberCodeReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(_mapper.Map<IEnumerable<MemberCodeReferenceViewModel>>(memberCodeRes));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberCodeRef : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "MemberCodeReferenceGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var memberCodeRef = _MemberCodeReferenceRepository.GetById(id);
                if (memberCodeRef == null) return NotFound($"MemberCodeRef {id} was not Found");
                if (!_MemberCodeReferenceRepository.DbState.IsValid)
                {
                    _MemberCodeReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberCodeReferenceViewModel>(memberCodeRef));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting MemberCodeRef : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MemberCodeReferenceViewModel model)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var memberCodeRef = _mapper.Map<MemberCode>(model);
                memberCodeRef.CreatedDate = base.TodaysDate;
                memberCodeRef.CreatedBy = base.UserName;

                _IMemberReferenceService.CheckMemberReference(memberCodeRef);
                if (!_IMemberReferenceService.BusinessState.IsValid)
                {
                    _IMemberReferenceService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                memberCodeRef.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, memberCodeRef.EffectiveDate, memberCodeRef.TermDate);
                memberCodeRef.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, memberCodeRef.EffectiveDate, memberCodeRef.TermDate).ToString();

                _MemberCodeReferenceRepository.Add(memberCodeRef);
                if (!_MemberCodeReferenceRepository.DbState.IsValid)
                {
                    _MemberCodeReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberCodeReferenceGet", new { id = memberCodeRef.MemberCodeID });
                _logger.LogInformation("New MemberCodeRef Created");
                return Created(newUri, memberCodeRef.MemberCodeID);

            }
            catch (Exception ex)
            {

                _logger.LogError("Error while saving MemberCodeRef : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]MemberCodeReferenceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldMemberCodeRef = _MemberCodeReferenceRepository.GetById(model.MemberCodeID);
                

                if (oldMemberCodeRef == null) return NotFound($"Could not find a MemberCodeRef with an MemberContactID of {model.MemberCodeID}");

                int controlTypeID = oldMemberCodeRef.ControlTypeID;

                _mapper.Map(model, oldMemberCodeRef);
                oldMemberCodeRef.UpdatedBy = base.UserName;
                oldMemberCodeRef.UpdatedDate = base.TodaysDate;
                oldMemberCodeRef.ControlTypeID = controlTypeID;


                _IMemberReferenceService.CheckMemberReference(oldMemberCodeRef);
                if (!_IMemberReferenceService.BusinessState.IsValid)
                {
                    _IMemberReferenceService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                oldMemberCodeRef.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldMemberCodeRef.EffectiveDate, oldMemberCodeRef.TermDate);
                oldMemberCodeRef.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldMemberCodeRef.EffectiveDate, oldMemberCodeRef.TermDate).ToString();

                _MemberCodeReferenceRepository.Update(oldMemberCodeRef);
                if (!_MemberCodeReferenceRepository.DbState.IsValid)
                {
                    _MemberCodeReferenceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.MemberCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating MemberCodeRef :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberCodeReferenceRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting MemberCodeRef : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetMemberCodeReference/{FamilyCode}")]
        public IActionResult GetMemberCodeReference(string FamilyCode)
        {
            try
            {
                List<MemberCodeReferenceViewModel> mcrList = _MemberCodeReferenceRepository.GetMemberCodeRef(FamilyCode).ToList();
                return Ok(mcrList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
