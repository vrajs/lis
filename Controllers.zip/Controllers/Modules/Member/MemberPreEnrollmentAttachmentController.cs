﻿using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Implementation.Member;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberPreEnrollmentAttachment")]
    [ApiController]
    public class MemberPreEnrollmentAttachmentAPIController :BaseAPIController
    {
        private readonly IFaasHttpClient _iFaasHttpClient;
        private IMapper _mapper;
       // private readonly PreEnrollmentAttachmentService _preEnrollmentAttachmentService;
        private readonly IMemberPreEnrollmentAttachmentRepository _iMemberPreEnrollmentAttachmentRepository;
        private ILogger<MemberEnrollmentHeaderAPIController> _logger;        

        public MemberPreEnrollmentAttachmentAPIController(IMapper mapper,
                    ILogger<MemberEnrollmentHeaderAPIController> logger,
                    IFaasHttpClient iFaasHttpClient,
                    IMemberPreEnrollmentAttachmentRepository iMemberPreEnrollmentAttachmentRepository)
        {
            _iFaasHttpClient = iFaasHttpClient;
            _iMemberPreEnrollmentAttachmentRepository = iMemberPreEnrollmentAttachmentRepository;
            _logger = logger;            
        }

        [HttpPost("CreateContainer")]
        [AllowAnonymous]
        public async Task<IActionResult> CreateContainer(string containerName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _iFaasHttpClient.CreateContainer(containerName);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Ok();
        }

        [HttpPost("CreateBlob")]
        [AllowAnonymous]
        public async Task<IActionResult> CreateBlob([FromForm] BlobDataModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _iFaasHttpClient.CreateBlob(model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Pre-Enrollment : {0}", ex);
                return BadRequest(ex.Message);
            }

            return Ok();
        }


        [HttpGet]
        [Route("GetAttachmentList/{memberId}")]
        public async Task<IActionResult> GetMemberAttachment(int memberId)
        {
            try
            {
                var result = await _iMemberPreEnrollmentAttachmentRepository.GetMemberAttachmentByMemberId(memberId);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting attachment list By Member Id : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("GetMemberAttachmentList/{memberId}")]
        public async Task<IActionResult> GetMemberAttachmentList(int memberId)
        {
            try
            {
                var result = await _iMemberPreEnrollmentAttachmentRepository.GetMemberAttachmentListByMemberId(memberId);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting attachment list By Member Id : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("GetBlob")]
        public async Task<IActionResult> GetBlob(BlobDataUriModel model)
        {
            try
            {
                var data = await _iFaasHttpClient.GetBlob(model);                
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Blob Url : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
