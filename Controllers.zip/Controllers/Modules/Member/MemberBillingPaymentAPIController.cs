using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Member;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Member;
using System.Net;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberBillingPayment")]
    public class MemberBillingPaymentAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<MemberBillingPaymentAPIController> _logger;
        private readonly IMemberBillingPaymentRepository _MemberBillingPaymentRepository;
        private IMemberBillingPaymentService _MemberBillingPaymentService;
        #endregion

        #region Constructor
        public MemberBillingPaymentAPIController(IMapper mapper, ILogger<MemberBillingPaymentAPIController> logger, IMemberBillingPaymentRepository memberBillingPaymentRepository, IMemberBillingPaymentService memberBillingPaymentService)
        {
            this._mapper = mapper;
            this._logger = logger;
            this._MemberBillingPaymentRepository = memberBillingPaymentRepository;
            this._MemberBillingPaymentService = memberBillingPaymentService;
        }
        #endregion

        #region Api Methods
        [HttpGet("{id}", Name = "MemberBillingPaymentGet")]
        public IActionResult Get(int id)
        {
            try
            {
                MemberBillingPayment eMemberBillingPayment = _MemberBillingPaymentRepository.GetById(id);
                if (eMemberBillingPayment == null) return NoContent();
                return Ok(_mapper.Map<MemberBillingPaymentViewModel>(eMemberBillingPayment));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  MemberBillingPaymentViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entityMemberBillingPayment = _mapper.Map<MemberBillingPayment>(model);
                entityMemberBillingPayment.CreatedDate = base.TodaysDate;
                entityMemberBillingPayment.CreatedBy = base.UserName;
                entityMemberBillingPayment.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entityMemberBillingPayment.EffectiveDate, entityMemberBillingPayment.TermDate);
                entityMemberBillingPayment.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entityMemberBillingPayment.EffectiveDate, entityMemberBillingPayment.TermDate).ToString();

                //Check Business logic
                _MemberBillingPaymentService.CheckBusinessRules(entityMemberBillingPayment);
                if (!_MemberBillingPaymentService.BusinessState.IsValid)
                {
                    _MemberBillingPaymentService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    //return BadRequest(ModelState);
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _MemberBillingPaymentRepository.Add(entityMemberBillingPayment);
                if (!_MemberBillingPaymentRepository.DbState.IsValid)
                {
                    _MemberBillingPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MemberBillingPaymentGet", new { id = entityMemberBillingPayment.MemberBillingPaymentID });
                _logger.LogInformation("New Billing Payment Created");
                return Created(newUri, _mapper.Map<MemberBillingPaymentViewModel>(entityMemberBillingPayment));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Billing Payment : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]  MemberBillingPaymentViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var oldMemberBillingPayment = _MemberBillingPaymentRepository.GetById(model.MemberBillingPaymentID);
                if (oldMemberBillingPayment == null) return NoContent();

                _mapper.Map(model, oldMemberBillingPayment);
                oldMemberBillingPayment.UpdatedBy = base.UserName;
                oldMemberBillingPayment.UpdatedDate = base.TodaysDate;
                oldMemberBillingPayment.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldMemberBillingPayment.EffectiveDate, oldMemberBillingPayment.TermDate);
                oldMemberBillingPayment.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldMemberBillingPayment.EffectiveDate, oldMemberBillingPayment.TermDate).ToString();

                //Check Business logic
                _MemberBillingPaymentService.CheckBusinessRules(oldMemberBillingPayment);
                if (!_MemberBillingPaymentService.BusinessState.IsValid)
                {
                    _MemberBillingPaymentService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                _MemberBillingPaymentRepository.Update(oldMemberBillingPayment);
                if (!_MemberBillingPaymentRepository.DbState.IsValid)
                {
                    _MemberBillingPaymentRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<MemberBillingPaymentViewModel>(oldMemberBillingPayment));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Billing Payment: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MemberBillingPaymentRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting Billing Payment : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetMemberBillingPayment/{FamilyCode}")]
        public IActionResult GetMemberBillingPayment(string FamilyCode)
        {
            try
            {
                List<MemberBillingPaymentViewModel> mbPaymentList = _MemberBillingPaymentRepository.GetMemberBillingPayment(FamilyCode, -1).ToList();
                return Ok(mbPaymentList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
