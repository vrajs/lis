using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberDiscloserInfoODController : BaseODController
    {
        #region Variables        
        private IMemberDiscloserInfoRepository _MemberDiscloserInfoRepository;
        #endregion

        #region Ctor        
        public MemberDiscloserInfoODController(IMemberDiscloserInfoRepository MemberDiscloserInfoRepository)
        {
            _MemberDiscloserInfoRepository = MemberDiscloserInfoRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberDiscloserInfo")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberDiscloserInfo(int MemberId)
        {
            var MemberDiscloserInfo = _MemberDiscloserInfoRepository.GetMemberDiscloserInfo(MemberId);
            return Ok(MemberDiscloserInfo);
        }
    }
}
