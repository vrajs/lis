﻿using AutoMapper;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Common;
using Kwicle.Data;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.AspNetCore.Authorization;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Business.Interfaces.Member;
using Kwicle.Data.Contracts.Member;
using Kwicle.Common.Utility;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Business.Interfaces.Provider;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Repositories.Member;
using IdentityModel.Client;
using Kwicle.Service.Authorization;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/PreEnrollment")]
    [ApiController]
    public class PreEnrollmentAPIController : BaseAPIController
    {
        #region Variables

        
        private IMapper _mapper;
        private ILogger<PreEnrollmentAPIController> _logger;
        private readonly KwicleContext _Context;

        private readonly ICommonCodeRepository _CommonCodeRepository;
        private readonly ICommonCodeService _CommonCodeService;

        private readonly IZipCodeRepository _ZipCodeRepository;
        private readonly IZipCodeService _zipCodeService;

        private readonly IMemberEnrollmentHeaderRepository _memberEnrollmentHeaderRepository;
        private readonly IMemberEnrollmentHeaderService _memberEnrollmentHeaderService;

        private readonly IProviderRepository _IProviderRepository;
        private readonly IProviderService _IProviderService;

        //private readonly IPreEnrollmentRepository _IPreEnrollmentRepository;
        private readonly IPreEnrollmentService _IPreEnrollmentService;

        private readonly IConfiguration _configuration;

        #endregion

        #region Ctor        

        public PreEnrollmentAPIController(IMapper mapper, ILogger<PreEnrollmentAPIController> logger, KwicleContext Context
            ,IMemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository, IMemberEnrollmentHeaderService memberEnrollmentHeaderService
            ,IZipCodeRepository ZipCodeRepository, IZipCodeService zipCodeService
            ,IProviderRepository IProviderRepository, IProviderService IProviderService
            ,ICommonCodeRepository CommonCodeRepository, ICommonCodeService CommonCodeService
            //,IPreEnrollmentRepository PreEnrollmentRepository
            , IPreEnrollmentService PreEnrollmentService
            , IConfiguration configuration
            )
        {
            
            _mapper = mapper;
            _logger = logger;            
            _Context = Context;
            _CommonCodeRepository = CommonCodeRepository;
            _CommonCodeService = CommonCodeService;

            _ZipCodeRepository = ZipCodeRepository;
            _zipCodeService = zipCodeService;

            _memberEnrollmentHeaderRepository = memberEnrollmentHeaderRepository;
            _memberEnrollmentHeaderService = memberEnrollmentHeaderService;

            _IProviderRepository = IProviderRepository;
            _IProviderService = IProviderService;

            //_IPreEnrollmentRepository = PreEnrollmentRepository;
            _IPreEnrollmentService = PreEnrollmentService;

            _configuration = configuration;
        }

        #endregion

        //Get

        [HttpGet("GetToken")]
        [AllowAnonymous]
        public async Task<IActionResult> GetToken()
        {
            try
            {                
                var client = new HttpClient();
                string authorityUrl = $"{_configuration["Keys:AuthorityUrl"]}";
                var disco = await client.GetDiscoveryDocumentAsync(authorityUrl);
                if (disco.IsError)
                {
                    return BadRequest(disco.Error.ToString());
                }
                var tokenResponse = await client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
                {
                    Address = disco.TokenEndpoint,
                    ClientId = $"{_configuration["Keys:GoldKidneyClientId"]}",
                    ClientSecret = $"{_configuration["Keys:GoldKidneyClientSecret"]}",
            });

                return Ok(tokenResponse.AccessToken);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetCommonCodeByCodeTypeId/{CodeTypeId}")]
        [Authorize(Policy = Service.Authorization.Policies.GoldKidneyGETPolicy)]
        public async Task<IActionResult> GetCommonCodeByCodeTypeId(Int16 CodeTypeId)
        {
            try
            {
                var result = await _CommonCodeRepository.GetCommonCodeByCodeTypeId(CodeTypeId);
                return Ok(_mapper.Map<List<CommonCode>>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //Get
        [HttpGet("GetCommonCodeConfigurationByCodeTypeId/{PageId}/{CodeTypeId}")]
        [Authorize(Policy = Service.Authorization.Policies.GoldKidneyGETPolicy)]
        public IActionResult GetCommonCodeConfigurationByCodeTypeId(string PageId, int CodeTypeId)
        {
            var commonCodesConfiguration = _CommonCodeRepository.GetCommonCodeConfigurationByCodeTypeId(PageId, CodeTypeId);
            return Json(commonCodesConfiguration);
        }

        //Get
        [HttpGet]
        [Route("GetZipCodeBySearchValue/{serachValue}")]
        [Authorize(Policy = Service.Authorization.Policies.GoldKidneyGETPolicy)]
        public async Task<IActionResult> GetZipCodeBySearchValue([FromQuery] string searchValue)
        {
            try
            {
                var result = await _ZipCodeRepository.GetZipCodesFromView(searchValue);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        //Get
        [HttpGet]
        [Route("GetSepReason")]
        [Authorize(Policy = Service.Authorization.Policies.GoldKidneyGETPolicy)]
        public async Task<IActionResult> GetSepReason()
        {
            try
            {
                var result = await _memberEnrollmentHeaderRepository.GetSepReason();
                return Ok(_mapper.Map<List<SEPReasonCodeViewModel>>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //Get
        [HttpGet("GetProviderNameByProCode/{proCode}")]
        [Authorize(Policy = Service.Authorization.Policies.GoldKidneyGETPolicy)]
        public IActionResult GetProviderNameByProCode(string proCode)
        {
            try
            {
                var provider = _IProviderRepository.GetProviderNameByProCode(proCode);
                if (provider == null) return NotFound($"Provider with {proCode} was not found");
                return Ok(provider);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //Post        
        [HttpPost]
        [Route("InsertPreEnrollment")]
        [Authorize(Policy = Service.Authorization.Policies.GoldKidneyPOSTPolicy)]
        public IActionResult InsertPreEnrollment([FromBody] PreEnrollment model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                int PreEnrollmentMemberId = _IPreEnrollmentService.InsertPreEnrollment(model);
                model.PreEnrollmentId = PreEnrollmentMemberId;
                //if (PreEnrollmentMemberId == 0) return NotFound($"Provider with {proCode} was not found");
                _logger.LogInformation("New Enrollment Member Created");
                return Ok("New Enrollment Member Created");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Enrollment Header: {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
