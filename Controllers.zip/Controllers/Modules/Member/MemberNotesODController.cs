using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberNotesODController : BaseODController
    {
        #region Variables        
        private IMemberNotesRepository _IMemberNotesRepository;
        #endregion

        #region Ctor        
        public MemberNotesODController(IMemberNotesRepository IMemberNotesRepository)
        {
            _IMemberNotesRepository = IMemberNotesRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberNotes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberNotes(string FamilyCode)
        {
            var MemberNotesQuery = _IMemberNotesRepository.GetMemberNotes(FamilyCode);
            return Ok(MemberNotesQuery);
        }
    }
}
