using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberPCPODController : BaseODController
    {
        #region Property        
        private IMemberPCPRepository _IMemberPCPRepository;
        #endregion

        #region Constructor        
        public MemberPCPODController(IMemberPCPRepository memberPCPRepository)
        {
            _IMemberPCPRepository = memberPCPRepository;
        }
        #endregion

        #region Odata Methods
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberPCP")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberPCP(string FamilyCode)
        {
            var query = _IMemberPCPRepository.GetMemberPCP(FamilyCode);
            return Ok(query);
        }


        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetProviderForMember")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetMemberProvider(int MemberID)
        {
            var query = _IMemberPCPRepository.GetProviderForMember(MemberID);
            return Ok(query);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetProviderLocationForMember")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetProviderLocationForMember(int ProviderID, int MemberID)
        {
            var query = _IMemberPCPRepository.GetProviderLocationForMember(ProviderID, MemberID);
            return Ok(query);
        }
        #endregion
    }
}
