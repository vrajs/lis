using Kwicle.Data.Contracts.Member;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.View;
using System.Linq;
using System;
using Kwicle.Core.Views;
using Kwicle.Core.Common;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("odata")]
    public class MemberODController : BaseODController
    {
        #region Property        
        private IMemberRepository _IMemberRepository;
        private IViewRepository _IViewRepository;
        #endregion

        #region Constructor        
        public MemberODController(IMemberRepository memberRepository, IViewRepository viewRepository)
        {
            _IMemberRepository = memberRepository;
            _IViewRepository = viewRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Members")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetMembers(byte recordStatus)
        {
            var query = _IMemberRepository.GetMember();
            if (recordStatus == (byte)RecordStatus.InActive)
            {
                query = query.Where(e => (e.RecordStatus == (byte)RecordStatus.Pend || e.RecordStatus == (byte)RecordStatus.InActive || e.RecordStatus == (byte)RecordStatus.Cancel || e.RecordStatus == (byte)RecordStatus.VoidOrInvalid));
            }
            else
            {
                if (recordStatus != byte.MaxValue)
                {
                    query = query.Where(e => e.RecordStatus == recordStatus);
                }
            }

            return Ok(query);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("MemberLookup")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetMemberLookup(DateTime? ClaimDOSFrom, DateTime? ClaimDOSTo)
        {
            IQueryable<MemberLookupViewModel> query;
            if (ClaimDOSFrom != null && ClaimDOSTo != null)
                query = _IViewRepository.MemberLookups.Where(e => (ClaimDOSFrom >= e.EffectiveDate && ClaimDOSTo <= e.TermDate) || (e.MemberEligibilityID == null)).AsQueryable();
            else
                query = _IViewRepository.MemberLookups;

            return Ok(query);
        }
    }
}
