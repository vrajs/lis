﻿using AutoMapper;
using DocumentFormat.OpenXml.Office2019.Drawing.Model3D;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Globalization;
using Xceed.Words.NET;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Modules.Member
{
    [Route("api/MemberTransaction")]
    [ApiController]
    public class MemberTransactionAPIController : BaseAPIController
    {
        private readonly IMemberTransactionRepository _memberTransactionRepository;
        private ILogger<MemberTransactionAPIController> _logger;
        private readonly IFaasHttpClient _faasHttpClient;
        private IMapper _mapper;
        private IConfiguration _config;
        public MemberTransactionAPIController(IMapper mapper,
            ILogger<MemberTransactionAPIController> logger,
            IMemberTransactionRepository memberTransactionRepository,
            IConfiguration iConfig, IFaasHttpClient faasHttpClient)
        {
            _memberTransactionRepository = memberTransactionRepository;
            _mapper = mapper;
            _logger = logger;
            _config = iConfig;
            _faasHttpClient = faasHttpClient;
        }

        /// <summary>
        /// Get Member Transaction by Id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _memberTransactionRepository.GetById(Id);
                if (result == null) return NoContent();
                return Ok(_mapper.Map<MemberTransactionDetailViewModel>(result));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Member Transaction : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Get All LetterCorrespondance
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAllLetterCorrespondance")]
        public async Task<IActionResult> GetAllLetterCorrespondance()
        {
            try
            {
                var result = await _memberTransactionRepository.GetAllLetterCorrespondance();
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Transaction By Member Id : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Get All Member Transaction by member Id
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetTransactionByMemberId/{memberId}")]
        public async Task<IActionResult> GetTransactionByMemberId(int memberId)
        {
            try
            {
                var result = await _memberTransactionRepository.GetTransactionByMemberId(memberId);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Transaction By Member Id : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Get All Member Correspondance by member Id
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCorrespondanceByMemberId/{memberId}")]
        public async Task<IActionResult> GetCorrespondanceByMemberId(int memberId)
        {
            try
            {
                var result = await _memberTransactionRepository.GetCorrespondanceByMemberId(memberId);
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting Transaction By Member Id : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        private byte[] GetBytesFromString(string input)
        {
            using (MemoryStream stream = new MemoryStream())
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.Write(input);
                writer.Flush();
                return stream.ToArray();
            }
        }
        [HttpGet]
        public async Task<string> ReplacePlaceHolders(PlaceHolderReplaceViewModel placeHolderReplaceViewModel)
        {
            try
            {
                string[] parts = placeHolderReplaceViewModel.EffectiveDate.Split(new char[] { ' ', '(' }, StringSplitOptions.RemoveEmptyEntries);

                // Extract the date part from the split parts
                placeHolderReplaceViewModel.EffectiveDate = string.Join(" ", parts[0], parts[1], parts[2], parts[3]);
                IFormFile newFile;
                string currentDirectory = Directory.GetCurrentDirectory();
                string templatePath = Path.Combine(currentDirectory, "Templates", "Enrollment_Acknowledgement.docx");
                using (var doc = DocX.Load(templatePath))
                {
                    ReplacePlaceholderWithValue(doc, "<LowIncomePartD>", (placeHolderReplaceViewModel.PartCPremiumAmount + placeHolderReplaceViewModel.PartDPremiumAmount - placeHolderReplaceViewModel.LowIncomePartD).ToString());
                    ReplacePlaceholderWithValue(doc, "<PartCPremiumAmount>", (placeHolderReplaceViewModel.PartCPremiumAmount + placeHolderReplaceViewModel.PartDPremiumAmount).ToString());
                    ReplacePlaceholderWithValue(doc, "<ClientMemberId>", placeHolderReplaceViewModel.ClientMemberId);
                    ReplacePlaceholderWithValue(doc, "<PrimaryRxId>", placeHolderReplaceViewModel.PrimaryRxId);
                    ReplacePlaceholderWithValue(doc, "<PrimaryRxBIN>", placeHolderReplaceViewModel.PrimaryRxBIN);
                    ReplacePlaceholderWithValue(doc, "<PrimaryRxGroup>", placeHolderReplaceViewModel.PrimaryRxGroup);
                    ReplacePlaceholderWithValue(doc, "<PlanName>", placeHolderReplaceViewModel.PBPDescription);
                    ReplacePlaceholderWithValue(doc, "<PrimaryRxPCN>", placeHolderReplaceViewModel.PrimaryRxPCN);

                    ReplacePlaceholderWithValue(doc, "<FirstName>", placeHolderReplaceViewModel.FirstName);
                    ReplacePlaceholderWithValue(doc, "<LastName>", placeHolderReplaceViewModel.LastName);
                    ReplacePlaceholderWithValue(doc, "<MiddleInitial>", placeHolderReplaceViewModel.MiddleInitial);
                    ReplacePlaceholderWithValue(doc, "<EffectiveDate>", placeHolderReplaceViewModel.EffectiveDate);
                    ReplacePlaceholderWithValue(doc, "<LowIncomeCoPay>", placeHolderReplaceViewModel.LowIncomeCoPay.ToString());
                    ReplacePlaceholderWithValue(doc, "<PBPDescription>", placeHolderReplaceViewModel.PBPDescription);
                    ReplacePlaceholderWithValue(doc, "<ContractDescription>", placeHolderReplaceViewModel.ContractDescription);
                    ReplacePlaceholderWithValue(doc, "<TTYNumber>", "1-844-294-6535 (TTY-711)");
                    ReplacePlaceholderWithValue(doc, "<TtyHoursOfOperation>", "8AM to 8PM on All Days");
                    ReplacePlaceholderWithValue(doc, "<plan telephone number>", "1-844-294-6535");
                    ReplacePlaceholderWithValue(doc, "<phone number>", "1-844-294-6535");
                    ReplacePlaceholderWithValue(doc, "<insert appropriate LIS deductible amount>", "LIS Deductible Amount");

                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        doc.SaveAs(memoryStream);
                        memoryStream.Position = 0; // Reset the stream position before using it

                        // Convert the MemoryStream data to byte[]
                        byte[] modifiedDocumentData = memoryStream.ToArray();

                        // Create a custom implementation of IFormFile using the custom class
                       
                        newFile = new ByteArrayFormFile(modifiedDocumentData, "Enrollment Acknowledgment_" + placeHolderReplaceViewModel.ClientMemberId + ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                    }
                    BlobDataModel blobModel = new()
                    {
                        ContainerName = _config.GetSection("ContainerName").Value,
                        FolderName = $"{"Enrollment_Acknowledgment"}/{placeHolderReplaceViewModel.ClientMemberId}",
                        FileUpload = newFile,
                        MetaDataJson = string.Empty
                    };

                    var blobResult = await _faasHttpClient.CreateBlob(blobModel);
                    CreateBlobResponse createBlobResponse = JsonConvert.DeserializeObject<CreateBlobResponse>(blobResult);
                    return createBlobResponse.data;

                }


            }
            catch (Exception e)
            {
                return "Some Error Occured";
                throw;
            }
        }
        private void ReplacePlaceholderWithValue(DocX doc, string placeholder, string value)
        {
            var paragraphs = doc.Paragraphs;
            foreach (var p in paragraphs)
            {
                var text = p.Text;
                if (text.Contains(placeholder))
                {
                    p.ReplaceText(placeholder, value);
                }
            }
        }
        /// <summary>
        /// Save Member Transaction Details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] MemberTransactionDetailViewModel model)
        {
            try
            {
                MemberTransactionDetail memberTransactionDetails = _mapper.Map<MemberTransactionDetailViewModel, MemberTransactionDetail>(model);
                memberTransactionDetails.CreatedBy = base.UserName;
                memberTransactionDetails.CreatedDate = base.TodaysDate;
                string file = ReplacePlaceHolders(model.placeHolderReplaceViewModel).Result;
                model.FolderName = _config.GetSection("ContainerName").Value + "/" + file;
                var transactionID = await _memberTransactionRepository.AddTransaction(memberTransactionDetails, model, model.placeHolderReplaceViewModel);

                return Ok(transactionID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving member transaction : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Member Transaction
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] MemberTransactionDetailViewModel model)
        {
            try
            {
                MemberTransactionDetail memberTransactionDetails = _mapper.Map<MemberTransactionDetailViewModel, MemberTransactionDetail>(model);
                memberTransactionDetails.UpdatedBy = base.UserName;
                memberTransactionDetails.CreatedBy = base.UserName;
                memberTransactionDetails.UpdatedDate = base.TodaysDate;
                await _memberTransactionRepository.UpdateTransaction(memberTransactionDetails, model, model.placeHolderReplaceViewModel);
                return Ok(memberTransactionDetails.MemberTransactionDetailID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating member transaction : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Delete Member Transaction
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        [Obsolete]
        public IActionResult Delete(int id)
        {
            try
            {
                _memberTransactionRepository.DeleteById(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting member transaction : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
    public class ByteArrayFormFile : IFormFile
    {
        private readonly byte[] _data;
        private readonly string _fileName;

        public ByteArrayFormFile(byte[] data, string fileName, string contentType)
        {
            _data = data;
            _fileName = fileName;
            ContentType = contentType;
        }

        public string ContentType { get; }

        public string ContentDisposition => $"form-data; name=file; filename={_fileName}.docx";

        public IHeaderDictionary Headers => new HeaderDictionary();

        public long Length => _data.Length;

        public string Name => "file.docx";

        public string FileName => "Acknowledgement.docx";

        public void CopyTo(Stream target)
        {
            target.Write(_data, 0, _data.Length);
        }

        public async Task CopyToAsync(Stream target, CancellationToken cancellationToken = default)
        {
            await target.WriteAsync(_data, 0, _data.Length, cancellationToken).ConfigureAwait(false);
        }

        public Stream OpenReadStream()
        {
            return new MemoryStream(_data);
        }
    }
}
