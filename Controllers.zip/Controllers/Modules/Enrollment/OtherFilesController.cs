﻿using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel.Enrollment;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Business.Interfaces.ETLStructure;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Data.Contracts.Member;
using AutoMapper;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Business.Interfaces.Member;
using Newtonsoft.Json;

namespace Kwicle.Service.Controllers.Modules.Enrollment
{
    [Route("api/OtherFiles")]
    public class OtherFilesController : BaseAPIController
    {
        #region Variables
        private readonly KwicleContext _Context;
        private readonly IOECFileUploadService _OECFileUploadService;
        private readonly ICmsAzureDataFactoryService _memberEnrollmentBEQService;
        private readonly IMemberEnrollmentBEQRepository _memberEnrollmentBEQRepository;
        private readonly IFaasHttpClient _faasHttpClient;
        private IMapper _mapper;
        private IConfiguration _config;

        #endregion

        #region Ctor
        public OtherFilesController(KwicleContext Context, IOECFileUploadService OECFileUploadService, IMapper mapper,
            ICmsAzureDataFactoryService memberEnrollmentBEQService,
            IMemberEnrollmentBEQRepository memberEnrollmentBEQRepository,
            IConfiguration iConfig,
            IFaasHttpClient faasHttpClient)
        {
            _memberEnrollmentBEQService = memberEnrollmentBEQService;
            _memberEnrollmentBEQRepository = memberEnrollmentBEQRepository;
            _mapper = mapper;
            _config = iConfig;
            _faasHttpClient = faasHttpClient;
            _Context = Context;
            _OECFileUploadService = OECFileUploadService;
        }
        #endregion

        #region API Methods
        /// <summary>
        /// Make entry in Db for uploaded documents
        /// </summary>
        /// <param name="DocumentListVM">Document details</param>
        /// <returns>File Upload or not message</returns>
        [HttpPost("DocumentUpload")]
        public async Task<IActionResult> DocumentUpload([FromBody] DocumentListVM documentInputModel)
        {
            try
            {
                List<OtherDocument> DocList = GetDocList(documentInputModel.DocumentList);
                await _Context.OtherDocuments.AddRangeAsync(DocList);
                int NoOfRowsInserted = await _Context.SaveChangesAsync();
                if (NoOfRowsInserted > 0)
                {
                    return Ok(new { message = "Documents Saved Successfully", Data = DocList });
                }
                else
                {
                    return Ok(new { message = "Something went wrong. Please try again." });
                }
            }
            catch (Exception ex)
            {
                return Ok(new { message = ex.Message });
            }
        }
        /// <summary>
        /// Call Create Blob method yo Upload document in Azure
        /// </summary>
        /// <param name="data">Attachment details</param>
        /// <returns></returns>
        [HttpPost, DisableRequestSizeLimit]
        [Route("OtherAttachmentUpload")]
        public async Task<IActionResult> OtherAttachmentUpload(IFormCollection data)
        {
            try
            {
                var uploadedEnrollAttachmentFiles = Request.Form.Files;
                string fileStorePath = _config.GetSection("ContainerName").Value;
                List<MemberPreEnrollmentAttachmentViewModel> attachmentList = new();

                //var containerResult = await _faasHttpClient.CreateContainer(_config.GetSection("ContainerName").Value);

                if (uploadedEnrollAttachmentFiles.Count > 0)
                {
                    for (int i = 0; i < uploadedEnrollAttachmentFiles.Count; i++)
                    {
                        //MemberPreEnrollmentAttachmentViewModel attachmentModel = new();

                        BlobDataModel blobModel = new()
                        {
                            ContainerName = _config.GetSection("ContainerName").Value,
                            FolderName = $"{data["memberId"]}/{"other"}",
                            FileUpload = uploadedEnrollAttachmentFiles[i],
                            MetaDataJson = string.Empty
                        };

                        var blobResult = await _faasHttpClient.CreateBlob(blobModel);
                        CreateBlobResponse createBlobResponse = JsonConvert.DeserializeObject<CreateBlobResponse>(blobResult);
                        //var postedFile = uploadedEnrollAttachmentFiles[i];

                        //if (!CommonUtil.allowedExtensions().Any(x => x == Path.GetExtension(postedFile.FileName)))
                        //{
                        //    return Ok("Extension is not allowed");
                        //}
                        OtherDocument otherDocument = new OtherDocument();
                        //otherDocument.DocumentName = blobResult.Substring(blobResult.LastIndexOf("/") + 1);
                        otherDocument.DocumentName = uploadedEnrollAttachmentFiles[i].FileName;
                        //attachmentModel.FileLocation = $"{fileStorePath}/{data["memberId"]}/{data["attachmentType"]}";
                        otherDocument.MemberID = Convert.ToInt32(data["memberId"]);
                        otherDocument.CreatedDate = DateTime.Now;
                        otherDocument.UpdatedDate = DateTime.Now;
                        otherDocument.IsDeleted = false;
                        otherDocument.FolderName = _config.GetSection("ContainerName").Value + "/" + createBlobResponse.data;
                        otherDocument.CreatedBy = base.UserName;
                        otherDocument.AttachmentType = data["attachmentType"];
                        otherDocument.ContentType = uploadedEnrollAttachmentFiles[i].ContentType;
                        otherDocument.DocumentContent = new Byte[1];

                        //attachmentList.Add(attachmentModel);
                        try
                        {
                            _Context.OtherDocuments.Add(otherDocument);
                            _Context.SaveChanges();
                        }
                        catch (Exception e)
                        {

                            throw;
                        }
                    }
                }
                return Ok();
            }
            catch (Exception e)
            {

                throw;
            }
        }
        private List<OtherDocument> GetDocList(DocumentVM[] lstDocVM)
        {
            //converting document array received to database document table list
            List<OtherDocument> DBDocList = new List<OtherDocument>();
            foreach (var Doc in lstDocVM)
            {
                // dividing file content from file type
                Doc.DocumentContent = Doc.DocumentContent.Substring(Doc.DocumentContent.IndexOf(",") + 1);
                DBDocList.Add(new OtherDocument
                {
                    DocumentName = Doc.DocumentName,
                    DocumentContent = Convert.FromBase64String(Doc.DocumentContent),
                    ContentType = Doc.ContentType,
                    IsDeleted = Doc.IsDeleted,
                    UpdatedBy = Doc.UpdatedBy,
                    MemberID = Doc.MemberID,
                    UpdatedDate = Doc.UpdatedDate,
                    CreatedBy = Doc.CreatedBy,
                    CreatedDate = Doc.CreatedDate,
                    AttachmentType = Doc.AttachmentType
                });
            }
            return DBDocList;
        }
        //[HttpGet("DownloadDocument/{DocumentId}")]
        //public HttpResponseMessage DownloadDoument(long documentId)
        //{
        //    try
        //    {
        //        OtherDocument doc = _Context.OtherDocuments.FirstOrDefault(x => x.DocumentId == documentId);

        //        HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
        //        //MemoryStream ms = new MemoryStream(DocumentBytes.Value);
        //        result.Content = new ByteArrayContent(doc.DocumentContent.ToArray());
        //        result.Content.Headers.ContentType = new MediaTypeHeaderValue(doc.ContentType);
        //        result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
        //        result.Content.Headers.ContentDisposition.FileName = doc.DocumentName;
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        return new HttpResponseMessage(HttpStatusCode.InternalServerError);
        //    }

        //}
        
        //[HttpGet("DownloadDocument/{DocumentId}")]
        //[AllowAnonymous]
        //public IActionResult DownloadDoument(long DocumentId)
        //{
        //    try
        //    {
        //        OtherDocument doc = _Context.OtherDocuments.FirstOrDefault(x => x.DocumentId == DocumentId);
        //        BlobDataUriModel blobDataUriModel = new BlobDataUriModel();
        //        blobDataUriModel.FileName = doc.FolderName;
        //        blobDataUriModel.ContainerName = _config.GetSection("ContainerName").Value;

        //        //BlobDataUriModel blobResult =  _faasHttpClient.GetBlob(blobDataUriModel);

        //        return File(doc.DocumentContent, doc.ContentType, doc.DocumentName);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Ok(new { message = ex.Message });
        //    }

        //}
        [HttpGet("ViewDocument/{DocumentId}")]
        [AllowAnonymous]
        public IActionResult ViewDocument(long DocumentId)
        {
            try
            {
                OtherDocument doc = _Context.OtherDocuments.FirstOrDefault(x => x.DocumentId == DocumentId);
                string pdfBase64 = Convert.ToBase64String(doc.DocumentContent);

                return Ok(new { content = pdfBase64, name = doc.DocumentName, contentType = doc.ContentType });
            }
            catch (Exception ex)
            {
                return Ok(new { message = ex.Message });
            }

        }
        /// <summary>
        /// For delete make isDeletd column true in Database
        /// </summary>
        /// <param name="DocumentId"></param>
        /// <returns></returns>
        [HttpDelete("DeleteDoument/{DocumentId}")]
        public IActionResult DeleteDoument(long DocumentId)
        {
            try
            {
                OtherDocument doc = _Context.OtherDocuments.FirstOrDefault(x => x.DocumentId == DocumentId);
                (from p in _Context.OtherDocuments
                 where p.DocumentId == DocumentId
                 select p).ToList().ForEach((x) => { x.IsDeleted = true; x.UpdatedDate = DateTime.Now; x.UpdatedBy = base.UserName; });

                _Context.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                return Ok(new { message = ex.Message });
            }
        }
        #endregion
    }
}
