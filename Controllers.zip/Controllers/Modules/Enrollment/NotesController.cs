﻿using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Kwicle.Service.Controllers.Modules.Enrollment
{
    [Route("api/OtherNotes")]
    public class NotesController : BaseAPIController
    {
        #region Variables
        private readonly KwicleContext _Context;
        #endregion

        #region Ctor
        public NotesController(KwicleContext Context)
        {
            _Context = Context;
        }
        #endregion

        #region API Methods
        /// <summary>
        /// Add entry in Db for Note
        /// </summary>
        /// <param name="OtherNote">Note details</param>
        /// <returns>Success or Failure Message</returns>
        [HttpPost("InsertNote")]
        public async Task<IActionResult> InsertNote([FromBody] OtherNote otherNote)
        {
            try
            {
                otherNote.CreatedDate = DateTime.Now;
                await _Context.OtherNotes.AddAsync(otherNote);
                int NoOfRowsInserted = await _Context.SaveChangesAsync();
                if (NoOfRowsInserted > 0)
                {
                    return Ok(new { message = "Note Saved Successfully", Data = otherNote });
                }
                else
                {
                    return Ok(new { message = "Something went wrong. Please try again." });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        /// <summary>
        /// Get List of Notes for particular member From Db
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns>Note List</returns>
        [HttpGet]
        [Route("GetMemberNotesList/{memberId}")]
        public async Task<IActionResult> GetMemberNotesList(int memberId)
        {
            try
            {
                var result = _Context.OtherNotes.Where(x => x.IsDeleted == false && x.MemberID == memberId).ToList();
                if (result == null) return NoContent();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Make isDeleted field true in Db for deleted note
        /// </summary>
        /// <param name="noteId"></param>
        /// <returns></returns>
        [HttpDelete("DeleteNote/{noteId}")]
        public IActionResult DeleteNote(long noteId)
        {
            try
            {
                OtherNote doc = _Context.OtherNotes.FirstOrDefault(x => x.NoteId == noteId);
                (from p in _Context.OtherNotes
                 where p.NoteId == noteId
                 select p).ToList().ForEach((x) => { x.IsDeleted = true; x.UpdatedDate = DateTime.Now; x.UpdatedBy = base.UserName; });


                _Context.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                return Ok(new { message = ex.Message });
            }

        }
        #endregion
    }
}
