using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities;
using System.Net;
using Kwicle.Business.Interfaces.Masters;
using Microsoft.AspNetCore.Authorization;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/InterestQuickPay")]
    public class InterestQuickPayAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<InterestQuickPayAPIController> _logger;
        private IInterestQuickPayRepository _interestQuickPayRepository;
        private IInterestQuickPayService _interestQuickPayService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public InterestQuickPayAPIController(IInterestQuickPayRepository interestQuickPayRepository, IInterestQuickPayService interestQuickPayService, ILogger<InterestQuickPayAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _interestQuickPayRepository = interestQuickPayRepository;
            _interestQuickPayService = interestQuickPayService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewInterestQuickPayPolicy)]
        public IActionResult Get()
        {
            try
            {
                var interestQuickPayRes = _interestQuickPayRepository.GetByPredicate(x => x.RecordStatus == (int)RecordStatus.Active);
                if (!_interestQuickPayRepository.DbState.IsValid)
                {
                    _interestQuickPayRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(interestQuickPayRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Interest Quick Pay: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "InterestQuickPayGet")]
        [Authorize(Policy = Authorization.Policies.ViewInterestQuickPayPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var interestQuickPay = _interestQuickPayRepository.GetById(id);
                if (interestQuickPay == null) return NotFound($"Interest quick pay with {id} was not found");
                return Ok(_mapper.Map<InterestQuickPayModel>(interestQuickPay));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageInterestQuickPayPolicy)]
        public IActionResult Post([FromBody] InterestQuickPayModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                InterestQuickPay entity = _mapper.Map<InterestQuickPay>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _interestQuickPayService.CheckIfExists(entity);
                if (!_interestQuickPayService.BusinessState.IsValid)
                {
                    _interestQuickPayService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _interestQuickPayRepository.Add(entity);

                if (!_interestQuickPayRepository.DbState.IsValid)
                {
                    _interestQuickPayRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("InterestQuickPayGet", new { id = entity.InterestQuickPayID });
                _logger.LogInformation("New InterestQuickPay Created");
                return Created(newUri, _mapper.Map<InterestQuickPayModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving InterestQuickPay : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageInterestQuickPayPolicy)]
        public IActionResult Put([FromBody] InterestQuickPayModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                InterestQuickPay entity = _interestQuickPayRepository.GetById(model.InterestQuickPayID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _interestQuickPayService.CheckIfExists(entity);
                if (!_interestQuickPayService.BusinessState.IsValid)
                {
                    _interestQuickPayService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _interestQuickPayRepository.Update(entity);
                if (!_interestQuickPayRepository.DbState.IsValid)
                {
                    _interestQuickPayRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("InterestQuickPay updated : {0}", entity.InterestQuickPayID);
                return Ok(entity.InterestQuickPayID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating InterestQuickPay : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteInterestQuickPayPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                InterestQuickPay entity = _interestQuickPayRepository.GetById(id);
                _interestQuickPayRepository.Delete(entity);
                //_interestQuickPayRepository.DeleteById(id);
                if (!_interestQuickPayRepository.DbState.IsValid)
                {
                    _interestQuickPayRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing InterestQuickPay : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
