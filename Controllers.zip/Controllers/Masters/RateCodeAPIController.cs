using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using Kwicle.Common.Utility;
using Kwicle.Business.Interfaces.Masters;
using System.Net;
using Kwicle.Core.Entities.Master;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/RateCode")]
    public class RateCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RateCodeAPIController> _logger;
        private IRateCodeRepository _RateCodeRepository;
        private IRateCodeService _RateCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public RateCodeAPIController(IRateCodeRepository RateCodeRepository, IRateCodeService RateCodeService, ILogger<RateCodeAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _RateCodeRepository = RateCodeRepository;
            _RateCodeService = RateCodeService;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var RateCodeRes = _RateCodeRepository.GetRateCode();
                return Ok(RateCodeRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Rate Code: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RateCodeGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var RateCode = _RateCodeRepository.GetById(id);
                if (RateCode == null) return NotFound($"RateCode with {id} was not found");
                return Ok(_mapper.Map<RateCodeModel>(RateCode));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] RateCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RateCode entity = _mapper.Map<RateCode>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _RateCodeService.CheckIfExists(entity);
                if (!_RateCodeService.BusinessState.IsValid)
                {
                    _RateCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _RateCodeRepository.Add(entity);

                if (!_RateCodeRepository.DbState.IsValid)
                {
                    _RateCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("RateCodeGet", new { id = entity.RateCodeID });
                _logger.LogInformation("New Rate Code Created");
                return Created(newUri, _mapper.Map<RateCodeModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Timly filling : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] RateCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RateCode entity = _RateCodeRepository.GetById(model.RateCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _RateCodeService.CheckIfExists(entity);
                if (!_RateCodeService.BusinessState.IsValid)
                {
                    _RateCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _RateCodeRepository.Update(entity);
                if (!_RateCodeRepository.DbState.IsValid)
                {
                    _RateCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Rate Code Updated : {0}", entity.RateCodeID);
                return Ok(entity.RateCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Rate Code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                RateCode entity = _RateCodeRepository.GetById(id);
                _RateCodeRepository.Delete(entity);
                if (!_RateCodeRepository.DbState.IsValid)
                {
                    _RateCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing Rate Code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
