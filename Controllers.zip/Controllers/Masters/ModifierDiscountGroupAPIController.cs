using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Masters;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/ModifierDiscountGroup")]
    public class ModifierDiscountGroupAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ModifierDiscountGroupAPIController> _logger;
        private IModifierDiscountGroupRepository _modifierDiscountGroupRepository;        
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public ModifierDiscountGroupAPIController(IModifierDiscountGroupRepository modifierDiscountGroupRepository, ILogger<ModifierDiscountGroupAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _modifierDiscountGroupRepository = modifierDiscountGroupRepository;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Route("GetModifierDiscountGroupKeyVal")]
        public IActionResult GetModifierDiscountGroupKeyVal()
        {
            var res = _modifierDiscountGroupRepository.GetModifierDiscountGroupKeyVal();
            return Ok(res);
        }       
    }
}
