using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Data.Repositories.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Masters
{
    [Produces("application/json")]
    [Route("api/NDCCode")]
    public class NDCCodeAPIController : BaseAPIController
    {
        #region Variables     

        private INDCCodeRepository _NDCCodeRepository;
        private INDCCodeService _NDCCodeService;
        private ILogger<NDCCodeAPIController> _logger;
        private IMapper _mapper;

        #endregion

        #region Constructor

        public NDCCodeAPIController(INDCCodeRepository nDCCodeRepository, INDCCodeService nDCCodeService, ILogger<NDCCodeAPIController> logger, IMapper mapper)
        {
            _NDCCodeRepository = nDCCodeRepository;
            _NDCCodeService = nDCCodeService;
            _logger = logger;
            _mapper = mapper;
        }

        #endregion

        [HttpGet("{id}", Name = "NDCCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewNDCCodePolicy)]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _NDCCodeRepository.GetById(Id);
                if (result == null) return NotFound($"NDC Code {Id} was not found");
                return Ok(_mapper.Map<NDCCodeModel>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddNDCCodePolicy)]
        public IActionResult Post([FromBody]NDCCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var NDCCodeEntity = _mapper.Map<NDCCode>(model);
                NDCCodeEntity.CreatedDate = base.TodaysDate;
                NDCCodeEntity.CreatedBy = base.UserName;
                NDCCodeEntity.RecordStatus = (int)RecordStatus.Active;
                NDCCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _NDCCodeService.CheckIfExists(NDCCodeEntity);

                if (!_NDCCodeService.BusinessState.IsValid)
                {
                    _NDCCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _NDCCodeRepository.Add(NDCCodeEntity);
                var newUri = Url.Link("NDCCodeGet", new { id = NDCCodeEntity.NDCCodeID });
                _logger.LogInformation("New NDC Code Created ");
                return Created(newUri, _mapper.Map<NDCCodeModel>(NDCCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving NDC Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateNDCCodePolicy)]
        public IActionResult Put([FromBody] NDCCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                NDCCode entity = _NDCCodeRepository.GetById(model.NDCCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _NDCCodeService.CheckIfExists(entity);
                if (!_NDCCodeService.BusinessState.IsValid)
                {
                    _NDCCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _NDCCodeRepository.Update(entity);
                if (!_NDCCodeRepository.DbState.IsValid)
                {
                    _NDCCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("NDC Code updated : {0}", entity.NDCCodeID);

                if (model.TermDate != null && model.HomeGrown != "Y")
                {
                    var homeGrownList = _NDCCodeRepository.GetByPredicate(x => x.HomeGrown == "Y" && x.MappedCode == entity.Code);
                    if (homeGrownList.Count() > 0)
                    {
                        foreach (var ndcCodeObj in homeGrownList)
                        {
                            ndcCodeObj.TermDate = entity.TermDate;
                            ndcCodeObj.UpdatedDate = base.TodaysDate;
                            ndcCodeObj.UpdatedBy = base.UserName;
                            ndcCodeObj.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            ndcCodeObj.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _NDCCodeService.CheckIfExists(ndcCodeObj);
                            if (!_NDCCodeService.BusinessState.IsValid)
                            {
                                _NDCCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _NDCCodeRepository.Update(ndcCodeObj);
                            if (!_NDCCodeRepository.DbState.IsValid)
                            {
                                _NDCCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("NDC Code updated : {0}", entity.NDCCodeID);
                        }
                    }
                }
                return Ok(entity.NDCCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating NDC Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


    }
}
