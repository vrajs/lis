using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Common;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/AnesthesiaRegionRate")]
    public class AnesthesiaRegionRateAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<AnesthesiaRegionRateAPIController> _logger;
        private readonly IAnesthesiaRegionRateRepository _anesthesiaRegionRateRepository;
        private readonly IAnesthesiaRegionRateService _anesthesiaRegionRateService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public AnesthesiaRegionRateAPIController(IAnesthesiaRegionRateRepository anesthesiaRegionRateRepository, IAnesthesiaRegionRateService anesthesiaRegionRateService, ILogger<AnesthesiaRegionRateAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _anesthesiaRegionRateRepository = anesthesiaRegionRateRepository;
            _anesthesiaRegionRateService = anesthesiaRegionRateService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewAnesthesiaRegionRatesPolicy)]
        public IActionResult Get()
        {
            try
            {
                var anesthesiaRegionRates = _anesthesiaRegionRateRepository.GetByPredicate(null).ToList();
                return Ok(anesthesiaRegionRates);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Anesthesia Region Rate list: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "AnesthesiaRegionRateGet")]
        [Authorize(Policy = Authorization.Policies.ViewAnesthesiaRegionRatesPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var anesthesiaRegionRate = _anesthesiaRegionRateRepository.GetById(id);
                if (anesthesiaRegionRate == null) return NotFound($"AnesthesiaRegionRate with {id} was not found");
                return Ok(_mapper.Map<AnesthesiaRegionRateModel>(anesthesiaRegionRate));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageAnesthesiaRegionRatesPolicy)]
        public IActionResult Post([FromBody] AnesthesiaRegionRateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AnesthesiaRegionRate entity = _mapper.Map<AnesthesiaRegionRate>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _anesthesiaRegionRateService.CheckIfExists(entity);
                if (!_anesthesiaRegionRateService.BusinessState.IsValid)
                {
                    _anesthesiaRegionRateService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _anesthesiaRegionRateRepository.Add(entity);

                if (!_anesthesiaRegionRateRepository.DbState.IsValid)
                {
                    _anesthesiaRegionRateRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("AnesthesiaRegionRateGet", new { id = entity.AnesthesiaRegionRateID });
                _logger.LogInformation("New anesthesia region rate created");
                return Created(newUri, _mapper.Map<AnesthesiaRegionRateModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving anesthesia region rate : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageAnesthesiaRegionRatesPolicy)]
        public IActionResult Put([FromBody] AnesthesiaRegionRateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AnesthesiaRegionRate entity = _anesthesiaRegionRateRepository.GetById(model.AnesthesiaRegionRateID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _anesthesiaRegionRateService.CheckIfExists(entity);
                if (!_anesthesiaRegionRateService.BusinessState.IsValid)
                {
                    _anesthesiaRegionRateService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _anesthesiaRegionRateRepository.Update(entity);
                if (!_anesthesiaRegionRateRepository.DbState.IsValid)
                {
                    _anesthesiaRegionRateRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Anesthesia region rate updated : {0}", entity.AnesthesiaRegionRateID);
                return Ok(entity.AnesthesiaRegionRateID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating anesthesia region rate : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteAnesthesiaRegionRatesPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                AnesthesiaRegionRate entity = _anesthesiaRegionRateRepository.GetById(id);
                _anesthesiaRegionRateRepository.Delete(entity);
                if (!_anesthesiaRegionRateRepository.DbState.IsValid)
                {
                    _anesthesiaRegionRateRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing anesthesia region rate : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
