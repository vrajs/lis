using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class FeeScheduleDetailODController : BaseODController
    {
        #region Variables        
        private IFeeScheduleLimitRepository _feeScheduleLimitRepository;
        private IFeeScheduleHeaderRepository _feeScheduleHeaderRepository;
        private IFeeScheduleDetailRepository _feeScheduleDetailRepository;
        #endregion

        #region Ctor        
        public FeeScheduleDetailODController(IFeeScheduleLimitRepository feeScheduleLimitRepository, IFeeScheduleHeaderRepository feeScheduleHeaderRepository, IFeeScheduleDetailRepository feeScheduleDetailRepository)
        {
            _feeScheduleLimitRepository = feeScheduleLimitRepository;
            _feeScheduleHeaderRepository = feeScheduleHeaderRepository;
            _feeScheduleDetailRepository = feeScheduleDetailRepository;
        }
        #endregion

        //[HttpGet]      
        //[Route("FeeSchedules")]       
        //public IActionResult GetFeeSchedules(ODataQueryOptions<FeeScheduleModel> options)
        //{
        //    ODataQuerySettings settings = new ODataQuerySettings()
        //    {
        //        PageSize = options.Top.Value,
        //        HandleNullPropagation = HandleNullPropagationOption.False;
        //    };

        //    IQueryable feeScheduleQuery = options.ApplyTo(_feeScheduleLimitRepository.FeeSchedules, settings);
        //    return Ok(feeScheduleQuery);
        //}


        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("FeeScheduleLimits")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetFeeScheduleLimits()
        {
            var feeScheduleLimitQuery = _feeScheduleLimitRepository.FeeScheduleLimits;
            return Ok(feeScheduleLimitQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("FeeScheduleHeaders")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetFeeScheduleHeaders()
        {
            var feeScheduleHeaderQuery = _feeScheduleHeaderRepository.GetFeeScheduleHeaders();
            return Ok(feeScheduleHeaderQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("FeeScheduleDetails")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetFeeScheduleDetails(int FeeScheduleHeaderID)
        {
            var feeScheduleDetailQuery = _feeScheduleDetailRepository.GetFeeScheduleDetails(FeeScheduleHeaderID);
            return Ok(feeScheduleDetailQuery);
        }

    }
}
