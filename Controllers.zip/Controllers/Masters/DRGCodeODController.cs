using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class DRGCodeODController : BaseODController
    {
        #region Variables     

        private IDRGCodeRepository _DRGCodeRepository;

        #endregion

        #region Constructor

        public DRGCodeODController(IDRGCodeRepository dRGCodeRepository)
        {
            _DRGCodeRepository = dRGCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("DRGCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetDRGCodes()
        {
            var DRGCodeQuery = _DRGCodeRepository.GetDRGCodes();
            return Ok(DRGCodeQuery);
        }
    }
}
