using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/Location")]
    public class LocationAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<LocationAPIController> _logger;
        private ILocationRepository _LocationRepository;
        private readonly ILocationService _LocationService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public LocationAPIController(ILocationRepository LocationRepository, ILocationService LocationService, ILogger<LocationAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _LocationRepository = LocationRepository;
            _LocationService = LocationService;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/GetKeyVal
        [HttpGet("GetKeyVal")]
        public IActionResult GetKeyVal()
        {
            try
            {
                List<KeyVal<int, string>> locationResult = _LocationRepository.GetKeyVal();
                return Ok(locationResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting  Locations: {ex}");
                return BadRequest(ex.Message);
            }
        }


        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var locationResult = _LocationRepository.GetLocation(null).ToList();
                return Ok(locationResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting all Locations: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "LocationGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var location = _LocationRepository.GetLocation(id).FirstOrDefault();
                if (location == null) return NotFound($"Location {id} was not found");
                return Ok(location);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting specific {id} Location: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]LocationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var location = _mapper.Map<Location>(model);
                location.CreatedDate = base.TodaysDate;
                location.CreatedBy = base.UserName;
                location.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, location.EffectiveDate, location.TermDate);
                location.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, location.EffectiveDate, location.TermDate).ToString();

                _LocationRepository.Add(location);
                if (!_LocationRepository.DbState.IsValid)
                {
                    _LocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("LocationGet", new { id = location.LocationID });
                _logger.LogInformation("New Location Created ");
                return Created(newUri, _mapper.Map<LocationModel>(location));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Location : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut()]
        public IActionResult Put([FromBody]LocationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var entity = _LocationRepository.GetById(model.LocationID);
                if (entity == null) return NotFound($"Could not find Location with LocationID of {model.LocationID}");
                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
                _LocationRepository.Update(entity);
                if (!_LocationRepository.DbState.IsValid)
                {
                    _LocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Location updated : {0}", entity.LocationID);
                return Ok(model.LocationID);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Location :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _LocationService.CheckIfAssociatedWithEntity(id);
                if (!_LocationService.BusinessState.IsValid)
                {
                    _LocationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _LocationRepository.DeleteById(id);
                if (!_LocationRepository.DbState.IsValid)
                {
                    _LocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Location : {ex}");
                return BadRequest(ex.Message);
            }
        }

        // Term api/values/5
        [HttpPut]
        [Route("Terminate")]
        public IActionResult Terminate([FromBody]TerminateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var entity = _LocationRepository.GetById(model.Id);
                if (entity == null) return NotFound($"Could not find Location with LocationID of {model.Id}");
                _mapper.Map(model, entity);
                entity.TermDate = model.TermDate;
                entity.RecordStatus = (int)RecordStatus.Termed;
                entity.RecordStatusChangeComment = model.TermReason;
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                _LocationRepository.Update(entity);
                if (!_LocationRepository.DbState.IsValid)
                {
                    _LocationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while terminating Location: {ex}");
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
