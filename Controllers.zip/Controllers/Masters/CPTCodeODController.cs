using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class CPTCodeODController : BaseODController
    {
        #region Variables     
        
        private ICPTCodeRepository _CPTCodeRepository;

        #endregion

        #region Constructor

        public CPTCodeODController(ICPTCodeRepository cPTCodeRepository)
        {
            _CPTCodeRepository = cPTCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("CPTCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCPTCodes(int? ClinicalCodeTypeID)
        {
            var cPTCodeQuery = _CPTCodeRepository.GetCPTCodes(ClinicalCodeTypeID ?? 0);
            return Ok(cPTCodeQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("CPTAndHCPCCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCPTAndHCPCCodes(int? ClinicalCodeTypeID)
        {
            var cPTCodeQuery = _CPTCodeRepository.GetCPTAndHCPCCodes(ClinicalCodeTypeID ?? 0);
            return Ok(cPTCodeQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetAllCPTCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetAllCPTCodes(int? ClinicalCodeTypeID)
        {
            var cptCodeQuery = _CPTCodeRepository.GetAllCPTCodes(ClinicalCodeTypeID??0);
            return Ok(cptCodeQuery);
        }
    }
}
