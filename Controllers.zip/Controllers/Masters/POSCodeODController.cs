using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class POSCodeODController : BaseODController
    {
        #region Variables     

        private IPOSCodeRepository _POSCodeRepository;

        #endregion

        #region Constructor

        public POSCodeODController(IPOSCodeRepository pOSCodeRepository)
        {
            _POSCodeRepository = pOSCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("POSCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetPOSCodes()
        {
            var POSCodeQuery = _POSCodeRepository.GetPOSCodes();
            return Ok(POSCodeQuery);
        }
    }
}
