using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class HCPCCodeODController : BaseODController
    {
        #region Variables     
        
        private ICPTCodeRepository _CPTCodeRepository;

        #endregion

        #region Constructor

        public HCPCCodeODController(ICPTCodeRepository cPTCodeRepository)
        {
            _CPTCodeRepository = cPTCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("HCPCCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetHCPCCodes()
        {
            var hCPCCodeQuery = _CPTCodeRepository.GetHCPCCodes();
            return Ok(hCPCCodeQuery);
        }
    }
}
