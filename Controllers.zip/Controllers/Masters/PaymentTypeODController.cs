using System.Linq;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class PaymentTypeODController : BaseODController
    {
        #region Variables     

        private IPaymentTypeRepository _paymentTypeRepository;

        #endregion

        #region Constructor

        public PaymentTypeODController(IPaymentTypeRepository paymentTypeRepository)
        {
            _paymentTypeRepository = paymentTypeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("PaymentTypesForManualCheck")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult PaymentTypesForManualCheck()
        {
            var PaymentTypeQuery = _paymentTypeRepository.GetByPredicate(x => x.Code == "M" || x.Code == "I" || x.Code == "PA");
            return Ok(PaymentTypeQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("PaymentTypeList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult PaymentTypeList()
        {
            var PaymentTypeQuery = _paymentTypeRepository.GetByPredicate(x => x.Code != "R" && x.Code != "V").ToList();
            return Ok(PaymentTypeQuery);
        }
    }
}
