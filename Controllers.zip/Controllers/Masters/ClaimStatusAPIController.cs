using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Masters;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Common.Utility;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/ClaimStatus")]
    public class ClaimStatusAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundStatusAPIController> _logger;
        private IClaimStatusRepository _ClaimStatusRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public ClaimStatusAPIController(ILogger<RefundStatusAPIController> logger, IClaimStatusRepository claimStatusRepository, IMapper mapper)
        {
            _logger = logger;
            _ClaimStatusRepository = claimStatusRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        [HttpGet("GetAllStatus")]
        public IActionResult GetAll()
        {
            var refundStatus = _ClaimStatusRepository.GetAllStatus();
            return Json(refundStatus);
        }
        #endregion
    }
}
