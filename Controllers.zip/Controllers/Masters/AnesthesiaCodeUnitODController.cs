using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class AnesthesiaCodeUnitODController : BaseODController
    {
        #region Variables  
        private IAnesthesiaCodeUnitRepository _anesthesiaCodeUnitRepository;
        #endregion

        #region Constructor
        public AnesthesiaCodeUnitODController(IAnesthesiaCodeUnitRepository anesthesiaCodeUnitRepository)
        {
            _anesthesiaCodeUnitRepository = anesthesiaCodeUnitRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("AnesthesiaCodeUnits")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewAnesthesiaCodeUnitPolicy)]
        public IActionResult GetAnesthesiaCodeUnits()
        {
            var anesthesiaCodeUnitQuery = _anesthesiaCodeUnitRepository.GetAnesthesiaCodeUnits();
            return Ok(anesthesiaCodeUnitQuery);
        }
    }
}
