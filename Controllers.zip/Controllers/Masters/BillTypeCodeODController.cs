using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class BillTypeCodeODController : BaseODController
    {
        #region Variables  
        private IBillTypeCodeRepository _BillTypeCodeRepository;
        #endregion

        #region Constructor

        public BillTypeCodeODController(IBillTypeCodeRepository billTypeCodeRepository)
        {
            _BillTypeCodeRepository = billTypeCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BillTypeCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetBillTypeCodes(int? ClinicalCodeTypeID)
        {
            var iCDCodeQuery = _BillTypeCodeRepository.GetBillTypeCodes(ClinicalCodeTypeID ?? 0);
            return Ok(iCDCodeQuery);
        }
    }
}
