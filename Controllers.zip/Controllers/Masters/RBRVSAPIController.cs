using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using AutoMapper;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Common;
using System.Net;
using Kwicle.Business.Interfaces.Masters;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/RBRVS")]
    public class RBRVSAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RBRVSAPIController> _logger;
        private readonly IRBRVSRepository _rbrvsRepository;
        private readonly IRBRVSService _rbrvsService;
        private readonly ICommonClinicalCodeService _commonClinicalCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public RBRVSAPIController(IRBRVSRepository rbrvsRepository, ILogger<RBRVSAPIController> logger, IMapper mapper, ICommonClinicalCodeService commonClinicalCodeService, IRBRVSService rbrvsService)
        {
            _logger = logger;
            _rbrvsRepository = rbrvsRepository;
            _rbrvsService = rbrvsService;
            _mapper = mapper;
            _commonClinicalCodeService = commonClinicalCodeService;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewRBRVSPolicy)]
        public IActionResult Get()
        {
            try
            {
                var rbrvss = _rbrvsRepository.GetByPredicate(null).ToList();
                return Ok(rbrvss);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting rbrvs list: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RBRVSGet")]
        [Authorize(Policy = Authorization.Policies.ViewRBRVSPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var rbrvs = _rbrvsRepository.GetById(id);
                if (rbrvs == null) return NotFound($"RBRVS with {id} was not found");
                return Ok(_mapper.Map<RBRVSModel>(rbrvs));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddRBRVSPolicy)]
        public IActionResult Post([FromBody] RBRVSModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RBRVS entity = _mapper.Map<RBRVS>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _commonClinicalCodeService.IsCommonClinicalCodeEffective(model.ClinicalCodeTypeIDs, entity.HCPCS, entity.EffectiveDate, entity.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _rbrvsService.CheckIfExists(entity);
                if (!_rbrvsService.BusinessState.IsValid)
                {
                    _rbrvsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _rbrvsRepository.Add(entity);

                if (!_rbrvsRepository.DbState.IsValid)
                {
                    _rbrvsRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("RBRVSGet", new { id = entity.RBRVSID });
                _logger.LogInformation("New rbrvs created");
                return Created(newUri, _mapper.Map<RBRVSModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving rbrvs : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateRBRVSPolicy)]
        public IActionResult Put([FromBody] RBRVSModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RBRVS entity = _rbrvsRepository.GetById(model.RBRVSID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _commonClinicalCodeService.IsCommonClinicalCodeEffective(model.ClinicalCodeTypeIDs, entity.HCPCS, entity.EffectiveDate, entity.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _rbrvsService.CheckIfExists(entity);
                if (!_rbrvsService.BusinessState.IsValid)
                {
                    _rbrvsService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _rbrvsRepository.Update(entity);
                if (!_rbrvsRepository.DbState.IsValid)
                {
                    _rbrvsRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("RBRVS updated : {0}", entity.RBRVSID);
                return Ok(entity.RBRVSID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating rbrvs : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteRBRVSPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                RBRVS entity = _rbrvsRepository.GetById(id);
                _rbrvsRepository.Delete(entity);
                if (!_rbrvsRepository.DbState.IsValid)
                {
                    _rbrvsRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing rbrvs : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
