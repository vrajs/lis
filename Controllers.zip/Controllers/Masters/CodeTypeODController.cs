using System.Linq;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class CodeTypeODController : BaseODController
    {
        private ICodeTypeRepository  _codeTypeRepository;

        public CodeTypeODController(ICodeTypeRepository codeTypeRepository)
        {
            _codeTypeRepository = codeTypeRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetCodeTypes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCodeTypes()
        {
            var query = _codeTypeRepository.GetAllCodeTypes();
            return Ok(query);
        }
    }
}
