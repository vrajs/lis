using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Masters;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Common;
using System.Net;
using Kwicle.Business.Interfaces.Common;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/AnesthesiaCodeUnit")]
    public class AnesthesiaCodeUnitAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<AnesthesiaCodeUnitAPIController> _logger;
        private readonly IAnesthesiaCodeUnitRepository _anesthesiaCodeUnitRepository;
        private readonly IAnesthesiaCodeUnitService _anesthesiaCodeUnitService;
        private readonly ICommonClinicalCodeService _commonClinicalCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public AnesthesiaCodeUnitAPIController(IAnesthesiaCodeUnitRepository anesthesiaCodeUnitRepository, IAnesthesiaCodeUnitService anesthesiaCodeUnitService, ILogger<AnesthesiaCodeUnitAPIController> logger, ICommonClinicalCodeService commonClinicalCodeService, IMapper mapper)
        {
            _logger = logger;
            _anesthesiaCodeUnitRepository = anesthesiaCodeUnitRepository;
            _anesthesiaCodeUnitService = anesthesiaCodeUnitService;
            _commonClinicalCodeService = commonClinicalCodeService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewAnesthesiaCodeUnitPolicy)]
        public IActionResult Get()
        {
            try
            {
                var anesthesiaCodeUnits = _anesthesiaCodeUnitRepository.GetByPredicate(null).ToList();
                return Ok(anesthesiaCodeUnits);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting anesthesia code unit list: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "AnesthesiaCodeUnitGet")]
        [Authorize(Policy = Authorization.Policies.ViewAnesthesiaCodeUnitPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var anesthesiaCodeUnit = _anesthesiaCodeUnitRepository.GetById(id);
                if (anesthesiaCodeUnit == null) return NotFound($"AnesthesiaCodeUnit with {id} was not found");
                return Ok(_mapper.Map<AnesthesiaCodeUnitModel>(anesthesiaCodeUnit));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageAnesthesiaCodeUnitPolicy)]
        public IActionResult Post([FromBody] AnesthesiaCodeUnitModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AnesthesiaCodeUnit entity = _mapper.Map<AnesthesiaCodeUnit>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _commonClinicalCodeService.IsCommonClinicalCodeEffective(model.ClinicalCodeTypeIDs, entity.CPTCode, entity.EffectiveDate, entity.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _anesthesiaCodeUnitService.CheckIfExists(entity);
                if (!_anesthesiaCodeUnitService.BusinessState.IsValid)
                {
                    _anesthesiaCodeUnitService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _anesthesiaCodeUnitRepository.Add(entity);

                if (!_anesthesiaCodeUnitRepository.DbState.IsValid)
                {
                    _anesthesiaCodeUnitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("AnesthesiaCodeUnitGet", new { id = entity.AnesthesiaCodeUnitID });
                _logger.LogInformation("New anesthesia code unit created");
                return Created(newUri, _mapper.Map<AnesthesiaCodeUnitModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving anesthesia code unit : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageAnesthesiaCodeUnitPolicy)]
        public IActionResult Put([FromBody] AnesthesiaCodeUnitModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AnesthesiaCodeUnit entity = _anesthesiaCodeUnitRepository.GetById(model.AnesthesiaCodeUnitID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _commonClinicalCodeService.IsCommonClinicalCodeEffective(model.ClinicalCodeTypeIDs, entity.CPTCode, entity.EffectiveDate, entity.TermDate);
                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _anesthesiaCodeUnitService.CheckIfExists(entity);
                if (!_anesthesiaCodeUnitService.BusinessState.IsValid)
                {
                    _anesthesiaCodeUnitService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _anesthesiaCodeUnitRepository.Update(entity);
                if (!_anesthesiaCodeUnitRepository.DbState.IsValid)
                {
                    _anesthesiaCodeUnitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Anesthesia code unit updated : {0}", entity.AnesthesiaCodeUnitID);
                return Ok(entity.AnesthesiaCodeUnitID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating anesthesia code unit : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteAnesthesiaCodeUnitPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                AnesthesiaCodeUnit entity = _anesthesiaCodeUnitRepository.GetById(id);
                _anesthesiaCodeUnitRepository.Delete(entity);
                if (!_anesthesiaCodeUnitRepository.DbState.IsValid)
                {
                    _anesthesiaCodeUnitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing anesthesia code unit : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
