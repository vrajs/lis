using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class HomeGrownCodeODController : BaseODController
    {
        private IHomeGrownCodeRepository _homeGrownCodeRepository;        

        public HomeGrownCodeODController( IHomeGrownCodeRepository homeGrownCodeRepository)
        {            
            _homeGrownCodeRepository = homeGrownCodeRepository;            
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("HomeGrownCodeList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetHomeGrownCodes(int ClinicalCodeTypeID)
        {
            var query = _homeGrownCodeRepository.GetHomeGrownCodes(ClinicalCodeTypeID);            
            return Ok(query);
        }        
    }
}
