using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/VisitCode")]
    public class VisitCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<VisitCodeAPIController> _logger;
        private IVisitCodeRepository _VisitCodeRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public VisitCodeAPIController(IVisitCodeRepository VisitCodeRepository, ILogger<VisitCodeAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _VisitCodeRepository = VisitCodeRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var visitCodeRes = _VisitCodeRepository.GetAllVisitCode().ToList();
            return Ok(visitCodeRes);
        }


        // GET api/values/5
        //get by id generic with only table fields
        [HttpGet("{id}", Name = "VisitCodeGet")]
        public IActionResult Get(int id)
        {
            var visitCode = _VisitCodeRepository.GetById(id);
            if (visitCode == null) return NotFound($"Visit Code {id} was not found");
            return Ok(_mapper.Map<VisitCodeModel>(visitCode));
        }

        // GET api/values/5
        //get by id generic with only table fields
        [HttpGet("GetByIdForView/{id}")]
        public IActionResult GetByIdForView(int id)
        {
            var visitCode = _VisitCodeRepository.GetAllVisitCode().Where(t => t.VisitCodeID == id).SingleOrDefault();
            if (visitCode == null) return NotFound($"Visit Code {id} was not found");
            return Ok(_mapper.Map<VisitCodeModel>(visitCode));
        }


        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]VisitCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var entity = _mapper.Map<VisitCode>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _VisitCodeRepository.Add(entity);
                if (!_VisitCodeRepository.DbState.IsValid)
                {
                    _VisitCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("VisitCodeGet", new { id = entity.VisitCodeID });
                _logger.LogInformation("New Visit Code Created ");
                return Created(newUri, _mapper.Map<VisitCodeModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving visit code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]VisitCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var entity = _VisitCodeRepository.GetById(model.VisitCodeID);
                if (entity == null) return NotFound($"Could not find a visit code with an visitCodeID  of {model.VisitCodeID}");

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _VisitCodeRepository.Update(entity);
                if (!_VisitCodeRepository.DbState.IsValid)
                {
                    _VisitCodeRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                _logger.LogInformation("Visit Code updated with id {0}", model.VisitCodeID);
                return Ok(model.VisitCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating visit code: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            VisitCode entity = _VisitCodeRepository.GetById(id);
            entity.RecordStatus = (int)RecordStatus.Deleted;
            entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
            _VisitCodeRepository.Update(entity);

            if (!_VisitCodeRepository.DbState.IsValid)
            {
                _VisitCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(id);
        }
        #endregion
    }
}
