using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class ICDCodeODController : BaseODController
    {
        #region Variables     

        private IICDCodeRepository _ICDCodeRepository;

        #endregion

        #region Constructor

        public ICDCodeODController(IICDCodeRepository iCDCodeRepository)
        {
            _ICDCodeRepository = iCDCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ICDCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetICDCodes(int? ClinicalCodeTypeID)
        {

            var iCDCodeQuery = _ICDCodeRepository.GetICDCodes(ClinicalCodeTypeID ?? 0);
            return Ok(iCDCodeQuery);
        }
    }
}
