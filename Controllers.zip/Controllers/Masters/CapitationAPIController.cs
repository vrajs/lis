using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/CapitationHeader")]
    public class CapitationHeaderController : BaseAPIController
    {
        #region Variables
        private ILogger<CapitationHeaderController> _logger;
        private ICapitationHeaderRepository _CapitationHeaderRepository;
        //private ICapitationHeaderService _CapitationHeaderService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        //, ICapitationHeaderService capitationHeaderService
        public CapitationHeaderController(ICapitationHeaderRepository capitationHeaderRepository, ILogger<CapitationHeaderController> logger, IMapper mapper)
        {
            _logger = logger;
            _CapitationHeaderRepository = capitationHeaderRepository;
            _mapper = mapper;
            //_CapitationHeaderService = capitationHeaderService;
        }
        #endregion

        #region API Methods

        [HttpGet("GetCapitationKeyVal")]
        public IActionResult GetCapitationKeyVal()
        {
            var res = _CapitationHeaderRepository.GetCapitationKeyVal();
            return Ok(res);
        }


        // GET api/values/5
        [HttpGet("{id}", Name = "CapitationHeaderGet")]
        [Authorize(Policy = Authorization.Policies.ViewCapitationPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var capitationHeader = _CapitationHeaderRepository.GetById(id);
                if (capitationHeader == null) return NotFound($"CapitationHeader {id} was not found");
                return Ok(capitationHeader);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while creating Capitation {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageCapitationPolicy)]
        public IActionResult Post([FromBody]CapitationHeader capitationHeader)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                capitationHeader.CreatedDate = base.TodaysDate;
                capitationHeader.CreatedBy = base.UserName;
                capitationHeader.TermDate = capitationHeader.TermDate.ToTermDate();
                capitationHeader.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, capitationHeader.EffectiveDate, capitationHeader.TermDate);
                capitationHeader.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, capitationHeader.EffectiveDate, capitationHeader.TermDate).ToString();

                _CapitationHeaderRepository.Add(capitationHeader);
                if (!_CapitationHeaderRepository.DbState.IsValid)
                {
                    _CapitationHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("CapitationHeaderGet", new { id = capitationHeader.CapitationHeaderId });
                _logger.LogInformation("New Capitation Created");
                return Created(newUri, capitationHeader);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Capitation Header : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageCapitationPolicy)]
        public IActionResult Put([FromBody]CapitationHeader capitationHeader)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                capitationHeader.UpdatedBy = base.UserName;
                capitationHeader.UpdatedDate = base.TodaysDate;
                capitationHeader.TermDate = capitationHeader.TermDate.ToTermDate();
                capitationHeader.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, capitationHeader.EffectiveDate, capitationHeader.TermDate);
                capitationHeader.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, capitationHeader.EffectiveDate, capitationHeader.TermDate).ToString();

                _CapitationHeaderRepository.Update(capitationHeader);
                if (!_CapitationHeaderRepository.DbState.IsValid)
                {
                    _CapitationHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(capitationHeader.CapitationHeaderId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Capitation Header: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteCapitationPolicy)]
        public IActionResult Delete(int id)
        {
            _CapitationHeaderRepository.DeleteById(id);
            if (!_CapitationHeaderRepository.DbState.IsValid)
            {
                _CapitationHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(id);
        }

        [HttpDelete]
        [Authorize(Policy = Authorization.Policies.DeleteCapitationPolicy)]
        public IActionResult DeleteByReason(DeleteModel deleteModel)
        {
            _CapitationHeaderRepository.DeleteByReason(deleteModel);
            if (!_CapitationHeaderRepository.DbState.IsValid)
            {
                _CapitationHeaderRepository.DbState.ErrorMessages.ForEach((businessState) =>
                {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(deleteModel);
        }
        #endregion  
    }
}
