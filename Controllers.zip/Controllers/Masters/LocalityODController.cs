using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class LocalityODController : BaseODController
    {
        #region Variables  
        private ILocalityRepository _localityRepository;
        #endregion

        #region Constructor
        public LocalityODController(ILocalityRepository localityRepository)
        {
            _localityRepository = localityRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Localities")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetLocalityList()
        {
            var localityQuery = _localityRepository.GetLocalityList();
            return Ok(localityQuery);
        }
    }
}
