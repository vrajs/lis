using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class ModifierDiscountODController : BaseODController
    {
        #region Variables  
        private IModifierDiscountRepository _modifierDiscountRepository;
        #endregion

        #region Constructor

        public ModifierDiscountODController(IModifierDiscountRepository modifierDiscountRepository)
        {
            _modifierDiscountRepository = modifierDiscountRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("ModifierDiscounts")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewModifierDiscountGroupPolicy)]
        public IActionResult GetModifierDiscounts()
        {
            var modifierDiscountQuery = _modifierDiscountRepository.GetModifierDiscounts();
            return Ok(modifierDiscountQuery);
        }
    }
}
