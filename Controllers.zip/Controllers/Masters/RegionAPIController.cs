using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Common;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/Region")]
    public class RegionAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RegionAPIController> _logger;
        private readonly IRegionRepository _regionRepository;
        private readonly IRegionService _regionService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public RegionAPIController(IRegionRepository regionRepository, IRegionService regionService, ILogger<RegionAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _regionRepository = regionRepository;
            _regionService = regionService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewRegionsPolicy)]
        public IActionResult Get()
        {
            try
            {
                var regions = _regionRepository.GetByPredicate(null).ToList();
                return Ok(regions);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting regions: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RegionGet")]
        [Authorize(Policy = Authorization.Policies.ViewRegionsPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var region = _regionRepository.GetById(id);
                if (region == null) return NotFound($"Region with {id} was not found");
                return Ok(_mapper.Map<RegionModel>(region));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageRegionsPolicy)]
        public IActionResult Post([FromBody] RegionModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                Region entity = _mapper.Map<Region>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _regionService.CheckIfExists(entity);
                if (!_regionService.BusinessState.IsValid)
                {
                    _regionService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _regionRepository.Add(entity);

                if (!_regionRepository.DbState.IsValid)
                {
                    _regionRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("RegionGet", new { id = entity.RegionID });
                _logger.LogInformation("New region created");
                return Created(newUri, _mapper.Map<RegionModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving region : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageRegionsPolicy)]
        public IActionResult Put([FromBody] RegionModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                Region entity = _regionRepository.GetById(model.RegionID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _regionService.CheckIfExists(entity);
                if (!_regionService.BusinessState.IsValid)
                {
                    _regionService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _regionRepository.Update(entity);
                if (!_regionRepository.DbState.IsValid)
                {
                    _regionRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Region updated : {0}", entity.RegionID);
                return Ok(entity.RegionID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating region : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteRegionsPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                Region entity = _regionRepository.GetById(id);
                _regionRepository.Delete(entity);
                if (!_regionRepository.DbState.IsValid)
                {
                    _regionRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing region : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
