using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class RegionZipCodeODController : BaseODController
    {
        #region Variables  
        private IRegionZipCodeRepository _regionZipCodeRepository;
        #endregion

        #region Constructor

        public RegionZipCodeODController(IRegionZipCodeRepository regionZipCodeRepository)
        {
            _regionZipCodeRepository = regionZipCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RegionZipCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRegionZipCodes(int? ZipCodeID)
        {
            var regionQuery = _regionZipCodeRepository.GetRegionZipCodes(ZipCodeID.HasValue ? ZipCodeID.Value : 0);
            return Ok(regionQuery);
        }
    }
}
