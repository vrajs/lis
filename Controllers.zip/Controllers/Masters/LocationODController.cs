using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class LocationODController : BaseODController
    {
        #region Variables        
        private ILocationRepository _LocationRepository;
        #endregion

        #region Ctor        
        public LocationODController(ILocationRepository LocationRepository)
        {
            _LocationRepository = LocationRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Locations")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetLocations()
        {
            var locationQuery = _LocationRepository.GetLocation(null);
            return Ok(locationQuery);
        }
    }
}
