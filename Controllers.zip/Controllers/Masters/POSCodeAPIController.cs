using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using AutoMapper;
using Microsoft.Extensions.Logging;
using System.Net;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.Entities;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/POSCode")]   
    public class POSCodeAPIController : BaseAPIController
    {
        #region Variables     

        private IPOSCodeRepository _POSCodeRepository;
        private IPOSCodeService _POSCodeService;
        private ILogger<POSCodeAPIController> _logger;
        private IMapper _mapper;           

        #endregion

        #region Constructor

        public POSCodeAPIController(IPOSCodeRepository pOSCodeRepository, IPOSCodeService pOSCodeService, ILogger<POSCodeAPIController> logger, IMapper mapper)
        {
            _POSCodeRepository = pOSCodeRepository;
            _POSCodeService = pOSCodeService;
            _logger = logger;
            _mapper = mapper;
        }

        #endregion

        [HttpGet("")]
        [Authorize(Policy = Authorization.Policies.ViewPlaceOfServicePolicy)]
        public IActionResult Get()
        {
            var feeScheduleRes = _POSCodeRepository.GetPOSCodes();
            return Json(feeScheduleRes.ToList());
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "POSCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewPlaceOfServicePolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var POSCode = _POSCodeRepository.GetPOSCodeByID(id);
                if (POSCode == null) return NotFound($"POS Code {id} was not found");
                return Ok(_mapper.Map<POSCodeModel>(POSCode));
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddPlaceOfServicePolicy)]
        public IActionResult Post([FromBody]POSCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var POSCodeEntity = _mapper.Map<POSCode>(model);
                POSCodeEntity.CreatedDate = base.TodaysDate;
                POSCodeEntity.CreatedBy = base.UserName;
                POSCodeEntity.RecordStatus = (int)RecordStatus.Active;
                POSCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _POSCodeService.CheckIfExists(POSCodeEntity);

                if (!_POSCodeService.BusinessState.IsValid)
                {
                    _POSCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _POSCodeRepository.Add(POSCodeEntity);
                var newUri = Url.Link("POSCodeGet", new { id = POSCodeEntity.POSCodeID });
                _logger.LogInformation("New POS Code Created ");
                return Created(newUri, _mapper.Map<POSCodeModel>(POSCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving POSCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdatePlaceOfServicePolicy)]
        public IActionResult Put([FromBody] POSCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                POSCode entity = _POSCodeRepository.GetById(model.POSCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _POSCodeService.CheckIfExists(entity);
                if (!_POSCodeService.BusinessState.IsValid)
                {
                    _POSCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _POSCodeRepository.Update(entity);
                if (!_POSCodeRepository.DbState.IsValid)
                {
                    _POSCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("POS Code updated : {0}", entity.POSCodeID);

                if (model.TermDate != null && model.HomeGrown != "Y")
                {
                    var homeGrownList = _POSCodeRepository.GetByPredicate(x => x.HomeGrown == "Y" && x.MappedCode == entity.Code);
                    if (homeGrownList.Count() > 0)
                    {
                        foreach (var posCodeObj in homeGrownList)
                        {
                            posCodeObj.TermDate = entity.TermDate;
                            posCodeObj.UpdatedDate = base.TodaysDate;
                            posCodeObj.UpdatedBy = base.UserName;
                            posCodeObj.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            posCodeObj.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _POSCodeService.CheckIfExists(posCodeObj);
                            if (!_POSCodeService.BusinessState.IsValid)
                            {
                                _POSCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _POSCodeRepository.Update(posCodeObj);
                            if (!_POSCodeRepository.DbState.IsValid)
                            {
                                _POSCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("POS Code updated : {0}", entity.POSCodeID);
                        }
                    }
                }
                return Ok(entity.POSCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating POS Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

    }
}
