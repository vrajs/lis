using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class RateCodeODController : BaseODController
    {
        #region Variables        
        private IRateCodeRepository _IRateCodeRepository;
        #endregion

        #region Ctor        
        public RateCodeODController(IRateCodeRepository IRateCodeRepository)
        {
            _IRateCodeRepository = IRateCodeRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RateCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRateCode()
        {
            var rateCodeQuery = _IRateCodeRepository.GetRateCode();
            return Ok(rateCodeQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RateCode")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRateCode(int MemberID)
        {
            var rateCodeQuery = _IRateCodeRepository.GetRateCode(MemberID);
            return Ok(rateCodeQuery);
        }
    }
}
