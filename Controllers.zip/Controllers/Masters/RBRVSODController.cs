using System;
using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class RBRVSODController : BaseODController
    {
        #region Variables  
        private IRBRVSRepository _rbrvsRepository;
        #endregion

        #region Constructor

        public RBRVSODController(IRBRVSRepository rbrvsRepository)
        {
            _rbrvsRepository = rbrvsRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RBRVSList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRBRVSList()
        {
            try
            {
                var rbrvsQuery = _rbrvsRepository.GetRBRVSList();
                return Ok(rbrvsQuery);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }            
        }
    }
}
