using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/SystemSetting")]
    public class SystemSettingAPIController : BaseAPIController
    {
        #region Variables

        private ILogger<SystemSettingAPIController> _logger;
        private ISystemSettingRepository _SystemSettingRepository;
        private ISystemSettingService _SystemSettingService;
        private IMapper _mapper;

        #endregion

        #region Ctor        

        public SystemSettingAPIController(ISystemSettingRepository SystemSettingRepository, ISystemSettingService SystemSettingService, ILogger<SystemSettingAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _SystemSettingRepository = SystemSettingRepository;
            _SystemSettingService = SystemSettingService;
            _mapper = mapper;
        }

        #endregion

        #region API Methods

        [HttpGet("GetAllSetting")]
        public IActionResult GetAllSetting()
        {
            List<SystemSettingModel> allItems = _SystemSettingRepository.GetAllSetting();
            return Ok(allItems);
        }

        [HttpGet("{id}", Name = "SystemSettingGet")]
        [Authorize(Policy = Authorization.Policies.ViewCustomerSettingPolicy)]
        public IActionResult Get(short id)
        {
            try
            {
                var SystemSetting = _SystemSettingRepository.GetById(id);
                if (SystemSetting == null) return NotFound($"SystemSetting with {id} was not found");
                return Ok(_mapper.Map<SystemSettingModel>(SystemSetting));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddCustomerSettingPolicy)]
        public IActionResult Post([FromBody] SystemSettingModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                SystemSetting entity = _mapper.Map<SystemSetting>(model);
                entity.CreatedDate = base.TodaysDate;                

                _SystemSettingService.CheckIfExists(entity);
                if (!_SystemSettingService.BusinessState.IsValid)
                {
                    _SystemSettingService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _SystemSettingRepository.Add(entity);

                if (!_SystemSettingRepository.DbState.IsValid)
                {
                    _SystemSettingRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("SystemSettingGet", new { id = entity.ID });
                _logger.LogInformation("New Syatem Setting Created");
                return Created(newUri, _mapper.Map<SystemSettingModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving System Setting : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateCustomerSettingPolicy)]
        public IActionResult Put([FromBody] SystemSettingModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                SystemSetting entity = _SystemSettingRepository.GetById(model.ID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                
                _SystemSettingService.CheckIfExists(entity);
                if (!_SystemSettingService.BusinessState.IsValid)
                {
                    _SystemSettingService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _SystemSettingRepository.Update(entity);
                if (!_SystemSettingRepository.DbState.IsValid)
                {
                    _SystemSettingRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("System Setting Updated : {0}", entity.ID);
                return Ok(entity.ID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating System Setting : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                SystemSetting entity = _SystemSettingRepository.GetById(id);
                _SystemSettingRepository.Delete(entity);
                if (!_SystemSettingRepository.DbState.IsValid)
                {
                    _SystemSettingRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing System Setting : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        #endregion
    }
}
