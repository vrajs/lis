using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Masters;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Common;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/AnesConversionFactor")]
    public class AnesConversionFactorAPIController : BaseAPIController
    {
        private ILogger<AnesConversionFactorAPIController> _logger;
        private IAnesConversionFactorRepository _anesConversionFactorRepository;
        private readonly IAnesConversionFactorService _anesConversionFactorService;
        private IMapper _mapper;

        public AnesConversionFactorAPIController(IAnesConversionFactorRepository anesConversionFactorRepository, IAnesConversionFactorService anesConversionFactorService, ILogger<AnesConversionFactorAPIController> logger, IMapper mapper)
        {
            _anesConversionFactorRepository = anesConversionFactorRepository;
            _anesConversionFactorService = anesConversionFactorService;
            _logger = logger;
            _mapper = mapper;
        }

        [HttpGet("GetAnesConversionFactorKeyVal")]
        //[Authorize(Policy = Authorization.Policies.ViewAnesthesiaConversionFactorPolicy)]
        public IActionResult GetAnesConversionFactorKeyVal()
        {
            var res = _anesConversionFactorRepository.GetAnesConversionFactorKeyVal();
            return Ok(res);
        }

        [HttpGet("GetAnesConversionFactors")]
        //[Authorize(Policy = Authorization.Policies.ViewAnesthesiaConversionFactorPolicy)]
        public IActionResult GetAnesConversionFactors()
        {
            var res = _anesConversionFactorRepository.GetAnesConversionFactors();
            return Ok(res);
        }

        [HttpGet]
        [Route("GetAnesConversionFactorByPOSCode")]
        //[Authorize(Policy = Authorization.Policies.ViewAnesthesiaConversionFactorPolicy)]
        public IActionResult GetAnesConversionFactorByPOSCode(string POSCode)
        {
            var res = _anesConversionFactorRepository.GetAnesConversionFactorByPOSCode(POSCode);
            return Ok(res);
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "AnesConversionFactorGet")]
        [Authorize(Policy = Authorization.Policies.ViewAnesthesiaConversionFactorPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var anesConversionFactor = _anesConversionFactorRepository.GetById(id);
                if (anesConversionFactor == null) return NotFound($"Anes conversion factor with {id} was not found");
                return Ok(_mapper.Map<AnesConversionFactorModel>(anesConversionFactor));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageAnesthesiaConversionFactorPolicy)]
        public IActionResult Post([FromBody] AnesConversionFactorModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AnesConversionFactor entity = _mapper.Map<AnesConversionFactor>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _anesConversionFactorService.CheckIfExists(entity);
                if (!_anesConversionFactorService.BusinessState.IsValid)
                {
                    _anesConversionFactorService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _anesConversionFactorRepository.Add(entity);

                if (!_anesConversionFactorRepository.DbState.IsValid)
                {
                    _anesConversionFactorRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("AnesConversionFactorGet", new { id = entity.AnesConversionFactorID });
                _logger.LogInformation("New anes conversion factor created");
                return Created(newUri, _mapper.Map<AnesConversionFactorModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving anes conversion factor : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageAnesthesiaConversionFactorPolicy)]
        public IActionResult Put([FromBody] AnesConversionFactorModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AnesConversionFactor entity = _anesConversionFactorRepository.GetById(model.AnesConversionFactorID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _anesConversionFactorService.CheckIfExists(entity);
                if (!_anesConversionFactorService.BusinessState.IsValid)
                {
                    _anesConversionFactorService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _anesConversionFactorRepository.Update(entity);
                if (!_anesConversionFactorRepository.DbState.IsValid)
                {
                    _anesConversionFactorRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Anes conversion factor updated : {0}", entity.AnesConversionFactorID);
                return Ok(entity.AnesConversionFactorID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating anes conversion factor : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteAnesthesiaConversionFactorPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                AnesConversionFactor entity = _anesConversionFactorRepository.GetById(id);
                _anesConversionFactorRepository.Delete(entity);
                if (!_anesConversionFactorRepository.DbState.IsValid)
                {
                    _anesConversionFactorRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing anes conersion factor : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
