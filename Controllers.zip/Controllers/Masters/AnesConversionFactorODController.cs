using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class AnesConversionFactorODController : BaseODController
    {
        #region Variables  
        private IAnesConversionFactorRepository _anesConversionFactorRepository;
        #endregion

        #region Constructor

        public AnesConversionFactorODController(IAnesConversionFactorRepository anesConversionFactorRepository)
        {
            _anesConversionFactorRepository = anesConversionFactorRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("AnesConversionFactors")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewAnesthesiaConversionFactorPolicy)]
        public IActionResult GetAgeGroups()
        {
            var anesConversionFactorQuery = _anesConversionFactorRepository.GetAnesConversionFactors();
            return Ok(anesConversionFactorQuery);
        }
    }
}
