using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using Kwicle.Common.Utility;
using Kwicle.Business.Interfaces.Masters;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/TimelyFiling")]
    public class TimelyFilingAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<TimelyFilingAPIController> _logger;
        private ITimelyFilingRepository _timelyFilingRepository;
        private ITimelyFilingService _timelyFilingService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public TimelyFilingAPIController(ITimelyFilingRepository timelyFilingRepository, ITimelyFilingService timelyFilingService, ILogger<TimelyFilingAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _timelyFilingRepository = timelyFilingRepository;
            _timelyFilingService = timelyFilingService;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewTimelyFilingPolicy)]
        public IActionResult Get()
        {
            try
            {
                var timelyFilingRes = _timelyFilingRepository.GetTimelyFilings();
                return Ok(timelyFilingRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Timely Filing: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "TimelyFilingGet")]
        [Authorize(Policy = Authorization.Policies.ViewTimelyFilingPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var timelyFiling = _timelyFilingRepository.GetById(id);
                if (timelyFiling == null) return NotFound($"Timelyfiling with {id} was not found");
                return Ok(_mapper.Map<TimelyFilingModel>(timelyFiling));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageTimelyFilingPolicy)]
        public IActionResult Post([FromBody] TimelyFilingModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                TimelyFiling entity = _mapper.Map<TimelyFiling>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _timelyFilingService.CheckIfExists(entity);
                if (!_timelyFilingService.BusinessState.IsValid)
                {
                    _timelyFilingService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _timelyFilingRepository.Add(entity);

                if (!_timelyFilingRepository.DbState.IsValid)
                {
                    _timelyFilingRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("TimelyFilingGet", new { id = entity.TimelyFilingID });
                _logger.LogInformation("New Timely filing Created");
                return Created(newUri, _mapper.Map<TimelyFilingModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Timly filling : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageTimelyFilingPolicy)]
        public IActionResult Put([FromBody] TimelyFilingModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                TimelyFiling entity = _timelyFilingRepository.GetById(model.TimelyFilingID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _timelyFilingService.CheckIfExists(entity);
                if (!_timelyFilingService.BusinessState.IsValid)
                {
                    _timelyFilingService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _timelyFilingRepository.Update(entity);
                if (!_timelyFilingRepository.DbState.IsValid)
                {
                    _timelyFilingRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Timely Filing Updated : {0}", entity.TimelyFilingID);
                return Ok(entity.TimelyFilingID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Timely Filing : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteTimelyFilingPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                TimelyFiling entity = _timelyFilingRepository.GetById(id);
                _timelyFilingRepository.Delete(entity);
                if (!_timelyFilingRepository.DbState.IsValid)
                {
                    _timelyFilingRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing timelyfilling : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
