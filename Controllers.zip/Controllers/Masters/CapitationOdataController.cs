using Kwicle.Core.Common;
using Kwicle.Data.Contracts.View;
using Microsoft.AspNetCore.OData.Query;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class CapitationOdataController : BaseODController
    {
        #region Variables  
        private IViewRepository _IViewRepository;
        #endregion

        #region Constructor

        public CapitationOdataController(IViewRepository IViewRepository)
        {
            _IViewRepository = IViewRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetCapitations")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewCapitationPolicy)]
        public IActionResult GetCapitations()
        {
            var capitations = _IViewRepository.Capitations.Where(x=>x.RecordStatus == (int)RecordStatus.Active);
            return Ok(capitations);
        }
    }
}
