using Kwicle.Data.Contracts.Alert;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class AlertCodeODController : BaseODController
    {
        #region Variables        
        private IAlertCodeRepository _AlertCodeRepository;
        #endregion

        #region Ctor        
        public AlertCodeODController(IAlertCodeRepository AlertCodeRepository)
        {
            _AlertCodeRepository = AlertCodeRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("AlertCode")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetAlertCodes()
        {
            var alertCodesQuery = _AlertCodeRepository.GetAlertCodes();
            return Ok(alertCodesQuery);
        }

    }
}
