using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Masters;
using AutoMapper;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Common;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/GPCI")]
    public class GPCIAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<GPCIAPIController> _logger;
        private readonly IGPCIRepository _gpciRepository;
        private readonly IGPCIService _gpciService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public GPCIAPIController(IGPCIRepository gpciRepository, IGPCIService gpciService, ILogger<GPCIAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _gpciRepository = gpciRepository;
            _gpciService = gpciService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewGPCIPolicy)]
        public IActionResult Get()
        {
            try
            {
                var gpcis = _gpciRepository.GetByPredicate(null).ToList();
                return Ok(gpcis);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting gpcis: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "GPCIGet")]
        [Authorize(Policy = Authorization.Policies.ViewGPCIPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var gpci = _gpciRepository.GetById(id);
                if (gpci == null) return NotFound($"GPCI with {id} was not found");
                return Ok(_mapper.Map<GPCIModel>(gpci));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddGPCIPolicy)]
        public IActionResult Post([FromBody] GPCIModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                GPCI entity = _mapper.Map<GPCI>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _gpciService.CheckIfExists(entity);
                if (!_gpciService.BusinessState.IsValid)
                {
                    _gpciService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _gpciRepository.Add(entity);

                if (!_gpciRepository.DbState.IsValid)
                {
                    _gpciRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("GPCIGet", new { id = entity.GPCIID });
                _logger.LogInformation("New gpci created");
                return Created(newUri, _mapper.Map<GPCIModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving gpci : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateGPCIPolicy)]
        public IActionResult Put([FromBody] GPCIModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                GPCI entity = _gpciRepository.GetById(model.GPCIID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _gpciService.CheckIfExists(entity);
                if (!_gpciService.BusinessState.IsValid)
                {
                    _gpciService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _gpciRepository.Update(entity);
                if (!_gpciRepository.DbState.IsValid)
                {
                    _gpciRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("GPCI updated : {0}", entity.GPCIID);
                return Ok(entity.GPCIID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating gpci : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteGPCIPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                GPCI entity = _gpciRepository.GetById(id);
                _gpciRepository.Delete(entity);
                if (!_gpciRepository.DbState.IsValid)
                {
                    _gpciRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing gpci : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
