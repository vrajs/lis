using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class RBRVSCodeODController : BaseODController
    {
        #region Variables  
        private IRBRVSCodeRepository _rbrvsCodeRepository;
        #endregion

        #region Constructor

        public RBRVSCodeODController(IRBRVSCodeRepository rbrvsCodeRepository)
        {
            _rbrvsCodeRepository = rbrvsCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RBRVSCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRBRVSCodes()
        {
            var rbrvsCodeQuery = _rbrvsCodeRepository.GetRBRVSCodes();
            return Ok(rbrvsCodeQuery);
        }
    }
}
