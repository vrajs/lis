using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Data.Repositories.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Produces("application/json")]
    [Route("api/HCCCode")]
    public class HCCCodeAPIController : BaseAPIController
    {
        #region Variables     

        private IHCCCodeRepository _HCCCodeRepository;
        private IHCCCodeService _HCCCodeService;
        private ILogger<HCCCodeAPIController> _logger;
        private IMapper _mapper;

        #endregion

        #region Constructor

        public HCCCodeAPIController(IHCCCodeRepository hCCCodeRepository, IHCCCodeService hCCCodeService, ILogger<HCCCodeAPIController> logger, IMapper mapper)
        {
            _HCCCodeRepository = hCCCodeRepository;
            _HCCCodeService = hCCCodeService;
            _logger = logger;
            _mapper = mapper;
        }

        #endregion

        [HttpGet("{id}", Name = "HCCCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewHCCCodePolicy)]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _HCCCodeRepository.GetById(Id);
                if (result == null) return NotFound($"HCC Code {Id} was not found");
                return Ok(_mapper.Map<HCCCodeModel>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddHCCCodePolicy)]
        public IActionResult Post([FromBody]HCCCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var HCCCodeEntity = _mapper.Map<HCCCode>(model);
                HCCCodeEntity.CreatedDate = base.TodaysDate;
                HCCCodeEntity.CreatedBy = base.UserName;
                HCCCodeEntity.RecordStatus = (byte)RecordStatus.Active;
                HCCCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _HCCCodeService.CheckIfExists(HCCCodeEntity);

                if (!_HCCCodeService.BusinessState.IsValid)
                {
                    _HCCCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _HCCCodeRepository.Add(HCCCodeEntity);
                var newUri = Url.Link("HCCCodeGet", new { id = HCCCodeEntity.HCCCodeID });
                _logger.LogInformation("New HCC Code Created ");
                return Created(newUri, _mapper.Map<HCCCodeModel>(HCCCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving HCC Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateHCCCodePolicy)]
        public IActionResult Put([FromBody] HCCCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                HCCCode entity = _HCCCodeRepository.GetById(model.HCCCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _HCCCodeService.CheckIfExists(entity);
                if (!_HCCCodeService.BusinessState.IsValid)
                {
                    _HCCCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _HCCCodeRepository.Update(entity);
                if (!_HCCCodeRepository.DbState.IsValid)
                {
                    _HCCCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("HCC Code updated : {0}", entity.HCCCodeID);
                return Ok(entity.HCCCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating HCC Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


    }
}
