using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Common.Utility;
using Microsoft.AspNetCore.Authorization;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/FeeScheduleLimit")]
    public class FeeScheduleLimitAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<FeeScheduleLimitAPIController> _logger;
        private IFeeScheduleLimitRepository _feeScheduleLimitRepository;
        private IFeeScheduleLimitService _feeScheduleLimitService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public FeeScheduleLimitAPIController(IFeeScheduleLimitRepository feeScheduleLimitRepository, ILogger<FeeScheduleLimitAPIController> logger, IMapper mapper, IFeeScheduleLimitService feeScheduleLimitService)
        {
            _logger = logger;
            _feeScheduleLimitRepository = feeScheduleLimitRepository;
            _mapper = mapper;
            _feeScheduleLimitService = feeScheduleLimitService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        [Authorize(Policy = Authorization.Policies.ViewFeeScheduleLimitsPolicy)]
        public IActionResult Get()
        {
            var feeScheduleRes = _feeScheduleLimitRepository.GetFeeScheduleLimits();
            return Ok(feeScheduleRes.ToList());
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "FeeScheduleLimitGet")]
        [Authorize(Policy = Authorization.Policies.ViewFeeScheduleLimitsPolicy)]
        public IActionResult Get(int id)
        {
            var feeSchedule = _feeScheduleLimitRepository.GetById(id);
            if (feeSchedule == null) return NotFound($"FeeScheduleLimit {id} was not found");
            return Ok(_mapper.Map<FeeScheduleLimitModel>(feeSchedule));
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageFeeScheduleLimitsPolicy)]
        public async Task<IActionResult> Post([FromBody]FeeScheduleLimitModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var feeSchedule = _mapper.Map<FeeScheduleLimit>(model);
                feeSchedule.CreatedDate = base.TodaysDate;
                feeSchedule.CreatedBy = base.UserName;
                feeSchedule.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, feeSchedule.EffectiveDate, feeSchedule.TermDate);
                feeSchedule.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, feeSchedule.EffectiveDate, feeSchedule.TermDate).ToString();

                _feeScheduleLimitService.CheckCreateTimeBusinessLogic(feeSchedule);
                if (!_feeScheduleLimitService.BusinessState.IsValid)
                {
                    _feeScheduleLimitService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                await _feeScheduleLimitRepository.AddAsync(feeSchedule);
                if (!_feeScheduleLimitRepository.DbState.IsValid)
                {
                    _feeScheduleLimitRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("FeeScheduleLimitGet", new { id = feeSchedule.FeeScheduleLimitID });
                _logger.LogInformation("New Fee Schedule Limit Created");
                return Created(newUri, _mapper.Map<FeeScheduleLimitModel>(feeSchedule));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Fee Schedule Limit: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageFeeScheduleLimitsPolicy)]
        public async Task<IActionResult> Put([FromBody]FeeScheduleLimitModel feeSchedule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var oldFeeSchedule = _feeScheduleLimitRepository.GetById(feeSchedule.FeeScheduleLimitID);
                if (oldFeeSchedule == null) return NotFound($"Could not find a FeeScheduleLimit with an FeeScheduleLimitID of {feeSchedule.FeeScheduleLimitID}");

                _mapper.Map(feeSchedule, oldFeeSchedule);
                oldFeeSchedule.UpdatedBy = base.UserName;
                oldFeeSchedule.UpdatedDate = base.TodaysDate;
                oldFeeSchedule.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldFeeSchedule.EffectiveDate, oldFeeSchedule.TermDate);
                oldFeeSchedule.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldFeeSchedule.EffectiveDate, oldFeeSchedule.TermDate).ToString();

                await _feeScheduleLimitRepository.SaveAllAsync();
                if (!_feeScheduleLimitRepository.DbState.IsValid)
                {
                    _feeScheduleLimitRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(feeSchedule.FeeScheduleLimitID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Fee Schedule Limit: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteFeeScheduleLimitsPolicy)]
        public IActionResult Delete(int id)
        {
            //_feeScheduleLimitRepository.DeleteById(id);
            //return Ok(id);

            try
            {
                FeeScheduleLimit entity = _feeScheduleLimitRepository.GetById(id);
                _feeScheduleLimitRepository.Delete(entity);
                if (!_feeScheduleLimitRepository.DbState.IsValid)
                {
                    _feeScheduleLimitRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing rbrvs : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpDelete]
        public IActionResult DeleteByReason(DeleteModel deleteModel)
        {
            _feeScheduleLimitRepository.DeleteByReason(deleteModel);
            return Ok(deleteModel);
        }

        [HttpGet("GetFeeScheduleLimitKeyVal")]
        public IActionResult GetFeeScheduleLimitKeyVal()
        {
            var res = _feeScheduleLimitRepository.GetFeeScheduleLimitKeyVal();
            return Ok(res);
        }
        #endregion  
    }
}
