using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class CustomerSettingODController : BaseODController
    {
        private ISystemSettingRepository _systemSettingRepository;

        public CustomerSettingODController(ISystemSettingRepository systemSettingRepository)
        {
            _systemSettingRepository = systemSettingRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetCustomerSettingList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCustomerSettingList()
        {
            var query = _systemSettingRepository.GetAllSetting();
            return Ok(query);
        }
    }
}
