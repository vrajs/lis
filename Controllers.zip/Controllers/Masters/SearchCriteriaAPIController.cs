using System;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Common;
using System.Linq;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/SearchCriteria")]
    public class SearchCriteriaAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<SearchCriteriaAPIController> _logger;
        private readonly ISearchCriteriaRepository _SearchCriteriaRepository;

        #endregion

        #region Constructor
        public SearchCriteriaAPIController(IMapper mapper, ILogger<SearchCriteriaAPIController> logger, ISearchCriteriaRepository searchCriteriaRepository)
        {
            this._mapper = mapper;
            this._logger = logger;
            this._SearchCriteriaRepository = searchCriteriaRepository;
        }
        #endregion

        #region Api Methods
        [HttpGet("{id}", Name = "SearchCriteriaGet")]
        public IActionResult Get(int id)
        {
            try
            {
                SearchCriteria entity = _SearchCriteriaRepository.GetById(id);
                if (entity == null) return NoContent();
                return Json(_mapper.Map<SearchCriteriaModel>(entity));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]  SearchCriteriaModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                string CurrentUser = base.UserName;
                var searchCriteriaExists = _SearchCriteriaRepository.GetByPredicate(w => w.Name == model.Name && w.CreatedBy == CurrentUser && w.RecordStatus == (int)RecordStatus.Active).FirstOrDefault();
                if (searchCriteriaExists != null)
                {
                    ModelState.AddModelError("SearchCriteriaAlreadyExists", "Name is already exists");
                    return BadRequest(ModelState);
                }

                var entity = _mapper.Map<SearchCriteria>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = CurrentUser;
                entity.RecordStatus = (byte)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                // Insert Data
                _SearchCriteriaRepository.Add(entity);
                if (!_SearchCriteriaRepository.DbState.IsValid)
                {
                    _SearchCriteriaRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("SearchCriteriaGet", new { id = entity.SearchCriteriaID });
                _logger.LogInformation("New search criteria created for claim search");
                return Created(newUri, _mapper.Map<SearchCriteriaModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving search criteria for claim search: {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody]  SearchCriteriaModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var entity = _SearchCriteriaRepository.GetById(model.SearchCriteriaID);
                if (entity == null) return NoContent();

                _mapper.Map(model, entity);
                entity.UpdatedBy = base.UserName;
                entity.UpdatedDate = base.TodaysDate;

                // Update data
                _SearchCriteriaRepository.Update(entity);
                if (!_SearchCriteriaRepository.DbState.IsValid)
                {
                    _SearchCriteriaRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<SearchCriteriaModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while updating search criteria for claim search: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _SearchCriteriaRepository.DeleteById(id);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting search criteria for claim search: {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("GetAllSearchCriteriaByUser/{UserName}")]
        public IActionResult GetAllSearchCriteriaByUser(string UserName)
        {
            var items = _SearchCriteriaRepository.GetAllSearchCriteriaByUser(UserName);
            return Json(items);
        }

        [HttpGet("GetAllSearchCriteriaByUserPage/{UserName}/{PageId}")]
        public IActionResult GetAllSearchCriteriaByUserPage(string UserName, string PageId)
        {
            var items = _SearchCriteriaRepository.GetAllSearchCriteriaByUserPage(UserName, PageId);
            return Json(items);
        }
        #endregion
    }
}
