using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class AgeGroupODController : BaseODController
    {
        #region Variables  
        private IAgeGroupRepository _ageGroupRepository;
        #endregion

        #region Constructor

        public AgeGroupODController(IAgeGroupRepository ageGroupRepository)
        {
            _ageGroupRepository = ageGroupRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("AgeGroups")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewAgeCategoriesPolicy)]
        public IActionResult GetAgeGroups()
        {
            var ageGroupQuery = _ageGroupRepository.GetAgeGroups();
            return Ok(ageGroupQuery);
        }
    }
}
