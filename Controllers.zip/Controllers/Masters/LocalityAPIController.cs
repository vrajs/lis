using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Masters;
using AutoMapper;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Common;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/Locality")]
    public class LocalityAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<LocalityAPIController> _logger;
        private readonly ILocalityRepository _localityRepository;
        private readonly ILocalityService _localityService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public LocalityAPIController(ILocalityRepository localityRepository, ILocalityService localityService, ILogger<LocalityAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _localityRepository = localityRepository;
            _localityService = localityService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy =Authorization.Policies.ViewLocalityPolicy)]
        public IActionResult Get()
        {
            try
            {
                var localitys = _localityRepository.GetByPredicate(null).ToList();
                return Ok(localitys);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting localitiess: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "LocalityGet")]
        [Authorize(Policy = Authorization.Policies.ViewLocalityPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var locality = _localityRepository.GetById(id);
                if (locality == null) return NotFound($"Locality with {id} was not found");
                return Ok(_mapper.Map<LocalityModel>(locality));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddLocalityPolicy)]
        public IActionResult Post([FromBody] LocalityModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                Locality entity = _mapper.Map<Locality>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _localityService.CheckIfExists(entity);
                if (!_localityService.BusinessState.IsValid)
                {
                    _localityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _localityRepository.Add(entity);

                if (!_localityRepository.DbState.IsValid)
                {
                    _localityRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("LocalityGet", new { id = entity.LocalityID });
                _logger.LogInformation("New locality created");
                return Created(newUri, _mapper.Map<LocalityModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving locality : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateLocalityPolicy)]
        public IActionResult Put([FromBody] LocalityModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                Locality entity = _localityRepository.GetById(model.LocalityID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _localityService.CheckIfExists(entity);
                if (!_localityService.BusinessState.IsValid)
                {
                    _localityService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _localityRepository.Update(entity);
                if (!_localityRepository.DbState.IsValid)
                {
                    _localityRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Locality updated : {0}", entity.LocalityID);
                return Ok(entity.LocalityID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating locality : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteLocalityPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                Locality entity = _localityRepository.GetById(id);
                _localityRepository.Delete(entity);
                if (!_localityRepository.DbState.IsValid)
                {
                    _localityRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing locality : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
