using Kwicle.Business.Implementation;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Masters
{
    public class PlanCapitationService : BaseService, IPlanCapitationService
    {
        #region Property
        private readonly IPlanCapitationRepository _PlanCapitationRepository;
        #endregion

        #region Constructor
        public PlanCapitationService(IPlanCapitationRepository planCapitationRepository)
        {
            this._PlanCapitationRepository = planCapitationRepository;
        }
        #endregion

        #region Public Methods
        public void CheckDuplicateData(PlanCapitation entity)
        {
            var query = _PlanCapitationRepository.GetByPredicate(i => i.CapitationHeaderId == entity.CapitationHeaderId && (entity.CapitationPlanId != 0 ? i.CapitationPlanId != entity.CapitationPlanId : true) && i.HealthPlanId == entity.HealthPlanId && i.RecordStatus != (int)RecordStatus.Deleted &&
                       (((i.MinAge <= entity.MinAge) && (i.MaxAge >= entity.MinAge)) ||
                       ((i.MinAge <= entity.MaxAge) && (i.MaxAge >= entity.MaxAge))
                       || ((i.MinAge >= entity.MinAge) && (i.MaxAge <= entity.MaxAge))) &&
                       (((i.EffectiveDate <= entity.EffectiveDate.Date) && (i.TermDate >= entity.EffectiveDate.Date)) ||
                       ((i.EffectiveDate <= entity.TermDate.Date) && (i.TermDate >= entity.TermDate.Date))
                       || ((i.EffectiveDate >= entity.EffectiveDate.Date) && (i.TermDate <= entity.TermDate.Date))));
            var existingPlanCapitation = query.FirstOrDefault();
            if (existingPlanCapitation != null)
            {
                base.BusinessState.AddErrorMessage($"Plan rate configuration already exists into system", "");
            }
        }
        #endregion
    }
}
