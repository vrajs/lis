using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class EditCodeODController : BaseODController
    {
        #region Variables        
        private IEditCodeRepository _EditCodeRepository;
        #endregion

        #region Ctor        
        public EditCodeODController(IEditCodeRepository EditCodeRepository)
        {
            _EditCodeRepository = EditCodeRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("EditCode")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetEditCode(string pageID)
        {
            int[] arr = pageID.Split(',').Select(n => Convert.ToInt32(n)).ToArray();
            var EditCodeQuery = _EditCodeRepository.GetEditCode(arr);
            return Ok(EditCodeQuery);
        }

    }
}
