using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.Extensions.Logging;
using Kwicle.Core.Common;
using AutoMapper;
using Kwicle.Core.CustomModel.Masters;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/InsuranceCarrier")]
    public class InsuranceCarrierAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<InsuranceCarrierAPIController> _logger;
        private IInsuranceCarrierRepository _IInsuranceCarrierRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public InsuranceCarrierAPIController(ILogger<InsuranceCarrierAPIController> logger, IInsuranceCarrierRepository IInsuranceCarrierRepository, IMapper mapper)
        {
            _logger = logger;
            _IInsuranceCarrierRepository = IInsuranceCarrierRepository;
            _mapper = mapper;

        }
        #endregion

        #region API Methods

        // GET api/values/5
        [HttpGet("{id}", Name = "InsuranceCarrierGet")]
        public IActionResult Get(long id)
        {
            try
            {
                var InsuranceCarrier = _IInsuranceCarrierRepository.GetById(id);
                if (InsuranceCarrier == null) return NotFound($"InsuranceCarrier {id} was not Found");
                if (!_IInsuranceCarrierRepository.DbState.IsValid)
                {
                    _IInsuranceCarrierRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<InsuranceCarrierModel>(InsuranceCarrier));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting InsuranceCarrier : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]InsuranceCarrierModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var insuranceCarrierModel = _mapper.Map<InsuranceCarrier>(model);
                insuranceCarrierModel.CreatedDate = base.TodaysDate;
                insuranceCarrierModel.CreatedBy = base.UserName;

                insuranceCarrierModel.RecordStatus = (byte)RecordStatus.Active;
                insuranceCarrierModel.RecordStatusChangeComment = RecordStatus.Active.ToString();

                if (_IInsuranceCarrierRepository.GetByPredicate(p => p.InsuranceTypeId == insuranceCarrierModel.InsuranceTypeId && insuranceCarrierModel.RecordStatus == (byte)RecordStatus.Active).Any())
                {
                    return BadRequest($"Insurance Carrier Id { insuranceCarrierModel.InsuranceTypeId } already exists");
                }

                _IInsuranceCarrierRepository.Add(insuranceCarrierModel);
                if (!_IInsuranceCarrierRepository.DbState.IsValid)
                {
                    _IInsuranceCarrierRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("InsuranceCarrierGet", new { id = insuranceCarrierModel.InsuranceCarrierID });
                _logger.LogInformation("New InsuranceCarrier Created");
                return Created(newUri, insuranceCarrierModel);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving InsuranceCarrier : {0}", ex);
                return BadRequest(ex.Message);
            }

        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]InsuranceCarrierModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldInsuranceCarrier = _IInsuranceCarrierRepository.GetById(model.InsuranceCarrierID);

                if (oldInsuranceCarrier == null) return NotFound($"Could not find a InsuranceCarrier with an InsuranceCarrierID of {model.InsuranceCarrierID}");

                _mapper.Map(model, oldInsuranceCarrier);
                oldInsuranceCarrier.UpdatedBy = base.UserName;
                oldInsuranceCarrier.UpdatedDate = base.TodaysDate;

                oldInsuranceCarrier.RecordStatus = (byte)RecordStatus.Active; 
                oldInsuranceCarrier.RecordStatusChangeComment = RecordStatus.Active.ToString(); 

                _IInsuranceCarrierRepository.Update(oldInsuranceCarrier);
                if (!_IInsuranceCarrierRepository.DbState.IsValid)
                {
                    _IInsuranceCarrierRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating InsuranceCarrier :{ex}");
                return BadRequest(ex.Message);
            }

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _IInsuranceCarrierRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting InsuranceCarrier : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
    }
