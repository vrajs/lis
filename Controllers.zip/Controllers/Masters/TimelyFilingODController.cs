using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class TimelyFilingODController : BaseODController
    {
        #region Variables  
        private ITimelyFilingRepository _timelyFilingRepository;
        #endregion

        #region Constructor

        public TimelyFilingODController(ITimelyFilingRepository timelyFilingRepository)
        {
            _timelyFilingRepository = timelyFilingRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("TimelyFilings")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewTimelyFilingPolicy)]
        public IActionResult GetModifierDiscounts()
        {
            var timelyFilingQuery = _timelyFilingRepository.GetTimelyFilings();
            return Ok(timelyFilingQuery);
        }
    }
}
