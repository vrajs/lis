using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities.Master;
using System.Net;
using Microsoft.AspNetCore.Authorization;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/ModifierDiscount")]
    public class ModifierDiscountAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<ModifierDiscountAPIController> _logger;
        private IModifierDiscountRepository _modifierDiscountRepository;
        private IModifierDiscountService _modifierDiscountService;
        private IMapper _mapper;
        private readonly IModifierDiscountGroupRepository _modifierDiscountGroupRepository;
        #endregion

        #region Ctor        
        public ModifierDiscountAPIController(IModifierDiscountRepository modifierDiscountRepository, IModifierDiscountService modifierDiscountService, ILogger<ModifierDiscountAPIController> logger, IMapper mapper, IModifierDiscountGroupRepository modifierDiscountGroupRepository)
        {
            _logger = logger;
            _modifierDiscountRepository = modifierDiscountRepository;
            _modifierDiscountService = modifierDiscountService;
            _mapper = mapper;
            _modifierDiscountGroupRepository = modifierDiscountGroupRepository;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewModifierDiscountGroupPolicy)]
        public IActionResult Get()
        {
            try
            {
                var modifierDiscountRes = _modifierDiscountRepository.GetByPredicate(null);
                if (!_modifierDiscountRepository.DbState.IsValid)
                {
                    _modifierDiscountRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Json(modifierDiscountRes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Modifier Discount: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "ModifierDiscountGet")]
        [Authorize(Policy = Authorization.Policies.ViewModifierDiscountGroupPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var modifierDiscount = _modifierDiscountRepository.GetById(id);
                if (modifierDiscount == null) return NotFound($"Modifier discount with {id} was not found");
                return Ok(_mapper.Map<ModifierDiscountModel>(modifierDiscount));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageModifierDiscountGroupPolicy)]
        public IActionResult Post([FromBody] ModifierDiscountModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                //check ModifierDiscountGroupID has value , if not then check ModifierDiscountGroup has value .. then add data to commoncode for perticular Code type
                if(model.ModifierDiscountGroupID == 0 && string.IsNullOrWhiteSpace(model.ModifierDiscountGroup))
                {
                    return BadRequest("Please add proper value for modifier discount group.");
                }
                if (model.ModifierDiscountGroupID == 0 && !string.IsNullOrWhiteSpace(model.ModifierDiscountGroup))
                {
                    // add data to ModifierDiscountGroup
                    ModifierDiscountGroup groupEntity = new ModifierDiscountGroup();
                    groupEntity.GroupName = model.ModifierDiscountGroup;
                    groupEntity.CreatedDate = base.TodaysDate;
                    groupEntity.CreatedBy = base.UserName;
                    groupEntity.RecordStatus = (byte)RecordStatus.Active;
                    groupEntity.RecordStatusChangeComment = "Active";

                    _modifierDiscountGroupRepository.Add(groupEntity);

                    if (!_modifierDiscountGroupRepository.DbState.IsValid)
                    {
                        _modifierDiscountGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    model.ModifierDiscountGroupID = groupEntity.ModifierDiscountGroupID;
                }


                ModifierDiscount entity = _mapper.Map<ModifierDiscount>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _modifierDiscountService.CheckIfExists(entity);
                if (!_modifierDiscountService.BusinessState.IsValid)
                {
                    _modifierDiscountService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _modifierDiscountRepository.Add(entity);

                if (!_modifierDiscountRepository.DbState.IsValid)
                {
                    _modifierDiscountRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("ModifierDiscountGet", new { id = entity.ModifierDiscountID });
                _logger.LogInformation("New ModifierDiscount Created");
                return Created(newUri, _mapper.Map<ModifierDiscountModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ModifierDiscount : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageModifierDiscountGroupPolicy)]
        public IActionResult Put([FromBody] ModifierDiscountModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                //check ModifierDiscountGroupID has value , if not then check ModifierDiscountGroup has value .. then add data to commoncode for perticular Code type
                if (model.ModifierDiscountGroupID == 0 && string.IsNullOrWhiteSpace(model.ModifierDiscountGroup))
                {
                    return BadRequest("Please add proper value for modifier discount group.");
                }
                if (model.ModifierDiscountGroupID == 0 && !string.IsNullOrWhiteSpace(model.ModifierDiscountGroup))
                {
                    // add data to ModifierDiscountGroup
                    ModifierDiscountGroup groupEntity = new ModifierDiscountGroup();
                    groupEntity.GroupName = model.ModifierDiscountGroup;
                    groupEntity.CreatedDate = base.TodaysDate;
                    groupEntity.CreatedBy = base.UserName;
                    groupEntity.RecordStatus = (byte)RecordStatus.Active;
                    groupEntity.RecordStatusChangeComment = "Active";

                    _modifierDiscountGroupRepository.Add(groupEntity);

                    if (!_modifierDiscountGroupRepository.DbState.IsValid)
                    {
                        _modifierDiscountGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    model.ModifierDiscountGroupID = groupEntity.ModifierDiscountGroupID;
                }

                ModifierDiscount entity = _modifierDiscountRepository.GetById(model.ModifierDiscountID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _modifierDiscountService.CheckIfExists(entity);
                if (!_modifierDiscountService.BusinessState.IsValid)
                {
                    _modifierDiscountService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _modifierDiscountRepository.Update(entity);
                if (!_modifierDiscountRepository.DbState.IsValid)
                {
                    _modifierDiscountRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("ModifierDiscount updated : {0}", entity.ModifierDiscountID);
                return Ok(entity.ModifierDiscountID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating ModifierDiscount : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteModifierDiscountGroupPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                ModifierDiscount entity = _modifierDiscountRepository.GetById(id);
                _modifierDiscountRepository.Delete(entity);
                //_modifierDiscountRepository.DeleteById(id);
                if (!_modifierDiscountRepository.DbState.IsValid)
                {
                    _modifierDiscountRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing ModifierDiscount : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
