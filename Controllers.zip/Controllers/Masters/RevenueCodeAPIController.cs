using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Common;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Business.Interfaces.Masters;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/RevenueCode")]
    public class RevenueCodeAPIController : BaseAPIController
    {
        #region Variables     

        private IRevenueCodeRepository _revenueCodeRepository;
        private ILogger<RevenueCodeAPIController> _logger;
        private IMapper _mapper;
        private IRevenueCodeService _revenueCodeService;

        #endregion

        #region Constructor

        public RevenueCodeAPIController(IRevenueCodeRepository RevenueCodeRepository,ILogger<RevenueCodeAPIController> logger, IMapper mapper, IRevenueCodeService revenueCodeService)
        {
            _revenueCodeRepository = RevenueCodeRepository;
            _logger = logger;
            _mapper = mapper;
            _revenueCodeService = revenueCodeService;
        }

        #endregion

        [HttpGet("")]
        [Authorize(Policy = Authorization.Policies.ViewRevenueCodePolicy)]
        public IActionResult Get()
        {
            var feeScheduleRes = _revenueCodeRepository.GetRevenueCodes();
            return Json(feeScheduleRes.ToList());
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RevenueCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewRevenueCodePolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var revenueCode = _revenueCodeRepository.GetRevenueCodeByID(id);
                if (revenueCode == null) return NotFound($"Revenue Code {id} was not found");
                return Ok(_mapper.Map<RevenueCodeModel>(revenueCode));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddRevenueCodePolicy)]
        public IActionResult Post([FromBody]RevenueCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var revenueCodeEntity = _mapper.Map<RevenueCode>(model);
                revenueCodeEntity.CreatedDate = base.TodaysDate;
                revenueCodeEntity.CreatedBy = base.UserName;
                revenueCodeEntity.RecordStatus = (int)RecordStatus.Active;
                revenueCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();                

                _revenueCodeService.CheckIfExists(revenueCodeEntity);

                if (!_revenueCodeService.BusinessState.IsValid)
                {
                    _revenueCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _revenueCodeRepository.Add(revenueCodeEntity);
                var newUri = Url.Link("RevenueCodeGet", new { id = revenueCodeEntity.RevenueCodeID });
                _logger.LogInformation("New Revenue Code Created ");
                return Created(newUri, _mapper.Map<RevenueCodeModel>(revenueCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Revenue Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateRevenueCodePolicy)]
        public IActionResult Put([FromBody] RevenueCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RevenueCode entity = _revenueCodeRepository.GetById(model.RevenueCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _revenueCodeService.CheckIfExists(entity);
                if (!_revenueCodeService.BusinessState.IsValid)
                {
                    _revenueCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _revenueCodeRepository.Update(entity);
                if (!_revenueCodeRepository.DbState.IsValid)
                {
                    _revenueCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("RevenueCode updated : {0}", entity.RevenueCodeID);
                if (model.TermDate != null && model.HomeGrown != "Y")
                {
                    var homeGrownList = _revenueCodeRepository.GetByPredicate(x => x.HomeGrown == "Y" && x.MappedCode == entity.Code);
                    if (homeGrownList.Count() > 0)
                    {
                        foreach (var revenueCodeObj in homeGrownList)
                        {
                            revenueCodeObj.TermDate = entity.TermDate;
                            revenueCodeObj.UpdatedDate = base.TodaysDate;
                            revenueCodeObj.UpdatedBy = base.UserName;
                            revenueCodeObj.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            revenueCodeObj.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _revenueCodeService.CheckIfExists(revenueCodeObj);
                            if (!_revenueCodeService.BusinessState.IsValid)
                            {
                                _revenueCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _revenueCodeRepository.Update(revenueCodeObj);
                            if (!_revenueCodeRepository.DbState.IsValid)
                            {
                                _revenueCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("RevenueCode updated : {0}", entity.RevenueCodeID);
                        }
                    }
                }

                return Ok(entity.RevenueCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating RevenueCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
