using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Implementation.Masters;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/CPT")]
    [EnableCors("AnyGET")]
    public class CPTAPIController : BaseAPIController
    {
        private ICPTCodeRepository _CPTCodeRepository;
        private ICPTCodeService _CPTCodeService;
        private ILogger<CPTAPIController> _logger;
        private IMapper _mapper;


        public CPTAPIController(ICPTCodeRepository cPTCodeRepository, IMapper mapper, ILogger<CPTAPIController> logger, ICPTCodeService cPTCodeService)
        {
            _CPTCodeRepository = cPTCodeRepository;
            _CPTCodeService = cPTCodeService;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetModifierCodes")]
        public IActionResult GetModifierCodes()
        {
            var res = _CPTCodeRepository.GetModifierCodes().ToList();
            return Json(res);
        }

        [HttpGet]
        [Route("GetHCPCCodes")]
        public IActionResult GetHCPCCodes()
        {
            var res = _CPTCodeRepository.GetHCPCCodes().ToList();
            return Json(res);
        }

        [HttpGet("{id}", Name = "CPTCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewCPTCodePolicy)]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _CPTCodeRepository.GetById(Id);
                if (result == null) return NotFound($"CPT Code {Id} was not found");
                return Ok(_mapper.Map<CPTCodeModel>(result));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Policy =Authorization.Policies.AddCPTCodePolicy)]
        public IActionResult Post([FromBody]CPTCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var CPTCodeEntity = _mapper.Map<CPTCode>(model);
                CPTCodeEntity.CreatedDate = base.TodaysDate;
                CPTCodeEntity.CreatedBy = base.UserName;
                CPTCodeEntity.RecordStatus = (int)RecordStatus.Active;
                CPTCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _CPTCodeService.CheckIfExists(CPTCodeEntity);

                if (!_CPTCodeService.BusinessState.IsValid)
                {
                    _CPTCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _CPTCodeRepository.Add(CPTCodeEntity);
                var newUri = Url.Link("CPTCodeGet", new { id = CPTCodeEntity.CPTCodeID });
                _logger.LogInformation("New CPT Code Created ");
                return Created(newUri, _mapper.Map<CPTCodeModel>(CPTCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving CPT Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateCPTCodePolicy)]
        public IActionResult Put([FromBody] CPTCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                CPTCode entity = _CPTCodeRepository.GetById(model.CPTCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _CPTCodeService.CheckIfExists(entity);
                if (!_CPTCodeService.BusinessState.IsValid)
                {
                    _CPTCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _CPTCodeRepository.Update(entity);
                if (!_CPTCodeRepository.DbState.IsValid)
                {
                    _CPTCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("CPT Code updated : {0}", entity.CPTCodeID);

                if (model.TermDate != null && model.HomeGrown != "Y")
                {
                    var homeGrownList = _CPTCodeRepository.GetByPredicate(x => x.HomeGrown == "Y" && x.MappedCode == entity.Code);
                    if (homeGrownList.Count() > 0)
                    {
                        foreach (var cptCodeObj in homeGrownList)
                        {
                            cptCodeObj.TermDate = entity.TermDate;
                            cptCodeObj.UpdatedDate = base.TodaysDate;
                            cptCodeObj.UpdatedBy = base.UserName;
                            cptCodeObj.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            cptCodeObj.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _CPTCodeService.CheckIfExists(cptCodeObj);
                            if (!_CPTCodeService.BusinessState.IsValid)
                            {
                                _CPTCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _CPTCodeRepository.Update(cptCodeObj);
                            if (!_CPTCodeRepository.DbState.IsValid)
                            {
                                _CPTCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("CPT Code updated : {0}", entity.CPTCodeID);
                        }
                    }
                }
                return Ok(entity.CPTCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating CPT Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

    }
}
