using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class CommonClinicalCodeODController : BaseODController
    {
        #region Variables     

        private ICommonClinicalCodeRepository _CommonClinicalCodeRepository;

        #endregion

        #region Constructor

        public CommonClinicalCodeODController(ICommonClinicalCodeRepository commonClinicalCodeRepository)
        {
            _CommonClinicalCodeRepository = commonClinicalCodeRepository;
        }

        #endregion

        #region Method

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("CommonClinicalCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCommonClinicalCodes(int ClinicalCodeTypeID)
        {
            var commonClinicalCodeQuery = _CommonClinicalCodeRepository.GetCommonClinicalCodes(ClinicalCodeTypeID);
            return Ok(commonClinicalCodeQuery);
        }

        #endregion

    }
}
