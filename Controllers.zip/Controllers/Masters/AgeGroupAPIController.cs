using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using AutoMapper;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Common;
using System.Net;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/AgeGroup")]
    public class AgeGroupAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<AgeGroupAPIController> _logger;
        private readonly IAgeGroupRepository _ageGroupRepository;
        private readonly IAgeGroupService _ageGroupService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public AgeGroupAPIController(IAgeGroupRepository ageGroupRepository, IAgeGroupService ageGroupService, ILogger<AgeGroupAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _ageGroupRepository = ageGroupRepository;
            _ageGroupService = ageGroupService;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewAgeCategoriesPolicy)]
        public IActionResult Get()
        {
            try
            {
                var ageGroups = _ageGroupRepository.GetByPredicate(null).ToList();
                return Ok(ageGroups);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting Age Groups: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "AgeGroupGet")]
        [Authorize(Policy = Authorization.Policies.ViewAgeCategoriesPolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var ageGroup = _ageGroupRepository.GetById(id);
                if (ageGroup == null) return NotFound($"Agegroup with {id} was not found");
                return Ok(_mapper.Map<AgeGroupModel>(ageGroup));                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.ManageAgeCategoriesPolicy)]
        public IActionResult Post([FromBody] AgeGroupModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AgeGroup entity = _mapper.Map<AgeGroup>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _ageGroupService.CheckIfExists(entity);
                if (!_ageGroupService.BusinessState.IsValid)
                {
                    _ageGroupService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _ageGroupRepository.Add(entity);

                if (!_ageGroupRepository.DbState.IsValid)
                {
                    _ageGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("AgeGroupGet", new { id = entity.AgeGroupID });
                _logger.LogInformation("New age group Created");
                return Created(newUri, _mapper.Map<AgeGroupModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving age group : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.ManageAgeCategoriesPolicy)]
        public IActionResult Put([FromBody] AgeGroupModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AgeGroup entity = _ageGroupRepository.GetById(model.AgeGroupID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _ageGroupService.CheckIfExists(entity);
                if (!_ageGroupService.BusinessState.IsValid)
                {
                    _ageGroupService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _ageGroupRepository.Update(entity);
                if (!_ageGroupRepository.DbState.IsValid)
                {
                    _ageGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Age group updated : {0}", entity.AgeGroupID);
                return Ok(entity.AgeGroupID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating age group : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteAgeCategoriesPolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                AgeGroup entity = _ageGroupRepository.GetById(id);
                _ageGroupRepository.Delete(entity);
                //_ageGroupRepository.DeleteById(id);
                if (!_ageGroupRepository.DbState.IsValid)
                {
                    _ageGroupRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing age group : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }
}
