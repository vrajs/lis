using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/DRGPaymentPayPercent")]
    public class DRGPaymentPayPercentAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<DRGPaymentPayPercentAPIController> _logger;
        private IDRGPaymentPayPercentRepository _dRGPaymentPayPercentRepository;
        private IMapper _mapper;
        #endregion

        #region ctor
        public DRGPaymentPayPercentAPIController(ILogger<DRGPaymentPayPercentAPIController> logger, IMapper mapper, IDRGPaymentPayPercentRepository dRGPaymentPayPercentRepository)
        {
            _logger = logger;
            _mapper = mapper;
            _dRGPaymentPayPercentRepository = dRGPaymentPayPercentRepository;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var feeScheduleHeaderRes = _dRGPaymentPayPercentRepository.GetByPredicate(i => i.RecordStatus == (int)RecordStatus.Active);
            return Ok(feeScheduleHeaderRes.ToList());
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
        #endregion
    }
}
