using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Business.Interfaces.Masters;
using AutoMapper;
using System.Linq;
using System;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Common;
using System.Net;
using Kwicle.Core.CustomModel.Masters;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/RBRVSCode")]
    public class RBRVSCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RBRVSCodeAPIController> _logger;
        private readonly IRBRVSCodeRepository _rbrvsCodeRepository;
        private readonly IRBRVSCodeService _rbrvsCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public RBRVSCodeAPIController(IRBRVSCodeRepository rbrvsCodeRepository, IRBRVSCodeService rbrvsCodeService, ILogger<RBRVSCodeAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _rbrvsCodeRepository = rbrvsCodeRepository;
            _rbrvsCodeService = rbrvsCodeService;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewRBRVSCodePolicy)]
        public IActionResult Get()
        {
            try
            {
                var rbrvsCodes = _rbrvsCodeRepository.GetRBRVSCodes().Where(x=>x.RecordStatus == (int)RecordStatus.Active).ToList();
                return Ok(rbrvsCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting rbrvs code: {ex}");
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RBRVSCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewRBRVSCodePolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var rbrvsCode = _rbrvsCodeRepository.GetById(id);
                if (rbrvsCode == null) return NotFound($"RBRVS code with {id} was not found");
                return Ok(_mapper.Map<RBRVSCodeModel>(rbrvsCode));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddRBRVSCodePolicy)]
        public IActionResult Post([FromBody] RBRVSCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RBRVSCode entity = _mapper.Map<RBRVSCode>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _rbrvsCodeService.CheckIfExists(entity);
                if (!_rbrvsCodeService.BusinessState.IsValid)
                {
                    _rbrvsCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _rbrvsCodeRepository.Add(entity);

                if (!_rbrvsCodeRepository.DbState.IsValid)
                {
                    _rbrvsCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("RBRVSCodeGet", new { id = entity.RBRVSCodeID });
                _logger.LogInformation("New rbrvs code Created");
                return Created(newUri, _mapper.Map<RBRVSCodeModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving rbrvs code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateRBRVSCodePolicy)]
        public IActionResult Put([FromBody] RBRVSCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RBRVSCode entity = _rbrvsCodeRepository.GetById(model.RBRVSCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _rbrvsCodeService.CheckIfExists(entity);
                if (!_rbrvsCodeService.BusinessState.IsValid)
                {
                    _rbrvsCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _rbrvsCodeRepository.Update(entity);
                if (!_rbrvsCodeRepository.DbState.IsValid)
                {
                    _rbrvsCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("RBRVS code updated : {0}", entity.RBRVSCodeID);
                return Ok(entity.RBRVSCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating rbrvs code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        [Authorize(Policy = Authorization.Policies.DeleteRBRVSCodePolicy)]
        public IActionResult Delete(int id)
        {
            try
            {
                RBRVSCode entity = _rbrvsCodeRepository.GetById(id);
                _rbrvsCodeRepository.Delete(entity);
                if (!_rbrvsCodeRepository.DbState.IsValid)
                {
                    _rbrvsCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing rbrvs code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpGet]
        [Route("GetByTypeNumber/{TypeNumber}")]
        public IActionResult GetByTypeNumber(short TypeNumber)
        {
            var res = _rbrvsCodeRepository.GetByTypeNumber(TypeNumber);
            return Ok(res);
        }
    }
}
