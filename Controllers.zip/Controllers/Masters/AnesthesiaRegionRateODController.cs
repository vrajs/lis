using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class AnesthesiaRegionRateODController : BaseODController
    {
        #region Variables  
        private IAnesthesiaRegionRateRepository _anesthesiaRegionRateRepository;
        #endregion

        #region Constructor
        public AnesthesiaRegionRateODController(IAnesthesiaRegionRateRepository anesthesiaRegionRateRepository)
        {
            _anesthesiaRegionRateRepository = anesthesiaRegionRateRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("AnesthesiaRegionRates")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewAnesthesiaRegionRatesPolicy)]
        public IActionResult GetAnesthesiaRegionRates()
        {
            var anesthesiaRegionRateQuery = _anesthesiaRegionRateRepository.GetAnesthesiaRegionRates();
            return Ok(anesthesiaRegionRateQuery);
        }
    }
}
