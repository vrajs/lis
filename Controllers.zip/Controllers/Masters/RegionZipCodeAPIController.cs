using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Masters
{
    [Produces("application/json")]
    [Route("api/RegionZipCode")]
    public class RegionZipCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RegionZipCodeAPIController> _logger;
        private readonly IRegionZipCodeRepository _regionZipCodeRepository;
        private readonly IRegionZipCodeService _regionZipCodeService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public RegionZipCodeAPIController(IRegionZipCodeRepository regionZipCodeRepository, IRegionZipCodeService regionZipCodeService, ILogger<RegionZipCodeAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _regionZipCodeRepository = regionZipCodeRepository;
            _regionZipCodeService = regionZipCodeService;
            _mapper = mapper;
        }
        #endregion

        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var regions = _regionZipCodeRepository.GetByPredicate(null).ToList();
                return Ok(regions);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting regionZipCode: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "RegionZipCodeGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var region = _regionZipCodeRepository.GetById(id);
                if (region == null) return NotFound($"RegionZipCode with {id} was not found");
                return Ok(_mapper.Map<RegionZipCodeModel>(region));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] RegionZipCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RegionZipCode entity = _mapper.Map<RegionZipCode>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _regionZipCodeService.CheckIfExists(entity);
                if (!_regionZipCodeService.BusinessState.IsValid)
                {
                    _regionZipCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _regionZipCodeRepository.Add(entity);

                if (!_regionZipCodeRepository.DbState.IsValid)
                {
                    _regionZipCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("RegionZipCodeGet", new { id = entity.RegionZipCodeID });
                _logger.LogInformation("New regionZipCode created");
                return Created(newUri, _mapper.Map<RegionZipCodeModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving regionZipCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] RegionZipCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                RegionZipCode entity = _regionZipCodeRepository.GetById(model.RegionZipCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _regionZipCodeService.CheckIfExists(entity);
                if (!_regionZipCodeService.BusinessState.IsValid)
                {
                    _regionZipCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _regionZipCodeRepository.Update(entity);
                if (!_regionZipCodeRepository.DbState.IsValid)
                {
                    _regionZipCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("RegionZipCode updated : {0}", entity.RegionZipCodeID);
                return Ok(entity.RegionZipCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating regionZipCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {                
                _regionZipCodeRepository.DeleteById(id, base.UserName, base.TodaysDate);
                if (!_regionZipCodeRepository.DbState.IsValid)
                {
                    _regionZipCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing regionZipCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
