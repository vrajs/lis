using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/ICDCode")]
    public class ICDCodeAPIController : BaseAPIController
    {
        private ILogger<ICDCodeAPIController> _logger;
        private IMapper _mapper;
        private IICDCodeRepository _ICDCodeRepository;
        private IICDCodeService _ICDCodeService;
        public ICDCodeAPIController(ILogger<ICDCodeAPIController> logger, IMapper mapper, IICDCodeRepository ICDCodeRepository, IICDCodeService ICDCodeService)
        {
            _logger = logger;
            _mapper = mapper;
            _ICDCodeRepository = ICDCodeRepository;
            _ICDCodeService = ICDCodeService;
        }


        #region CRUD
        [HttpGet]
        [Authorize(Policy = Authorization.Policies.ViewICDCodePolicy)]
        public IActionResult Get()
        {
            try
            {
                var ICDCodes = _ICDCodeRepository.GetByPredicate(null).ToList();
                return Ok(ICDCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting ICD Codes : {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "ICDCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewICDCodePolicy)]
        public IActionResult Get(int id)
        {
            try
            {
                var ICDCode = _ICDCodeRepository.GetById(id);
                if (ICDCode == null) return NotFound($"ICD Code with {id} was not found");
                return Ok(_mapper.Map<ICDCodeModel>(ICDCode));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddICDCodePolicy)]
        public IActionResult Post([FromBody]ICDCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var ICDCodeEntity = _mapper.Map<ICDCode>(model);
                ICDCodeEntity.CreatedDate = base.TodaysDate;
                ICDCodeEntity.CreatedBy = base.UserName;
                ICDCodeEntity.RecordStatus = (int)RecordStatus.Active;
                ICDCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();                

                _ICDCodeService.CheckIfExists(ICDCodeEntity);

                if (!_ICDCodeService.BusinessState.IsValid)
                {
                    _ICDCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _ICDCodeRepository.Add(ICDCodeEntity);
                var newUri = Url.Link("ICDCodeGet", new { id = ICDCodeEntity.ICDCodeID });
                _logger.LogInformation("New ICD Code Created ");
                return Created(newUri, _mapper.Map<ICDCodeModel>(ICDCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving ICD Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateICDCodePolicy)]
        public IActionResult Put([FromBody] ICDCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                ICDCode entity = _ICDCodeRepository.GetById(model.ICDCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _ICDCodeService.CheckIfExists(entity);
                if (!_ICDCodeService.BusinessState.IsValid)
                {
                    _ICDCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _ICDCodeRepository.Update(entity);
                if (!_ICDCodeRepository.DbState.IsValid)
                {
                    _ICDCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("ICD Code updated : {0}", entity.ICDCodeID);

                if(model.TermDate != null && model.HomeGrown != "Y")
                {
                    var homeGrownList = _ICDCodeRepository.GetByPredicate(x => x.HomeGrown == "Y" && x.MappedCode == entity.Code);
                    if(homeGrownList.Count() > 0)
                    {
                        foreach(var icdCodeObj in homeGrownList)
                        {
                            icdCodeObj.TermDate = entity.TermDate;
                            icdCodeObj.UpdatedDate = base.TodaysDate;
                            icdCodeObj.UpdatedBy = base.UserName;
                            icdCodeObj.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            icdCodeObj.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _ICDCodeService.CheckIfExists(icdCodeObj);
                            if (!_ICDCodeService.BusinessState.IsValid)
                            {
                                _ICDCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _ICDCodeRepository.Update(icdCodeObj);
                            if (!_ICDCodeRepository.DbState.IsValid)
                            {
                                _ICDCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("ICD Code updated : {0}", entity.ICDCodeID);
                        }
                    }
                }
                return Ok(entity.ICDCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating ICD Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                ICDCode entity = _ICDCodeRepository.GetById(id);
                _ICDCodeRepository.Delete(entity);
                if (!_ICDCodeRepository.DbState.IsValid)
                {
                    _ICDCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing ICD Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion CRUD
    }
}
