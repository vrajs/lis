using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/Specialty")]
    public class SpecialtyAPIController : BaseAPIController
    {
        private ISpecialtyRepository _SpecialtyRepository;
        public SpecialtyAPIController(ISpecialtyRepository specialtyRepository)
        {
            _SpecialtyRepository = specialtyRepository;
        }

        [HttpGet]
        [Route("GetSpecialties")]
        public IActionResult GetSpecialties()
        {
            var res = _SpecialtyRepository.GetSpecialties().ToList();
            return Ok(res);
        }

        [HttpGet("GetSpecialtiesKeyVal")]
        public IActionResult GetSpecialtiesKeyVal()
        {
            var res = _SpecialtyRepository.GetSpecialtiesKeyVal();
            return Ok(res);
        }
    }
}
