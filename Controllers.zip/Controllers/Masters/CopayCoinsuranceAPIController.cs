using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Linq.Expressions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/CopayCoinsurance")]
    public class CopayCoinsuranceAPIController : BaseAPIController
    {

        #region Variables
        private ILogger<CopayCoinsuranceAPIController> _logger;
        private ICopayCoinsuranceRepository _CopayCoinsuranceRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public CopayCoinsuranceAPIController(ICopayCoinsuranceRepository CopayCoinsuranceRepository, ILogger<CopayCoinsuranceAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _CopayCoinsuranceRepository = CopayCoinsuranceRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var copayCoinsuranceRes = _CopayCoinsuranceRepository.GetAllCopayCoinsurance().ToList();
            return Ok(copayCoinsuranceRes);
        }


        // GET api/values/5
        [HttpGet("{id}", Name = "CopayCoinsuranceGet")]
        public IActionResult Get(short id)
        {
            var copayCoinsurance = _CopayCoinsuranceRepository.GetByPredicate(x => x.CopayCoinsuranceID == id, new Expression<Func<CopayCoinsurance, object>>[] { x => x.MaxCopayPerDiemTimePeriod, y => y.MaxCopayTimePeriod }).Single();
            if (copayCoinsurance == null) return NotFound($"CopayCoinsurance {id} was not found");
            return Ok(_mapper.Map<CopayCoinsuranceModel>(copayCoinsurance));
        }


        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]CopayCoinsuranceModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var copayCoinsurance = _mapper.Map<CopayCoinsurance>(model);
                copayCoinsurance.CreatedDate = base.TodaysDate;
                copayCoinsurance.CreatedBy = base.UserName;
                copayCoinsurance.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, copayCoinsurance.EffectiveDate, copayCoinsurance.TermDate);
                copayCoinsurance.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, copayCoinsurance.EffectiveDate, copayCoinsurance.TermDate).ToString();

                _CopayCoinsuranceRepository.Add(copayCoinsurance);
                if (!_CopayCoinsuranceRepository.DbState.IsValid)
                {
                    _CopayCoinsuranceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("CopayCoinsuranceGet", new { id = copayCoinsurance.CopayCoinsuranceID });
                _logger.LogInformation("New Copay Coinsurance Created ");
                return Created(newUri, _mapper.Map<CopayCoinsuranceModel>(copayCoinsurance));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Copay Coinsurance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]CopayCoinsuranceModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);


            try
            {
                var oldCopayCoinsurance = _CopayCoinsuranceRepository.GetById(model.CopayCoinsuranceID);
                if (oldCopayCoinsurance == null) return NotFound($"Could not find a Copay Coinsurance with an CopayCoinsuranceID of {model.CopayCoinsuranceID}");

                _mapper.Map(model, oldCopayCoinsurance);
                oldCopayCoinsurance.UpdatedBy = base.UserName;
                oldCopayCoinsurance.UpdatedDate = base.TodaysDate;
                oldCopayCoinsurance.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldCopayCoinsurance.EffectiveDate, oldCopayCoinsurance.TermDate);
                oldCopayCoinsurance.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldCopayCoinsurance.EffectiveDate, oldCopayCoinsurance.TermDate).ToString();

                _CopayCoinsuranceRepository.Update(oldCopayCoinsurance);
                if (!_CopayCoinsuranceRepository.DbState.IsValid)
                {
                    _CopayCoinsuranceRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(model.CopayCoinsuranceID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Copay Coinsurance: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            _CopayCoinsuranceRepository.DeleteById(id);
            return Ok(id);
        }
        #endregion
    }
}
