using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class InterestQuickPayODController : BaseODController
    {
        #region Variables  
        private IInterestQuickPayRepository _interestQuickPayRepository;
        #endregion

        #region Constructor

        public InterestQuickPayODController(IInterestQuickPayRepository interestQuickPayRepository)
        {
            _interestQuickPayRepository = interestQuickPayRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("InterestQuickPays")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        //[Authorize(Policy = Authorization.Policies.ViewInterestQuickPayPolicy)]
        public IActionResult GetInterestQuickPays()
        {
            var interestQuickPayQuery = _interestQuickPayRepository.GetInterestQuickPays();
            return Ok(interestQuickPayQuery);
        }
    }
}
