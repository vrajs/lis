using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Masters
{
    //[Produces("application/json")]
    [Route("api/HomeGrownCode")]
    public class HomeGrownCodeAPIController : BaseAPIController
    {
        private ILogger<HomeGrownCodeAPIController> _logger;
        private IMapper _mapper;
        private IICDCodeRepository _ICDCodeRepository;
        private IICDCodeService _ICDCodeService;
        private ICPTCodeRepository _CPTCodeRepository;
        private ICPTCodeService _CPTCodeService;
        private IRevenueCodeRepository _revenueCodeRepository;
        private IRevenueCodeService _revenueCodeService;
        private IPOSCodeRepository _POSCodeRepository;
        private IPOSCodeService _POSCodeService;
        private INDCCodeRepository _NDCCodeRepository;
        private INDCCodeService _NDCCodeService;
        private IHomeGrownCodeRepository _homeGrownCodeRepository;

        public HomeGrownCodeAPIController(ILogger<HomeGrownCodeAPIController> logger, IMapper mapper,
                                        IICDCodeRepository iCDCodeRepository, IICDCodeService iCDCodeService,
                                        ICPTCodeRepository cPTCodeRepository, ICPTCodeService cPTCodeService,
                                        IRevenueCodeRepository revenueCodeRepository, IRevenueCodeService revenueCodeService,
                                        IPOSCodeRepository pOSCodeRepository, IPOSCodeService pOSCodeService,
                                        INDCCodeRepository nDCCodeRepository, INDCCodeService nDCCodeService,
                                        IHomeGrownCodeRepository homeGrownCodeRepository)
        {
            _logger = logger;
            _mapper = mapper;

            _ICDCodeRepository = iCDCodeRepository;
            _ICDCodeService = iCDCodeService;

            _CPTCodeRepository = cPTCodeRepository;
            _CPTCodeService = cPTCodeService;

            _revenueCodeRepository = revenueCodeRepository;
            _revenueCodeService = revenueCodeService;

            _POSCodeRepository = pOSCodeRepository;
            _POSCodeService = pOSCodeService;

            _NDCCodeRepository = nDCCodeRepository;
            _NDCCodeService = nDCCodeService;

            _homeGrownCodeRepository = homeGrownCodeRepository;
        }

        #region ICDCode
        [HttpGet]
        [Route("GetICDCodeList")]
        public IActionResult GetICDCodeList()
        {
            try
            {
                var ICDCodes = _ICDCodeRepository.GetByPredicate(null).ToList();
                return Ok(ICDCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting ICDCodes : {ex}");
                return BadRequest(ex.Message);
            }
        }

        #endregion ICDCode

        #region CPTCode
        [HttpGet]
        [Route("GetCPTCode")]
        public IActionResult GetCPTCode()
        {
            try
            {
                var cptCodes = _CPTCodeRepository.GetByPredicate(null).ToList();
                return Ok(cptCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting CPTCodes : {ex}");
                return BadRequest(ex.Message);
            }
        }

        #endregion CPTCode

        #region RevenueCode
        [HttpGet]
        [Route("GetRevenueCode")]
        public IActionResult GetRevenueCode()
        {
            try
            {
                var revenueCodes = _revenueCodeRepository.GetByPredicate(null).ToList();
                return Ok(revenueCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting RevenueCodes : {ex}");
                return BadRequest(ex.Message);
            }
        }

        #endregion RevenueCode

        #region POSCode
        [HttpGet]
        [Route("GetPOSCodeList")]
        public IActionResult GetPOSCodeList()
        {
            try
            {
                var POSCodes = _POSCodeRepository.GetByPredicate(null).ToList();
                return Ok(POSCodes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting POSCodes : {ex}");
                return BadRequest(ex.Message);
            }
        }
        #endregion POSCode

        #region Post
        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddHomeGrownCodePolicy)]
        public IActionResult Post([FromBody]HomeGrownCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Kwicle.Core.Common.ClinicalCodeType type = model.CodeTypeID.ToEnum<Kwicle.Core.Common.ClinicalCodeType>();
            try
            {
                switch (type)
                {
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMPCS:
                        {
                            ICDCode ICDCodeEntity = new ICDCode();
                            _mapper.Map(model, ICDCodeEntity);
                            ICDCodeEntity.CreatedDate = base.TodaysDate;
                            ICDCodeEntity.CreatedBy = base.UserName;
                            ICDCodeEntity.RecordStatus = (int)RecordStatus.Active;
                            ICDCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                            _ICDCodeService.CheckIfExists(ICDCodeEntity);

                            if (!_ICDCodeService.BusinessState.IsValid)
                            {
                                _ICDCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    this.ModelState.AddModelError(errormessage.Key, errormessage.Value);

                                });
                                return BadRequest(this.ModelState);
                            }

                            _ICDCodeRepository.Add(ICDCodeEntity);

                            if (!_ICDCodeRepository.DbState.IsValid)
                            {
                                _ICDCodeRepository.DbState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    ModelState.AddModelError(errormessage.Key, errormessage.Value);
                                });
                                return BadRequest(ModelState);
                            }

                            var newUri = Url.Link("GetHomeGrownCode", new { id = ICDCodeEntity.ICDCodeID, type = model.CodeTypeID });
                            _logger.LogInformation("New HomeGrownCode of Type {0} Created ", model.MappedCode);
                            model.HomeGrownCodeID = ICDCodeEntity.ICDCodeID;
                            return Created(newUri, model);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.CPT2:
                    case Kwicle.Core.Common.ClinicalCodeType.CPT4:
                    case Kwicle.Core.Common.ClinicalCodeType.Modifier:
                    case Kwicle.Core.Common.ClinicalCodeType.HCPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.HUGS:
                    case Kwicle.Core.Common.ClinicalCodeType.RUGS:                        
                        {
                            CPTCode cptCodeEntity = new CPTCode();
                            _mapper.Map(model, cptCodeEntity);
                            cptCodeEntity.CreatedDate = base.TodaysDate;
                            cptCodeEntity.CreatedBy = base.UserName;
                            cptCodeEntity.RecordStatus = (int)RecordStatus.Active;
                            cptCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                            _CPTCodeService.CheckIfExists(cptCodeEntity);
                            if (!_CPTCodeService.BusinessState.IsValid)
                            {
                                _CPTCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    this.ModelState.AddModelError(errormessage.Key, errormessage.Value);

                                });
                                return BadRequest(this.ModelState);
                            }

                            _CPTCodeRepository.Add(cptCodeEntity);

                            if (!_CPTCodeRepository.DbState.IsValid)
                            {
                                _CPTCodeRepository.DbState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    ModelState.AddModelError(errormessage.Key, errormessage.Value);
                                });
                                return BadRequest(ModelState);
                            }

                            var newUri = Url.Link("GetHomeGrownCode", new { id = cptCodeEntity.CPTCodeID, type = model.CodeTypeID });
                            _logger.LogInformation("New HomeGrownCode of Type {0} Created ", model.MappedCode);
                            model.HomeGrownCodeID = cptCodeEntity.CPTCodeID;
                            return Created(newUri, model);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.UBRevenue:
                    case Kwicle.Core.Common.ClinicalCodeType.UBCondition:
                    case Kwicle.Core.Common.ClinicalCodeType.UBOccurrence:
                    case Kwicle.Core.Common.ClinicalCodeType.UBTOB:
                    case Kwicle.Core.Common.ClinicalCodeType.UBValue:
                        {
                            RevenueCode revenueCodeEntity = new RevenueCode();
                            _mapper.Map(model, revenueCodeEntity);
                            revenueCodeEntity.CreatedDate = base.TodaysDate;
                            revenueCodeEntity.CreatedBy = base.UserName;
                            revenueCodeEntity.RecordStatus = (int)RecordStatus.Active;
                            revenueCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                            _revenueCodeService.CheckIfExists(revenueCodeEntity);
                            if (!_revenueCodeService.BusinessState.IsValid)
                            {
                                _revenueCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    this.ModelState.AddModelError(errormessage.Key, errormessage.Value);

                                });
                                return BadRequest(this.ModelState);
                            }

                            _revenueCodeRepository.Add(revenueCodeEntity);

                            if (!_revenueCodeRepository.DbState.IsValid)
                            {
                                _revenueCodeRepository.DbState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    ModelState.AddModelError(errormessage.Key, errormessage.Value);
                                });
                                return BadRequest(ModelState);
                            }

                            var newUri = Url.Link("GetHomeGrownCode", new { id = revenueCodeEntity.RevenueCodeID, type = model.CodeTypeID });
                            _logger.LogInformation("New HomeGrownCode of Type {0} Created ", model.MappedCode);
                            model.HomeGrownCodeID = revenueCodeEntity.RevenueCodeID;
                            return Created(newUri, model);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.POS:
                        {
                            POSCode POSCodeEntity = new POSCode();
                            _mapper.Map(model, POSCodeEntity);
                            POSCodeEntity.CreatedDate = base.TodaysDate;
                            POSCodeEntity.CreatedBy = base.UserName;
                            POSCodeEntity.RecordStatus = (int)RecordStatus.Active;
                            POSCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                            _POSCodeService.CheckIfExists(POSCodeEntity);

                            if (!_POSCodeService.BusinessState.IsValid)
                            {
                                _POSCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    this.ModelState.AddModelError(errormessage.Key, errormessage.Value);

                                });
                                return BadRequest(this.ModelState);
                            }

                            _POSCodeRepository.Add(POSCodeEntity);

                            if (!_POSCodeRepository.DbState.IsValid)
                            {
                                _POSCodeRepository.DbState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    ModelState.AddModelError(errormessage.Key, errormessage.Value);
                                });
                                return BadRequest(ModelState);
                            }

                            var newUri = Url.Link("GetHomeGrownCode", new { id = POSCodeEntity.POSCodeID, type = model.CodeTypeID });
                            _logger.LogInformation("New HomeGrownCode of Type {0} Created ", model.MappedCode);
                            model.HomeGrownCodeID = POSCodeEntity.POSCodeID;
                            return Created(newUri, model);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.NDC9:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC10:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC11:
                        {
                            NDCCode NDCCodeEntity = new NDCCode();
                            _mapper.Map(model, NDCCodeEntity);
                            NDCCodeEntity.CreatedDate = base.TodaysDate;
                            NDCCodeEntity.CreatedBy = base.UserName;
                            NDCCodeEntity.RecordStatus = (int)RecordStatus.Active;
                            NDCCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                            _NDCCodeService.CheckIfExists(NDCCodeEntity);

                            if (!_NDCCodeService.BusinessState.IsValid)
                            {
                                _NDCCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    this.ModelState.AddModelError(errormessage.Key, errormessage.Value);

                                });
                                return BadRequest(this.ModelState);
                            }

                            _NDCCodeRepository.Add(NDCCodeEntity);

                            if (!_NDCCodeRepository.DbState.IsValid)
                            {
                                _NDCCodeRepository.DbState.ErrorMessages.ForEach((errormessage) =>
                                {
                                    ModelState.AddModelError(errormessage.Key, errormessage.Value);
                                });
                                return BadRequest(ModelState);
                            }

                            var newUri = Url.Link("GetHomeGrownCode", new { id = NDCCodeEntity.NDCCodeID, type = model.CodeTypeID });
                            _logger.LogInformation("New HomeGrownCode of Type {0} Created ", model.MappedCode);
                            model.HomeGrownCodeID = NDCCodeEntity.NDCCodeID;
                            return Created(newUri, model);
                        }
                    default:
                        return NotFound("Code type not found");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving HomeGrownCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion Post

        #region Put
        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateHomeGrownCodePolicy)]
        public IActionResult Put([FromBody] HomeGrownCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Kwicle.Core.Common.ClinicalCodeType type = model.CodeTypeID.ToEnum<Kwicle.Core.Common.ClinicalCodeType>();
            try
            {
                switch (type)
                {
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMPCS:
                        {
                            ICDCode entity = _ICDCodeRepository.GetById(model.HomeGrownCodeID);
                            _mapper.Map(model, entity);
                            entity.UpdatedDate = base.TodaysDate;
                            entity.UpdatedBy = base.UserName;
                            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _ICDCodeService.CheckIfExists(entity);
                            if (!_ICDCodeService.BusinessState.IsValid)
                            {
                                _ICDCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _ICDCodeRepository.Update(entity);
                            if (!_ICDCodeRepository.DbState.IsValid)
                            {
                                _ICDCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("Home Grown updated : {0}", entity.ICDCodeID);
                            return Ok(entity.ICDCodeID);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.CPT2:
                    case Kwicle.Core.Common.ClinicalCodeType.CPT4:
                    case Kwicle.Core.Common.ClinicalCodeType.Modifier:
                    case Kwicle.Core.Common.ClinicalCodeType.HCPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.HUGS:
                    case Kwicle.Core.Common.ClinicalCodeType.RUGS:
                        {
                            CPTCode entity = _CPTCodeRepository.GetById(model.HomeGrownCodeID);
                            _mapper.Map(model, entity);
                            entity.UpdatedDate = base.TodaysDate;
                            entity.UpdatedBy = base.UserName;
                            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _CPTCodeService.CheckIfExists(entity);
                            if (!_CPTCodeService.BusinessState.IsValid)
                            {
                                _CPTCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _CPTCodeRepository.Update(entity);
                            if (!_CPTCodeRepository.DbState.IsValid)
                            {
                                _CPTCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("HomeGrownCode updated : {0}", entity.CPTCodeID);
                            return Ok(entity.CPTCodeID);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.UBRevenue:
                    case Kwicle.Core.Common.ClinicalCodeType.UBCondition:
                    case Kwicle.Core.Common.ClinicalCodeType.UBOccurrence:
                    case Kwicle.Core.Common.ClinicalCodeType.UBTOB:
                    case Kwicle.Core.Common.ClinicalCodeType.UBValue:
                        {
                            RevenueCode entity = _revenueCodeRepository.GetById(model.HomeGrownCodeID);
                            _mapper.Map(model, entity);
                            entity.UpdatedDate = base.TodaysDate;
                            entity.UpdatedBy = base.UserName;
                            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _revenueCodeService.CheckIfExists(entity);
                            if (!_revenueCodeService.BusinessState.IsValid)
                            {
                                _revenueCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _revenueCodeRepository.Update(entity);
                            if (!_revenueCodeRepository.DbState.IsValid)
                            {
                                _revenueCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("HomeGrownCode updated : {0}", entity.RevenueCodeID);
                            return Ok(entity.RevenueCodeID);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.POS:
                        {
                            POSCode entity = _POSCodeRepository.GetById(model.HomeGrownCodeID);
                            _mapper.Map(model, entity);
                            entity.UpdatedDate = base.TodaysDate;
                            entity.UpdatedBy = base.UserName;
                            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _POSCodeService.CheckIfExists(entity);
                            if (!_POSCodeService.BusinessState.IsValid)
                            {
                                _POSCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _POSCodeRepository.Update(entity);
                            if (!_POSCodeRepository.DbState.IsValid)
                            {
                                _POSCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("HomeGrownCode updated : {0}", entity.POSCodeID);
                            return Ok(entity.POSCodeID);
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.NDC9:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC10:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC11:
                        {
                            NDCCode entity = _NDCCodeRepository.GetById(model.HomeGrownCodeID);
                            _mapper.Map(model, entity);
                            entity.UpdatedDate = base.TodaysDate;
                            entity.UpdatedBy = base.UserName;
                            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                            _NDCCodeService.CheckIfExists(entity);
                            if (!_NDCCodeService.BusinessState.IsValid)
                            {
                                _NDCCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                                {
                                    ModelState.AddModelError(businessState.Key, businessState.Value);
                                });
                                return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                            }

                            _NDCCodeRepository.Update(entity);
                            if (!_NDCCodeRepository.DbState.IsValid)
                            {
                                _NDCCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                            _logger.LogInformation("HomeGrownCode updated : {0}", entity.NDCCodeID);
                            return Ok(entity.NDCCodeID);
                        }
                    default:
                        return NotFound("Code type not found");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating HomeGrownCode : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion Put

        #region GetById
        [HttpGet("{id}/{type}", Name = "GetHomeGrownCode")]
        [Authorize(Policy = Authorization.Policies.ViewHomeGrownCodePolicy)]
        public IActionResult Get(int id, int type)
        {
            Kwicle.Core.Common.ClinicalCodeType TypeID = type.ToEnum<Kwicle.Core.Common.ClinicalCodeType>();
            try
            {
                switch (TypeID)
                {
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMPCS:
                        {
                            var icdCode = _ICDCodeRepository.GetById(id);
                            if (icdCode == null)
                                return NotFound($"ICDCode with {id} was not found");
                            else
                            {
                                HomeGrownCodeModel model = new HomeGrownCodeModel();
                                _mapper.Map(icdCode, model);
                                var mappedCode = _ICDCodeRepository.GetByPredicate(x => x.Code == model.MappedCode).FirstOrDefault();
                                if (mappedCode != null)
                                {
                                    model.StandardCodeEffectiveDate = mappedCode.EffectiveDate;
                                    model.StandardCodeTermDate = mappedCode.TermDate == DateTime.MaxValue.Date ? (DateTime?)null : mappedCode.TermDate.Date;
                                }

                                return Ok(model);
                            }


                        }
                    case Kwicle.Core.Common.ClinicalCodeType.CPT2:
                    case Kwicle.Core.Common.ClinicalCodeType.CPT4:
                    case Kwicle.Core.Common.ClinicalCodeType.Modifier:
                    case Kwicle.Core.Common.ClinicalCodeType.HCPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.HUGS:
                    case Kwicle.Core.Common.ClinicalCodeType.RUGS:
                        {
                            var cptCode = _CPTCodeRepository.GetById(id);
                            if (cptCode == null) return NotFound($"CPTCode with {id} was not found");
                            else
                            {
                                HomeGrownCodeModel model = new HomeGrownCodeModel();
                                _mapper.Map(cptCode, model);
                                var mappedCode = _CPTCodeRepository.GetByPredicate(x => x.Code == model.MappedCode).FirstOrDefault();
                                if (mappedCode != null)
                                {
                                    model.StandardCodeEffectiveDate = mappedCode.EffectiveDate;
                                    model.StandardCodeTermDate = mappedCode.TermDate == DateTime.MaxValue.Date ? (DateTime?)null : mappedCode.TermDate.Date;
                                }
                                return Ok(model);
                            }
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.UBRevenue:
                    case Kwicle.Core.Common.ClinicalCodeType.UBCondition:
                    case Kwicle.Core.Common.ClinicalCodeType.UBOccurrence:
                    case Kwicle.Core.Common.ClinicalCodeType.UBTOB:
                    case Kwicle.Core.Common.ClinicalCodeType.UBValue:
                        {
                            var revenueCode = _revenueCodeRepository.GetById(id);
                            if (revenueCode == null) return NotFound($"RevenueCode with {id} was not found");
                            else
                            {
                                HomeGrownCodeModel model = new HomeGrownCodeModel();
                                _mapper.Map(revenueCode, model);
                                var mappedCode = _revenueCodeRepository.GetByPredicate(x => x.Code == model.MappedCode).FirstOrDefault();
                                if (mappedCode != null)
                                {
                                    model.StandardCodeEffectiveDate = mappedCode.EffectiveDate;
                                    model.StandardCodeTermDate = mappedCode.TermDate == DateTime.MaxValue.Date ? (DateTime?)null : mappedCode.TermDate.Date;
                                }
                                return Ok(model);
                            }

                        }
                    case Kwicle.Core.Common.ClinicalCodeType.POS:
                        {
                            var posCode = _POSCodeRepository.GetById(id);
                            if (posCode == null) return NotFound($"POSCode with {id} was not found");
                            else
                            {
                                HomeGrownCodeModel model = new HomeGrownCodeModel();
                                _mapper.Map(posCode, model);
                                var mappedCode = _POSCodeRepository.GetByPredicate(x => x.Code == model.MappedCode).FirstOrDefault();
                                if (mappedCode != null)
                                {
                                    model.StandardCodeEffectiveDate = mappedCode.EffectiveDate;
                                    model.StandardCodeTermDate = mappedCode.TermDate == DateTime.MaxValue.Date ? (DateTime?)null : mappedCode.TermDate.Date;
                                }
                                return Ok(model);
                            }
                        }
                    case Kwicle.Core.Common.ClinicalCodeType.NDC9:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC10:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC11:
                        {
                            var ndcCode = _NDCCodeRepository.GetById(id);
                            if (ndcCode == null) return NotFound($"NDCCode with {id} was not found");
                            else
                            {
                                HomeGrownCodeModel model = new HomeGrownCodeModel();
                                _mapper.Map(ndcCode, model);
                                var mappedCode = _NDCCodeRepository.GetByPredicate(x => x.Code == model.MappedCode).FirstOrDefault();
                                if (mappedCode != null)
                                {
                                    model.StandardCodeEffectiveDate = mappedCode.EffectiveDate;
                                    model.StandardCodeTermDate = mappedCode.TermDate == DateTime.MaxValue.Date ? (DateTime?)null : mappedCode.TermDate.Date;
                                }
                                return Ok(model);
                            }
                        }
                }
                return null;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion GetById

        #region Delete
        [HttpDelete("{id}/{type}")]        
        [Authorize(Policy = Authorization.Policies.DeleteHomeGrownCodePolicy)]
        public IActionResult Delete(int id, int type)
        {
            Kwicle.Core.Common.ClinicalCodeType TypeID = type.ToEnum<Kwicle.Core.Common.ClinicalCodeType>();
            try
            {
                switch (TypeID)
                {
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD9CMPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMDX:
                    case Kwicle.Core.Common.ClinicalCodeType.ICD10CMPCS:
                        {
                            _ICDCodeRepository.DeleteById(id, base.UserName, base.TodaysDate);
                            if (!_ICDCodeRepository.DbState.IsValid)
                            {
                                _ICDCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        break;
                    case Kwicle.Core.Common.ClinicalCodeType.CPT2:
                    case Kwicle.Core.Common.ClinicalCodeType.CPT4:
                    case Kwicle.Core.Common.ClinicalCodeType.Modifier:
                    case Kwicle.Core.Common.ClinicalCodeType.HCPCS:
                    case Kwicle.Core.Common.ClinicalCodeType.HUGS:
                    case Kwicle.Core.Common.ClinicalCodeType.RUGS:
                        {
                            _CPTCodeRepository.DeleteById(id, base.UserName, base.TodaysDate);
                            if (!_CPTCodeRepository.DbState.IsValid)
                            {
                                _CPTCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        break;
                    case Kwicle.Core.Common.ClinicalCodeType.UBRevenue:
                    case Kwicle.Core.Common.ClinicalCodeType.UBCondition:
                    case Kwicle.Core.Common.ClinicalCodeType.UBOccurrence:
                    case Kwicle.Core.Common.ClinicalCodeType.UBTOB:
                    case Kwicle.Core.Common.ClinicalCodeType.UBValue:
                        {
                            _revenueCodeRepository.DeleteById(id, base.UserName, base.TodaysDate);
                            if (!_revenueCodeRepository.DbState.IsValid)
                            {
                                _revenueCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        break;
                    case Kwicle.Core.Common.ClinicalCodeType.POS:
                        {
                            _POSCodeRepository.DeleteById(id, base.UserName, base.TodaysDate);
                            if (!_POSCodeRepository.DbState.IsValid)
                            {
                                _POSCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        break;
                    case Kwicle.Core.Common.ClinicalCodeType.NDC9:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC10:
                    case Kwicle.Core.Common.ClinicalCodeType.NDC11:
                        {
                            _NDCCodeRepository.DeleteById(id, base.UserName, base.TodaysDate);
                            if (!_NDCCodeRepository.DbState.IsValid)
                            {
                                _NDCCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                                {
                                    this.ModelState.AddModelError(error.Key, error.Value);
                                });
                                return BadRequest(this.ModelState);
                            }
                        }
                        break;
                }

                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing Home Grown Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion Delete

        #region Other Methods
        [HttpPost]
        [Route("GetHomeGrownCodeForStandardCode")]
        public IActionResult GetHomeGrownCodeForStandardCode([FromBody]vwHomeGrownCodeList homeGrownCode)
        {
            try
            {
                if (!string.IsNullOrEmpty(homeGrownCode.MappedCode))
                {
                    var result = _homeGrownCodeRepository.GetHomeGrownCodes(0).Where(x => x.MappedCode == homeGrownCode.MappedCode).ToList();
                    if (result.Count > 0)
                    {
                        return Ok(true);
                    }
                    else
                    {
                        return Ok(false);   
                    }

                }
                return BadRequest();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion Other Methods
    }
}
