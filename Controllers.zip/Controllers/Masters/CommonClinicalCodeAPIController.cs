using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/CommonClinicalCode")]
    public class CommonClinicalCodeAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<CommonClinicalCodeAPIController> _logger;
        private ICommonClinicalCodeRepository _CommonClinicalCodeRepository;
        private ICommonClinicalCodeService _CommonClinicalCodeService;

        private IMapper _mapper;
        #endregion

        #region Ctor        
        public CommonClinicalCodeAPIController(ICommonClinicalCodeService CommonClinicalCodeService, ICommonClinicalCodeRepository CommonClinicalCodeRepository, ILogger<CommonClinicalCodeAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _CommonClinicalCodeRepository = CommonClinicalCodeRepository;
            _mapper = mapper;
            _CommonClinicalCodeService = CommonClinicalCodeService;
        }
        #endregion

        #region API Methods        
        [HttpGet("CheckCommonClinicalCode/{ClinicalCodeTypeID}/{Code}", Name = "CommonClinicalCodeGet")]
        public IActionResult CheckCommonClinicalCode(int ClinicalCodeTypeID, string Code)
        {
            try
            {
                var query = _CommonClinicalCodeRepository.CheckCommonClinicalCode(ClinicalCodeTypeID, Code);
                return Json(Ok(query.AsQueryable().Cast<object>().Any()));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while fetching code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("CheckCodeValidity")]
        public IActionResult CheckCodeValidity(int ClinicalCodeTypeID, string MinCode, string MaxCode, DateTime ValidationDate, ValidityCheck ValidityMode)
        {
            try
            {
                MinCodeMaxCodeValidityModel minCodeMaxCodeValidityModel = _CommonClinicalCodeRepository.CheckCodeValidity(ClinicalCodeTypeID, MinCode, MaxCode, ValidationDate, ValidityMode);
                return Ok(minCodeMaxCodeValidityModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while fetching code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("CheckCommonClinicalCodeEffective")]
        public IActionResult CheckCommonClinicalCodeEffective(int ClinicalCodeTypeID, string Code, DateTime EffectiveDate, DateTime TermDate)
        {

            try
            {
                var query = _CommonClinicalCodeService.CheckCommonClinicalCodeEffective(ClinicalCodeTypeID, Code, EffectiveDate, TermDate);
                return Ok(query);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while fetching code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("CheckCode/{ClinicalCodeTypeID}/{Code}")]
        public IActionResult CheckCode(string ClinicalCodeTypeID, string Code)
        {
            try
            {
                var clinicalCodeTypes = ClinicalCodeTypeID.Split(',');
                var res = false;
                foreach (var item in clinicalCodeTypes)
                {
                    var query = _CommonClinicalCodeRepository.CheckCommonClinicalCode(int.Parse(item), Code);
                    if (query.Any())
                    {
                        res = true;
                        break;
                    }
                    else
                    {
                        res = false;
                    }
                }                
                return Json(Ok(res));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while fetching code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("CheckExistsCommonClinicalCodeUsed")]
        public IActionResult CheckExistsCommonClinicalCodeUsed(int ClinicalCodeTypeID, string Code, DateTime EffectiveDate, DateTime TermDate)
        {
            try
            {
                var ExistsCommonClinicalCodeUsed = _CommonClinicalCodeService.CheckExistsCommonClinicalCodeUsed(ClinicalCodeTypeID, Code, EffectiveDate, TermDate);
                return Ok(ExistsCommonClinicalCodeUsed);
            }
            catch (Exception ex)
            {
                _logger.LogError("CheckExistsCommonClinicalCodeUsed Error while fetching code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{Id}/{ClinicalCodeTypeID}")]
        public IActionResult Delete(int Id, int ClinicalCodeTypeID)
        {
            try
            {
                _CommonClinicalCodeService.Delete(ClinicalCodeTypeID, Id, base.UserName, base.TodaysDate);

                return Ok(Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
