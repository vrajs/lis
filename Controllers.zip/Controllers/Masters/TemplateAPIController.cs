using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Contracts.Masters;
using Kwicle.API.Controllers;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/Template")]
    public class TemplateAPIController : BaseAPIController
    {
        #region Property
        private IMapper _mapper;
        private ILogger<TemplateAPIController> _logger;
        private readonly ITemplateRepository _TemplateRepository;
        #endregion

        #region Constructor
        public TemplateAPIController(IMapper mapper, ILogger<TemplateAPIController> logger, ITemplateRepository templateRepository)
        {
            this._mapper = mapper;
            this._logger = logger;
            this._TemplateRepository = templateRepository;
        }
        #endregion

        #region API Methods
        [HttpGet("GetTemplate/{SubTypeName}")]
        public IActionResult GetTemplate(string SubTypeName)
        {
            try
            {
               var  templates = _TemplateRepository.GetTemplate(SubTypeName);
                return Json(templates);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
