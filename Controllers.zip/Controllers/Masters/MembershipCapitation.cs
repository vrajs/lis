using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Data.Contracts.View;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;
using Kwicle.Common.Utility;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/MembershipCapitation")]
    public class MembershipCapitationController : BaseAPIController
    {
        #region Variables
        private ILogger<MembershipCapitationController> _logger;
        private IMembershipCapitationRepository _MembershipCapitationRepository;
        private IMembershipCapitationService _MembershipCapitationService;

        private IViewRepository _ViewRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public MembershipCapitationController(IMembershipCapitationRepository membershipCapitationRepository, ILogger<MembershipCapitationController> logger, IMapper mapper, IViewRepository viewRepository,
            IMembershipCapitationService MembershipCapitationService)
        {
            _logger = logger;
            _MembershipCapitationRepository = membershipCapitationRepository;
            _mapper = mapper;
            _ViewRepository = viewRepository;
            _MembershipCapitationService = MembershipCapitationService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("{id}", Name = "MembershipCapitationGet")]
        public IActionResult Get(int id)
        {
            var membershipCapitationRes = _ViewRepository.MembershipCapitations.Where(i => i.CapitationHeaderID == id && (i.RecordStatus != 3 && i.RecordStatus != 4));
            return Ok(membershipCapitationRes);
        }



        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]MembershipCapitation model)
        {
            model.CreatedDate = base.TodaysDate;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }            

            _MembershipCapitationService.Validate(model);
            if (!_MembershipCapitationService.BusinessState.IsValid)
            {
                _MembershipCapitationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });

                return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
            }
            try
            {
                model.TermDate = model.TermDate.ToTermDate();
                model.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate);
                model.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate).ToString();

                _MembershipCapitationRepository.Add(model);
                if (!_MembershipCapitationRepository.DbState.IsValid)
                {
                    _MembershipCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("MembershipCapitationGet", new { id = model.MembershipCapitationId });
                _logger.LogInformation("New Membership Capitation Created");
                return Created(newUri, _mapper.Map<MembershipCapitation>(model));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Membership Capitation : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]MembershipCapitation membershipCapitation)
        {
            //var oldMembershipCapitation = _MembershipCapitationRepository.GetById(membershipCapitation.MembershipCapitationId);
            //if (oldMembershipCapitation == null) return Json(NotFound($"Could not find a Membership Capitation with an Id of {membershipCapitation.MembershipCapitationId}"));
            //membershipCapitation.CreatedBy = oldMembershipCapitation.CreatedBy;
            //membershipCapitation.CreatedDate = oldMembershipCapitation.CreatedDate;
            //membershipCapitation.IsFreezed = oldMembershipCapitation.IsFreezed;
            //membershipCapitation.RecordStatus = oldMembershipCapitation.RecordStatus;
            //membershipCapitation.RecordStatusChangeComment = oldMembershipCapitation.RecordStatusChangeComment;

            //_mapper.Map(membershipCapitation, oldMembershipCapitation);


            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }            
            _MembershipCapitationService.Validate(membershipCapitation);
            if (!_MembershipCapitationService.BusinessState.IsValid)
            {
                _MembershipCapitationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });

                return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
            }
            try
            {
                membershipCapitation.UpdatedBy = base.UserName;
                membershipCapitation.UpdatedDate = base.TodaysDate;
                membershipCapitation.TermDate = membershipCapitation.TermDate.ToTermDate();
                membershipCapitation.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, membershipCapitation.EffectiveDate, membershipCapitation.TermDate);
                membershipCapitation.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, membershipCapitation.EffectiveDate, membershipCapitation.TermDate).ToString();

                _MembershipCapitationRepository.Update(membershipCapitation);
                if (!_MembershipCapitationRepository.DbState.IsValid)
                {
                    _MembershipCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(membershipCapitation.MembershipCapitationId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Membership Capitation: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _MembershipCapitationRepository.DeleteById(id, base.UserName, base.TodaysDate);
                if (!_MembershipCapitationRepository.DbState.IsValid)
                {
                    _MembershipCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {

                _logger.LogError($"Exception thrown while deleting Membership Capitation: {ex}");
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete]
        public IActionResult DeleteByReason(DeleteModel deleteModel)
        {
            _MembershipCapitationRepository.DeleteByReason(deleteModel);
            if (!_MembershipCapitationRepository.DbState.IsValid)
            {
                _MembershipCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(deleteModel);
        }
        #endregion  
    }
}
