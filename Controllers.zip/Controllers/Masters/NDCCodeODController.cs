using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class NDCCodeODController : BaseODController
    {
        #region Variables     

        private INDCCodeRepository _NDCCodeRepository;

        #endregion

        #region Constructor

        public NDCCodeODController(INDCCodeRepository nDCCodeRepository)
        {
            _NDCCodeRepository = nDCCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("NDCCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetNDCCodes(int? ClinicalCodeTypeID)
        {

            var CodeQuery = _NDCCodeRepository.GetNDCCodes(ClinicalCodeTypeID ?? 0);
            return Ok(CodeQuery);
        }        
    }
}
