using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class HCCCodeODController : BaseODController
    {
        #region Variables     

        private IHCCCodeRepository _HCCCodeRepository;

        #endregion

        #region Constructor

        public HCCCodeODController(IHCCCodeRepository hCCCodeRepository)
        {
            _HCCCodeRepository = hCCCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("HCCCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetHCCCodes(int? ClinicalCodeTypeID)
        {
            var HCCCodeQuery = _HCCCodeRepository.GetHCCCodes(ClinicalCodeTypeID??0);
            return Ok(HCCCodeQuery);
        }
    }
}
