using Microsoft.AspNetCore.Mvc;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class GPCIODController : BaseODController
    {
        #region Variables  
        private IGPCIRepository _gpciRepository;
        #endregion

        #region Constructor
        public GPCIODController(IGPCIRepository gpciRepository)
        {
            _gpciRepository = gpciRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GPCIs")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetGPCIs()
        {
            var gpciQuery = _gpciRepository.GetGPCIList();
            return Ok(gpciQuery);
        }
    }
}
