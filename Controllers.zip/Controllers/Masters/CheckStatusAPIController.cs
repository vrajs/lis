using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/CheckStatus")]
    public class CheckStatusAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundStatusAPIController> _logger;
        private ICheckStatusRepository _CheckStatusRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public CheckStatusAPIController(ILogger<RefundStatusAPIController> logger, ICheckStatusRepository CheckStatusRepository, IMapper mapper)
        {
            _logger = logger;
            _CheckStatusRepository = CheckStatusRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods        
        [HttpGet]
        [Route("GetAllStatus")]
        public IActionResult GetAll()
        {
            var refundStatus = _CheckStatusRepository.GetAllStatus();
            return Json(refundStatus);
        }
        #endregion
    }
}
