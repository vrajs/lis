using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Common;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Masters
{
    [Produces("application/json")]
    [Route("api/CommonCodeDisplayConfiguration")]
    public class CommonCodeDisplayConfigurationAPIController : BaseAPIController
    {
        private readonly ICommonCodeDisplayConfigurationRepository _commonCodeDisplayConfigurationRepository;
        private readonly ICommonCodeRepository _commonCodeRepository;
        private IMapper _mapper;
        private ILogger<CommonCodeDisplayConfigurationAPIController> _logger;

        public CommonCodeDisplayConfigurationAPIController(ICommonCodeDisplayConfigurationRepository commonCodeDisplayConfigurationRepository, ICommonCodeRepository commonCodeRepository, IMapper mapper, ILogger<CommonCodeDisplayConfigurationAPIController> logger)
        {
            _commonCodeDisplayConfigurationRepository = commonCodeDisplayConfigurationRepository;
            _commonCodeRepository = commonCodeRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet("")]
        [Authorize(Policy = Authorization.Policies.ViewCommonCodeDisplayConfigurationPolicy)]
        public IActionResult Get()
        {
            var commonCodeDisplayConfigurations = _commonCodeDisplayConfigurationRepository.GetByPredicate(x => true).ToList();
            return Ok(commonCodeDisplayConfigurations);
        }

        [HttpGet("GetCommonCodesByPageId/{pageID}")]
        public IActionResult GetCommonCodesByPageId(string pageId)
        {
            var commonCodeIDs = _commonCodeDisplayConfigurationRepository.GetByPredicate(x => x.PageId == pageId).Select(x => x.CommonCodeID).ToList();
            var commonCodes = _commonCodeRepository.GetCommonCodeList(0).Where(x => commonCodeIDs.Contains(x.CommonCodeID));
            return Ok(commonCodes);
        }

        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddCommonCodeDisplayConfigurationPolicy)]
        public IActionResult Post([FromBody]CommonCodeDisplayConfigurationModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var existingCommonCodeIDs = _commonCodeDisplayConfigurationRepository.GetByPredicate(x => x.PageId == model.PageId).Select(x => x.CommonCodeID).ToList();
                var listToInsert = model.CommonCodeIDList.Except(existingCommonCodeIDs).ToList();
                var listToDelete = existingCommonCodeIDs.Except(model.CommonCodeIDList).ToList();

                if (listToInsert.Count > 0)
                {
                    List<CommonCodeDisplayConfiguration> CommonCodeDisplayConfigurationList = listToInsert.Select(x => new CommonCodeDisplayConfiguration
                    {
                        PageId = model.PageId,
                        CreatedDate = base.TodaysDate,
                        CommonCodeID = x
                    }).ToList();

                    if (CommonCodeDisplayConfigurationList.Count > 0)
                    {
                        _commonCodeDisplayConfigurationRepository.InsertBunchOfCommonCodeDisplayConfiguration(CommonCodeDisplayConfigurationList);
                    }

                    _logger.LogInformation("New Common Code Display Configuration Created ");
                }

                if (listToDelete.Count > 0)
                {
                    List<CommonCodeDisplayConfiguration> CommonCodeDisplayConfigurationList = new List<CommonCodeDisplayConfiguration>();

                    CommonCodeDisplayConfigurationList = _commonCodeDisplayConfigurationRepository.GetDataCommonCodeDisplayConfigurationByCommonCodeIDs(listToDelete, model.PageId);

                    if (CommonCodeDisplayConfigurationList.Count > 0)
                    {
                        _commonCodeDisplayConfigurationRepository.DeleteBunchOfCommonCodeDisplayConfiguration(CommonCodeDisplayConfigurationList);
                    }

                }

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving common code display configuration : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
