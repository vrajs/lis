using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Data.Contracts.View;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/PlanCapitation")]
    public class PlanCapitationAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<PlanCapitationAPIController> _logger;
        private IPlanCapitationRepository _PlanCapitationRepository;
        private IViewRepository _ViewRepository;
        private IMapper _mapper;
        private IPlanCapitationService _PlanCapitationService;
        #endregion

        #region Ctor        
        public PlanCapitationAPIController(IPlanCapitationRepository planCapitationRepository, ILogger<PlanCapitationAPIController> logger, IMapper mapper, IViewRepository viewRepository, IPlanCapitationService planCapitationService)
        {
            _logger = logger;
            _PlanCapitationRepository = planCapitationRepository;
            _mapper = mapper;
            _ViewRepository = viewRepository;
            _PlanCapitationService = planCapitationService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var planCapitationRes = _ViewRepository.PlanCapitations.Where(i => i.CapitationHeaderID == id && (i.RecordStatus != (int)RecordStatus.Deleted && i.RecordStatus != (int)RecordStatus.VoidOrInvalid));
            return Ok(planCapitationRes);
        }

        // GET api/values/5
        //[HttpGet("{id}", Name = "PlanCapitationGet")]
        //public IActionResult GetById(int id)
        //{
        //    var planCapitation = _PlanCapitationRepository.GetById(id);
        //    if (planCapitation == null) return NotFound($"PlanCapitation {id} was not found");
        //    return Json(_mapper.Map<PlanCapitation>(planCapitation));
        //}

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]PlanCapitation planCapitation)
        {
            planCapitation.CreatedDate = base.TodaysDate;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                planCapitation.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, planCapitation.EffectiveDate, planCapitation.TermDate);
                planCapitation.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, planCapitation.EffectiveDate, planCapitation.TermDate).ToString();

                // Check data is exists into System or not.
                _PlanCapitationService.CheckDuplicateData(planCapitation);
                if (!_PlanCapitationService.BusinessState.IsValid)
                {
                    _PlanCapitationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _PlanCapitationRepository.Add(planCapitation);
                if (!_PlanCapitationRepository.DbState.IsValid)
                {
                    _PlanCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                //var newUri = Url.Link("PlanCapitationGet", new { id = model.CapitationPlanId });
                _logger.LogInformation("New Capitation Plan Created");
                return Created("", _mapper.Map<PlanCapitation>(planCapitation));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Plan Capitation : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]PlanCapitation planCapitation)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                PlanCapitation oldPlanCapitation = _PlanCapitationRepository.GetById(planCapitation.CapitationPlanId);
                if (oldPlanCapitation == null) return NotFound($"Could not find a PlanCapitation with an CapitationPlanId of {planCapitation.CapitationPlanId}");

                planCapitation.CreatedBy = oldPlanCapitation.CreatedBy;
                planCapitation.CreatedDate = oldPlanCapitation.CreatedDate;
                planCapitation.IsFreezed = oldPlanCapitation.IsFreezed;

                _mapper.Map(planCapitation, oldPlanCapitation);
                oldPlanCapitation.UpdatedBy = base.UserName;
                oldPlanCapitation.UpdatedDate = base.TodaysDate;
                oldPlanCapitation.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldPlanCapitation.EffectiveDate, oldPlanCapitation.TermDate);
                oldPlanCapitation.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldPlanCapitation.EffectiveDate, oldPlanCapitation.TermDate).ToString();

                // Check data is exists into System or not.
                _PlanCapitationService.CheckDuplicateData(planCapitation);
                if (!_PlanCapitationService.BusinessState.IsValid)
                {
                    _PlanCapitationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _PlanCapitationRepository.Update(oldPlanCapitation);
                if (!_PlanCapitationRepository.DbState.IsValid)
                {
                    _PlanCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(planCapitation.CapitationPlanId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating Fee Schedule: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _PlanCapitationRepository.DeleteById(id, base.UserName, base.TodaysDate);
                if (!_PlanCapitationRepository.DbState.IsValid)
                {
                    _PlanCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while deleting Plan Capitation: {ex}");
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete]
        public IActionResult DeleteByReason(DeleteModel deleteModel)
        {
            _PlanCapitationRepository.DeleteByReason(deleteModel);
            if (!_PlanCapitationRepository.DbState.IsValid)
            {
                _PlanCapitationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                {
                    ModelState.AddModelError(businessState.Key, businessState.Value);
                });
                return BadRequest(ModelState);
            }
            return Ok(deleteModel);
        }
        #endregion  
    }
}
