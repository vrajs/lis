using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using Microsoft.AspNetCore.OData.Query;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class RevenueCodeODController : BaseODController
    {
        #region Variables     

        private IRevenueCodeRepository _RevenueCodeRepository;

        #endregion

        #region Constructor

        public RevenueCodeODController(IRevenueCodeRepository RevenueCodeRepository)
        {
            _RevenueCodeRepository = RevenueCodeRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RevenueCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRevenueCodes()
        {
            var RevenueCodeQuery = _RevenueCodeRepository.GetRevenueCodes();
            return Ok(RevenueCodeQuery);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("RevenueUBCodes")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetRevenueUBCodes(string ClinicalCodeTypeID)
        {
            int[] arr = ClinicalCodeTypeID.Split(',').Select(n => Convert.ToInt32(n)).ToArray(); 
           
              var   RevenueCodeQuery = _RevenueCodeRepository.GetRevenueUBCodes(arr);
           
            return Ok(RevenueCodeQuery);
            
        }
    }
}
