using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Kwicle.Common.Utility;
using Kwicle.Core.Entities;
using System.Net;
using Kwicle.Business.Interfaces.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/FeeScheduleDetail")]
    public class FeeScheduleDetailAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<FeeScheduleDetailAPIController> _logger;
        private IFeeScheduleDetailRepository _feeScheduleDetailRepository;
        private IFeeScheduleDetailService _feeScheduleDetailService;
        private ICommonClinicalCodeService _commonClinicalCodeService;
        private IMapper _mapper;
        #endregion

        #region ctor
        public FeeScheduleDetailAPIController(ILogger<FeeScheduleDetailAPIController> logger, IMapper mapper, IFeeScheduleDetailRepository feeScheduleDetailRepository, IFeeScheduleDetailService feeScheduleDetailService, ICommonClinicalCodeService commonClinicalCodeService)
        {
            _logger = logger;
            _mapper = mapper;
            _feeScheduleDetailRepository = feeScheduleDetailRepository;
            _feeScheduleDetailService = feeScheduleDetailService;
            _commonClinicalCodeService = commonClinicalCodeService;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet]
        public IActionResult Get()
        {
            var feeScheduleDetailRes = _feeScheduleDetailRepository.GetByPredicateIgnoreQueryFilters(x => x.RecordStatus == (int)RecordStatus.Active);
            return Ok(feeScheduleDetailRes.ToList());
        }

        // GET api/values/5
        [HttpGet("{id}", Name = "FeeScheduleDetailGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var feeScheduleDetail = _feeScheduleDetailRepository.GetById(id);
                if (feeScheduleDetail == null) return NotFound($"FeeScheduleDetail with {id} was not found");
                return Ok(_mapper.Map<FeeScheduleDetailModel>(feeScheduleDetail));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] FeeScheduleDetailModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                FeeScheduleDetail entity = _mapper.Map<FeeScheduleDetail>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _commonClinicalCodeService.IsCommonClinicalCodeEffective(entity.ClinicalCodeTypeID.ToString(), entity.Code, entity.EffectiveDate, entity.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _feeScheduleDetailService.CheckIfExists(entity);
                if (!_feeScheduleDetailService.BusinessState.IsValid)
                {
                    _feeScheduleDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _feeScheduleDetailRepository.Add(entity);

                if (!_feeScheduleDetailRepository.DbState.IsValid)
                {
                    _feeScheduleDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("FeeScheduleDetailGet", new { id = entity.FeeScheduleDetailID });
                _logger.LogInformation("New FeeScheduleDetail created");
                return Created(newUri, _mapper.Map<FeeScheduleDetailModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving feeScheduleDetail : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] FeeScheduleDetailModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                FeeScheduleDetail entity = _feeScheduleDetailRepository.GetById(model.FeeScheduleDetailID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _commonClinicalCodeService.IsCommonClinicalCodeEffective(entity.ClinicalCodeTypeID.ToString(), entity.Code, entity.EffectiveDate, entity.TermDate);

                if (!_commonClinicalCodeService.BusinessState.IsValid)
                {
                    _commonClinicalCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return StatusCode((int)HttpStatusCode.NotAcceptable, ModelState);
                }

                _feeScheduleDetailService.CheckIfExists(entity);
                if (!_feeScheduleDetailService.BusinessState.IsValid)
                {
                    _feeScheduleDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _feeScheduleDetailRepository.Update(entity);
                if (!_feeScheduleDetailRepository.DbState.IsValid)
                {
                    _feeScheduleDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("FeeScheduleDetail updated : {0}", entity.FeeScheduleDetailID);
                return Ok(entity.FeeScheduleDetailID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating feeScheduleDetail : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                FeeScheduleDetail entity = _feeScheduleDetailRepository.GetById(id);
                _feeScheduleDetailRepository.Delete(entity);
                if (!_feeScheduleDetailRepository.DbState.IsValid)
                {
                    _feeScheduleDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing feeScheduleDetail : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
        #endregion
    }
}
