using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/DRGGroup")]
    public class DRGGroupAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<DRGGroupAPIController> _logger;
        private IDRGGroupRepository _dRGGroupRepository;
        private IMapper _mapper;
        #endregion

        #region ctor
        public DRGGroupAPIController(ILogger<DRGGroupAPIController> logger, IMapper mapper, IDRGGroupRepository dRGGroupRepository)
        {
            _logger = logger;
            _mapper = mapper;
            _dRGGroupRepository = dRGGroupRepository;
        }
        #endregion

        #region API Methods
        // GET: api/values
        [HttpGet("")]
        public IActionResult Get()
        {
            var query = _dRGGroupRepository.GetByPredicate(i => i.RecordStatus != (int)RecordStatus.VoidOrInvalid && i.RecordStatus != (int)RecordStatus.Deleted);
            var result = query.ToList();
            return Ok(result);
        }

        [HttpGet("Hierarchical")]
        public IActionResult GetHierarchical()
        {
            var query = _dRGGroupRepository.GetByPredicate(i => i.RecordStatus != (int)RecordStatus.VoidOrInvalid && i.RecordStatus != (int)RecordStatus.Deleted, i => i.DRGGroupHeaderID);
            var result = query.ToList();
            return Ok(result);
        }
        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]DRGGroupHeader model)
        {
            model.CreatedDate = base.TodaysDate;

            if (!ModelState.IsValid)
                return BadRequest(ModelState);


            try
            {
                model.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate);
                model.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, model.EffectiveDate, model.TermDate).ToString();

                _dRGGroupRepository.Add(model);
                if (!_dRGGroupRepository.DbState.IsValid)
                {
                    _dRGGroupRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }

                var newUri = Url.Link("DRGGroupGet", new { id = model.DRGGroupHeaderID });
                _logger.LogInformation("New DRG Group Created");
                return Created(newUri, _mapper.Map<DRGGroupHeader>(model));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving DRG Group : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]DRGGroupHeader drgGroupHeader)
        {
            //var oldDRGGroup = _dRGGroupRepository.GetById(drgGroup.DRGGroupID);
            //if (oldDRGGroup == null) return NotFound($"Could not find a DRG Group with an Id of {drgGroup.DRGGroupID}");
            //drgGroup.CreatedBy = oldDRGGroup.CreatedBy;
            //drgGroup.CreatedDate = oldDRGGroup.CreatedDate;
            //drgGroup.IsFreezed = oldDRGGroup.IsFreezed;
            //drgGroup.RecordStatus = oldDRGGroup.RecordStatus;
            //drgGroup.RecordStatusChangeComment = oldDRGGroup.RecordStatusChangeComment;

            //_mapper.Map(drgGroup, oldDRGGroup);


            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                drgGroupHeader.UpdatedBy = base.UserName;
                drgGroupHeader.UpdatedDate = base.TodaysDate;
                drgGroupHeader.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, drgGroupHeader.EffectiveDate, drgGroupHeader.TermDate);
                drgGroupHeader.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, drgGroupHeader.EffectiveDate, drgGroupHeader.TermDate).ToString();

                _dRGGroupRepository.Update(drgGroupHeader);
                if (!_dRGGroupRepository.DbState.IsValid)
                {
                    _dRGGroupRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });

                    return BadRequest(ModelState);
                }
                return Ok(drgGroupHeader.DRGGroupHeaderID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating DRG Group: {ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _dRGGroupRepository.DeleteById(id, base.UserName, base.TodaysDate);
                return Ok(id);
            }
            catch (Exception ex)
            {

                _logger.LogError($"Exception thrown while deleting DRG Group: {ex}");
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete]
        public IActionResult DeleteByReason(DeleteModel deleteModel)
        {
            _dRGGroupRepository.DeleteByReason(deleteModel);
            return Ok(deleteModel);
        }
        #endregion
    }
}
