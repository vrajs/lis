using Kwicle.Data.Contracts.Masters;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Masters
{
    [Route("odata")]
    public class InsuranceCarrierODController : BaseODController
    {
        #region Variables     
        private IInsuranceCarrierRepository _InsuranceCarrierRepository;
        #endregion

        #region Constructor
        public InsuranceCarrierODController(IInsuranceCarrierRepository insuranceCarrierRepository)
        {
            _InsuranceCarrierRepository = insuranceCarrierRepository;
        }
        #endregion

        #region API Methods
        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("InsuranceCarriers")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetInsuranceCarriers()
        {
            var query = _InsuranceCarrierRepository.GetInsuranceCarriers();
            return Ok(query);
        }
        #endregion
    }
}
