using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Masters;
using Microsoft.Extensions.Logging;
using Kwicle.Business.Interfaces.Common;
using Kwicle.Common.Utility;


namespace Kwicle.Service.Controllers.Masters
{
    [Route("api/RefundStatus")]
    public class RefundStatusAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<RefundStatusAPIController> _logger;
        private IRefundStatusRepository _RefundStatusRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor
        public RefundStatusAPIController(ILogger<RefundStatusAPIController> logger, IRefundStatusRepository refundStatusRepository, IMapper mapper)
        {
            _logger = logger;
            _RefundStatusRepository = refundStatusRepository;
            _mapper = mapper;
        }
        #endregion

        #region API Methods
        [HttpGet("GetAllStatus")]
        public IActionResult GetAll()
        {
            var refundStatus = _RefundStatusRepository.GetAllStatus();
            return Json(refundStatus);
        }
        #endregion
    }
}
