using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Masters;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Masters
{
    [Produces("application/json")]
    [Route("api/DRGCode")]
    public class DRGCodeAPIController : BaseAPIController
    {
        #region Variables     

        private IDRGCodeRepository _DRGCodeRepository;
        private IDRGCodeService _DRGCodeService;
        private ILogger<DRGCodeAPIController> _logger;
        private IMapper _mapper;

        #endregion

        #region Constructor

        public DRGCodeAPIController(IDRGCodeRepository dRGCodeRepository, IDRGCodeService dRGCodeService, ILogger<DRGCodeAPIController> logger, IMapper mapper)
        {
            _DRGCodeRepository = dRGCodeRepository;
            _DRGCodeService = dRGCodeService;
            _logger = logger;
            _mapper = mapper;
        }

        #endregion

        [HttpGet("{id}", Name = "DRGCodeGet")]
        [Authorize(Policy = Authorization.Policies.ViewDRGCodePolicy)]
        public IActionResult Get(int Id)
        {
            try
            {
                var result = _DRGCodeRepository.GetById(Id);
                if (result == null) return NotFound($"DRG Code {Id} was not found");
                return Ok(_mapper.Map<DRGCodeModel>(result));
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        [Authorize(Policy = Authorization.Policies.AddDRGCodePolicy)]
        public IActionResult Post([FromBody]DRGCodeModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var DRGCodeEntity = _mapper.Map<DRGCode>(model);
                DRGCodeEntity.CreatedDate = base.TodaysDate;
                DRGCodeEntity.CreatedBy = base.UserName;
                DRGCodeEntity.RecordStatus = (int)RecordStatus.Active;
                DRGCodeEntity.RecordStatusChangeComment = RecordStatus.Active.ToString();

                _DRGCodeService.CheckIfExists(DRGCodeEntity);

                if (!_DRGCodeService.BusinessState.IsValid)
                {
                    _DRGCodeService.BusinessState.ErrorMessages.ForEach((errormessage) =>
                    {
                        this.ModelState.AddModelError(errormessage.Key, errormessage.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                _DRGCodeRepository.Add(DRGCodeEntity);
                var newUri = Url.Link("DRGCodeGet", new { id = DRGCodeEntity.DRGCodeID });
                _logger.LogInformation("New DRG Code Created ");
                return Created(newUri, _mapper.Map<DRGCodeModel>(DRGCodeEntity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving DRG Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Authorize(Policy = Authorization.Policies.UpdateDRGCodePolicy)]
        public IActionResult Put([FromBody] DRGCodeModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                DRGCode entity = _DRGCodeRepository.GetById(model.DRGCodeID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _DRGCodeService.CheckIfExists(entity);
                if (!_DRGCodeService.BusinessState.IsValid)
                {
                    _DRGCodeService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _DRGCodeRepository.Update(entity);
                if (!_DRGCodeRepository.DbState.IsValid)
                {
                    _DRGCodeRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("DRG Code updated : {0}", entity.DRGCodeID);
                return Ok(entity.DRGCodeID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating DRG Code : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

    }
}
