using Kwicle.API.Controllers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Data.Contracts.Masters;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.CustomModel;

namespace Kwicle.Service.Controllers.Masters
{
    [Produces("application/json")]
    [Route("api/DBField")]
    public class DBFieldAPIController : BaseAPIController
    {
        #region Property
        private IDBFieldRepository _DBFieldRepository;
        private IMapper _Mapper;
        private ILogger<DBFieldAPIController> _Logger;
        #endregion

        #region Constructor
        public DBFieldAPIController(IMapper mapper, ILogger<DBFieldAPIController> logger, IDBFieldRepository dbFieldRepository)
        {
            _Mapper = mapper;
            _Logger = logger;
            _DBFieldRepository = dbFieldRepository;
        }
        #endregion

        #region Get Methods
        [HttpGet]
        [Route("GetValues/{DBFieldID}")]
        public IActionResult GetValues(int dbFieldID)
        {
            List<KeyVal<int, string>> valItems = _DBFieldRepository.GetValues(dbFieldID);
            return Ok(valItems);
        }
        #endregion
    }
}
