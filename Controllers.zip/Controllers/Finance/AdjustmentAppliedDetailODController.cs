using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class AdjustmentAppliedDetailODController : BaseODController
    {
        
        private IAdjustmentAppliedDetailRepository _adjustmentRepository;

        public AdjustmentAppliedDetailODController(IAdjustmentAppliedDetailRepository adjustmentRepository)
        {
            _adjustmentRepository = adjustmentRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetAdjustmentAppliedList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetAdjustmentAppliedList(int CheckDetailID)
        {
            var query = _adjustmentRepository.GetAdjustmentAppliedList(CheckDetailID);
            return Ok(query);
        }
    }
}
