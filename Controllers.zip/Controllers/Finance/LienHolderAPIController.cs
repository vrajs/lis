using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/LienHolder")]
    public class LienHolderAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<LienHolderAPIController> _logger;
        private readonly ILienHolderRepository _lienHolderDetailRepository;
        private readonly ILienHolderService _lienHolderDetailService;

        private IMapper _mapper;
        #endregion

        #region Ctor        
        public LienHolderAPIController(ILienHolderRepository lienHolderDetailRepository, ILogger<LienHolderAPIController> logger, IMapper mapper, ILienHolderService _lienHolderDetail)
        {
            _logger = logger;
            _lienHolderDetailRepository = lienHolderDetailRepository;
            _mapper = mapper;
            _lienHolderDetailService = _lienHolderDetail;
        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetLienHolder")]
        public IActionResult GetLienHolder(short id)
        {
            try
            {
                var result = _lienHolderDetailRepository.GetLienHolder(id);
                if (result == null) return NotFound($"LienHolder with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]LienHolderModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                LienHolder entity = _mapper.Map<LienHolder>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _lienHolderDetailService.CheckIfExists(entity);
                if (!_lienHolderDetailService.BusinessState.IsValid)
                {
                    _lienHolderDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _lienHolderDetailRepository.Add(entity);

                if (!_lienHolderDetailRepository.DbState.IsValid)
                {
                    _lienHolderDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("GetLienHolder", new { id = entity.LienHolderID });
                _logger.LogInformation("New lienHolderDetail created");
                return Created(newUri, _mapper.Map<LienHolderModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving lienHolderDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] LienHolderModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                LienHolder entity = _lienHolderDetailRepository.GetById(model.LienHolderID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _lienHolderDetailService.CheckIfExists(entity);
                if (!_lienHolderDetailService.BusinessState.IsValid)
                {
                    _lienHolderDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _lienHolderDetailRepository.Update(entity);
                if (!_lienHolderDetailRepository.DbState.IsValid)
                {
                    _lienHolderDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("LienHolder updated : {0}", entity.LienHolderID);
                return Ok(entity.LienHolderID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating lienHolderDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _lienHolderDetailRepository.DeleteById(id, base.UserName, base.TodaysDate);
                //_lienHolderDetailRepository.Update(entity);
                if (!_lienHolderDetailRepository.DbState.IsValid)
                {
                    _lienHolderDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing lienHolderDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion methods
    }

}
