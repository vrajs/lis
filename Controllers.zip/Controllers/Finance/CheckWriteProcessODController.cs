using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class CheckWriteProcessODController : BaseODController
    {
        private ICheckWriteProcessRepository _checkWriteProcessRepository;

        public CheckWriteProcessODController(ICheckWriteProcessRepository checkWriteProcessRepository)
        {
            _checkWriteProcessRepository = checkWriteProcessRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetCheckWriteProcessList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetcheckWriteProcessList()
        {
            var query = _checkWriteProcessRepository.GetVwCheckWriteProcessList();
            return Ok(query);
        }
    }
}
