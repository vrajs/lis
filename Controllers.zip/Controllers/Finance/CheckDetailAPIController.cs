using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/CheckDetail")]
    public class CheckDetailAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<CheckDetailAPIController> _logger;
        private readonly ICheckDetailRepository _checkDetailRepository;
        private readonly ICheckDetailService _checkDetailService;
        private readonly IAdjustmentAppliedDetailRepository _adjustmentAppliedDetailRepository;
        private readonly IPaymentTypeRepository _paymentTypeRepository;
        private readonly ICheckStatusRepository _checkStatusRepository;

        private IMapper _mapper;
        #endregion

        #region Ctor        
        public CheckDetailAPIController(ILogger<CheckDetailAPIController> logger, IMapper mapper, ICheckDetailService checkDetailService, ICheckDetailRepository checkDetailRepository, IAdjustmentAppliedDetailRepository adjustmentAppliedDetailRepository, IPaymentTypeRepository paymentTypeRepository, ICheckStatusRepository checkStatusRepository)
        {
            _logger = logger;
            _checkDetailRepository = checkDetailRepository;
            _mapper = mapper;
            _checkDetailService = checkDetailService;
            _adjustmentAppliedDetailRepository = adjustmentAppliedDetailRepository;
            _paymentTypeRepository = paymentTypeRepository;
            _checkStatusRepository = checkStatusRepository;
        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetCheckDetail")]
        public IActionResult GetCheckDetail(short id)
        {
            try
            {
                var result = _checkDetailRepository.GetCheckDetail(id);
                if (result == null) return NotFound($"CheckDetail with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        [Route("Save")]
        public IActionResult Post([FromBody]CheckDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                CheckDetail entity = _mapper.Map<CheckDetail>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _checkDetailService.CheckIfExists(entity);
                if (!_checkDetailService.BusinessState.IsValid)
                {
                    _checkDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _checkDetailRepository.Add(entity);

                if (!_checkDetailRepository.DbState.IsValid)
                {
                    _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("GetCheckDetail", new { id = entity.CheckDetailID });
                _logger.LogInformation("New checkDetailDetail created");


                //if (model.IsApplyPaymentType)
                //{
                //    AdjustmentAppliedDetail adjustmentAppliedDetail = _mapper.Map<AdjustmentAppliedDetail>(entity);
                //    adjustmentAppliedDetail.CreatedDate = base.TodaysDate;
                //    adjustmentAppliedDetail.CreatedBy = base.UserName;
                //    adjustmentAppliedDetail.RecordStatus = 0;
                //    adjustmentAppliedDetail.RecordStatusChangeComment = RecordStatus.Active.ToString();
                //    adjustmentAppliedDetail.AppliedDate = model.AppliedDate.HasValue ? model.AppliedDate.Value.Date : base.TodaysDate;

                //    _adjustmentAppliedDetailRepository.Add(adjustmentAppliedDetail);

                //    if (!_adjustmentAppliedDetailRepository.DbState.IsValid)
                //    {
                //        _adjustmentAppliedDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                //        {
                //            this.ModelState.AddModelError(error.Key, error.Value);
                //        });
                //        return BadRequest(this.ModelState);
                //    }
                //}

                return Created(newUri, _mapper.Map<CheckDetailModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving checkDetailDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] CheckDetailModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                CheckDetail entity = _checkDetailRepository.GetById(model.CheckDetailID);
                _mapper.Map(model, entity);                

                if (model.CheckStatusID == CheckStatus.Reissued.ToInteger())
                {
                    CheckDetail newCheckDetail = new CheckDetail();
                    newCheckDetail = entity;
                    newCheckDetail.CheckDetailID = 0;
                    newCheckDetail.CheckNumber = model.ReissueCheckNumber != null ? model.ReissueCheckNumber.Value : model.CheckNumber;
                    newCheckDetail.CreatedDate = base.TodaysDate;
                    newCheckDetail.CreatedBy = base.UserName;
                    newCheckDetail.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                    newCheckDetail.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                    _checkDetailService.CheckIfExists(newCheckDetail);
                    if (!_checkDetailService.BusinessState.IsValid)
                    {
                        _checkDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                        {
                            ModelState.AddModelError(businessState.Key, businessState.Value);
                        });
                        return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                    }

                    _checkDetailRepository.Add(newCheckDetail);

                    if (!_checkDetailRepository.DbState.IsValid)
                    {
                        _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }
                }

                if (model.CheckStatusID == CheckStatus.StopPayment.ToInteger())
                {
                    entity.StopPayDate = base.TodaysDate;
                }

                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _checkDetailService.CheckIfExists(entity);
                if (!_checkDetailService.BusinessState.IsValid)
                {
                    _checkDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _checkDetailRepository.Update(entity);
                if (!_checkDetailRepository.DbState.IsValid)
                {
                    _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("CheckDetail updated : {0}", entity.CheckDetailID);


                //if (model.IsApplyPaymentType)
                //{
                //    AdjustmentAppliedDetail adjustmentAppliedDetail = _mapper.Map<AdjustmentAppliedDetail>(entity);
                //    adjustmentAppliedDetail.CreatedDate = base.TodaysDate;
                //    adjustmentAppliedDetail.CreatedBy = base.UserName;
                //    adjustmentAppliedDetail.RecordStatus = 0;
                //    adjustmentAppliedDetail.RecordStatusChangeComment = RecordStatus.Active.ToString();
                //    adjustmentAppliedDetail.AppliedDate = model.AppliedDate.HasValue ? model.AppliedDate.Value.Date : base.TodaysDate;

                //    _adjustmentAppliedDetailRepository.Add(adjustmentAppliedDetail);

                //    if (!_adjustmentAppliedDetailRepository.DbState.IsValid)
                //    {
                //        _adjustmentAppliedDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                //        {
                //            this.ModelState.AddModelError(error.Key, error.Value);
                //        });
                //        return BadRequest(this.ModelState);
                //    }
                //}

                return Ok(entity.CheckDetailID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating checkDetailDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                //IQueryable<AdjustmentAppliedDetailModel> detailsObj = _adjustmentAppliedDetailRepository.GetAdjustmentAppliedDetailByAdjustmentID(id);
                //if (detailsObj != null)
                //{
                //    foreach (AdjustmentAppliedDetailModel obj in detailsObj)
                //    {
                //        _adjustmentAppliedDetailRepository.DeleteById(obj.AdjustmentAppliedDetailID, base.UserName, base.TodaysDate);
                //        if (!_adjustmentAppliedDetailRepository.DbState.IsValid)
                //        {
                //            _adjustmentAppliedDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                //            {
                //                this.ModelState.AddModelError(error.Key, error.Value);
                //            });
                //            return BadRequest(this.ModelState);
                //        }
                //    }
                //}

                _checkDetailRepository.DeleteById(id, base.UserName, base.TodaysDate);
                if (!_checkDetailRepository.DbState.IsValid)
                {
                    _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing checkDetailDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("VoidCheck")]
        public IActionResult VoidCheck([FromBody]int[] SelectedIDs)
        {
            var Ids = SelectedIDs;
            try
            {
                var checkList = _checkDetailRepository.GetByPredicate(x => Ids.Contains(x.CheckDetailID)).ToList();
                if (checkList != null)
                {
                    foreach (var x in checkList)
                    {
                        x.CheckStatusID = _checkStatusRepository.GetByPredicate(y => y.Code == "V").FirstOrDefault().CheckStatusID;
                        //x.StopPayDate = base.TodaysDate;
                        //x.PaymentTypeID = _paymentTypeRepository.GetByPredicate(y => y.Code == "V").FirstOrDefault().PaymentTypeID;
                        x.UpdatedDate = base.TodaysDate;
                        x.UpdatedBy = base.UserName;
                        x.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                        x.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                        _checkDetailService.CheckIfExists(x);
                        if (!_checkDetailService.BusinessState.IsValid)
                        {
                            _checkDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                            {
                                ModelState.AddModelError(businessState.Key, businessState.Value);
                            });
                            return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                        }

                        _checkDetailRepository.Update(x);
                        if (!_checkDetailRepository.DbState.IsValid)
                        {
                            _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating check : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        [Route("ReissueCheck")]
        public IActionResult ReissueCheck([FromBody]int[] SelectedIDs)
        {
            var Ids = SelectedIDs;
            try
            {
                var checkList = _checkDetailRepository.GetByPredicate(x => Ids.Contains(x.CheckDetailID)).ToList();
                if (checkList != null)
                {
                    foreach (var x in checkList)
                    {
                        x.CheckStatusID = _checkStatusRepository.GetByPredicate(y => y.Code == "R").FirstOrDefault().CheckStatusID;
                        //x.StopPayDate = base.TodaysDate;
                        //x.PaymentTypeID = _paymentTypeRepository.GetByPredicate(y => y.Code == "R").FirstOrDefault().PaymentTypeID;
                        x.UpdatedDate = base.TodaysDate;
                        x.UpdatedBy = base.UserName;
                        x.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                        x.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                        _checkDetailService.CheckIfExists(x);
                        if (!_checkDetailService.BusinessState.IsValid)
                        {
                            _checkDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                            {
                                ModelState.AddModelError(businessState.Key, businessState.Value);
                            });
                            return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                        }

                        _checkDetailRepository.Update(x);
                        if (!_checkDetailRepository.DbState.IsValid)
                        {
                            _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating check : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        [Route("StopPayCheck")]
        public IActionResult StopPayCheck([FromBody]int[] SelectedIDs)
        {
            var Ids = SelectedIDs;
            try
            {
                var checkList = _checkDetailRepository.GetByPredicate(x => Ids.Contains(x.CheckDetailID)).ToList();
                if (checkList != null)
                {
                    foreach (var x in checkList)
                    {
                        x.CheckStatusID = _checkStatusRepository.GetByPredicate(y => y.Code == "S").FirstOrDefault().CheckStatusID;
                        x.StopPayDate = base.TodaysDate;                        
                        x.UpdatedDate = base.TodaysDate;
                        x.UpdatedBy = base.UserName;
                        x.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                        x.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                        _checkDetailService.CheckIfExists(x);
                        if (!_checkDetailService.BusinessState.IsValid)
                        {
                            _checkDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                            {
                                ModelState.AddModelError(businessState.Key, businessState.Value);
                            });
                            return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                        }

                        _checkDetailRepository.Update(x);
                        if (!_checkDetailRepository.DbState.IsValid)
                        {
                            _checkDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating check : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion methods
    }

}
