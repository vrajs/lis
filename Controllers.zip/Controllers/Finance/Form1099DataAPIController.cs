using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/Form1099Data")]
    public class Form1099DataAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<Form1099DataAPIController> _logger;
        private readonly IForm1099DataRepository _form1099DataRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public Form1099DataAPIController(ILogger<Form1099DataAPIController> logger, IMapper mapper, IForm1099DataRepository form1099DataRepository)
        {
            _logger = logger;
            _mapper = mapper;
            _form1099DataRepository = form1099DataRepository;
        }
        #endregion

        #region methods
        [HttpGet("{id}", Name = "GetForm1099DataByProcessID")]
        public IActionResult GetForm1099DataByProcessID(int Id)
        {
            try
            {
                var result = _form1099DataRepository.GetForm1099DataByProcessID(Id);
                if (result == null) return NotFound($"Form1099Process with {Id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        #endregion methods
    }
}
