using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/AccountDetail")]
    public class AccountDetailAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<AccountDetailAPIController> _logger;
        private readonly IAccountDetailRepository _accountDetailRepository;
        private readonly IAccountDetailService _accountDetailService;
        private readonly IAccountDetailCompanyStructureRepository _accountDetailCompanyStructureRepository;

        private IMapper _mapper;
        #endregion

        #region Ctor        
        public AccountDetailAPIController(IAccountDetailRepository accountDetailRepository, ILogger<AccountDetailAPIController> logger, IMapper mapper, IAccountDetailService _accountDetail, IAccountDetailCompanyStructureRepository accountDetailCompanyStructureRepository)
        {
            _logger = logger;
            _accountDetailRepository = accountDetailRepository;
            _mapper = mapper;
            _accountDetailService = _accountDetail;
            _accountDetailCompanyStructureRepository = accountDetailCompanyStructureRepository;
        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetAccountDetail")]
        public IActionResult GetAccountDetail(short id)
        {
            try
            {
                var result = _accountDetailRepository.GetAccountDetail(id);
                if (result == null) return NotFound($"AccountDetail with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]AccountDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                AccountDetail entity = _mapper.Map<AccountDetail>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _accountDetailService.CheckIfExists(entity);
                if (!_accountDetailService.BusinessState.IsValid)
                {
                    _accountDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _accountDetailRepository.Add(entity);

                if (!_accountDetailRepository.DbState.IsValid)
                {
                    _accountDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("GetAccountDetail", new { id = entity.AccountDetailID });
                _logger.LogInformation("New accountDetail created");
                return Created(newUri, _mapper.Map<AccountDetailModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving accountDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] AccountDetailModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AccountDetail entity = _accountDetailRepository.GetById(model.AccountDetailID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _accountDetailService.CheckIfExists(entity);
                if (!_accountDetailService.BusinessState.IsValid)
                {
                    _accountDetailService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _accountDetailRepository.Update(entity);
                if (!_accountDetailRepository.DbState.IsValid)
                {
                    _accountDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("AccountDetail updated : {0}", entity.AccountDetailID);
                return Ok(entity.AccountDetailID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating accountDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                var companyAccount = _accountDetailCompanyStructureRepository.GetAccountDetailCompanyStructureByAccountDetailID(id).ToList();
                if (companyAccount.Count>0) {
                    this.ModelState.AddModelError("Can not delete", "Account already mapped, can not delete record.");
                    return BadRequest(this.ModelState);
                }
                   
                _accountDetailRepository.DeleteById(id, base.UserName, base.TodaysDate);
                //_accountDetailRepository.Update(entity);
                if (!_accountDetailRepository.DbState.IsValid)
                {
                    _accountDetailRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing accountDetail : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion methods
    }
}
