using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class BillParameterODController : BaseODController
    {
        #region Variables        
        private IBillParameterRepository _IBillParameterRepository;
        #endregion

        #region Ctor        
        public BillParameterODController(IBillParameterRepository IBillParameterRepository)
        {
            _IBillParameterRepository = IBillParameterRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("BillParameters")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetBillParameter(short BillParameterID)
        {
            var BillParameterQuery = _IBillParameterRepository.GetBillParameter(BillParameterID);
            return Ok(BillParameterQuery);
        }
    }
}

