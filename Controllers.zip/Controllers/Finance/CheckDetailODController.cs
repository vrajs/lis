using Microsoft.AspNetCore.Mvc;
using Kwicle.Service.Filters;
using Kwicle.Data.Contracts.View;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class CheckDetailODController : BaseODController
    {
        #region Variables  
        private IViewRepository _IViewRepository;
        private ICheckDetailRepository _checkDetailRepository;
        #endregion

        #region Constructor

        public CheckDetailODController(IViewRepository IViewRepository, ICheckDetailRepository checkDetailRepository)
        {
            _IViewRepository = IViewRepository;
            _checkDetailRepository = checkDetailRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("CheckHistoryList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult CheckHistoryList()
        {
            var query = _IViewRepository.CheckHistoryList;
            return Ok(query);
        }


        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetAdjustmentList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetAdjustmentList()
        {
            var query = _checkDetailRepository.GetAdjustmentList();
            return Ok(query);
        }

    }
}
