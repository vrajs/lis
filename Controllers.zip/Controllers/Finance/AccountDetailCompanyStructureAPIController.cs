using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Kwicle.Data.Contracts.OrganizationStructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/AccountDetailCompanyStructure")]
    public class AccountDetailCompanyStructureAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<AccountDetailCompanyStructureAPIController> _logger;
        private readonly IAccountDetailCompanyStructureRepository _accountDetailCompanyStructureRepository;
        private readonly IAccountDetailCompanyStructureService _accountDetailCompanyStructureService;
        private readonly IOrganizationRepository _organizationRepository;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public AccountDetailCompanyStructureAPIController(IAccountDetailCompanyStructureRepository accountDetailCompanyStructureRepository, ILogger<AccountDetailCompanyStructureAPIController> logger, IMapper mapper, IAccountDetailCompanyStructureService _accountDetailCompanyStructure, IOrganizationRepository organizationRepository)
        {
            _logger = logger;
            _accountDetailCompanyStructureRepository = accountDetailCompanyStructureRepository;
            _mapper = mapper;
            _accountDetailCompanyStructureService = _accountDetailCompanyStructure;
            _organizationRepository = organizationRepository;
        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetAccountDetailCompanyStructure")]
        public IActionResult GetAccountDetailCompanyStructure(short id)
        {
            try
            {
                var result = _accountDetailCompanyStructureRepository.GetAccountDetailCompanyStructure(id);
                if (result == null) return NotFound($"AccountDetailCompanyStructure with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]AccountDetailCompanyStructureModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                AccountDetailCompanyStructure entity = _mapper.Map<AccountDetailCompanyStructure>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.OrganizationID = (model.OrganizationID > 0) ? model.OrganizationID : _organizationRepository.GetByPredicate(x => x.OrganizationID == model.CompanyID && x.OrganizationTypeID == OrganizationType.Company.ToInteger()).FirstOrDefault().ParentOrganizationID;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _accountDetailCompanyStructureService.CheckIfExists(entity);
                if (!_accountDetailCompanyStructureService.BusinessState.IsValid)
                {
                    _accountDetailCompanyStructureService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _accountDetailCompanyStructureRepository.Add(entity);

                if (!_accountDetailCompanyStructureRepository.DbState.IsValid)
                {
                    _accountDetailCompanyStructureRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("GetAccountDetailCompanyStructure", new { id = entity.AccountDetailCompanyStructureID });
                _logger.LogInformation("New accountDetailCompanyStructure created");
                return Created(newUri, _mapper.Map<AccountDetailCompanyStructureModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving accountDetailCompanyStructure : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] AccountDetailCompanyStructureModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                AccountDetailCompanyStructure entity = _accountDetailCompanyStructureRepository.GetById(model.AccountDetailCompanyStructureID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _accountDetailCompanyStructureService.CheckIfExists(entity);
                if (!_accountDetailCompanyStructureService.BusinessState.IsValid)
                {
                    _accountDetailCompanyStructureService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _accountDetailCompanyStructureRepository.Update(entity);
                if (!_accountDetailCompanyStructureRepository.DbState.IsValid)
                {
                    _accountDetailCompanyStructureRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("AccountDetailCompanyStructure updated : {0}", entity.AccountDetailCompanyStructureID);
                return Ok(entity.AccountDetailCompanyStructureID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating accountDetailCompanyStructure : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                //AccountDetailCompanyStructure entity = _accountDetailCompanyStructureRepository.GetById(id);
                //if(entity != null)
                //{
                //    entity.UpdatedDate = base.TodaysDate;
                //    entity.UpdatedBy = base.UserName;
                //    entity.RecordStatus = 3;
                //    entity.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                    
                //}
                _accountDetailCompanyStructureRepository.DeleteById(id, base.UserName, base.TodaysDate);
                //_accountDetailCompanyStructureRepository.Update(entity);
                if (!_accountDetailCompanyStructureRepository.DbState.IsValid)
                {
                    _accountDetailCompanyStructureRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing accountDetailCompanyStructure : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion methods

    }
}
