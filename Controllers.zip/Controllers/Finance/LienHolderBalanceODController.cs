using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class LienHolderBalanceODController : BaseODController
    {
        private ILienHolderBalanceRepository _lienHolderBalanceRepository;

        public LienHolderBalanceODController(ILienHolderBalanceRepository lienHolderBalanceRepository)
        {
            _lienHolderBalanceRepository = lienHolderBalanceRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetLienAccountList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetAccountDetailList()
        {
            var query = _lienHolderBalanceRepository.GetLienAccountList();
            return Ok(query);
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetLienHolderBalanceAmountHistory")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetLienHolderBalanceAmountHistory()
        {
            var query = _lienHolderBalanceRepository.GetLienHolderBalanceAmountHistory();
            return Ok(query);
        }
    }
}
