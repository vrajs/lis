using System;
using System.Net;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/BillParameter")]
    public class BillParameterAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<BillParameterAPIController> _logger;
        private IBillParameterRepository _BillParameterRepository;
        private IBillParameterService _BillParameterService;
        private IMapper _mapper;
        #endregion

        #region Ctor        
        public BillParameterAPIController(IBillParameterRepository BillParameterRepository, IBillParameterService BillParameterService, ILogger<BillParameterAPIController> logger, IMapper mapper)
        {
            _logger = logger;
            _BillParameterRepository = BillParameterRepository;
            _BillParameterService = BillParameterService;
            _mapper = mapper;
        }
        #endregion


        //// GET: api/values
        //[HttpGet]
        //public IActionResult Get()
        //{
        //    try
        //    {
        //        var BillParameterRes = _BillParameterRepository.GetBillParameter();
        //        return Ok(BillParameterRes);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Exception thrown while getting Rate Code: {ex}");
        //        return BadRequest(ex.ToErrorMessage());
        //    }
        //}

        // GET api/values/5
        [HttpGet("{id}", Name = "BillParameterGet")]
        public IActionResult Get(short id)
        {
            try
            {
                var BillParameter = _BillParameterRepository.GetById(id);
                if (BillParameter == null) return NotFound($"BillParameter with {id} was not found");
                return Ok(_mapper.Map<BillParameterViewModel>(BillParameter));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] BillParameterViewModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                BillParameter entity = _mapper.Map<BillParameter>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _BillParameterService.CheckIfExists(entity);
                if (!_BillParameterService.BusinessState.IsValid)
                {
                    _BillParameterService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _BillParameterRepository.Add(entity);

                if (!_BillParameterRepository.DbState.IsValid)
                {
                    _BillParameterRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("BillParameterGet", new { id = entity.BillParameterID });
                _logger.LogInformation("New Rate Code Created");
                return Created(newUri, _mapper.Map<BillParameterViewModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving Bill Parameter : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] BillParameterViewModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                BillParameter entity = _BillParameterRepository.GetById(model.BillParameterID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _BillParameterService.CheckIfExists(entity);
                if (!_BillParameterService.BusinessState.IsValid)
                {
                    _BillParameterService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _BillParameterRepository.Update(entity);
                if (!_BillParameterRepository.DbState.IsValid)
                {
                    _BillParameterRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Rate Code Updated : {0}", entity.BillParameterID);
                return Ok(entity.BillParameterID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating Rate Code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                BillParameter entity = _BillParameterRepository.GetById(id);
                _BillParameterRepository.Delete(entity);
                if (!_BillParameterRepository.DbState.IsValid)
                {
                    _BillParameterRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing Rate Code : {0}", ex);
                return BadRequest(ex.ToErrorMessage());
            }
        }
    }

}
