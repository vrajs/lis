using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class Form1099ProcessStatusHistoryODController : BaseODController
    {
        #region Variables          
        private IForm1099ProcessStatusHistoryRepository _form1099ProcessStatusHistoryRepository;
        #endregion

        #region Constructor

        public Form1099ProcessStatusHistoryODController(IForm1099ProcessStatusHistoryRepository form1099ProcessStatusHistoryRepository)
        {
            _form1099ProcessStatusHistoryRepository = form1099ProcessStatusHistoryRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetForm1099ProcessStatusHistoryList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetForm1099ProcessStatusHistoryList(long RecGroupKey)
        {
            var query = _form1099ProcessStatusHistoryRepository.GetForm1099ProcessStatusHistoryList(RecGroupKey);
            return Ok(query);
        }
    }
}
