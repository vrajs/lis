using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class LienHolderODController : BaseODController
    {
        private ILienHolderRepository _lienHolderRepository;

        public LienHolderODController(ILienHolderRepository lienHolderRepository)
        {
            _lienHolderRepository = lienHolderRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetLienHolderForDDL")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetLienHolderForDDL()
        {
            var query = _lienHolderRepository.GetLienHolderList();
            return Ok(query);
        }
    }
}
