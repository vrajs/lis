using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class AccountDetailODController : BaseODController
    {
        private IAccountDetailRepository _accountDetailRepository;

        public AccountDetailODController(IAccountDetailRepository accountDetailRepository)
        {
            _accountDetailRepository = accountDetailRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetAccountDetailList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetAccountDetailList()
        {
            var query = _accountDetailRepository.GetAccountDetailList();
            return Ok(query);
        }
    }
}
