using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    
    [Route("api/LienHolderBalance")]
    public class LienHolderBalanceAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<LienHolderBalanceAPIController> _logger;
        private readonly ILienHolderBalanceRepository _lienHolderBalanceRepository;
        private readonly ILienHolderBalanceService _lienHolderBalanceService;

        private IMapper _mapper;
        #endregion

        #region Ctor        
        public LienHolderBalanceAPIController(ILienHolderBalanceRepository lienHolderBalanceRepository, ILogger<LienHolderBalanceAPIController> logger, IMapper mapper, ILienHolderBalanceService _lienHolderBalance)
        {
            _logger = logger;
            _lienHolderBalanceRepository = lienHolderBalanceRepository;
            _mapper = mapper;
            _lienHolderBalanceService = _lienHolderBalance;
        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetLienHolderBalance")]
        public IActionResult GetLienHolderBalance(short id)
        {
            try
            {
                var result = _lienHolderBalanceRepository.GetLienHolderBalance(id);
                if (result == null) return NotFound($"LienHolderBalance with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        [Route("SaveLienHolderBalance")]
        public IActionResult Post([FromBody]LienHolderBalanceModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                LienHolderBalance entity = _mapper.Map<LienHolderBalance>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _lienHolderBalanceService.CheckIfExists(entity);
                if (!_lienHolderBalanceService.BusinessState.IsValid)
                {
                    _lienHolderBalanceService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _lienHolderBalanceRepository.Add(entity);

                if (!_lienHolderBalanceRepository.DbState.IsValid)
                {
                    _lienHolderBalanceRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("GetLienHolderBalance", new { id = entity.LienHolderBalanceID });
                _logger.LogInformation("New lienHolderBalance created");
                return Created(newUri, _mapper.Map<LienHolderBalanceModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving lienHolderBalance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] LienHolderBalanceModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                LienHolderBalance entity = _lienHolderBalanceRepository.GetById(model.LienHolderBalanceID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _lienHolderBalanceService.CheckIfExists(entity);
                if (!_lienHolderBalanceService.BusinessState.IsValid)
                {
                    _lienHolderBalanceService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _lienHolderBalanceRepository.Update(entity);
                if (!_lienHolderBalanceRepository.DbState.IsValid)
                {
                    _lienHolderBalanceRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("LienHolderBalance updated : {0}", entity.LienHolderBalanceID);
                return Ok(entity.LienHolderBalanceID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating lienHolderBalance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                _lienHolderBalanceRepository.DeleteById(id, base.UserName, base.TodaysDate);
                //_lienHolderBalanceRepository.Update(entity);
                if (!_lienHolderBalanceRepository.DbState.IsValid)
                {
                    _lienHolderBalanceRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing lienHolderBalance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("cancelLien")]
        public ActionResult Post([FromBody]short Id)
        {
            try
            {
                LienHolderBalance entity = _lienHolderBalanceRepository.GetById(Id);
                entity.TermDate = base.TodaysDate;
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _lienHolderBalanceService.CheckIfExists(entity);
                if (!_lienHolderBalanceService.BusinessState.IsValid)
                {
                    _lienHolderBalanceService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _lienHolderBalanceRepository.Update(entity);
                if (!_lienHolderBalanceRepository.DbState.IsValid)
                {
                    _lienHolderBalanceRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("LienHolderBalance updated : {0}", entity.LienHolderBalanceID);
                return Ok(entity.LienHolderBalanceID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating lienHolderBalance : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
     
        #endregion methods
    }
}
