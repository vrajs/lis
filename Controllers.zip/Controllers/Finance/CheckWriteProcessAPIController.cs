using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/CheckWriteProcess")]
    public class CheckWriteProcessAPIController : BaseAPIController
    {
        #region variables
        private ICheckWriteProcessRepository _checkWriteProcessRepository;
        private IMapper _mapper;
        private ILogger<CheckWriteProcessAPIController> _logger;
        private ICheckWriteProcessService _checkWriteProcessService;
        private IAccountDetailCompanyStructureRepository _accountDetailCompanyStructureRepository;

        #endregion

        #region Ctor
        public CheckWriteProcessAPIController(ICheckWriteProcessRepository checkWriteProcessRepository, IMapper mapper, ILogger<CheckWriteProcessAPIController> logger, ICheckWriteProcessService checkWriteProcessService, IAccountDetailCompanyStructureRepository accountDetailCompanyStructureRepository)
        {
            _checkWriteProcessRepository = checkWriteProcessRepository;
            _mapper = mapper;
            _logger = logger;
            _checkWriteProcessService = checkWriteProcessService;
            _accountDetailCompanyStructureRepository = accountDetailCompanyStructureRepository;
        }
        #endregion

        #region public methods
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var result = _checkWriteProcessRepository.GetAllCheckWriteProcess();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while getting check write processes: {ex}");
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "checkWriteProcessGet")]
        public IActionResult Get(int id)
        {
            try
            {
                var checkWriteProcess = _checkWriteProcessRepository.GetById(id);
                if (checkWriteProcess == null) return NotFound($"check Write Process with {id} was not found");
                return Ok(_mapper.Map<CheckWriteProcessModel>(checkWriteProcess));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while getting check write process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody]CheckWriteProcessModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                CheckWriteProcess entity = _mapper.Map<CheckWriteProcess>(model);
                var accountDetail = _accountDetailCompanyStructureRepository.GetCompanyAccountList().Where(x => x.LOBID == model.LOBID && x.HealthPlanID == model.HealthPlanID).FirstOrDefault();
                entity.AccountDetailID = accountDetail != null? accountDetail.AccountDetailID: (short)0;
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _checkWriteProcessService.CheckIfExists(entity);
                if (!_checkWriteProcessService.BusinessState.IsValid)
                {
                    _checkWriteProcessService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _checkWriteProcessRepository.Add(entity);

                if (!_checkWriteProcessRepository.DbState.IsValid)
                {
                    _checkWriteProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                var newUri = Url.Link("CheckWriteProcessGet", new { id = entity.CheckWriteProcessID });
                _logger.LogInformation("New checkWriteProcess created");
                return Created(newUri, _mapper.Map<CheckWriteProcessModel>(entity));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving check write process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpPut]
        public IActionResult Put([FromBody] CheckWriteProcessModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                CheckWriteProcess entity = _checkWriteProcessRepository.GetById(model.CheckWriteProcessID);
                _mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;
                entity.RecordStatus = 0;//(byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();//Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();

                _checkWriteProcessService.CheckIfExists(entity);
                if (!_checkWriteProcessService.BusinessState.IsValid)
                {
                    _checkWriteProcessService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _checkWriteProcessRepository.Update(entity);
                if (!_checkWriteProcessRepository.DbState.IsValid)
                {
                    _checkWriteProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("CheckWriteProcess updated : {0}", entity.CheckWriteProcessID);
                return Ok(entity.CheckWriteProcessID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating checkWriteProcess : {0}", ex);
                return BadRequest(ex.Message);
            }
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _checkWriteProcessRepository.DeleteById(id, base.UserName, base.TodaysDate);
                if (!_checkWriteProcessRepository.DbState.IsValid)
                {
                    _checkWriteProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing check write process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
