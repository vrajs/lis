using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class Form1099ProcessODController : BaseODController
    {
        #region Variables          
        private IForm1099ProcessRepository _form1099ProcessRepository;
        #endregion

        #region Constructor

        public Form1099ProcessODController(IForm1099ProcessRepository form1099ProcessRepository)
        {            
            _form1099ProcessRepository = form1099ProcessRepository;
        }

        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetForm1099ProcessList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetForm1099ProcessList()
        {
            var query = _form1099ProcessRepository.GetForm1099ProcessList();
            return Ok(query);
        }
    }
}
