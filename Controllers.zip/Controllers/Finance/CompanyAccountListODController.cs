using Kwicle.Data.Contracts.Finance;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.Finance
{
    [Route("odata")]
    public class CompanyAccountListODController : BaseODController
    {
        private IAccountDetailCompanyStructureRepository _accountDetailCompanyStructureRepository;

        public CompanyAccountListODController(IAccountDetailCompanyStructureRepository accountDetailCompanyStructureRepository)
        {
            _accountDetailCompanyStructureRepository = accountDetailCompanyStructureRepository;
        }

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("GetCompanyAccountList")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All, HandleNullPropagation = HandleNullPropagationOption.False)]
        public IActionResult GetCompanyAccountList()
        {
            var query = _accountDetailCompanyStructureRepository.GetCompanyAccountList();
            return Ok(query);
        }
    }
}
