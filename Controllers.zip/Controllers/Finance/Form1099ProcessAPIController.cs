using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using Kwicle.API.Controllers;
using Kwicle.Business.Interfaces.Finance;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Implementations;
using Kwicle.Data.Contracts.Common;
using Kwicle.Data.Contracts.Finance;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Kwicle.Service.Controllers.Finance
{
    [Produces("application/json")]
    [Route("api/Form1099Process")]
    public class Form1099ProcessAPIController : BaseAPIController
    {
        #region Variables
        private ILogger<Form1099ProcessAPIController> _logger;
        private readonly IForm1099ProcessRepository _form1099ProcessRepository;
        private readonly IForm1099ProcessService _form1099ProcessService;
        private readonly IForm1099DataRepository _form1099DataRepository;
        private readonly IForm1099ProcessStatusHistoryRepository _form1099ProcessStatusHistoryRepository;
        private readonly ITemplateRepository _templateRepository;
        private readonly IDocumentRepository _documentRepository;
        private readonly IForm1099Repository _form1099Repository;
        private IMapper _mapper;

        #endregion

        #region Ctor        
        public Form1099ProcessAPIController(IForm1099ProcessRepository form1099ProcessRepository, ILogger<Form1099ProcessAPIController> logger, IMapper mapper, IForm1099ProcessService _form1099Process, IForm1099DataRepository form1099DataRepository, IForm1099ProcessStatusHistoryRepository form1099ProcessStatusHistoryRepository, ITemplateRepository templateRepository, IDocumentRepository documentRepository, IForm1099Repository form1099Repository)
        {
            _logger = logger;
            _form1099ProcessRepository = form1099ProcessRepository;
            _mapper = mapper;
            _form1099ProcessService = _form1099Process;
            _form1099DataRepository = form1099DataRepository;
            _form1099ProcessStatusHistoryRepository = form1099ProcessStatusHistoryRepository;
            _templateRepository = templateRepository;
            _documentRepository = documentRepository;
            _form1099Repository = form1099Repository;
        }
        #endregion

        #region methods
        // GET api/values/5
        [HttpGet("{id}", Name = "GetForm1099Process")]
        public IActionResult GetForm1099Process(short id)
        {
            try
            {
                var result = _form1099ProcessRepository.GetForm1099Process(id);
                if (result == null) return NotFound($"Form1099Process with {id} was not found");
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost]
        [Route("Create")]
        public IActionResult Create([FromBody]Form1099ProcessModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Form1099Process entity = _mapper.Map<Form1099Process>(model);
                entity.CreatedDate = base.TodaysDate;
                entity.CreatedBy = base.UserName;
                entity.RecordStatus = (byte)RecordStatus.Active;
                entity.RecordStatusChangeComment = RecordStatus.Active.ToString();
                entity.RecGroupKey = long.Parse(DateTime.Now.ToString("yyMMddHHmmssff"));

                _form1099ProcessService.CheckIfExists(entity);
                if (!_form1099ProcessService.BusinessState.IsValid)
                {
                    _form1099ProcessService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _form1099ProcessRepository.Add(entity);

                if (!_form1099ProcessRepository.DbState.IsValid)
                {
                    _form1099ProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                if (model.ProcessMode == ProcessMode.Prod.ToInteger().ToString())
                {
                    Form1099ProcessStatusHistory historyObj = new Form1099ProcessStatusHistory();
                    historyObj.Form1099ProcessID = entity.Form1099ProcessID;
                    historyObj.CreatedBy = base.UserName;
                    historyObj.CreatedDate = base.TodaysDate;
                    historyObj.RecGroupKey = entity.RecGroupKey;
                    historyObj.Status = !string.IsNullOrEmpty(model.Status) ? model.Status : Form1099ProcessStatus.Created.ToString();
                    historyObj.StatusDate = base.TodaysDate;
                    _form1099ProcessStatusHistoryRepository.Add(historyObj);
                    if (!_form1099ProcessStatusHistoryRepository.DbState.IsValid)
                    {
                        _form1099ProcessStatusHistoryRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    var processData = _form1099ProcessRepository.SaveForm1099ProcessData(entity.Form1099ProcessID, base.UserName);
                    var testData = _form1099DataRepository.GetForm1099DataByProcessID(entity.Form1099ProcessID);
                    //int templateTypeId = (int)TemplateType.Report;
                    //int templateSubTypeId = (int)TemplateSubTypeEnum.Form1099;

                    //var template = _templateRepository.GetTemplate(templateTypeId, templateSubTypeId, "Form-1099");
                    //var fileFormat = template.FileFormat.ToEnum<TemplateFileFormat>();

                    //TemplateFileFormat templateFileFormat = template.FileFormat.ToEnum<TemplateFileFormat>();
                    //var placeHolderKeyVal = _templateRepository.GetPlaceholderDictionary(template.TemplateID, testData.FirstOrDefault().Form1099DataID);
                    //var dictionary = placeHolderKeyVal.ToDictionary(x => x.Key, x => x.Value);
                    //var relativeFilePath = $"Form-1099_{entity.Form1099ProcessID.ToString() }_{ DateTime.Now.ToString("HH_mm_ss")}.{ template.FileFormat}";
                    //var relativeFilePath = $"Form-1099_{entity.Form1099ProcessID.ToString() }_{ DateTime.Now.ToString("yyMMddHHmmss")}.pdf";

                    //var filePath = $"{ApplicationVariables.RootPath}{ApplicationVariables.ReportOutputPath}{relativeFilePath}";
                    //using (var templateService = new TemplateService(template.RelativeFilePath, templateFileFormat, base.ZoneId))
                    //{
                    //    var fileContents = await templateService.ReadFile();
                    //    var renderedContents = templateService.RenderTemplate(dictionary);

                    //    StringReader sr = new StringReader(renderedContents.ToString());
                    //    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                    //    HtmlWorker htmlparser = new HtmlWorker(pdfDoc);

                    //    using (MemoryStream memoryStream = new MemoryStream())
                    //    {
                    //        PdfWriter writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                    //        pdfDoc.Open();

                    //        htmlparser.Parse(sr);
                    //        pdfDoc.Close();

                    //        byte[] bytes = memoryStream.ToArray();
                    //        //byte[] bytes = _form1099ProcessService.GenereateForm1099PDF(testData.ToArray());
                    //        memoryStream.Close();


                    //        using (FileStream file = new FileStream(filePath, FileMode.Create, System.IO.FileAccess.Write))
                    //        {
                    //            file.Write(bytes, 0, bytes.Length);                             
                    //        }
                    //    }                        
                    //}

                    //return Ok(testData);


                    //aproach2
                    var relativeFilePath = $"Form-1099_{entity.Form1099ProcessID.ToString() }_{ DateTime.Now.ToString("yyMMddHHmmss")}.pdf";
                    var filePath = $"{ApplicationVariables.RootPath}{ApplicationVariables.ReportOutputPath}{relativeFilePath}";

                    var testbytes = _form1099ProcessService.GenereateForm1099PDF(testData.ToArray());
                    using (FileStream file = new FileStream(filePath, FileMode.Create, System.IO.FileAccess.Write))
                    {
                        file.Write(testbytes, 0, testbytes.Length);
                    }

                    //Add document Entry
                    Core.Entities.CommonStructure.Document documentObj = new Core.Entities.CommonStructure.Document();
                    documentObj.DocumentName = relativeFilePath.ToString();
                    documentObj.DocumentTypeID = (short)_documentRepository.GetForm1099DocumentType();
                    documentObj.SourceFileName = relativeFilePath.ToString();
                    documentObj.FileType = FileType.PDF.ToString();
                    documentObj.RelativeFilePath = filePath.ToString();
                    documentObj.DocumentReceivedDate = base.TodaysDate;
                    documentObj.Comment = string.Empty;
                    documentObj.IsNeedReview = false;
                    documentObj.IsReviewed = false;
                    documentObj.ReviewedBy = string.Empty;
                    documentObj.ReviewedDate = DateTime.MaxValue.Date;
                    documentObj.RecordStatus = (byte)RecordStatus.Active;
                    documentObj.IsFreezed = (byte)0;
                    documentObj.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    documentObj.CreatedBy = base.UserName;
                    documentObj.CreatedDate = base.TodaysDate;
                    documentObj.UpdatedBy = null;
                    documentObj.UpdatedDate = null;
                    documentObj.AddedFromMenuID = 0;

                    _documentRepository.Add(documentObj);
                    if (!_documentRepository.DbState.IsValid)
                    {
                        _documentRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    //Save Form-1099 to map document with the form-1099 process
                    Form1099 objForm1099 = new Form1099();
                    objForm1099.CreatedBy = base.UserName;
                    objForm1099.CreatedDate = base.TodaysDate;
                    objForm1099.DocumentID = documentObj.DocumentID;
                    objForm1099.Form1099ProcessID = entity.Form1099ProcessID;
                    objForm1099.IsFreezed = (byte)0;
                    objForm1099.IsSent = false;
                    objForm1099.LastPrintBY = null;
                    objForm1099.LastPrintDate = null;
                    objForm1099.PrintCount = 0;
                    objForm1099.RecipientID = null;
                    objForm1099.RecordStatus = (byte)RecordStatus.Active;
                    objForm1099.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    objForm1099.SentVia = null;
                    objForm1099.UpdatedBy = null;
                    objForm1099.UpdatedDate = null;

                    _form1099Repository.Add(objForm1099);
                    if (!_form1099Repository.DbState.IsValid)
                    {
                        _form1099Repository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                }
                _logger.LogInformation("New form1099Process created");

                var outputData = _form1099ProcessRepository.GetForm1099ProcessData(entity.Form1099ProcessID, base.UserName);
                return Ok(outputData);

            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving form1099Process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// This operation will only be peformed on corrected state
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        public IActionResult Put([FromBody] Form1099ProcessModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                //void the recordstatus of existing record
                Form1099Process entity = _form1099ProcessRepository.GetById(model.Form1099ProcessID);
                entity.RecordStatus = (byte)RecordStatus.VoidOrInvalid;
                entity.RecordStatusChangeComment = RecordStatus.VoidOrInvalid.ToString();

                _form1099ProcessRepository.Update(entity);
                if (!_form1099ProcessRepository.DbState.IsValid)
                {
                    _form1099ProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Form1099Process updated : {0}", entity.Form1099ProcessID);


                //Create New Object                
                Form1099Process newObjToInsert = new Form1099Process();
                _mapper.Map(model, newObjToInsert);
                newObjToInsert.Form1099ProcessID = 0;
                newObjToInsert.RecGroupKey = entity.RecGroupKey;
                newObjToInsert.CreatedDate = base.TodaysDate;
                newObjToInsert.CreatedBy = base.UserName;
                newObjToInsert.RecordStatus = (byte)RecordStatus.Active;
                newObjToInsert.RecordStatusChangeComment = RecordStatus.Active.ToString();
                newObjToInsert.UpdatedBy = null;
                newObjToInsert.UpdatedDate = null;

                _form1099ProcessService.CheckIfExists(newObjToInsert);
                if (!_form1099ProcessService.BusinessState.IsValid)
                {
                    _form1099ProcessService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _form1099ProcessRepository.Add(newObjToInsert);

                if (!_form1099ProcessRepository.DbState.IsValid)
                {
                    _form1099ProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                Form1099ProcessStatusHistory historyObj = new Form1099ProcessStatusHistory();
                historyObj.Form1099ProcessID = newObjToInsert.Form1099ProcessID;
                historyObj.CreatedBy = base.UserName;
                historyObj.CreatedDate = base.TodaysDate;
                historyObj.RecGroupKey = entity.RecGroupKey;
                historyObj.Status = Form1099ProcessStatus.Corrected.ToString();
                historyObj.StatusDate = base.TodaysDate;
                _form1099ProcessStatusHistoryRepository.Add(historyObj);
                if (!_form1099ProcessStatusHistoryRepository.DbState.IsValid)
                {
                    _form1099ProcessStatusHistoryRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                if (newObjToInsert.ProcessMode == ProcessMode.Test.ToInteger().ToString())
                {
                    var testData = _form1099ProcessRepository.GetForm1099ProcessData(newObjToInsert.Form1099ProcessID, base.UserName);
                    return Ok(testData);
                }
                else
                {
                    var processData = _form1099ProcessRepository.SaveForm1099ProcessData(newObjToInsert.Form1099ProcessID, base.UserName);
                    var testData = _form1099DataRepository.GetForm1099DataByProcessID(newObjToInsert.Form1099ProcessID);

                    var relativeFilePath = $"Form-1099_{entity.Form1099ProcessID.ToString() }_{ DateTime.Now.ToString("yyMMddHHmmss")}.pdf";
                    var filePath = $"{ApplicationVariables.RootPath}{ApplicationVariables.ReportOutputPath}{relativeFilePath}";
                    var testbytes = _form1099ProcessService.GenereateForm1099PDF(testData.ToArray());

                    using (FileStream file = new FileStream(filePath, FileMode.Create, System.IO.FileAccess.Write))
                    {
                        file.Write(testbytes, 0, testbytes.Length);
                    }

                    //Add document Entry
                    Core.Entities.CommonStructure.Document documentObj = new Core.Entities.CommonStructure.Document();
                    documentObj.DocumentName = relativeFilePath.ToString();
                    documentObj.DocumentTypeID = (short)DocumentType.Form1099;
                    documentObj.SourceFileName = relativeFilePath.ToString();
                    documentObj.FileType = FileType.PDF.ToString();
                    documentObj.RelativeFilePath = filePath.ToString();
                    documentObj.DocumentReceivedDate = base.TodaysDate;
                    documentObj.Comment = string.Empty;
                    documentObj.IsNeedReview = false;
                    documentObj.IsReviewed = false;
                    documentObj.ReviewedBy = string.Empty;
                    documentObj.ReviewedDate = DateTime.MaxValue.Date;
                    documentObj.RecordStatus = (byte)RecordStatus.Active;
                    documentObj.IsFreezed = (byte)0;
                    documentObj.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    documentObj.CreatedBy = base.UserName;
                    documentObj.CreatedDate = base.TodaysDate;
                    documentObj.UpdatedBy = null;
                    documentObj.UpdatedDate = null;
                    documentObj.AddedFromMenuID = 0;

                    _documentRepository.Add(documentObj);
                    if (!_documentRepository.DbState.IsValid)
                    {
                        _documentRepository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }
                    
                    //Save Form-1099 to map document with the form-1099 process
                    Form1099 objForm1099 = new Form1099();
                    objForm1099.CreatedBy = base.UserName;
                    objForm1099.CreatedDate = base.TodaysDate;
                    objForm1099.DocumentID = documentObj.DocumentID;
                    objForm1099.Form1099ProcessID = entity.Form1099ProcessID;
                    objForm1099.IsFreezed = (byte)0;
                    objForm1099.IsSent = false;
                    objForm1099.LastPrintBY = null;
                    objForm1099.LastPrintDate = null;
                    objForm1099.PrintCount = 0;
                    objForm1099.RecipientID = null;
                    objForm1099.RecordStatus = (byte)RecordStatus.Active;
                    objForm1099.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    objForm1099.SentVia = null;
                    objForm1099.UpdatedBy = null;
                    objForm1099.UpdatedDate = null;

                    _form1099Repository.Add(objForm1099);
                    if (!_form1099Repository.DbState.IsValid)
                    {
                        _form1099Repository.DbState.ErrorMessages.ForEach((error) =>
                        {
                            this.ModelState.AddModelError(error.Key, error.Value);
                        });
                        return BadRequest(this.ModelState);
                    }

                    return Ok(testData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating form1099Process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _form1099ProcessRepository.DeleteById(id, base.UserName, base.TodaysDate);
                //_form1099ProcessRepository.Update(entity);
                if (!_form1099ProcessRepository.DbState.IsValid)
                {
                    _form1099ProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while removing form1099Process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("SaveData")]
        public IActionResult SaveData([FromBody]int id)
        {
            try
            {
                var testData = _form1099ProcessRepository.SaveForm1099ProcessData(id, base.UserName);
                return Ok(testData);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while saving data for form1099Process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("Void")]
        public IActionResult Void([FromBody]int Form1099ProcessID)
        {
            try
            {
                //Update existing record with void
                Form1099Process entity = _form1099ProcessRepository.GetById(Form1099ProcessID);
                entity.IsVoid = true;
                //_mapper.Map(model, entity);
                entity.UpdatedDate = base.TodaysDate;
                entity.UpdatedBy = base.UserName;


                _form1099ProcessRepository.Update(entity);
                if (!_form1099ProcessRepository.DbState.IsValid)
                {
                    _form1099ProcessRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                _logger.LogInformation("Form1099Process updated : {0}", entity.Form1099ProcessID);


                // Update the data in form-1099-data
                var dataList = _form1099DataRepository.GetForm1099DataByProcessID(Form1099ProcessID);
                if (dataList != null)
                {
                    foreach (var item in dataList)
                    {
                        item.IsVoid = true;
                        item.UpdatedDate = base.TodaysDate;
                        item.UpdatedBy = base.UserName;
                        //item.RecordStatus = (byte)RecordStatus.VoidOrInvalid;
                        //item.RecordStatusChangeComment = RecordStatus.VoidOrInvalid.ToString();

                        _form1099DataRepository.Update(item);
                        if (!_form1099DataRepository.DbState.IsValid)
                        {
                            _form1099DataRepository.DbState.ErrorMessages.ForEach((error) =>
                            {
                                this.ModelState.AddModelError(error.Key, error.Value);
                            });
                            return BadRequest(this.ModelState);
                        }
                        _logger.LogInformation("Form1099ProcessData updated : {0}", item.Form1099DataID);
                    }
                }

                Form1099ProcessStatusHistory historyObj = new Form1099ProcessStatusHistory();
                historyObj.Form1099ProcessID = entity.Form1099ProcessID;
                historyObj.CreatedBy = base.UserName;
                historyObj.CreatedDate = base.TodaysDate;
                historyObj.RecGroupKey = entity.RecGroupKey;
                historyObj.Status = Form1099ProcessStatus.Void.ToString();
                historyObj.StatusDate = base.TodaysDate;
                _form1099ProcessStatusHistoryRepository.Add(historyObj);
                if (!_form1099ProcessStatusHistoryRepository.DbState.IsValid)
                {
                    _form1099ProcessStatusHistoryRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }

                return Ok(entity.Form1099ProcessID);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while updating form1099Process : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        #endregion methods

        #region Other methods        

        #endregion
    }
}
