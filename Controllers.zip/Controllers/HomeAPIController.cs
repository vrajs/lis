using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.Implementations;
using Kwicle.Core.Interfaces;
using Kwicle.Data.Contracts.Masters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MimeKit;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Service.Controllers
{
    public class HomeAPIController : Controller
    {
        private readonly IEmailService _emailService;
        
        

        public HomeAPIController(IEmailService emailService)
        {
            
            _emailService = emailService;
        
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Error()
        {
            ViewData["RequestId"] = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            return View();
        }

        [HttpPost()]
        public async Task<IActionResult> Mail([FromBody]MailViewModel model)
        {
            if (ModelState.IsValid)
            {
                //// create an image attachment for the file located at path
                //var attachment = new MimePart("image", "gif")
                //{
                //    Content = new MimeContent(System.IO.File.OpenRead(@"F:\Work\HealthPlan\Business\User Management\User Management Queries.docx"), ContentEncoding.Default),
                //    ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                //    ContentTransferEncoding = ContentEncoding.Base64,
                //    FileName = Path.GetFileName(@"F:\Work\HealthPlan\Business\User Management\User Management Queries.docx")
                //};

                await _emailService.SendEmailAsync(model.MailTo, model.MailCc, model.MailBcc, model.Subject, model.Message);

                ViewBag.Succes = true;
            }

            return View(model);
        }

        //[HttpGet()]
        //public IActionResult GetTemplate(string path)
        //{
        //    //Email
        //    //When user creation email need to send we know template name, get it by type, sub type and name
        //    int templateTypeId = (int)TemplateType.Email;
        //    int templateSubTypeId = (int)TemplateType.Email;
        //    var template = _templateRepository.GetTemplate(templateTypeId, templateSubTypeId,"User Welcome Email");

        //    //ApplicationVariables.TemplateBasePath
        //    //var placeHolders = from n in template.TemplatePlaceHolders
        //    //                   join p in 


        //    //string tableName = "Member";
        //    string[] properties = new string[] { "DOB", "DisplayName", "FamilyCode" };


        //    //            var renderedTemplate = TemplateService.GetRenderedTemplate(template.HtmltemplateContent,template.TemplatePlaceHolders, new WelcomeTemplateModel());
        //    //var renderedTemplate = TemplateService.GetRenderedTemplate(tableName, properties);
        //    return Ok("");
        //}


        // GET api/values
        [Route("api/[controller]"), Authorize, HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
    }
    public class MailViewModel
    {
        public string[] MailTo { get; set; }
        public string[] MailCc { get; set; }
        public string[] MailBcc { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
    }
}
