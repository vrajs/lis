using IdentityServer4.AccessTokenValidation;
using Kwicle.Core.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace Kwicle.API.Controllers
{
    //[Authorize]
    //[AuditApi]
    [Authorize(AuthenticationSchemes = IdentityServerAuthenticationDefaults.AuthenticationScheme)]
    public abstract class BaseAPIController : Controller
    {
        public const string URLHELPER = "URLHELPER";
        //public  string ZoneId = "Eastern Standard Time";
        public string ZoneId { get { return "Eastern Standard Time"; } }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
            context.HttpContext.Items[URLHELPER] = this.Url;
        }

        public DateTime TodaysDate => Utility.GetTimeZoneBasedDateTime(ZoneId);


        public string UserName => User.Identity.Name;

        public short OrganizationID => 10;
    }
}
