using AutoMapper;
using Kwicle.API.Controllers;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Common;
using Kwicle.Data.Contracts.OrganizationStructure;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.OrganizationStructure
{
    [EnableCors("AnyGET")]
    [Route("api/Lob")]
    public class LobAPIController : BaseAPIController
    {
        private readonly ILobRepository _ILobRepository;
        private readonly ICommonRepository _ICommonRepository;
        private IMapper _mapper;


        public LobAPIController(ILobRepository ILobRepository, ICommonRepository ICommonRepository, IMapper mapper)
        {
            _ILobRepository = ILobRepository;
            _ICommonRepository = ICommonRepository;
            _mapper = mapper;
        }


        [HttpGet("{id}", Name = "LobGet")]
        public IActionResult Get(int id)
        {
            try
            {
                LobModel lob = _ILobRepository.GetLobByID(id);
                if (lob == null) return NotFound($"Lob {id} was not found");
                return Ok(lob);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]LobModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            Lob entity = _mapper.Map<Lob>(model);
            entity.CreatedDate = base.TodaysDate;
            entity.SubCompanyID = model.SubCompanyID;
            entity.CreatedBy = base.UserName;
            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
            if (entity.TermDate == DateTime.MinValue)
                entity.TermDate = DateTime.MaxValue;

            _ILobRepository.Add(entity);
            if (!_ILobRepository.DbState.IsValid)
            {
                _ILobRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            var newUri = Url.Link("LobGet", new { id = entity.LobID });
            return Created(newUri, _mapper.Map<LobModel>(entity));
        }


        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody] LobModel model)
        {
            Lob entity = _ILobRepository.GetByID(model.LobID);
            _mapper.Map(model, entity);
            entity.UpdatedDate = base.TodaysDate;
            entity.UpdatedBy = base.UserName;
            entity.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate);
            entity.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, entity.EffectiveDate, entity.TermDate).ToString();
            if (entity.TermDate == DateTime.MinValue)
                entity.TermDate = DateTime.MaxValue;

            _ILobRepository.Update(entity);

            if (!_ILobRepository.DbState.IsValid)
            {
                _ILobRepository.DbState.ErrorMessages.ForEach((error) =>
                {
                    this.ModelState.AddModelError(error.Key, error.Value);
                });
                return BadRequest(this.ModelState);
            }
            return Ok(model);
        }
         
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {

            bool isDelete = _ICommonRepository.CheckReferenceExist("LOB", id, 0, (short)ReferenceCheckType.Both);

            if (isDelete == true)
            {
                Lob entity = _ILobRepository.GetByID(id);
                _ILobRepository.Delete(entity);

                if (!_ILobRepository.DbState.IsValid)
                {
                    _ILobRepository.DbState.ErrorMessages.ForEach((error) =>
                    {
                        this.ModelState.AddModelError(error.Key, error.Value);
                    });
                    return BadRequest(this.ModelState);
                }
                return Ok(id);
            }
            else
            {
                return BadRequest("Can't delete this LOB. Related reference/child data exist");
            }
        }
        [HttpGet]
        [Route("GetBySubCompanyId/{subCompanyId?}")]
        public IActionResult GetLobBySubcompanyId(int? subCompanyId)
        {
            List<KeyVal<short, string>> lobs = _ILobRepository.GetBySubCompanyId(subCompanyId);
            return Ok(lobs);
        }
    }
}
