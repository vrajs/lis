using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.OrganizationStructure;
using Kwicle.Core.CustomModel;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.OrganizationStructure
{
    [Route("api/Product")]
    public class ProductAPIController : BaseAPIController
    {
        #region Variables
        private readonly IProductRepository _IProductRepository;
        private readonly IMapper _mapper;
        #endregion

        #region Ctor
        public ProductAPIController(IProductRepository IProductRepository, IMapper mapper)
        {
            _IProductRepository = IProductRepository;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        [Route("GetProductForDDL")]
        public IActionResult GetProductForDDL()
        {
            List<KeyVal<int, string>> products = _IProductRepository.GetKeyValuedProducts();
            return Ok(products);
        }
    }   

}
