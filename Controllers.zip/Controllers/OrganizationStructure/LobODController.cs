using Kwicle.Data.Contracts.OrganizationStructure;
using Kwicle.Service.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Kwicle.Service.Controllers.OrganizationStructure
{
    [Route("odata")]
    public class LobODController : BaseODController
    {
        #region Property        
        private ILobRepository _LobRepository;
        #endregion

        #region Ctor        
        public LobODController(ILobRepository pLobRepository)
        {
            _LobRepository = pLobRepository;
        }
        #endregion

        [HttpGet]
        [ConvertUrlToOdataV4]
        [Route("Lobs")]
        [EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult GetLobs()
        {
            var lobQuery = _LobRepository.GetLobs();
            return Ok(lobQuery);
        }
    }
}
