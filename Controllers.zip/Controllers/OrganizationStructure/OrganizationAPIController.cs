using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Kwicle.Core.CustomModel;
using Kwicle.Data.Contracts.OrganizationStructure;
using Microsoft.AspNetCore.Cors;
using Kwicle.Core.CustomModel.OrganizationStructure;
using Kwicle.Core.Entities;
using Kwicle.Core.Common;
using Kwicle.Business.Interfaces.Configuration;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.OrganizationStructure
{
    [EnableCors("AnyGET")]
    [Route("api/Organization")]
    public class OrganizationAPIController : BaseAPIController
    {

        #region Property Declaration
        private readonly ILogger<OrganizationAPIController> _logger;
        private readonly IOrganizationRepository _organizationRepository;
        private readonly IOrganizationService _organizationService;
        private readonly IMapper _mapper;
        #endregion


        #region Constructor
        public OrganizationAPIController(ILogger<OrganizationAPIController> logger,  IMapper mapper, IOrganizationRepository pOrganizationRepository, IOrganizationService organizationService)
        {
            this._logger = logger;
            this._mapper = mapper;
            this._organizationRepository = pOrganizationRepository;
            this._organizationService = organizationService;
        }
        #endregion


        #region Get Methods
        /// <summary>
        /// Method use for get parent organization.
        /// </summary>
        /// <returns>List Of Select2OptionDataModel</returns>
        [HttpGet]
        [Route("GetCompanyForDDL")]
        public IActionResult GetCompanyForDDL()
        {
            List<KeyVal<short, string>> result = _organizationRepository.GetCompany();
            return Ok(result);
        }

        /// <summary>
        /// Method use for get child organization.
        /// </summary>
        /// <returns>List Of Select2OptionDataModel</returns>
        [HttpGet]
        [Route("GetSubCompanyForDDL/{OrganizationID?}")]
        public IActionResult GetSubCompanyForDDL(int? OrganizationID)
        {
            List<KeyVal<short, string>> result = _organizationRepository.GetSubCompany(OrganizationID);
            return Ok(result);
        }
        [HttpGet]
        [Route("GetCompanies")]
        public IActionResult GetCompanies()
        {
            List<OrganizationStructureModel> companies = _organizationRepository.GetCompanies();
            return Ok(companies);
        }

        [HttpGet("{id}", Name = "OrganizationGet")]
        public IActionResult GetOrganizationById(short id)
        {
            try
            {
                var organizationModel = _organizationRepository.GetById(id);
                if (organizationModel == null) return NotFound($"Organization {id} was not Found");
                if (!_organizationRepository.DbState.IsValid)
                {
                    _organizationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<OrganizationViewModel>(organizationModel));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting Organization : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("OrganizationDetailsGet/{OrganizationID}")]
        public IActionResult GetOrganizationDetailsByID(short OrganizationID)
        {
            try
            {
                var organizationModel = _organizationRepository.GetOrganizationDetailsByID(OrganizationID);
                if (organizationModel == null) return NotFound($"Organization {OrganizationID} was not Found");
                if (!_organizationRepository.DbState.IsValid)
                {
                    _organizationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                return Ok(_mapper.Map<OrganizationViewModel>(organizationModel));
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while Getting Organization : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetHierarchyOrganizations")]
        public IActionResult GetHierarchyOrganizations()
        {
            var Organizations = _organizationRepository.GetHierarchyOrganizations();
            return Json(Organizations);
        }
        #endregion

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]OrganizationViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                Organization organizationModule = _mapper.Map<Organization>(model);
                organizationModule.CreatedDate = base.TodaysDate;
                organizationModule.CreatedBy = base.UserName;
                organizationModule.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, organizationModule.EffectiveDate, organizationModule.TermDate);
                organizationModule.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, organizationModule.EffectiveDate, organizationModule.TermDate).ToString();

                _organizationService.CheckIfExist(organizationModule);
                if (!_organizationService.BusinessState.IsValid)
                {
                    _organizationService.BusinessState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return StatusCode((int)HttpStatusCode.NotAcceptable, this.ModelState);
                }

                _organizationRepository.Add(organizationModule);
                if (!_organizationRepository.DbState.IsValid)
                {
                    _organizationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
                if (model.Iscompanysame)
                {
                    model.ParentOrganizationID = organizationModule.OrganizationID;
                    model.OrganizationID = 0;
                    model.OrganizationTypeID = (int)OrganizationType.Subcompany;
                    model.OrganizationCode = model.SubCompanyCode;
                    model.Iscompanysame = false;
                    organizationModule = new Organization();
                    return this.Post(model);
                }
                else { 
                var newUri = Url.Link("OrganizationGet", new { id = organizationModule.OrganizationID });
                _logger.LogInformation("New Organization Created");
              
                return Created(newUri, organizationModule.OrganizationID);
                }

            }
            catch (Exception ex)
            {

                _logger.LogError("Error while saving Organization : {0}", ex);
                return BadRequest(ex.Message);
            }
        }

        // PUT api/values/5
        [HttpPut]
        public IActionResult Put([FromBody]OrganizationViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var oldOrganization = _organizationRepository.GetById(model.OrganizationID);

                if (oldOrganization == null) return Json(NotFound($"Could not find a organization with an organizationID of {model.OrganizationID}"));

                _mapper.Map(model, oldOrganization);
                oldOrganization.UpdatedBy = base.UserName;
                oldOrganization.UpdatedDate = base.TodaysDate;
                oldOrganization.RecordStatus = (byte)Utility.GetRecordStatus(base.TodaysDate, oldOrganization.EffectiveDate, oldOrganization.TermDate);
                oldOrganization.RecordStatusChangeComment = Utility.GetRecordStatus(base.TodaysDate, oldOrganization.EffectiveDate, oldOrganization.TermDate).ToString();
                _organizationRepository.Update(oldOrganization);
                if (!_organizationRepository.DbState.IsValid)
                {
                    _organizationRepository.DbState.ErrorMessages.ForEach((businessState) =>
                    {
                        ModelState.AddModelError(businessState.Key, businessState.Value);
                    });
                    return BadRequest(ModelState);
                }
              
                    return Ok(model.OrganizationID);
              
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception thrown while updating organization :{ex}");
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            try
            {
                if (!_organizationRepository.CheckLOBCompany(id))
                {
                    _organizationRepository.DeleteById(id, base.UserName, base.TodaysDate);
                    return Ok(id);
                }
                else {
                    return Ok(-1);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while deleting Organization : {0}", ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
