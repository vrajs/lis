using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.OrganizationStructure;
using Kwicle.Core.CustomModel;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.OrganizationStructure
{
    [Route("api/Category")]
    public class CategoryAPIController : BaseAPIController
    {
        #region Variables
        private readonly ICategoryRepository _ICategoryRepository;
        private readonly IMapper _mapper;
        #endregion

        #region Ctor
        public CategoryAPIController(ICategoryRepository ICategoryRepository, IMapper mapper)
        {
            _ICategoryRepository = ICategoryRepository;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        [Route("GetCategoryForDDL")]
        public IActionResult GetCategoryForDDL()
        {
            List<KeyVal<Int16, string>> categories =  _ICategoryRepository.GetKeyValuedCategories();
            return Ok(categories);
        }        
    }
}
