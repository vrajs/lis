using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Kwicle.API.Controllers;
using Kwicle.Data.Contracts.OrganizationStructure;
using Kwicle.Core.CustomModel;
using AutoMapper;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Kwicle.Service.Controllers.OrganizationStructure
{
    [Route("api/Sponsor")]
    public class SponsorAPIController : BaseAPIController
    {
        #region Variables
        private readonly ISponsorRepository _ISponsorRepository;
        private readonly IMapper _mapper;
        #endregion

        #region Ctor
        public SponsorAPIController(ISponsorRepository ISponsorRepository, IMapper mapper)
        {
            _ISponsorRepository = ISponsorRepository;
            _mapper = mapper;
        }
        #endregion


        // GET: api/values
        [HttpGet]
        [Route("GetSponsorForDDL")]
        public IActionResult GetSponsorForDDL()
        {
            List<KeyVal<Int16, string>> categories = _ISponsorRepository.GetSponsor();
            return Ok(categories);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
