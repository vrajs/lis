﻿using Kwicle.Core.Entities;
using Kwicle.Core.Entities.Core;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data
{
    public class KwicleCoreContext : IdentityDbContext<KwicleUser, KwicleRole, string>
    {
        public KwicleCoreContext(DbContextOptions<KwicleCoreContext> options) : base(options)
        {
        }

        public DbSet<Menu> Menus { get; set; }

        public DbSet<Module> Modules { get; set; }

        public DbSet<RoleType> RoleTypes { get; set; }

        public DbSet<RoleTypeClaims> RoleTypeClaims { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<KwicleUser>().HasMany(u => u.Claims).WithOne().HasForeignKey(c => c.UserId).IsRequired().OnDelete(DeleteBehavior.Cascade);
            builder.Entity<KwicleUser>().HasMany(u => u.Roles).WithOne().HasForeignKey(r => r.UserId).IsRequired().OnDelete(DeleteBehavior.Cascade);
            builder.Entity<KwicleUser>().Property(e => e.IsActiveDirectoryUser).HasDefaultValueSql("((0))");

            builder.Entity<KwicleRole>().HasMany(r => r.Claims).WithOne().HasForeignKey(c => c.RoleId).IsRequired().OnDelete(DeleteBehavior.Cascade);
            builder.Entity<KwicleRole>().HasMany(r => r.Users).WithOne().HasForeignKey(r => r.RoleId).IsRequired().OnDelete(DeleteBehavior.Cascade);
            builder.Entity<KwicleRole>().HasOne(r => r.RoleType).WithMany(r => r.KwicleRoles).HasForeignKey(r => r.RoleTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<KwicleRole>().Property(r => r.IsFreezed).HasDefaultValue(0);

            //builder.Entity<KwicleRoleClaim>().HasOne(rc => rc.RoleTypeClaim).WithMany(rc => rc.KwicleRoleClaims).HasForeignKey(rc => rc.RoleTypeCLaimsID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Menu>().Property(x => x.ID).ValueGeneratedNever();            
            builder.Entity<Menu>().Property(c => c.IsShowInMenu).HasDefaultValue(1);
            builder.Entity<Module>().Property(x => x.ID).ValueGeneratedNever();
            builder.Entity<Module>().Property(c => c.SiteID).HasDefaultValue(7);

            builder.Entity<RoleType>().Property(r => r.RoleTypeID).ValueGeneratedOnAdd();
            builder.Entity<RoleType>().HasIndex(r => r.Name).IsUnique();

            builder.Entity<RoleTypeClaims>().Property(r => r.RoleTypeClaimsID).ValueGeneratedOnAdd();
            builder.Entity<RoleTypeClaims>().Property(r => r.IsFreezed).HasDefaultValue(0);
            builder.Entity<RoleTypeClaims>().HasIndex(r => new { r.Name, r.ClaimValue }).IsUnique();            
            builder.Entity<RoleTypeClaims>().HasOne(r => r.RoleType).WithMany(r => r.RoleTypeClaims).HasForeignKey(r => r.RoleTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RoleTypeClaims>().HasOne(r => r.Menu).WithMany(r => r.RoleTypeClaims).HasForeignKey(r => r.MenuID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RoleTypeClaims>().HasOne(r => r.Module).WithMany(r => r.RoleTypeClaims).HasForeignKey(r => r.ModuleID).OnDelete(DeleteBehavior.Restrict);
        }
       
    }
}
