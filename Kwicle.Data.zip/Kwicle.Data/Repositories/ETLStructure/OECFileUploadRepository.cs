﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Common;
using Kwicle.Core.Common.OECFile;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.ETLStructure;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class OECFileUploadRepository : BaseRepository<FileModel>, IOECFileUploadRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public OECFileUploadRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   
        public IQueryable<DataFileTemplateFields> GetAllDataFileTemplateFields()
        {
            try
            {
                var res = _context.DataFileTemplateFields;
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotDataFileTemplateFields", ex.Message);
                return null;
            }
        }
        public long InsertOECFileProcessDataInDataFileProcess(int DataFileProcessConfigurationId, string FileName)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@" + OECFileProcessData.DataFileProcessConfigurationId, DataFileProcessConfigurationId ),
                new SqlParameter("@" + OECFileProcessData.FileName, FileName)
            };

            List<OECFileInsertedDataFileToProcessModel> OECFileInsertedDataFileToProcessModel = _context.ExecuteStoreProcedure<OECFileInsertedDataFileToProcessModel>(OECFileProcessData.InsertDataFileToProcess, parameters.ToArray());

            return  OECFileInsertedDataFileToProcessModel[0].DataFileToProcessDetailsID;

        }
        public IEnumerable<OECLayout> GetOECUplodedDataByDataFileToProcessDetailsID(long DataFileToProcessDetailsID, int DataFileTemplateID)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@" + "DataFileToProcessDetailsID", DataFileToProcessDetailsID),
                new SqlParameter("@" + "DataFileTemplateID", DataFileTemplateID)
            };

            List<OECLayout> OECLayouts = _context.ExecuteStoreProcedure<OECLayout>(OECFileProcessData.OEC_Datatype_Validation, parameters.ToArray());

            return OECLayouts;

        }
        public void OECActualLoadData(long DataFileToProcessDetailsID)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@" + "DataFileToProcessDetailsID", DataFileToProcessDetailsID),
            };

            _context.Database.ExecuteSqlRaw(OECFileProcessData.OEC_ActualLoadData, parameters.ToArray());
        }

        #endregion


    }
}
