﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class DataFileToProcessDetailsRepository : BaseRepository<DataFileToProcessDetails>, IDataFileToProcessDetailsRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public DataFileToProcessDetailsRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   

        public IEnumerable<DataFileToProcessDetails> GetAllDataFileToProcessDetails()
        {
            try
            {
                var res = _context.DataFileToProcessDetails.ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllDataFileToProcessDetails", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
