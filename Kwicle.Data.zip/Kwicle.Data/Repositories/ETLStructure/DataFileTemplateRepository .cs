﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class DataFileTemplateRepository : BaseRepository<DataFileTemplate>, IDataFileTemplateRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public DataFileTemplateRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   

        public IEnumerable<DataFileTemplate> GetAllDataFileTemplate()
        {
            try
            {
                var res = _context.DataFileTemplate.ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllDataFileTemplate", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
