﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class DataFileProcessConfigurationRepository : BaseRepository<DataFileProcessConfiguration>, IDataFileProcessConfigurationRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public DataFileProcessConfigurationRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   

        public IQueryable<DataFileProcessConfiguration> GetAllDataFileProcessConfiguration()
        {
            try
            {
                var res = _context.DataFileProcessConfigurations;
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllDataFileProcessConfiguration", ex.Message);
                return null;
            }
        }

        public DataFileProcessConfiguration GetDataByDatafileTemplateId(int DatafileTemplateId)
        {
            DataFileProcessConfiguration DataFileProcessConfiguration = _context.DataFileProcessConfigurations
                                               .Where(e => e.DatafileTemplateId == Convert.ToInt16(DatafileTemplateId)).FirstOrDefault();

            return DataFileProcessConfiguration;
        }
        #endregion
    }
}
