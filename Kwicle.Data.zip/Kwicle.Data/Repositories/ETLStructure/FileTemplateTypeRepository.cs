﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;
using Kwicle.Core.CustomModel.ETLStructure;
using System.Linq.Expressions;
using System.Globalization;
using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.Kwicle.Core.Entities.Files;
using Kwicle.Core.Entities.Files;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class FileTemplateTypeRepository : BaseRepository<FileTemplateType>, IFileTemplateTypeRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public FileTemplateTypeRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   

        public IEnumerable<FileTemplateType> GetAllFileTemplateType()
        {
            try
            {
                var res = _context.FileTemplateTypes.ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllFileTemplateType", ex.Message);
                return null;
            }
        }

        public async Task<List<FileSubCategory>> GetCMSFileType()
        {
            try
            {
                //var res =   _context.FileSubCategories.ToList();
                var res = await (from f in _context.FileSubCategories
                                 join d in _context.DataFileTemplate on f.FileSubCategoryID equals d.FileSubCategoryId
                                 where d.FileTemplateTypeId == 11
                                 select new FileSubCategory
                                 {
                                     FileSubCategoryID = d.FileSubCategoryId,
                                     FileCategoryID = f.FileCategoryID,
                                     SubCategoryName = f.SubCategoryName
                                 }).ToListAsync();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllFileTemplateType", ex.Message);
                return null;
            }
            throw new NotImplementedException();
        }
        public async Task<List<FullEnrollmentDetailLayout>> GetEnrollmentFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.FullEnrollmentDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MembershipDetailLayout>> GetMembershipFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MembershipDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MMSRDetailLayout>> GetMMSRDetailFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MMSRDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT92Layout>> GetMARxT92FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT92Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT81Layout>> GetMARxT81FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT81Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT80Layout>> GetMARxT80FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT80Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT79Layout>> GetMARxT79FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT79Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT78Layout>> GetMARxT78FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT78Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT77Layout>> GetMARxT77FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT77Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT76Layout>> GetMARxT76FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT76Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT75Layout>> GetMARxT75FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT75Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT74Layout>> GetMARxT74FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT74Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT73Layout>> GetMARxT73FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT73Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT72Layout>> GetMARxT72FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT72Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT51Layout>> GetMARxT51FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT51Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT61Layout>> GetMARxT61FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT61Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT93Layout>> GetMARxT93FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT93Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MARxRequestT94Layout>> GetMARxT94FileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MARxRequestT94Layout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<TRRDetailLayout>> GetTRRDetailFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.TRRDetailLayouts.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<OECLayout>> GetOECFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.OECLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<NoRxDetailLayout>> GetNoRxFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.NoRxDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MPWRDDetailLayout>> GetMPWRDFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MPWRDDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MMSRDetailLayout>> GetMMSRFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MMSRDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<LossOfSubsidyDetailLayout>> GetLossOfSubsidyFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.LossOfSubsidyDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<MAMSDetailLayout>> GetMAMSFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.MAMSDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<LISPartDPremiumDetailLayout>> GetLisPartDPremiumFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.LISPartDPremiumDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<LEPDetailLayout>> GetLEPDetailFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.LEPDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<BEQRequestDetailLayout>> GetBeqRequestFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.BEQRequestDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<BEQResponseDetailLayout>> GetBeqResponseFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.BEQResponseDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<AgentCompDetailLayout>> GetAgentCompFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.AgentCompDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<LISHISTDetailLayout>> GetLisHistFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.LISHISTDetailLayout.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<List<LTIResident>> GetLTIResidentFileData(int dataFileToProcessDetailsID)
        {
            try
            {
                var data = _context.LTIResident.Where(x => x.DataFileToProcessDetailsID == dataFileToProcessDetailsID).ToList();
                return data;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<FileTemplateTypeListViewModel> GetFileTemplateDetails(FileTemplateTypeSearchModel searchModel)
        {
            try
            {
                FileTemplateTypeListViewModel objListViewModel = new FileTemplateTypeListViewModel();
                Dictionary<int, object> filters = new Dictionary<int, object>();
                var query = (from a in _context.FileSubCategories
                             join b in _context.DataFileTemplate on a.FileSubCategoryID equals b.FileSubCategoryId
                             where b.FileTemplateTypeId == 11
                             join c in _context.DataFileProcessConfigurations on b.DataFileTemplateId equals c.DatafileTemplateId
                             join d in _context.DataFileProcessConfigurationDetails on c.DataFileProcessConfigurationId equals d.DataFileProcessConfigurationId
                             join e in _context.DataFileToProcesses on d.DataFileProcessConfigurationId equals e.DataFileProcessConfigurationId
                             join f in _context.DataFileToProcessDetails on e.DataFileToProcessId equals f.DataFileToProcessId
                             select new
                             {
                                 FileSubCategoryID = a.FileSubCategoryID,
                                 FileType = a.SubCategoryName,
                                 FileCategoryID = b.FileCategoryId,
                                 DataFileToProcessDetailsID = f.DataFileToProcessDetailsId,
                                 FileName = f.FileName,
                                 FileDate = f.CreatedDate,
                                 FileCode = b.DataFileCode,
                                 CreatedBy = f.CreatedBy,
                                 Records = f.TotalRecords ?? 0,
                                 FilePath = f.FilePath
                             }).AsQueryable();
                bool isFilter = false;
                int count = 1;
                if (searchModel.fileSubCategoryID != 0)
                {
                    var filterCondition = ("fileSubCategoryID", searchModel.fileSubCategoryID.ToString(), "equal");
                    filters.Add(count++, filterCondition);
                    isFilter = true;
                }
                if (searchModel.fileCategoryID != 0)
                {
                    var filterCondition = ("fileCategoryID", searchModel.fileCategoryID.ToString(), "equal");
                    filters.Add(count++, filterCondition);
                    isFilter = true;
                }
                if (!string.IsNullOrEmpty(searchModel.fileName))
                {
                    var filterCondition = ("FileName", searchModel.fileName, "contains");
                    filters.Add(count++, filterCondition);
                    isFilter = true;
                }
                if (searchModel.fileDateFrom != null)
                {
                    var filterCondition = ("FileDate", searchModel.fileDateFrom.ToString(), "greaterthanorequal");
                    filters.Add(count++, filterCondition);
                    isFilter = true;
                }
                if (searchModel.fileDateTo != null)
                {
                    var filterCondition = ("FileDate", searchModel.fileDateTo.ToString(), "lessthanorequal");
                    filters.Add(count++, filterCondition);
                    isFilter = true;
                }
                if (isFilter)
                {
                    query = query.Where(GetExpression(query, filters));
                }
                int countTotalRecords = query.Count();
                var data = OrderBy(query, searchModel.orderByColumn, searchModel.isDesc).Skip(searchModel.skip).Take(searchModel.take).ToList();
                objListViewModel.FileTemplateList = (from a in data
                                                     select new FileTemplateTypeListModel
                                                     {
                                                         FileSubCategoryID = a.FileSubCategoryID,
                                                         FileCategoryID = a.FileCategoryID,
                                                         DataFileToProcessDetailsID = a.DataFileToProcessDetailsID,
                                                         FileName = a.FileName,
                                                         FileType = a.FileType,
                                                         FileDate = a.FileDate,
                                                         CreatedBy = a.CreatedBy,
                                                         Records = a.Records,
                                                         FileCode = a.FileCode,
                                                         FilePath = a.FilePath,
                                                         TotalRecords = countTotalRecords
                                                     }).ToList();
                objListViewModel.TotalRecords = countTotalRecords;
                return objListViewModel;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetFileTemplateDetails", ex.Message);
                return null;
            }
        }

        public IEnumerable<TEntity> OrderBy<TEntity>(IEnumerable<TEntity> source, string orderByProperty, bool desc)
        {
            string command = desc ? "OrderByDescending" : "OrderBy";
            var type = typeof(TEntity);
            var property = type.GetProperty(orderByProperty);
            var parameter = Expression.Parameter(type, "p");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);
            var resultExpression = Expression.Call(typeof(Queryable), command,
                                                   new[] { type, property.PropertyType },
                                                   source.AsQueryable().Expression,
                                                   Expression.Quote(orderByExpression));
            var data = source.AsQueryable().Provider.CreateQuery<TEntity>(resultExpression);
            return data;
        }

        private Expression<Func<TEntity, bool>> GetExpression<TEntity>(IEnumerable<TEntity> source, Dictionary<int, object> filters)
        {
            var type = typeof(TEntity);
            var parameter = Expression.Parameter(type, "p");
            Expression propertyValueClause = null;
            Expression propertyValueClause_Collection = null;
            MethodInfo ContainsMethod = typeof(string).GetMethod("Contains", new[] { typeof(string) });
            int columnCount = -1;
            foreach (KeyValuePair<int, object> filter in filters)
            {
                var columnName = (((string, string, string))filter.Value).Item1;
                object key_Value = (((string, string, string))filter.Value).Item2;
                var key_condition = (((string, string, string))filter.Value).Item3;

                var propertyInfo = Expression.Property(parameter, columnName);

                Type[] targetTypes = { typeof(SByte), typeof(Int16), typeof(Int32),
                             typeof(Int64), typeof(Byte), typeof(UInt16),
                             typeof(UInt32), typeof(UInt64), typeof(Decimal),
                             typeof(Single), typeof(Double), typeof(String), typeof(DateTime) };

                foreach (Type targetType in targetTypes)
                {
                    if (propertyInfo.Type.Name == targetType.Name)
                    {
                        columnCount = columnCount + 1;
                        key_Value = Convert.ChangeType(key_Value, targetType);
                        if (key_condition.ToLower() == "equal")
                        {
                            propertyValueClause = Expression.Equal(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "lessthan")
                        {
                            propertyValueClause = Expression.LessThan(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "lessthanorequal")
                        {
                            propertyValueClause = Expression.LessThanOrEqual(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "greaterthan")
                        {
                            propertyValueClause = Expression.GreaterThan(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "greaterthanorequal")
                        {
                            propertyValueClause = Expression.GreaterThanOrEqual(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "contains")
                        {
                            propertyValueClause = Expression.Call(propertyInfo, ContainsMethod, Expression.Constant(key_Value));
                        }
                        if (columnCount > 0)
                        {
                            propertyValueClause_Collection = Expression.AndAlso(propertyValueClause_Collection, propertyValueClause);
                        }
                        else
                        {
                            propertyValueClause_Collection = propertyValueClause;
                        }
                        break;
                    }
                }
            }
            return Expression.Lambda<Func<TEntity, bool>>(propertyValueClause_Collection, parameter);
        }
        #endregion
    }
}
