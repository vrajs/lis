﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class DataFileProcessConfigurationDetailsRepository : BaseRepository<DataFileProcessConfigurationDetails>, IDataFileProcessConfigurationDetailsRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public DataFileProcessConfigurationDetailsRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   

        public IEnumerable<DataFileProcessConfigurationDetails> GetAllDataFileProcessConfigurationDetails()
        {
            try
            {
                var res = _context.DataFileProcessConfigurationDetails;
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllDataFileProcessConfigurationDetails", ex.Message);
                return null;
            }
        }
        public DataFileProcessConfigurationDetails GetDataByDataFileProcessConfigurationId(int DataFileProcessConfigurationId)
        {
            DataFileProcessConfigurationDetails DataFileProcessConfiguration = _context.DataFileProcessConfigurationDetails
                                               .Where(e => e.DataFileProcessConfigurationId == Convert.ToInt16(DataFileProcessConfigurationId)).FirstOrDefault();

            return DataFileProcessConfiguration;
        }
        #endregion
    }
}
