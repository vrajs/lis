﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Data.Contracts.ETLStructure;

namespace Kwicle.Data.Repositories.ETLStructure
{
    public class DataFileToProcessRepository : BaseRepository<DataFileToProcess>, IDataFileToProcessRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public DataFileToProcessRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #region Interface Methods Implementation   

        public IEnumerable<DataFileToProcess> GetAllDataFileToProcess()
        {
            try
            {
                var res = _context.DataFileToProcesses.ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllDataFileToProcess", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
