﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimProcessingStepsRepository : BaseRepository<ClaimProcessingSteps>, IClaimProcessingStepsRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimProcessingStepsRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimProcessingSteps> GetAllClaimProcessingSteps()
        {
            try
            {
                var res = _context.ClaimProcessingStepss.ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimProcessingSteps", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimProcessingStepsViewModel> GetClaimProcessingSteps(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimProcessingStepss
                            where b.ClaimHeaderID == ClaimHeaderID
                            select new ClaimProcessingStepsViewModel()
                            {
                                ClaimProcessingStepsID = b.ClaimProcessingStepsID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                ClaimDetailLine = b.ClaimDetailLine,
                                ProcessDate = b.ProcessDate,
                                ProcessStep = b.ProcessStep,
                                ProcessValue = b.ProcessValue,
                                CreatedDate = b.CreatedDate
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimProcessingSteps", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
