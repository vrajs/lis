﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimReferenceRepository : BaseRepository<ClaimReference>, IClaimReferenceRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimReferenceRepository(KwicleContext context) :base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimReference> GetAllClaimReference()
        {
            try
            {
                var res = _context.ClaimReferences.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimReference", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimReferenceViewModel> GetClaimReference(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimReferences
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new ClaimReferenceViewModel()
                            {
                                ClaimReferenceID = b.ClaimReferenceID,
                                CodeTypeID=b.CodeTypeID,
                                CodeValue=b.CodeValue,
                                ControlTypeID=b.ControlTypeID,
                                EffectiveDate=b.EffectiveDate,
                                MemberID = b.MemberID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                TermDate = (b.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : b.TermDate,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimReference", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
