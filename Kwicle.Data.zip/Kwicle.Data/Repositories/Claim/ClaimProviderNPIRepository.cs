﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimProviderNPIRepository : BaseRepository<Kwicle.Core.Entities.ProviderStructure.Provider>, IClaimProviderNPIRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ClaimProviderNPIRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation
        public IQueryable<ClaimProviderNPIViewModel> GetClaimProviderNPI()
        {
            try
            {
                var query = from b in _context.Providers
                            where b.RecordStatus == (byte)RecordStatus.Active
                            select new ClaimProviderNPIViewModel()
                            {
                                FullName=b.FullName,
                                NPI=b.NPI,
                                FirstName=b.FirstName,
                                SecondaryEmail=b.SecondaryEmail,
                                CredentialStatusID=b.CredentialStatusID,
                                Dob=b.DOB,
                                Ethnicity=b.Ethnicity,
                                Fax=b.Fax,
                                IsSpecialist=b.IsSpecialist,
                                IsProviderWatch=b.IsProviderWatch,
                                Gender=b.Gender,
                                IsPCP=b.IsPCP,
                                IsPerson=b.IsPerson,
                                LastName=b.LastName,
                                MaxMemberCount=b.MaxMemberCount,
                                MiddleName=b.MiddleName,
                                Phone=b.Phone,
                                PrimaryEmail=b.PrimaryEmail,
                                ProviderCode=b.ProviderCode,
                                ProviderEligibilityID=b.ProviderEligibilityID,
                                ProviderID=b.ProviderID,
                                ProviderTypeID=b.ProviderTypeID,
                                Race=b.Race,
                                SSN=b.SSN,
                                Suffix=b.Suffix,
                                Title=b.Title

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimProviderNPI", ex.Message);
                return null;
            }
        }

        #endregion
    }
}
