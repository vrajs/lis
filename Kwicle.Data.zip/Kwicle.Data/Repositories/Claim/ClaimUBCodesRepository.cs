﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimUBCodesRepository : BaseRepository<ClaimUBCodes>, IClaimUBCodesRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimUBCodesRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimUBCodes> GetAllClaimUBCodes()
        {
            try
            {
                var res = _context.ClaimUBCodess.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimUBCodes", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimUBCodesViewModel> GetClaimUBCodes(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimUBCodess
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new ClaimUBCodesViewModel()
                            {
                                ClaimUBCodesID = b.ClaimUBCodesID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                TypeID = b.TypeID,
                                UBCode = b.UBCode,
                                Description = b.Description,
                                FromDate = b.FromDate,
                                ToDate = (b.ToDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : b.ToDate,
                                Amount = b.Amount,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimUBCodes", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
