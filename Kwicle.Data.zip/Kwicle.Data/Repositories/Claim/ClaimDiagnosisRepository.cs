﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimDiagnosisRepository : BaseRepository<ClaimDiagnosis>, IClaimDiagnosisRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimDiagnosisRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimDiagnosis> GetAllClaimDiagnosis()
        {
            try
            {
                var res = _context.ClaimDiagnoses.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimDiagnoses", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimDiagnosisViewModel> GetClaimDiagnosis(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimDiagnoses
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            join icd in _context.ICDCodes on b.DiagnosisCode equals icd.Code
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            && ((icd.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD9CMDX) || (icd.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD10CMDX))
                            select new ClaimDiagnosisViewModel()
                            {
                                ClaimDiagnosisID = b.ClaimDiagnosisID,
                                DiagnosisCode = b.DiagnosisCode,
                                DiagnosisDescription = b.DiagnosisDescription,
                                DiagnosisProdedure = b.DiagnosisCode,
                                DiagnosisTypeID = b.DiagnosisTypeID,
                                DiagnosisPointer = b.DiagnosisPointer,
                                Qualifier = b.Qualifier,
                                IsPOA = b.IsPOA != null && b.IsPOA == true ? true : false,
                                ProcDate = b.ProcDate,
                                MemberID = b.MemberID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                DiagnosisPointerStr = b.DiagnosisPointer.ToString(),
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimDiagnoses", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimDiagnosisViewModel> GetClaimDiagnosisProcedure(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimDiagnoses
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            join icd in _context.ICDCodes on b.DiagnosisCode equals icd.Code
                            where b.ClaimHeaderID == ClaimHeaderID && icd.RecordStatus == (int)RecordStatus.Active && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                             && ((icd.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD9CMPCS) || (icd.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD10CMPCS))
                            select new ClaimDiagnosisViewModel()
                            {
                                ClaimDiagnosisID = b.ClaimDiagnosisID,
                                DiagnosisProdedure = b.DiagnosisCode,
                                DiagnosisCode = b.DiagnosisCode,
                                DiagnosisDescription = b.DiagnosisDescription,
                                DiagnosisTypeID = b.DiagnosisTypeID,
                                DiagnosisPointer = b.DiagnosisPointer,
                                Qualifier = b.Qualifier,
                                IsPOA = b.IsPOA != null && b.IsPOA == true ? true : false,
                                ProcDate = b.ProcDate,
                                MemberID = b.MemberID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                DiagnosisPointerStr = b.DiagnosisPointer.ToString(),
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimDiagnoseProcedure", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
