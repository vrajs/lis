﻿using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.Claim;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Kwicle.Data.Repositories.Claim
{
    public class ExternalClaimRepository : IExternalClaimRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public ExternalClaimRepository(KwicleContext context, KwicleViewContext viewContext)
        {
            _context = context;
            _viewContext = viewContext;

        }
        
        #endregion

        #region Interface Methods Implementation  
        
        public ExternalClaimStatusViewModel InsertExternalClaim(ExternalClaimImportViewModel objExternalClaimImportViewModel)
        {
            ExternalClaimStatusViewModel objExternalClaimStatusViewModel = new ExternalClaimStatusViewModel();

            if (objExternalClaimImportViewModel != null)
            {

                IList<ClaimHeaderInsertUpdateViewModel> lstClaimHeaderInsertUpdateViewModel = new List<ClaimHeaderInsertUpdateViewModel>();
                lstClaimHeaderInsertUpdateViewModel.Add(objExternalClaimImportViewModel.ClaimHeaderInfo);
                DataTable udtExternalClaimHeader = new DataTable("udtExternalClaimHeader");
                //udtExternalClaimHeader = lstClaimHeaderInsertUpdateViewModel != null && lstClaimHeaderInsertUpdateViewModel[0] != null ? ToDataTableFromIList(lstClaimHeaderInsertUpdateViewModel) : null;
                udtExternalClaimHeader = GetClaimHeaderInfoDataTable(objExternalClaimImportViewModel.ClaimHeaderInfo);

                DataTable udtExternalClaimDiagnosis = new DataTable("udtExternalClaimDiagnosis");
                //udtExternalClaimDiagnosis = objExternalClaimImportViewModel.ClaimDiagnosisList != null && objExternalClaimImportViewModel.ClaimDiagnosisList.Count > 0 && objExternalClaimImportViewModel.ClaimDiagnosisList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimDiagnosisList) : null;
                udtExternalClaimDiagnosis = GetClaimDiagnosisDataTable(objExternalClaimImportViewModel.ClaimDiagnosisList);

                DataTable udtExternalClaimService = new DataTable("udtExternalClaimService");
                //udtExternalClaimService = objExternalClaimImportViewModel.ClaimServiceList != null && objExternalClaimImportViewModel.ClaimServiceList.Count > 0 && objExternalClaimImportViewModel.ClaimServiceList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimServiceList) : null;
                udtExternalClaimService = GetClaimServiceDataTable(objExternalClaimImportViewModel.ClaimServiceList);

                DataTable udtExternalClaimReference = new DataTable("udtExternalClaimReference");
                //udtExternalClaimReference = objExternalClaimImportViewModel.ClaimReferenceList != null && objExternalClaimImportViewModel.ClaimReferenceList.Count > 0 && objExternalClaimImportViewModel.ClaimReferenceList[0] !=  null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimReferenceList) : null;
                udtExternalClaimReference = GetClaimReferenceDataTable(objExternalClaimImportViewModel.ClaimReferenceList);

                DataTable udtExternalClaimOtherInsurance = new DataTable("udtExternalClaimOtherInsurance");
                //udtExternalClaimOtherInsurance = objExternalClaimImportViewModel.ClaimOtherInsuranceList != null && objExternalClaimImportViewModel.ClaimOtherInsuranceList.Count > 0 && objExternalClaimImportViewModel.ClaimOtherInsuranceList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimOtherInsuranceList) : null;
                udtExternalClaimOtherInsurance = GetClaimOtherInsuranceDataTable(objExternalClaimImportViewModel.ClaimOtherInsuranceList);

                DataTable udtExternalClaimAudit = new DataTable("udtExternalClaimAudit");
                //udtExternalClaimAudit = objExternalClaimImportViewModel.ClaimAuditList != null && objExternalClaimImportViewModel.ClaimAuditList.Count > 0 && objExternalClaimImportViewModel.ClaimAuditList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimAuditList) : null;
                udtExternalClaimAudit = GetClaimAuditDataTable(objExternalClaimImportViewModel.ClaimAuditList);

                DataTable udtExternalClaimEdits = new DataTable("udtExternalClaimEdits");
                //udtExternalClaimEdits = objExternalClaimImportViewModel.ClaimEditsList != null && objExternalClaimImportViewModel.ClaimEditsList.Count > 0 && objExternalClaimImportViewModel.ClaimEditsList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimEditsList) : null;
                //udtExternalClaimEdits = GetClaimEditsDataTable(objExternalClaimImportViewModel.ClaimEditsList);

                DataTable udtExternalClaimNotes = new DataTable("udtExternalClaimNotes");
                //udtExternalClaimNotes = objExternalClaimImportViewModel.ClaimNotesList != null && objExternalClaimImportViewModel.ClaimNotesList.Count > 0 && objExternalClaimImportViewModel.ClaimNotesList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimNotesList) : null;
                udtExternalClaimNotes = GetClaimNotesDataTable(objExternalClaimImportViewModel.ClaimNotesList);

                DataTable udtExternalClaimProcessingSteps = new DataTable("udtExternalClaimProcessingSteps");
                //udtExternalClaimProcessingSteps = objExternalClaimImportViewModel.ClaimProcessingStepsList != null && objExternalClaimImportViewModel.ClaimProcessingStepsList.Count > 0 && objExternalClaimImportViewModel.ClaimProcessingStepsList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimProcessingStepsList) : null;
                udtExternalClaimProcessingSteps = GetClaimProcessingStepsDataTable(objExternalClaimImportViewModel.ClaimProcessingStepsList);

                DataTable udtExternalClaimEOBEOP = new DataTable("udtExternalClaimEOBEOP");
                //udtExternalClaimEOBEOP = objExternalClaimImportViewModel.ClaimEOBEOPList != null && objExternalClaimImportViewModel.ClaimEOBEOPList.Count > 0 && objExternalClaimImportViewModel.ClaimEOBEOPList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimEOBEOPList) : null;
                udtExternalClaimEOBEOP = GetClaimEOBEOPDataTable(objExternalClaimImportViewModel.ClaimEOBEOPList);

                DataTable udtExternalClaimOtherPhysician = new DataTable("udtExternalClaimOtherPhysician");
                //udtExternalClaimOtherPhysician = objExternalClaimImportViewModel.ClaimOtherPhysicianList != null && objExternalClaimImportViewModel.ClaimOtherPhysicianList.Count > 0 && objExternalClaimImportViewModel.ClaimOtherPhysicianList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimOtherPhysicianList) : null;
                udtExternalClaimOtherPhysician = GetClaimOtherPhysicianDataTable(objExternalClaimImportViewModel.ClaimOtherPhysicianList);

                DataTable udtExternalClaimUBCodes = new DataTable("udtExternalClaimUBCodes");
                //udtExternalClaimUBCodes = objExternalClaimImportViewModel.ClaimUBCodesList != null && objExternalClaimImportViewModel.ClaimUBCodesList.Count > 0 && objExternalClaimImportViewModel.ClaimUBCodesList[0] != null ? ToDataTableFromIList(objExternalClaimImportViewModel.ClaimUBCodesList) : null;
                udtExternalClaimUBCodes = GetClaimUBCodesDataTable(objExternalClaimImportViewModel.ClaimUBCodesList);


                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@udtExternalClaimHeader", udtExternalClaimHeader) { TypeName = "hps.ExternalClaimHeader" });
                parameters.Add(new SqlParameter("@udtExternalClaimDiagnosis", udtExternalClaimDiagnosis) { TypeName = "hps.ExternalClaimDiagnosis" });
                parameters.Add(new SqlParameter("@udtExternalClaimService", udtExternalClaimService) { TypeName = "hps.ExternalClaimService" });
                parameters.Add(new SqlParameter("@udtExternalClaimReference", udtExternalClaimReference) { TypeName = "hps.ExternalClaimReference" });
                parameters.Add(new SqlParameter("@udtExternalClaimOtherInsurance", udtExternalClaimOtherInsurance) { TypeName = "hps.ExternalClaimOtherInsurance" });
                parameters.Add(new SqlParameter("@udtExternalClaimAudit", udtExternalClaimAudit) { TypeName = "hps.ExternalClaimAudit" });
                parameters.Add(new SqlParameter("@udtExternalClaimEdits", udtExternalClaimEdits) { TypeName = "hps.ExternalClaimEdits" });
                parameters.Add(new SqlParameter("@udtExternalClaimNotes", udtExternalClaimNotes) { TypeName = "hps.ExternalClaimNotes" });
                parameters.Add(new SqlParameter("@udtExternalClaimProcessingSteps", udtExternalClaimProcessingSteps) { TypeName = "hps.ExternalClaimProcessingSteps" });
                parameters.Add(new SqlParameter("@udtExternalClaimEOBEOP", udtExternalClaimEOBEOP) { TypeName = "hps.ExternalClaimEOBEOP" });
                parameters.Add(new SqlParameter("@udtExternalClaimOtherPhysician", udtExternalClaimOtherPhysician) { TypeName = "hps.ExternalClaimOtherPhysician" });
                parameters.Add(new SqlParameter("@udtExternalClaimUBCodes", udtExternalClaimUBCodes) { TypeName = "hps.ExternalClaimUBCodes" });
                parameters.Add(new SqlParameter("@ClaimHeaderID", SqlDbType.BigInt) { Direction = ParameterDirection.Output });
                parameters.Add(new SqlParameter("@ClaimNumber", SqlDbType.VarChar, 32) { Direction = ParameterDirection.Output });
                parameters.Add(new SqlParameter("@ClaimStatus", SqlDbType.VarChar, 50) { Direction = ParameterDirection.Output });
                parameters.Add(new SqlParameter("@ClaimInformationMessage", SqlDbType.VarChar, 200) { Direction = ParameterDirection.Output });
                parameters.Add(new SqlParameter("@ClaimError", SqlDbType.VarChar, -1) { Direction = ParameterDirection.Output });

                _context.Database.ExecuteSqlRaw("[hps].[usp_InsertExternalClaim] @udtExternalClaimHeader, @udtExternalClaimDiagnosis, @udtExternalClaimService, @udtExternalClaimReference, @udtExternalClaimOtherInsurance" +
                                                                                                                ", @udtExternalClaimAudit, @udtExternalClaimEdits, @udtExternalClaimNotes, @udtExternalClaimProcessingSteps, @udtExternalClaimEOBEOP" +
                                                                                                                ", @udtExternalClaimOtherPhysician, @udtExternalClaimUBCodes" +
                                                                                                                ", @ClaimHeaderID OUT, @ClaimNumber OUT, @ClaimStatus OUT, @ClaimInformationMessage OUT, @ClaimError OUT", parameters.ToArray());

                objExternalClaimStatusViewModel.ClaimHeaderID = (Int64)parameters.Where(e => e.ParameterName == "@ClaimHeaderID").FirstOrDefault().Value;                
                objExternalClaimStatusViewModel.ClaimNumber = (string)parameters.Where(e => e.ParameterName == "@ClaimNumber").FirstOrDefault().Value;
                objExternalClaimStatusViewModel.ClaimStatus = (string)parameters.Where(e => e.ParameterName == "@ClaimStatus").FirstOrDefault().Value;
                objExternalClaimStatusViewModel.ClaimInformationMessage = (string)parameters.Where(e => e.ParameterName == "@ClaimInformationMessage").FirstOrDefault().Value;
                objExternalClaimStatusViewModel.ClaimError = (string)parameters.Where(e => e.ParameterName == "@ClaimError").FirstOrDefault().Value;
            }

            return objExternalClaimStatusViewModel;
        }

        #region Different Methods to get DataTable from different List Objects        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimHeaderInfo"></param>
        /// <returns></returns>
        private DataTable GetClaimHeaderInfoDataTable(ClaimHeaderInsertUpdateViewModel ClaimHeaderInfo)
        {
            #region Create DataTable for ClaimHeaderInfo and Add Required Columns.

            DataTable dtClaimHeaderInfo = new DataTable("udtExternalClaimHeader");

            dtClaimHeaderInfo.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimHeaderInfo.Columns.Add("AddedSource", typeof(string));
            dtClaimHeaderInfo.Columns.Add("AdmitDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("AdmitHour", typeof(byte));
            dtClaimHeaderInfo.Columns.Add("AdmitSourceID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("AdmitTypeID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("AltFeeScheduleID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("BillTypeID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("BilledAmount", typeof(decimal));
            dtClaimHeaderInfo.Columns.Add("BilledDRGCode", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ClaimAge", typeof(short));
            dtClaimHeaderInfo.Columns.Add("ClaimNumber", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ClaimSourceID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("ClaimStatusID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("ClaimStatusReason", typeof(string));
            dtClaimHeaderInfo.Columns.Add("CreatedBy", typeof(string));
            dtClaimHeaderInfo.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("DCN", typeof(string));
            dtClaimHeaderInfo.Columns.Add("DOSFrom", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("DOSTo", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("DischargeHour", typeof(byte));
            dtClaimHeaderInfo.Columns.Add("DischargeStatusID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("EnteredDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("ExternalClaimID", typeof(string));
            dtClaimHeaderInfo.Columns.Add("FormTypeID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("IllnessDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("IsAcceptsAssignment", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsAlternatePayee", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsAuto", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsCleanClaim", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsCorrectedClaim", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsEPSDTTitleXIX", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsEmployment", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsEncounter", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsFreezed", typeof(byte));
            dtClaimHeaderInfo.Columns.Add("IsOtherAccident", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsPatientReimbursement", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsPayAndPursue", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsPreDetermiantion", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsRefundRequest", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsSplitPayment", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("IsSuppressEOB", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("LoadComment", typeof(string));
            dtClaimHeaderInfo.Columns.Add("MemberID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("OtherDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("OtherInsurancePaid", typeof(decimal));
            dtClaimHeaderInfo.Columns.Add("PaidAmount", typeof(decimal));
            dtClaimHeaderInfo.Columns.Add("PaidDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("PatientAccountNumber", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PhysicianNPI", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PhysicianName", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PriorAuthNumber", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ProviderID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("ProviderTypeID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("ReceivedDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("RecordStatus", typeof(byte));
            dtClaimHeaderInfo.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimHeaderInfo.Columns.Add("RevisedDRGCode", typeof(string));
            dtClaimHeaderInfo.Columns.Add("UpdatedBy", typeof(string));
            dtClaimHeaderInfo.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("UpdatedSource", typeof(string));
            dtClaimHeaderInfo.Columns.Add("VendorName", typeof(string));
            dtClaimHeaderInfo.Columns.Add("DOB", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("Gender", typeof(char));
            dtClaimHeaderInfo.Columns.Add("MemberCode", typeof(string));
            dtClaimHeaderInfo.Columns.Add("MemberEligibilityID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("MemberName", typeof(string));
            dtClaimHeaderInfo.Columns.Add("MemberPCPID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("PCPID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("PCPName", typeof(string));
            dtClaimHeaderInfo.Columns.Add("Plan", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ProviderCode", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ProviderGroupTIN", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ProviderNPI", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ProviderName", typeof(string));
            dtClaimHeaderInfo.Columns.Add("Relationship", typeof(string));
            dtClaimHeaderInfo.Columns.Add("EffectiveDate", typeof(DateTime));
            dtClaimHeaderInfo.Columns.Add("PayeeAddress1", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PayeeAddress2", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PayeeCity", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PayeeName", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PayeeState", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PayeeTin", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PayeeZip", typeof(string));
            dtClaimHeaderInfo.Columns.Add("PaymentRedirectReason", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ReasonForSplitPayment", typeof(string));
            dtClaimHeaderInfo.Columns.Add("ReimburseAmount", typeof(decimal));
            dtClaimHeaderInfo.Columns.Add("ReimburseReminderToProvider", typeof(bool));
            dtClaimHeaderInfo.Columns.Add("VendorID", typeof(int));
            dtClaimHeaderInfo.Columns.Add("ServiceRendered", typeof(string));
            dtClaimHeaderInfo.Columns.Add("AccidentStateOrProvince", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimHeaderInfo != null)
            {
                DataRow drClaimHeaderInfo;
                drClaimHeaderInfo = dtClaimHeaderInfo.NewRow();

                drClaimHeaderInfo["ClaimHeaderID"] = 0; //Mandatory Field
                drClaimHeaderInfo["AddedSource"] = string.IsNullOrEmpty(ClaimHeaderInfo.AddedSource) != true && Convert.ToString(ClaimHeaderInfo.AddedSource.Trim()) != string.Empty ? ClaimHeaderInfo.AddedSource.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["AdmitDate"] = ClaimHeaderInfo.AdmitDate != null ? ClaimHeaderInfo.AdmitDate : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["AdmitHour"] = ClaimHeaderInfo.AdmitHour != null ? ClaimHeaderInfo.AdmitHour : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["AdmitSourceID"] = ClaimHeaderInfo.AdmitSourceID != null && ClaimHeaderInfo.AdmitSourceID > 0 ? ClaimHeaderInfo.AdmitSourceID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["AdmitTypeID"] = ClaimHeaderInfo.AdmitTypeID != null && ClaimHeaderInfo.AdmitTypeID > 0 ? ClaimHeaderInfo.AdmitTypeID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["AltFeeScheduleID"] = ClaimHeaderInfo.AltFeeScheduleID != null && ClaimHeaderInfo.AltFeeScheduleID > 0 ? ClaimHeaderInfo.AltFeeScheduleID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["BillTypeID"] = ClaimHeaderInfo.BillTypeID != null && ClaimHeaderInfo.BillTypeID > 0 ? ClaimHeaderInfo.BillTypeID : (object)DBNull.Value; //Not Mandatory Field 
                drClaimHeaderInfo["BilledAmount"] = ClaimHeaderInfo.BilledAmount > 0 ? ClaimHeaderInfo.BilledAmount : Decimal.Zero; //Mandatory Field
                drClaimHeaderInfo["BilledDRGCode"] = string.IsNullOrEmpty(ClaimHeaderInfo.BilledDRGCode) != true && Convert.ToString(ClaimHeaderInfo.BilledDRGCode.Trim()) != string.Empty ? ClaimHeaderInfo.BilledDRGCode.Trim() : string.Empty; //Not Mandatory Field
                drClaimHeaderInfo["ClaimAge"] = ClaimHeaderInfo.ClaimAge != null ? ClaimHeaderInfo.ClaimAge : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["ClaimSourceID"] = ClaimHeaderInfo.ClaimSourceID > 0 ? ClaimHeaderInfo.ClaimSourceID : (int)ClaimSource.EDI; //Mandatory Field
                drClaimHeaderInfo["ClaimStatusID"] = ClaimHeaderInfo.ClaimStatusID > 0 ? ClaimHeaderInfo.ClaimStatusID : (int)ClaimStatus.Load; //Mandatory Field
                drClaimHeaderInfo["ClaimStatusReason"] = string.IsNullOrEmpty(ClaimHeaderInfo.ClaimStatusReason) != true && Convert.ToString(ClaimHeaderInfo.ClaimStatusReason.Trim()) != string.Empty ? ClaimHeaderInfo.ClaimStatusReason.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["CreatedBy"] = "ExternalInterface"; // ClaimHeaderInfo.CreatedBy; //Mandatory Field
                drClaimHeaderInfo["CreatedDate"] = DateTime.Now; //Mandatory Field
                drClaimHeaderInfo["DCN"] = string.IsNullOrEmpty(ClaimHeaderInfo.DCN) != true && Convert.ToString(ClaimHeaderInfo.DCN.Trim()) != string.Empty ? ClaimHeaderInfo.DCN.Trim() : string.Empty; //Not Mandatory Field
                drClaimHeaderInfo["DOSFrom"] = ClaimHeaderInfo.DOSFrom; //Mandatory Field
                drClaimHeaderInfo["DOSTo"] = ClaimHeaderInfo.DOSTo; //Mandatory Field
                drClaimHeaderInfo["DischargeHour"] = ClaimHeaderInfo.DischargeHour != null ? ClaimHeaderInfo.DischargeHour : (object)DBNull.Value; //Mandatory Fieldt Mandatory Field
                drClaimHeaderInfo["DischargeStatusID"] = ClaimHeaderInfo.DischargeStatusID != null && ClaimHeaderInfo.DischargeStatusID > 0 ? ClaimHeaderInfo.DischargeStatusID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["EnteredDate"] = ClaimHeaderInfo.EnteredDate; //Mandatory Field
                drClaimHeaderInfo["ExternalClaimID"] = string.IsNullOrEmpty(ClaimHeaderInfo.ExternalClaimID) != true && Convert.ToString(ClaimHeaderInfo.ExternalClaimID.Trim()) != string.Empty ? ClaimHeaderInfo.ExternalClaimID.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["FormTypeID"] = ClaimHeaderInfo.FormTypeID; //Mandatory Field
                drClaimHeaderInfo["IllnessDate"] = ClaimHeaderInfo.IllnessDate != null && Convert.ToString(ClaimHeaderInfo.IllnessDate).Trim() != string.Empty ? ClaimHeaderInfo.IllnessDate : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["IsAcceptsAssignment"] = ClaimHeaderInfo.IsAcceptsAssignment; //Mandatory Field
                drClaimHeaderInfo["IsAlternatePayee"] = ClaimHeaderInfo.IsAlternatePayee; //Mandatory Field
                drClaimHeaderInfo["IsAuto"] = ClaimHeaderInfo.IsAuto; //Mandatory Field
                drClaimHeaderInfo["IsCleanClaim"] = ClaimHeaderInfo.IsCleanClaim; //Mandatory Field
                drClaimHeaderInfo["IsCorrectedClaim"] = ClaimHeaderInfo.IsCorrectedClaim; //Mandatory Field
                drClaimHeaderInfo["IsEPSDTTitleXIX"] = ClaimHeaderInfo.IsEPSDTTitleXIX != null ? ClaimHeaderInfo.IsEPSDTTitleXIX : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["IsEmployment"] = ClaimHeaderInfo.IsEmployment; //Mandatory Field
                drClaimHeaderInfo["IsEncounter"] = ClaimHeaderInfo.IsEncounter; //Mandatory Field
                drClaimHeaderInfo["IsFreezed"] = false; // ClaimHeaderInfo.IsFreezed; //Mandatory Field
                drClaimHeaderInfo["IsOtherAccident"] = ClaimHeaderInfo.IsOtherAccident; //Mandatory Field
                drClaimHeaderInfo["IsPatientReimbursement"] = ClaimHeaderInfo.IsPatientReimbursement; //Mandatory Field
                drClaimHeaderInfo["IsPayAndPursue"] = ClaimHeaderInfo.IsPayAndPursue; //Mandatory Field
                drClaimHeaderInfo["IsPreDetermiantion"] = ClaimHeaderInfo.IsPreDetermiantion != null ? ClaimHeaderInfo.IsPreDetermiantion : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["IsRefundRequest"] = ClaimHeaderInfo.IsRefundRequest; //Mandatory Field
                drClaimHeaderInfo["IsSplitPayment"] = ClaimHeaderInfo.IsSplitPayment; //Mandatory Field
                drClaimHeaderInfo["IsSuppressEOB"] = ClaimHeaderInfo.IsSuppressEOB; //Mandatory Field
                drClaimHeaderInfo["LoadComment"] = string.Empty; // ClaimHeaderInfo.LoadComment; //Not Mandatory Field
                drClaimHeaderInfo["MemberID"] = ClaimHeaderInfo.MemberID; //Mandatory Field
                drClaimHeaderInfo["OtherDate"] = ClaimHeaderInfo.OtherDate != null && Convert.ToString(ClaimHeaderInfo.OtherDate).Trim() != string.Empty ? ClaimHeaderInfo.OtherDate : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["OtherInsurancePaid"] = ClaimHeaderInfo.OtherInsurancePaid > 0 ? ClaimHeaderInfo.OtherInsurancePaid : Decimal.Zero; //Mandatory Field
                drClaimHeaderInfo["PaidAmount"] = ClaimHeaderInfo.PaidAmount > 0 ? ClaimHeaderInfo.PaidAmount : Decimal.Zero; //Mandatory Field
                drClaimHeaderInfo["PaidDate"] = ClaimHeaderInfo.PaidDate != null && Convert.ToString(ClaimHeaderInfo.PaidDate).Trim() != string.Empty ? ClaimHeaderInfo.PaidDate : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["PatientAccountNumber"] = string.IsNullOrEmpty(ClaimHeaderInfo.PatientAccountNumber) != true && Convert.ToString(ClaimHeaderInfo.PatientAccountNumber.Trim()) != string.Empty ? ClaimHeaderInfo.PatientAccountNumber.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PhysicianNPI"] = string.IsNullOrEmpty(ClaimHeaderInfo.PhysicianNPI) != true && Convert.ToString(ClaimHeaderInfo.PhysicianNPI.Trim()) != string.Empty ? ClaimHeaderInfo.PhysicianNPI.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PhysicianName"] = string.IsNullOrEmpty(ClaimHeaderInfo.PhysicianName) != true && Convert.ToString(ClaimHeaderInfo.PhysicianName.Trim()) != string.Empty ? ClaimHeaderInfo.PhysicianName.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PriorAuthNumber"] = string.IsNullOrEmpty(ClaimHeaderInfo.PriorAuthNumber) != true && Convert.ToString(ClaimHeaderInfo.PriorAuthNumber.Trim()) != string.Empty ? ClaimHeaderInfo.PriorAuthNumber.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ProviderID"] = ClaimHeaderInfo.ProviderID; //Mandatory Field
                drClaimHeaderInfo["ProviderTypeID"] = ClaimHeaderInfo.ProviderTypeID != null && ClaimHeaderInfo.ProviderTypeID > 0 ? ClaimHeaderInfo.ProviderTypeID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["ReceivedDate"] = ClaimHeaderInfo.ReceivedDate; //Mandatory Field
                drClaimHeaderInfo["RecordStatus"] = (byte)RecordStatus.Active; //Mandatory Field
                drClaimHeaderInfo["RecordStatusChangeComment"] = string.Empty; // ClaimHeaderInfo.RecordStatusChangeComment; //Mandatory Field
                drClaimHeaderInfo["RevisedDRGCode"] = ClaimHeaderInfo.RevisedDRGCode; //Not Mandatory Field
                drClaimHeaderInfo["UpdatedBy"] = string.Empty; // ClaimHeaderInfo.UpdatedBy; //Not Mandatory Field
                drClaimHeaderInfo["UpdatedDate"] = (object)DBNull.Value;  // ClaimHeaderInfo.UpdatedDate; //Not Mandatory Field
                drClaimHeaderInfo["UpdatedSource"] = string.Empty; // ClaimHeaderInfo.UpdatedSource; //Not Mandatory Field
                drClaimHeaderInfo["VendorName"] = string.IsNullOrEmpty(ClaimHeaderInfo.VendorName) != true && Convert.ToString(ClaimHeaderInfo.VendorName.Trim()) != string.Empty ? ClaimHeaderInfo.VendorName.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["DOB"] = ClaimHeaderInfo.DOB != null && Convert.ToString(ClaimHeaderInfo.DOB).Trim() != string.Empty ? ClaimHeaderInfo.DOB : (object)DBNull.Value; ; //Not Mandatory Field
                drClaimHeaderInfo["Gender"] = string.IsNullOrEmpty(ClaimHeaderInfo.Gender) != true && Convert.ToString(ClaimHeaderInfo.Gender.Trim()) != string.Empty ? ClaimHeaderInfo.Gender.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["MemberCode"] = string.IsNullOrEmpty(ClaimHeaderInfo.MemberCode) != true && Convert.ToString(ClaimHeaderInfo.MemberCode.Trim()) != string.Empty ? ClaimHeaderInfo.MemberCode.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["MemberEligibilityID"] = ClaimHeaderInfo.MemberEligibilityID != null && ClaimHeaderInfo.MemberEligibilityID > 0 ? ClaimHeaderInfo.MemberEligibilityID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["MemberName"] = string.IsNullOrEmpty(ClaimHeaderInfo.MemberName) != true && Convert.ToString(ClaimHeaderInfo.MemberName.Trim()) != string.Empty ? ClaimHeaderInfo.MemberName.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["MemberPCPID"] = ClaimHeaderInfo.MemberPCPID != null && ClaimHeaderInfo.MemberPCPID > 0 ? ClaimHeaderInfo.MemberPCPID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["PCPID"] = ClaimHeaderInfo.PCPID != null && ClaimHeaderInfo.PCPID > 0 ? ClaimHeaderInfo.PCPID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["PCPName"] = string.IsNullOrEmpty(ClaimHeaderInfo.PCPName) != true && Convert.ToString(ClaimHeaderInfo.PCPName.Trim()) != string.Empty ? ClaimHeaderInfo.PCPName.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["Plan"] = string.IsNullOrEmpty(ClaimHeaderInfo.Plan) != true && Convert.ToString(ClaimHeaderInfo.Plan.Trim()) != string.Empty ? ClaimHeaderInfo.Plan.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ProviderCode"] = string.IsNullOrEmpty(ClaimHeaderInfo.ProviderCode) != true && Convert.ToString(ClaimHeaderInfo.ProviderCode.Trim()) != string.Empty ? ClaimHeaderInfo.ProviderCode.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ProviderGroupTIN"] = string.IsNullOrEmpty(ClaimHeaderInfo.ProviderGroupTIN) != true && Convert.ToString(ClaimHeaderInfo.ProviderGroupTIN.Trim()) != string.Empty ? ClaimHeaderInfo.ProviderGroupTIN.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ProviderNPI"] = string.IsNullOrEmpty(ClaimHeaderInfo.ProviderNPI) != true && Convert.ToString(ClaimHeaderInfo.ProviderNPI.Trim()) != string.Empty ? ClaimHeaderInfo.ProviderNPI.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ProviderName"] = string.IsNullOrEmpty(ClaimHeaderInfo.ProviderName) != true && Convert.ToString(ClaimHeaderInfo.ProviderName.Trim()) != string.Empty ? ClaimHeaderInfo.ProviderName.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["Relationship"] = string.IsNullOrEmpty(ClaimHeaderInfo.Relationship) != true && Convert.ToString(ClaimHeaderInfo.Relationship.Trim()) != string.Empty ? ClaimHeaderInfo.Relationship.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["EffectiveDate"] = ClaimHeaderInfo.EffectiveDate; //Mandatory Field
                drClaimHeaderInfo["PayeeAddress1"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeAddress1) != true && Convert.ToString(ClaimHeaderInfo.PayeeAddress1.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeAddress1.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PayeeAddress2"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeAddress2) != true && Convert.ToString(ClaimHeaderInfo.PayeeAddress2.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeAddress2.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PayeeCity"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeCity) != true && Convert.ToString(ClaimHeaderInfo.PayeeCity.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeCity.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PayeeName"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeName) != true && Convert.ToString(ClaimHeaderInfo.PayeeName.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeName.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PayeeState"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeState) != true && Convert.ToString(ClaimHeaderInfo.PayeeState.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeState.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PayeeTin"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeTin) != true && Convert.ToString(ClaimHeaderInfo.PayeeTin.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeTin.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PayeeZip"] = string.IsNullOrEmpty(ClaimHeaderInfo.PayeeZip) != true && Convert.ToString(ClaimHeaderInfo.PayeeZip.Trim()) != string.Empty ? ClaimHeaderInfo.PayeeZip.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["PaymentRedirectReason"] = string.IsNullOrEmpty(ClaimHeaderInfo.PaymentRedirectReason) != true && Convert.ToString(ClaimHeaderInfo.PaymentRedirectReason.Trim()) != string.Empty ? ClaimHeaderInfo.PaymentRedirectReason.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ReasonForSplitPayment"] = string.IsNullOrEmpty(ClaimHeaderInfo.ReasonForSplitPayment) != true && Convert.ToString(ClaimHeaderInfo.ReasonForSplitPayment.Trim()) != string.Empty ? ClaimHeaderInfo.ReasonForSplitPayment.Trim() : string.Empty; //Mandatory Field
                drClaimHeaderInfo["ReimburseAmount"] = ClaimHeaderInfo.ReimburseAmount > 0 ? ClaimHeaderInfo.ReimburseAmount : Decimal.Zero; //Mandatory Field
                drClaimHeaderInfo["ReimburseReminderToProvider"] = ClaimHeaderInfo.ReimburseReminderToProvider; //Mandatory Field
                drClaimHeaderInfo["VendorID"] = ClaimHeaderInfo.VendorID != null && ClaimHeaderInfo.VendorID > 0 ? ClaimHeaderInfo.VendorID : (object)DBNull.Value; //Not Mandatory Field
                drClaimHeaderInfo["ServiceRendered"] = string.IsNullOrEmpty(ClaimHeaderInfo.ServiceRendered) != true && Convert.ToString(ClaimHeaderInfo.ServiceRendered.Trim()) != string.Empty ? ClaimHeaderInfo.ServiceRendered.Trim() : string.Empty; //Not Mandatory Field
                drClaimHeaderInfo["AccidentStateOrProvince"] = string.IsNullOrEmpty(ClaimHeaderInfo.AccidentStateOrProvince) != true && Convert.ToString(ClaimHeaderInfo.AccidentStateOrProvince.Trim()) != string.Empty ? ClaimHeaderInfo.AccidentStateOrProvince.Trim() : string.Empty; //Mandatory Field

                dtClaimHeaderInfo.Rows.Add(drClaimHeaderInfo);
            }

            #endregion

            return dtClaimHeaderInfo;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimDiagnosisList"></param>
        /// <returns></returns>
        private DataTable GetClaimDiagnosisDataTable(List<ClaimDiagnosisViewModel> ClaimDiagnosisList)
        {
            #region Create DataTable for ClaimDiagnosis and Add Required Columns.

            DataTable dtClaimDiagnosis = new DataTable("udtExternalClaimDiagnosis");

            dtClaimDiagnosis.Columns.Add("ClaimDiagnosisID", typeof(Int64));
            dtClaimDiagnosis.Columns.Add("AddedSource", typeof(string));
            dtClaimDiagnosis.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimDiagnosis.Columns.Add("CreatedBy", typeof(string));
            dtClaimDiagnosis.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimDiagnosis.Columns.Add("DiagnosisCode", typeof(string));
            dtClaimDiagnosis.Columns.Add("DiagnosisDescription", typeof(string));
            dtClaimDiagnosis.Columns.Add("DiagnosisPointer", typeof(byte));
            dtClaimDiagnosis.Columns.Add("DiagnosisTypeID", typeof(int));
            dtClaimDiagnosis.Columns.Add("IsFreezed", typeof(byte));
            dtClaimDiagnosis.Columns.Add("LoadComment", typeof(string));
            dtClaimDiagnosis.Columns.Add("MemberID", typeof(int));
            dtClaimDiagnosis.Columns.Add("Qualifier", typeof(char));
            dtClaimDiagnosis.Columns.Add("RecordStatus", typeof(byte));
            dtClaimDiagnosis.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimDiagnosis.Columns.Add("UpdatedBy", typeof(string));
            dtClaimDiagnosis.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimDiagnosis.Columns.Add("UpdatedSource", typeof(string));
            dtClaimDiagnosis.Columns.Add("ProcDate", typeof(DateTime));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimDiagnosisList != null && ClaimDiagnosisList.Count > 0 && ClaimDiagnosisList[0] != null)
            {
                DataRow drClaimDiagnosis;

                foreach (ClaimDiagnosisViewModel objClaimDiagnosis in ClaimDiagnosisList)
                {
                    drClaimDiagnosis = dtClaimDiagnosis.NewRow();

                    drClaimDiagnosis["ClaimDiagnosisID"] = 0; //Mandatory Field
                    drClaimDiagnosis["AddedSource"] = string.IsNullOrEmpty(objClaimDiagnosis.AddedSource) != true && Convert.ToString(objClaimDiagnosis.AddedSource.Trim()) != string.Empty ? objClaimDiagnosis.AddedSource.Trim() : string.Empty; //Mandatory Field
                    drClaimDiagnosis["ClaimHeaderID"] = objClaimDiagnosis.ClaimHeaderID > 0 ? objClaimDiagnosis.ClaimHeaderID : 0; //Mandatory Field
                    drClaimDiagnosis["CreatedBy"] = "ExternalInterface"; // objClaimDiagnosis.CreatedBy; //Mandatory Field
                    drClaimDiagnosis["CreatedDate"] = DateTime.Now; // objClaimDiagnosis.CreatedDate; //Mandatory Field
                    drClaimDiagnosis["DiagnosisCode"] = string.IsNullOrEmpty(objClaimDiagnosis.DiagnosisCode) != true && Convert.ToString(objClaimDiagnosis.DiagnosisCode.Trim()) != string.Empty ? objClaimDiagnosis.DiagnosisCode.Trim() : string.Empty; //Not Mandatory Field
                    drClaimDiagnosis["DiagnosisDescription"] = string.IsNullOrEmpty(objClaimDiagnosis.DiagnosisDescription) != true && Convert.ToString(objClaimDiagnosis.DiagnosisDescription.Trim()) != string.Empty ? objClaimDiagnosis.DiagnosisDescription.Trim() : string.Empty; //Not Mandatory Field
                    drClaimDiagnosis["DiagnosisPointer"] = objClaimDiagnosis.DiagnosisPointer; //Mandatory Field
                    drClaimDiagnosis["DiagnosisTypeID"] = objClaimDiagnosis.DiagnosisTypeID != null && objClaimDiagnosis.DiagnosisTypeID > 0 ? objClaimDiagnosis.DiagnosisTypeID : (object)DBNull.Value; //Not Mandatory Field
                    drClaimDiagnosis["IsFreezed"] = false; // objClaimDiagnosis.IsFreezed; //Mandatory Field
                    drClaimDiagnosis["LoadComment"] = string.Empty; // objClaimDiagnosis.LoadComment; //Not Mandatory Field
                    drClaimDiagnosis["MemberID"] = objClaimDiagnosis.MemberID; //Mandatory Field
                    drClaimDiagnosis["Qualifier"] = string.IsNullOrEmpty(objClaimDiagnosis.Qualifier) != true && Convert.ToString(objClaimDiagnosis.Qualifier.Trim()) != string.Empty ? objClaimDiagnosis.Qualifier.Trim() : string.Empty; //Not Mandatory Field
                    drClaimDiagnosis["RecordStatus"] = (byte)RecordStatus.Active; //Mandatory Field
                    drClaimDiagnosis["RecordStatusChangeComment"] = string.Empty; // objClaimDiagnosis.RecordStatusChangeComment; //Mandatory Field
                    drClaimDiagnosis["UpdatedBy"] = string.Empty; // objClaimDiagnosis.UpdatedBy;
                    drClaimDiagnosis["UpdatedDate"] = (object)DBNull.Value;  // objClaimDiagnosis.UpdatedDate; //Not Mandatory Field
                    drClaimDiagnosis["UpdatedSource"] = string.Empty; //objClaimDiagnosis.UpdatedSource; //Not Mandatory Field
                    drClaimDiagnosis["ProcDate"] = objClaimDiagnosis.ProcDate != null && Convert.ToString(objClaimDiagnosis.ProcDate).Trim() != string.Empty ? objClaimDiagnosis.ProcDate : (object)DBNull.Value; //Not Mandatory Field

                    dtClaimDiagnosis.Rows.Add(drClaimDiagnosis);
                }
            }
            #endregion

            return dtClaimDiagnosis;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimServiceList"></param>
        /// <returns></returns>
        private DataTable GetClaimServiceDataTable(List<ClaimServiceViewModel> ClaimServiceList)
        {
            #region Create DataTable for ClaimService and Add Required Columns.

            DataTable dtClaimService = new DataTable("udtExternalClaimService");

            dtClaimService.Columns.Add("ClaimServiceID", typeof(Int64));
            dtClaimService.Columns.Add("AddedSource", typeof(string));
            dtClaimService.Columns.Add("AdminRoute", typeof(int));
            dtClaimService.Columns.Add("AllowedAmount", typeof(decimal));
            dtClaimService.Columns.Add("AllowedUnitsOrMinutes", typeof(short));
            dtClaimService.Columns.Add("AreaOfOralCavity", typeof(string));
            dtClaimService.Columns.Add("BenefitHeaderID", typeof(int));
            dtClaimService.Columns.Add("BilledAmount", typeof(decimal));
            dtClaimService.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimService.Columns.Add("CoinsuranceAmount", typeof(decimal));
            dtClaimService.Columns.Add("CompoundCode", typeof(string));
            dtClaimService.Columns.Add("CompoundCount", typeof(short));
            dtClaimService.Columns.Add("CompoundDispUnit", typeof(short));
            dtClaimService.Columns.Add("CompoundModifierCode", typeof(string));
            dtClaimService.Columns.Add("CompoundProductID", typeof(short));
            dtClaimService.Columns.Add("CompoundQualifierCode", typeof(string));
            dtClaimService.Columns.Add("CopayAmount", typeof(decimal));
            dtClaimService.Columns.Add("CreatedBy", typeof(string));
            dtClaimService.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimService.Columns.Add("DOSFrom", typeof(DateTime));
            dtClaimService.Columns.Add("DOSTo", typeof(DateTime));
            dtClaimService.Columns.Add("DateRXWritten", typeof(DateTime));
            dtClaimService.Columns.Add("DaysSupply", typeof(short));
            dtClaimService.Columns.Add("DeductibleAmount", typeof(decimal));
            dtClaimService.Columns.Add("DiagnosisPointer", typeof(string));
            dtClaimService.Columns.Add("DifferenceAmount", typeof(decimal));
            dtClaimService.Columns.Add("DispenseAsWrittenCode", typeof(int));
            dtClaimService.Columns.Add("DispensingFee", typeof(decimal));
            dtClaimService.Columns.Add("EPSDT", typeof(string));
            dtClaimService.Columns.Add("FeeScheduleID", typeof(int));
            dtClaimService.Columns.Add("FillNumber", typeof(short));
            dtClaimService.Columns.Add("GrossAmountDue", typeof(decimal));
            dtClaimService.Columns.Add("IncentiveAmount", typeof(decimal));
            dtClaimService.Columns.Add("IngredientCost", typeof(decimal));
            dtClaimService.Columns.Add("InterestAmount", typeof(decimal));
            dtClaimService.Columns.Add("IsClean", typeof(bool));
            dtClaimService.Columns.Add("IsEMG", typeof(bool));
            dtClaimService.Columns.Add("IsFreezed", typeof(byte));
            dtClaimService.Columns.Add("IsOverride", typeof(bool));
            dtClaimService.Columns.Add("LineNumber", typeof(short));
            dtClaimService.Columns.Add("LoadComment", typeof(string));
            dtClaimService.Columns.Add("MemberID", typeof(int));
            dtClaimService.Columns.Add("Modifiers", typeof(string));
            dtClaimService.Columns.Add("NDCCode", typeof(string));
            dtClaimService.Columns.Add("NonCoveredAmount", typeof(decimal));
            dtClaimService.Columns.Add("POSCode", typeof(string));
            dtClaimService.Columns.Add("PatientPaitAmount", typeof(decimal));
            dtClaimService.Columns.Add("PayableAmount", typeof(decimal));
            dtClaimService.Columns.Add("ProcedureCode", typeof(string));
            dtClaimService.Columns.Add("ProdQualifierID", typeof(int));
            dtClaimService.Columns.Add("ProviderContractID", typeof(int));
            dtClaimService.Columns.Add("ProviderContractTermID", typeof(int));
            dtClaimService.Columns.Add("RUGSCode", typeof(string));
            dtClaimService.Columns.Add("RecordStatus", typeof(byte));
            dtClaimService.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimService.Columns.Add("ReferralAuthNumber", typeof(string));
            dtClaimService.Columns.Add("RenderingProviderNPI", typeof(string));
            dtClaimService.Columns.Add("RenderingProviderName", typeof(string));
            dtClaimService.Columns.Add("RevenueCode", typeof(string));
            dtClaimService.Columns.Add("ServiceLineStatusID", typeof(int));
            dtClaimService.Columns.Add("ToothNumberLetter", typeof(string));
            dtClaimService.Columns.Add("ToothSurface", typeof(string));
            dtClaimService.Columns.Add("ToothSystem", typeof(string));
            dtClaimService.Columns.Add("TotalPaidAmount", typeof(decimal));
            dtClaimService.Columns.Add("UnitsOfMeasureCode", typeof(string));
            dtClaimService.Columns.Add("UnitsOrMinutes", typeof(short));
            dtClaimService.Columns.Add("UpdatedBy", typeof(string));
            dtClaimService.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimService.Columns.Add("UpdatedSource", typeof(string));
            dtClaimService.Columns.Add("ProcedureCodeDescription", typeof(string));
            dtClaimService.Columns.Add("ProcedureCodeTypeID", typeof(int));


            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimServiceList != null && ClaimServiceList.Count > 0 && ClaimServiceList[0] != null)
            {
                DataRow drClaimService;

                foreach (ClaimServiceViewModel objClaimService in ClaimServiceList)
                {
                    drClaimService = dtClaimService.NewRow();

                    drClaimService["ClaimServiceID"] = 0;  //Mandatory Field
                    drClaimService["AddedSource"] = string.IsNullOrEmpty(objClaimService.AddedSource) != true && Convert.ToString(objClaimService.AddedSource.Trim()) != string.Empty ? objClaimService.AddedSource.Trim() : string.Empty; //Mandatory Field
                    drClaimService["AdminRoute"] = objClaimService.AdminRoute; //Mandatory Field
                    drClaimService["AllowedAmount"] = objClaimService.AllowedAmount > 0 ? objClaimService.AllowedAmount : Decimal.Zero; //Mandatory Field
                    drClaimService["AllowedUnitsOrMinutes"] = objClaimService.AllowedUnitsOrMinutes;
                    drClaimService["AreaOfOralCavity"] = string.IsNullOrEmpty(objClaimService.AreaOfOralCavity) != true && Convert.ToString(objClaimService.AreaOfOralCavity.Trim()) != string.Empty ? objClaimService.AreaOfOralCavity.Trim() : string.Empty;
                    drClaimService["BenefitHeaderID"] = objClaimService.BenefitHeaderID != null && objClaimService.BenefitHeaderID > 0 ? objClaimService.BenefitHeaderID : (object)DBNull.Value;
                    drClaimService["BilledAmount"] = objClaimService.BilledAmount > 0 ? objClaimService.BilledAmount : Decimal.Zero;
                    drClaimService["ClaimHeaderID"] = objClaimService.ClaimHeaderID > 0 ? objClaimService.ClaimHeaderID : 0;
                    drClaimService["CoinsuranceAmount"] = objClaimService.CoinsuranceAmount > 0 ? objClaimService.CoinsuranceAmount : Decimal.Zero;
                    drClaimService["CompoundCode"] = string.IsNullOrEmpty(objClaimService.CompoundCode) != true && Convert.ToString(objClaimService.CompoundCode.Trim()) != string.Empty ? objClaimService.CompoundCode.Trim() : string.Empty;
                    drClaimService["CompoundCount"] = objClaimService.CompoundCount > 0 ? objClaimService.CompoundCount : 0;
                    drClaimService["CompoundDispUnit"] = objClaimService.CompoundDispUnit;
                    drClaimService["CompoundModifierCode"] = string.IsNullOrEmpty(objClaimService.CompoundModifierCode) != true && Convert.ToString(objClaimService.CompoundModifierCode.Trim()) != string.Empty ? objClaimService.CompoundModifierCode.Trim() : string.Empty;
                    drClaimService["CompoundProductID"] = objClaimService.CompoundProductID;
                    drClaimService["CompoundQualifierCode"] = string.IsNullOrEmpty(objClaimService.CompoundQualifierCode) != true && Convert.ToString(objClaimService.CompoundQualifierCode.Trim()) != string.Empty ? objClaimService.CompoundQualifierCode.Trim() : string.Empty;
                    drClaimService["CopayAmount"] = objClaimService.CopayAmount > 0 ? objClaimService.CopayAmount : Decimal.Zero;
                    drClaimService["CreatedBy"] = "ExternalInterface"; // objClaimService.CreatedBy;
                    drClaimService["CreatedDate"] = DateTime.Now; // objClaimService.CreatedDate;
                    drClaimService["DOSFrom"] = objClaimService.DOSFrom;
                    drClaimService["DOSTo"] = objClaimService.DOSTo;
                    drClaimService["DateRXWritten"] = objClaimService.DateRXWritten != null && Convert.ToString(objClaimService.DateRXWritten).Trim() != string.Empty ? objClaimService.DateRXWritten : (object)DBNull.Value;
                    drClaimService["DaysSupply"] = objClaimService.DaysSupply;
                    drClaimService["DeductibleAmount"] = objClaimService.DeductibleAmount > 0 ? objClaimService.DeductibleAmount : Decimal.Zero;
                    drClaimService["DiagnosisPointer"] = string.IsNullOrEmpty(objClaimService.DiagnosisPointer) != true && Convert.ToString(objClaimService.DiagnosisPointer.Trim()) != string.Empty ? objClaimService.DiagnosisPointer.Trim() : string.Empty;
                    drClaimService["DifferenceAmount"] = objClaimService.DifferenceAmount > 0 ? objClaimService.DifferenceAmount : Decimal.Zero;
                    drClaimService["DispenseAsWrittenCode"] = objClaimService.DispenseAsWrittenCode;
                    drClaimService["DispensingFee"] = objClaimService.DispensingFee > 0 ? objClaimService.DispensingFee : Decimal.Zero;
                    drClaimService["EPSDT"] = string.IsNullOrEmpty(objClaimService.EPSDT) != true && Convert.ToString(objClaimService.EPSDT.Trim()) != string.Empty ? objClaimService.EPSDT.Trim() : string.Empty;
                    drClaimService["FeeScheduleID"] = objClaimService.FeeScheduleID != null && objClaimService.FeeScheduleID > 0 ? objClaimService.FeeScheduleID : (object)DBNull.Value;
                    drClaimService["FillNumber"] = objClaimService.FillNumber;
                    drClaimService["GrossAmountDue"] = objClaimService.GrossAmountDue > 0 ? objClaimService.GrossAmountDue : Decimal.Zero;
                    drClaimService["IncentiveAmount"] = objClaimService.IncentiveAmount > 0 ? objClaimService.IncentiveAmount : Decimal.Zero;
                    drClaimService["IngredientCost"] = objClaimService.IngredientCost > 0 ? objClaimService.IngredientCost : Decimal.Zero;
                    drClaimService["InterestAmount"] = objClaimService.InterestAmount > 0 ? objClaimService.InterestAmount : Decimal.Zero;
                    drClaimService["IsClean"] = objClaimService.IsClean;
                    drClaimService["IsEMG"] = objClaimService.IsEMG;
                    drClaimService["IsFreezed"] = false; // objClaimService.IsFreezed;
                    drClaimService["IsOverride"] = objClaimService.IsOverride;
                    drClaimService["LineNumber"] = objClaimService.LineNumber;
                    drClaimService["LoadComment"] = string.Empty; // objClaimService.LoadComment;
                    drClaimService["MemberID"] = objClaimService.MemberID;
                    drClaimService["Modifiers"] = string.IsNullOrEmpty(objClaimService.Modifiers) != true && Convert.ToString(objClaimService.Modifiers.Trim()) != string.Empty ? objClaimService.Modifiers.Trim() : string.Empty;
                    drClaimService["NDCCode"] = string.IsNullOrEmpty(objClaimService.NDCCode) != true && Convert.ToString(objClaimService.NDCCode.Trim()) != string.Empty ? objClaimService.NDCCode.Trim() : string.Empty;
                    drClaimService["NonCoveredAmount"] = objClaimService.NonCoveredAmount > 0 ? objClaimService.NonCoveredAmount : Decimal.Zero;
                    drClaimService["POSCode"] = string.IsNullOrEmpty(objClaimService.POSCode) != true && Convert.ToString(objClaimService.POSCode.Trim()) != string.Empty ? objClaimService.POSCode.Trim() : string.Empty;
                    drClaimService["PatientPaitAmount"] = objClaimService.PatientPaitAmount > 0 ? objClaimService.PatientPaitAmount : Decimal.Zero;
                    drClaimService["PayableAmount"] = objClaimService.PayableAmount > 0 ? objClaimService.PayableAmount : Decimal.Zero;
                    drClaimService["ProcedureCode"] = string.IsNullOrEmpty(objClaimService.ProcedureCode) != true && Convert.ToString(objClaimService.ProcedureCode.Trim()) != string.Empty ? objClaimService.ProcedureCode.Trim() : string.Empty;
                    drClaimService["ProdQualifierID"] = objClaimService.ProdQualifierID != null && objClaimService.ProdQualifierID > 0 ? objClaimService.ProdQualifierID : (object)DBNull.Value;
                    drClaimService["ProviderContractID"] = objClaimService.ProviderContractID != null && objClaimService.ProviderContractID > 0 ? objClaimService.ProviderContractID : (object)DBNull.Value;
                    drClaimService["ProviderContractTermID"] = objClaimService.ProviderContractTermID != null && objClaimService.ProviderContractTermID > 0 ? objClaimService.ProviderContractTermID : (object)DBNull.Value;
                    drClaimService["RUGSCode"] = string.IsNullOrEmpty(objClaimService.RUGSCode) != true && Convert.ToString(objClaimService.RUGSCode.Trim()) != string.Empty ? objClaimService.RUGSCode.Trim() : string.Empty;
                    drClaimService["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimService["RecordStatusChangeComment"] = string.Empty; // objClaimService.RecordStatusChangeComment;
                    drClaimService["ReferralAuthNumber"] = string.IsNullOrEmpty(objClaimService.ReferralAuthNumber) != true && Convert.ToString(objClaimService.ReferralAuthNumber.Trim()) != string.Empty ? objClaimService.ReferralAuthNumber.Trim() : string.Empty;
                    drClaimService["RenderingProviderNPI"] = string.IsNullOrEmpty(objClaimService.RenderingProviderNPI) != true && Convert.ToString(objClaimService.RenderingProviderNPI.Trim()) != string.Empty ? objClaimService.RenderingProviderNPI.Trim() : string.Empty;
                    drClaimService["RenderingProviderName"] = string.IsNullOrEmpty(objClaimService.RenderingProviderName) != true && Convert.ToString(objClaimService.RenderingProviderName.Trim()) != string.Empty ? objClaimService.RenderingProviderName.Trim() : string.Empty;
                    drClaimService["RevenueCode"] = string.IsNullOrEmpty(objClaimService.RevenueCode) != true && Convert.ToString(objClaimService.RevenueCode.Trim()) != string.Empty ? objClaimService.RevenueCode.Trim() : string.Empty;
                    drClaimService["ServiceLineStatusID"] = objClaimService.ServiceLineStatusID != null && objClaimService.ServiceLineStatusID > 0 ? objClaimService.ServiceLineStatusID : (object)DBNull.Value;
                    drClaimService["ToothNumberLetter"] = string.IsNullOrEmpty(objClaimService.ToothNumberLetter) != true && Convert.ToString(objClaimService.ToothNumberLetter.Trim()) != string.Empty ? objClaimService.ToothNumberLetter.Trim() : string.Empty;
                    drClaimService["ToothSurface"] = string.IsNullOrEmpty(objClaimService.ToothSurface) != true && Convert.ToString(objClaimService.ToothSurface.Trim()) != string.Empty ? objClaimService.ToothSurface.Trim() : string.Empty;
                    drClaimService["ToothSystem"] = string.IsNullOrEmpty(objClaimService.ToothSystem) != true && Convert.ToString(objClaimService.ToothSystem.Trim()) != string.Empty ? objClaimService.ToothSystem.Trim() : string.Empty;
                    drClaimService["TotalPaidAmount"] = objClaimService.TotalPaidAmount > 0 ? objClaimService.TotalPaidAmount : Decimal.Zero;
                    drClaimService["UnitsOfMeasureCode"] = string.IsNullOrEmpty(objClaimService.UnitsOfMeasureCode) != true && Convert.ToString(objClaimService.UnitsOfMeasureCode.Trim()) != string.Empty ? objClaimService.UnitsOfMeasureCode.Trim() : string.Empty;
                    drClaimService["UnitsOrMinutes"] = objClaimService.UnitsOrMinutes;
                    drClaimService["UpdatedBy"] = string.Empty; // objClaimService.UpdatedBy;
                    drClaimService["UpdatedDate"] = (object)DBNull.Value;  // objClaimService.UpdatedDate;
                    drClaimService["UpdatedSource"] = string.Empty; //objClaimService.UpdatedSource;
                    drClaimService["ProcedureCodeDescription"] = string.IsNullOrEmpty(objClaimService.ProcedureCodeDescription) != true && Convert.ToString(objClaimService.ProcedureCodeDescription.Trim()) != string.Empty ? objClaimService.ProcedureCodeDescription.Trim() : string.Empty;
                    drClaimService["ProcedureCodeTypeID"] = objClaimService.ProcedureCodeTypeID != null && objClaimService.ProcedureCodeTypeID > 0 ? objClaimService.ProcedureCodeTypeID : (object)DBNull.Value;

                    dtClaimService.Rows.Add(drClaimService);
                }
            }

            #endregion

            return dtClaimService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimReferenceList"></param>
        /// <returns></returns>
        private DataTable GetClaimReferenceDataTable(List<ClaimReferenceViewModel> ClaimReferenceList)
        {
            #region Create DataTable for ClaimReference and Add Required Columns.

            DataTable dtClaimReference = new DataTable("udtExternalClaimReference");

            dtClaimReference.Columns.Add("ClaimReferenceID", typeof(Int64));
            dtClaimReference.Columns.Add("AddedSource", typeof(string));
            dtClaimReference.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimReference.Columns.Add("CodeTypeID", typeof(int));
            dtClaimReference.Columns.Add("CodeValue", typeof(string));
            dtClaimReference.Columns.Add("ControlTypeID", typeof(int));
            dtClaimReference.Columns.Add("CreatedBy", typeof(string));
            dtClaimReference.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimReference.Columns.Add("EffectiveDate", typeof(DateTime));
            dtClaimReference.Columns.Add("IsFreezed", typeof(byte));
            dtClaimReference.Columns.Add("LoadComment", typeof(string));
            dtClaimReference.Columns.Add("MemberID", typeof(int));
            dtClaimReference.Columns.Add("RecordStatus", typeof(byte));
            dtClaimReference.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimReference.Columns.Add("TermDate", typeof(DateTime));
            dtClaimReference.Columns.Add("UpdatedBy", typeof(string));
            dtClaimReference.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimReference.Columns.Add("UpdatedSource", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimReferenceList != null && ClaimReferenceList.Count > 0 && ClaimReferenceList[0] != null)
            {
                DataRow drClaimReference;

                foreach (ClaimReferenceViewModel objClaimReference in ClaimReferenceList)
                {
                    drClaimReference = dtClaimReference.NewRow();

                    drClaimReference["ClaimReferenceID"] = objClaimReference.ClaimReferenceID;
                    drClaimReference["AddedSource"] = string.IsNullOrEmpty(objClaimReference.AddedSource) != true && Convert.ToString(objClaimReference.AddedSource.Trim()) != string.Empty ? objClaimReference.AddedSource.Trim() : string.Empty; 
                    drClaimReference["ClaimHeaderID"] = objClaimReference.ClaimHeaderID > 0 ? objClaimReference.ClaimHeaderID : 0;
                    drClaimReference["CodeTypeID"] = objClaimReference.CodeTypeID;
                    drClaimReference["CodeValue"] = string.IsNullOrEmpty(objClaimReference.CodeValue) != true && Convert.ToString(objClaimReference.CodeValue.Trim()) != string.Empty ? objClaimReference.CodeValue.Trim() : string.Empty;
                    drClaimReference["ControlTypeID"] = objClaimReference.ControlTypeID;
                    drClaimReference["CreatedBy"] = "ExternalInterface"; // objClaimReference.CreatedBy;
                    drClaimReference["CreatedDate"] = DateTime.Now; // objClaimReference.CreatedDate;
                    drClaimReference["EffectiveDate"] = objClaimReference.EffectiveDate;
                    drClaimReference["IsFreezed"] = false; // objClaimReference.IsFreezed;
                    drClaimReference["LoadComment"] = string.Empty; // objClaimReference.LoadComment;
                    drClaimReference["MemberID"] = objClaimReference.MemberID;
                    drClaimReference["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimReference["RecordStatusChangeComment"] = string.Empty; // objClaimReference.RecordStatusChangeComment;
                    drClaimReference["TermDate"] = objClaimReference.TermDate != null && Convert.ToString(objClaimReference.TermDate).Trim() != string.Empty ? objClaimReference.TermDate : DateTime.MaxValue.Date;
                    drClaimReference["UpdatedBy"] = string.Empty; // objClaimReference.UpdatedBy;
                    drClaimReference["UpdatedDate"] = (object)DBNull.Value;  // objClaimReference.UpdatedDate;
                    drClaimReference["UpdatedSource"] = string.Empty; //objClaimReference.UpdatedSource;

                    dtClaimReference.Rows.Add(drClaimReference);
                }
            }

            #endregion

            return dtClaimReference;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimOtherInsuranceList"></param>
        /// <returns></returns>
        private DataTable GetClaimOtherInsuranceDataTable(List<ClaimOtherInsuranceViewModel> ClaimOtherInsuranceList)
        {
            #region Create DataTable for ClaimOtherInsurance and Add Required Columns.

            DataTable dtClaimOtherInsurance = new DataTable("udtExternalClaimOtherInsurance");

            dtClaimOtherInsurance.Columns.Add("ClaimOtherInsuranceID", typeof(Int64));
            dtClaimOtherInsurance.Columns.Add("AddedSource", typeof(string));
            dtClaimOtherInsurance.Columns.Add("AllowedAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("BilledAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimOtherInsurance.Columns.Add("CoinsuranceAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("CopayAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("CreatedBy", typeof(string));
            dtClaimOtherInsurance.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimOtherInsurance.Columns.Add("DOSFrom", typeof(DateTime));
            dtClaimOtherInsurance.Columns.Add("DOSTo", typeof(DateTime));
            dtClaimOtherInsurance.Columns.Add("DeductibleAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("EOBDate", typeof(DateTime));
            dtClaimOtherInsurance.Columns.Add("IsFreezed", typeof(byte));
            dtClaimOtherInsurance.Columns.Add("IsLineLevel", typeof(bool));
            dtClaimOtherInsurance.Columns.Add("LoadComment", typeof(string));
            dtClaimOtherInsurance.Columns.Add("Modifiers", typeof(string));
            dtClaimOtherInsurance.Columns.Add("NetAllowedAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("POSCode", typeof(string));
            dtClaimOtherInsurance.Columns.Add("ProcedureCode", typeof(string));
            dtClaimOtherInsurance.Columns.Add("RecordStatus", typeof(byte));
            dtClaimOtherInsurance.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimOtherInsurance.Columns.Add("RevenueCode", typeof(string));
            dtClaimOtherInsurance.Columns.Add("ServiceLineNumber", typeof(short));
            dtClaimOtherInsurance.Columns.Add("TotalPaidAmount", typeof(decimal));
            dtClaimOtherInsurance.Columns.Add("Units", typeof(int));
            dtClaimOtherInsurance.Columns.Add("UpdatedBy", typeof(string));
            dtClaimOtherInsurance.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimOtherInsurance.Columns.Add("UpdatedSource", typeof(string));
            dtClaimOtherInsurance.Columns.Add("InsuranceCarrierID", typeof(int));
            dtClaimOtherInsurance.Columns.Add("SourceInsuranceName", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimOtherInsuranceList != null && ClaimOtherInsuranceList.Count > 0 && ClaimOtherInsuranceList[0] != null)
            {
                DataRow drClaimOtherInsurance;

                foreach (ClaimOtherInsuranceViewModel objClaimOtherInsurance in ClaimOtherInsuranceList)
                {
                    drClaimOtherInsurance = dtClaimOtherInsurance.NewRow();

                    drClaimOtherInsurance["ClaimOtherInsuranceID"] = objClaimOtherInsurance.ClaimOtherInsuranceID;
                    drClaimOtherInsurance["AddedSource"] = string.IsNullOrEmpty(objClaimOtherInsurance.AddedSource) != true && Convert.ToString(objClaimOtherInsurance.AddedSource.Trim()) != string.Empty ? objClaimOtherInsurance.AddedSource.Trim() : string.Empty;
                    drClaimOtherInsurance["AllowedAmount"] = objClaimOtherInsurance.AllowedAmount > 0 ? objClaimOtherInsurance.AllowedAmount : Decimal.Zero;
                    drClaimOtherInsurance["BilledAmount"] = objClaimOtherInsurance.BilledAmount > 0 ? objClaimOtherInsurance.BilledAmount : Decimal.Zero;
                    drClaimOtherInsurance["ClaimHeaderID"] = objClaimOtherInsurance.ClaimHeaderID > 0 ? objClaimOtherInsurance.ClaimHeaderID : 0;
                    drClaimOtherInsurance["CoinsuranceAmount"] = objClaimOtherInsurance.CoinsuranceAmount > 0 ? objClaimOtherInsurance.CoinsuranceAmount : Decimal.Zero;
                    drClaimOtherInsurance["CopayAmount"] = objClaimOtherInsurance.CopayAmount > 0 ? objClaimOtherInsurance.CopayAmount : Decimal.Zero;
                    drClaimOtherInsurance["CreatedBy"] = "ExternalInterface"; // objClaimOtherInsurance.CreatedBy;
                    drClaimOtherInsurance["CreatedDate"] = DateTime.Now; // objClaimOtherInsurance.CreatedDate;
                    drClaimOtherInsurance["DOSFrom"] = objClaimOtherInsurance.DOSFrom;
                    drClaimOtherInsurance["DOSTo"] = objClaimOtherInsurance.DOSTo;
                    drClaimOtherInsurance["DeductibleAmount"] = objClaimOtherInsurance.DeductibleAmount > 0 ? objClaimOtherInsurance.DeductibleAmount : Decimal.Zero;
                    drClaimOtherInsurance["EOBDate"] = objClaimOtherInsurance.EOBDate;
                    drClaimOtherInsurance["IsFreezed"] = false; // objClaimOtherInsurance.IsFreezed;
                    drClaimOtherInsurance["IsLineLevel"] = objClaimOtherInsurance.IsLineLevel;
                    drClaimOtherInsurance["LoadComment"] = string.Empty; // objClaimOtherInsurance.LoadComment;
                    drClaimOtherInsurance["Modifiers"] = string.IsNullOrEmpty(objClaimOtherInsurance.Modifiers) != true && Convert.ToString(objClaimOtherInsurance.Modifiers.Trim()) != string.Empty ? objClaimOtherInsurance.Modifiers.Trim() : string.Empty;
                    drClaimOtherInsurance["NetAllowedAmount"] = objClaimOtherInsurance.NetAllowedAmount > 0 ? objClaimOtherInsurance.NetAllowedAmount : Decimal.Zero;
                    drClaimOtherInsurance["POSCode"] = string.IsNullOrEmpty(objClaimOtherInsurance.POSCode) != true && Convert.ToString(objClaimOtherInsurance.POSCode.Trim()) != string.Empty ? objClaimOtherInsurance.POSCode.Trim() : string.Empty;
                    drClaimOtherInsurance["ProcedureCode"] = string.IsNullOrEmpty(objClaimOtherInsurance.ProcedureCode) != true && Convert.ToString(objClaimOtherInsurance.ProcedureCode.Trim()) != string.Empty ? objClaimOtherInsurance.ProcedureCode.Trim() : string.Empty;
                    drClaimOtherInsurance["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimOtherInsurance["RecordStatusChangeComment"] = string.Empty; // objClaimOtherInsurance.RecordStatusChangeComment;
                    drClaimOtherInsurance["RevenueCode"] = string.IsNullOrEmpty(objClaimOtherInsurance.RevenueCode) != true && Convert.ToString(objClaimOtherInsurance.RevenueCode.Trim()) != string.Empty ? objClaimOtherInsurance.RevenueCode.Trim() : string.Empty;
                    drClaimOtherInsurance["ServiceLineNumber"] = objClaimOtherInsurance.ServiceLineNumber;
                    drClaimOtherInsurance["TotalPaidAmount"] = objClaimOtherInsurance.TotalPaidAmount > 0 ? objClaimOtherInsurance.TotalPaidAmount : Decimal.Zero;
                    drClaimOtherInsurance["Units"] = objClaimOtherInsurance.Units;
                    drClaimOtherInsurance["UpdatedBy"] = string.Empty; // objClaimOtherInsurance.UpdatedBy;
                    drClaimOtherInsurance["UpdatedDate"] = (object)DBNull.Value;  // objClaimOtherInsurance.UpdatedDate;
                    drClaimOtherInsurance["UpdatedSource"] = string.Empty; //objClaimOtherInsurance.UpdatedSource;
                    drClaimOtherInsurance["InsuranceCarrierID"] = objClaimOtherInsurance.InsuranceCarrierID != null && objClaimOtherInsurance.InsuranceCarrierID > 0 ? objClaimOtherInsurance.InsuranceCarrierID : (object)DBNull.Value;
                    drClaimOtherInsurance["SourceInsuranceName"] = string.IsNullOrEmpty(objClaimOtherInsurance.SourceInsuranceName) != true && Convert.ToString(objClaimOtherInsurance.SourceInsuranceName.Trim()) != string.Empty ? objClaimOtherInsurance.SourceInsuranceName.Trim() : string.Empty;

                    dtClaimOtherInsurance.Rows.Add(drClaimOtherInsurance);
                }
            }

            #endregion

            return dtClaimOtherInsurance;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimAuditList"></param>
        /// <returns></returns>
        private DataTable GetClaimAuditDataTable(List<ClaimAuditViewModel> ClaimAuditList)
        {
            #region Create DataTable for ClaimAudit and Add Required Columns.

            DataTable dtClaimAudit = new DataTable("udtExternalClaimAudit");

            dtClaimAudit.Columns.Add("ClaimAuditID", typeof(Int64));
            dtClaimAudit.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimAudit.Columns.Add("ActionID", typeof(int));
            dtClaimAudit.Columns.Add("UserInitials", typeof(string));
            dtClaimAudit.Columns.Add("ActionDescription", typeof(string));
            dtClaimAudit.Columns.Add("CreatedDate", typeof(DateTime));


            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimAuditList != null && ClaimAuditList.Count > 0 && ClaimAuditList[0] != null)
            {
                DataRow drClaimAudit;

                foreach (ClaimAuditViewModel objClaimAudit in ClaimAuditList)
                {
                    drClaimAudit = dtClaimAudit.NewRow();

                    drClaimAudit["ClaimAuditID"] = objClaimAudit.ClaimAuditID;
                    drClaimAudit["ClaimHeaderID"] = objClaimAudit.ClaimHeaderID > 0 ? objClaimAudit.ClaimHeaderID : 0;
                    drClaimAudit["ActionID"] = objClaimAudit.ActionID != null && objClaimAudit.ActionID > 0 ? objClaimAudit.ActionID : (object)DBNull.Value;
                    drClaimAudit["UserInitials"] = string.IsNullOrEmpty(objClaimAudit.UserInitials) != true && Convert.ToString(objClaimAudit.UserInitials.Trim()) != string.Empty ? objClaimAudit.UserInitials.Trim() : string.Empty;
                    drClaimAudit["ActionDescription"] = string.IsNullOrEmpty(objClaimAudit.ActionDescription) != true && Convert.ToString(objClaimAudit.ActionDescription.Trim()) != string.Empty ? objClaimAudit.ActionDescription.Trim() : string.Empty;
                    drClaimAudit["CreatedDate"] = DateTime.Now; // objClaimAudit.CreatedDate;

                    dtClaimAudit.Rows.Add(drClaimAudit);
                }
            }

            #endregion

            return dtClaimAudit;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimEditsList"></param>
        /// <returns></returns>
        //private DataTable GetClaimEditsDataTable(List<ClaimEditsViewModel> ClaimEditsList)
        //{
        //    #region Create DataTable for ClaimEdits and Add Required Columns.

        //    DataTable dtClaimEdits = new DataTable("udtExternalClaimEdits");

        //    dtClaimEdits.Columns.Add("ClaimEditsID", typeof(Int64));
        //    dtClaimEdits.Columns.Add("AddedSource", typeof(string));
        //    dtClaimEdits.Columns.Add("ClaimHeaderID", typeof(Int64));
        //    dtClaimEdits.Columns.Add("ClaimLineID", typeof(Int64));
        //    dtClaimEdits.Columns.Add("LineNumber", typeof(short));
        //    dtClaimEdits.Columns.Add("Comments", typeof(string));
        //    dtClaimEdits.Columns.Add("CreatedBy", typeof(string));
        //    dtClaimEdits.Columns.Add("CreatedDate", typeof(DateTime));
        //    dtClaimEdits.Columns.Add("Edit", typeof(string));
        //    dtClaimEdits.Columns.Add("EditDescription", typeof(string));
        //    dtClaimEdits.Columns.Add("EditStatusCode", typeof(string));
        //    dtClaimEdits.Columns.Add("IsFreezed", typeof(byte));
        //    dtClaimEdits.Columns.Add("LoadComment", typeof(string));
        //    dtClaimEdits.Columns.Add("OutcomeReason", typeof(string));
        //    dtClaimEdits.Columns.Add("RecordStatus", typeof(byte));
        //    dtClaimEdits.Columns.Add("RecordStatusChangeComment", typeof(string));
        //    dtClaimEdits.Columns.Add("UpdatedBy", typeof(string));
        //    dtClaimEdits.Columns.Add("UpdatedDate", typeof(DateTime));
        //    dtClaimEdits.Columns.Add("UpdatedSource", typeof(string));

        //    #endregion

        //    #region Create New DataRow and Set value for each Column.

        //    if (ClaimEditsList != null && ClaimEditsList.Count > 0 && ClaimEditsList[0] != null)
        //    {
        //        DataRow drClaimEdits;

        //        foreach (ClaimEditsViewModel objClaimEdits in ClaimEditsList)
        //        {
        //            drClaimEdits = dtClaimEdits.NewRow();

        //            drClaimEdits["ClaimEditsID"] = objClaimEdits.ClaimEditsID;
        //            drClaimEdits["AddedSource"] = string.IsNullOrEmpty(objClaimEdits.AddedSource) != true && Convert.ToString(objClaimEdits.AddedSource.Trim()) != string.Empty ? objClaimEdits.AddedSource.Trim() : string.Empty;
        //            drClaimEdits["ClaimHeaderID"] = objClaimEdits.ClaimHeaderID > 0 ? objClaimEdits.ClaimHeaderID : 0;
        //            drClaimEdits["ClaimLineID"] = objClaimEdits.ClaimLineID != null && objClaimEdits.ClaimLineID > 0 ? objClaimEdits.ClaimLineID : (object)DBNull.Value;
        //            drClaimEdits["LineNumber"] = objClaimEdits.LineNumber != null ? objClaimEdits.LineNumber : (object)DBNull.Value;
        //            drClaimEdits["Comments"] = string.IsNullOrEmpty(objClaimEdits.Comments) != true && Convert.ToString(objClaimEdits.Comments.Trim()) != string.Empty ? objClaimEdits.Comments.Trim() : string.Empty;
        //            drClaimEdits["CreatedBy"] = string.IsNullOrEmpty(objClaimEdits.User) != true && Convert.ToString(objClaimEdits.User.Trim()) != string.Empty ? objClaimEdits.User.Trim() : string.Empty;
        //            drClaimEdits["CreatedDate"] = DateTime.Now; // objClaimEdits.CreatedDate;
        //            drClaimEdits["Edit"] = string.IsNullOrEmpty(objClaimEdits.EditCode) != true && Convert.ToString(objClaimEdits.EditCode.Trim()) != string.Empty ? objClaimEdits.EditCode.Trim() : string.Empty;
        //            drClaimEdits["EditDescription"] = string.IsNullOrEmpty(objClaimEdits.EditDescription) != true && Convert.ToString(objClaimEdits.EditDescription.Trim()) != string.Empty ? objClaimEdits.EditDescription.Trim() : string.Empty;
        //            drClaimEdits["EditStatusCode"] = string.IsNullOrEmpty(objClaimEdits.EditStatusCode) != true && Convert.ToString(objClaimEdits.EditStatusCode.Trim()) != string.Empty ? objClaimEdits.EditStatusCode.Trim() : string.Empty;
        //            drClaimEdits["IsFreezed"] = false; // objClaimEdits.IsFreezed;
        //            drClaimEdits["LoadComment"] = string.Empty; // objClaimEdits.LoadComment;
        //            drClaimEdits["OutcomeReason"] = string.IsNullOrEmpty(objClaimEdits.OutcomeReason) != true && Convert.ToString(objClaimEdits.OutcomeReason.Trim()) != string.Empty ? objClaimEdits.OutcomeReason.Trim() : string.Empty;
        //            drClaimEdits["RecordStatus"] = (byte)RecordStatus.Active;
        //            drClaimEdits["RecordStatusChangeComment"] = string.Empty; // objClaimEdits.RecordStatusChangeComment;
        //            drClaimEdits["UpdatedBy"] = string.Empty; // objClaimEdits.UpdatedBy;
        //            drClaimEdits["UpdatedDate"] = (object)DBNull.Value;  // objClaimEdits.UpdatedDate;
        //            drClaimEdits["UpdatedSource"] = string.Empty; //objClaimEdits.UpdatedSource;

        //            dtClaimEdits.Rows.Add(drClaimEdits);
        //        }
        //    }

        //    #endregion

        //    return dtClaimEdits;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimNotesList"></param>
        /// <returns></returns>
        private DataTable GetClaimNotesDataTable(List<ClaimNotesViewModel> ClaimNotesList)
        {
            #region Create DataTable for ClaimNotes and Add Required Columns.

            DataTable dtClaimNotes = new DataTable("udtExternalClaimNotes");

            dtClaimNotes.Columns.Add("ClaimNotesID", typeof(Int64));
            dtClaimNotes.Columns.Add("AddedSource", typeof(string));
            dtClaimNotes.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimNotes.Columns.Add("CreatedBy", typeof(string));
            dtClaimNotes.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimNotes.Columns.Add("EffectiveDate", typeof(DateTime));
            dtClaimNotes.Columns.Add("IsFreezed", typeof(byte));
            dtClaimNotes.Columns.Add("LoadComment", typeof(string));
            dtClaimNotes.Columns.Add("LongDesc", typeof(string));
            dtClaimNotes.Columns.Add("MemberID", typeof(int));
            dtClaimNotes.Columns.Add("NoteDate", typeof(DateTime));
            dtClaimNotes.Columns.Add("RecordStatus", typeof(byte));
            dtClaimNotes.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimNotes.Columns.Add("ShortDesc", typeof(string));
            dtClaimNotes.Columns.Add("TermDate", typeof(DateTime));
            dtClaimNotes.Columns.Add("UpdatedBy", typeof(string));
            dtClaimNotes.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimNotes.Columns.Add("UpdatedSource", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimNotesList != null && ClaimNotesList.Count > 0 && ClaimNotesList[0] != null)
            {
                DataRow drClaimNotes;

                foreach (ClaimNotesViewModel objClaimNotes in ClaimNotesList)
                {
                    drClaimNotes = dtClaimNotes.NewRow();

                    drClaimNotes["ClaimNotesID"] = objClaimNotes.ClaimNotesID;
                    drClaimNotes["AddedSource"] = string.IsNullOrEmpty(objClaimNotes.AddedSource) != true && Convert.ToString(objClaimNotes.AddedSource.Trim()) != string.Empty ? objClaimNotes.AddedSource.Trim() : string.Empty;
                    drClaimNotes["ClaimHeaderID"] = objClaimNotes.ClaimHeaderID > 0 ? objClaimNotes.ClaimHeaderID : 0;
                    drClaimNotes["CreatedBy"] = "ExternalInterface"; // objClaimNotes.CreatedBy;
                    drClaimNotes["CreatedDate"] = DateTime.Now; // objClaimNotes.CreatedDate;
                    drClaimNotes["EffectiveDate"] = objClaimNotes.EffectiveDate;
                    drClaimNotes["IsFreezed"] = false; // objClaimNotes.IsFreezed;
                    drClaimNotes["LoadComment"] = string.Empty; // objClaimNotes.LoadComment;
                    drClaimNotes["LongDesc"] = string.IsNullOrEmpty(objClaimNotes.LongDesc) != true && Convert.ToString(objClaimNotes.LongDesc.Trim()) != string.Empty ? objClaimNotes.LongDesc.Trim() : string.Empty;
                    drClaimNotes["MemberID"] = objClaimNotes.MemberID;
                    drClaimNotes["NoteDate"] = objClaimNotes.NoteDate;
                    drClaimNotes["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimNotes["RecordStatusChangeComment"] = string.Empty; // objClaimNotes.RecordStatusChangeComment;
                    drClaimNotes["ShortDesc"] = string.IsNullOrEmpty(objClaimNotes.ShortDesc) != true && Convert.ToString(objClaimNotes.ShortDesc.Trim()) != string.Empty ? objClaimNotes.ShortDesc.Trim() : string.Empty;
                    drClaimNotes["TermDate"] = objClaimNotes.TermDate != null && Convert.ToString(objClaimNotes.TermDate).Trim() != string.Empty ? objClaimNotes.TermDate : DateTime.MaxValue.Date;
                    drClaimNotes["UpdatedBy"] = string.Empty; // objClaimNotes.UpdatedBy;
                    drClaimNotes["UpdatedDate"] = (object)DBNull.Value;  // objClaimNotes.UpdatedDate;
                    drClaimNotes["UpdatedSource"] = string.Empty; //objClaimNotes.UpdatedSource;

                    dtClaimNotes.Rows.Add(drClaimNotes);
                }
            }

            #endregion

            return dtClaimNotes;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimProcessingStepsList"></param>
        /// <returns></returns>
        private DataTable GetClaimProcessingStepsDataTable(List<ClaimProcessingStepsViewModel> ClaimProcessingStepsList)
        {
            #region Create DataTable for ClaimProcessingSteps and Add Required Columns.

            DataTable dtClaimProcessingSteps = new DataTable("udtExternalClaimProcessingSteps");

            dtClaimProcessingSteps.Columns.Add("ClaimProcessingStepsID", typeof(Int64));
            dtClaimProcessingSteps.Columns.Add("ClaimDetailLine", typeof(int));
            dtClaimProcessingSteps.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimProcessingSteps.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimProcessingSteps.Columns.Add("ProcessDate", typeof(DateTime));
            dtClaimProcessingSteps.Columns.Add("ProcessStep", typeof(string));
            dtClaimProcessingSteps.Columns.Add("ProcessValue", typeof(string));



            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimProcessingStepsList != null && ClaimProcessingStepsList.Count > 0 && ClaimProcessingStepsList[0] != null)
            {
                DataRow drClaimProcessingSteps;

                foreach (ClaimProcessingStepsViewModel objClaimProcessingSteps in ClaimProcessingStepsList)
                {
                    drClaimProcessingSteps = dtClaimProcessingSteps.NewRow();

                    drClaimProcessingSteps["ClaimProcessingStepsID"] = objClaimProcessingSteps.ClaimProcessingStepsID;
                    drClaimProcessingSteps["ClaimDetailLine"] = objClaimProcessingSteps.ClaimDetailLine;
                    drClaimProcessingSteps["ClaimHeaderID"] = objClaimProcessingSteps.ClaimHeaderID > 0 ? objClaimProcessingSteps.ClaimHeaderID : 0;
                    drClaimProcessingSteps["CreatedDate"] = DateTime.Now; // objClaimProcessingSteps.CreatedDate;
                    drClaimProcessingSteps["ProcessDate"] = objClaimProcessingSteps.ProcessDate;
                    drClaimProcessingSteps["ProcessStep"] = string.IsNullOrEmpty(objClaimProcessingSteps.ProcessStep) != true && Convert.ToString(objClaimProcessingSteps.ProcessStep.Trim()) != string.Empty ? objClaimProcessingSteps.ProcessStep.Trim() : string.Empty;
                    drClaimProcessingSteps["ProcessValue"] = string.IsNullOrEmpty(objClaimProcessingSteps.ProcessValue) != true && Convert.ToString(objClaimProcessingSteps.ProcessValue.Trim()) != string.Empty ? objClaimProcessingSteps.ProcessValue.Trim() : string.Empty;

                    dtClaimProcessingSteps.Rows.Add(drClaimProcessingSteps);
                }
            }

            #endregion

            return dtClaimProcessingSteps;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimEOBEOPList"></param>
        /// <returns></returns>
        private DataTable GetClaimEOBEOPDataTable(List<ClaimEOBEOPViewModel> ClaimEOBEOPList)
        {
            #region Create DataTable for ClaimEOBEOP and Add Required Columns.

            DataTable dtClaimEOBEOP = new DataTable("udtExternalClaimEOBEOP");

            dtClaimEOBEOP.Columns.Add("ClaimEOBEOPID", typeof(Int64));
            dtClaimEOBEOP.Columns.Add("AddedSource", typeof(string));
            dtClaimEOBEOP.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimEOBEOP.Columns.Add("Code", typeof(string));
            dtClaimEOBEOP.Columns.Add("CreatedBy", typeof(string));
            dtClaimEOBEOP.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimEOBEOP.Columns.Add("Description", typeof(string));
            dtClaimEOBEOP.Columns.Add("EOBEOPTypeID", typeof(int));
            dtClaimEOBEOP.Columns.Add("IsFreezed", typeof(byte));
            dtClaimEOBEOP.Columns.Add("LineNumber", typeof(short));
            dtClaimEOBEOP.Columns.Add("LoadComment", typeof(string));
            dtClaimEOBEOP.Columns.Add("RecordStatus", typeof(byte));
            dtClaimEOBEOP.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimEOBEOP.Columns.Add("UpdatedBy", typeof(string));
            dtClaimEOBEOP.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimEOBEOP.Columns.Add("UpdatedSource", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimEOBEOPList != null && ClaimEOBEOPList.Count > 0 && ClaimEOBEOPList[0] != null)
            {
                DataRow drClaimEOBEOP;

                foreach (ClaimEOBEOPViewModel objClaimEOBEOP in ClaimEOBEOPList)
                {
                    drClaimEOBEOP = dtClaimEOBEOP.NewRow();

                    drClaimEOBEOP["ClaimEOBEOPID"] = objClaimEOBEOP.ClaimEOBEOPID;
                    drClaimEOBEOP["AddedSource"] = string.IsNullOrEmpty(objClaimEOBEOP.AddedSource) != true && Convert.ToString(objClaimEOBEOP.AddedSource.Trim()) != string.Empty ? objClaimEOBEOP.AddedSource.Trim() : string.Empty;
                    drClaimEOBEOP["ClaimHeaderID"] = objClaimEOBEOP.ClaimHeaderID > 0 ? objClaimEOBEOP.ClaimHeaderID : 0;
                    drClaimEOBEOP["Code"] = string.IsNullOrEmpty(objClaimEOBEOP.Code) != true && Convert.ToString(objClaimEOBEOP.Code.Trim()) != string.Empty ? objClaimEOBEOP.Code.Trim() : string.Empty;
                    drClaimEOBEOP["CreatedBy"] = "ExternalInterface"; // objClaimEOBEOP.CreatedBy;
                    drClaimEOBEOP["CreatedDate"] = DateTime.Now; // objClaimEOBEOP.CreatedDate;
                    drClaimEOBEOP["Description"] = string.IsNullOrEmpty(objClaimEOBEOP.Description) != true && Convert.ToString(objClaimEOBEOP.Description.Trim()) != string.Empty ? objClaimEOBEOP.Description.Trim() : string.Empty;
                    drClaimEOBEOP["EOBEOPTypeID"] = objClaimEOBEOP.EOBEOPTypeID;
                    drClaimEOBEOP["IsFreezed"] = false; // objClaimEOBEOP.IsFreezed;
                    drClaimEOBEOP["LineNumber"] = objClaimEOBEOP.LineNumber;
                    drClaimEOBEOP["LoadComment"] = string.Empty; // objClaimEOBEOP.LoadComment;
                    drClaimEOBEOP["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimEOBEOP["RecordStatusChangeComment"] = string.Empty; // objClaimEOBEOP.RecordStatusChangeComment;
                    drClaimEOBEOP["UpdatedBy"] = string.Empty; // objClaimEOBEOP.UpdatedBy;
                    drClaimEOBEOP["UpdatedDate"] = (object)DBNull.Value;  // objClaimEOBEOP.UpdatedDate;
                    drClaimEOBEOP["UpdatedSource"] = string.Empty; //objClaimEOBEOP.UpdatedSource;

                    dtClaimEOBEOP.Rows.Add(drClaimEOBEOP);

                }
            }

            #endregion

            return dtClaimEOBEOP;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimOtherPhysicianList"></param>
        /// <returns></returns>
        private DataTable GetClaimOtherPhysicianDataTable(List<ClaimOtherPhysicianViewModel> ClaimOtherPhysicianList)
        {
            #region Create DataTable for ClaimOtherPhysician and Add Required Columns.

            DataTable dtClaimOtherPhysician = new DataTable("udtExternalClaimOtherPhysician");

            dtClaimOtherPhysician.Columns.Add("ClaimOtherPhysicianID", typeof(Int64));
            dtClaimOtherPhysician.Columns.Add("AddedSource", typeof(string));
            dtClaimOtherPhysician.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimOtherPhysician.Columns.Add("CreatedBy", typeof(string));
            dtClaimOtherPhysician.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimOtherPhysician.Columns.Add("FirstName", typeof(string));
            dtClaimOtherPhysician.Columns.Add("IsFreezed", typeof(byte));
            dtClaimOtherPhysician.Columns.Add("LastName", typeof(string));
            dtClaimOtherPhysician.Columns.Add("LoadComment", typeof(string));
            dtClaimOtherPhysician.Columns.Add("PhysicianCode", typeof(string));
            dtClaimOtherPhysician.Columns.Add("PhysicianTypeID", typeof(int));
            dtClaimOtherPhysician.Columns.Add("QualifierID", typeof(int));
            dtClaimOtherPhysician.Columns.Add("RecordStatus", typeof(byte));
            dtClaimOtherPhysician.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimOtherPhysician.Columns.Add("UpdatedBy", typeof(string));
            dtClaimOtherPhysician.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimOtherPhysician.Columns.Add("UpdatedSource", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimOtherPhysicianList != null && ClaimOtherPhysicianList.Count > 0 && ClaimOtherPhysicianList[0] != null)
            {
                DataRow drClaimOtherPhysician;

                foreach (ClaimOtherPhysicianViewModel objClaimOtherPhysician in ClaimOtherPhysicianList)
                {
                    drClaimOtherPhysician = dtClaimOtherPhysician.NewRow();

                    drClaimOtherPhysician["ClaimOtherPhysicianID"] = objClaimOtherPhysician.ClaimOtherPhysicianID;
                    drClaimOtherPhysician["AddedSource"] = string.IsNullOrEmpty(objClaimOtherPhysician.AddedSource) != true && Convert.ToString(objClaimOtherPhysician.AddedSource.Trim()) != string.Empty ? objClaimOtherPhysician.AddedSource.Trim() : string.Empty;
                    drClaimOtherPhysician["ClaimHeaderID"] = objClaimOtherPhysician.ClaimHeaderID > 0 ? objClaimOtherPhysician.ClaimHeaderID : 0;
                    drClaimOtherPhysician["CreatedBy"] = "ExternalInterface"; // objClaimOtherPhysician.CreatedBy;
                    drClaimOtherPhysician["CreatedDate"] = DateTime.Now; // objClaimOtherPhysician.CreatedDate;
                    drClaimOtherPhysician["FirstName"] = string.IsNullOrEmpty(objClaimOtherPhysician.FirstName) != true && Convert.ToString(objClaimOtherPhysician.FirstName.Trim()) != string.Empty ? objClaimOtherPhysician.FirstName.Trim() : string.Empty;
                    drClaimOtherPhysician["IsFreezed"] = false; // objClaimOtherPhysician.IsFreezed;
                    drClaimOtherPhysician["LastName"] = string.IsNullOrEmpty(objClaimOtherPhysician.LastName) != true && Convert.ToString(objClaimOtherPhysician.LastName.Trim()) != string.Empty ? objClaimOtherPhysician.LastName.Trim() : string.Empty;
                    drClaimOtherPhysician["LoadComment"] = string.Empty; // objClaimOtherPhysician.LoadComment;
                    drClaimOtherPhysician["PhysicianCode"] = string.IsNullOrEmpty(objClaimOtherPhysician.PhysicianCode) != true && Convert.ToString(objClaimOtherPhysician.PhysicianCode.Trim()) != string.Empty ? objClaimOtherPhysician.PhysicianCode.Trim() : string.Empty;
                    drClaimOtherPhysician["PhysicianTypeID"] = objClaimOtherPhysician.PhysicianTypeID;
                    drClaimOtherPhysician["QualifierID"] = objClaimOtherPhysician.QualifierID;
                    drClaimOtherPhysician["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimOtherPhysician["RecordStatusChangeComment"] = string.Empty; // objClaimOtherPhysician.RecordStatusChangeComment;
                    drClaimOtherPhysician["UpdatedBy"] = string.Empty; // objClaimOtherPhysician.UpdatedBy;
                    drClaimOtherPhysician["UpdatedDate"] = (object)DBNull.Value;  // objClaimOtherPhysician.UpdatedDate;
                    drClaimOtherPhysician["UpdatedSource"] = string.Empty; //objClaimOtherPhysician.UpdatedSource;

                    dtClaimOtherPhysician.Rows.Add(drClaimOtherPhysician);
                }
            }

            #endregion

            return dtClaimOtherPhysician;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimUBCodesList"></param>
        /// <returns></returns>
        private DataTable GetClaimUBCodesDataTable(List<ClaimUBCodesViewModel> ClaimUBCodesList)
        {
            #region Create DataTable for ClaimUBCodes and Add Required Columns.

            DataTable dtClaimUBCodes = new DataTable("udtExternalClaimUBCodes");

            dtClaimUBCodes.Columns.Add("ClaimUBCodesID", typeof(Int64));
            dtClaimUBCodes.Columns.Add("AddedSource", typeof(string));
            dtClaimUBCodes.Columns.Add("Amount", typeof(decimal));
            dtClaimUBCodes.Columns.Add("ClaimHeaderID", typeof(Int64));
            dtClaimUBCodes.Columns.Add("CreatedBy", typeof(string));
            dtClaimUBCodes.Columns.Add("CreatedDate", typeof(DateTime));
            dtClaimUBCodes.Columns.Add("Description", typeof(string));
            dtClaimUBCodes.Columns.Add("FromDate", typeof(DateTime));
            dtClaimUBCodes.Columns.Add("IsFreezed", typeof(byte));
            dtClaimUBCodes.Columns.Add("LoadComment", typeof(string));
            dtClaimUBCodes.Columns.Add("RecordStatus", typeof(byte));
            dtClaimUBCodes.Columns.Add("RecordStatusChangeComment", typeof(string));
            dtClaimUBCodes.Columns.Add("ToDate", typeof(DateTime));
            dtClaimUBCodes.Columns.Add("TypeID", typeof(int));
            dtClaimUBCodes.Columns.Add("UBCode", typeof(string));
            dtClaimUBCodes.Columns.Add("UpdatedBy", typeof(string));
            dtClaimUBCodes.Columns.Add("UpdatedDate", typeof(DateTime));
            dtClaimUBCodes.Columns.Add("UpdatedSource", typeof(string));

            #endregion

            #region Create New DataRow and Set value for each Column.

            if (ClaimUBCodesList != null && ClaimUBCodesList.Count > 0 && ClaimUBCodesList[0] != null)
            {
                DataRow drClaimUBCodes;

                foreach (ClaimUBCodesViewModel objClaimUBCodes in ClaimUBCodesList)
                {
                    drClaimUBCodes = dtClaimUBCodes.NewRow();

                    drClaimUBCodes["ClaimUBCodesID"] = objClaimUBCodes.ClaimUBCodesID;
                    drClaimUBCodes["AddedSource"] = string.IsNullOrEmpty(objClaimUBCodes.AddedSource) != true && Convert.ToString(objClaimUBCodes.AddedSource.Trim()) != string.Empty ? objClaimUBCodes.AddedSource.Trim() : string.Empty;
                    drClaimUBCodes["Amount"] = objClaimUBCodes.Amount > 0 ? objClaimUBCodes.Amount : Decimal.Zero;
                    drClaimUBCodes["ClaimHeaderID"] = objClaimUBCodes.ClaimHeaderID > 0 ? objClaimUBCodes.ClaimHeaderID : 0;
                    drClaimUBCodes["CreatedBy"] = "ExternalInterface"; // objClaimUBCodes.CreatedBy;
                    drClaimUBCodes["CreatedDate"] = DateTime.Now; // objClaimUBCodes.CreatedDate;
                    drClaimUBCodes["Description"] = string.IsNullOrEmpty(objClaimUBCodes.Description) != true && Convert.ToString(objClaimUBCodes.Description.Trim()) != string.Empty ? objClaimUBCodes.Description.Trim() : string.Empty;
                    drClaimUBCodes["FromDate"] = objClaimUBCodes.FromDate;
                    drClaimUBCodes["IsFreezed"] = false; // objClaimUBCodes.IsFreezed;
                    drClaimUBCodes["LoadComment"] = string.Empty; // objClaimUBCodes.LoadComment;
                    drClaimUBCodes["RecordStatus"] = (byte)RecordStatus.Active;
                    drClaimUBCodes["RecordStatusChangeComment"] = string.Empty; // objClaimUBCodes.RecordStatusChangeComment;
                    drClaimUBCodes["ToDate"] = objClaimUBCodes.ToDate != null && Convert.ToString(objClaimUBCodes.ToDate).Trim() != string.Empty ? objClaimUBCodes.ToDate : (object)DBNull.Value;
                    drClaimUBCodes["TypeID"] = objClaimUBCodes.TypeID;
                    drClaimUBCodes["UBCode"] = string.IsNullOrEmpty(objClaimUBCodes.UBCode) != true && Convert.ToString(objClaimUBCodes.UBCode.Trim()) != string.Empty ? objClaimUBCodes.UBCode.Trim() : string.Empty;
                    drClaimUBCodes["UpdatedBy"] = string.Empty; // objClaimUBCodes.UpdatedBy;
                    drClaimUBCodes["UpdatedDate"] = (object)DBNull.Value;  // objClaimUBCodes.UpdatedDate;
                    drClaimUBCodes["UpdatedSource"] = string.Empty; //objClaimUBCodes.UpdatedSource;

                    dtClaimUBCodes.Rows.Add(drClaimUBCodes);
                }
            }

            #endregion

            return dtClaimUBCodes;
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="items"></param>
        /// <returns></returns>
        public DataTable ToDataTableFromIList<TSource>(IList<TSource> items)
        {
            DataTable dataTable = new DataTable(typeof(TSource).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            foreach (TSource item in items)
            {
                var values = new object[Props.Length];

                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                //put a breakpoint here and check datatable
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="items"></param>
        /// <returns></returns>
        public DataTable ToDataTableFromList<TSource>(List<TSource> items)
        {
            DataTable dataTable = new DataTable(typeof(TSource).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            foreach (TSource item in items)
            {
                var values = new object[Props.Length];

                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            //put a breakpoint here and check datatable
            return dataTable;
        }

        #endregion
    }
}
