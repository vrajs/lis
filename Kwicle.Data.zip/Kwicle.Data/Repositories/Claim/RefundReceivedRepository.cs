﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class RefundReceivedRepository : BaseRepository<RefundReceived>, IRefundReceivedRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public RefundReceivedRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation   

        public IEnumerable<RefundReceived> GetAllRefundReceived()
        {
            try
            {
                var res = _context.RefundReceiveds.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundReceived", ex.Message);
                return null;
            }
        }

        public IQueryable<RefundReceivedViewModel> GetRefundReceived(int RefundRequestID)
        {
            try
            {
                var query = from rr in _context.RefundReceiveds
                            where rr.RecordStatus == (int)RecordStatus.Active && rr.RefundRequestID == RefundRequestID
                            select new RefundReceivedViewModel()
                            {
                                RefundReceivedID = rr.RefundReceivedID,
                                RefundRequestID = rr.RefundRequestID,
                                ReceivedDate = rr.ReceivedDate,
                                ReceivedAmount = rr.ReceivedAmount,
                                CheckNo = rr.CheckNo,
                                CheckDate = rr.CheckDate,                                
                                PostingTypeID = rr.PostingTypeID,                                                                
                                StringCheckNo = rr.CheckNo.ToString(),
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundReceived", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
