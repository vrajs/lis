﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Core.Views;

namespace Kwicle.Data.Repositories.Claim
{
    public class RefundPostingRepository : BaseRepository<RefundPosting>, IRefundPostingRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _vwcontext;

        #endregion

        #region Ctor

        public RefundPostingRepository(KwicleContext context, KwicleViewContext vwcontext) : base(context)
        {
            _context = context;
            _vwcontext = vwcontext;

        }

        #endregion

        #region Interface Methods Implementation   

        public IEnumerable<RefundPosting> GetAllRefundPosting()
        {
            try
            {
                var res = _context.RefundPostings.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundPosting", ex.Message);
                return null;
            }
        }

        public IQueryable<RefundPostingViewModel> GetRefundPosting(int RefundRequestID)
        {
            try
            {
                var query = from rp in _context.RefundPostings
                            join mem in _context.Members on rp.MemberID equals mem.MemberID
                            join et in _context.CommonCodes on rp.EntryTypeID equals et.CommonCodeID
                            join rr in _context.RefundReceiveds on rp.RefundReceivedID equals rr.RefundReceivedID into refr
                            from refrs in refr.DefaultIfEmpty()
                            where rp.RecordStatus == (int)RecordStatus.Active && rp.RefundRequestID == RefundRequestID
                            select new RefundPostingViewModel()
                            {
                                RefundPostingID = rp.RefundPostingID,
                                RefundRequestID = rp.RefundRequestID,
                                RefundReceivedID = rp.RefundReceivedID,
                                EntryTypeID = rp.EntryTypeID,
                                ClaimHeaderID = rp.ClaimHeaderID,
                                MemberID = rp.MemberID,
                                MemberName = mem.DisplayName,
                                ClaimNumber = rp.ClaimNumber,
                                PostedAmount = rp.PostedAmount,
                                PostedDate = rp.PostedDate,
                                EntryType = et.ShortName,
                                CheckNo = refrs==null ? 0 :  refrs.CheckNo,
                                RecoupmentAmount = rp.RecoupmentAmount,
                                IsPosted = rp.IsPosted,
                                BalanceAmount = rp.BalanceAmount,
                                Comment = rp.Comment
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundPosting", ex.Message);
                return null;
            }
        }

        //public IQueryable<vwClaimRefundList> GetClaimRefundLists() {
        //    var refundList = _vwcontext.GetclaimRefundLists.ToList() ;
        //    refundList.ForEach(lst =>
        //    {
        //        refundList.TakeWhile(t => t.RefundRequestID == lst.RefundRequestID && lst.EntryTypeId == 10702).OrderBy(o=>o.RefundRequestID);
        //        lst.Balance = lst.EntryTypeId == 10702 ? lst.Balance-lst.RecoupmentAmount: lst.Balance;

        //    });

        //}
        #endregion
    }
}
