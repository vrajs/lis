﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimOtherPhysicianRepository : BaseRepository<ClaimOtherPhysician>, IClaimOtherPhysicianRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimOtherPhysicianRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimOtherPhysician> GetAllClaimOtherPhysician()
        {
            try
            {
                var res = _context.ClaimOtherPhysicians.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimOtherPhysician", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimOtherPhysicianViewModel> GetClaimOtherPhysician(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimOtherPhysicians
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new ClaimOtherPhysicianViewModel()
                            {
                                ClaimOtherPhysicianID = b.ClaimOtherPhysicianID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                PhysicianTypeID = b.PhysicianTypeID,
                                PhysicianCode = b.PhysicianCode,
                                QualifierID = b.QualifierID,
                                LastName = b.LastName,
                                FirstName = b.FirstName,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimOtherPhysician", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
