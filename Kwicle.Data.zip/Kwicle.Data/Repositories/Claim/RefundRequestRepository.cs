﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Common;
using System.Collections.ObjectModel;

namespace Kwicle.Data.Repositories.Claim
{
    public class RefundRequestRepository : BaseRepository<RefundRequest>, IRefundRequestRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Ctor
        public RefundRequestRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;

        }
        #endregion

        #region Interface Methods Implementation    
        public RefundRequest InsertUpdateRefund(RefundRequest entity)
        {
            List<RefundRequestClaim> refundsClaims = entity.RefundRequestClaims.ToList();
            entity.RefundRequestClaims = new Collection<RefundRequestClaim>();
            var executionStrategy = _context.Database.CreateExecutionStrategy();
            executionStrategy.Execute(
    () =>
    {
        using (var dbCTransaction = _context.Database.BeginTransaction())
        {
            try
            {
                // Code for insert and update refund request
                if (entity.RefundRequestID == 0)
                {
                    _context.RefundRequests.Add(entity);
                    _context.SaveChanges();
                }
                else
                {
                    _context.Entry(entity).State = EntityState.Modified;
                    _context.SaveChanges();
                }

                // Update RefundRequestID into claims list
                refundsClaims.ForEach(e => e.RefundRequestID = entity.RefundRequestID);

                // Code for insert claims.
                _context.RefundRequestClaims.AddRange(refundsClaims.Where(e => e.RefundRequestClaimID == 0).ToArray());
                _context.SaveChanges();

                // Code for update claims.
                _context.RefundRequestClaims.UpdateRange(refundsClaims.Where(e => e.RefundRequestClaimID != 0).ToArray());
                _context.SaveChanges();

                // Commit transaction
                dbCTransaction.Commit();

                return entity;
            }
            catch (Exception ex)
            {
                dbCTransaction.Rollback();
                base.DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                return new RefundRequest();
            }
        }
    });
            return entity;
        }



        public RefundRequestViewModel GetByID(int RefundRequestID)
        {
            RefundRequestViewModel model = new RefundRequestViewModel();
            model = (from c in _context.RefundRequests
                     join z in _context.ZipCodes on c.Zip equals z.Code
                     where c.RefundRequestID == RefundRequestID && c.RecordStatus != (byte)RecordStatus.Deleted
                     select new RefundRequestViewModel()
                     {
                         RefundRequestID = c.RefundRequestID,
                         RefundRequestForID = c.RefundRequestForID,
                         RefundStatusID = c.RefundStatusID,
                         RequestDate = c.RequestDate,
                         RequestedAmount = c.RequestedAmount,
                         TotalInterestAccrued = c.TotalInterestAccrued,
                         TotalReceivedAmount = c.TotalReceivedAmount,
                         IsVendorAddressOnFile = c.IsVendorAddressOnFile,
                         ProviderID = c.ProviderID,
                         TIN = c.TIN,
                         VendorName = c.VendorName,
                         Address1 = c.Address1,
                         Address2 = c.Address2,
                         City = c.City,
                         State = c.State,
                         Zip = c.Zip,
                         Attention = c.Attention,
                         RequestReasonID = c.RequestReasonID,
                         IsGenerateLetter = c.IsGenerateLetter,
                         FollowupDays = c.FollowupDays,
                         RefundReason = c.RefundReason,
                         CreatedBy = c.CreatedBy,
                         CreatedDate = c.CreatedDate,
                         ZipCodeInfo = new ZipCodeModel()
                         {
                             AreaCode = z.AreaCode,
                             City = z.City,
                             Code = z.Code,
                             Country = z.Country,
                             County = z.County,
                             State = z.State,
                             StateFullName = z.StateFullName,
                             ZipCodeID = z.ZipCodeID,
                         }
                     }).FirstOrDefault();
            if (model != null)
            {
                model.Claims = (from rc in _context.RefundRequestClaims
                                join c in _context.ClaimHeaders on rc.ClaimHeaderID equals c.ClaimHeaderID
                                where rc.RefundRequestID == model.RefundRequestID && rc.RecordStatus != (int)RecordStatus.Deleted
                                select new RefundRequestClaimViewModel()
                                {
                                    RefundRequestClaimID = rc.RefundRequestClaimID,
                                    RefundRequestID = rc.RefundRequestID,
                                    ClaimHeaderID = rc.ClaimHeaderID,
                                    MemberID = rc.MemberID,
                                    ClaimNumber = rc.ClaimNumber,
                                    BilledAmount = c.BilledAmount,
                                    PaidAmount = c.PaidAmount,
                                    RequestedAmount = rc.RequestedAmount,
                                    RecordStatus = rc.RecordStatus,
                                    IsFreezed = rc.IsFreezed,
                                    RecordStatusChangeComment = rc.RecordStatusChangeComment,
                                    CreatedBy = rc.CreatedBy,
                                    CreatedDate = rc.CreatedDate,
                                    UpdatedBy = rc.UpdatedBy,
                                    UpdatedDate = rc.UpdatedDate,
                                    AddedSource = rc.AddedSource,
                                    UpdatedSource = rc.UpdatedSource,
                                    LoadComment = rc.LoadComment,
                                    ProviderGroupTIN = c.ProviderGroupTIN,
                                    VendorName = c.VendorName,
                                    //ClaimInfo = _viewContext.GetClaimLoockups.Where(e => e.ClaimHeaderID == rc.ClaimHeaderID).FirstOrDefault()
                                }).ToList();

                model.Claims.ToList().ForEach(e =>
                {
                    e.ClaimInfo = _viewContext.GetClaimLoockups.Where(w => w.ClaimHeaderID == e.ClaimHeaderID).FirstOrDefault();
                });
            }
            return model;
        }
        #endregion
    }
}
