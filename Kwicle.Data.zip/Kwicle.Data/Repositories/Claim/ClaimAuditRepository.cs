﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimAuditRepository : BaseRepository<ClaimAudit>, IClaimAuditRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimAuditRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimAudit> GetAllClaimAudit()
        {
            try
            {
                var res = _context.ClaimAudits.ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimAudit", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimAuditViewModel> GetClaimAudit(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimAudits
                            where b.ClaimHeaderID == ClaimHeaderID
                            select new ClaimAuditViewModel()
                            {
                                ClaimAuditID = b.ClaimAuditID,
                                ActionID = b.ActionID,
                                UserInitials = b.UserInitials,
                                ActionDescription = b.ActionDescription,
                                CreatedDate = b.CreatedDate
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimAudit", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
