﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimEOBEOPRepository : BaseRepository<ClaimEOBEOP>, IClaimEOBEOPRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimEOBEOPRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
       
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimEOBEOP> GetAllClaimEOBEOP()
        {
            try
            {
                var res = _context.ClaimEOBEOPs.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimEOBEOP", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimEOBEOPViewModel> GetClaimEOBEOP(long ClaimHeaderID,int EOBEOPTypeID)
        {
            try
            {
                var query = from b in _context.ClaimEOBEOPs
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted && b.EOBEOPTypeID==EOBEOPTypeID
                            select new ClaimEOBEOPViewModel()
                            {
                                ClaimEOBEOPID = b.ClaimEOBEOPID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                EOBEOPTypeID = b.EOBEOPTypeID,
                                LineNumber = b.LineNumber,
                                Code = b.Code,
                                Description = b.Description,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimEOBEOP", ex.Message);
                return null;
            }
        }

        public void AddEOBEOP(params object[] model)
        {
            var modelService = (ClaimServiceViewModel)model.GetValue(0);
            var eobeopid = (int)model.GetValue(2);
            var lineModel = _context.ClaimEOBEOPs.FirstOrDefault(z => z.LineNumber == modelService.LineNumber && z.ClaimHeaderID == modelService.ClaimHeaderID && z.EOBEOPTypeID == eobeopid);
            var line = lineModel == null ? 0 : lineModel.LineNumber;

            using (var dbctransaction = _context.Database.BeginTransaction())
            {
                ClaimEOBEOP modelEOB = new ClaimEOBEOP();
            try
            {

                modelEOB = line != 0 ? this.GetByPredicate(z => z.LineNumber == modelService.LineNumber && z.ClaimHeaderID == modelService.ClaimHeaderID && z.EOBEOPTypeID == eobeopid).FirstOrDefault():modelEOB;
                var desc = _context.CommonCodes.FirstOrDefault(z => z.CommonCodeID == modelService.ServiceLineStatusID).ShortName;
                modelEOB.ClaimHeaderID = modelService.ClaimHeaderID;
                modelEOB.Code = modelService.Code;
                modelEOB.LineNumber = modelService.LineNumber;
                modelEOB.CreatedBy = model.GetValue(1).ToString();
                modelEOB.CreatedDate = System.TimeZoneInfo.ConvertTime(DateTime.Now, System.TimeZoneInfo.Local, System.TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
                modelEOB.Description = desc;
                modelEOB.RecordStatus = (byte)RecordStatus.Active;
                modelEOB.RecordStatusChangeComment = RecordStatus.Active.ToString();
                modelEOB.EOBEOPTypeID =(int) model.GetValue(2);
                    if (line != 0)
                    {
                        _context.ClaimEOBEOPs.Update(modelEOB);
                        _context.SaveChanges();
                    }
                    else {
                        modelEOB.ClaimEOBEOPID = 0;
                        _context.ClaimEOBEOPs.Add(modelEOB);
                        _context.SaveChanges();
                    }

                    dbctransaction.Commit();
                    //return modelEOB;
                }
            catch (Exception ex)
            {
                    dbctransaction.Rollback();
                    base.DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                //return modelEOB;
            }
            }
        }
        #endregion
    }
}
