﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class RefundLetterRepository : BaseRepository<RefundLetter>, IRefundLetterRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public RefundLetterRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation   

        public IEnumerable<RefundLetter> GetAllRefundLetter()
        {
            try
            {
                var res = _context.RefundLetters.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundLetter", ex.Message);
                return null;
            }
        }

        public IQueryable<RefundLetterViewModel> GetRefundLetterHistory(int RefundRequestID)
        {
            try
            {
                var query = from rl in _context.RefundLetters
                            join lt in _context.CommonCodes on rl.LetterTypeID equals lt.CommonCodeID
                            where rl.RecordStatus == (int)RecordStatus.Active && rl.RefundRequestID == RefundRequestID
                            select new RefundLetterViewModel()
                            {
                                RefundLetterID = rl.RefundLetterID,
                                RefundRequestID = rl.RefundRequestID,
                                LetterDate = rl.LetterDate,
                                LetterTypeID = rl.LetterTypeID,
                                LetterTypeName = lt.ShortName,
                                DocumentNo = rl.DocumentNo,
                                LetterHTMLContent = rl.LetterHTMLContent,
                                CreatedBy = rl.CreatedBy
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundLetter", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
