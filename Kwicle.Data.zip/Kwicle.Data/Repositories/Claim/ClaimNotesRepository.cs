﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimNotesRepository : BaseRepository<ClaimNotes>, IClaimNotesRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimNotesRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimNotes> GetAllClaimNotes()
        {
            try
            {
                var res = _context.ClaimNotes.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimNotes", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimNotesViewModel> GetClaimNotes(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimNotes
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new ClaimNotesViewModel()
                            {
                                ClaimNotesID = b.ClaimNotesID,
                                ShortDesc = b.ShortDesc,
                                LongDesc = b.LongDesc,
                                NoteDate = b.NoteDate,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = b.TermDate,
                                MemberID = b.MemberID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                UserInitials=b.CreatedBy,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimNotes", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
