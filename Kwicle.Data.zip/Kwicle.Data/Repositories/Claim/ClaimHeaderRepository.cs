﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Views;
using System.Data.SqlTypes;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimHeaderRepository : BaseRepository<ClaimHeader>, IClaimHeaderRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Ctor
        public ClaimHeaderRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;

        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<ClaimHeader> GetAllClaimHeader()
        {
            try
            {
                var res = _context.ClaimHeaders.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimHeader", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimHeaderViewModel> GetClaimHeader(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimHeaders
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new ClaimHeaderViewModel()
                            {
                                ClaimHeaderID = b.ClaimHeaderID,
                                ClaimNumber = b.ClaimNumber,
                                ReceivedDate = b.ReceivedDate,
                                FormTypeID = b.FormTypeID,
                                EnteredDate = b.EnteredDate,
                                DOSFrom = b.DOSFrom,
                                DOSTo = b.DOSTo,
                                BilledAmount = b.BilledAmount,
                                PaidAmount = b.PaidAmount,
                                PaidDate = b.PaidDate,
                                OtherInsurancePaid = b.OtherInsurancePaid,
                                PatientAccountNumber = b.PatientAccountNumber,
                                ExternalClaimID = b.ExternalClaimID,
                                PriorAuthNumber = b.PriorAuthNumber,
                                ClaimStatusID = b.ClaimStatusID,
                                ClaimStatusReason = b.ClaimStatusReason,
                                ClaimSourceID = b.ClaimSourceID,
                                MemberID = b.MemberID,
                                ProviderID = b.ProviderID,
                                ProviderTypeID = b.ProviderTypeID,
                                VendorName = b.VendorName,
                                IsCorrectedClaim = b.IsCorrectedClaim,
                                IsPatientReimbursement = b.IsPatientReimbursement,
                                IsRefundRequest = b.IsRefundRequest,
                                IsCleanClaim = b.IsCleanClaim,
                                IsEncounter = b.IsEncounter,
                                IsAlternatePayee = b.IsAlternatePayee,
                                IsSplitPayment = b.IsSplitPayment,
                                IsSuppressEOB = b.IsSuppressEOB,
                                IsPayAndPursue = b.IsPayAndPursue,
                                AltFeeScheduleID = b.AltFeeScheduleID,
                                IsEmployment = b.IsEmployment,
                                IsAuto = b.IsAuto,
                                IsOtherAccident = b.IsOtherAccident,
                                IllnessDate = b.IllnessDate,
                                OtherDate = b.OtherDate,
                                PhysicianName = b.PhysicianName,
                                PhysicianNPI = b.PhysicianNPI,
                                IsAcceptsAssignment = b.IsAcceptsAssignment,
                                BillTypeID = b.BillTypeID,
                                AdmitDate = b.AdmitDate,
                                AdmitHour = b.AdmitHour,
                                AdmitTypeID = b.AdmitTypeID,
                                AdmitSourceID = b.AdmitSourceID,
                                DischargeHour = b.DischargeHour,
                                DischargeStatusID = b.DischargeStatusID,
                                BilledDRGCode = b.BilledDRGCode,
                                RevisedDRGCode = b.RevisedDRGCode,
                                IsPreDetermiantion = b.IsPreDetermiantion,
                                IsEPSDTTitleXIX = b.IsEPSDTTitleXIX,
                                ServiceRendered = b.ServiceRendered,
                                AccidentStateOrProvince = b.AccidentStateOrProvince,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimHeader", ex.Message);
                return null;
            }
        }

        public long InsertUpdateClaim(ClaimHeader entity, List<ClaimEditsViewModel> ClaimEditsList = null)
        {
            long ClaimHeaderID = 0;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@ClaimHeaderID", entity.ClaimHeaderID));
                parameters.Add(new SqlParameter("@AddedSource", (string.IsNullOrEmpty(entity.AddedSource) ? DBNull.Value : (object)entity.AddedSource)));
                parameters.Add(new SqlParameter("@AdmitDate", (entity.AdmitDate == null) ? DBNull.Value : (object)entity.AdmitDate));
                parameters.Add(new SqlParameter("@AdmitHour", (entity.AdmitHour == null) ? DBNull.Value : (object)entity.AdmitHour));
                parameters.Add(new SqlParameter("@AdmitSourceID", (entity.AdmitSourceID == null) ? DBNull.Value : (object)entity.AdmitSourceID));
                parameters.Add(new SqlParameter("@AdmitTypeID", (entity.AdmitTypeID == null) ? DBNull.Value : (object)entity.AdmitTypeID));
                parameters.Add(new SqlParameter("@AltFeeScheduleID", (entity.AltFeeScheduleID == null) ? DBNull.Value : (object)entity.AltFeeScheduleID));
                parameters.Add(new SqlParameter("@BillTypeID", (entity.BillTypeID == null) ? DBNull.Value : (object)entity.BillTypeID));
                parameters.Add(new SqlParameter("@BilledAmount", entity.BilledAmount));
                parameters.Add(new SqlParameter("@BilledDRGCode", (entity.BilledDRGCode == null) ? DBNull.Value : (object)entity.BilledDRGCode));
                parameters.Add(new SqlParameter("@ClaimNumber", entity.ClaimNumber));
                parameters.Add(new SqlParameter("@ClaimSourceID", entity.ClaimSourceID));
                parameters.Add(new SqlParameter("@ClaimStatusID", entity.ClaimStatusID));
                parameters.Add(new SqlParameter("@ClaimStatusReason", entity.ClaimStatusReason));
                parameters.Add(new SqlParameter("@CreatedBy", entity.CreatedBy));
                parameters.Add(new SqlParameter("@CreatedDate", entity.CreatedDate));
                parameters.Add(new SqlParameter("@DCN", (entity.DCN == null) ? DBNull.Value : (object)entity.DCN));
                parameters.Add(new SqlParameter("@DischargeHour", (entity.DischargeHour == null) ? DBNull.Value : (object)entity.DischargeHour));
                parameters.Add(new SqlParameter("@DischargeStatusID", (entity.DischargeStatusID == null) ? DBNull.Value : (object)entity.DischargeStatusID));
                parameters.Add(new SqlParameter("@EnteredDate", entity.EnteredDate));
                parameters.Add(new SqlParameter("@ExternalClaimID", (entity.ExternalClaimID == null)? "" : entity.ExternalClaimID));
                parameters.Add(new SqlParameter("@FormTypeID", entity.FormTypeID));
                parameters.Add(new SqlParameter("@IllnessDate", (entity.IllnessDate == null) ? DBNull.Value : (object)entity.IllnessDate));
                parameters.Add(new SqlParameter("@IsAcceptsAssignment", entity.IsAcceptsAssignment));
                parameters.Add(new SqlParameter("@IsAlternatePayee", entity.IsAlternatePayee));
                parameters.Add(new SqlParameter("@IsAuto", entity.IsAuto));
                parameters.Add(new SqlParameter("@IsCleanClaim", entity.IsCleanClaim));
                parameters.Add(new SqlParameter("@IsCorrectedClaim", entity.IsCorrectedClaim));
                parameters.Add(new SqlParameter("@IsEPSDTTitleXIX", (entity.IsEPSDTTitleXIX == null) ? DBNull.Value : (object)entity.IsEPSDTTitleXIX));
                parameters.Add(new SqlParameter("@IsEmployment", entity.IsEmployment));
                parameters.Add(new SqlParameter("@IsEncounter", entity.IsEncounter));
                parameters.Add(new SqlParameter("@IsFreezed", entity.IsFreezed));
                parameters.Add(new SqlParameter("@IsOtherAccident", entity.IsOtherAccident));
                parameters.Add(new SqlParameter("@IsPatientReimbursement", entity.IsPatientReimbursement));
                parameters.Add(new SqlParameter("@IsPayAndPursue", entity.IsPayAndPursue));
                parameters.Add(new SqlParameter("@IsPreDetermiantion", (entity.IsPreDetermiantion == null) ? DBNull.Value : (object)entity.IsPreDetermiantion));
                parameters.Add(new SqlParameter("@IsRefundRequest", entity.IsRefundRequest));
                parameters.Add(new SqlParameter("@IsSplitPayment", entity.IsSplitPayment));
                parameters.Add(new SqlParameter("@IsSuppressEOB", entity.IsSuppressEOB));
                parameters.Add(new SqlParameter("@LoadComment", (entity.LoadComment == null) ? DBNull.Value : (object)entity.LoadComment));
                parameters.Add(new SqlParameter("@MemberID", entity.MemberID));
                parameters.Add(new SqlParameter("@OtherDate", (entity.OtherDate == null) ? DBNull.Value : (object)entity.OtherDate));
                parameters.Add(new SqlParameter("@OtherInsurancePaid", entity.OtherInsurancePaid));
                parameters.Add(new SqlParameter("@PaidAmount", entity.PaidAmount));
                parameters.Add(new SqlParameter("@PaidDate", (entity.PaidDate == null) ? DBNull.Value : (object)entity.PaidDate));
                parameters.Add(new SqlParameter("@PatientAccountNumber", (entity.PatientAccountNumber == null) ? "" : entity.PatientAccountNumber));
                parameters.Add(new SqlParameter("@PhysicianNPI", entity.PhysicianNPI));
                parameters.Add(new SqlParameter("@PhysicianName", entity.PhysicianName));
                parameters.Add(new SqlParameter("@PriorAuthNumber", (entity.PriorAuthNumber == null) ? "" : entity.PriorAuthNumber));
                parameters.Add(new SqlParameter("@ProviderID", entity.ProviderID));
                parameters.Add(new SqlParameter("@ProviderTypeID", (entity.ProviderTypeID == null) ? DBNull.Value : (object)entity.ProviderTypeID));
                parameters.Add(new SqlParameter("@ReceivedDate", entity.ReceivedDate));
                parameters.Add(new SqlParameter("@RecordStatus", entity.RecordStatus));
                parameters.Add(new SqlParameter("@RecordStatusChangeComment", entity.RecordStatusChangeComment));
                parameters.Add(new SqlParameter("@RevisedDRGCode", (entity.RevisedDRGCode == null) ? DBNull.Value : (object)entity.RevisedDRGCode));
                //parameters.Add(new SqlParameter("@ServiceRenderedID", (entity.ServiceRenderedID == null) ? DBNull.Value : (object)entity.ServiceRenderedID));
                parameters.Add(new SqlParameter("@ServiceRendered", (entity.ServiceRendered == null) ? DBNull.Value : (object)entity.ServiceRendered));
                parameters.Add(new SqlParameter("@UpdatedBy", (entity.UpdatedBy == null) ? DBNull.Value : (object)entity.UpdatedBy));
                parameters.Add(new SqlParameter("@UpdatedDate", (entity.UpdatedDate == null) ? DBNull.Value : (object)entity.UpdatedDate));
                parameters.Add(new SqlParameter("@UpdatedSource", (entity.UpdatedSource == null) ? DBNull.Value : (object)entity.UpdatedSource));
                parameters.Add(new SqlParameter("@VendorName", entity.VendorName));
                parameters.Add(new SqlParameter("@ClaimAge", (entity.ClaimAge == null) ? DBNull.Value : (object)entity.ClaimAge));
                parameters.Add(new SqlParameter("@DOSFrom", entity.DOSFrom));
                parameters.Add(new SqlParameter("@DOSTo", entity.DOSTo));
                parameters.Add(new SqlParameter("@MemberCode", entity.MemberCode));
                parameters.Add(new SqlParameter("@MemberName", entity.MemberName));
                parameters.Add(new SqlParameter("@DOB", entity.DOB));
                parameters.Add(new SqlParameter("@Gender", entity.Gender));
                parameters.Add(new SqlParameter("@MemberEligibilityID", (entity.MemberEligibilityID == null) ? DBNull.Value : (object)entity.MemberEligibilityID));
                parameters.Add(new SqlParameter("@Plan", entity.Plan));
                parameters.Add(new SqlParameter("@MemberPCPID", (entity.MemberPCPID == null) ? DBNull.Value : (object)entity.MemberPCPID));
                parameters.Add(new SqlParameter("@PCPID", (entity.PCPID == null) ? DBNull.Value : (object)entity.PCPID));
                parameters.Add(new SqlParameter("@PCPName", entity.PCPName));
                parameters.Add(new SqlParameter("@Relationship", entity.Relationship));
                parameters.Add(new SqlParameter("@ProviderCode", entity.ProviderCode));
                parameters.Add(new SqlParameter("@ProviderName", entity.ProviderName));
                parameters.Add(new SqlParameter("@ProviderNPI", entity.ProviderNPI));
                parameters.Add(new SqlParameter("@ProviderGroupTIN", entity.ProviderGroupTIN));
                parameters.Add(new SqlParameter("@EffectiveDate", (entity.EffectiveDate.Date == DateTime.MinValue.Date) ? SqlDateTime.MinValue : (object)entity.EffectiveDate));
                parameters.Add(new SqlParameter("@ReimburseAmount", entity.ReimburseAmount));
                parameters.Add(new SqlParameter("@ReimburseReminderToProvider", entity.ReimburseReminderToProvider));
                parameters.Add(new SqlParameter("@ReasonForSplitPayment", entity.ReasonForSplitPayment));
                parameters.Add(new SqlParameter("@PayeeName", entity.PayeeName));
                parameters.Add(new SqlParameter("@PayeeAddress1", entity.PayeeAddress1));
                parameters.Add(new SqlParameter("@PayeeAddress2", entity.PayeeAddress2));
                parameters.Add(new SqlParameter("@PayeeCity", entity.PayeeCity));
                parameters.Add(new SqlParameter("@PayeeState", entity.PayeeState));
                parameters.Add(new SqlParameter("@PayeeZip", entity.PayeeZip));
                parameters.Add(new SqlParameter("@PayeeTin", entity.PayeeTin));
                parameters.Add(new SqlParameter("@PaymentRedirectReason", entity.PaymentRedirectReason));
                parameters.Add(new SqlParameter("@VendorID", (entity.VendorID == null) ? DBNull.Value : (object)entity.VendorID));
                parameters.Add(new SqlParameter("@AccidentStateOrProvince", (entity.AccidentStateOrProvince == null) ? "" : (object)entity.AccidentStateOrProvince));

                //DataTable udtClaimEditsCodes = new DataTable("udtClaimEditsCodes");
                //udtClaimEditsCodes = GetClaimEditsDataTable(ClaimEditsList);
                //parameters.Add(new SqlParameter("@udtClaimEditsCodes", udtClaimEditsCodes) { TypeName = "hps.ClaimEditsCodes" });

                parameters.Add(new SqlParameter("@ResultID", SqlDbType.BigInt) { Direction = ParameterDirection.Output });

                _context.Database.ExecuteSqlRaw("[hps].[usp_InsertUpdateClaimHeader] @ClaimHeaderID, @AddedSource, @AdmitDate, @AdmitHour, @AdmitSourceID, @AdmitTypeID, @AltFeeScheduleID, @BillTypeID, @BilledAmount, @BilledDRGCode" +
                                                                                                                        ", @ClaimNumber, @ClaimSourceID, @ClaimStatusID, @ClaimStatusReason, @CreatedBy, @CreatedDate, @DCN, @DischargeHour,@DischargeStatusID, @EnteredDate" +
                                                                                                                        ", @ExternalClaimID, @FormTypeID, @IllnessDate, @IsAcceptsAssignment, @IsAlternatePayee, @IsAuto, @IsCleanClaim, @IsCorrectedClaim, @IsEPSDTTitleXIX" +
                                                                                                                        ", @IsEmployment, @IsEncounter, @IsFreezed, @IsOtherAccident, @IsPatientReimbursement, @IsPayAndPursue, @IsPreDetermiantion, @IsRefundRequest" +
                                                                                                                        ", @IsSplitPayment, @IsSuppressEOB, @LoadComment, @MemberID, @OtherDate, @OtherInsurancePaid, @PaidAmount, @PaidDate, @PatientAccountNumber" +
                                                                                                                        ", @PhysicianNPI, @PhysicianName, @PriorAuthNumber, @ProviderID, @ProviderTypeID, @ReceivedDate, @RecordStatus, @RecordStatusChangeComment" +
                                                                                                                        ", @RevisedDRGCode, @ServiceRendered, @UpdatedBy, @UpdatedDate, @UpdatedSource, @VendorName, @ClaimAge, @DOSFrom, @DOSTo, @MemberCode" +
                                                                                                                        ", @MemberName, @DOB, @Gender, @MemberEligibilityID, @Plan, @MemberPCPID, @PCPID, @PCPName, @Relationship, @ProviderCode, @ProviderName, @ProviderNPI" +
                                                                                                                        ", @ProviderGroupTIN, @EffectiveDate, @ReimburseAmount, @ReimburseReminderToProvider, @ReasonForSplitPayment, @PayeeName, @PayeeAddress1" +
                                                                                                                        ", @PayeeAddress2, @PayeeCity, @PayeeState, @PayeeZip, @PayeeTin, @PaymentRedirectReason, @VendorID, @AccidentStateOrProvince" +
                                                                                                                        ", @ResultID OUT", parameters.ToArray());

                ClaimHeaderID = (long)parameters.Where(e => e.ParameterName == "@ResultID").FirstOrDefault().Value;

                return ClaimHeaderID;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotInsertUpdateClaim", ex.Message);
                return ClaimHeaderID;
            }
        }

        //private DataTable GetClaimEditsDataTable(List<ClaimEditsViewModel> ClaimEditsList)
        //{
        //    #region Create DataTable for ClaimEdits and Add Required Columns.

        //    DataTable dtClaimEdits = new DataTable("udtClaimEditsCodes");

        //    dtClaimEdits.Columns.Add("ClaimEditsID", typeof(Int64));
        //    dtClaimEdits.Columns.Add("AddedSource", typeof(string));
        //    dtClaimEdits.Columns.Add("ClaimHeaderID", typeof(Int64));
        //    dtClaimEdits.Columns.Add("ClaimLineID", typeof(Int64));            
        //    dtClaimEdits.Columns.Add("Comments", typeof(string));
        //    dtClaimEdits.Columns.Add("CreatedBy", typeof(string));
        //    dtClaimEdits.Columns.Add("CreatedDate", typeof(DateTime));
        //    dtClaimEdits.Columns.Add("Edit", typeof(string));
        //    dtClaimEdits.Columns.Add("EditDescription", typeof(string));
        //    dtClaimEdits.Columns.Add("EditStatusCode", typeof(string));
        //    dtClaimEdits.Columns.Add("IsFreezed", typeof(byte));
        //    dtClaimEdits.Columns.Add("LoadComment", typeof(string));
        //    dtClaimEdits.Columns.Add("OutcomeReason", typeof(string));
        //    dtClaimEdits.Columns.Add("RecordStatus", typeof(byte));
        //    dtClaimEdits.Columns.Add("RecordStatusChangeComment", typeof(string));
        //    dtClaimEdits.Columns.Add("UpdatedBy", typeof(string));
        //    dtClaimEdits.Columns.Add("UpdatedDate", typeof(DateTime));
        //    dtClaimEdits.Columns.Add("UpdatedSource", typeof(string));

        //    #endregion

        //    #region Create New DataRow and Set value for each Column.

        //    if (ClaimEditsList != null && ClaimEditsList.Count > 0 && ClaimEditsList[0] != null)
        //    {
        //        DataRow drClaimEdits;

        //        foreach (ClaimEditsViewModel objClaimEdits in ClaimEditsList)
        //        {
        //            drClaimEdits = dtClaimEdits.NewRow();

        //            drClaimEdits["ClaimEditsID"] = objClaimEdits.ClaimEditsID;
        //            drClaimEdits["AddedSource"] = string.Empty; //This column is used in future.
        //            drClaimEdits["ClaimHeaderID"] = objClaimEdits.ClaimHeaderID > 0 ? objClaimEdits.ClaimHeaderID : 0;
        //            drClaimEdits["ClaimLineID"] = objClaimEdits.ClaimLineID != null ? objClaimEdits.ClaimLineID : 0;                    
        //            drClaimEdits["Comments"] = string.IsNullOrEmpty(objClaimEdits.Comments) != true && Convert.ToString(objClaimEdits.Comments.Trim()) != string.Empty ? objClaimEdits.Comments.Trim() : string.Empty;

        //            if (objClaimEdits.ClaimEditsID == 0)
        //            {
        //                drClaimEdits["CreatedBy"] = string.IsNullOrEmpty(objClaimEdits.User) != true && Convert.ToString(objClaimEdits.User.Trim()) != string.Empty ? objClaimEdits.User.Trim() : string.Empty;
        //                drClaimEdits["CreatedDate"] = DateTime.Now; // objClaimEdits.CreatedDate;
        //            }
        //            else
        //            {
        //                drClaimEdits["CreatedBy"] = string.IsNullOrEmpty(objClaimEdits.User) != true && Convert.ToString(objClaimEdits.User.Trim()) != string.Empty ? objClaimEdits.User.Trim() : string.Empty;
        //                drClaimEdits["CreatedDate"] = (object)DBNull.Value;
        //            }

        //            drClaimEdits["Edit"] = string.IsNullOrEmpty(objClaimEdits.Edit) != true && Convert.ToString(objClaimEdits.Edit.Trim()) != string.Empty ? objClaimEdits.Edit.Trim() : string.Empty;
        //            drClaimEdits["EditDescription"] = string.IsNullOrEmpty(objClaimEdits.EditDescription) != true && Convert.ToString(objClaimEdits.EditDescription.Trim()) != string.Empty ? objClaimEdits.EditDescription.Trim() : string.Empty;
        //            drClaimEdits["EditStatusCode"] = string.IsNullOrEmpty(objClaimEdits.EditStatusCode) != true && Convert.ToString(objClaimEdits.EditStatusCode.Trim()) != string.Empty ? objClaimEdits.EditStatusCode.Trim() : string.Empty;
        //            drClaimEdits["IsFreezed"] = false; // objClaimEdits.IsFreezed;
        //            drClaimEdits["LoadComment"] = string.Empty; // objClaimEdits.LoadComment;
        //            drClaimEdits["OutcomeReason"] = string.IsNullOrEmpty(objClaimEdits.OutcomeReason) != true && Convert.ToString(objClaimEdits.OutcomeReason.Trim()) != string.Empty ? objClaimEdits.OutcomeReason.Trim() : string.Empty;
        //            drClaimEdits["RecordStatus"] = (byte)RecordStatus.Active;
        //            drClaimEdits["RecordStatusChangeComment"] = string.Empty; // objClaimEdits.RecordStatusChangeComment;

        //            if (objClaimEdits.ClaimEditsID != 0)
        //            {
        //                drClaimEdits["UpdatedBy"] = string.IsNullOrEmpty(objClaimEdits.User) != true && Convert.ToString(objClaimEdits.User.Trim()) != string.Empty ? objClaimEdits.User.Trim() : string.Empty; // objClaimEdits.UpdatedBy;
        //                drClaimEdits["UpdatedDate"] = DateTime.Now;  // objClaimEdits.UpdatedDate;
        //            }
        //            else
        //            {
        //                drClaimEdits["UpdatedBy"] = string.Empty; // objClaimEdits.UpdatedBy;
        //                drClaimEdits["UpdatedDate"] = (object)DBNull.Value;  // objClaimEdits.UpdatedDate;
        //            }

        //            drClaimEdits["UpdatedSource"] = string.Empty; //objClaimEdits.UpdatedSource;

        //            dtClaimEdits.Rows.Add(drClaimEdits);
        //        }
        //    }

        //    #endregion

        //    return dtClaimEdits;
        //}

        public ClaimHeaderViewModel GetClaimByClaimNumber(string ClaimNumber)
        {
            ClaimHeaderViewModel model = new ClaimHeaderViewModel();
            model = (from c in _context.ClaimHeaders
                     join cs in _context.ClaimStatuses on c.ClaimStatusID equals cs.ClaimStatusID
                     where c.ClaimNumber == ClaimNumber
                     select new ClaimHeaderViewModel()
                     {
                         ClaimHeaderID = c.ClaimHeaderID,
                         ClaimNumber = c.ClaimNumber,
                         ReceivedDate = c.ReceivedDate,
                         FormTypeID = c.FormTypeID,
                         EnteredDate = c.EnteredDate,
                         DOSFrom = c.DOSFrom,
                         DOSTo = c.DOSTo,
                         BilledAmount = c.BilledAmount,
                         PaidAmount = c.PaidAmount,
                         PaidDate = c.PaidDate,
                         OtherInsurancePaid = c.OtherInsurancePaid,
                         PatientAccountNumber = c.PatientAccountNumber,
                         ExternalClaimID = c.ExternalClaimID,
                         PriorAuthNumber = c.PriorAuthNumber,
                         ClaimStatusID = c.ClaimStatusID,
                         ClaimStatusReason = c.ClaimStatusReason,
                         ClaimSourceID = c.ClaimSourceID,
                         MemberID = c.MemberID,
                         ProviderID = c.ProviderID,
                         ProviderTypeID = c.ProviderTypeID,
                         VendorName = c.VendorName,
                         IsCorrectedClaim = c.IsCorrectedClaim,
                         IsPatientReimbursement = c.IsPatientReimbursement,
                         IsRefundRequest = c.IsRefundRequest,
                         IsCleanClaim = c.IsCleanClaim,
                         IsEncounter = c.IsEncounter,
                         IsAlternatePayee = c.IsAlternatePayee,
                         IsSplitPayment = c.IsSplitPayment,
                         IsSuppressEOB = c.IsSuppressEOB,
                         IsPayAndPursue = c.IsPayAndPursue,
                         AltFeeScheduleID = c.AltFeeScheduleID,
                         IsEmployment = c.IsEmployment,
                         IsAuto = c.IsAuto,
                         IsOtherAccident = c.IsOtherAccident,
                         IllnessDate = c.IllnessDate,
                         OtherDate = c.OtherDate,
                         PhysicianName = c.PhysicianName,
                         PhysicianNPI = c.PhysicianNPI,
                         IsAcceptsAssignment = c.IsAcceptsAssignment,
                         BillTypeID = c.BillTypeID,
                         AdmitDate = c.AdmitDate,
                         AdmitHour = c.AdmitHour,
                         AdmitTypeID = c.AdmitTypeID,
                         AdmitSourceID = c.AdmitSourceID,
                         DischargeHour = c.DischargeHour,
                         DischargeStatusID = c.DischargeStatusID,
                         BilledDRGCode = c.BilledDRGCode,
                         RevisedDRGCode = c.RevisedDRGCode,
                         IsPreDetermiantion = c.IsPreDetermiantion,
                         IsEPSDTTitleXIX = c.IsEPSDTTitleXIX,
                         ServiceRendered = c.ServiceRendered,
                         DCN = c.DCN,
                         ClaimAge = (cs.ClaimStatusID == (int)Kwicle.Core.Common.ClaimStatus.Paid || cs.ClaimStatusID == (int)Kwicle.Core.Common.ClaimStatus.Reversed || cs.ClaimStatusID == (int)Kwicle.Core.Common.ClaimStatus.Denied) ? CommonUtil.ClaimAge(c.ReceivedDate, c.PaidDate) : CommonUtil.ClaimAge(c.ReceivedDate, null),
                         ClaimStatus = cs.ClaimStatusCode,
                         MemberCode = c.MemberCode,
                         MemberName = c.MemberName,
                         DOB = c.DOB,
                         Gender = c.Gender,
                         MemberEligibilityID = c.MemberEligibilityID,
                         Plan = c.Plan,
                         MemberPCPID = c.MemberPCPID,
                         PCPID = c.PCPID,
                         PCPName = c.PCPName,
                         Relationship = c.Relationship,
                         ProviderCode = c.ProviderCode,
                         ProviderName = c.ProviderName,
                         ProviderNPI = c.ProviderNPI,
                         ProviderGroupTIN = c.ProviderGroupTIN,
                         EffectiveDate = c.EffectiveDate,
                         ReimburseAmount = c.ReimburseAmount,
                         ReimburseReminderToProvider = c.ReimburseReminderToProvider,
                         ReasonForSplitPayment = c.ReasonForSplitPayment,
                         PayeeName = c.PayeeName,
                         PayeeAddress1 = c.PayeeAddress1,
                         PayeeAddress2 = c.PayeeAddress2,
                         PayeeCity = c.PayeeCity,
                         PayeeState = c.PayeeState,
                         PayeeZip = c.PayeeZip,
                         PayeeTin = c.PayeeTin,
                         PaymentRedirectReason = c.PaymentRedirectReason,
                         AccidentStateOrProvince = c.AccidentStateOrProvince,
                         RecordStatus = c.RecordStatus,
                         AddedSource = c.AddedSource,
                         VendorID = c.VendorID,
                     }).FirstOrDefault();

            if (model != null)
            {
                // Get Alt Feeschedule
                if (model.AltFeeScheduleID != null)
                {
                    model.AltFreeScheduleInfo = _viewContext.GetContracts.Where(e => e.ContractHeaderID == model.AltFeeScheduleID).FirstOrDefault();
                }

                // Get Refering Physician
                if (model.PhysicianName.Length > 0)
                {
                    model.ReferingPhysician = (from p in _context.Providers
                                               where p.FullName == model.PhysicianName && p.ProviderTypeID == (int)ProviderType.Provider
                                               select new ProviderViewModel()
                                               {
                                                   ProviderID = p.ProviderID,
                                                   ProviderTypeID = p.ProviderTypeID,
                                                   ProviderCode = p.ProviderCode,
                                                   Title = p.Title,
                                                   LastName = p.LastName,
                                                   FirstName = p.FirstName,
                                                   MiddleName = p.MiddleName,
                                                   Suffix = p.Suffix,
                                                   SSN = p.SSN,
                                                   FullName = p.FullName,
                                                   Gender = p.Gender,
                                                   NPI = p.NPI,
                                                   Phone = p.Phone,
                                                   Fax = p.Fax,
                                                   PrimaryEmail = p.PrimaryEmail,
                                                   SecondaryEmail = p.SecondaryEmail,
                                                   CredentialStatusID = p.CredentialStatusID,
                                                   IsPCP = p.IsPCP,
                                                   IsSpecialist = p.IsSpecialist,
                                                   IsProviderWatch = p.IsProviderWatch,
                                                   IsPerson = p.IsPerson,
                                                   Race = p.Race,
                                                   Ethnicity = p.Ethnicity,
                                                   MaxMemberCount = p.MaxMemberCount,
                                                   ProviderEligibilityID = p.ProviderEligibilityID,
                                               }).FirstOrDefault();
                }

                // Get Alternate Payee Country Information
                if (model.PayeeZip.Length > 0)
                {
                    model.AlternatePayeeZipCodeInfo = (from n in this._context.ZipCodes.Where(e => e.Code == model.PayeeZip)
                                                       select new ZipCodeModel()
                                                       {
                                                           ZipCodeID = n.ZipCodeID,
                                                           AreaCode = n.AreaCode,
                                                           City = n.City,
                                                           Country = n.Country,
                                                           County = n.County,
                                                           Code = n.Code,
                                                           StateFullName = n.StateFullName
                                                       }).FirstOrDefault();
                }
            }
            return model;
        }

        public string GenerateClaimNumber(DateTime ReceivedDate, int ClaimSourceID)
        {
            string NewClaimNumber = string.Empty;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@ReceivedDate", ReceivedDate));
                parameters.Add(new SqlParameter("@ClaimSourceID", ClaimSourceID));
                parameters.Add(new SqlParameter("@NewClaimNumber", SqlDbType.VarChar, 32) { Direction = ParameterDirection.Output });

                _context.Database.ExecuteSqlRaw("[hps].[usp_GenerateClaimNumber] @ReceivedDate,@ClaimSourceID, @NewClaimNumber OUT", parameters.ToArray());

                NewClaimNumber = parameters.Where(e => e.ParameterName == "@NewClaimNumber").FirstOrDefault().Value.ToString();

                return NewClaimNumber;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGenerateClaimNumber", ex.Message);
                return NewClaimNumber;
            }
        }

        public ClaimHeader GetClaimByID(long ClaimHeaderID)
        {
            return _context.ClaimHeaders.Where(e => e.ClaimHeaderID == ClaimHeaderID).FirstOrDefault();
        }
        #endregion
    }
}
