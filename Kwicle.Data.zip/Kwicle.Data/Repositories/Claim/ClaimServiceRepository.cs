﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;
using Kwicle.Core.Views;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Masters;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimServiceRepository : BaseRepository<ClaimService>, IClaimServiceRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _vwcontext;
        #endregion
        #region Ctor
        public ClaimServiceRepository(KwicleContext context, KwicleViewContext vwcontext) :base(context)
        {
            _context = context;
            _vwcontext = vwcontext;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimService> GetAllClaimService()
        {
            try
            {
                var res = _context.ClaimServices.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimService", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimServiceViewModel> GetClaimService(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimServices
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            join fee in _context.FeeScheduleHeaders on b.FeeScheduleID equals fee.FeeScheduleHeaderID into dm
                            from z in dm.DefaultIfEmpty()
                            join ben in _context.BenefitHeaders on b.BenefitHeaderID equals ben.BenefitHeaderID into bn
                            from y in bn.DefaultIfEmpty()
                            join pr in _context.TermHeaders on b.ProviderContractTermID equals pr.TermHeaderID into term
                            from trm in term.DefaultIfEmpty()
                            join cont in _context.Contracts on b.ProviderContractID equals cont.ContractID into cn
                            from contr in cn.DefaultIfEmpty()
                            join comm in _context.CommonCodes on b.ServiceLineStatusID equals comm.CommonCodeID into stat
                            from com in stat.DefaultIfEmpty()
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new ClaimServiceViewModel()
                            {
                                ClaimServiceID = b.ClaimServiceID,
                                AdminRoute = b.AdminRoute,
                                AllowedAmount = b.AllowedAmount,
                                AllowedUnitsOrMinutes = b.AllowedUnitsOrMinutes,
                                AreaOfOralCavity = b.AreaOfOralCavity,
                                BilledAmount = b.BilledAmount,
                                BenefitHeaderID = b.BenefitHeaderID,
                                CoinsuranceAmount = b.CoinsuranceAmount,
                                CompoundCode = b.CompoundCode,
                                CompoundCount = b.CompoundCount,
                                CompoundDispUnit = b.CompoundDispUnit,
                                CompoundModifierCode = b.CompoundModifierCode,
                                CompoundProductID = b.CompoundProductID,
                                CompoundQualifierCode = b.CompoundQualifierCode,
                                CopayAmount = b.CopayAmount,
                                DateRXWritten = b.DateRXWritten,
                                DaysSupply = b.DaysSupply,
                                DeductibleAmount = b.DeductibleAmount,
                                DiagnosisPointer = b.DiagnosisPointer,
                                DifferenceAmount = b.DifferenceAmount,
                                DispenseAsWrittenCode = b.DispenseAsWrittenCode,
                                DispensingFee = b.DispensingFee,
                                DOSFrom = b.DOSFrom,
                                DOSTo = b.DOSTo,
                                EPSDT = b.EPSDT,
                                FeeScheduleID = b.FeeScheduleID,
                                FillNumber = b.FillNumber,
                                GrossAmountDue = b.GrossAmountDue,
                                IncentiveAmount = b.IncentiveAmount,
                                NDCCode = b.NDCCode,
                                ServiceLineStatusID = b.ServiceLineStatusID,
                                POSCode = b.POSCode,
                                RUGSCode = b.RUGSCode,
                                ToothSurface = b.ToothSurface,
                                ToothSystem = b.ToothSystem,
                                IngredientCost = b.IngredientCost,
                                InterestAmount = b.InterestAmount,
                                IsClean = b.IsClean,
                                IsEMG = b.IsEMG,
                                IsOverride = b.IsOverride,
                                LineNumber = b.LineNumber,
                                Modifiers = b.Modifiers,
                                NonCoveredAmount = b.NonCoveredAmount,
                                PatientPaitAmount = b.PatientPaitAmount,
                                PayableAmount = b.PayableAmount,
                                ProcedureCode = b.ProcedureCode,
                                ProdQualifierID = b.ProdQualifierID,
                                ProviderContractID = b.ProviderContractID,
                                ProviderContractTermID = b.ProviderContractTermID,
                                ReferralAuthNumber = b.ReferralAuthNumber,
                                RenderingProviderName = b.RenderingProviderName,
                                RenderingProviderNPI = b.RenderingProviderNPI,
                                RevenueCode = b.RevenueCode,
                                ToothNumberLetter = b.ToothNumberLetter,
                                TotalPaidAmount = b.TotalPaidAmount,
                                UnitsOfMeasureCode = b.UnitsOfMeasureCode,
                                UnitsOrMinutes = b.UnitsOrMinutes,
                                ProcedureCodeTypeID = b.ProcedureCodeTypeID,
                                ProcedureCodeDescription = b.ProcedureCodeDescription,
                                MemberID = b.MemberID,
                                ClaimHeaderID = b.ClaimHeaderID,
                                FeeScheduleCode = z == null ? string.Empty : z.Description,
                                Benefit = y == null ? string.Empty : y.BenefitName,
                                ProviderContract = contr == null ? string.Empty : contr.ContractName,
                                ContractTerm = trm == null ? string.Empty : trm.TermName,
                                Code = com == null ? string.Empty : com.Code ,
                                StartTime=b.StartTime,
                                EndTime=b.EndTime,
                                TotalMinutes=b.TotalMinutes,
                                ConversionTime=b.ConversionTime,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimService", ex.Message);
                return null;
            }
        }

        public KeyValuePair<int,string> GetServiceContract(int lOBID, DateTime DosFrom, DateTime DosTo)
        {
            KeyValuePair<int, string> Contracts = new KeyValuePair<int, string>();
            try
            {  
                //start Migrations 2.1 to 3.1 (Change group by query)
                Contracts = (from pcl in _context.ProviderContractLobs 
                             join pc in _context.ProviderContracts on pcl.ProviderContractID equals pc.ProviderContractID
                             join c in _context.Contracts on pc.ContractHeaderID equals c.ContractID
                             where pcl.LOBID == lOBID && c.RecordStatus == (int)RecordStatus.Active
                              && pc.RecordStatus == (int)RecordStatus.Active
                               && pcl.RecordStatus == (int)RecordStatus.Active
                             && (((c.EffectiveDate <= DosFrom.Date) && (c.TermDate >= DosFrom.Date)) ||
                              ((c.EffectiveDate <= DosTo.Date) && (c.TermDate >= DosTo.Date))
                              || ((c.EffectiveDate >= DosFrom.Date) && (c.TermDate <= DosTo.Date)))
                             //select new KeyValuePair<int, string>(c.ContractID, c.ContractName))
                             select new KeyValuePair<int, string>(c.ContractID,c.ContractName)).ToList()
                             .GroupBy(g =>g.Key).Select(x => x.FirstOrDefault()).FirstOrDefault();

                //End Migrations 2.1 to 3.1

                //For demo Purpose commented these below things
                //if (Contracts.Count > 1)
                //{
                //    var contract = Contracts.First();
                //    //base.DbState.AddErrorMessage("CanNotGetServiceContract", "More than 1 provider contract assigned to member");
                //    return contract;
                //}
                //else
                //{

                    return Contracts;

                //}
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetServiceContract", ex.Message);
                return Contracts;
            }
        }

        public Tuple<int,string, decimal> GetServiceFeeSchedule(int ContractID, KeyValuePair<int, string>[] Code, DateTime DosFrom, DateTime DosTo)
        {
            try
            {
                Tuple<int, string, decimal> tuple ;
                var codes = Code.FirstOrDefault(x => x.Key==(int)ClinicalCodeType.POS);
                var keys = Code.Select(s => s.Key);
                var values = Code.Select(s => s.Value);

                var feeScheduleDetail = (from c in _context.ProviderContracts
                                join fh in _context.FeeScheduleHeaders on c.FeeScheduleHeaderID equals fh.FeeScheduleHeaderID
                                join fdtl in _context.FeeScheduleDetails on fh.FeeScheduleHeaderID equals fdtl.FeeScheduleHeaderID
                                where c.ContractHeaderID == ContractID && fh.RecordStatus == (int)RecordStatus.Active
                                && fdtl.RecordStatus == (int)RecordStatus.Active 
                                && fdtl.POSCode==codes.Value && keys.Contains(fdtl.ClinicalCodeTypeID) && values.Contains(fdtl.Code)
                                && (((fdtl.EffectiveDate <= DosFrom.Date) && (fdtl.TermDate >= DosFrom.Date)) ||
                               ((fdtl.EffectiveDate <= DosTo.Date) && (fdtl.TermDate >= DosTo.Date))
                               || ((fdtl.EffectiveDate >= DosFrom.Date) && (fdtl.TermDate <= DosTo.Date)))
                                    && (((fh.EffectiveDate <= DosFrom.Date) && (fh.TermDate >= DosFrom.Date)) ||
                               ((fh.EffectiveDate <= DosTo.Date) && (fh.TermDate >= DosTo.Date))
                               || ((fh.EffectiveDate >= DosFrom.Date) && (fh.TermDate <= DosTo.Date)))
                                         select new  {
                                               fh.FeeScheduleHeaderID,
                                               fh.Description,
                                               fdtl.Code,
                                               fdtl.ClinicalCodeTypeID,
                                               fdtl.Rate }).ToList();
                if (feeScheduleDetail.Count() > 1)
                {
                    base.DbState.AddErrorMessage("CanNotGetServiceFeeSchedules", "More than 1 FeeSchedule Found");
                    return null;
                }
                else
                {
                    var feeSchedule = feeScheduleDetail.FirstOrDefault();
                    tuple= feeSchedule!=null? new Tuple<int, string, decimal>(feeSchedule.FeeScheduleHeaderID, feeSchedule.Description, feeSchedule.Rate):null;
                    return tuple;
                }
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetServiceFeeSchedules", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimServiceDollarsViewModel> GetDollarValues(DollarsCalculationModel model)
        {
            try
            {
               
                var queryProviderNetwork = from pro in _context.ProviderContracts
                                           join con in _context.Contracts on pro.ContractHeaderID equals con.ContractID
                                           where con.ContractID == model.ProviderContractID && pro.RecordStatus == (int)RecordStatus.Active
                                           select pro.NetworkID;
                var providerNetwork = queryProviderNetwork.Count() == 0 ? 0 : queryProviderNetwork.FirstOrDefault();

                var dollarQuery = from ben in _context.BenefitHeaders
                                  join co in _context.BenefitCopayCoinsurances on ben.BenefitHeaderID equals co.BenefitHeaderID
                                  join cop in _context.CopayCoinsurances on co.CopayCoinsuranceID equals cop.CopayCoinsuranceID
                                  join ded in _context.HealthPlanDeductibles on ben.BenefitHeaderID equals ded.BenefitHeaderID into dedtmp
                                  from pde in dedtmp.DefaultIfEmpty()
                                  where cop.RecordStatus == (int)RecordStatus.Active && ben.BenefitHeaderID == model.BenefitHeaderID
                                  select new ClaimServiceDollarsViewModel()
                                  {
                                      BenefitHeaderID = co.BenefitHeaderID,
                                      CopayAmount = ben.IsCopay ? cop.FixedCopay : 0,
                                      IsNonCovered = ben.EOBReason == EOBEOPType.NS.Description() ? true : false,
                                      CoinsurancePercentage = ben.IsCoinsurance ? cop.CoinsurancePercentage : 100,
                                      DeductibleAmount = pde == null ? 0 : providerNetwork == (int)NetworkType.InNetwork ? pde.IndividualDeductibleInNetwork : providerNetwork == (int)NetworkType.OutOfNetwork ? pde.IndividualDeductibleOutNetwork : 0,

                                  };
                return dollarQuery;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetDollarValues", ex.Message);
                return null;
            }
        }
       
        public decimal GetAllowableAmount(int FeeScheduleId,string ProcedureCode, string POSCode, DateTime DosFrom, DateTime DosTo,string[] Modifiers) {
            try
            {
                var queryFeeSchedules = from fee in _context.FeeScheduleDetails
                          .Where(x => x.FeeScheduleHeaderID == FeeScheduleId && x.Code==ProcedureCode
                          &&  (x.POSCode == POSCode) ||( (Modifiers.Contains(x.Modifier1)) || (Modifiers.Contains(x.Modifier2)))
                          && x.RecordStatus == (int)RecordStatus.Active
                          && (((x.EffectiveDate <= DosFrom.Date) && (x.TermDate >= DosFrom.Date)) ||
                          ((x.EffectiveDate <= DosTo.Date) && (x.TermDate >= DosTo.Date))
                          || ((x.EffectiveDate >= DosFrom.Date) && (x.TermDate <= DosTo.Date))))
                                        select fee;

                var isPricingModifier = queryFeeSchedules
                         .Any(x => Modifiers.Contains(x.Modifier1)
                         || Modifiers.Contains(x.Modifier2));


                //var FeeSchedule = isPricingModifier? queryFeeSchedules.Where(x => Modifiers.Contains(x.Modifier1) || Modifiers.Contains(x.Modifier2)).FirstOrDefault(): queryFeeSchedules.FirstOrDefault();
                var modifierDis = isPricingModifier?_context.ModifierDiscounts.Where(m => ((m.ModifierCode == queryFeeSchedules.FirstOrDefault().Modifier1) || (m.ModifierCode == queryFeeSchedules.FirstOrDefault().Modifier2))
                                    && (((m.EffectiveDate <= DosFrom.Date) && (m.TermDate >= DosFrom.Date)) ||
                                        ((m.EffectiveDate <= DosTo.Date) && (m.TermDate >= DosTo.Date))
                                        || ((m.EffectiveDate >= DosFrom.Date) && (m.TermDate <= DosTo.Date)))
                                    && m.RecordStatus == (int)RecordStatus.Active):null;

                var allowableAmount =Math.Round(modifierDis !=null? queryFeeSchedules.FirstOrDefault().Rate * (modifierDis.FirstOrDefault().ModifierPercentage / 100): queryFeeSchedules.FirstOrDefault().Rate);

                return allowableAmount;

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllowableAmount", ex.Message);
                return 0;
            }

        }

        public decimal AnesthesiaCalculatedValue(long ClaimHeaderID, int Unit, DateTime DosFrom, DateTime DosTo)
        {
            try
            {
                var rate = (from c in _context.ClaimHeaders
                            join p in _context.ProviderLocations on c.ProviderID equals p.ProviderID
                            join lcl in _context.Locations on p.LocationID equals lcl.LocationID
                            join z in _context.ZipCodes on lcl.Zip equals z.Code
                            join lty in _context.Localities on z.County equals lty.County
                            join ar in _context.AnesthesiaRegionRates on new { lty.LocalityCode,lty.Carrier } equals new {ar.LocalityCode,ar.Carrier}
                        where p.RecordStatus == (int)RecordStatus.Active && ar.RecordStatus == (int)RecordStatus.Active
                         && (((ar.EffectiveDate <= DosFrom.Date) && (ar.TermDate >= DosFrom.Date)) ||
                                ((ar.EffectiveDate <= DosTo.Date) && (ar.TermDate >= DosTo.Date))
                                || ((ar.EffectiveDate >= DosFrom.Date) && (ar.TermDate <= DosTo.Date)))
                        select ar.Rate).FirstOrDefault();
                rate =Math.Round(rate * Unit);
                return rate;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAnesthesiaCalculatedValue", ex.Message);
                return 0;
            }
        }

        public short AnesthesiaUnit(string Code,int lOBID, DateTime DosFrom, DateTime DosTo)
        {
            var basicUnit = (from a in _context.AnesthesiaCodeUnits
                            join l in _context.Lobs on a.ProductID equals l.ProductID
                            where l.LobID == lOBID && a.CPTCode == Code && a.RecordStatus==(byte)RecordStatus.Active
                            && l.RecordStatus == (byte)RecordStatus.Active
                             && (((a.EffectiveDate <= DosFrom.Date) && (a.TermDate >= DosFrom.Date)) ||
                               ((a.EffectiveDate <= DosTo.Date) && (a.TermDate >= DosTo.Date))
                               || ((a.EffectiveDate >= DosFrom.Date) && (a.TermDate <= DosTo.Date)))
                            select a.BaseUnit).FirstOrDefault();


            return basicUnit;
        }
        #endregion
    }
}
