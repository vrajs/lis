﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class RefundNoteRepository : BaseRepository<RefundNote>, IRefundNoteRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public RefundNoteRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation   

        public IEnumerable<RefundNote> GetAllRefundNote()
        {
            try
            {
                var res = _context.RefundNotes.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundNote", ex.Message);
                return null;
            }
        }

        public IQueryable<RefundNoteViewModel> GetRefundNote(int RefundRequestID)
        {
            try
            {
                var query = from rn in _context.RefundNotes
                            where rn.RecordStatus != (int)RecordStatus.Deleted && rn.RefundRequestID == RefundRequestID
                            select new RefundNoteViewModel()
                            {
                                RefundNoteID = rn.RefundNoteID,
                                RefundRequestID = rn.RefundRequestID,
                                ShortDesc = rn.ShortDesc,
                                LongDesc = rn.LongDesc,
                                EffectiveDate = rn.EffectiveDate,
                                TermDate = (rn.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rn.TermDate,
                                CreatedBy = rn.CreatedBy,
                                CreatedDate = rn.CreatedDate
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetRefundNote", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
