﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimEditsRepository : BaseRepository<ClaimEdits>, IClaimEditsRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimEditsRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimEdits> GetAllClaimEdits()
        {
            try
            {
                var res = _context.ClaimEditss.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimEdits", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimEditsViewModel> GetClaimEdits(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimEditss
                            join e in _context.EditCode on b.EditCodeID equals e.EditCodeID
                            join o in _context.CommonCodes on b.OutComeID equals o.CommonCodeID
                            join moc in _context.CommonCodes on b.OutComeCodeID equals moc.CommonCodeID into toc
                            from oc in toc.DefaultIfEmpty()
                            join msl in _context.ClaimServices on b.ClaimLineID equals msl.ClaimServiceID into tsl
                            from sl in tsl.DefaultIfEmpty()
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted
                            orderby (b.OutComeID == (int)EditReason.Deny ? 1 : b.OutComeID == (int)EditReason.Pend ? 2 : b.OutComeID == (int)EditReason.Approve ? 3 : b.OutComeID == (int)EditReason.Informational ? 4 : 5), (sl == null ? Convert.ToInt16(0) : sl.LineNumber)
                            select new ClaimEditsViewModel()
                            {
                                ClaimEditsID = b.ClaimEditsID,
                                ClaimLineID = b.ClaimLineID,
                                EditCode = b.EditCode,
                                EditDescription = b.EditDescription,
                                Comments = b.Comments,
                                LastUpdatedBy = (b.UpdatedBy != null) ? b.UpdatedBy : b.CreatedBy,
                                LastUpdatedDate = (b.UpdatedDate != null) ? Convert.ToDateTime(b.UpdatedDate) : b.CreatedDate,
                                AddedSource = b.AddedSource,
                                ClaimHeaderID = b.ClaimHeaderID,
                                EditCodeID = b.EditCodeID,
                                IsOverride = b.IsOverride,
                                OutCome = o.ShortName,
                                OutComeCode = oc == null ? string.Empty : oc.ShortName,
                                OutComeCodeID = b.OutComeCodeID,
                                OutComeID = b.OutComeID,
                                LineNumber = (sl == null ? Convert.ToInt16(0) : sl.LineNumber),
                                RecordDisplayOrder = 0,
                                IsFreezedEditCode = e.IsFreezed
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetClaimEdits", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
