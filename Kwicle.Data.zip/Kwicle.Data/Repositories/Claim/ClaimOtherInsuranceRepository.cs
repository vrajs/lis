﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class ClaimOtherInsuranceRepository : BaseRepository<ClaimOtherInsurance>, IClaimOtherInsuranceRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClaimOtherInsuranceRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<ClaimOtherInsurance> GetAllClaimOtherInsurance()
        {
            try
            {
                var res = _context.ClaimOtherInsurances.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllClaimOtherInsurance", ex.Message);
                return null;
            }
        }

        public IQueryable<ClaimOtherInsuranceViewModel> GetClaimOtherInsurance(long ClaimHeaderID)
        {
            try
            {
                var query = from b in _context.ClaimOtherInsurances                            
                            where b.ClaimHeaderID == ClaimHeaderID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new ClaimOtherInsuranceViewModel()
                            {
                                ClaimOtherInsuranceID = b.ClaimOtherInsuranceID,
                                IsLineLevel = b.IsLineLevel,
                                ServiceLineNumber = b.ServiceLineNumber,
                                DOSFrom = b.DOSFrom,
                                DOSTo = b.DOSTo,
                                POSCode = b.POSCode,
                                RevenueCode = b.RevenueCode,
                                ProcedureCode = b.ProcedureCode,
                                Modifiers = b.Modifiers,
                                BilledAmount = b.BilledAmount,
                                EOBDate = b.EOBDate,
                                AllowedAmount = b.AllowedAmount,
                                DeductibleAmount = b.DeductibleAmount,
                                CopayAmount = b.CopayAmount,
                                CoinsuranceAmount = b.CoinsuranceAmount,
                                NetAllowedAmount = b.NetAllowedAmount,
                                TotalPaidAmount = b.TotalPaidAmount,
                                InsuranceCarrierID = b.InsuranceCarrierID,
                                SourceInsuranceName = b.SourceInsuranceName,
                                Units =b.Units,
                                ClaimHeaderID=b.ClaimHeaderID,
                                AddedSource = b.AddedSource
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetClaimOtherInsurance", ex.Message);
                return null;
            }
        }
        
        public ClaimOtherInsurance GetInsuranceID(int ID, ClaimOtherInsurance model)
        {
            var cob = _context.MemberCOBs.Where(c => c.MemberID == ID && c.RecordStatus == (int)RecordStatus.Active).FirstOrDefault();
            if (cob!=null) { 
                if (cob.InsuranceCarrierID != 0 || !cob.InsuranceCarrierID.Equals(null))
            {
                var ins = _context.InsuranceCarriers.Where(i => i.InsuranceCarrierID == cob.InsuranceCarrierID && i.RecordStatus == (int)RecordStatus.Active).FirstOrDefault();
                model.InsuranceCarrierID = cob.InsuranceCarrierID;
                model.SourceInsuranceName = ins != null ? ins.InsuranceName : string.Empty;
            }
            }
            return model;
        }
        #endregion
    }
}
