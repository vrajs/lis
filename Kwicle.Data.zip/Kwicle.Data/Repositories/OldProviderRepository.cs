﻿using Kwicle.Data.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories
{

    public class OldProviderRepository : BaseRepository<OldProvider>, IOldProviderRepository
    {
        private readonly KwicleContext _context;
        public OldProviderRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        public OldProvider GetProvider(int ProviderId)
        {
            return _context.OldProviders
              .Include(s => s.Clinic)
              .Where(s => s.ProviderID == ProviderId)
              .FirstOrDefault();
        }

        public IEnumerable<OldProvider> GetProviders(int id)
        {
            return _context.OldProviders
              .Include(s => s.Clinic)
              .Where(s => s.Clinic.ClinicID == id)
              .OrderBy(s => s.Name)
              .ToList();
        }

        public IEnumerable<OldProvider> GetProvidersWithProcedures(int id)
        {
            return _context.OldProviders
              .Include(s => s.Clinic)
              .Include(s => s.Procedures)
              .Where(s => s.Clinic.ClinicID == id)
              .OrderBy(s => s.Name)
              .ToList();
        }

        public IEnumerable<OldProvider> GetProvidersByUID(string UID)
        {
            return _context.OldProviders
              .Include(s => s.Clinic)
              .Where(s => s.Clinic.UID.Equals(UID, StringComparison.CurrentCultureIgnoreCase))
              .OrderBy(s => s.Name)
              .ToList();
        }

        public IEnumerable<OldProvider> GetProvidersByUIDWithProcedures(string UID)
        {
            return _context.OldProviders
              .Include(s => s.Clinic)
              .Include(s => s.Procedures)
              .Where(s => s.Clinic.UID.Equals(UID, StringComparison.CurrentCultureIgnoreCase))
              .OrderBy(s => s.Name)
              .ToList();
        }

        public OldProvider GetProviderWithProcedures(int ProviderId)
        {
            return _context.OldProviders
              .Include(s => s.Clinic)
              .Include(s => s.Procedures)
              .Where(s => s.ProviderID == ProviderId)
              .FirstOrDefault();
        }
    }
}
