﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Data.Contracts.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.Master;
using Microsoft.EntityFrameworkCore;
using Kwicle.Data.Models;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberRepository : BaseRepository<Kwicle.Core.Entities.MemberStructure.Member>, IMemberRepository
    {
        #region Property
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Constructor
        public MemberRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Get Methods
        public IQueryable<vwMemberList> GetMember()
        {
            return from mem in _viewContext.vwMemberList select mem;
        }

        public MemberViewModel GetMemberForView(string MemberCode)
        {
            var query = from m in _context.Members
                        join rel in _context.CommonCodes on m.RelationshipID equals rel.CommonCodeID
                        join g in _context.CommonCodes on m.GenderID equals g.CommonCodeID
                        join tmsc in _context.CommonCodes on m.MaritalStatusID equals tmsc.CommonCodeID into dtmsc
                        from msc in dtmsc.DefaultIfEmpty()
                        join trt in _context.CommonCodes on m.ResidingAtID equals trt.CommonCodeID into dtrt
                        from rt in dtrt.DefaultIfEmpty()
                        join tr in _context.CommonCodes on m.RaceID equals tr.CommonCodeID into dtr
                        from r in dtr.DefaultIfEmpty()
                        join te in _context.CommonCodes on m.EthnicityID equals te.CommonCodeID into dte
                        from e in dte.DefaultIfEmpty()
                        join tpl in _context.CommonCodes on m.PrimaryLanguageID equals tpl.CommonCodeID into dtpl
                        from pl in dtpl.DefaultIfEmpty()
                        join tsl in _context.CommonCodes on m.SecondaryLanguageID equals tsl.CommonCodeID into dtsl
                        from sl in dtsl.DefaultIfEmpty()
                        join tss in _context.CommonCodes on m.StudentStatusID equals tss.CommonCodeID into dtss
                        from ss in dtss.DefaultIfEmpty()
                        join tes in _context.CommonCodes on m.EmployeeStatusID equals tes.CommonCodeID into dtes
                        from es in dtes.DefaultIfEmpty()
                        where m.MemberCode == MemberCode && m.RecordStatus == (int)RecordStatus.Active
                        select new MemberViewModel()
                        {
                            MemberID = m.MemberID,
                            DOB = m.DOB,
                            DeceasedDate = m.DeceasedDate,
                            DeceasedReason = m.DeceasedReason,
                            DisplayName = m.DisplayName,
                            EmployeeStatusID = m.EmployeeStatusID,
                            EmployeeStatusValue = (es == null) ? null : es.ShortName,
                            EthnicityID = m.EthnicityID,
                            EthnicityValue = (e == null) ? null : e.ShortName,
                            FamilyID = m.FamilyID,
                            FamilyCode = m.FamilyCode,
                            FirstName = m.FirstName,
                            GenderID = m.GenderID,
                            GenderValue = g.ShortName,
                            IsAdvanceDirective = m.IsAdvanceDirective,
                            IsDeceased = m.IsDeceased,
                            IsExcludeFromClaimEditing = m.IsExcludeFromClaimEditing,
                            IsHandicap = m.IsHandicap,
                            IsHippaEmail = m.IsHippaEmail,
                            IsHippaMail = m.IsHippaMail,
                            IsHippaText = m.IsHippaText,
                            IsHippaVoiceMessage = m.IsHippaVoiceMessage,
                            IsTestMember = m.IsTestMember,
                            PrimaryLanguageID = m.PrimaryLanguageID,
                            PrimaryLanguageValue = (pl == null) ? null : pl.ShortName,
                            SecondaryLanguageID = m.SecondaryLanguageID,
                            SecondaryLanguageValue = (sl == null) ? null : sl.ShortName,
                            LastName = m.LastName,
                            MaritalStatusID = m.MaritalStatusID,
                            MaritalStatusValue = (msc == null) ? null : msc.ShortName,
                            MiddleName = m.MiddleName,
                            Prefix = m.Prefix,
                            PreviousName = m.PreviousName,
                            PrimaryEmail = m.PrimaryEmail,
                            RaceID = m.RaceID,
                            RaceValue = (r == null) ? null : r.ShortName,
                            RelationshipID = m.RelationshipID,
                            RelationshipValue = rel.ShortName,
                            ResidingAtID = m.ResidingAtID,
                            ResidingAtValue = (rt == null) ? null : rt.ShortName,
                            SSN = m.SSN,
                            SecondaryEmail = m.SecondaryEmail,
                            StudentStatusID = m.StudentStatusID,
                            StudentStatusValue = (ss == null) ? null : ss.ShortName,
                            Suffix = m.Suffix,
                            MemberCode = m.MemberCode,
                            SelfMemberID = m.FamilyID.Value,
                            SelfMemberCode = _context.Members.Where(e => e.FamilyID == m.FamilyID).FirstOrDefault().MemberCode
                        };
            return query.FirstOrDefault();
        }


        public MemberViewModel GetMember(string MemberCode)
        {
            var query = from d in _context.Members
                        where d.MemberCode == MemberCode && d.RecordStatus == (int)RecordStatus.Active
                        select new MemberViewModel()
                        {
                            MemberID = d.MemberID,
                            MemberCode = d.MemberCode,
                            FamilyID = d.FamilyID,
                            FamilyCode = d.FamilyCode,
                            DisplayName = d.DisplayName,
                            RelationshipID = d.RelationshipID,
                            Prefix = d.Prefix,
                            PrimaryLanguageID = d.PrimaryLanguageID,
                            SecondaryLanguageID = d.SecondaryLanguageID,
                            LastName = d.LastName,
                            FirstName = d.FirstName,
                            MiddleName = d.MiddleName,
                            Suffix = d.Suffix,
                            SSN = d.SSN,
                            GenderID = d.GenderID,
                            DOB = d.DOB,
                            MaritalStatusID = d.MaritalStatusID,
                            RaceID = d.RaceID,
                            EthnicityID = d.EthnicityID,
                            PrimaryEmail = d.PrimaryEmail,
                            IsAdvanceDirective = d.IsAdvanceDirective,
                            IsDeceased = d.IsDeceased,
                            DeceasedDate = d.DeceasedDate,
                            ResidingAtID = d.ResidingAtID,
                            StudentStatusID = d.StudentStatusID,
                            EmployeeStatusID = d.EmployeeStatusID,
                            IsHandicap = d.IsHandicap,
                            IsHippaEmail = d.IsHippaEmail,
                            IsHippaMail = d.IsHippaMail,
                            IsHippaText = d.IsHippaText,
                            IsHippaVoiceMessage = d.IsHippaVoiceMessage
                        };
            return query.FirstOrDefault();
        }


        public string Insert(Kwicle.Core.Entities.MemberStructure.Member entity, MemberEligibility memberEligibility)
        {
            string MemberCode = string.Empty;
            var executionStrategy = _context.Database.CreateExecutionStrategy();
            executionStrategy.Execute(() =>
            {
                using (var dbCTransaction = _context.Database.BeginTransaction())
                {
                    try
                    {
                        // Get System Settings For Member Code
                        SeqNumber ssEntity = _context.SeqNumbers.Where(e => e.SettingCode == "MemSeqNo").FirstOrDefault();
                        if (ssEntity != null)
                        {
                            // Update last sequence number
                            ssEntity.LastSeqNumber = (Convert.ToInt32(ssEntity.LastSeqNumber) + 1).ToString();
                            _context.Entry(ssEntity).State = EntityState.Modified;
                            _context.SaveChanges();

                            // Update Member Code
                            entity.MemberCode = ssEntity.LastSeqNumber.ToString();

                            // Get System Settings For Family Code
                            if (entity.RelationshipID == (int)MemberRelationship.Self)
                            {
                                SeqNumber FamilySeqEntity = _context.SeqNumbers.Where(e => e.SettingCode == "FamilySeqNo").FirstOrDefault();

                                if (FamilySeqEntity != null)
                                {
                                    // Update last Family Sequence Number
                                    FamilySeqEntity.LastSeqNumber = (Convert.ToInt32(FamilySeqEntity.LastSeqNumber) + 1).ToString();
                                    _context.Entry(FamilySeqEntity).State = EntityState.Modified;
                                    _context.SaveChanges();

                                    // Update Family Code
                                    entity.FamilyCode = FamilySeqEntity.LastSeqNumber.ToString();
                                }
                            }

                            // Code for check member exists or not and insert new member
                            Kwicle.Core.Entities.MemberStructure.Member existingMember = _context.Members.Where(e => e.MemberCode == entity.MemberCode).FirstOrDefault();
                            if (existingMember == null)
                            {
                                // Add record into database
                                _context.Members.Add(entity);
                                _context.SaveChanges();

                                // Code for insert member eligibility
                                memberEligibility.MemberID = entity.MemberID;
                                _context.MemberEligibilitys.Add(memberEligibility);
                                _context.SaveChanges();

                                // Code for set family ID
                                if (entity.RelationshipID == (int)MemberRelationship.Self)
                                {
                                    entity.FamilyID = entity.MemberID;
                                }

                                // Code for update member Eleigibility ID & Family ID
                                entity.MemberEligibilityID = memberEligibility.MemberEligibilityID;
                                entity.UpdatedBy = entity.CreatedBy;
                                entity.UpdatedDate = entity.CreatedDate;
                                _context.Members.Update(entity);
                                _context.SaveChanges();

                                dbCTransaction.Commit();

                                MemberCode = entity.MemberCode;
                            }
                            else
                            {
                                dbCTransaction.Rollback();
                                base.DbState.AddErrorMessage("CanNotAddRecord", "Member ID already exists.");
                                MemberCode = string.Empty;
                            }
                        }
                        else
                        {
                            dbCTransaction.Rollback();
                            base.DbState.AddErrorMessage("CanNotAddRecord", "Member ID generation default setting does not exists.");
                            MemberCode = string.Empty;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbCTransaction.Rollback();
                        base.DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                        MemberCode = string.Empty;
                        return string.Empty;
                    }
                }
                return MemberCode;
            });

            return MemberCode;
        }


        public MemberInfoForCOBLetterViewModel GetMemberInfoForCOBLetter(int MemberID)
        {
            var query = from d in _context.Members
                        from ele in _context.MemberEligibilitys.Where(e => e.MemberEligibilityID == d.MemberEligibilityID).DefaultIfEmpty()
                        from con in _context.MemberContacts.Where(e => e.MemberContactID == d.MemberContactID).DefaultIfEmpty()
                        from pla in _context.HealthPlans.Where(e => e.HealthPlanID == ele.HealthPlanID).DefaultIfEmpty()
                        where d.MemberID == MemberID
                        select new MemberInfoForCOBLetterViewModel()
                        {
                            MemberID = d.MemberID,
                            DisplayName = d.DisplayName,
                            MailingAddress = (con == null) ? string.Empty : con.Address1,
                            City = (con == null) ? string.Empty : con.City,
                            State = (con == null) ? string.Empty : con.State,
                            Zip = (con == null) ? string.Empty : con.Zip,
                            PlanName = (pla == null) ? string.Empty : pla.PlanName,
                            MemberCode = d.MemberCode,
                        };
            return query.FirstOrDefault();
        }


        public List<MemberViewModel> GetDependentMember(string FamilyCode)
        {
            var query = from m in _context.Members
                        join rel in _context.CommonCodes on m.RelationshipID equals rel.CommonCodeID
                        join g in _context.CommonCodes on m.GenderID equals g.CommonCodeID
                        join tmsc in _context.CommonCodes on m.MaritalStatusID equals tmsc.CommonCodeID into dtmsc
                        from msc in dtmsc.DefaultIfEmpty()
                        join trt in _context.CommonCodes on m.ResidingAtID equals trt.CommonCodeID into dtrt
                        from rt in dtrt.DefaultIfEmpty()
                        join tr in _context.CommonCodes on m.RaceID equals tr.CommonCodeID into dtr
                        from r in dtr.DefaultIfEmpty()
                        join te in _context.CommonCodes on m.EthnicityID equals te.CommonCodeID into dte
                        from e in dte.DefaultIfEmpty()
                        join tpl in _context.CommonCodes on m.PrimaryLanguageID equals tpl.CommonCodeID into dtpl
                        from pl in dtpl.DefaultIfEmpty()
                        join tsl in _context.CommonCodes on m.SecondaryLanguageID equals tsl.CommonCodeID into dtsl
                        from sl in dtsl.DefaultIfEmpty()
                        join tss in _context.CommonCodes on m.StudentStatusID equals tss.CommonCodeID into dtss
                        from ss in dtss.DefaultIfEmpty()
                        join tes in _context.CommonCodes on m.EmployeeStatusID equals tes.CommonCodeID into dtes
                        from es in dtes.DefaultIfEmpty()
                        join dEli in _context.MemberEligibilitys on m.MemberID equals dEli.MemberID into tdEli
                        from de in tdEli.Where(w => w.CoverageTypeID == (int)CoverageType.Primary && w.RecordStatus != (byte)RecordStatus.Deleted).DefaultIfEmpty()
                        join drt in _context.CommonCodes on de.RiskTypeID equals drt.CommonCodeID into tdrt
                        from drty in tdrt.DefaultIfEmpty()
                        where m.FamilyCode == FamilyCode && m.RecordStatus == (int)RecordStatus.Active
                        orderby m.DisplayName ascending
                        select new MemberViewModel()
                        {
                            MemberID = m.MemberID,
                            DOB = m.DOB,
                            DeceasedDate = m.DeceasedDate,
                            DeceasedReason = m.DeceasedReason,
                            DisplayName = m.DisplayName,
                            EmployeeStatusID = m.EmployeeStatusID,
                            EmployeeStatusValue = (es == null) ? null : es.ShortName,
                            EthnicityID = m.EthnicityID,
                            EthnicityValue = (e == null) ? null : e.ShortName,
                            FamilyID = m.FamilyID,
                            FamilyCode = m.FamilyCode,
                            FirstName = m.FirstName,
                            GenderID = m.GenderID,
                            GenderValue = g.ShortName,
                            IsAdvanceDirective = m.IsAdvanceDirective,
                            IsDeceased = m.IsDeceased,
                            IsExcludeFromClaimEditing = m.IsExcludeFromClaimEditing,
                            IsHandicap = m.IsHandicap,
                            IsHippaEmail = m.IsHippaEmail,
                            IsHippaMail = m.IsHippaMail,
                            IsHippaText = m.IsHippaText,
                            IsHippaVoiceMessage = m.IsHippaVoiceMessage,
                            IsTestMember = m.IsTestMember,
                            PrimaryLanguageID = m.PrimaryLanguageID,
                            PrimaryLanguageValue = (pl == null) ? null : pl.ShortName,
                            SecondaryLanguageID = m.SecondaryLanguageID,
                            SecondaryLanguageValue = (sl == null) ? null : sl.ShortName,
                            LastName = m.LastName,
                            MaritalStatusID = m.MaritalStatusID,
                            MaritalStatusValue = (msc == null) ? null : msc.ShortName,
                            MiddleName = m.MiddleName,
                            Prefix = m.Prefix,
                            PreviousName = m.PreviousName,
                            PrimaryEmail = m.PrimaryEmail,
                            RaceID = m.RaceID,
                            RaceValue = (r == null) ? null : r.ShortName,
                            RelationshipID = m.RelationshipID,
                            RelationshipValue = rel.ShortName,
                            ResidingAtID = m.ResidingAtID,
                            ResidingAtValue = (rt == null) ? null : rt.ShortName,
                            SSN = m.SSN,
                            SecondaryEmail = m.SecondaryEmail,
                            StudentStatusID = m.StudentStatusID,
                            StudentStatusValue = (ss == null) ? null : ss.ShortName,
                            Suffix = m.Suffix,
                            MemberCode = m.MemberCode,
                            EffectiveDate = (de == null) ? (DateTime?)null : de.EffectiveDate,
                            RiskType = (drty == null) ? null : drty.ShortName,
                        };
            return query.ToList();
        }

        #endregion
    }
}
