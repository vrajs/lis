﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Kwicle.Data.Repositories.Member
{
    public class MemberPreEnrollmentAttachmentRepository : BaseRepository<MemberPreEnrollmentAttachment>, IMemberPreEnrollmentAttachmentRepository
    {
        private readonly KwicleContext _context;
        private readonly IMemberEnrollmentHeaderRepository _memberEnrollmentHeaderRepository;
        public MemberPreEnrollmentAttachmentRepository(KwicleContext context, IMemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository) : base(context)
        {
            _context = context;
            _memberEnrollmentHeaderRepository = memberEnrollmentHeaderRepository;
        }


        public async Task<MemberPreEnrollmentAttachment> GetContainerName(MemberPreEnrollmentAttachment memberPreEnrollmentAttachment)
        {

            await _context.SaveChangesAsync();
            return memberPreEnrollmentAttachment;

        }

        public async Task<List<MemberPreEnrollmentAttachmentViewModel>> GetMemberAttachmentByMemberId(int MemberId)
        {
            return await (from mt in _context.MemberPreEnrollmentAttachment
                          join mem in _context.MemberPreEnrollment on mt.MemberPreEnrollmentID equals mem.MemberPreEnrollmentID
                          where mem.MemberID == MemberId && mt.RecordStatus != (int)RecordStatus.Deleted && mt.RecordStatus == (int)RecordStatus.Active

                          select new MemberPreEnrollmentAttachmentViewModel()
                          {
                              MemberPreEnrollmentAttachmentID = mt.MemberPreEnrollmentAttachmentID,
                              MemberPreEnrollmentID = mt.MemberPreEnrollmentID,
                              FileName = mt.FileName,
                              FileLocation = mt.FileLocation,
                              IsFreezed = mt.IsFreezed,
                              RecordStatusChangeComment = mt.RecordStatusChangeComment,
                              CreatedDate = mt.CreatedDate,
                              CreatedBy = mt.CreatedBy
                          }).ToListAsync();

        }
        public async Task<List<OtherDocument>> GetMemberAttachmentListByMemberId(int memberId)
        {
            return await (from od in _context.OtherDocuments
                          where od.IsDeleted == false && od.MemberID == memberId    
                          select new OtherDocument()
                          {
                              DocumentId = od.DocumentId,
                              DocumentName = od.DocumentName,
                              MemberID = od.MemberID,
                              AttachmentType = od.AttachmentType,
                              CreatedDate = od.CreatedDate,
                              CreatedBy = od.CreatedBy,
                              FolderName = od.FolderName,
                          }).ToListAsync();
        }

    }

}
