﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberCOBRepository : BaseRepository<MemberCOB>, IMemberCOBRepository
    {
        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public MemberCOBRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region API Methods
        public List<MemberCOBViewModel> GetMemberCOB(string FamilyCode)
        {
            var query = from n in _context.MemberCOBs
                        join ic in _context.InsuranceCarriers on n.InsuranceCarrierID equals ic.InsuranceCarrierID
                        join iy in _context.CommonCodes on n.InsuranceTypeID equals iy.CommonCodeID
                        join cy in _context.CommonCodes on n.CoverageTypeID equals cy.CommonCodeID
                        join mem in _context.Members on n.MemberID equals mem.MemberID
                        join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                        join tps in _context.CommonCodes on n.PolicyHolderStatusID equals tps.CommonCodeID into dtps
                        from ps in dtps.DefaultIfEmpty()
                        where mem.FamilyCode == FamilyCode && n.RecordStatus != (int)RecordStatus.Deleted
                        select new MemberCOBViewModel()
                        {
                            MemberCOBID = n.MemberCOBID,
                            AccidentInjuryDate = n.AccidentInjuryDate,
                            CoverageTypeID = n.CoverageTypeID,
                            EffectiveDate = n.EffectiveDate,
                            GroupNumber = n.GroupNumber,
                            InsuranceCarrierID = n.InsuranceCarrierID,
                            InsuranceCarrierName = ic.InsuranceName,
                            InsuranceMemberCode = n.InsuranceMemberCode,
                            InsuranceTypeID = n.InsuranceTypeID,
                            MemberID = n.MemberID,
                            PolicyHolderDOB = n.PolicyHolderDOB,
                            PolicyHolderMemberCode = n.PolicyHolderMemberCode,
                            PolicyHolderName = n.PolicyHolderName,
                            PolicyHolderStatusID = n.PolicyHolderStatusID,
                            PolicyNumber = n.PolicyNumber,
                            Relationship = n.Relationship,
                            TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                            IsReleaseInfoOnFile = n.IsReleaseInfoOnFile,
                            InsuranceType = iy.ShortName,
                            CoverageType = cy.ShortName,
                            PolicyHolderStatus = (ps == null) ? null : ps.ShortName,
                            InsuranceCarrierTypeID = ic.InsuranceTypeId,
                            MemberName = mem.DisplayName,
                            MemberRelationship = rel.ShortName
                        };
            return query.ToList();
        }
        #endregion
    }
}
