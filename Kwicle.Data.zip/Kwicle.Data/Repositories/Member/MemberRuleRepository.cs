﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberRuleRepository : BaseRepository<MemberRule>, IMemberRuleRepository
    {
        private readonly KwicleContext _context;

        public MemberRuleRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public async Task<List<MemberRule>> GetMemberRuleById(int sepReasonCodeId)
        {
            try
            {
                return await _context.MemberRules.Where(x => x.SEPReasonCodeID == sepReasonCodeId).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
