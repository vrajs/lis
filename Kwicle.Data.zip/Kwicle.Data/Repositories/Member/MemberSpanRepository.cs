﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberSpanRepository : BaseRepository<MemberSpan>, IMemberSpanRepository
    {
        private readonly KwicleContext _context;
        private readonly IMemberEnrollmentHeaderRepository _memberEnrollmentHeaderRepository;
        public MemberSpanRepository(KwicleContext context, IMemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository) : base(context)
        {
            _context = context;
            _memberEnrollmentHeaderRepository = memberEnrollmentHeaderRepository;
        }

        public async Task<List<MemberSpanListViewModel>> GetMemberSpanByMemberId(int MemberId)
        {
            var query = from ms in _context.MemberSpans
                        join ss in _context.CommonCodes on ms.SpanSourceID equals ss.CommonCodeID into sse
                        from ssa in sse.DefaultIfEmpty()
                        join st in _context.CommonCodes on ms.SpanTypeID equals st.CommonCodeID into ste
                        from sta in ste.DefaultIfEmpty()
                        where ms.MemberID == MemberId && ms.RecordStatus != (int)RecordStatus.Deleted && ms.RecordStatus == (int)RecordStatus.Active

                        select new MemberSpanListViewModel()
                        {
                            MemberSpanID = ms.MemberSpanID,
                            MemberID = ms.MemberID,
                            SpanTypeID = ms.SpanTypeID,
                            SpanType = sta == null ? string.Empty : sta.Code,
                            SpanEffectivedate = ms.SpanEffectivedate,
                            SpanTermDate = ms.SpanTermDate,
                            SpanValue = ms.SpanValue,
                            SpanSourceID = ms.SpanSourceID,
                            SpanSource = ssa == null ? string.Empty : ssa.Code,
                            Comments = ms.Comments,
                            IsFreezed = ms.IsFreezed,
                        };
            return await query.ToListAsync();
        }

        public async Task<MemberSpan> SaveMemberSpan(MemberSpan memberSpan)
        {
            var entity = await _context.Members.Where(x => x.MemberID == memberSpan.MemberID).FirstOrDefaultAsync();
            MemberEnrollmentViewModel memberEnrollment = new MemberEnrollmentViewModel();
            memberEnrollment.MemberID = memberSpan.MemberID;
            memberEnrollment.CreatedBy = memberSpan.CreatedBy;
            memberEnrollment.CreatedDate = memberSpan.CreatedDate;
            await _memberEnrollmentHeaderRepository.UpdateAndInsertMemberSpan(memberEnrollment, memberSpan.SpanTypeID, memberSpan.SpanValue, memberSpan.SpanEffectivedate, entity.MemberSpans,0);

            await _context.SaveChangesAsync();
            return memberSpan;
        }

        public async Task<MemberSpan> UpdateMemberSpan(MemberSpan memberSpan)
        {
            var entity = await _context.Members.Where(x => x.MemberID == memberSpan.MemberID).FirstOrDefaultAsync();
            MemberEnrollmentViewModel memberEnrollment = new MemberEnrollmentViewModel();
            memberEnrollment.MemberID = memberSpan.MemberID;
            memberEnrollment.CreatedBy = memberSpan.CreatedBy;
            memberEnrollment.CreatedDate = memberSpan.CreatedDate;
            memberEnrollment.UpdatedBy = memberSpan.UpdatedBy != null ? memberSpan.UpdatedBy : memberSpan.CreatedBy;
            memberEnrollment.UpdatedDate = memberSpan.UpdatedDate != null ? memberSpan.UpdatedDate : memberSpan.CreatedDate;
            await _memberEnrollmentHeaderRepository.UpdateAndInsertMemberSpan(memberEnrollment, memberSpan.SpanTypeID, memberSpan.SpanValue, memberSpan.SpanEffectivedate, entity.MemberSpans,0);

            await _context.SaveChangesAsync();
            return memberSpan;
        }
    }
}
