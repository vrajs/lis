﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enrollment = Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Repositories.Member
{
    public class PreEnrollmentRepository : BaseRepository<PreEnrollment>, IPreEnrollmentRepository
    {
        private readonly KwicleContext _context;
        public PreEnrollmentRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public int InsertPreEnrollment(PreEnrollment model)
        {
            try
            {
                _context.PreEnrollment.Add(model);
                _context.ChangeTracker.DetectChanges();
                _context.SaveChanges();

                return model.PreEnrollmentId;
            }
            catch (Exception ex)
            {
                DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                return 0;
            }
        }
    }
}
