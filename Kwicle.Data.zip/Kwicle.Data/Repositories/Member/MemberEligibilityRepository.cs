﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberEligibilityRepository : BaseRepository<MemberEligibility>, IMemberEligibilityRepository
    {

        #region Variables
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Ctor
        public MemberEligibilityRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<MemberEligibility> GetAllMemberEligibility()
        {
            try
            {
                var res = _context.MemberEligibilitys.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberEligibility", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberEligibilityViewModel> GetMemberEligibility(string FamilyCode)
        {
            try
            {
                var query = from m in _context.MemberEligibilitys
                            join mem in _context.Members on m.MemberID equals mem.MemberID
                            join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                            join o in _context.Organizations on m.CompanyID equals o.OrganizationID
                            join s in _context.Organizations on m.SubCompanyID equals s.OrganizationID
                            join l in _context.Lobs on m.LOBID equals l.LobID
                            join h in _context.HealthPlans on m.HealthPlanID equals h.HealthPlanID
                            join c in _context.CommonCodes on m.CoverageTypeID equals c.CommonCodeID
                            join r in _context.CommonCodes on m.RiskTypeID equals r.CommonCodeID
                            join pt in _context.Products on l.ProductID equals pt.ProductID
                            join d in _context.CommonCodes on m.DisenrollmentReasonID equals d.CommonCodeID into dm
                            from z in dm.DefaultIfEmpty()
                            where mem.FamilyCode == FamilyCode && m.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new MemberEligibilityViewModel()
                            {
                                MemberEligibilityID = m.MemberEligibilityID,
                                Company = o.OrganizationName,
                                CompanyID = m.CompanyID,
                                SubCompanyID = m.SubCompanyID,
                                SubCompany = s.OrganizationName,
                                LOBID = m.LOBID,
                                Lob = l.LobName,
                                HealthPlanID = h.HealthPlanID,
                                HealthPlan = h.PlanName,
                                CoverageTypeID = c.CommonCodeID,
                                CoverageType = c.ShortName,
                                InsuranceMemberCode = m.InsuranceMemberCode,
                                PolicyNumber = m.PolicyNumber,
                                GroupName = m.GroupName,
                                RiskTypeID = r.CommonCodeID,
                                RiskType = r.ShortName,
                                EffectiveDate = m.EffectiveDate,
                                TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                                DisenrollmentReasonID = m.DisenrollmentReasonID,
                                DisenrollmentReason = z == null ? string.Empty : z.ShortName,
                                MemberCode = mem.MemberCode,
                                RecordStatus = m.RecordStatus,
                                ProductType = pt.ProductName,
                                PBP = h.PBPCode,
                                MemberName = mem.DisplayName,
                                Relationship = rel.ShortName,
                                RelationshipID = mem.RelationshipID,
                                RecordStatusOrder = (m.RecordStatus == 0 ? 1 : m.RecordStatus == 2 ? 2 : m.RecordStatus == 4 ? 3 : m.RecordStatus == 1 ? 4 : 5),
                                MemberID = m.MemberID
                            };
                return query;

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberEligibility", ex.Message);
                return null;
            }
        }


        public MemberEligibilityViewModel GetSelfMemberPrimaryEligibility(int MemberID)
        {
            MemberEligibilityViewModel model = new MemberEligibilityViewModel();
            model = (from m in _context.MemberEligibilitys
                     join mem in _context.Members on m.MemberID equals mem.MemberID
                     join o in _context.Organizations on m.CompanyID equals o.OrganizationID
                     join s in _context.Organizations on m.SubCompanyID equals s.OrganizationID
                     join l in _context.Lobs on m.LOBID equals l.LobID
                     join h in _context.HealthPlans on m.HealthPlanID equals h.HealthPlanID
                     join c in _context.CommonCodes on m.CoverageTypeID equals c.CommonCodeID
                     join r in _context.CommonCodes on m.RiskTypeID equals r.CommonCodeID
                     join pt in _context.Products on l.ProductID equals pt.ProductID
                     join d in _context.CommonCodes on m.DisenrollmentReasonID equals d.CommonCodeID into dm
                     from z in dm.DefaultIfEmpty()
                     where m.MemberID == MemberID && m.CoverageTypeID == (int)CoverageType.Primary && (m.RecordStatus == (int)RecordStatus.Active || m.RecordStatus == (int)RecordStatus.Termed) && mem.RecordStatus == (int)RecordStatus.Active
                     orderby m.RecordStatus
                     select new MemberEligibilityViewModel()
                     {
                         MemberEligibilityID = m.MemberEligibilityID,
                         MemberID = m.MemberID,
                         Company = o.OrganizationName,
                         CompanyID = m.CompanyID,
                         SubCompanyID = m.SubCompanyID,
                         SubCompany = s.OrganizationName,
                         LOBID = m.LOBID,
                         Lob = l.LobName,
                         HealthPlanID = h.HealthPlanID,
                         HealthPlan = h.PlanName,
                         CoverageTypeID = c.CommonCodeID,
                         CoverageType = c.ShortName,
                         InsuranceMemberCode = m.InsuranceMemberCode,
                         PolicyNumber = m.PolicyNumber,
                         GroupName = m.GroupName,
                         RiskTypeID = r.CommonCodeID,
                         RiskType = r.ShortName,
                         EffectiveDate = m.EffectiveDate,
                         TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                         DisenrollmentReasonID = m.DisenrollmentReasonID,
                         DisenrollmentReason = z == null ? string.Empty : z.ShortName,
                         MemberCode = mem.MemberCode,
                         RecordStatus = m.RecordStatus,
                         ProductType = pt.ProductName,
                         PBP = h.PBPCode
                     }).FirstOrDefault();
            return model;
        }


        public MemberEligibilityViewModel GetByID(int MemberEligibilityID)
        {
            MemberEligibilityViewModel model = new MemberEligibilityViewModel();
            model = (from m in _context.MemberEligibilitys
                     join mem in _context.Members on m.MemberID equals mem.MemberID
                     join o in _context.Organizations on m.CompanyID equals o.OrganizationID
                     join s in _context.Organizations on m.SubCompanyID equals s.OrganizationID
                     join l in _context.Lobs on m.LOBID equals l.LobID
                     join h in _context.HealthPlans on m.HealthPlanID equals h.HealthPlanID
                     join c in _context.CommonCodes on m.CoverageTypeID equals c.CommonCodeID
                     join r in _context.CommonCodes on m.RiskTypeID equals r.CommonCodeID
                     join d in _context.CommonCodes on m.DisenrollmentReasonID equals d.CommonCodeID into dm
                     from z in dm.DefaultIfEmpty()
                     where m.MemberEligibilityID == MemberEligibilityID
                     orderby m.CoverageTypeID ascending
                     select new MemberEligibilityViewModel()
                     {
                         MemberEligibilityID = m.MemberEligibilityID,
                         MemberID = m.MemberID,
                         Company = o.OrganizationName,
                         CompanyID = m.CompanyID,
                         SubCompanyID = m.SubCompanyID,
                         SubCompany = s.OrganizationName,
                         LOBID = m.LOBID,
                         Lob = l.LobName,
                         HealthPlanID = h.HealthPlanID,
                         HealthPlan = h.PlanName,
                         CoverageTypeID = c.CommonCodeID,
                         CoverageType = c.ShortName,
                         InsuranceMemberCode = m.InsuranceMemberCode,
                         PolicyNumber = m.PolicyNumber,
                         GroupName = m.GroupName,
                         RiskTypeID = r.CommonCodeID,
                         RiskType = r.ShortName,
                         EffectiveDate = m.EffectiveDate,
                         TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                         DisenrollmentReasonID = m.DisenrollmentReasonID,
                         DisenrollmentReason = z == null ? string.Empty : z.ShortName,
                         MemberCode = mem.MemberCode,
                         RecordStatus = m.RecordStatus
                     }).FirstOrDefault();

            // Get Selected Plan
            if (model != null && model.HealthPlanID > 0)
            {
                model.HealthPlanInfo = _context.GetPlans.Where(e => e.HealthPlanID == model.HealthPlanID).FirstOrDefault();
            }
            return model;
        }

        public int GetTotalEligibilityCount(string FamilyCode)
        {
            int TotalEligibility = 0;
            TotalEligibility = (from e in _context.MemberEligibilitys
                                join m in _context.Members on e.MemberID equals m.MemberID
                                where m.FamilyCode == FamilyCode && e.RecordStatus != (int)RecordStatus.Deleted
                                select e).ToList().Count;
            return TotalEligibility;
        }

        public List<MemberEligibilityViewModel> GetAllMemberActiveEligibility(string FamilyCode)
        {
            List<MemberEligibilityViewModel> items = new List<MemberEligibilityViewModel>();

            //Start Migration 2.1 to 3.1 (Update query with breaking changes of GroupBy in EF 3.1)
            var groupQuery = (from m in _context.MemberEligibilitys
                          join mem in _context.Members on m.MemberID equals mem.MemberID
                          where mem.FamilyCode == FamilyCode && m.RecordStatus == (int)RecordStatus.Active && mem.RecordStatus == (int)RecordStatus.Active
                          group new { mem, m }
                          by new
                          {
                              mem.RelationshipID,m.RecordStatus,m.CompanyID,m.SubCompanyID,
                              m.LOBID,m.HealthPlanID,m.CoverageTypeID,m.RiskTypeID,
                              m.DisenrollmentReasonID,m.MemberEligibilityID,m.InsuranceMemberCode,
                              m.PolicyNumber,m.GroupName,m.EffectiveDate,m.TermDate,
                              mem.MemberCode,mem.DisplayName
                          } into tg
                          select new
                          {
                              tg.Key.RelationshipID,tg.Key.RecordStatus,tg.Key.CompanyID,
                              tg.Key.SubCompanyID,tg.Key.LOBID,tg.Key.HealthPlanID,
                              tg.Key.CoverageTypeID,tg.Key.RiskTypeID,tg.Key.DisenrollmentReasonID,
                              tg.Key.MemberEligibilityID,tg.Key.InsuranceMemberCode,tg.Key.PolicyNumber,
                              tg.Key.GroupName,tg.Key.EffectiveDate,tg.Key.TermDate,
                              tg.Key.MemberCode,tg.Key.DisplayName
                          }).OrderBy(x => x.CoverageTypeID).Take(1);
            
            var groupQueryResult = groupQuery.ToList();
            
            var joinWithGroupQueryRes = (from gResult in groupQueryResult
                         join rel in _context.CommonCodes on gResult.RelationshipID equals rel.CommonCodeID
                         join o in _context.Organizations on gResult.CompanyID equals o.OrganizationID
                         join s in _context.Organizations on gResult.SubCompanyID equals s.OrganizationID
                         join l in _context.Lobs on gResult.LOBID equals l.LobID
                         join h in _context.HealthPlans on gResult.HealthPlanID equals h.HealthPlanID
                         join c in _context.CommonCodes on gResult.CoverageTypeID equals c.CommonCodeID
                         join r in _context.CommonCodes on gResult.RiskTypeID equals r.CommonCodeID
                         join pt in _context.Products on l.ProductID equals pt.ProductID
                         join d in _context.CommonCodes on gResult.DisenrollmentReasonID equals d.CommonCodeID into dm
                         from z in dm.DefaultIfEmpty()
                         select new MemberEligibilityViewModel()
                         {
                             MemberEligibilityID = gResult.MemberEligibilityID,
                             Company = o.OrganizationName,
                             CompanyID = gResult.CompanyID,
                             SubCompanyID = gResult.SubCompanyID,
                             SubCompany = s.OrganizationName,
                             LOBID = gResult.LOBID,
                             Lob = l.LobName,
                             HealthPlanID = h.HealthPlanID,
                             HealthPlan = h.PlanName,
                             CoverageTypeID = c.CommonCodeID,
                             CoverageType = c.ShortName,
                             InsuranceMemberCode = gResult.InsuranceMemberCode,
                             PolicyNumber = gResult.PolicyNumber,
                             GroupName = gResult.GroupName,
                             RiskTypeID = r.CommonCodeID,
                             RiskType = r.ShortName,
                             EffectiveDate = gResult.EffectiveDate,
                             TermDate = (gResult.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : gResult.TermDate,
                             DisenrollmentReasonID = gResult.DisenrollmentReasonID,
                             DisenrollmentReason = z == null ? string.Empty : z.ShortName,
                             MemberCode = gResult.MemberCode,
                             RecordStatus = gResult.RecordStatus,
                             ProductType = pt.ProductName,
                             PBP = h.PBPCode,
                             MemberName = gResult.DisplayName,
                             Relationship = rel.ShortName,
                             RelationshipID = gResult.RelationshipID
                         }).OrderBy(l => l.RelationshipID == (int)MemberRelationship.Self ? 0 : 1);

             items = joinWithGroupQueryRes.ToList();

             return items;

            //var query = (from m in _context.MemberEligibilitys
            //             join mem in _context.Members on m.MemberID equals mem.MemberID
            //             where mem.FamilyCode == FamilyCode && m.RecordStatus == (int)RecordStatus.Active && mem.RecordStatus == (int)RecordStatus.Active
            //             group new { mem, m } by new { mem.RelationshipID, m.RecordStatus } into tg
            //             from x in tg.OrderBy(o => o.m.CoverageTypeID).Take(1)
            //             join rel in _context.CommonCodes on x.mem.RelationshipID equals rel.CommonCodeID
            //             join o in _context.Organizations on x.m.CompanyID equals o.OrganizationID
            //             join s in _context.Organizations on x.m.SubCompanyID equals s.OrganizationID
            //             join l in _context.Lobs on x.m.LOBID equals l.LobID
            //             join h in _context.HealthPlans on x.m.HealthPlanID equals h.HealthPlanID
            //             join c in _context.CommonCodes on x.m.CoverageTypeID equals c.CommonCodeID
            //             join r in _context.CommonCodes on x.m.RiskTypeID equals r.CommonCodeID
            //             join pt in _context.Products on l.ProductID equals pt.ProductID
            //             join d in _context.CommonCodes on x.m.DisenrollmentReasonID equals d.CommonCodeID into dm
            //             from z in dm.DefaultIfEmpty()
            //             select new MemberEligibilityViewModel()
            //             {
            //                 MemberEligibilityID = x.m.MemberEligibilityID,
            //                 Company = o.OrganizationName,
            //                 CompanyID = x.m.CompanyID,
            //                 SubCompanyID = x.m.SubCompanyID,
            //                 SubCompany = s.OrganizationName,
            //                 LOBID = x.m.LOBID,
            //                 Lob = l.LobName,
            //                 HealthPlanID = h.HealthPlanID,
            //                 HealthPlan = h.PlanName,
            //                 CoverageTypeID = c.CommonCodeID,
            //                 CoverageType = c.ShortName,
            //                 InsuranceMemberCode = x.m.InsuranceMemberCode,
            //                 PolicyNumber = x.m.PolicyNumber,
            //                 GroupName = x.m.GroupName,
            //                 RiskTypeID = r.CommonCodeID,
            //                 RiskType = r.ShortName,
            //                 EffectiveDate = x.m.EffectiveDate,
            //                 TermDate = (x.m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : x.m.TermDate,
            //                 DisenrollmentReasonID = x.m.DisenrollmentReasonID,
            //                 DisenrollmentReason = z == null ? string.Empty : z.ShortName,
            //                 MemberCode = x.mem.MemberCode,
            //                 RecordStatus = x.m.RecordStatus,
            //                 ProductType = pt.ProductName,
            //                 PBP = h.PBPCode,
            //                 MemberName = x.mem.DisplayName,
            //                 Relationship = rel.ShortName,
            //                 RelationshipID = x.mem.RelationshipID
            //             }).OrderBy(l => l.RelationshipID == (int)MemberRelationship.Self ? 0 : 1);
            //items = query.ToList();
            //return items;
            //End Migration 2.1 to 3.1 (Update query with breaking changes of GroupBy in EF 3.1)
        }

        public MemberEligibility GetMostRecentEligibility(int MemberID)
        {
            var query = (from mem_ele in _context.MemberEligibilitys
                         where mem_ele.MemberID == MemberID && mem_ele.RecordStatus != 3
                         orderby ((mem_ele.RecordStatus == (byte)RecordStatus.Active) ? 0 : (mem_ele.RecordStatus == (byte)RecordStatus.Pend || mem_ele.RecordStatus == (byte)RecordStatus.InActive || mem_ele.RecordStatus == (byte)RecordStatus.Cancel || mem_ele.RecordStatus == (byte)RecordStatus.VoidOrInvalid) ? 1 : 2), mem_ele.CoverageTypeID
                         select mem_ele);

            return query.FirstOrDefault();
        }
        #endregion
    }
}
