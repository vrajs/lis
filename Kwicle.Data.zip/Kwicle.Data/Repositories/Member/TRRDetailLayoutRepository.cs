﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Member
{
    public class TRRDetailLayoutRepository : BaseRepository<TRRDetailLayout>, ITRRDetailLayoutRepository
    {
        private readonly KwicleContext _context;
        public TRRDetailLayoutRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public async Task<List<VwTRRDetailLayoutList>> GetTRRDetailLayoutByMemberId(int MemberId)
        {
            var TRRDetails = await _context.VwTRRDetailLayoutList.Where(x => x.MemberID == MemberId).ToListAsync();

            TRRDetails.ForEach(x =>
            {
                x.TransactionCode = x.TransactionCode + " - " + x.TransactionCodeName;
                x.TransStatus = TransactionStatus.Any(t => t.Key == x.TransStatus) ? TransactionStatus.FirstOrDefault(t => t.Key == x.TransStatus).Value : x.TransStatus;
            }
            );
            return TRRDetails;
        }

        public List<KeyValuePair<string, string>> TransactionStatus = new List<KeyValuePair<string, string>>()
        {
            new KeyValuePair<string, string>("A","Accepted"),
            new KeyValuePair<string, string>("R","Rejected"),
            new KeyValuePair<string, string>("I","Informational"),
            new KeyValuePair<string, string>("M","Maintenance"),
            new KeyValuePair<string, string>("F","Failed")          
        };
        
    }    
}
