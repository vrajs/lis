﻿using DocumentFormat.OpenXml.Packaging;
using FastMember;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Org.BouncyCastle.Crypto;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberTransactionRepository : BaseRepository<MemberTransactionDetail>, IMemberTransactionRepository
    {
        private readonly KwicleContext _context;
        private readonly IMemberEnrollmentHeaderRepository _memberEnrollmentHeaderRepository;

        public MemberTransactionRepository(KwicleContext context, IMemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository) : base(context)
        {
            _context = context;
            _memberEnrollmentHeaderRepository = memberEnrollmentHeaderRepository;
        }
        public async Task<List<LetterCorrespondanceViewModel>> GetAllLetterCorrespondance()
        {
            try
            {
                var data = from lc in _context.LetterCorrespondance
                           join cl in _context.CommonList on lc.LetterTypeId equals cl.NumericValue
                           join m in _context.Members on lc.MemberId equals m.MemberID
                           select new LetterCorrespondanceViewModel
                           {
                               LetterGenerationDate = lc.LetterGenerationDate,
                               CreatedDate = lc.CreatedDate,
                               LetterMailDate = lc.LetterMailDate,
                               ResponseDueDate = lc.ResponseDueDate,
                               UpdatedDate = lc.UpdatedDate,
                               UpdatedBy = lc.UpdatedBy,
                               CreatedBy = lc.CreatedBy,
                               LetterTypeName = cl.ListValue,
                               LetterTypeId = lc.LetterTypeId,
                               LetterCorrespondanceId = lc.LetterCorrespondanceId,
                               MemberId = lc.MemberId,
                               Source = lc.Source,
                               MBI = m.MedicareNumber,
                               FolderName = lc.FolderName
                           };

                return data.ToList();
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<int> AddTransaction(MemberTransactionDetail model, MemberTransactionDetailViewModel mainModel, PlaceHolderReplaceViewModel placeHolderReplaceViewModel)
        {
            try
            {
                if (model.TransactionTypeID == TransactionType.Enrollment)
                {
                    var letterCorrespondance = new LetterCorrespondance();
                    letterCorrespondance.Source = SourceDetails.TransactionDetail;
                    letterCorrespondance.LetterTypeId = LetterType.EnrollmentAcknowledgement;
                    letterCorrespondance.MemberId = model.MemberID;
                    letterCorrespondance.CreatedDate = DateTime.Now;
                    letterCorrespondance.CreatedBy = mainModel.CreatedBy;
                    letterCorrespondance.LetterGenerationDate = DateTime.Now;
                    letterCorrespondance.FolderName = mainModel.FolderName;
                    //await _context.LetterCorrespondance.AddAsync(letterCorrespondance);

                    if (model.PendReasonID == PendReason.InComplete)
                    {
                        var letterCorrespondancePend = new LetterCorrespondance();
                        letterCorrespondancePend.Source = SourceDetails.TransactionDetail;
                        letterCorrespondancePend.MemberId = model.MemberID;
                        letterCorrespondancePend.CreatedDate = DateTime.Now;
                        letterCorrespondancePend.CreatedBy = mainModel.CreatedBy;
                        letterCorrespondancePend.LetterGenerationDate = DateTime.Now;
                        letterCorrespondancePend.LetterTypeId = LetterType.EnrollmentRequestForInfo;
                        letterCorrespondance.FolderName = mainModel.FolderName;
                        await _context.LetterCorrespondance.AddRangeAsync(letterCorrespondance, letterCorrespondancePend);
                    }
                    else
                    {
                        await _context.LetterCorrespondance.AddAsync(letterCorrespondance);
                    }
                    if (model.IsDenialFlag == true)
                    {
                        var letterCorrespondanceDenial = new LetterCorrespondance();
                        letterCorrespondanceDenial.Source = SourceDetails.TransactionDetail;
                        letterCorrespondanceDenial.MemberId = model.MemberID;
                        letterCorrespondanceDenial.CreatedDate = DateTime.Now;
                        letterCorrespondanceDenial.CreatedBy = mainModel.CreatedBy;
                        letterCorrespondanceDenial.LetterGenerationDate = DateTime.Now;
                        letterCorrespondanceDenial.LetterTypeId = LetterType.EnrollmentDenialLetter;
                        letterCorrespondance.FolderName = mainModel.FolderName;
                        await _context.LetterCorrespondance.AddAsync(letterCorrespondanceDenial);
                    }
                }
                if (model.TransactionTypeID == TransactionType.Disenrollment)
                {
                    var letterCorrespondance = new LetterCorrespondance();
                    letterCorrespondance.Source = SourceDetails.TransactionDetail;
                    letterCorrespondance.LetterTypeId = LetterType.DisenrollmentAcknowledgement;
                    letterCorrespondance.MemberId = model.MemberID;
                    letterCorrespondance.CreatedDate = DateTime.Now;
                    letterCorrespondance.CreatedBy = mainModel.CreatedBy;
                    letterCorrespondance.LetterGenerationDate = DateTime.Now;
                    letterCorrespondance.FolderName = mainModel.FolderName;
                    //await _context.LetterCorrespondance.AddAsync(letterCorrespondance);

                    if (model.PendReasonID == PendReason.InComplete)
                    {
                        var letterCorrespondancePend = new LetterCorrespondance();
                        letterCorrespondancePend.Source = SourceDetails.TransactionDetail;
                        letterCorrespondancePend.MemberId = model.MemberID;
                        letterCorrespondancePend.CreatedDate = DateTime.Now;
                        letterCorrespondancePend.CreatedBy = mainModel.CreatedBy;
                        letterCorrespondancePend.LetterGenerationDate = DateTime.Now;
                        letterCorrespondancePend.LetterTypeId = LetterType.DisenrollmentRequestForInformation;
                        letterCorrespondance.FolderName = mainModel.FolderName;
                        await _context.LetterCorrespondance.AddRangeAsync(letterCorrespondance, letterCorrespondancePend);
                    }
                    else
                    {
                        await _context.LetterCorrespondance.AddAsync(letterCorrespondance);
                    }
                    if (model.IsDenialFlag == true)
                    {
                        var letterCorrespondanceDenial = new LetterCorrespondance();
                        letterCorrespondanceDenial.Source = SourceDetails.TransactionDetail;
                        letterCorrespondanceDenial.MemberId = model.MemberID;
                        letterCorrespondanceDenial.CreatedDate = DateTime.Now;
                        letterCorrespondanceDenial.CreatedBy = mainModel.CreatedBy;
                        letterCorrespondanceDenial.LetterGenerationDate = DateTime.Now;
                        letterCorrespondanceDenial.LetterTypeId = LetterType.DisenrollmentDenialLetter;
                        letterCorrespondance.FolderName = mainModel.FolderName;
                        await _context.LetterCorrespondance.AddAsync(letterCorrespondanceDenial);
                    }
                }
                await _context.MemberTransactionDetails.AddAsync(model);

                var entity = await _context.Members.Where(x => x.MemberID == model.MemberID).FirstOrDefaultAsync();
                var memberDetails = entity;
                memberDetails.ApplicationStatusID = model.TransactionStatusID;
                memberDetails.ContractID = model.ContractID;
                memberDetails.PBPID = model.PBPID;
                memberDetails.MemberStatusID = mainModel.MemberStatusId ?? 0;

                await UpdateAndInsertMemberTransactionSpans(model, mainModel, entity.MemberSpans);
                _context.Entry(entity).CurrentValues.SetValues(memberDetails);

                await _context.SaveChangesAsync();

                return model.MemberTransactionDetailID;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<int> UpdateTransaction(MemberTransactionDetail model, MemberTransactionDetailViewModel mainModel, PlaceHolderReplaceViewModel placeHolderReplaceViewModel)
        {
            if (model.TransactionTypeID == TransactionType.Enrollment)
            {
                var checkPendRecord = _context.LetterCorrespondance.Where(x => x.MemberId == model.MemberID && x.Source == SourceDetails.TransactionDetail && x.LetterTypeId == LetterType.EnrollmentRequestForInfo);
                if (model.PendReasonID == PendReason.InComplete && checkPendRecord.Count() == 0)
                {
                    var letterCorrespondancePend = new LetterCorrespondance();
                    letterCorrespondancePend.Source = SourceDetails.TransactionDetail;
                    letterCorrespondancePend.MemberId = model.MemberID;
                    letterCorrespondancePend.CreatedDate = DateTime.Now;
                    letterCorrespondancePend.CreatedBy = model.CreatedBy;
                    letterCorrespondancePend.LetterGenerationDate = DateTime.Now;
                    letterCorrespondancePend.LetterTypeId = LetterType.EnrollmentRequestForInfo;
                    await _context.LetterCorrespondance.AddAsync(letterCorrespondancePend);
                }
                var checkDenialRecord = _context.LetterCorrespondance.Where(x => x.MemberId == model.MemberID && x.Source == SourceDetails.TransactionDetail && x.LetterTypeId == LetterType.EnrollmentDenialLetter);
                if (model.IsDenialFlag == true && checkDenialRecord.Count() == 0)
                {
                    var letterCorrespondanceDenial = new LetterCorrespondance();
                    letterCorrespondanceDenial.Source = SourceDetails.TransactionDetail;
                    letterCorrespondanceDenial.MemberId = model.MemberID;
                    letterCorrespondanceDenial.CreatedDate = DateTime.Now;
                    letterCorrespondanceDenial.CreatedBy = model.CreatedBy;
                    letterCorrespondanceDenial.LetterGenerationDate = DateTime.Now;
                    letterCorrespondanceDenial.LetterTypeId = LetterType.EnrollmentDenialLetter;
                    await _context.LetterCorrespondance.AddAsync(letterCorrespondanceDenial);
                }
            }
            if (model.TransactionTypeID == TransactionType.Disenrollment)
            {
                var checkPendRecord = _context.LetterCorrespondance.Where(x => x.MemberId == model.MemberID && x.Source == SourceDetails.TransactionDetail && x.LetterTypeId == LetterType.DisenrollmentRequestForInformation);
                if (model.PendReasonID == PendReason.InComplete && checkPendRecord.Count() == 0)
                {
                    var letterCorrespondancePend = new LetterCorrespondance();
                    letterCorrespondancePend.Source = SourceDetails.TransactionDetail;
                    letterCorrespondancePend.MemberId = model.MemberID;
                    letterCorrespondancePend.CreatedDate = DateTime.Now;
                    letterCorrespondancePend.CreatedBy = model.CreatedBy;
                    letterCorrespondancePend.LetterGenerationDate = DateTime.Now;
                    letterCorrespondancePend.LetterTypeId = LetterType.DisenrollmentRequestForInformation;
                    await _context.LetterCorrespondance.AddAsync(letterCorrespondancePend);
                }
                var checkDenialRecord = _context.LetterCorrespondance.Where(x => x.MemberId == model.MemberID && x.Source == SourceDetails.TransactionDetail && x.LetterTypeId == LetterType.DisenrollmentDenialLetter);
                if (model.IsDenialFlag == true && checkDenialRecord.Count() == 0)
                {
                    var letterCorrespondanceDenial = new LetterCorrespondance();
                    letterCorrespondanceDenial.Source = SourceDetails.TransactionDetail;
                    letterCorrespondanceDenial.MemberId = model.MemberID;
                    letterCorrespondanceDenial.CreatedDate = DateTime.Now;
                    letterCorrespondanceDenial.CreatedBy = model.CreatedBy;
                    letterCorrespondanceDenial.LetterGenerationDate = DateTime.Now;
                    letterCorrespondanceDenial.LetterTypeId = LetterType.DisenrollmentDenialLetter;
                    await _context.LetterCorrespondance.AddAsync(letterCorrespondanceDenial);
                }
            }
            MemberTransactionDetail entityTransaction = await _context.MemberTransactionDetails.Where(x => x.MemberTransactionDetailID == model.MemberTransactionDetailID && x.MemberID == model.MemberID).FirstOrDefaultAsync();
            if (entityTransaction != null)
            {
                model.CreatedBy = entityTransaction.CreatedBy;
                model.CreatedDate = entityTransaction.CreatedDate;
                //DbSet.Attach(model);
                //_context.Entry(model).State = EntityState.Modified;
                string[] PropertiesToExclude = { "DenialReason", "DisEnrollmentReasonCode", "ElectionType", "IncompleteReason", "PendReason", "PremiumWithholdOption", "TransactionType", "TransactionStatus", "Member", "PBP", "Contract", "SepReasonCode", "TRRDetailLayouts" };
                MemberEnrollmentHeaderRepository memberEnrollmentHeaderRepository = new MemberEnrollmentHeaderRepository(_context);
                memberEnrollmentHeaderRepository.CompareObjects(mainModel.MBI, model.UpdatedBy, model.MemberID, entityTransaction, model, PropertiesToExclude);
                _context.Entry(entityTransaction).CurrentValues.SetValues(model);

                var entity = await _context.Members.Where(x => x.MemberID == model.MemberID).FirstOrDefaultAsync();
                var memberDetails = entity;
                memberDetails.ApplicationStatusID = model.TransactionStatusID;
                memberDetails.ContractID = model.ContractID;
                memberDetails.PBPID = model.PBPID;
                memberDetails.MemberStatusID = mainModel.MemberStatusId ?? 0;

                await UpdateAndInsertMemberTransactionSpans(entityTransaction, mainModel, entity.MemberSpans);

                _context.Entry(entity).CurrentValues.SetValues(memberDetails);
            }
            await _context.SaveChangesAsync();
            return model.MemberTransactionDetailID;
        }

        private async Task UpdateAndInsertMemberTransactionSpans(MemberTransactionDetail model, MemberTransactionDetailViewModel mainModel, ICollection<MemberSpan> memberSpans)
        {
            MemberEnrollmentViewModel memberEnrollment = new MemberEnrollmentViewModel();
            memberEnrollment.MemberID = model.MemberID;
            memberEnrollment.CreatedBy = model.CreatedBy;
            memberEnrollment.CreatedDate = model.CreatedDate;
            memberEnrollment.UpdatedBy = model.UpdatedBy != null ? model.UpdatedBy : model.CreatedBy;
            memberEnrollment.UpdatedDate = model.UpdatedDate != null ? model.UpdatedDate : model.CreatedDate;
            await _memberEnrollmentHeaderRepository.UpdateAndInsertMemberSpan(memberEnrollment, (int)SpanType.PBP, mainModel.PBPName, model.EffectiveDate, memberSpans, 1);
            await _memberEnrollmentHeaderRepository.UpdateAndInsertMemberSpan(memberEnrollment, (int)SpanType.PremiumPayment, mainModel.PremiumWithholdOptionName, model.EffectiveDate, memberSpans, 1);
        }

        public async Task<List<MemberTransactionViewModel>> GetTransactionByMemberId(int MemberId)
        {
            var query = from mt in _context.MemberTransactionDetails
                        join et in _context.CommonCodes on mt.ElectionTypeID equals et.CommonCodeID into ete
                        from eta in ete.DefaultIfEmpty()
                        join tt in _context.CommonCodes on mt.TransactionTypeID equals tt.CommonCodeID into tte
                        from tta in tte.DefaultIfEmpty()
                        join ts in _context.CommonCodes on mt.TransactionStatusID equals ts.CommonCodeID into tse
                        from tsa in tse.DefaultIfEmpty()
                        join pb in _context.CommonCodes on mt.PBPID equals pb.CommonCodeID into pbe
                        from pba in pbe.DefaultIfEmpty()
                        join cc in _context.CommonCodes on mt.ContractID equals cc.CommonCodeID into dm
                        from z in dm.DefaultIfEmpty()
                        where mt.MemberID == MemberId && mt.RecordStatus != (int)RecordStatus.Deleted && mt.RecordStatus == (int)RecordStatus.Active

                        select new MemberTransactionViewModel()
                        {
                            MemberTransactionDetailID = mt.MemberTransactionDetailID,
                            TransactionTypeID = mt.TransactionTypeID,
                            TransactionTypeName = tta == null ? string.Empty : tta.Code + " - " + tta.ShortName,
                            TransactionStatusID = mt.TransactionStatusID,
                            TransactionStatusName = tsa == null ? string.Empty : tsa.Code,
                            ContractID = mt.ContractID,
                            ContractName = z == null ? string.Empty : z.Code,
                            PBPID = mt.PBPID,
                            PBPName = pba == null ? string.Empty : pba.Code + " - " + pba.ShortName,
                            EffectiveDate = mt.EffectiveDate,
                            TermDate = mt.TermDate,
                            ElectionTypeID = mt.ElectionTypeID,
                            ElectionTypeName = eta == null ? string.Empty : eta.ShortName,
                            MemberID = mt.MemberID,

                        };
            return await query.ToListAsync();
        }

        public async Task<List<MemberCorrespondanceViewModel>> GetCorrespondanceByMemberId(int memberId)
        {
            var query = from lc in _context.LetterCorrespondance
                        join cl in _context.CommonList on lc.LetterTypeId equals cl.NumericValue
                        where lc.MemberId == memberId && lc.Source == SourceDetails.TransactionDetail && cl.CharValue == "Enrollment"

                        select new MemberCorrespondanceViewModel()
                        {
                            LetterType = cl.ListValue,
                            LetterCorrespondanceId = lc.LetterCorrespondanceId,
                            LetterTypeId = lc.LetterTypeId,
                            Source = lc.Source,
                            CreatedBy = lc.CreatedBy,
                            CreatedDate = lc.CreatedDate,
                            LetterGenerationDate = lc.LetterGenerationDate,
                            LetterMailDate = lc.LetterMailDate,
                            ResponseDueDate = lc.ResponseDueDate,
                            UpdatedBy = lc.UpdatedBy,
                            UpdatedDate = lc.UpdatedDate,
                            FolderName = lc.FolderName
                        };
            return await query.ToListAsync();

        }
    }
}
