﻿using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Member
{
    public class OECLayoutRepository : BaseRepository<OECLayout>, IOECLayoutRepository
    {
        private readonly KwicleContext _context;
        public OECLayoutRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #region Interface Methods Implementation   
        public IEnumerable<OECLayout> GetAllOECLayoutByDataFileToProcessDetailsID(int DataFileToProcessDetailsID)
        {
            try
            {
                var res = _context.OECLayout.Where(x => x.DataFileToProcessDetailsID == DataFileToProcessDetailsID).ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotFoundGetAllOECLayoutByDataFileToProcessDetailsID", ex.Message);
                return null;
            }
        }

        #endregion
    }
}
