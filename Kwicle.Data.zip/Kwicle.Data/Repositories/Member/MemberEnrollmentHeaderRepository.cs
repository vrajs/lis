﻿using FastMember;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Member;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using Enrollment = Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberEnrollmentHeaderRepository : BaseRepository<MemberEnrollmentHeader>, IMemberEnrollmentHeaderRepository
    {
        private readonly KwicleContext _context;

        public MemberEnrollmentHeaderRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public async Task<MemberEnrollmentHeader> GetPreEnrollmentHeaderByMBI(MemberEnrollmentHeader model)
        {
            //return await _context.MemberEnrollmentHeader.
            //    Include(x => x.MemberEnrollmentHeaderAttachment).
            //        Where(x => (x.MBI == model.MBI && x.DOB.Equals(model.DOB) ? true : false) && (model.GenderID == null ? true : x.GenderID == model.GenderID) && x.RecordStatus == (int)RecordStatus.Active).FirstOrDefaultAsync();

            return await _context.MemberEnrollmentHeader.
                Include(x => x.MemberEnrollmentHeaderAttachment).
                    Where(x => x.MBI == model.MBI && x.RecordStatus == (int)RecordStatus.Active).FirstOrDefaultAsync();
        }
        public async Task<List<AuditHistory>> GetMemberAuditHistory(int memberId)
        {
            var data = new List<AuditHistory>();
            var idData = new List<AuditHistory>();

            data = _context.AuditHistorys.Where(x => x.MemberId == memberId && x.ModifiedField != "UpdatedDate" && x.ModifiedField != "DisplayName" && x.ModifiedField != "NoteDate" && x.ModifiedField != "TermDate" && x.ModifiedField.Substring(x.ModifiedField.Length - 2).ToLower() != "id").ToList();

            try
            {
                idData = (from ah in _context.AuditHistorys
                          join ca in _context.CommonCodes on ah.AfterValue equals ca.CommonCodeID.ToString()
                          join cb in _context.CommonCodes on ah.BeforeValue equals cb.CommonCodeID.ToString()
                          where ah.MemberId == memberId
                          select new AuditHistory()
                          {
                              AuditHistoryId = ah.AuditHistoryId,
                              ModifiedField = ah.ModifiedField,
                              BeforeValue = cb.LongDescription,
                              AfterValue = ca.LongDescription,
                              ModifiedBy = ah.ModifiedBy,
                              ModifiedDate = ah.ModifiedDate,
                              Source = ah.Source,
                              MemberId = ah.MemberId,
                              MBI = ah.MBI
                          }).ToList();
                idData = idData.Where(row => row.ModifiedField.EndsWith("id", StringComparison.OrdinalIgnoreCase)).ToList();
            }
            catch (Exception e)
            {

                throw;
            }

            return data.Concat(idData).ToList();
        }
        public async Task<List<AuditHistory>> GetAuditHistory(AuditHistoryFilterModel auditHistoryFilterModel)
        {
            var data = new List<AuditHistory>();
            var idData = new List<AuditHistory>();

            data = _context.AuditHistorys.Where(x => x.ModifiedField != "UpdatedDate" && x.ModifiedField != "DisplayName" && x.ModifiedField != "NoteDate" && x.ModifiedField != "TermDate" && x.ModifiedField.Substring(x.ModifiedField.Length - 2).ToLower() != "id").ToList();

            try
            {
                idData = (from ah in _context.AuditHistorys
                          join ca in _context.CommonCodes on ah.AfterValue equals ca.CommonCodeID.ToString()
                          join cb in _context.CommonCodes on ah.BeforeValue equals cb.CommonCodeID.ToString()
                          select new AuditHistory()
                          {
                              AuditHistoryId = ah.AuditHistoryId,
                              ModifiedField = ah.ModifiedField,
                              BeforeValue = cb.LongDescription,
                              AfterValue = ca.LongDescription,
                              ModifiedBy = ah.ModifiedBy,
                              ModifiedDate = ah.ModifiedDate,
                              Source = ah.Source,
                              MemberId = ah.MemberId,
                              MBI = ah.MBI
                          }).ToList();
                idData = idData.Where(row => row.ModifiedField.EndsWith("id", StringComparison.OrdinalIgnoreCase)).ToList();
            }
            catch (Exception e)
            {
                throw;
            }
            data = data.Concat(idData).ToList();

            if (auditHistoryFilterModel.ModifiedField != null)
                data = data.Where(item => item.ModifiedField == auditHistoryFilterModel.ModifiedField).ToList();
            if (auditHistoryFilterModel.MemberId != null)
                data = data.Where(item => item.MemberId == auditHistoryFilterModel.MemberId).ToList();
            if (auditHistoryFilterModel.FromDate != null)
                data = data.Where(item => item.ModifiedDate >= auditHistoryFilterModel.FromDate).ToList();
            if (auditHistoryFilterModel.ToDate != null)
                data = data.Where(item => item.ModifiedDate <= auditHistoryFilterModel.ToDate).ToList();
            if (auditHistoryFilterModel.MBI != null && auditHistoryFilterModel.MBI != "")
                data = data.Where(item => item.MBI == auditHistoryFilterModel.MBI).ToList();
            return data;

        }

        public async Task<string> GetNextSequenceNumber(string SettingCode, int Padding)
        {
            string NextID = string.Empty;
            SeqNumber trackingId = _context.SeqNumbers.Where(e => e.SettingCode == SettingCode).FirstOrDefault();
            if (trackingId != null)
            {
                trackingId.LastSeqNumber = Convert.ToString((Convert.ToInt32(trackingId.LastSeqNumber) + 1).ToString().PadLeft(Padding, '0'));
                _context.Entry(trackingId).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                NextID = trackingId.PreFix + trackingId.LastSeqNumber.ToString();
            }
            return NextID;
        }

        public async Task<MemberEnrollmentListViewModel> GetMemberEnrollmentHeader(MemberEnrollmentSearchModel searchModel)
        {
            try
            {
                MemberEnrollmentListViewModel memberEnrollmentListViewModel = new MemberEnrollmentListViewModel();
                var parameters = new SqlParameter[]
            {
                    new SqlParameter("@TrackingID", searchModel.TrackingID),
                    new SqlParameter("@MBI", searchModel.MBI),
                    new SqlParameter("@FirstName", searchModel.FirstName),
                    new SqlParameter("@LastName", searchModel.LastName),
                    new SqlParameter("@MemberID", searchModel.MemberID),
                    new SqlParameter("@ClientMemberId", searchModel.ClientMemberId),
                    new SqlParameter("@ApplicationStatusID", searchModel.ApplicationStatusID),
                    new SqlParameter("@MemberStatusID", searchModel.MemberStatusID),
                    new SqlParameter("@PBPID", searchModel.PBPID),
                    new SqlParameter("@ContractID", searchModel.ContractID),
                    new SqlParameter("@skip", searchModel.skip),
                    new SqlParameter("@take", searchModel.take),
                    new SqlParameter("@TotalCount", 0),
             };
                parameters[12].Direction = ParameterDirection.Output;
                memberEnrollmentListViewModel.MemberEnrollmentList = _context.ExecuteStoreProcedure<EnrollmentListModel>("[hps].[usp_MemberEnrollmentList]", parameters);
                memberEnrollmentListViewModel.TotalCount = (int)(long)parameters[12].Value;
                return memberEnrollmentListViewModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> InsertEnrollmentHeader(MemberEnrollmentViewModel model)
        {
            //using (var dbTransaction = _context.Database.BeginTransaction())
            //{
            try
            {
                var entity = await _context.Members.Where(x => x.MedicareNumber == model.MBI).FirstOrDefaultAsync();

                if (entity == null)
                {
                    MemberSpan memberSpan = new MemberSpan();
                    memberSpan.MemberSpanID = 0;
                    memberSpan.MemberID = model.MemberID;
                    memberSpan.SpanEffectivedate = model.CreatedDate;
                    memberSpan.SpanTermDate = null;
                    memberSpan.CreatedBy = model.CreatedBy;
                    memberSpan.CreatedDate = model.CreatedDate;
                    memberSpan.RecordStatus = (int)RecordStatus.Active;
                    memberSpan.RecordStatusChangeComment = RecordStatus.Active.ToString();
                    // Retriving dynamic tracking and member Id's
                    model.TrackingID = GetNextSequenceNumber("EnrollTrackingId", 10).Result;
                    model.MemberCode = GetNextSequenceNumber("EnrollMemberId", 9).Result;

                    // Mapping member enrollment data to Member Model
                    Enrollment.Member memberDetails = new Enrollment.Member();
                    memberDetails = MemberEnrollmentDataMapper(model);
                    memberDetails.MemberCMSDetails.Add(MemberCMSDetailDataMapper(model));
                    memberDetails.MemberContacts.Add(MemberContactDataMapper(model, ContactType.Other));
                    memberDetails.MemberContacts.Add(MemberContactDataMapper(model, ContactType.Mailing));
                    memberDetails.MemberContacts.Add(MemberContactDataMapper(model, ContactType.Emergency));
                    memberDetails.MemberEligibilitys.Add(MemberEligibilityDataMapper(model));
                    memberDetails.MemberEnrollmentDetails.Add(MemberEnrollmentDetailDataMapper(model));
                    memberDetails.MemberNotes.Add(MemberNoteDataMapper(model));
                    memberDetails.MemberOtherCoverages.Add(MemberOtherCoverageDataMapper(model));
                    memberDetails.MemberPremiumDetails.Add(MemberPremiumDetailDataMapper(model));
                    memberDetails.CreatedBy = model.CreatedBy == null ? "" : model.CreatedBy;
                    if (model.PCPID > 0)
                    {
                        memberDetails.MemberPCPs.Add(MemberPCPDataMapper(model));
                    }
                    if (model.MemberTransactionList != null)
                    {
                        if (model.MemberTransactionList.Count == 1)
                        {
                            memberDetails.MemberTransactionDetails.Add(MemberTransactionDetailDataMapper(model));
                            memberDetails.MemberSpans.Add(MemberSpanDataMapper(0, (int)SpanType.PBP, model.MemberTransactionList[0].PBPName, model, model.MemberTransactionList[0].EffectiveDate, null, 1));
                            memberDetails.MemberSpans.Add(MemberSpanDataMapper(0, (int)SpanType.PremiumPayment, model.MemberTransactionList[0].PremiumWithholdOptionName, model, model.MemberTransactionList[0].EffectiveDate, null, 1));
                            if (model.PCPID > 0)
                            {
                                memberDetails.MemberSpans.Add(MemberSpanDataMapper(0, (int)SpanType.PCP, model.PCPID.ToString(), model, model.MemberTransactionList[0].EffectiveDate, null, 1));
                            }
                            memberDetails.MemberSpans.Add(MemberSpanDataMapper(0, (int)SpanType.SCC, model.PermanentStateAndCountyCode, model, model.MemberTransactionList[0].EffectiveDate, null, 1));
                        }
                    }

                    memberDetails.ApplicationStatusID = model.ApplicationStatusID != null ? model.ApplicationStatusID : (int?)ApplicationStatus.ENew;
                    memberDetails.MemberGUID = Guid.NewGuid();

                    _context.Members.Add(memberDetails);
                    await _context.SaveChangesAsync();

                    //dbTransaction.Commit();
                    return memberDetails.MemberID;
                }
                else
                {
                    //dbTransaction.Rollback();
                    DbState.AddErrorMessage("CanNotAddRecord", "Enrollment Member is already exists.");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                //dbTransaction.Rollback();
                DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                return 0;
            }
            //}
        }


        public void CompareObjects<T>(string mbi, string updatedBy, int memberId, T obj1, T obj2, string[] propertiesToExclude)
        {
            Type type = typeof(T);
            PropertyInfo[] properties = type.GetProperties();

            foreach (PropertyInfo property in properties)
            {
                if (propertiesToExclude.Contains(property.Name))
                    continue;

                object value1 = property.GetValue(obj1);
                object value2 = property.GetValue(obj2);

                if (value1 != null)
                {
                    if (!Equals(value1, value2))
                    {
                        //Console.WriteLine($"Property '{property.Name}' is different:");
                        //Console.WriteLine($" Value 1: {value1}");
                        //Console.WriteLine($" Value 2: {value2}");
                        //Console.WriteLine();
                        var auditHistory = new AuditHistory();
                        auditHistory.ModifiedDate = DateTime.Now;
                        auditHistory.MBI = mbi;
                        auditHistory.ModifiedBy = updatedBy;
                        auditHistory.Source = Screen.Enrollment;
                        auditHistory.MemberId = memberId;
                        auditHistory.ModifiedField = property.Name;
                        auditHistory.BeforeValue = value1.ToString();
                        auditHistory.AfterValue = value2 == null ? "" : value2.ToString();
                        _context.AuditHistorys.Add(auditHistory);
                    }
                }

            }
            _context.SaveChanges();
        }
        public async Task<int> UpdateEnrollmentHeader(MemberEnrollmentViewModel model)
        {
            //using (var dbTransaction = _context.Database.BeginTransaction())
            //{
            try
            {
                var mbiExists = await _context.Members.Where(x => x.MedicareNumber == model.MBI).FirstOrDefaultAsync();
                if (mbiExists == null || mbiExists.MemberID == model.MemberID)
                {
                    var entity = await _context.Members.Where(x => x.MemberID == model.MemberID).FirstOrDefaultAsync();
                    if (entity != null)
                    {
                        if (model.TrackingID == null)
                        {
                            model.TrackingID = GetNextSequenceNumber("EnrollTrackingId", 10).Result;
                        }
                        if (model.MemberCode == null)
                        {
                            model.MemberCode = GetNextSequenceNumber("EnrollMemberId", 9).Result;
                        }

                        // Mapping member enrollment data to Member Model
                        model.CreatedBy = entity.CreatedBy;
                        model.CreatedDate = entity.CreatedDate;
                        Enrollment.Member memberDetails = new Enrollment.Member();
                        memberDetails = MemberEnrollmentDataMapper(model);
                        memberDetails.MemberCMSDetails.Add(MemberCMSDetailDataMapper(model));
                        memberDetails.MemberContacts.Add(MemberContactDataMapper(model, ContactType.Other));
                        memberDetails.MemberContacts.Add(MemberContactDataMapper(model, ContactType.Mailing));
                        memberDetails.MemberContacts.Add(MemberContactDataMapper(model, ContactType.Emergency));
                        memberDetails.MemberEligibilitys.Add(MemberEligibilityDataMapper(model));
                        memberDetails.MemberEnrollmentDetails.Add(MemberEnrollmentDetailDataMapper(model));
                        memberDetails.MemberNotes.Add(MemberNoteDataMapper(model));
                        memberDetails.MemberOtherCoverages.Add(MemberOtherCoverageDataMapper(model));
                        memberDetails.MemberPremiumDetails.Add(MemberPremiumDetailDataMapper(model));
                        memberDetails.MemberGUID = model.MemberGUID != null ? model.MemberGUID : Guid.Empty;
                        if (model.PCPID > 0)
                            memberDetails.MemberPCPs.Add(MemberPCPDataMapper(model));

                        string[] memberPropertiesToExclude = { "MemberEligibilitys", "MemberPCPs", "MemberContacts", "MemberDependents", "ParentMembers", "MemberCodes", "MemberNotes", "MemberCOBs", "MemberBillings", "MemberBillingPayments", "MemberDiscloserInfos", "MemberCostShares", "ClaimHeaderMembers", "ClaimDiagnosisMembers", "ClaimServiceMembers", "ClaimNotesMembers", "ClaimReferenceMembers", "PaymentMembers", "MemberCMSDetails", "RefundRequestClaimMembers", "RefundPostingMembers", "MemberEnrollmentDetails", "MemberOtherCoverages", "MemberPremiumDetails", "MemberEnrollmentHeaderAttachments", "MemberTransactionDetails", "TRRDetailLayouts", "MemberSpans", "Gender", "Relationship", "PrimaryLanguage", "SecondaryLanguage", "MaritalStatus", "ResidingAt", "Race", "Ethnicity", "StudentStatus", "EmployeeStatus", "MemberStatus", "AccessibilityFormat", "ApplicationStatus", "Contract", "PBP" };
                        CompareObjects(model.MBI, model.UpdatedBy, model.MemberID, entity, memberDetails, memberPropertiesToExclude);

                        //string[] cmsPropertiesToExclude = {  };

                        //CompareObjects(model.UpdatedBy, model.MemberID, entity.MemberCMSDetails, memberDetails.MemberCMSDetails, cmsPropertiesToExclude);


                        //CompareObjects(model.UpdatedBy, model.MemberID, entity, memberDetails, propertiesToExclude);
                        //CompareObjects(model.UpdatedBy, model.MemberID, entity, memberDetails, propertiesToExclude);
                        //CompareObjects(model.UpdatedBy, model.MemberID, entity, memberDetails, propertiesToExclude);
                        //CompareObjects(model.UpdatedBy, model.MemberID, entity, memberDetails, propertiesToExclude);
                        //CompareObjects(model.UpdatedBy, model.MemberID, entity, memberDetails, propertiesToExclude);
                        //CompareObjects(model.UpdatedBy, model.MemberID, entity, memberDetails, propertiesToExclude);

                        _context.Entry(entity).CurrentValues.SetValues(memberDetails);
                        // Update and Insert Child Entity
                        var memberCMSEntity = _context.MemberCMSDetails.Where(x => x.MemberID == model.MemberID).ToList();

                        string[] cmsPropertiesToExclude = { "LISLevel", "Member" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, cmsPropertiesToExclude, memberCMSEntity, memberDetails.MemberCMSDetails, entity.MemberCMSDetails);

                        var memberContactEntity = _context.MemberContacts.Where(x => x.MemberID == model.MemberID && x.ContactTypeID == (int)ContactType.Other).ToList();
                        var primaryMemberContact = memberDetails.MemberContacts.Where(x => x.ContactTypeID == (int)ContactType.Other).ToList();

                        string[] contactPropertiesToExclude = { "Member", "ContactType", "Relationship" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, contactPropertiesToExclude, memberContactEntity, primaryMemberContact, entity.MemberContacts);

                        var memberContactMailingEntity = _context.MemberContacts.Where(x => x.MemberID == model.MemberID && x.ContactTypeID == (int)ContactType.Mailing).ToList();
                        var mailingMemberContact = memberDetails.MemberContacts.Where(x => x.ContactTypeID == (int)ContactType.Mailing).ToList();

                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, contactPropertiesToExclude, memberContactMailingEntity, mailingMemberContact, entity.MemberContacts);

                        var memberContactAuthEntity = _context.MemberContacts.Where(x => x.MemberID == model.MemberID && x.ContactTypeID == (int)ContactType.Emergency).ToList();
                        var authMemberContact = memberDetails.MemberContacts.Where(x => x.ContactTypeID == (int)ContactType.Emergency).ToList();
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, contactPropertiesToExclude, memberContactAuthEntity, authMemberContact, entity.MemberContacts);

                        var memberEligibilitysEntity = _context.MemberEligibilitys.Where(x => x.MemberID == model.MemberID).ToList();

                        string[] eligibilityPropertiesToExclude = { "ClaimHeaderMemberEligibilities", "Member", "Company", "SubCompany", "Lob", "HealthPlan", "CoverageType", "RiskType", "DisenrollmentReason" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, eligibilityPropertiesToExclude, memberEligibilitysEntity, memberDetails.MemberEligibilitys, entity.MemberEligibilitys);

                        var memberEnrollmentDetailsEntity = _context.MemberEnrollmentDetails.Where(x => x.MemberID == model.MemberID).ToList();

                        string[] enrollmentPropertiesToExclude = { "Member", "EnrollmentSource", "EnrollmentMechanism" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, enrollmentPropertiesToExclude, memberEnrollmentDetailsEntity, memberDetails.MemberEnrollmentDetails, entity.MemberEnrollmentDetails);

                        var MemberNotesEntity = _context.MemberNotes.Where(x => x.MemberID == model.MemberID).ToList();

                        string[] notePropertiesToExclude = { "Member" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, notePropertiesToExclude, MemberNotesEntity, memberDetails.MemberNotes, entity.MemberNotes);

                        var memberOtherCoveragesEntity = _context.MemberOtherCoverages.Where(x => x.MemberID == model.MemberID).ToList();

                        string[] coveragePropertiesToExclude = { "Member", "PlanSpecificChronicCondition" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, coveragePropertiesToExclude, memberOtherCoveragesEntity, memberDetails.MemberOtherCoverages, entity.MemberOtherCoverages);

                        var memberPremiumDetails = _context.MemberPremiumDetails.Where(x => x.MemberID == model.MemberID).ToList();

                        string[] premiumPropertiesToExclude = { "Member" };
                        UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, premiumPropertiesToExclude, memberPremiumDetails, memberDetails.MemberPremiumDetails, entity.MemberPremiumDetails);
                        if (model.PCPID > 0)
                        {
                            var memberPCP = _context.MemberPCPs.Where(x => x.MemberID == model.MemberID).ToList();

                            string[] pcpPropertiesToExclude = { "ClaimHeaderMemberPCPs", "Member", "DisenrollmentReason" };
                            UpdateAndInsertChildEntity(model.MBI, model.UpdatedBy, model.MemberID, pcpPropertiesToExclude, memberPCP, memberDetails.MemberPCPs, entity.MemberPCPs);
                        }

                        var memberTransactionDetails = _context.MemberTransactionDetails.Where(x => x.MemberID == model.MemberID).ToList();
                        if (memberTransactionDetails.Count > 0)
                        {
                            if (memberTransactionDetails.Count == 1)
                            {
                                model.UpdatedDate = memberTransactionDetails[0].EffectiveDate;
                            }
                            string[] spanPropertiesToExclude = { "Member", "SpanType", "SpanSource" };
                            CompareObjects(model.MBI, model.UpdatedBy, model.MemberID, entity.MemberSpans, memberDetails.MemberSpans, spanPropertiesToExclude);

                            await UpdateAndInsertMemberSpan(model, (int)SpanType.SCC, model.PermanentStateAndCountyCode, model.UpdatedDate, entity.MemberSpans, 1);
                            if (model.PCPID > 0)
                            {
                                await UpdateAndInsertMemberSpan(model, (int)SpanType.PCP, model.PCPID.ToString(), model.UpdatedDate, entity.MemberSpans, 1);
                            }
                        }
                        await _context.SaveChangesAsync();

                        //dbTransaction.Commit();
                        return memberDetails.MemberID;
                    }
                    else
                    {
                        //dbTransaction.Rollback();
                        DbState.AddErrorMessage("CanNotAddRecord", "Enrollment Member does not exists.");
                        return 0;
                    }
                }
                else
                {
                    //dbTransaction.Rollback();
                    DbState.AddErrorMessage("CanNotAddRecord", "Enrollment Member is already exists with MBI.");
                    return 0;
                }
            }
            catch (Exception ex)
            {
                //dbTransaction.Rollback();
                //DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                return 0;
            }
            //}
        }

        public async Task UpdateAndInsertMemberSpan(MemberEnrollmentViewModel model, int spanType, string spanValue, DateTime? spanEffectivedate, ICollection<MemberSpan> memberSpans, byte isFreezed)
        {
            try
            {
                MemberSpan memberSpanDetails = _context.MemberSpans.Where(x => x.MemberID == model.MemberID && x.SpanTypeID == spanType).OrderByDescending(x => x.MemberSpanID).FirstOrDefault();
                if (memberSpanDetails != null && memberSpanDetails.SpanValue != spanValue)
                {
                    if (isFreezed == 1 && (spanType == (int)SpanType.SCC || spanType == (int)SpanType.PremiumPayment))
                    {
                        spanEffectivedate = DateTime.Now;
                    }
                    MemberSpan addMemberSpan = MemberSpanDataMapper(0, spanType, spanValue, model, spanEffectivedate, null, isFreezed);
                    memberSpans.Add(addMemberSpan);
                    DateTime oldSpanDate;
                    DateTime newSpanDate;
                    DateTime.TryParseExact(memberSpanDetails.SpanEffectivedate.ToString(), "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out oldSpanDate);
                    //var newSpanDate = DateTime.Parse(addMemberSpan.SpanEffectivedate.ToString(), CultureInfo.InvariantCulture).Date;
                    DateTime.TryParseExact(addMemberSpan.SpanEffectivedate.ToString(), "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out newSpanDate);

                    memberSpanDetails.SpanTermDate = newSpanDate.AddDays(-1);
                    if (newSpanDate <= oldSpanDate)
                    {
                        memberSpanDetails.SpanEffectivedate = new DateTime(1900, 1, 1);
                        memberSpanDetails.SpanTermDate = new DateTime(1900, 1, 1);
                    }
                    model.CreatedDate = memberSpanDetails.CreatedDate;
                    model.CreatedBy = memberSpanDetails.CreatedBy;
                    MemberSpan updateMemberSpan = MemberSpanDataMapper(memberSpanDetails.MemberSpanID, memberSpanDetails.SpanTypeID, memberSpanDetails.SpanValue, model, memberSpanDetails.SpanEffectivedate, memberSpanDetails.SpanTermDate, memberSpanDetails.IsFreezed);

                    _context.Entry(memberSpanDetails).CurrentValues.SetValues(updateMemberSpan);
                }
                else if (memberSpanDetails == null)
                {
                    MemberSpan addMemberSpan = MemberSpanDataMapper(0, spanType, spanValue, model, spanEffectivedate, null, isFreezed);
                    memberSpans.Add(addMemberSpan);
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<MemberEnrollmentEditViewModel> GetMemberEnrollmentHeaderById(int MemberEnrollmentHeaderID)
        {
            try
            {
                var parameters = new SqlParameter[]
            {
                    new SqlParameter("@ID", MemberEnrollmentHeaderID),
             };
                MemberEnrollmentEditViewModel MemberEnrollmentData = _context.ExecuteStoreProcedure<MemberEnrollmentEditViewModel>("[hps].[GetMemberEnrollmentById]", parameters).FirstOrDefault();
                return MemberEnrollmentData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void UpdateAndInsertChildEntity<TEntity>(string mbi, string updatedBy, int memberId, string[] propertiesToExclude, ICollection<TEntity> entity, ICollection<TEntity> updateModel, ICollection<TEntity> mainEntityData)
            where TEntity : class, IEntity
        {
            foreach (var childModel in updateModel)
            {
                var existingChild = entity
                    .Where(c => c.MemberID == childModel.MemberID)
                    .SingleOrDefault();
                if (existingChild != null)
                {
                    // Update child
                    CompareObjects(mbi, updatedBy, memberId, existingChild, childModel, propertiesToExclude);
                    _context.Entry(existingChild).CurrentValues.SetValues(childModel);
                    _context.SaveChanges();
                }
                else
                {
                    // Insert child
                    var newChild = updateModel.FirstOrDefault();
                    mainEntityData.Add(newChild);
                }
            }
        }

        private TEntity CreateUpdateValueChanges<TEntity, T>(TEntity entity, T model, int Id) where TEntity : class, IEntity
            where T : class, IEntity
        {
            if (Id == 0)
            {
                entity.CreatedBy = model.CreatedBy == null ? "" : model.CreatedBy;
                entity.CreatedDate = model.CreatedDate;
            }
            else
            {
                entity.CreatedBy = model.CreatedBy == null ? "" : model.CreatedBy;
                entity.CreatedDate = model.CreatedDate;
                entity.UpdatedBy = model.UpdatedBy;
                entity.UpdatedDate = model.UpdatedDate;
            }
            return entity;
        }

        private MemberTransactionDetail MemberTransactionDetailDataMapper(MemberEnrollmentViewModel model)
        {
            MemberTransactionDetail memberTransactionDetailData = new MemberTransactionDetail();
            foreach (var item in model.MemberTransactionList)
            {
                memberTransactionDetailData = new MemberTransactionDetail()
                {
                    MemberTransactionDetailID = item.MemberTransactionDetailID != 0 ? item.MemberTransactionDetailID : 0,
                    ContractID = item.ContractID,
                    PBPID = item.PBPID,
                    ElectionTypeID = item.ElectionTypeID,
                    SepReasonDate = item.SepReasonDate,
                    EffectiveDate = item.EffectiveDate,
                    TransactionTypeID = item.TransactionTypeID,
                    SepReasonCodeID = item.SepReasonCodeID,
                    TermDate = item.TermDate,
                    SignatureDate = item.SignatureDate,
                    ReceiptDate = item.ReceiptDate,
                    ISPartDOptOut = item.ISPartDOptOut,
                    PremiumWithholdOptionID = item.PremiumWithholdOptionID,
                    EmployerSubsidyOverride = item.EmployerSubsidyOverride,
                    DisEnrollmentReasonCodeID = item.DisEnrollmentReasonCodeID,
                    RFIRequestedDate = item.RFIRequestedDate,
                    RFIDueDate = item.RFIDueDate,
                    RFIResponseDate = item.RFIResponseDate,
                    TransactionStatusID = item.TransactionStatusID,
                    PendReasonID = item.PendReasonID,
                    IncompleteReasonID = item.IncompleteReasonID,
                    IsDenialFlag = item.IsDenialFlag,
                    DenialReasonID = item.DenialReasonID,
                    DeniedDate = item.DeniedDate,
                    CMSSubmissionDate = item.CMSSubmissionDate,
                    TRRResponseDate = item.TRRResponseDate,
                    BEQSubmissionDate = item.BEQSubmissionDate,
                    BEQResponseDate = item.BEQResponseDate,
                    OEVLetterSentDate = item.OEVLetterSentDate,
                    TransactionReplyCode = item.TransactionReplyCode,
                    CMSSubmissionTrackingID = item.CMSSubmissionTrackingID,
                    RecordStatusChangeComment = model.RecordStatusChangeComment,
                    MemberID = model.MemberID != 0 ? model.MemberID : 0
                };
                memberTransactionDetailData = CreateUpdateValueChanges<MemberTransactionDetail, MemberEnrollmentViewModel>(memberTransactionDetailData, model, item.MemberTransactionDetailID);
            }
            return memberTransactionDetailData;
        }

        private MemberPremiumDetail MemberPremiumDetailDataMapper(MemberEnrollmentViewModel model)
        {
            MemberPremiumDetail memberPremiumDetailData = new MemberPremiumDetail()
            {
                LowIncomeCopayID = model.LowIncomeCopayID,
                PartDLEPAmount = model.PartDLEPAmount,
                PartDLEPWaivedAmount = model.PartDLEPWaivedAmount,
                PartDLEPSubsidyAmount = model.PartDLEPSubsidyAmount,
                LowIncomePartDPremiumSubsidyAmount = model.LowIncomePartDPremiumSubsidyAmount,
                PartCPremiumAmount = model.PartCPremiumAmount,
                PartDPremiumAmount = model.PartDPremiumAmount,
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                MemberPremiumDetailID = model.MemberPremiumDetailID != 0 ? model.MemberPremiumDetailID : 0,
            };
            memberPremiumDetailData = CreateUpdateValueChanges<MemberPremiumDetail, MemberEnrollmentViewModel>(memberPremiumDetailData, model, model.MemberPremiumDetailID);

            return memberPremiumDetailData;
        }

        private MemberOtherCoverage MemberOtherCoverageDataMapper(MemberEnrollmentViewModel model)
        {
            MemberOtherCoverage memberOtherCoverageData = new MemberOtherCoverage()
            {
                IsEnrolledInStateMedicaid = model.IsEnrolledInStateMedicaId,
                MedicaidNumber = model.MedicaidNumber,
                MedicaidLevelForSNP = model.MedicaidLevelForSNP,
                PlanSpecificChronicConditionID = model.PlanSpecificChronicConditionID,
                ProviderOfficeNameForVerification = model.ProviderOfficeNameForVerification,
                ProviderOfficeAddress = model.ProviderOfficeAddress,
                ProviderOfficeCity = model.ProviderOfficeCity,
                ProviderOfficeState = model.ProviderOfficeState,
                ProviderOfficeZip = model.ProviderOfficeZip,
                ProviderOfficeContactCount = model.ProviderOfficeContactCount,
                LongTermCare = model.LongTermCare,
                LongTermName = model.LongTermName,
                LongTermAddress = model.LongTermAddress,
                LongTermPhone = model.LongTermPhone,
                EmployerGroupNumber = model.EmployerGroupNumber,
                EmployerGroupName = model.EmployerGroupName,
                IsOtherPrescriptionDrugCoverage = model.IsOtherPrescriptionDrugCoverage,
                OtherCoverageName = model.OtherCoverageName,
                OtherCoverageID = model.OtherCoverageID,
                OtherCoverageGroup = model.OtherCoverageGroup,
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                MemberOtherCoverageID = model.MemberOtherCoverageID != 0 ? model.MemberOtherCoverageID : 0,
                SecondaryDrugBIN = model.SecondaryDrugBIN,
                SecondaryDrugPCN = model.SecondaryDrugPCN
            };
            memberOtherCoverageData = CreateUpdateValueChanges<MemberOtherCoverage, MemberEnrollmentViewModel>(memberOtherCoverageData, model, model.MemberOtherCoverageID);

            return memberOtherCoverageData;
        }

        private MemberNote MemberNoteDataMapper(MemberEnrollmentViewModel model)
        {
            MemberNote memberNoteData = new MemberNote()
            {
                LongDesc = model.Notes != null ? model.Notes : "",
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                EffectiveDate = DateTime.MinValue,
                IsFreezed = 0,
                NoteDate = DateTime.Now,
                ShortDesc = "",
                TermDate = DateTime.MaxValue,
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                MemberNoteID = model.MemberNoteID != 0 ? model.MemberNoteID : 0,
            };
            memberNoteData = CreateUpdateValueChanges<MemberNote, MemberEnrollmentViewModel>(memberNoteData, model, model.MemberNoteID);

            return memberNoteData;
        }

        private MemberEnrollmentDetail MemberEnrollmentDetailDataMapper(MemberEnrollmentViewModel model)
        {
            MemberEnrollmentDetail memberEnrollmentDetailData = new MemberEnrollmentDetail()
            {
                EnrollmentSourceID = model.EnrollmentSourceID,
                EnrollmentMechanismID = model.EnrollmentMechanismID == 0 ? null : model.EnrollmentMechanismID,
                SalesAgentID = model.SalesAgentID,
                SalesAgentName = model.SalesAgentName,
                SaleDate = model.SaleDate,
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                MemberEnrollmentDetailID = model.MemberEnrollmentDetailID != 0 ? model.MemberEnrollmentDetailID : 0,
            };
            memberEnrollmentDetailData = CreateUpdateValueChanges<MemberEnrollmentDetail, MemberEnrollmentViewModel>(memberEnrollmentDetailData, model, model.MemberEnrollmentDetailID);

            return memberEnrollmentDetailData;
        }

        private MemberEligibility MemberEligibilityDataMapper(MemberEnrollmentViewModel model)
        {
            MemberEligibility memberEligibilityData = new MemberEligibility()
            {
                LOBID = model.LOBID != null ? model.LOBID : (short)(123),
                PrimaryRxGroup = model.PrimaryRxGroup,
                PrimaryRxBIN = model.PrimaryRxBIN,
                PrimaryRxPCN = model.PrimaryRxPCN,
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                CompanyID = 1,
                CoverageTypeID = 6103,
                EffectiveDate = DateTime.MinValue,
                TermDate = DateTime.MaxValue,
                GroupName = "",
                HealthPlanID = 1081,
                InsuranceMemberCode = "",
                PolicyNumber = "",
                RiskTypeID = 6206,
                SubCompanyID = 2,
                IsFreezed = 0,
                PrimaryRxID = model.PrimaryRxID != null ? model.PrimaryRxID : (short)(0),
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                MemberEligibilityID = model.MemberEligibilityID != 0 ? model.MemberEligibilityID : 0,
            };
            memberEligibilityData = CreateUpdateValueChanges<MemberEligibility, MemberEnrollmentViewModel>(memberEligibilityData, model, model.MemberEligibilityID);

            return memberEligibilityData;
        }

        private MemberContact MemberContactDataMapper(MemberEnrollmentViewModel model, ContactType contactType)
        {
            MemberContact memberContactData = new MemberContact();
            if (ContactType.Other == contactType)
            {
                memberContactData = new MemberContact()
                {
                    Address1 = model.PermanentAddressLine1 != null ? model.PermanentAddressLine1 : "",
                    Address2 = model.PermanentAddressLine2 != null ? model.PermanentAddressLine2 : "",
                    City = model.PermanentAddressCity != null ? model.PermanentAddressCity : "",
                    State = model.PermanentAddressState != null ? model.PermanentAddressState : "",
                    Zip = model.PermanentAddressZip != null ? model.PermanentAddressZip : "",
                    County = model.PermanentAddressCounty != null ? model.PermanentAddressCounty : "",
                    PermanentStateandCountyCode = model.PermanentStateAndCountyCode != null ? model.PermanentStateAndCountyCode : "",
                    MobilePhone = model.Phonenumber != null ? model.Phonenumber : "",
                    HomePhone = model.AltPhonenumber != null ? model.AltPhonenumber : "",
                    ContactTypeID = (int)ContactType.Other,
                    Email = model.Email != null ? model.Email : "",
                    ContactName = model.EmergencyContactName != null ? model.EmergencyContactName : "",
                    RelationshipID = model.EmergencyContactRelationshipID != 0 ? model.EmergencyContactRelationshipID : null,
                    WorkPhone = model.AuthorisedRepContactNumber != null ? model.AuthorisedRepContactNumber : "",
                    RecordStatusChangeComment = model.RecordStatusChangeComment,
                    Country = "",
                    MemberID = model.MemberID != 0 ? model.MemberID : 0,
                    MemberContactID = model.MemberContactID != 0 ? model.MemberContactID : 0,
                    ContactPreference = model.ContactPreference != null ? model.ContactPreference : null,
                    CreatedBy = model.CreatedBy == null ? "" : model.CreatedBy
                };
                memberContactData = CreateUpdateValueChanges<MemberContact, MemberEnrollmentViewModel>(memberContactData, model, model.MemberContactID);

            }
            else if (ContactType.Emergency == contactType)
            {
                memberContactData = new MemberContact()
                {
                    County = "",
                    PermanentStateandCountyCode = "",
                    HomePhone = "",
                    ContactTypeID = (int)ContactType.Emergency,
                    Email = "",
                    Address1 = model.AuthorisedRepAddress != null ? model.AuthorisedRepAddress : "",
                    Address2 = "",
                    City = "",
                    State = "",
                    Zip = "",
                    MobilePhone = "",
                    RelationshipID = model.AuthorisedRepRelationship != 0 ? model.AuthorisedRepRelationship : null,
                    ContactName = model.AuthorisedRepName != null ? model.AuthorisedRepName : "",
                    WorkPhone = model.AuthorisedRepContactNumber != null ? model.AuthorisedRepContactNumber : "",
                    RecordStatusChangeComment = model.RecordStatusChangeComment,
                    Country = "",
                    MemberID = model.MemberID != 0 ? model.MemberID : 0,
                    MemberContactID = model.MemberContactAuthID != 0 ? model.MemberContactAuthID : 0,
                    ContactPreference = null
                };
                memberContactData = CreateUpdateValueChanges<MemberContact, MemberEnrollmentViewModel>(memberContactData, model, model.MemberContactMailingID);

            }
            else
            {
                memberContactData = new MemberContact()
                {
                    County = model.PermanentAddressCounty != null ? model.PermanentAddressCounty : "",
                    PermanentStateandCountyCode = model.PermanentStateAndCountyCode != null ? model.PermanentStateAndCountyCode : "",
                    HomePhone = model.AltPhonenumber != null ? model.AltPhonenumber : "",
                    ContactTypeID = (int)ContactType.Mailing,
                    Email = model.Email != null ? model.Email : "",
                    Address1 = model.MailingAddressLine1 != null ? model.MailingAddressLine1 : "",
                    Address2 = model.MailingAddressLine2 != null ? model.MailingAddressLine2 : "",
                    City = model.MailingAddressCity != null ? model.MailingAddressCity : "",
                    State = model.MailingAddressState != null ? model.MailingAddressState : "",
                    Zip = model.MailingAddressZip != null ? model.MailingAddressZip : "",
                    MobilePhone = model.EmergencyContactPhone != null ? model.EmergencyContactPhone : "",
                    RelationshipID = model.EmergencyContactRelationshipID != 0 ? model.EmergencyContactRelationshipID : null,
                    ContactName = model.EmergencyContactName != null ? model.EmergencyContactName : "",
                    WorkPhone = model.AuthorisedRepContactNumber != null ? model.AuthorisedRepContactNumber : "",
                    RecordStatusChangeComment = model.RecordStatusChangeComment,
                    Country = "",
                    MemberID = model.MemberID != 0 ? model.MemberID : 0,
                    MemberContactID = model.MemberContactMailingID != 0 ? model.MemberContactMailingID : 0,
                    ContactPreference = model.ContactPreference != null ? model.ContactPreference : null
                };
                memberContactData = CreateUpdateValueChanges<MemberContact, MemberEnrollmentViewModel>(memberContactData, model, model.MemberContactMailingID);

            }
            return memberContactData;
        }

        private MemberCMSDetail MemberCMSDetailDataMapper(MemberEnrollmentViewModel model)
        {
            MemberCMSDetail memberCMSDetailData = new MemberCMSDetail()
            {
                TrackingID = model.TrackingID,
                MedicarePartAEffectiveDate = model.MedicarePartAEffectiveDate,
                MedicarePartBEffectiveDate = model.MedicarePartBEffectiveDate,
                MedicarePartDEffectiveDate = model.MedicarePartDEffectiveDate,
                IsESRD = model.IsESRD,
                EmployedStatusID = model.IsEmployed,
                LISLevelID = model.LISLevelID,
                PriorCoverageName = model.PriorCoverageName,
                IsEGHP = model.IsEGHP,
                IsCreditableCoverage = model.IsCreditableCoverage,
                NumberOfUncoveredMonths = model.NumberOfUncoveredMonths,
                LepRequestedDate = model.LepRequestedDate,
                LepResponseDate = model.LepResponseDate,
                LepStartDate = model.LepStartDate,
                LepEndDate = model.LepEndDate,
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                SpouseEmployedStatusID = model.SpouseEmployedStatusID,
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                MemberCMSDetailID = model.MemberCMSDetailID != 0 ? model.MemberCMSDetailID : 0,
                CreatedBy = model.CreatedBy == null ? "" : model.CreatedBy
            };
            memberCMSDetailData = CreateUpdateValueChanges<MemberCMSDetail, MemberEnrollmentViewModel>(memberCMSDetailData, model, model.MemberCMSDetailID);

            return memberCMSDetailData;
        }

        private MemberPCP MemberPCPDataMapper(MemberEnrollmentViewModel model)
        {
            MemberPCP memberPCPData = new MemberPCP()
            {
                MemberPCPID = model.MemberPCPID != 0 ? model.MemberPCPID : 0,
                EffectiveDate = DateTime.MinValue,
                TermDate = DateTime.MaxValue,
                IsFreezed = 0,
                IsPrimary = true,
                MemberID = model.MemberID != 0 ? model.MemberID : 0,
                PCPID = model.PCPID,
                ProviderLocationID = 1,
                RecordStatus = (int)RecordStatus.Active,
                RecordStatusChangeComment = model.RecordStatusChangeComment,
                IsCurrentPatient = model.IsCurrentPatient
            };
            memberPCPData = CreateUpdateValueChanges<MemberPCP, MemberEnrollmentViewModel>(memberPCPData, model, model.MemberPCPID);

            return memberPCPData;
        }

        private Enrollment.Member MemberEnrollmentDataMapper(MemberEnrollmentViewModel model)
        {
            Enrollment.Member memberDetails = new Enrollment.Member();
            memberDetails.MemberID = model.MemberID != 0 ? model.MemberID : 0;
            memberDetails.Prefix = model.Salutation != null ? model.Salutation : "";
            memberDetails.MemberCode = model.MemberCode;
            memberDetails.FirstName = model.FirstName;
            memberDetails.LastName = model.LastName;
            memberDetails.RaceID = model.RaceID;
            memberDetails.EthnicityID = model.EthnicityID;
            memberDetails.DOB = model.DOB;
            memberDetails.GenderID = model.GenderID;
            memberDetails.SSN = model.SSN != null ? model.SSN : "";
            memberDetails.MedicareNumber = model.MBI;
            memberDetails.MemberStatusID = model.MemberStatusID;
            memberDetails.PrimaryLanguageID = model.PrimaryLanguageID;
            memberDetails.AccessibilityFormatID = model.AccessibilityFormatID == 0 ? null : model.AccessibilityFormatID;
            memberDetails.ConfirmationNumber = model.ConfirmationNumber;
            memberDetails.RecordStatusChangeComment = model.RecordStatusChangeComment;
            memberDetails.DeceasedReason = "";
            memberDetails.FamilyCode = "0";
            memberDetails.MedicaidNumber = model.MedicaidNumber != null ? model.MedicaidNumber : "0";
            memberDetails.MiddleName = model.MiddleName != null ? model.MiddleName : "";
            memberDetails.PreviousName = "";
            memberDetails.PrimaryEmail = "";
            memberDetails.RelationshipID = (int)MemberRelationship.Self;
            memberDetails.SecondaryEmail = "";
            memberDetails.Suffix = "";
            memberDetails.DisplayName = model.FirstName + " " + model.MiddleName + " " + model.LastName;
            memberDetails.ApplicationStatusID = model.ApplicationStatusID;
            memberDetails.ContractID = model.ContractID;
            memberDetails.PBPID = model.PBPID;
            memberDetails = CreateUpdateValueChanges<Enrollment.Member, MemberEnrollmentViewModel>(memberDetails, model, model.MemberID);

            return memberDetails;
        }

        public MemberSpan MemberSpanDataMapper(int memberSpanID, int spanType, string spanValue, MemberEnrollmentViewModel model, DateTime? effectiveDate, DateTime? spanTermDate, byte isFreezed)
        {
            MemberSpan memberSpan = new MemberSpan();
            memberSpan.MemberSpanID = memberSpanID;
            memberSpan.MemberID = model.MemberID;
            memberSpan.SpanTypeID = spanType;
            memberSpan.SpanEffectivedate = effectiveDate != null ? effectiveDate : DateTime.Now;
            memberSpan.SpanTermDate = spanTermDate;
            memberSpan.SpanValue = spanValue;
            memberSpan.SpanSourceID = (int)SpanSource.Enrollment;
            memberSpan.IsFreezed = isFreezed;
            memberSpan.RecordStatus = (int)RecordStatus.Active;
            memberSpan.RecordStatusChangeComment = RecordStatus.Active.ToString();
            memberSpan = CreateUpdateValueChanges<MemberSpan, MemberEnrollmentViewModel>(memberSpan, model, memberSpanID);
            return memberSpan;
        }

        public async Task<List<SEPReasonCode>> GetSepReasonCodeById(int electionTypeCodeId)
        {
            try
            {
                return await _context.SEPReasonCode.Where(x => x.ElectionTypeCodeID == electionTypeCodeId).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        async Task<List<SEPReasonCode>> IMemberEnrollmentHeaderRepository.GetSepReason()
        {
            try
            {
                return await _context.SEPReasonCode.ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
