﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberDiscloserInfoRepository : BaseRepository<MemberDiscloserInfo>, IMemberDiscloserInfoRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public MemberDiscloserInfoRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion
        #region Interface Methods Implementation    
        public IEnumerable<MemberDiscloserInfo> GetAllMemberDiscloserInfo()
        {
            try
            {
                var res = _context.MemberDiscloserInfos.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberDiscloserInfos", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberDiscloserInfoViewModel> GetMemberDiscloserInfo(int MemberID)
        {
            try
            {
                var query = from dis in _context.MemberDiscloserInfos
                            join mem in _context.Members on dis.MemberID equals mem.MemberID
                            where dis.MemberID == MemberID && dis.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new MemberDiscloserInfoViewModel()
                            {
                                MemberDiscloserInfoID = dis.MemberDiscloserInfoID,
                                MemberID = dis.MemberID,
                                MemberName = mem.FirstName,
                                FirstName = dis.FirstName,
                                LastName = dis.LastName,
                                DisclosePersonalHealthID = dis.DisclosePersonalHealthID,
                                DiscloseLimitedInfo = dis.DiscloseLimitedInfo,
                                DiscloseInfoTimeID = dis.DiscloseInfoTimeID,
                                DiscloseInfoStartTime = dis.DiscloseInfoStartTime,
                                DiscloseInfoEndTime = (dis.DiscloseInfoEndTime.Date == DateTime.MaxValue.Date) ? (DateTime?)null : dis.DiscloseInfoEndTime,
                                Address1 = dis.Address1,
                                Address2 = dis.Address2,
                                State = dis.State,
                                City = dis.City,
                                IsMemberSignature = dis.IsMemberSignature,
                                Zip = dis.Zip,
                                MemberCode = mem.MemberCode
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberDiscloserInfo", ex.Message);
                return null;
            }
        }


        public List<MemberDiscloserInfoViewModel> GetMemberDiscloserInfoByPHI(string FamilyCode, int DisclosePersonalHealthID)
        {
            List<MemberDiscloserInfoViewModel> items = (from dis in _context.MemberDiscloserInfos
                                                        join mem in _context.Members on dis.MemberID equals mem.MemberID
                                                        join ctime in _context.CommonCodes on dis.DiscloseInfoTimeID equals ctime.CommonCodeID
                                                        join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                                                        join dph in _context.CommonCodes on dis.DisclosePersonalHealthID equals dph.CommonCodeID
                                                        where mem.FamilyCode == FamilyCode && ((DisclosePersonalHealthID == -1) ? dis.DisclosePersonalHealthID != DisclosePersonalHealthID : dis.DisclosePersonalHealthID == DisclosePersonalHealthID) && dis.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                                                        orderby dis.RecordStatus ascending
                                                        select new MemberDiscloserInfoViewModel()
                                                        {
                                                            MemberDiscloserInfoID = dis.MemberDiscloserInfoID,
                                                            MemberID = dis.MemberID,
                                                            MemberName = mem.DisplayName,
                                                            FirstName = dis.FirstName,
                                                            LastName = dis.LastName,
                                                            DisclosePersonalHealthID = dis.DisclosePersonalHealthID,
                                                            DiscloseLimitedInfo = dis.DiscloseLimitedInfo,
                                                            DiscloseInfoTimeID = dis.DiscloseInfoTimeID,
                                                            DiscloseInfoTime = ctime.ShortName,
                                                            DiscloseInfoStartTime = dis.DiscloseInfoStartTime,
                                                            DiscloseInfoEndTime = (dis.DiscloseInfoEndTime.Date == DateTime.MaxValue.Date) ? (DateTime?)null : dis.DiscloseInfoEndTime,
                                                            Address1 = dis.Address1,
                                                            Address2 = dis.Address2,
                                                            State = dis.State,
                                                            City = dis.City,
                                                            IsMemberSignature = dis.IsMemberSignature,
                                                            Zip = dis.Zip,
                                                            MemberCode = mem.MemberCode,
                                                            RecordStatus = dis.RecordStatus,
                                                            Relationship = rel.ShortName,
                                                            DisclosePersonalHealth = dph.ShortName
                                                        }).ToList();
            foreach (MemberDiscloserInfoViewModel item in items)
            {
                string[] DLimitedInfo = item.DiscloseLimitedInfo.Split(',');
                item.DiscloseLimitedInfoValue = string.Join(", ", _context.CommonCodes.Where(e => DLimitedInfo.Contains(e.CommonCodeID.ToString())).Select(s => s.ShortName));
            }
            return items;
        }
        #endregion
    }
}
