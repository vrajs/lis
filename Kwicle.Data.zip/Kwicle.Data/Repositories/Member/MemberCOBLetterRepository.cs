﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberCOBLetterRepository : BaseRepository<MemberCOBLetter>, IMemberCOBLetterRepository
    {
        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public MemberCOBLetterRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Get Methods
        public IQueryable<MemberCOBLetterViewModel> GetMemberCOBLetter(string FamilyCode)
        {
            var query = from mcobl in _context.MemberCOBLetters
                        join mcob in _context.MemberCOBs on mcobl.MemberCOBID equals mcob.MemberCOBID
                        join mem in _context.Members on mcob.MemberID equals mem.MemberID
                        join rt in _context.CommonCodes on mem.RelationshipID equals rt.CommonCodeID
                        join t in _context.Templates on mcobl.TemplateID equals t.TemplateID
                        where mem.FamilyCode == FamilyCode && mcobl.RecordStatus == (int)RecordStatus.Active
                        orderby mcobl.MemberCOBLetterID descending
                        select new MemberCOBLetterViewModel()
                        {
                            MemberCOBLetterID = mcobl.MemberCOBLetterID,
                            TemplateID = mcobl.TemplateID,
                            LetterDate = mcobl.LetterDate,
                            MemberCOBID = mcobl.MemberCOBID,
                            Outcome = mcobl.Outcome,
                            ResponseDate = mcobl.ResponseDate,
                            TemplateName = t.TemplateName,
                            MemberID = mem.MemberID,
                            MemberName = mem.DisplayName,
                            Relationship = rt.ShortName,
                            MemberCode = mem.MemberCode
                        };
            return query;
        }
        #endregion
    }
}
