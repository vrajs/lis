﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberCodeReferenceRepository : BaseRepository<MemberCode>, IMemberCodeReferenceRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public MemberCodeReferenceRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<MemberCode> GetAllMemberCodeRef()
        {
            try
            {
                var res = _context.MemberCodes.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberCodeReferences", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberCodeReferenceViewModel> GetMemberCodeRef(string FamilyCode)
        {
            try
            {
                var query = from b in _context.MemberCodes
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                            join ct in _context.CommonCodes on b.CodeTypeID equals ct.CommonCodeID
                            where mem.FamilyCode == FamilyCode && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            orderby (mem.RelationshipID == (int)MemberRelationship.Self) ? 0 : 1
                            select new MemberCodeReferenceViewModel()
                            {
                                MemberCodeID = b.MemberCodeID,
                                MemberID = b.MemberID,
                                MemberName = mem.DisplayName,
                                CodeTypeID = b.CodeTypeID,
                                CodeType = ct.ShortName,
                                CodeValue = b.CodeValue,
                                ControlTypeID = b.ControlTypeID,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = (b.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : b.TermDate,
                                MemberCode = mem.MemberCode,
                                Relationship = rel.ShortName
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberCodeReferences", ex.Message);
                return null;
            }
        }
        #endregion

    }
}
