﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberBillingPaymentRepository : BaseRepository<MemberBillingPayment>, IMemberBillingPaymentRepository
    {

        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public MemberBillingPaymentRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Get Methods
        public IQueryable<MemberBillingPaymentViewModel> GetMemberBillingPayment(string FamilyCode, int AccountTypeID)
        {
            var query = from mbp in _context.MemberBillingPayments
                        join mem in _context.Members on mbp.MemberID equals mem.MemberID
                        join ccode in _context.CommonCodes on mbp.InvoiceTypeID equals ccode.CommonCodeID
                        join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                        where mem.FamilyCode == FamilyCode && ((AccountTypeID == -1) ? mbp.AccountTypeID != AccountTypeID : mbp.AccountTypeID == AccountTypeID) && mbp.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                        orderby mbp.MemberBillingPaymentID descending
                        select new MemberBillingPaymentViewModel()
                        {
                            MemberBillingPaymentID = mbp.MemberBillingPaymentID,
                            MemberName = mem.DisplayName,
                            AccountNumber = mbp.AccountNumber,
                            AccountTypeID = mbp.AccountTypeID,
                            BankName = mbp.BankName,
                            CVS = mbp.CVS,
                            EffectiveDate = mbp.EffectiveDate,
                            ExpirationMonth = mbp.ExpirationMonth,
                            ExpirationYear = mbp.ExpirationYear,
                            InvoiceTypeID = mbp.InvoiceTypeID,
                            MemberID = mbp.MemberID,
                            NameOnAccount = mbp.NameOnAccount,
                            RoutingNumber = mbp.RoutingNumber,
                            TermDate = (mbp.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : mbp.TermDate,
                            InvoiceType = ccode.ShortName,
                            MemberCode = mem.MemberCode,
                            Relationship = rel.ShortName
                        };
            return query;
        }
        #endregion
    }
}
