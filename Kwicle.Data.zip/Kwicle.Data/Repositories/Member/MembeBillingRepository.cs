﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MembeBillingRepository : BaseRepository<MemberBilling>, IMemberBillingRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public MembeBillingRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<MemberBilling> GetAllMemberBilling()
        {
            try
            {
                var res = _context.MemberBillings.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberBilling", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberBillingViewModel> GetMemberBilling(string FamilyCode)
        {
            try
            {
                var query = from b in _context.MemberBillings
                            join mem in _context.Members on b.MemberID equals mem.MemberID
                            join r in _context.RateCodes on b.RateCodeID equals r.RateCodeID
                            join c in _context.CommonCodes on r.RateTypeID equals c.CommonCodeID
                            join cs in _context.CommonCodes on r.SourceTypeID equals cs.CommonCodeID
                            join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                            where mem.FamilyCode == FamilyCode && b.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new MemberBillingViewModel()
                            {
                                MemberBillingID = b.MemberBillingID,
                                MemberID = b.MemberID,
                                MemberName = mem.DisplayName,
                                SourceType = cs.ShortName,
                                Type = c.ShortName,
                                Code = r.Code,
                                RateCodeID = b.RateCodeID,
                                Amount = r.Rate,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = (b.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : b.TermDate,
                                MemberCode = mem.MemberCode,
                                Relationship = rel.ShortName
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberBilling", ex.Message);
                return null;
            }
        }
        #endregion


    }
}
