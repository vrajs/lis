﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberCostShareRepository : BaseRepository<MemberCostShare>, IMemberCostShareRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public MemberCostShareRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Interface Methods Implementation  
        public IEnumerable<MemberCostShare> GetAllMemberCostShare()
        {
            try
            {
                var res = _context.MemberCostShares.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberCostShare", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberCostShareViewModel> GetMemberCostShare(string FamilyCode)
        {
            try
            {
                var query = from cost in _context.MemberCostShares
                            join mem in _context.Members on cost.MemberID equals mem.MemberID
                            join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                            join dtype in _context.CommonCodes on cost.DurationTypeID equals dtype.CommonCodeID
                            where mem.FamilyCode == FamilyCode && cost.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new MemberCostShareViewModel()
                            {
                                MemberCostShareID = cost.MemberCostShareID,
                                MemberID = cost.MemberID,
                                MemberName = mem.DisplayName,
                                Amount = cost.Amount,
                                Duration = cost.Duration,
                                DurationTypeID = cost.DurationTypeID,
                                EditCodeID = cost.EditCodeID,
                                EffectiveDate = cost.EffectiveDate,
                                TermDate = (cost.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : cost.TermDate,
                                MemberCode = mem.MemberCode,
                                Relationship = rel.ShortName,
                                DurationType = dtype.ShortName
                            };
                return query;

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberCostShare", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
