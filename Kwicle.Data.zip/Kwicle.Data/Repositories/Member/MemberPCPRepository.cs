﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using Kwicle.Common.Utility;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberPCPRepository : BaseRepository<MemberPCP>, IMemberPCPRepository
    {
        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public MemberPCPRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Get Methods
        public IQueryable<MemberPCPViewModel> GetMemberPCP(string FamilyCode)
        {
            var query = from mpcp in _context.MemberPCPs
                        join mem in _context.Members on mpcp.MemberID equals mem.MemberID
                        join p in _context.Providers on mpcp.PCPID equals p.ProviderID
                        join pl in _context.ProviderLocations on mpcp.ProviderLocationID equals pl.ProviderLocationID
                        from r in _context.CommonCodes.Where(x => x.CommonCodeID == mpcp.DisenrollmentReasonID).DefaultIfEmpty()
                        join memrel in _context.CommonCodes on mem.RelationshipID equals memrel.CommonCodeID
                        where mem.FamilyCode == FamilyCode && mpcp.RecordStatus != (int)RecordStatus.Deleted
                        orderby (mem.RelationshipID == (int)MemberRelationship.Self) ? 0 : 1
                        select new MemberPCPViewModel()
                        {
                            MemberPCPID = mpcp.MemberPCPID,
                            MemberName = mem.DisplayName,
                            DisenrollmentReasonID = mpcp.DisenrollmentReasonID,
                            EffectiveDate = mpcp.EffectiveDate,
                            IsPrimary = mpcp.IsPrimary,
                            PCPID = mpcp.PCPID,
                            ProviderLocationID = mpcp.ProviderLocationID,
                            ProviderMappingID = (int)mpcp.ProviderMappingID,
                            TermDate = (mpcp.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : mpcp.TermDate,
                            MemberCode = mem.MemberCode,
                            PCPName = p.FullName,
                            ProviderAddress1 = pl.Location.Address1,
                            CSZ = pl.Location.City + ", " + pl.Location.State + " " + pl.Location.Zip,
                            MemberID = mpcp.MemberID,
                            DisenrollmentReason = r.ShortName,
                            RecordStatusOrder = (mpcp.RecordStatus == 0 ? 1 : mpcp.RecordStatus == 2 ? 2 : mpcp.RecordStatus == 4 ? 3 : mpcp.RecordStatus == 1 ? 4 : 5),
                            Relationship = memrel.ShortName,
                        };
            return query;
        }

        public IQueryable<MemberProviderViewModel> GetProviderForMember(int MemberID)
        {
            int memberAge = -1;
            string memberGender = string.Empty;
            int? memberEligibilityID = -1;
            // Get member and set age, gender
            Kwicle.Core.Entities.MemberStructure.Member entMember = _context.Members.Where(e => e.MemberID == MemberID).FirstOrDefault();
            if (entMember != null)
            {
                memberAge = entMember.DOB.GetAge();
                memberEligibilityID = entMember.MemberEligibilityID;
                if (entMember.GenderID == (int)Gender.Male)
                    memberGender = "m";
                else if (entMember.GenderID == (int)Gender.Female)
                    memberGender = "f";
            }

            // Get Providers
            var query = from p in _context.Providers
                        join pe in _context.ProviderEligibilities on p.ProviderID equals pe.ProviderID
                        join gc in _context.GroupProviderContracts on p.ProviderID equals gc.ProviderID
                        join g in _context.Providers on gc.GroupID equals g.ProviderID
                        join plob in _context.ProviderContractLobs on gc.ProviderContractID equals plob.ProviderContractID
                        join me in _context.MemberEligibilitys on plob.LOBID equals me.LOBID
                        join pl in _context.ProviderLocations on new { gc.GroupID, gc.ProviderID } equals new { GroupID = pl.GroupID.Value, pl.ProviderID }
                        where me.MemberEligibilityID.Equals(memberEligibilityID) &&
                              pl.RecordStatus == (int)RecordStatus.Active &&
                              pl.Location.LocationTypeID == (int)PCPLocation.Office &&
                              pl.Location.IsAcceptingNewPatient == true &&
                              pl.Location.IsPCP == true &&
                              pl.Location.GenderRestriction.ToLower() != memberGender &&
                              memberAge >= pl.Location.MinimumAge && memberAge <= pl.Location.MaximumAge &&
                              p.IsPCP == true && p.RecordStatus == (int)RecordStatus.Active &&
                              pe.RecordStatus == (int)RecordStatus.Active &&
                              gc.RecordStatus == (int)RecordStatus.Active
                        orderby p.FullName ascending
                        select new MemberProviderViewModel()
                        {
                            ProviderID = p.ProviderID,
                            ProviderTypeID = p.ProviderTypeID,
                            ProviderCode = p.ProviderCode,
                            Title = p.Title,
                            LastName = p.LastName,
                            FirstName = p.FirstName,
                            FullName = p.FullName,
                            Dob = p.DOB,
                            NPI = (p.NPI == string.Empty) ? "N/A" : p.NPI,
                            Phone = p.Phone,
                            PrimaryEmail = p.PrimaryEmail,
                            IsPCP = p.IsPCP,
                            IsSpecialist = p.IsSpecialist,
                            IsProviderWatch = p.IsProviderWatch,
                            IsPerson = p.IsPerson,
                            GroupName = g.FullName,
                            RowGuid = (p.ProviderID.ToString() + g.ProviderID.ToString())
                        };
            return query;
        }


        public IQueryable<MemberProviderLocationViewModel> GetProviderLocationForMember(int ProviderID, int MemberID)
        {
            int memberAge = -1;
            string memberGender = string.Empty;

            // Get member and set age, gender
            Kwicle.Core.Entities.MemberStructure.Member entMember = _context.Members.Where(e => e.MemberID == MemberID).FirstOrDefault();
            if (entMember != null)
            {
                memberAge = entMember.DOB.GetAge();
                if (entMember.GenderID == (int)Gender.Male)
                    memberGender = "m";
                else if (entMember.GenderID == (int)Gender.Female)
                    memberGender = "f";
            }

            var query = from pl in _context.ProviderLocations
                        where pl.ProviderID == ProviderID && pl.RecordStatus == (int)RecordStatus.Active && pl.Location.LocationTypeID == (int)PCPLocation.Office &&
                                         pl.Location.IsAcceptingNewPatient == true && pl.Location.IsPCP == true && pl.Location.GenderRestriction.ToLower() != memberGender &&
                                         memberAge >= pl.Location.MinimumAge && memberAge <= pl.Location.MaximumAge
                        orderby pl.Location.Address1 ascending
                        select new MemberProviderLocationViewModel()
                        {
                            ProviderLocationID = pl.ProviderLocationID,
                            LocationName = pl.Location.LocationName,
                            Address1 = pl.Location.Address1,
                            Address2 = pl.Location.Address2,
                            City = (pl.Location.City == string.Empty) ? "N/A" : pl.Location.City,
                            State = (pl.Location.State == string.Empty) ? "N/A" : pl.Location.State,
                            County = pl.Location.County,
                            Country = pl.Location.Country,
                            Zip = (pl.Location.Zip == string.Empty) ? "N/A" : pl.Location.Zip,
                        };
            return query;
        }

        public List<MemberPCPProviderAndLocationViewModel> GetMemberPCPProviderAndLocation(string FamilyCode)
        {
            var query = from mpcp in _context.MemberPCPs
                        join mem in _context.Members on mpcp.MemberID equals mem.MemberID
                        join p in _context.Providers on mpcp.PCPID equals p.ProviderID
                        join pl in _context.ProviderLocations on mpcp.ProviderLocationID equals pl.ProviderLocationID
                        where mem.FamilyCode == FamilyCode && mpcp.RecordStatus != (int)RecordStatus.Deleted
                        orderby mpcp.MemberPCPID descending
                        select new MemberPCPProviderAndLocationViewModel()
                        {
                            MemberPCPID = mpcp.MemberPCPID,
                            MemberID = mpcp.MemberID,
                            Provider = new MemberProviderViewModel()
                            {
                                ProviderID = p.ProviderID,
                                ProviderTypeID = p.ProviderTypeID,
                                ProviderCode = p.ProviderCode,
                                Title = p.Title,
                                LastName = p.LastName,
                                FirstName = p.FirstName,
                                FullName = p.FullName,
                                Dob = p.DOB,
                                NPI = (p.NPI == string.Empty) ? "N/A" : p.NPI,
                                Phone = p.Phone,
                                PrimaryEmail = p.PrimaryEmail,
                                IsPCP = p.IsPCP,
                                IsSpecialist = p.IsSpecialist,
                                IsProviderWatch = p.IsProviderWatch,
                                IsPerson = p.IsPerson,
                                RowGuid = (p.ProviderID.ToString() + pl.GroupID.ToString())
                            },
                            ProviderLocation = new MemberProviderLocationViewModel()
                            {
                                ProviderLocationID = pl.ProviderLocationID,
                                LocationName = pl.Location.LocationName,
                                Address1 = pl.Location.Address1,
                                Address2 = pl.Location.Address2,
                                City = (pl.Location.City == string.Empty) ? "N/A" : pl.Location.City,
                                State = (pl.Location.State == string.Empty) ? "N/A" : pl.Location.State,
                                County = pl.Location.County,
                                Country = pl.Location.Country,
                                Zip = (pl.Location.Zip == string.Empty) ? "N/A" : pl.Location.Zip,
                                ProviderID = mpcp.PCPID
                            },
                        };
            return query.ToList();
        }


        public MemberPCPViewModel GetPrimaryActivePCP(int MemberID)
        {
            var query = from mpcp in _context.MemberPCPs
                        join mem in _context.Members on mpcp.MemberID equals mem.MemberID
                        join p in _context.Providers on mpcp.PCPID equals p.ProviderID
                        join pl in _context.ProviderLocations on mpcp.ProviderLocationID equals pl.ProviderLocationID
                        from r in _context.CommonCodes.Where(x => x.CommonCodeID == mpcp.DisenrollmentReasonID).DefaultIfEmpty()
                        where mem.MemberID == MemberID && mpcp.RecordStatus == (int)RecordStatus.Active && mpcp.IsPrimary == true
                        select new MemberPCPViewModel()
                        {
                            MemberPCPID = mpcp.MemberPCPID,
                            MemberName = mem.FirstName,
                            DisenrollmentReasonID = mpcp.DisenrollmentReasonID,
                            EffectiveDate = mpcp.EffectiveDate,
                            IsPrimary = mpcp.IsPrimary,
                            PCPID = mpcp.PCPID,
                            ProviderLocationID = mpcp.ProviderLocationID,
                            ProviderMappingID = (int)mpcp.ProviderMappingID,
                            TermDate = (mpcp.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : mpcp.TermDate,
                            MemberCode = mem.MemberCode,
                            PCPName = p.FullName,
                            ProviderAddress1 = pl.Location.Address1,
                            CSZ = pl.Location.City + ", " + pl.Location.State + " " + pl.Location.Zip,
                            MemberID = mpcp.MemberID,
                            DisenrollmentReason = r.ShortName
                        };
            return query.FirstOrDefault();
        }
        #endregion
    }
}
