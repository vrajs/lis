﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberNotesRepository : BaseRepository<MemberNote>, IMemberNotesRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public MemberNotesRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<MemberNote> GetAllMemberNotes()
        {
            try
            {
                var res = _context.MemberNotes.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberNotes", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberNotesViewModel> GetMemberNotes(string FamilyCode)
        {
            try
            {
                var query = from m in _context.MemberNotes
                            join mem in _context.Members on m.MemberID equals mem.MemberID
                            join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                            where mem.FamilyCode == FamilyCode && m.RecordStatus != (int)RecordStatus.Deleted && mem.RecordStatus == (int)RecordStatus.Active
                            select new MemberNotesViewModel
                            {
                                MemberNoteID = m.MemberNoteID,
                                MemberID = m.MemberID,
                                MemberName = mem.DisplayName,
                                ShortDescription = m.ShortDesc,
                                LongDescription = m.LongDesc,
                                NoteDate = m.NoteDate,
                                UserInitials = m.CreatedBy,
                                EffectiveDate = m.EffectiveDate,
                                TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                                MemberCode = mem.MemberCode,
                                Relationship = rel.ShortName
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetMemberNotes", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
