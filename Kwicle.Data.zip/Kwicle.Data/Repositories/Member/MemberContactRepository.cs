﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberContactRepository : BaseRepository<MemberContact>, IMemberContactRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public MemberContactRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<MemberContact> GetAllMemberContact()
        {
            try
            {
                var res = _context.MemberContacts.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberContacts", ex.Message);
                return null;
            }
        }

        public IQueryable<MemberContactViewModel> GetMemberContact(int MemberID)
        {
            try
            {
                var query = from m in _context.MemberContacts
                            join c in _context.CommonCodes on m.ContactTypeID equals c.CommonCodeID
                            join r in _context.CommonCodes on m.RelationshipID equals r.CommonCodeID
                            join mem in _context.Members on m.MemberID equals mem.MemberID
                            where m.MemberID == MemberID && m.RecordStatus != (int)RecordStatus.Deleted
                            select new MemberContactViewModel()
                            {
                                MemberContactID = m.MemberContactID,
                                MemberID = m.MemberID,
                                ContactTypeID = m.ContactTypeID,
                                RelationshipID = m.RelationshipID,
                                ContactName = m.ContactName,
                                Address1 = m.Address1,
                                Address2 = m.Address2,
                                City = m.City,
                                State = m.State,
                                Country = m.Country,
                                County = m.County,
                                Zip = m.Zip,
                                HomePhone = m.HomePhone,
                                WorkPhone = m.WorkPhone,
                                MobilePhone = m.MobilePhone,
                                Email = m.Email,
                                IsPrimary = m.IsPrimary,
                                EffectiveDate = m.EffectiveDate,
                                TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                                ContactType = c.ShortName,
                                Relationship = r.ShortName,
                                MemberCode = mem.MemberCode
                            };
                return query;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetMemberContacts", ex.Message);
                return null;
            }
        }

        public List<MemberContactViewModel> GetMemberContactByType(string FamilyCode, int ContactTypeID)
        {
            var query = from m in _context.MemberContacts
                        join c in _context.CommonCodes on m.ContactTypeID equals c.CommonCodeID
                        join r in _context.CommonCodes on m.RelationshipID equals r.CommonCodeID
                        join mem in _context.Members on m.MemberID equals mem.MemberID
                        join memrel in _context.CommonCodes on mem.RelationshipID equals memrel.CommonCodeID
                        where mem.FamilyCode == FamilyCode && m.ContactTypeID == ContactTypeID && m.RecordStatus != (int)RecordStatus.Deleted
                        orderby m.IsPrimary descending, m.RecordStatus ascending
                        select new MemberContactViewModel()
                        {
                            MemberContactID = m.MemberContactID,
                            MemberID = m.MemberID,
                            ContactTypeID = m.ContactTypeID,
                            RelationshipID = m.RelationshipID,
                            ContactName = m.ContactName,
                            Address1 = m.Address1,
                            Address2 = m.Address2,
                            City = m.City,
                            State = m.State,
                            Country = m.Country,
                            County = m.County,
                            Zip = m.Zip,
                            HomePhone = m.HomePhone,
                            WorkPhone = m.WorkPhone,
                            MobilePhone = m.MobilePhone,
                            Email = m.Email,
                            IsPrimary = m.IsPrimary,
                            EffectiveDate = m.EffectiveDate,
                            TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                            ContactType = c.ShortName,
                            Relationship = r.ShortName,
                            MemberCode = mem.MemberCode,
                            RecordStatus = m.RecordStatus,
                            MemberName = mem.DisplayName,
                            MemberRelationship = memrel.ShortName
                        };
            return query.ToList();
        }


        public MemberContactViewModel GetMemberActiveMailingContact(int MemberID)
        {
            var query = from m in _context.MemberContacts
                        join c in _context.CommonCodes on m.ContactTypeID equals c.CommonCodeID
                        join r in _context.CommonCodes on m.RelationshipID equals r.CommonCodeID
                        join mem in _context.Members on m.MemberID equals mem.MemberID
                        where m.MemberID == MemberID && m.ContactTypeID == (int)ContactType.Mailing && m.RecordStatus == (int)RecordStatus.Active
                        select new MemberContactViewModel()
                        {
                            MemberContactID = m.MemberContactID,
                            MemberID = m.MemberID,
                            ContactTypeID = m.ContactTypeID,
                            RelationshipID = m.RelationshipID,
                            ContactName = m.ContactName,
                            Address1 = m.Address1,
                            Address2 = m.Address2,
                            City = m.City,
                            State = m.State,
                            Country = m.Country,
                            County = m.County,
                            Zip = m.Zip,
                            HomePhone = m.HomePhone,
                            WorkPhone = m.WorkPhone,
                            MobilePhone = m.MobilePhone,
                            Email = m.Email,
                            IsPrimary = m.IsPrimary,
                            EffectiveDate = m.EffectiveDate,
                            TermDate = (m.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : m.TermDate,
                            ContactType = c.ShortName,
                            Relationship = r.ShortName,
                            MemberCode = mem.MemberCode,
                            RecordStatus = m.RecordStatus
                        };
            return query.FirstOrDefault();
        }
        #endregion
    }
}
