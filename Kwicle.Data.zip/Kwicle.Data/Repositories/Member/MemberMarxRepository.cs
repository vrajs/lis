﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Contracts.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberMarxRepository: BaseRepository<MemberPreEnrollment>, IMemberEnrollmentMarxRepository
    {
        private readonly KwicleContext _context;
        public MemberMarxRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public async Task<MemberEnrollmentList[]> GetMemberEnrollmentMarxFiles(MemberEnrollmentSearchModel model)
        {
                int ECmsReady = Convert.ToInt32(ApplicationStatus.ECmsReady);
                int IsActive = Convert.ToInt32(RecordStatus.Active);
                var EnrollmentList = (from MT in _context.MemberTransactionDetails
                                      join M in _context.Members on MT.MemberID equals M.MemberID
                                      where MT.TransactionStatusID == ECmsReady && MT.RecordStatus == IsActive
                                      select new MemberEnrollmentList
                                      {
                                          memberTransactionDetailId = MT.MemberTransactionDetailID,
                                          mbi = M.MedicareNumber,
                                          TransactionStatusID = MT.TransactionStatusID,
                                          RecordStatus = MT.RecordStatus,
                                          ContractId = MT.ContractID,
                                          TransactionTypeId = MT.TransactionTypeID,
                                          EffectiveDate = (MT.EffectiveDate == null) ? MT.TermDate : MT.EffectiveDate,
                                          PBPID = MT.PBPID,
                                          lastName = M.LastName,
                                          firstName = M.FirstName,
                                          transTypeCode = MT.TransactionType.Code + " - " + MT.TransactionType.ShortName,
                                          contractIdAndPBP = "H4869 - " + MT.PBP.Code
                                      });


                if (model.PBPID != 0)
                {
                    EnrollmentList = EnrollmentList.Where(x => x.PBPID == model.PBPID);

                }

                if (model.ContractID != 0)
                {
                    EnrollmentList = EnrollmentList.Where(x => x.ContractId == model.ContractID);
                }

                if (!string.IsNullOrEmpty(model.TransactionTypeId))
                {
                    var list =  model.TransactionTypeId.Split(',').ToList();
                    EnrollmentList = EnrollmentList.Where(x => list.Contains(x.TransactionTypeId.ToString()));
                }
                if (model.EffectiveDate != null)
                {
                      EnrollmentList = EnrollmentList.Where(x => x.EffectiveDate == model.EffectiveDate);
                    //EnrollmentList = EnrollmentList.Where(x => x.EffectiveDate == null || x.EffectiveDate >= model.EffectiveDate);
                }

                return EnrollmentList.Skip(model.skip).Take(model.take).ToArray();
            
        }

        public async Task<string> GetPipelineName(int tranTypeId)
        {
            int ConfigurationDtlId = ConfigurationDetail.GetValueByKey(tranTypeId);
            string strPipeLineName = _context.DataFileProcessConfigurationDetails.Where(x => x.DataFileProcessConfigurationId == ConfigurationDtlId).Select(x => x.ProcessApp).FirstOrDefault().ToString();
            return strPipeLineName;


        }
    }
}
