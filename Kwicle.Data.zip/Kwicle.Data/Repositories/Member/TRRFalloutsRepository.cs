﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Member
{
    public class TRRFalloutsRepository : BaseRepository<vwTRRFallouts>, ITRRFalloutsRepository
    {
        private readonly KwicleContext _context;
        public TRRFalloutsRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public async Task<bool> UpdateFalloutStatusAsync(MemberTRRUpdateModel updateModel)
        {
            var trrDetail = _context.TRRDetailLayouts.Where(x => x.TRRDetailLayoutID == updateModel.TRRDetailLayoutID).ToList();
            if(trrDetail.Count > 0)
            {
                trrDetail.ForEach(x => x.TRRFalloutStatus = updateModel.FalloutStatus);
                _context.SaveChanges();
                return await Task.FromResult(true);
            }
            else
            {
                return await Task.FromResult(false);
            }
        }

        public async Task<List<vwTRRFallouts>> GetTRRFalloutsAsync(MemberTRRSearchModel searchModel)
        {
            try
            {
                vwTRRFalloutsListViewModel objListViewModel = new vwTRRFalloutsListViewModel();
                Dictionary<int, object> filters = new Dictionary<int, object>();
                var query = (from a in _context.VwTRRFallouts.AsQueryable() select a);
                if (searchModel.MBI != "")
                {
                    query = query.Where(x => x.MBI == searchModel.MBI);
                }
                if (searchModel.MemberID != "")
                {
                    query = query.Where(x => x.MemberID == Convert.ToInt32(searchModel.MemberID));
                }
                if (searchModel.TRC != "")
                {
                    query = query.Where(x => x.TransactionReplyCode == searchModel.TransactionReplyCode);
                }
                if (searchModel.TransactionReplyCode != "")
                {
                    query = query.Where(x => x.TransactionCode == searchModel.TRC);
                }
                if (searchModel.FalloutReason != "")
                {
                    query = query.Where(x => x.FalloutReason == searchModel.FalloutReason);
                }
                if (searchModel.FalloutStatus != null && searchModel.FalloutStatus != "")
                {
                    query = query.Where(x => x.TRRFalloutStatus == Convert.ToInt32(searchModel.FalloutStatus));
                }
                if (searchModel.PlanID != null && searchModel.PlanID != "")
                {
                    query = query.Where(x => x.PBPID == Convert.ToInt32(searchModel.PlanID));
                }
                if (searchModel.TransactionDate != null && searchModel.TransactionDate != "")
                {
                    query = query.Where(x => x.TransactionDate == Convert.ToDateTime(searchModel.TransactionDate));
                }
                int countTotalRecords = query.Count();
                var data = OrderBy(query, searchModel.orderByColumn, searchModel.isDesc).Skip(searchModel.skip).Take(searchModel.take).ToList();
                return await Task.FromResult(data);
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetFileTemplateDetails", ex.Message);
                return null;
            }
        }

        public IEnumerable<TEntity> OrderBy<TEntity>(IEnumerable<TEntity> source, string orderByProperty, bool desc)
        {
            string command = desc ? "OrderByDescending" : "OrderBy";
            var type = typeof(TEntity);
            var property = type.GetProperty(orderByProperty);
            var parameter = Expression.Parameter(type, "p");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);
            var resultExpression = Expression.Call(typeof(Queryable), command,
                                                   new[] { type, property.PropertyType },
                                                   source.AsQueryable().Expression,
                                                   Expression.Quote(orderByExpression));
            var data = source.AsQueryable().Provider.CreateQuery<TEntity>(resultExpression);
            var list = data.ToList();
            return data;
        }

        private Expression<Func<TEntity, bool>> GetExpression<TEntity>(IEnumerable<TEntity> source, Dictionary<int, object> filters)
        {
            var type = typeof(TEntity);
            var parameter = Expression.Parameter(type, "p");
            Expression propertyValueClause = null;
            Expression propertyValueClause_Collection = null;
            MethodInfo ContainsMethod = typeof(string).GetMethod("Contains", new[] { typeof(string) });
            int columnCount = -1;
            foreach (KeyValuePair<int, object> filter in filters)
            {
                var columnName = (((string, string, string))filter.Value).Item1;
                object key_Value = (((string, string, string))filter.Value).Item2;
                var key_condition = (((string, string, string))filter.Value).Item3;

                var propertyInfo = Expression.Property(parameter, columnName);

                Type[] targetTypes = { typeof(SByte), typeof(Int16), typeof(Int32),
                             typeof(Int64), typeof(Byte), typeof(UInt16),
                             typeof(UInt32), typeof(UInt64), typeof(Decimal),
                             typeof(Single), typeof(Double), typeof(String), typeof(DateTime), typeof(Nullable) };

                foreach (Type targetType in targetTypes)
                {
                    if (propertyInfo.Type.Name == targetType.Name)
                    {
                        columnCount = columnCount + 1;
                        key_Value = Convert.ChangeType(key_Value, targetType);
                        if (key_condition.ToLower() == "equal")
                        {
                            propertyValueClause = Expression.Equal(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "lessthan")
                        {
                            propertyValueClause = Expression.LessThan(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "lessthanorequal")
                        {
                            propertyValueClause = Expression.LessThanOrEqual(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "greaterthan")
                        {
                            propertyValueClause = Expression.GreaterThan(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "greaterthanorequal")
                        {
                            propertyValueClause = Expression.GreaterThanOrEqual(propertyInfo, Expression.Constant(key_Value));
                        }
                        else if (key_condition.ToLower() == "contains")
                        {
                            propertyValueClause = Expression.Call(propertyInfo, ContainsMethod, Expression.Constant(key_Value));
                        }
                        if (columnCount > 0)
                        {
                            propertyValueClause_Collection = Expression.AndAlso(propertyValueClause_Collection, propertyValueClause);
                        }
                        else
                        {
                            propertyValueClause_Collection = propertyValueClause;
                        }
                        break;
                    }
                }
            }
            return Expression.Lambda<Func<TEntity, bool>>(propertyValueClause_Collection, parameter);
        }

    }
}
