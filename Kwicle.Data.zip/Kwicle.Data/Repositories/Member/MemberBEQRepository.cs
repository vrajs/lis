﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.Entities.MemberStructure.View;
using Kwicle.Data.Contracts.Member;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Member
{
    public class MemberBEQRepository : BaseRepository<MemberPreEnrollment>, IMemberEnrollmentBEQRepository
    {
        private readonly KwicleContext _context;
        private readonly IMemberEnrollmentHeaderRepository _MemberEnrollmentHeaderRepository;
        public MemberBEQRepository(KwicleContext context, IMemberEnrollmentHeaderRepository MemberEnrollmentHeaderRepository) : base(context)
        {
            _context = context;
            _MemberEnrollmentHeaderRepository = MemberEnrollmentHeaderRepository;
        }

        public async Task<int> GetMemberByMBI(string MBI)
        {
            try
            {
                MemberEnrollmentViewModel enrollmentResult = new MemberEnrollmentViewModel();
                var entityMember = _context.Members.Where(x => x.MedicareNumber == MBI).FirstOrDefault();

                if (entityMember != null)
                    return entityMember.MemberID;
                else
                    return 0;
            }
            catch (Exception ex)
            {

                DbState.AddErrorMessage("CanNotFindRecord", ex.Message);
                return 0;
            }

        }


        public async Task<int> InsertMemberPreEnrollment(MemberPreEnrollment model)
        {
            try
            {
                _context.MemberPreEnrollment.Add(model);
                _context.SaveChanges();

                return model.MemberID;
            }
            catch (Exception ex)
            {
                DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                return 0;
            }
        }

        public async Task<int> InsertMemberPreEnrollmentFinal(MemberPreEnrollmentTableViewModel mdlPreEnrollment)
        {
            try
            {
                Kwicle.Core.Entities.MemberStructure.Member mem = new Kwicle.Core.Entities.MemberStructure.Member();
                mem.LastName = mdlPreEnrollment.LastName;
                mem.FirstName = mdlPreEnrollment.FirstName;
                if (mdlPreEnrollment.MiddleInitial == null)
                    mem.MiddleName = "";
                else
                    mem.MiddleName = mdlPreEnrollment.MiddleInitial;
                mem.DOB = mdlPreEnrollment.DOB;
                mem.GenderID = mdlPreEnrollment.GenderID;
                mem.MedicareNumber = mdlPreEnrollment.MBI == null ? "" : mdlPreEnrollment.MBI;
                mem.DeceasedReason = "";
                mem.CreatedBy = mdlPreEnrollment.CreatedBy;
                mem.CreatedDate = mdlPreEnrollment.CreatedDate;
                mem.FamilyCode = "0";
                mem.IsAdvanceDirective = false;
                mem.IsDeceased = false;
                mem.IsExcludeFromClaimEditing = false;
                mem.IsFreezed = 0;
                mem.IsHandicap = false;
                mem.IsHippaEmail = false;
                mem.IsHippaMail = false;
                mem.IsHippaText = false;
                mem.IsHippaVoiceMessage = false;
                mem.IsTestMember = false;
                mem.MedicaidNumber = "0";
                //mem.TrackingID = GetNextSequenceNumber("EnrollTrackingId", 10).Result;
                mem.MemberCode = _MemberEnrollmentHeaderRepository.GetNextSequenceNumber("EnrollMemberId", 9).Result;
                mem.PrimaryLanguageID = 5841;
                mem.ContractID = (int)ContractID.H4869;
                mem.PBPID = (int)PBP.P001;
                mem.MemberStatusID = (int)MemberStatus.Pending;
                mem.AccessibilityFormatID = (int)AccessibiltyFormat.Regular;
                mem.Prefix = "";
                mem.PreviousName = "";
                mem.PrimaryEmail = "";
                mem.RecordStatus = 0;
                mem.RecordStatusChangeComment = "Active";
                mem.RelationshipID = 5106;
                mem.SSN = "";
                mem.SecondaryEmail = "";
                mem.Suffix = "";
                mem.MemberGUID = Guid.NewGuid();
                mem.DisplayName = "";
                mem.ApplicationStatusID = mdlPreEnrollment.ApplicationStatusID;// (int?)ApplicationStatus.EPreEnrollReady;
                mem.MemberContacts.Add(new MemberContact()
                {
                    City = mdlPreEnrollment.PermanentAddressCity,
                    State = mdlPreEnrollment.PermanentAddressState,
                    Zip = mdlPreEnrollment.PermanentAddressZip,
                    County = mdlPreEnrollment.PermanentAddressCounty,
                    ContactTypeID = (int)ContactType.Other,
                    Country = "",
                    //MemberContactID = 1,
                    Address1 = "",
                    Address2 = "",
                    ContactName = "",
                    CreatedBy = mdlPreEnrollment.CreatedBy,
                    EffectiveDate = mdlPreEnrollment.CreatedDate,
                    Email = "",
                    HomePhone = "",
                    IsFreezed = 0,
                    IsPrimary = false,
                    MobilePhone = "",
                    RecordStatus = 1,
                    RecordStatusChangeComment = "Active",
                    RelationshipID = 1,
                    TermDate = DateTime.Now,
                    WorkPhone = "",
                    PermanentStateandCountyCode = mdlPreEnrollment.PermanentStateandCountyCode
                });
                mem.MemberCMSDetails.Add(new MemberCMSDetail()
                {
                    TrackingID = GetNextTrackingID().Result,
                    MedicarePartAEffectiveDate = mdlPreEnrollment.MedicarePartAEffectiveDate,
                    MedicarePartBEffectiveDate = mdlPreEnrollment.MedicarePartBEffectiveDate,
                    IsESRD = mdlPreEnrollment.IsESRD,
                    IsEGHP = mdlPreEnrollment.IsEGHP,
                    RecordStatus = (int)RecordStatus.Active,
                    IsFreezed = 0,
                    RecordStatusChangeComment = "Active",
                    CreatedBy = mdlPreEnrollment.CreatedBy,
                    CreatedDate = mdlPreEnrollment.CreatedDate,
                });

                mem.MemberEligibilitys.Add(new MemberEligibility()
                {
                    CompanyID = 1,
                    CoverageTypeID = 6103,
                    LOBID = 123,
                    EffectiveDate = mdlPreEnrollment.CreatedDate,
                    HealthPlanID = 1081,
                    RiskTypeID = 6206,
                    SubCompanyID = 2,
                    TermDate = DateTime.MaxValue,
                    PrimaryRxID = 0,
                    GroupName = "",
                    InsuranceMemberCode = "",
                    PolicyNumber = "",
                    RecordStatus = (int)RecordStatus.Active,
                    IsFreezed = 0,
                    RecordStatusChangeComment = RecordStatus.Active.ToString(),
                    CreatedBy = mdlPreEnrollment.CreatedBy,
                    CreatedDate = mdlPreEnrollment.CreatedDate,
                });

                mem.MemberOtherCoverages.Add(
                    new MemberOtherCoverage
                    {
                        IsEnrolledInStateMedicaid = mdlPreEnrollment.IsEnrolledInStateMedicaid,
                        RecordStatus = (int)RecordStatus.Active,
                        IsFreezed = 0,
                        RecordStatusChangeComment = RecordStatus.Active.ToString(),
                        CreatedBy = mdlPreEnrollment.CreatedBy,
                        CreatedDate = mdlPreEnrollment.CreatedDate,
                    }
                    );


                _context.Members.Add(mem);
                await _context.SaveChangesAsync();

                return mem.MemberID;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public async Task<String> GetNextTrackingID()
        {
            string TrackingID = string.Empty;
            SeqNumber trackingId = _context.SeqNumbers.Where(e => e.SettingCode == "EnrollTrackingId").FirstOrDefault();

            if (trackingId != null)
            {
                // Generate dynamic tracking and member Id's
                trackingId.LastSeqNumber = Convert.ToString((Convert.ToInt32(trackingId.LastSeqNumber) + 1).ToString().PadLeft(10, '0'));


                _context.Entry(trackingId).State = EntityState.Modified;
                await _context.SaveChangesAsync();


                TrackingID = trackingId.PreFix + trackingId.LastSeqNumber.ToString();
            }
            return TrackingID;
        }
        public async Task<MemberEnrollmentList[]> GetMemberEnrollmentBEQFiles(MemberEnrollmentSearchModel model)
        {
            int EBeqReady = Convert.ToInt32(ApplicationStatus.EBeqReady);
            int IsActive = Convert.ToInt32(RecordStatus.Active);
            var EnrollmentList = (from MT in _context.MemberTransactionDetails
                                  join M in _context.Members on MT.MemberID equals M.MemberID
                                  where MT.TransactionStatusID == EBeqReady && MT.RecordStatus == IsActive
                                  select new MemberEnrollmentList
                                  {
                                      memberTransactionDetailId = MT.MemberTransactionDetailID,
                                      mbi = M.MedicareNumber,
                                      TransactionStatusID = MT.TransactionStatusID,
                                      RecordStatus = MT.RecordStatus,
                                      ContractId = MT.ContractID,
                                      TransactionTypeId = MT.TransactionTypeID,
                                      EffectiveDate = MT.EffectiveDate,
                                      PBPID = MT.PBPID,
                                      lastName = M.LastName,
                                      firstName = M.FirstName,
                                      transTypeCode = MT.TransactionType.Code + " - " + MT.TransactionType.ShortName,
                                      contractIdAndPBP = "H4869 - " + MT.PBP.Code

                                  });


            if (model.PBPID != 0)
            {
                EnrollmentList = EnrollmentList.Where(x => x.PBPID == model.PBPID);
            }

            if (model.ContractID != 0)
            {
                EnrollmentList = EnrollmentList.Where(x => x.ContractId == model.ContractID);
            }

            //if (model.TransactionTypeId != 0)
            //{
            //    EnrollmentList = EnrollmentList.Where(x => x.TransactionTypeId == model.TransactionTypeId);
            //}
            if (model.EffectiveDate != null)
            {
                EnrollmentList = EnrollmentList.Where(x => x.EffectiveDate >= model.EffectiveDate);
            }

            return await EnrollmentList.Skip(model.skip).Take(model.take).ToArrayAsync();

        }
        public async void UpdateFileStatus(int MemTranDtlId)
        {
            // var File=_context.MemberTransactionDetails.Where(x=>x.MemberTransactionDetailID= MemTranDtlId)

        }

        public async Task<List<VwBEQdetails>> GetMemberBEQByMemberId(int MemberId)
        {
            var data = await _context.VwBEQdetails.Where(x => x.MemberID == MemberId).ToListAsync();
            return data;
        }

        public async Task<VwBEQdetails> GetBEQRequestByDetailLayoutID(int BEQRequestDetailLayoutID)
        {
            return await _context.VwBEQdetails.Where(x => x.BEQRequestDetailLayoutID == BEQRequestDetailLayoutID).FirstOrDefaultAsync();
        }

        public async Task<MemberPreEnrollment> GetMemberPreEnrollmentByMemberID(int memberID)
        {
            return await _context.MemberPreEnrollment.Where(x => x.MemberID == memberID).FirstOrDefaultAsync();
        }
    }

}
