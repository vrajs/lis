﻿using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.OrganizationRule;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Repositories.OrganizationRule
{
    public class RuleHeaderEditRuleCriteriaRepository : BaseRepository<RuleHeaderEditRuleCriteria>, IRuleHeaderEditRuleCriteriaRepository
    {
        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public RuleHeaderEditRuleCriteriaRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion
    }
}
