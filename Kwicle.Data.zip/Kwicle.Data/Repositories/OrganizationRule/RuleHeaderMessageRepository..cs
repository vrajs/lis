﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
   public class RuleHeaderMessageRepository : BaseRepository<RuleHeaderMessage>, IRuleHeaderMessageRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        public RuleHeaderMessageRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RuleHeaderMessageViewModel> GetRuleHeaderMessageByMessageType(short RuleHeaderID, byte MessageTypeID)
        {
            try
            {
                var query = from rc in _context.RuleHeaderMessage
                            where rc.RuleHeaderID == RuleHeaderID 
                            && rc.MessageTypeID==MessageTypeID
                            && rc.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderMessageViewModel()
                            {
                                RuleHeaderID = rc.RuleHeaderID,
                                RuleHeaderMessageID = rc.RuleHeaderMessageID,
                                EnglishMessage = rc.EnglishMessage,
                                AlternateLanguageMessage = rc.AlternateLanguageMessage,
                                SplashMessage = rc.SplashMessage,
                                FormNumber = rc.FormNumber,
                                MessageTypeID = rc.MessageTypeID,
                                SplashMessageEffectiveDate = rc.SplashMessageEffectiveDate,
                                LogoPath = rc.LogoPath != null ? Encoding.ASCII.GetString(rc.LogoPath) : null,
                                EnglishMessageEffectiveDate = rc.EnglishMessageEffectiveDate,
                                EnglishMessageTermDate = (rc.EnglishMessageTermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rc.EnglishMessageTermDate,
                                SplashMessageTermDate = (rc.SplashMessageTermDate == DateTime.MaxValue) ? (DateTime?)null : rc.SplashMessageTermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderMessages", ex.Message);
                return null;
            }
        }

        public IQueryable<RuleHeaderMessageViewModel> GetRuleHeaderMessages(short RuleHeaderID)
        {
            try
            {
                var query = from rc in _context.RuleHeaderMessage
                            where rc.RuleHeaderID == RuleHeaderID && rc.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderMessageViewModel()
                            {
                                RuleHeaderID = rc.RuleHeaderID,
                                RuleHeaderMessageID = rc.RuleHeaderMessageID,
                                EnglishMessage=rc.EnglishMessage,
                                AlternateLanguageMessage=rc.AlternateLanguageMessage,
                                SplashMessage=rc.SplashMessage,
                                FormNumber=rc.FormNumber,
                                MessageTypeID=rc.MessageTypeID,
                                SplashMessageEffectiveDate=rc.SplashMessageEffectiveDate,
                                LogoPath= rc.LogoPath != null ? Encoding.ASCII.GetString(rc.LogoPath) : null,
                                EnglishMessageEffectiveDate = rc.EnglishMessageEffectiveDate,
                                EnglishMessageTermDate = (rc.EnglishMessageTermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rc.EnglishMessageTermDate,
                                SplashMessageTermDate = (rc.SplashMessageTermDate == DateTime.MaxValue) ? (DateTime?)null : rc.SplashMessageTermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderMessages", ex.Message);
                return null;
            }
        }
    }
}
