﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
   public class RuleHeaderClaimAddressRepository : BaseRepository<RuleHeaderClaimAddress>, IRuleHeaderClaimAddressRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        public RuleHeaderClaimAddressRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RuleHeaderClaimAddressViewModel> GetRuleHeaderClaimAddress(short RuleHeaderID)
        {
            try
            {
                var query = from rc in _context.RuleHeaderClaimAddress
                            where rc.RuleHeaderID == RuleHeaderID && rc.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderClaimAddressViewModel()
                            {
                                RuleHeaderID = rc.RuleHeaderID,
                                RuleHeaderClaimAddressID = rc.RuleHeaderClaimAddressID,
                                Name=rc.Name,
                                Address1 = rc.Address1,
                                Address2=rc.Address2,
                                City=rc.City,
                                State=rc.State,
                                County=rc.County,
                                Country=rc.Country,
                                Zip=rc.Zip,
                                Email=rc.Email,
                                Fax=rc.Fax,
                                Phone=rc.Phone,
                                EffectiveDate = rc.EffectiveDate,
                                TermDate = (rc.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rc.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderClaimAddress", ex.Message);
                return null;
            }
        }
    }
}
