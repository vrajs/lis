﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
   public class RuleHeaderFeeScheduleRepository : BaseRepository<RuleHeaderFeeSchedule>, IRuleHeaderFeeScheduleRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        public RuleHeaderFeeScheduleRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RuleHeaderFeeScheduleViewModel> GetRuleHeaderFeeSchedules(short RuleHeaderID)
        {
            try
            {
                var query = from rf in _context.RuleHeaderFeeSchedule
                            join ct in _context.Contracts on rf.ContractID equals ct.ContractID
                            where rf.RuleHeaderID == RuleHeaderID && rf.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderFeeScheduleViewModel()
                            {
                                RuleHeaderID = rf.RuleHeaderID,
                                RuleHeaderFeeScheduleID = rf.RuleHeaderFeeScheduleID,
                                ContractID = rf.ContractID,
                                ContractDescription = ct.ContractDescription,
                                ProviderTypeID=rf.ProviderTypeID,
                                ClaimTypeID=rf.ClaimTypeID,
                                EffectiveDate = rf.EffectiveDate,
                                TermDate = (rf.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rf.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderFeeSchedules", ex.Message);
                return null;
            }
        }
    }
}
