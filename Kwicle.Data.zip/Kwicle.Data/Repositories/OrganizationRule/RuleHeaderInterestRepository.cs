﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
    public class RuleHeaderInterestRepository : BaseRepository<RuleHeaderInterest>, IRuleHeaderInterestRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        public RuleHeaderInterestRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RuleHeaderInterestViewModel> GetRuleHeaderInterests(short RuleHeaderID)
        {
            try
            {
                var query = from ri in _context.RuleHeaderInterest
                            join iqp in _context.InterestQuickPays on ri.InterestQuickPayID equals iqp.InterestQuickPayID
                            where ri.RuleHeaderID == RuleHeaderID && ri.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderInterestViewModel()
                            {
                                RuleHeaderID = ri.RuleHeaderID,
                                RuleHeaderInterestID = ri.RuleHeaderInterestID,
                                InterestQuickPayID = ri.InterestQuickPayID,
                                Schedule = iqp.Schedule,
                                EffectiveDate = ri.EffectiveDate,
                                TermDate = (ri.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : ri.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderInterests", ex.Message);
                return null;
            }
        }
    }
}
