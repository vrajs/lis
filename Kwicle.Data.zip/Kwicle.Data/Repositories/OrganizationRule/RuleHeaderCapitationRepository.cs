﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
   public class RuleHeaderCapitationRepository : BaseRepository<RuleHeaderCapitation>, IRuleHeaderCapitationRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        public RuleHeaderCapitationRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RuleHeaderCapitationViewModel> GetRuleHeaderCapitations(short RuleHeaderID)
        {
            try
            {
                var query = from rc in _context.RuleHeaderCapitation
                            where rc.RuleHeaderID == RuleHeaderID && rc.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderCapitationViewModel()
                            {
                                RuleHeaderID = rc.RuleHeaderID,
                                RuleHeaderCapitationID = rc.RuleHeaderCapitationID,
                                CapitationTypeID = rc.CapitationTypeID,
                                ProrateMethodID = rc.ProrateMethodID,
                                AgeInDays=rc.AgeInDays,
                                AfterStartPercentage=rc.AfterStartPercentage,
                                BeforeStartPercentage=rc.BeforeStartPercentage,
                                StartDayOfMonth=rc.StartDayOfMonth,
                                EffectiveDate = rc.EffectiveDate,
                                TermDate = (rc.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rc.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderCapitations", ex.Message);
                return null;
            }
        }
    }
}
