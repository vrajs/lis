﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Microsoft.EntityFrameworkCore;
using System.Runtime.Serialization.Json;

namespace Kwicle.Data.Repositories.OrganizationRule
{
    public class RuleHeaderEditRuleRepository : BaseRepository<RuleHeaderEditRule>, IRuleHeaderEditRuleRepository
    {
        #region Property
        private readonly KwicleContext _context;
        private readonly IRuleHeaderEditRuleCriteriaRepository _ruleHeaderEditRuleCriteriaRepository;
        #endregion

        #region Constructor
        public RuleHeaderEditRuleRepository(KwicleContext context, IRuleHeaderEditRuleCriteriaRepository ruleHeaderEditRuleCriteriaRepository) : base(context)
        {
            _context = context;
            _ruleHeaderEditRuleCriteriaRepository = ruleHeaderEditRuleCriteriaRepository;
        }
        #endregion

        #region Methods
        public List<RuleHeaderEditRuleCategoryViewModel> GetCategory(short ruleHeaderID)
        {
            // Get active user define edits
            List<KeyVal<int, string>> activeUserDefineEdits = (from rul_edi in _context.RuleHeaderEditRules
                                                               join edit in _context.EditCode on rul_edi.EditCodeID equals edit.EditCodeID
                                                               where rul_edi.RuleHeaderID == ruleHeaderID
                                                                     && rul_edi.RecordStatus != (byte)RecordStatus.Deleted
                                                                     && edit.RecordStatus != (byte)RecordStatus.Deleted
                                                                     && (edit.IsFreezed == (int)FreezedStatus.NotFreezed)
                                                                     && rul_edi.IsEnabled == true
                                                               select new KeyVal<int, string>()
                                                               {
                                                                   Value = edit.Category,
                                                                   Key = rul_edi.EditCodeID,
                                                               }).ToList();

            // Get all edits categories with count
            List<RuleHeaderEditRuleCategoryViewModel> catItems = (from edit in _context.EditCode
                                                                  where edit.RecordStatus != (byte)RecordStatus.Deleted
                                                                  orderby edit.Category
                                                                  group edit by edit.Category into enaSysCatGro
                                                                  select new RuleHeaderEditRuleCategoryViewModel()
                                                                  {
                                                                      Category = enaSysCatGro.Key,
                                                                      TotalEdits = enaSysCatGro.Count()
                                                                  }).ToList();

            // Code is use for set active items as per edit category 
            catItems.ForEach(i =>
            {
                i.ActiveEdits = _context.EditCode.Count(x => x.Category == i.Category && (x.IsFreezed == (int)FreezedStatus.Freezed || x.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable) && x.RecordStatus != (byte)RecordStatus.Deleted) + activeUserDefineEdits.Count(w => w.Value == i.Category);
            });

            return catItems;
        }

        public List<RuleHeaderEditRuleViewModel> GetEdits(short ruleHeaderID, string category)
        {
            // Get Common Code value of Edit Reason, Pend, Deny code type 
            List<KeyVal<int, string>> editCommonCodes = (from edi_res in _context.CommonCodes
                                                         where (edi_res.CodeTypeID == (int)CodeType.EditReason || edi_res.CodeTypeID == (int)CodeType.ClaimPend || edi_res.CodeTypeID == (int)CodeType.ClaimDeny)
                                                         select new KeyVal<int, string>()
                                                         {
                                                             Key = edi_res.CommonCodeID,
                                                             Value = edi_res.ShortName
                                                         }).ToList();


            // Get Edit Codes
            List<RuleHeaderEditRuleViewModel> items = (from edit in _context.EditCode
                                                       join trul_edi in _context.RuleHeaderEditRules.Where(i => i.RuleHeaderID == ruleHeaderID && i.RecordStatus != (byte)RecordStatus.Deleted) on edit.EditCodeID equals trul_edi.EditCodeID into grul_edi
                                                       from rul_edi in grul_edi.DefaultIfEmpty()
                                                       where edit.Category == category && edit.RecordStatus != (byte)RecordStatus.Deleted
                                                       orderby edit.Code
                                                       select new RuleHeaderEditRuleViewModel()
                                                       {
                                                           EditCodeID = edit.EditCodeID,
                                                           Code = edit.Code,
                                                           CodeName = edit.CodeName,
                                                           RuleHeaderEditRuleID = (rul_edi != null) ? rul_edi.RuleHeaderEditRuleID : 0,
                                                           RuleHeaderID = (rul_edi != null) ? rul_edi.RuleHeaderID : Convert.ToInt16(0),
                                                           IsEnabled = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? true
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.IsEnabled : false,
                                                           OutComeID = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.DefaultOutComeID
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.OutComeID : null,
                                                           OutComeCodeID = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.DefaultOutComeCodeID
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.OutComeCodeID : null,
                                                           AdjudicationLevel = edit.AdjudicationLevel,
                                                           Priority = edit.Priority,
                                                           EffectiveDate = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.EffectiveDate
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.EffectiveDate : (DateTime?)null,
                                                           TermDate = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.TermDate
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.TermDate : (DateTime?)null,
                                                           ClaimApplyLevel = edit.ClaimApplyLevel,
                                                           IsFreezed = edit.IsFreezed
                                                       }).ToList();

            // Code for update Max Date with null & set common code value of some properites
            items.ForEach(e =>
            {
                e.TermDate = ((e.TermDate != null && Convert.ToDateTime(e.TermDate).Date != DateTime.MaxValue.Date) ? e.TermDate : (DateTime?)null);
                e.OutCome = ((e.OutComeID != null) ? editCommonCodes.Where(t => t.Key == e.OutComeID).FirstOrDefault().Value : null);
                e.OutComeDescription = ((e.OutComeCodeID != null) ? editCommonCodes.Where(t => t.Key == e.OutComeCodeID).FirstOrDefault().Value : null);
            });
            return items;
        }

        public RuleHeaderEditRuleViewModel GetByID(int EditCodeID, int RuleHeaderID)
        {
            RuleHeaderEditRuleViewModel editRule = null;

            // Get Edit Code Details
            editRule = (from edit in _context.EditCode
                        join trul_edi in _context.RuleHeaderEditRules.Where(e => e.RuleHeaderID == RuleHeaderID && e.RecordStatus != (byte)RecordStatus.Deleted) on edit.EditCodeID equals trul_edi.EditCodeID into mrul_edi
                        from rul_edi in mrul_edi.DefaultIfEmpty()
                        where edit.EditCodeID == EditCodeID
                        select new RuleHeaderEditRuleViewModel()
                        {
                            EditCodeID = edit.EditCodeID,
                            Code = edit.Code,
                            CodeName = edit.CodeName,
                            RuleHeaderEditRuleID = (rul_edi != null) ? rul_edi.RuleHeaderEditRuleID : 0,
                            RuleHeaderID = (rul_edi != null) ? rul_edi.RuleHeaderID : Convert.ToInt16(0),
                            IsEnabled = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? true
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.IsEnabled : false,
                            OutComeID = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.DefaultOutComeID
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.OutComeID : null,
                            OutComeCodeID = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.DefaultOutComeCodeID
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.OutComeCodeID : null,
                            AdjudicationLevel = edit.AdjudicationLevel,
                            Priority = edit.Priority,
                            EffectiveDate = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.EffectiveDate
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.EffectiveDate : (DateTime?)null,
                            TermDate = (edit.IsFreezed == (int)FreezedStatus.Freezed || (edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi == null)) ? edit.TermDate
                                                                      : ((edit.IsFreezed == (int)FreezedStatus.SystemEditOutcomeConfigurable && rul_edi != null) || (edit.IsFreezed == (int)FreezedStatus.NotFreezed && rul_edi != null)) ? rul_edi.TermDate : (DateTime?)null,
                            ClaimApplyLevel = edit.ClaimApplyLevel,
                            IsFreezed = edit.IsFreezed,
                        }).FirstOrDefault();


            if (editRule != null)
            {
                editRule.TermDate = (editRule.TermDate.HasValue && ((DateTime)editRule.TermDate).Date == DateTime.MaxValue.Date) ? (DateTime?)null : editRule.TermDate;

                // Get Edit Code Criteria Fields
                editRule.EditCodeCriterias = new List<RuleHeaderEditRuleCriteriaViewModel>();
                int[] dbClaimApplyLevel = new int[(editRule.ClaimApplyLevel == (int)ClaimApplyLevel.Both) ? 3 : 2];
                if (editRule.ClaimApplyLevel == (int)ClaimApplyLevel.Both)
                {
                    dbClaimApplyLevel[0] = (int)ClaimApplyLevel.Both;
                    dbClaimApplyLevel[1] = (int)ClaimApplyLevel.Header;
                    dbClaimApplyLevel[2] = (int)ClaimApplyLevel.Line;
                }
                else if (editRule.ClaimApplyLevel == (int)ClaimApplyLevel.Header)
                {
                    dbClaimApplyLevel[0] = (int)ClaimApplyLevel.Both;
                    dbClaimApplyLevel[1] = (int)ClaimApplyLevel.Header;
                }
                else if (editRule.ClaimApplyLevel == (int)ClaimApplyLevel.Line)
                {
                    dbClaimApplyLevel[0] = (int)ClaimApplyLevel.Both;
                    dbClaimApplyLevel[1] = (int)ClaimApplyLevel.Line;
                }
                editRule.CriteriaDBFields = (from db_field in _context.DBFields
                                             where db_field.IsAllowInRuleCreteria == true && dbClaimApplyLevel.Contains(db_field.ClaimApplyLevel)
                                             select new RuleHeaderEditRuleDBFieldViewModel()
                                             {
                                                 DBFieldID = db_field.DBFieldID,
                                                 ClaimApplyLevel = db_field.ClaimApplyLevel,
                                                 ControlTypeID = db_field.ControlTypeID,
                                                 FieldDisplayName = db_field.FieldDisplayName,
                                                 IsMultiSelectOptions = db_field.IsMultiSelectOptions,
                                                 IsLovs = db_field.IsLovs,
                                                 CustomLovs = db_field.CustomLovs,
                                                 AllowedOperator = db_field.AllowedOperator
                                             }).ToList();

                // Get Edit Code Criteria
                editRule.CriteriaJson = _context.RuleHeaderEditRuleCriterias.Where(e => e.RuleHeaderEditRuleID == editRule.RuleHeaderEditRuleID && e.RecordStatus != (byte)RecordStatus.Deleted).Select(e => e.CriteriaJson).FirstOrDefault();
            }

            return editRule;
        }
        #endregion


        #region Insert Or Update Methods
        public int InsertOrUpdate(RuleHeaderEditRule entRHEditRule, RuleHeaderEditRuleCriteria entRHEditRuleCriteria)
        {
            var executionStrategy = _context.Database.CreateExecutionStrategy();
            executionStrategy.Execute(
    () =>
    {
        using (var dbCTransaction = _context.Database.BeginTransaction())
        {
            try
            {
                // Code for insert and update Rule Header Edit Rule
                if (entRHEditRule.RuleHeaderEditRuleID == 0)
                {
                    _context.RuleHeaderEditRules.Add(entRHEditRule);
                    _context.SaveChanges();
                }
                else
                {
                    _context.Entry(entRHEditRule).State = EntityState.Modified;
                    _context.SaveChanges();
                }

                // Code for insert and update Rule Header Edit Rule Criteria
                if (entRHEditRuleCriteria != null)
                {
                    entRHEditRuleCriteria.RuleHeaderEditRuleID = entRHEditRule.RuleHeaderEditRuleID;
                    if (entRHEditRuleCriteria.RuleHeaderEditRuleCriteriaID == 0)
                    {
                        _context.RuleHeaderEditRuleCriterias.Add(entRHEditRuleCriteria);
                        _context.SaveChanges();
                    }
                    else
                    {
                        _context.Entry(entRHEditRuleCriteria).State = EntityState.Modified;
                        _context.SaveChanges();
                    }
                }

                // Commit transaction
                dbCTransaction.Commit();

                return entRHEditRule.RuleHeaderEditRuleID;
            }
            catch (Exception ex)
            {
                dbCTransaction.Rollback();
                base.DbState.AddErrorMessage("CanNotAddEditRule", ex.Message);
                return -1;
            }
        }
    });
        return entRHEditRule.RuleHeaderEditRuleID;
        }
        #endregion

        #region Delete
        public void Delete(int ruleHeaderEditRuleID, string UserName, DateTime TodaysDate)
        {
            using (var dbCTransaction = _context.Database.BeginTransaction())
            {
                try
                {
                    // Code for delete Edit Rule
                    var editRule = this.GetById(ruleHeaderEditRuleID);
                    editRule.UpdatedBy = UserName;
                    editRule.UpdatedDate = TodaysDate;
                    editRule.RecordStatus = (byte)RecordStatus.Deleted;
                    editRule.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                    _context.Entry(editRule).State = EntityState.Modified;

                    // Code for delete Edit Rule Criteria
                    var editRuleCriteria = _ruleHeaderEditRuleCriteriaRepository.GetByPredicate(e => e.RuleHeaderEditRuleID == ruleHeaderEditRuleID && e.RecordStatus != (byte)RecordStatus.Deleted).FirstOrDefault();
                    if (editRuleCriteria != null)
                    {
                        editRuleCriteria.UpdatedBy = UserName;
                        editRuleCriteria.UpdatedDate = TodaysDate;
                        editRuleCriteria.RecordStatus = (byte)RecordStatus.Deleted;
                        editRuleCriteria.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                        _context.Entry(editRuleCriteria).State = EntityState.Modified;
                    }

                    // Commit transaction
                    _context.SaveChanges();
                    dbCTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbCTransaction.Rollback();
                    base.DbState.AddErrorMessage("CanNotDeleteEditRule", ex.Message);
                }
            }
        }
        #endregion
    }
}
