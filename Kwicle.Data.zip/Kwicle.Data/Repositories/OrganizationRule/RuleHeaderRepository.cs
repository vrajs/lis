﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Data.Contracts.OrganizationRule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.OrganizationRule
{
    
    public class RuleHeaderRepository : BaseRepository<RuleHeader> , IRuleHeaderRepository
    {
        private readonly KwicleContext _kwicleContext;

        public RuleHeaderRepository(KwicleContext kwicleContext) : base(kwicleContext)
        {
            _kwicleContext = kwicleContext;
        }
        
    }
}
