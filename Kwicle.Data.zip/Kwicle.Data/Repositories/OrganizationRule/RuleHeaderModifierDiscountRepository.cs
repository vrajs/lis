﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
   public class RuleHeaderModifierDiscountRepository : BaseRepository<RuleHeaderModifierDiscount>, IRuleHeaderModifierDiscountRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        public RuleHeaderModifierDiscountRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RuleHeaderModifierDiscountViewModel> GetRuleHeaderModifierDiscounts(short RuleHeaderID)
        {
            try
            {
                var query = from rmd in _context.RuleHeaderModifierDiscount
                            join mdg in _context.ModifierDiscountGroups on rmd.ModifierDiscountGroupID equals mdg.ModifierDiscountGroupID
                            where rmd.RuleHeaderID == RuleHeaderID && rmd.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderModifierDiscountViewModel()
                            {
                                RuleHeaderID = rmd.RuleHeaderID,
                                RuleHeaderModifierDiscountID = rmd.RuleHeaderModifierDiscountID,
                                ModifierDiscountGroupID = rmd.ModifierDiscountGroupID,
                                Schedule = mdg.GroupName,
                                EffectiveDate = rmd.EffectiveDate,
                                TermDate = (rmd.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rmd.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetRuleHeaderModifierDiscounts", ex.Message);
                return null;
            }
        }
    }
}
