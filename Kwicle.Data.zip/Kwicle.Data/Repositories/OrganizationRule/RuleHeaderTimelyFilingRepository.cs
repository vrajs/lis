﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;
using Kwicle.Data.Contracts.OrganizationRule;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationRule
{
    public class RuleHeaderTimelyFilingRepository : BaseRepository<RuleHeaderTimelyFiling>, IRuleHeaderTimelyFiling
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public RuleHeaderTimelyFilingRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation   
        public IQueryable<RuleHeaderTimelyFilingViewModel> GetRuleHeaderTimelyFilings(short RuleHeaderID)
        {
            try
            {
                var query = from rtf in _context.RuleHeaderTimelyFiling
                            join tf in _context.TimelyFilings on rtf.TimelyFilingID equals tf.TimelyFilingID
                            where rtf.RuleHeaderID == RuleHeaderID && rtf.RecordStatus != (int)RecordStatus.Deleted
                            select new RuleHeaderTimelyFilingViewModel()
                            {
                                RuleHeaderID = rtf.RuleHeaderID,
                                RuleHeaderTimelyFilingID = rtf.RuleHeaderTimelyFilingID,
                                TimelyFilingDesc = tf.Description,
                                TimelyFilingID = rtf.TimelyFilingID,
                                EffectiveDate = rtf.EffectiveDate,
                                ScheduleDays=tf.Days,
                                TermDate = (rtf.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rtf.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotRuleHeaderTimelyFilings", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
