﻿using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderNoteRepository :  BaseRepository<Kwicle.Core.Entities.ProviderStructure.ProviderNote>, IProviderNoteRepository
    {
        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public ProviderNoteRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Get Methods
        
        #endregion
    }
}
