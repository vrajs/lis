﻿using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderCodeRepository : BaseRepository<ProviderCode>, IProviderCodeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProviderCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IQueryable<ProviderCodeViewModel> GetProviderCode(int? ProviderID, int? CodeTypeID)
        {
            var res = from n in _context.ProviderCodes.Where(x => (!ProviderID.HasValue || x.ProviderID == ProviderID) && (!CodeTypeID.HasValue || x.CodeTypeID == CodeTypeID)).OrderByDescending(x=>x.TermDate)
                      from ct in _context.CommonCodes.Where(x => x.CommonCodeID == n.CodeTypeID).DefaultIfEmpty()
                      from cont in _context.CommonCodes.Where(x => x.CommonCodeID == n.ControlTypeID).DefaultIfEmpty()
                      select new ProviderCodeViewModel()
                      {
                          ProviderCodeID = n.ProviderCodeID,
                          ProviderID = n.ProviderID,
                          CodeTypeID = n.CodeTypeID,
                          CodeTypeName = ct.ShortName,
                          CodeName = n.CodeName,
                          CodeValue = n.CodeValue,
                          ControlTypeID = n.ControlTypeID,
                          ControlTypeName = cont.ShortName,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };
            return res;
        }      
        #endregion
    }
}
