﻿using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class IPARepository :BaseRepository<IPA> , IIPARepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        public IPARepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }
        public IQueryable<vwIPA> GetIPAs()
        {
            var query = from ipa in _viewContext.GetIPAs select ipa;
            return query;
        }
    }
}
