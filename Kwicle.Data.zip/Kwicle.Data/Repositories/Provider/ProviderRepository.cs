﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.Master;
using Microsoft.EntityFrameworkCore;
using Kwicle.Data.Models;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Views;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderRepository : BaseRepository<Core.Entities.ProviderStructure.Provider>, IProviderRepository
    {
        #region Property
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Constructor
        public ProviderRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Get Methods
        public IQueryable<ProviderViewModel> GetClaimReferringPhysician()
        {
            var query = from p in _context.Providers.IgnoreQueryFilters()
                        where p.RecordStatus == (int)RecordStatus.Active && p.ProviderTypeID == (int)ProviderType.Provider
                        select new ProviderViewModel()
                        {
                            ProviderID = p.ProviderID,
                            ProviderTypeID = p.ProviderTypeID,
                            ProviderCode = p.ProviderCode,
                            Title = p.Title,
                            LastName = p.LastName,
                            FirstName = p.FirstName,
                            MiddleName = p.MiddleName,
                            Suffix = p.Suffix,
                            SSN = p.SSN,
                            FullName = p.FullName,
                            Gender = p.Gender,
                            NPI = p.NPI,
                            Phone = p.Phone,
                            Fax = p.Fax,
                            PrimaryEmail = p.PrimaryEmail,
                            SecondaryEmail = p.SecondaryEmail,
                            CredentialStatusID = p.CredentialStatusID,
                            IsPCP = p.IsPCP,
                            IsSpecialist = p.IsSpecialist,
                            IsProviderWatch = p.IsProviderWatch,
                            IsPerson = p.IsPerson,
                            Race = p.Race,
                            Ethnicity = p.Ethnicity,
                            MaxMemberCount = p.MaxMemberCount,
                            ProviderEligibilityID = p.ProviderEligibilityID,
                        };
            return query;
        }
        //public new void Update(Core.Entities.ProviderStructure.Provider Model)
        //{
        //    //using (this._context)
        //    //{
        //        try
        //        {
        //            var deletedData = _context.ProviderLanguages.Where(x => x.ProviderID == Model.ProviderID);
        //            _context.ProviderLanguages.RemoveRange(deletedData);
        //            _context.SaveChanges();
        //        }
        //        catch (Exception ex)
        //        {
        //            base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
        //        }
        //    //}
        //}
        //public IQueryable<vwProvider> GetProviders()
        //{
        //    var query = from pv in _viewContext.GetProviders
        //                select pv;
        //    return query;
        //}
        public IQueryable<vwProviderList> GetProviders()
        {
            var query = from pv in _viewContext.GetProviders
                        select pv;
            return query;
        }
        public IQueryable<vwProviderRelation> GetProviderRelation()
        {
            var query = from pr in _viewContext.vwProviderRelation
                        select pr;
            return query;
        }

        public IQueryable<ProviderLocationModel> GetProviderLocation(int ProviderID)
        {
            var res = from n in _context.ProviderLocations.Where(x => x.ProviderID == ProviderID).OrderByDescending(x=>x.TermDate)
                      select new ProviderLocationModel()
                      {
                          ProviderLocationID = n.ProviderLocationID,
                          ProviderID = n.ProviderID,
                          LocationID = n.LocationID,
                          GroupID = n.GroupID,
                          GroupProviderName = n.GroupProvider.FullName,
                          LocationName = n.Location.LocationName,
                          ProviderName = n.Provider.FullName,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                          Location = new LocationModel { LocationName = n.Location.LocationName, LocationTypeName = n.Location.LocationType.ShortName, Address1 = n.Location.Address1, Address2 = n.Location.Address2, City = n.Location.City, State = n.Location.State, Zip = n.Location.Zip }
                      };

            return res;
        }

        public IQueryable<GroupProviderContractModel> GetProviderContract(int ProviderID)
        {
            var res = from n in _context.GroupProviderContracts.Where(x => x.ProviderID == ProviderID).OrderByDescending(x=>x.TermDate)
                      select new GroupProviderContractModel()
                      {
                          GroupProviderContractID = n.GroupProviderContractID,
                          //ProviderRelationID = n.ProviderRelationID,
                          //ProviderContractID = n.ProviderContractID,
                          //ProviderID = n.ProviderID,
                          //ProviderName = n.ProviderRelation.RelatedProvider.FullName,
                          //ContractHeaderID = n.ProviderContract.ContractHeaderID,
                          ContractHeaderName = n.ProviderContract.ContractHeader.ContractName,
                          ProviderStatusName = n.ProviderContract.ProviderStatus.ShortName,
                          LOBNames = string.Join(",", n.ProviderContract.ProviderContractLobs.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.Lob.LobName)),
                          //GroupID = n.GroupID,
                          GroupProviderName = n.ProviderRelation.ParentProvider.FullName,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };
            return res;
        }

        public IQueryable<ProviderDataCheckModel> CheckProviderData(int identifierType, string identifierCode)
        {
            IQueryable<ProviderDataCheckModel> query = null;
            if (identifierType == (int)IdentifierType.GroupID)
            {
                query = _context.Providers.Where(i => i.ProviderCode.ToUpper() == identifierCode && i.ProviderTypeID == (int)GroupType.Group)
                    .Select(t => new ProviderDataCheckModel()
                    {
                        ProviderID = t.ProviderID,
                        ProviderCode = t.ProviderCode,
                        RecordStatus = t.RecordStatus,
                        EffectiveDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.EffectiveDate).FirstOrDefault(),
                        TermDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.TermDate).FirstOrDefault(),
                    });
            }
            if (identifierType == (int)IdentifierType.ProvID)
            {
                query = _context.Providers.Where(i => i.ProviderCode.ToUpper() == identifierCode && i.ProviderTypeID == (int)ProviderType.Provider)
                    .Select(t => new ProviderDataCheckModel()
                    {
                        ProviderID = t.ProviderID,
                        ProviderCode = t.ProviderCode,
                        RecordStatus = t.RecordStatus,
                        EffectiveDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.EffectiveDate).FirstOrDefault(),
                        TermDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.TermDate).FirstOrDefault(),
                    });
            }
            if (identifierType == (int)IdentifierType.NPI)
            {
                query = _context.Providers.Where(i => i.NPI.ToUpper() == identifierCode)
                    .Select(t => new ProviderDataCheckModel()
                    {
                        ProviderID = t.ProviderID,
                        ProviderCode = t.ProviderCode,
                        RecordStatus = t.RecordStatus,
                        EffectiveDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.EffectiveDate).FirstOrDefault(),
                        TermDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.TermDate).FirstOrDefault(),
                    });
            }
            if (identifierType == (int)IdentifierType.Tax)
            {
                query = (from t in _context.Providers
                         join pt in _context.ProviderTINs on t.ProviderID equals pt.ProviderID
                         where pt.TINNumber.ToString().ToUpper() == identifierCode && pt.TINTypeID == (int)TINType.TIN
                         select new ProviderDataCheckModel()
                         {
                             ProviderID = t.ProviderID,
                             ProviderCode = t.ProviderCode,
                             RecordStatus = t.RecordStatus,
                             EffectiveDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.EffectiveDate).FirstOrDefault(),
                             TermDate = t.ProviderEligibility.Where(x => x.ProviderEligibilityID == t.ProviderEligibilityID).Select(y => y.TermDate).FirstOrDefault(),
                         });
            }
            return query;
        }

        public HasProviderConfigurationDataModel CheckProviderConfigurationHasData(int providerID)
        {
            HasProviderConfigurationDataModel res = new HasProviderConfigurationDataModel();
            res.HasEligigbilityData = _context.ProviderEligibilities.Any(x => x.ProviderID == providerID && x.ProviderEligibilityID != _context.Providers.Where(t=>t.ProviderID == providerID).SingleOrDefault().ProviderEligibilityID);
            res.HasSpecialtyData = _context.ProviderSpecialties.Any(x => x.ProviderID == providerID);
            res.HasReferenceData = _context.ProviderCodes.Any(x => x.ProviderID == providerID);
            res.HasNotesData = _context.ProviderNotes.Any(x => x.ProviderID == providerID);
            res.HasProviderLocationData = _context.ProviderLocations.Any(x => x.ProviderID == providerID);
            res.HasProviderContractData = _context.GroupProviderContracts.Any(x => x.ProviderID == providerID);            
            return res;
        }

        public HasGroupConfigurationDataModel CheckGroupConfigurationHasData(int providerID)
        {
            HasGroupConfigurationDataModel res = new HasGroupConfigurationDataModel();
            res.HasEligigbilityData = _context.ProviderEligibilities.Any(x => x.ProviderID == providerID && x.ProviderEligibilityID != _context.Providers.Where(t => t.ProviderID == providerID).SingleOrDefault().ProviderEligibilityID);
            res.HasSpecialtyData = _context.ProviderSpecialties.Any(x => x.ProviderID == providerID);
            res.HasIPAData = _context.ProviderIPAs.Any(x => x.ProviderID == providerID);
            res.HasProviderRelationData = _context.ProviderRelations.Any(x => x.ParentProviderID == providerID);
            res.HasLocationData = _context.ProviderLocations.Any(x => x.ProviderID == providerID);
            res.HasProviderLocationData = _context.ProviderLocations.Any(x => x.GroupID == providerID);
            res.HasContractData = _context.ProviderContracts.Any(x => x.ProviderID == providerID);
            res.HasProviderContractData = _context.GroupProviderContracts.Any(x => x.GroupID == providerID);
            res.HasReferenceData = _context.ProviderCodes.Any(x => x.ProviderID == providerID);
            res.HasNotesData = _context.ProviderNotes.Any(x => x.ProviderID == providerID);
            res.HasEFTData = _context.ProviderEFTs.Any(x => x.ProviderID == providerID);
            res.HasTINData = _context.ProviderTINs.Any(x => x.ProviderID == providerID);
            res.HasCheckHistoryData = false;//need to implement logic when requirement will clear
            return res;
        }

        public ProviderViewModel GetView(int providerID)
        {
            var res = (from p in _context.Providers where p.ProviderID == providerID
                       join cc in _context.CommonCodes on p.ProviderTypeID equals cc.CommonCodeID
                       let pe = _context.ProviderEligibilities.Where(x=>x.ProviderEligibilityID == p.ProviderEligibilityID).SingleOrDefault()
                       let pl = _context.ProviderLanguages.Where(x => x.ProviderID == providerID).ToList()
                       select new ProviderViewModel()
                       {
                           ProviderID = p.ProviderID,
                           ProviderTypeID = p.ProviderTypeID,
                           ProviderTypeName = cc.ShortName,
                           ProviderCode = p.ProviderCode,
                           Title = p.Title,
                           LastName = p.LastName,
                           FirstName = p.FirstName,
                           MiddleName = p.MiddleName,
                           Suffix = p.Suffix,
                           FullName = p.FullName,
                           Dob = p.DOB,
                           Gender = p.Gender,
                           SSN = p.SSN,
                           NPI = p.NPI,
                           Phone = p.Phone,
                           Fax = p.Fax,
                           PrimaryEmail = p.PrimaryEmail,
                           SecondaryEmail = p.SecondaryEmail,
                           CredentialStatusID = p.CredentialStatusID,
                           IsPCP = p.IsPCP,
                           IsSpecialist = p.IsSpecialist,
                           IsProviderWatch = p.IsProviderWatch,
                           IsPerson = p.IsPerson,
                           Race = p.Race,
                           Ethnicity = p.Ethnicity,
                           MaxMemberCount = p.MaxMemberCount,
                           ProviderEligibilityID = p.ProviderEligibilityID,
                           Prefix = p.Prefix,
                           ProviderLanguage = pl.ToList(),
                           //EffectiveDate = p.ProviderEligibility.Where(x => x.ProviderEligibilityID == p.ProviderEligibilityID).Single().EffectiveDate,
                           //TermDate = p.ProviderEligibility.Where(x => x.ProviderEligibilityID == p.ProviderEligibilityID).Single().TermDate,
                           EffectiveDate = pe.EffectiveDate,
                           TermDate = pe.TermDate,
                       }).Single();
            return res;
        }

        public int CreateGroupFromProvider(int ProviderID)
        {
            
            return 0;
        }
        #endregion

        //public Provider GetProviderNameByProCode(string proCode)
        //{
        //    return _context.Providers.Where(x => x.ProviderCode == proCode && x.RecordStatus == (int)RecordStatus.Active)..ToListAsync();
        //}

        public ProviderViewModel GetProviderNameByProCode(string proCode)
        {
            try
            {
                //return _context.Providers.Where(x => x.ProviderCode == searchValue && x.RecordStatus == (int)RecordStatus.Active).ToListAsync();

                var query = (from p in _context.Providers.Where(x => x.ProviderCode == proCode && x.RecordStatus != 3)
                             select new ProviderViewModel()
                             {
                                 LastName = p.LastName,
                                 FirstName = p.FirstName,
                                 MiddleName = p.MiddleName,
                                 FullName = p.FullName,
                             }).FirstOrDefault();

                return (ProviderViewModel)query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingContries", ex.Message);
                return null;
            }
        }
    }
}
