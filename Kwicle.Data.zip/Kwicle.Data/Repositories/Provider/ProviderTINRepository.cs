﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderTINRepository : BaseRepository<ProviderTIN>, IProviderTINRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProviderTINRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IQueryable<ProviderTINViewModel> GetProviderTIN(int? ProviderID, int? TINTypeID)
        {
            var res = from n in _context.ProviderTINs.Where(x => (!ProviderID.HasValue || x.ProviderID == ProviderID) && (!TINTypeID.HasValue || x.TINTypeID == TINTypeID)).OrderByDescending(x=> x.TermDate)
                      from ct in _context.CommonCodes.Where(x => x.CommonCodeID == n.TINTypeID).DefaultIfEmpty()
                      select new ProviderTINViewModel()
                      {
                          ProviderTINID = n.ProviderTINID,
                          ProviderID = n.ProviderID,
                          TINTypeID = n.TINTypeID,
                          TINType = ct.ShortName,
                          TINNumber = n.TINNumber,
                          TINName = n.TINName,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };

            //var sql = res.ToSql();
            return res;
        }
        #endregion
    }
}
