﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Data.Extensions;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderRelationRepository : BaseRepository<ProviderRelation>, IProviderRelationRepository
    {
        private readonly KwicleContext _context;
        public ProviderRelationRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<ProviderRelationModel> GetProviderRelation(int? parentProviderID, int? relatedProviderID)
        {
            var res = from pr in _context.ProviderRelations.Where(x => (!parentProviderID.HasValue || x.ParentProviderID == parentProviderID) && (!relatedProviderID.HasValue || x.RelatedProviderID == relatedProviderID)).OrderByDescending(x=>x.TermDate)
                      from pvdr in _context.Providers.Where(x => x.ProviderID == pr.RelatedProviderID)
                      select new ProviderRelationModel()
                      {
                          ProviderRelationID = pr.ProviderRelationID,
                          ParentProviderID = pr.ParentProviderID,
                          RelatedProviderID = pr.RelatedProviderID,
                          RelatedProviderName = pr.RelatedProvider.FullName,
                          RelatedProvider = new ProviderViewModel
                          {
                              ProviderCode = pvdr.ProviderCode,
                              FullName = pvdr.FullName,
                              FirstName = pvdr.FirstName,
                              LastName = pvdr.LastName,
                              Title = pvdr.Title,
                              NPI = pvdr.NPI,
                              SSN = pvdr.SSN,
                              //Languages = pvdr.ProviderLanguage.Where(x => x.ProviderID == pvdr.ProviderID).Select(x => x.ProviderLanguages.ShortName).ToList().ToString(),
                              Languages = string.Join(",", pvdr.ProviderLanguage.Where(p => p.ProviderID == pvdr.ProviderID).Select(x => x.ProviderLanguages.ShortName.ToString())),
                              Phone = pvdr.Phone,
                              Fax = pvdr.Fax,
                              PrimaryEmail = pvdr.PrimaryEmail,
                          },
                          IsPrimaryPCP = pr.IsPrimaryPCP,
                          EffectiveDate = pr.EffectiveDate,
                          TermDate = (pr.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : pr.TermDate
                      };
            return res;
        }

        public IQueryable<int> GetRelatedProviderIDByParentProviderID(int parentProviderID)
        {
            var res = from pr in _context.ProviderRelations.Where(x => x.ParentProviderID == parentProviderID)
                      select pr.RelatedProviderID;
            return res;
        }
    }
}
