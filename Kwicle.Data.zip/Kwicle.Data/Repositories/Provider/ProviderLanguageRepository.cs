﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderLanguageRepository : BaseRepository<ProviderLanguage>, IProviderLanguageRepository
    {
        private readonly KwicleContext _context;

        public ProviderLanguageRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public List<ProviderLanguage> GetByProviderID(int providerID)
        {
            var result = (from bps in _context.ProviderLanguages
                          where bps.ProviderID == providerID
                          select new ProviderLanguage()
                          {
                              ProviderLanguageID = bps.ProviderLanguageID,
                              ProviderID = bps.ProviderID,
                              LanguageID = bps.LanguageID,                              
                              Language = bps.Language,
                              CreatedBy = bps.CreatedBy,
                              CreatedDate = bps.CreatedDate,
                              RecordStatus = bps.RecordStatus,
                              RecordStatusChangeComment = bps.RecordStatusChangeComment
                          }).ToList();
            return result;
        }
        public List<ProviderLanguage> GetLangByProviderId(int providerID)
        {
                return _context.ProviderLanguages.Where(x => x.ProviderID == providerID).ToList();
        }
    }
}
