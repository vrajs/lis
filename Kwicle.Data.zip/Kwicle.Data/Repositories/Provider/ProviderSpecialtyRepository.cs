﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderSpecialtyRepository : BaseRepository<ProviderSpecialty>, IProviderSpecialtyRepository
    {
        #region Property
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public ProviderSpecialtyRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Get Methods
        public IQueryable<ProviderSpecialtyModel> GetByProvider(int providerID)
        {
            var res = (from ps in _context.ProviderSpecialties
                       where ps.ProviderID == providerID 
                       orderby ps.TermDate descending
                       select new ProviderSpecialtyModel()
                       {
                           ProviderSpecialtyID = ps.ProviderSpecialtyID,
                           ProviderID = ps.ProviderID,
                           SpecialtyID = ps.SpecialtyID,
                           SpecialtyName = ps.Specialty.SpecialtyName,
                           IsPrimarySpecialty = ps.IsPrimarySpecialty,
                           EffectiveDate = ps.EffectiveDate,
                           TermDate = (ps.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : ps.TermDate,
                       });
            return res;
        }
        public void Add(ProviderSpecialty model, bool isPrimry)
        {
            using (this._context)
            {
                try
                {
                    if (isPrimry)
                    {
                        this.UpdateIsPrimaryFlag(model.ProviderID, model.ProviderSpecialtyID);
                    }
                    _context.Add(model);
                    _context.SaveChanges();
                    
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotAddRecord", ex.Message);
                }
            }
        }

        public void Update(ProviderSpecialty model, bool isPrimry)
        {
            using (this._context)
            {
                try
                {
                    if (isPrimry)
                    {
                        this.UpdateIsPrimaryFlag(model.ProviderID, model.ProviderSpecialtyID);
                    }
                    _context.SaveChanges();
                    
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
                }
            }
        }

        private void UpdateIsPrimaryFlag(int providerID, int providerSpecialtyID)
        {
            ProviderSpecialty updateData = _context.ProviderSpecialties.Where(x => x.ProviderID == providerID && (providerSpecialtyID == 0 ? true : x.ProviderSpecialtyID != providerSpecialtyID) && x.IsPrimarySpecialty == true).Single();
            updateData.IsPrimarySpecialty = false;
        }
        #endregion
    }
}
