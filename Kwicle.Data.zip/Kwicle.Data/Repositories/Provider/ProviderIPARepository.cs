﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Data.Extensions;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderIPARepository : BaseRepository<ProviderIPA>, IProviderIPARepository
    {
        private readonly KwicleContext _context;
        public ProviderIPARepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<ProviderIPAModel> GetProviderIPA(int? providerID, int? ipaid)
        {
            var res = (from pi in _context.ProviderIPAs where (!providerID.HasValue || pi.ProviderID == providerID) && (!ipaid.HasValue || pi.IPAID == ipaid)
                       orderby pi.TermDate descending
                       select new ProviderIPAModel()
                       {
                           ProviderIPAID = pi.ProviderIPAID,
                           ProviderID = pi.ProviderID,
                           IPAID = pi.IPAID,
                           EffectiveDate = pi.EffectiveDate,
                           TermDate = pi.TermDate.Date == DateTime.MaxValue.Date ? (DateTime?)null : pi.TermDate,
                           ipa = new IPAModel
                           {
                               IPAName = pi.IPA.IPAName,
                               ContactName = pi.IPA.ContactName,                               
                               NPI = pi.IPA.NPI,                               
                               Lobs = string.Join(",", pi.IPA.IPALOB.Where(p => p.IPAID == pi.IPA.IPAID).Select(x => x.Lob.LobName.ToString())),
                               Phone = pi.IPA.Phone,
                               Fax = pi.IPA.Fax,
                               PrimaryEmail = pi.IPA.PrimaryEmail,
                               EffectiveDate = pi.IPA.EffectiveDate,
                               TermDate = pi.IPA.TermDate.Date == DateTime.MaxValue.Date ? (DateTime?)null : pi.IPA.TermDate
                           }
                       });
            //var sql = res.ToSql();
            return res;
        }
    }
}
