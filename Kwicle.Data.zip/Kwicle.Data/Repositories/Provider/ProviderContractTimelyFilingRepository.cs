﻿using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderContractTimelyFilingRepository : BaseRepository<ProviderContractTimelyFiling> , IProviderContractTimelyFilingRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProviderContractTimelyFilingRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation           
        #endregion      
    }
}
