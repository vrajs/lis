﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Data;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderLocationRepository : BaseRepository<ProviderLocation>, IProviderLocationRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProviderLocationRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IQueryable<ProviderLocationModel> GetProviderLocation(int? ProviderID, int? ProviderLocationID)
        {
            var res = from n in _context.ProviderLocations.Where(x => (!ProviderID.HasValue || x.ProviderID == ProviderID) && (!ProviderLocationID.HasValue || x.ProviderLocationID == ProviderLocationID) && x.GroupID == null).OrderByDescending(x=>x.TermDate)
                      select new ProviderLocationModel()
                      {
                          ProviderLocationID = n.ProviderLocationID,
                          ProviderID = n.ProviderID,
                          LocationID = n.LocationID,
                          LocationName = n.Location.LocationName,
                          Provider = new ProviderViewModel { FirstName = n.Provider.FirstName, LastName = n.Provider.LastName, FullName = n.Provider.FullName },
                          Location = new LocationModel { LocationName = n.Location.LocationName, LocationTypeName = n.Location.LocationType.ShortName, Address1 = n.Location.Address1, Address2 = n.Location.Address2, City = n.Location.City, State = n.Location.State, Zip = n.Location.Zip, EffectiveDate = n.Location.EffectiveDate, TermDate = ((n.Location.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.Location.TermDate) },
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                          GroupID = n.GroupID,
                          GroupProviderName = n.GroupProvider.FullName
                      };
            return res;
        }

        public IQueryable<ProviderLocationModel> GetGroupProviderLocation(int GroupID, int? GroupLocationID)
        {
            var res = from n in _context.ProviderLocations.Where(x => x.GroupID == GroupID && (!GroupLocationID.HasValue || x.LocationID == GroupLocationID)).OrderByDescending(x=>x.TermDate)
                      select new ProviderLocationModel()
                      {
                          ProviderLocationID = n.ProviderLocationID,
                          ProviderID = n.ProviderID,
                          LocationID = n.LocationID,
                          GroupID = n.GroupID,
                          GroupProviderName = n.GroupProvider.FullName,
                          LocationName = n.Location.LocationName,
                          ProviderName = n.Provider.FullName,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                          Location = new LocationModel { CreatedBy = n.Location.CreatedBy,LocationID = n.Location.LocationID, LocationTypeID = n.Location.LocationTypeID, LocationName = n.Location.LocationName, LocationTypeName = n.Location.LocationType.ShortName, Address1 = n.Location.Address1, Address2 = n.Location.Address2, City = n.Location.City, State = n.Location.State, Zip = n.Location.Zip },
                          GroupLocationEffectiveDate = _context.ProviderLocations.Where(x => x.ProviderID == n.GroupID).Select(x => x.EffectiveDate).FirstOrDefault(),
                          GroupLocationTermDate = _context.ProviderLocations.Where(x => x.ProviderID == n.GroupID).Select(x => x.TermDate).FirstOrDefault(),
                      };

            return res;
        }

        public void DeleteOrTermGroupProviderLocation(int groupID, int? locationID, DateTime todaysDate, string userName, int recordStatus, string recordStatusChangeComment, DateTime? termDate)
        {
            try
            {

                object[] parameters = {
                    new SqlParameter("GroupID", groupID),
                    new SqlParameter("LocationID", locationID),
                    new SqlParameter("UpdatedDate",todaysDate) ,
                    new SqlParameter("UpdatedBy", userName),
                    new SqlParameter("RecordStatus", recordStatus),
                    new SqlParameter("RecordStatusChangeComment",recordStatusChangeComment),
                    new SqlParameter("TermDate",termDate),
                    new SqlParameter("ErrorMessage", SqlDbType.VarChar ,4000) {Direction = ParameterDirection.Output},

                };
                if (!locationID.HasValue)
                {
                    ((SqlParameter)parameters[1]).Value = DBNull.Value;
                }
                if (!termDate.HasValue)
                {
                    ((SqlParameter)parameters[6]).Value = DBNull.Value;
                }
                _context.Database.ExecuteSqlRaw("[hps].[usp_DeleteOrTermGroupProviderLocation]  @GroupID,@LocationID, @UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@TermDate,@ErrorMessage out", parameters);

                var errorMessage = Convert.ToString(((SqlParameter)parameters[7]).Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotPerform : RemoveBenefit", errorMessage);
                }
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : RemoveBenefit", ex.Message);

            }
        }
        #endregion
    }
}
