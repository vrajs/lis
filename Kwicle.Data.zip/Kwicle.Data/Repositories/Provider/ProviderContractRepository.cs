﻿using System.Linq;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Kwicle.Core.Common;
using System;
using Kwicle.Data.Extensions;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Common.Utility;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderContractRepository : BaseRepository<ProviderContract>, IProviderContractRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProviderContractRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation           
        public IQueryable<ProviderContractModel> GetGroupContract(int? ProviderID, int? ProviderContractID)
        {
            try
            {
                var res = from n in _context.ProviderContracts.Where(x => (!ProviderID.HasValue || x.ProviderID == ProviderID) && (!ProviderContractID.HasValue || x.ProviderContractID == ProviderContractID)).OrderByDescending(x=>x.TermDate) //&& x.GroupID == null
                          select new ProviderContractModel()
                          {
                              ProviderContractID = n.ProviderContractID,
                              ProviderID = n.ProviderID,
                              ContractHeaderID = n.ContractHeaderID,
                              ContractHeaderName = n.ContractHeader.ContractName,
                              ProviderStatusID = n.ProviderStatusID,
                              ProviderStatusName = n.ProviderStatus.ShortName,
                              IsCapitated = n.IsCapitated,
                              ModifierDiscountGroupID = n.ModifierDiscountGroupID,
                              ModifierDiscountGroupName = n.ModifierDiscountGroup.GroupName,
                              FeeScheduleHeaderID = n.FeeScheduleHeaderID,
                              FeeScheduleHeaderCode = n.FeeScheduleHeader.Code,

                              NetworkID = n.NetworkID,
                              NetworkName = n.Network.ShortName,
                              IsExcludeFromSequestration = n.IsExcludeFromSequestration,
                              LOBIds = n.ProviderContractLobs.Where(t => t.ProviderContractID == n.ProviderContractID).Select(a => new LobModel()
                              {
                                  LobID = a.Lob.LobID,
                                  LobCode = a.Lob.LobCode,
                                  LobName = a.Lob.LobName,
                                  SubmitterCode = a.Lob.SubmitterCode,
                                  CaidContractNumber = a.Lob.CaidContractNumber,
                                  CareContractNumber = a.Lob.CareContractNumber,
                                  NICNumber = a.Lob.NICNumber,
                                  EffectiveDate = a.Lob.EffectiveDate,
                                  TermDate = (a.Lob.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : a.Lob.TermDate,
                                  OrganizationID = a.Lob.SubCompanyID,
                                  OrganizationName = a.Lob.SubCompany.OrganizationName,
                                  SponsorID = a.Lob.SponsorID,
                                  SponsorName = a.Lob.Sponsor.SponsorName,
                                  CategoryID = a.Lob.CategoryID,
                                  CategoryName = a.Lob.Category.CategoryName,
                                  ProductID = a.Lob.ProductID,
                                  ProductName = a.Lob.Product.ProductName
                              }).ToArray(),
                              LOBNames = string.Join(",", n.ProviderContractLobs.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.Lob.LobName)),
                              ProviderContractLob = n.ProviderContractLobs.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => new ProviderContractLobModel { LOBID = t.LOBID, ProviderContractID = t.ProviderContractID, ProviderContractLOBID = t.ProviderContractLOBID }).ToArray(),

                              InterestQuickPayIDs = n.ProviderContractInterest.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.InterestQuickPayID).ToArray(),
                              InterestQuickPayNames = string.Join(",", n.ProviderContractInterest.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.InterestQuickPay.Schedule)),
                              ProviderContractInterest = n.ProviderContractInterest.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => new ProviderContractInterestModel { InterestQuickPayID = t.InterestQuickPayID, ProviderContractID = t.ProviderContractID, ProviderContractInterestID = t.ProviderContractInterestID }).ToArray(),

                              TimelyFilingIDs = n.ProviderContractTimelyFiling.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.TimelyFilingID).ToArray(),
                              TimelyFilingNames = string.Join(",", n.ProviderContractTimelyFiling.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.TimelyFiling.Description)),
                              ProviderContractTimelyFiling = n.ProviderContractTimelyFiling.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => new ProviderContractTimelyFilingModel { TimelyFilingID = t.TimelyFilingID, ProviderContractID = t.ProviderContractID, ProviderContractTimelyFilingID = t.ProviderContractTimelyFilingID }).ToArray(),

                              EffectiveDate = n.EffectiveDate,
                              TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,

                              //GroupID = n.GroupID,
                              //GroupProviderName = n.GroupProvider.FullName
                          };
                //var sql = res.ToSql();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerformGetOperation", ex.ToErrorMessage());
                return null;
            }
        }

        public IQueryable<ProviderContractModel> GetProviderContract(int ProviderID)
        {
            var res = from n in _context.ProviderContracts.Where(x => x.ProviderID == ProviderID)
                      select new ProviderContractModel()
                      {
                          ProviderContractID = n.ProviderContractID,                          
                          ContractHeaderID = n.ContractHeaderID,
                          ContractHeaderName = n.ContractHeader.ContractName,     
                          EffectiveDate = n.EffectiveDate,
                          LOBNames= string.Join(",",n.ProviderContractLobs.Select(x=>x.Lob.LobName)),
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };
            return res;
        }

        public new void Update(ProviderContract Model)
        {
            //using (var dbCTransaction = _context.Database.BeginTransaction())
            //{
            //    try
            //    {
            //        // Get existing claim list
            //        var lobData = _context.ProviderContractLobs.Where(x => x.ProviderContractID == Model.ProviderContractID);

            //        // Prepare insert list of 'RefundRequestClaim' table.
            //        var insert = Model.ProviderContractLobs.Where(y => lobData.Any(z => z.ProviderContractLOBID != y.ProviderContractLOBID)).ToList();

            //        // Prepare updtae list of 'RefundRequestClaim' table.
            //        var update = Model.ProviderContractLobs.Where(y => lobData.Any(z => z.ProviderContractLOBID == y.ProviderContractLOBID)).ToList();

            //        // Code for insert and update claims
            //        _context.ProviderContractLobs.AddRange(insert);
            //        _context.ProviderContractLobs.UpdateRange(update);
            //        _context.SaveChanges();

            //        // Commit transaction
            //        dbCTransaction.Commit();
            //    }
            //    catch (Exception ex)
            //    {
            //        dbCTransaction.Rollback();
            //        base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
            //    }

            //}
            try
            {
                var deletedLobData = _context.ProviderContractLobs.Where(x => x.ProviderContractID == Model.ProviderContractID);
                _context.ProviderContractLobs.RemoveRange(deletedLobData);

                var deletedInterestsData = _context.ProviderContractInterests.Where(x => x.ProviderContractID == Model.ProviderContractID);
                _context.ProviderContractInterests.RemoveRange(deletedInterestsData);

                var deletedTimelyFilingsData = _context.ProviderContractTimelyFilings.Where(x => x.ProviderContractID == Model.ProviderContractID);
                _context.ProviderContractTimelyFilings.RemoveRange(deletedTimelyFilingsData);

                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.ToErrorMessage());
            }
        }

       
    }
    #endregion
}

