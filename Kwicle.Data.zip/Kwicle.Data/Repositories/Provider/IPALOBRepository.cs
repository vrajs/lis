﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class IPALOBRepository : BaseRepository<IPALOB>, IIPALOBRepository
    {
        private readonly KwicleContext _context;
        public IPALOBRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<IPALOBModel> GetIpaLobByIPAID(int ipaID)
        {
            var res = (from il in _context.IPALOBs
                       where il.IPAID == ipaID
                       select new IPALOBModel()
                       {
                           IPALOBID = il.IPALOBID,
                           IPAID = il.IPAID,
                           LOBID = il.LOBID,
                           LobName = il.Lob.LobName,
                           PremiumPercentage = il.PremiumPercentage,
                           EffectiveDate = il.EffectiveDate,
                           TermDate = (il.TermDate.Date == DateTime.MaxValue.Date ? (DateTime?)null : il.TermDate)
                       });
            return res;
        }
    }
}
