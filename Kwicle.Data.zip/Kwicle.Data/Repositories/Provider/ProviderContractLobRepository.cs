﻿using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderContractLobRepository : BaseRepository<ProviderContractLob>, IProviderContractLobRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProviderContractLobRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation           
        #endregion
    }
}
