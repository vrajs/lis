﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class GroupProviderContractRepository : BaseRepository<GroupProviderContract>, IGroupProviderContractRepository
    {
        private readonly KwicleContext _context;
        public GroupProviderContractRepository(KwicleContext context) :
            base(context)
        {
            _context = context;
        }

        public IQueryable<GroupProviderContractModel> GetGroupProviderContract(int GroupID, int? ProviderContractID)
        {
            var res = from n in _context.GroupProviderContracts.Where(x => x.GroupID == GroupID  && (!ProviderContractID.HasValue || x.ProviderContractID == ProviderContractID)).OrderByDescending(x=>x.TermDate)                      
                      select new GroupProviderContractModel()
                      {
                          GroupProviderContractID = n.GroupProviderContractID,
                          ProviderRelationID = n.ProviderRelationID,
                          ProviderContractID = n.ProviderContractID,
                          ProviderID = n.ProviderID,
                          ProviderName = n.ProviderRelation.RelatedProvider.FullName,
                          ContractHeaderID = n.ProviderContract.ContractHeaderID,
                          ContractHeaderName = n.ProviderContract.ContractHeader.ContractName,
                          //ProviderStatusName = n.ProviderContract.ProviderStatus.ShortName,
                          //LOBNames = string.Join(",", n.ProviderContract.ProviderContractLobs.Where(t => t.ProviderContractID == n.ProviderContractID).Select(t => t.Lob.LobName)),
                          GroupID = n.GroupID,
                          //GroupProviderName = n.ProviderRelation.ParentProvider.FullName,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                          GroupContractEffectiveDate = n.ProviderContract.EffectiveDate,
                          GroupContractTermDate = n.ProviderContract.TermDate,
                      };
            return res;
        }

        public void DeleteOrTermGroupProviderContract(int GroupID, int? ProviderContractID, string UpdatedBy, DateTime UpdatedDate, DateTime? TermDate, byte RecordStatus, string RecordStatusChangeComment)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@GroupID", GroupID),
                    new SqlParameter("@ProviderContractID", ProviderContractID),
                    new SqlParameter("@UpdatedDate", UpdatedDate),
                    new SqlParameter("@UpdatedBy", UpdatedBy),
                    new SqlParameter("@RecordStatus", RecordStatus),
                    new SqlParameter("@RecordStatusChangeComment", RecordStatusChangeComment),
                    new SqlParameter("@TermDate",TermDate) ,
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output, Value = String.Empty}
                };

                if (TermDate == null || TermDate == DateTime.MinValue)
                {
                    parameters[6].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_DeleteOrTermGroupProviderContract] @GroupID,@ProviderContractID,@UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@TermDate,@ErrorMessage out", parameters);

                var errorMessage = Convert.ToString(parameters[7].Value);

                if (!string.IsNullOrEmpty(errorMessage))
                    base.DbState.AddErrorMessage("CanNotDeleteOrTermGroupProviderContract : DeleteOrTermGroupProviderContract", errorMessage);

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotDeleteOrTermGroupProviderContract", ex.ToErrorMessage());
            }
        }
    }
}
