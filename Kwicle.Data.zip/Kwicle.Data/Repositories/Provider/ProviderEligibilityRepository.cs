﻿using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderEligibilityRepository:BaseRepository<ProviderEligibility>, IProviderEligibilityRepository
    {
        private readonly KwicleContext _context;
        public ProviderEligibilityRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public List<ProviderEligibility> GetByProviderID(int providerID)
        {
            var result = (from bps in _context.ProviderEligibilities
                          where bps.ProviderID == providerID
                          select new ProviderEligibility()
                          {
                              ProviderEligibilityID = bps.ProviderEligibilityID,
                              ProviderID = bps.ProviderID,
                              ProviderEligibilityCode = bps.ProviderEligibilityCode,
                              EffectiveDate = bps.EffectiveDate,
                              TermDate = bps.TermDate,
                              CreatedBy = bps.CreatedBy,
                              CreatedDate = bps.CreatedDate,
                              RecordStatus = bps.RecordStatus,
                              RecordStatusChangeComment = bps.RecordStatusChangeComment
                          }).ToList();
            return result;
        }
        public int GetMaxProvEligId(int providerId)
        {
            var result = _context.ProviderEligibilities.Where(x => x.ProviderID == providerId)
                         .Select(x => x.ProviderEligibilityID);
            var result_max = result.Max();
            return result_max;

        }
    }
}
