﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Data.Contracts.Provider;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Provider
{
    public class ProviderEFTRepository : BaseRepository<ProviderEFT>, IProviderEFTRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region ctor
        public ProviderEFTRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IQueryable<ProviderEFTViewModel> GetProviderEFT(int? ProviderID, int? AccountTypeID)
        {
            var res = from n in _context.ProviderEFTs.Where(x => (!ProviderID.HasValue || x.ProviderID == ProviderID) && (!AccountTypeID.HasValue || x.ProviderEFTID == AccountTypeID)).OrderByDescending(x=>x.TermDate)
                      from ct in _context.CommonCodes.Where(x => x.CommonCodeID == n.AccountTypeID).DefaultIfEmpty()
                      select new ProviderEFTViewModel()
                      {
                          ProviderEFTID = n.ProviderEFTID,
                          ProviderID = n.ProviderID,
                          AccountTypeID = n.AccountTypeID,
                          AccountTypeName = ct.ShortName,
                          BankName = n.BankName,
                          AccountNumber = n.AccountNumber,
                          NameOnAccount = n.NameOnAccount,
                          Routing = n.Routing,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };
            return res;
        }
        #endregion

    }
}
