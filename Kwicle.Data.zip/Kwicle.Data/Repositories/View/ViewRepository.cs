﻿using Kwicle.Data.Contracts.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Views;
using Kwicle.Common.Utility;

namespace Kwicle.Data.Repositories.View
{
    public class ViewRepository : IViewRepository
    {
        KwicleViewContext _context;
        KwicleContext _KwicleContext;
        public ViewRepository(KwicleViewContext context, KwicleContext kwicleContext)
        {
            _context = context;
            _KwicleContext = kwicleContext;
        }

        public IQueryable<vwCapitation> Capitations => from n in this._context.GetCapitations select n;

        public IQueryable<vwTerm> Terms => from n in this._context.vwTerm select n;

        public IQueryable<vwContract> GetContracts { get; set; }

        public IQueryable<vwPlanCapitation> PlanCapitations => from n in this._context.GetPlanCapitations select n;

        public IQueryable<vwMembershipCapitation> MembershipCapitations => from n in this._context.GetMembershipCapitations select n;

        public IQueryable<MemberLookupViewModel> MemberLookups => from n in this._context.GetMemberLookups
                                                           select new MemberLookupViewModel()
                                                           {
                                                               MemberID = n.MemberID,
                                                               MemberCode = n.MemberCode,
                                                               MemberName = n.MemberName,
                                                               FirstName = n.FirstName,
                                                               LastName = n.LastName,
                                                               DOB = n.DOB,
                                                               HealthPlanID = n.HealthPlanID,
                                                               PlanName = (n.PlanName == null) ? "N/A" : n.PlanName,
                                                               ProviderID = n.ProviderID,
                                                               PCPID = n.PCPID,
                                                               PCPName = (n.PCPName == null) ? "N/A" : n.PCPName,
                                                               EffectiveDate = n.EffectiveDate,
                                                               TermDate = n.TermDate,
                                                               LobName = (n.LobName == null) ? "N/A" : n.LobName,
                                                               RelationshipID = n.RelationshipID,
                                                               Relationship = n.Relationship,
                                                               RecordStatus = n.RecordStatus,
                                                               Gender = n.Gender,
                                                               MemberEligibilityID = n.MemberEligibilityID,
                                                               MemberPCPID = n.MemberPCPID,
                                                               LOBID = n.LOBID,
                                                               ProviderCode = n.ProviderCode,
                                                               CoverageType = (n.CoverageType == null) ? "N/A" : n.CoverageType,
                                                               FormattedEffectiveDate = (n.EffectiveDate == null) ? "N/A" : n.EffectiveDate.Value.ToString(CommonUtil.SYSTEM_DEFAULT_DATE_FORMAT),
                                                               FormattedTermDate = (n.TermDate == null || n.TermDate == DateTime.MaxValue.Date) ? "N/A" : n.TermDate.Value.ToString(CommonUtil.SYSTEM_DEFAULT_DATE_FORMAT),
                                                               CoverageTypeID = n.CoverageTypeID,
                                                               MedicaidID = (n.MedicaidID == null) ? "N/A" : n.MedicaidID,
                                                               MedicareID = (n.MedicareID == null) ? "N/A" : n.MedicareID
                                                           };

        public IQueryable<ProviderLookupModel> ProviderLookups => from n in this._context.GetProviderLookups
                                                               select new ProviderLookupModel()
                                                               {
                                                                   ProviderID = n.ProviderID,
                                                                   ProviderCode = n.ProviderCode,
                                                                   ProviderFirstName = n.ProviderFirstName,
                                                                   ProviderLastName = n.ProviderLastName,
                                                                   ProviderName = n.ProviderName,
                                                                   ProviderNPI = n.ProviderNPI,
                                                                   GroupID = n.GroupID,
                                                                   GroupCode = n.GroupCode,
                                                                   GroupFirstName = n.GroupFirstName,
                                                                   GroupLastName = n.GroupLastName,
                                                                   GroupName = n.GroupName,
                                                                   Vendor = n.Vendor,
                                                                   GroupNPI = n.GroupNPI,
                                                                   TIN = n.TIN,
                                                                   Title = n.Title,
                                                                   EffectiveDate = n.EffectiveDate,
                                                                   TermDate = n.TermDate,
                                                                   ProviderEligibilityID = n.ProviderEligibilityID,
                                                                   GroupEffectiveDate = n.GroupEffectiveDate,
                                                                   GroupTermDate = n.GroupTermDate,
                                                                   GroupEligibilityID = n.GroupEligibilityID,
                                                                   GroupRecordStatus = n.GroupRecordStatus,
                                                                   PREffectiveDate = n.PREffectiveDate,
                                                                   PRTermDate = n.PRTermDate,
                                                                   ProviderRelationID = n.ProviderRelationID,
                                                                   PRRecordStatus = n.PRRecordStatus,
                                                                   ProviderTypeID = n.ProviderTypeID,
                                                                   RecordStatus = n.RecordStatus
                                                               };

        public IQueryable<vwFacilityLookup> FacilityLookups => from n in this._context.GetFacilityLookups
                                                               select new vwFacilityLookup()
                                                               {
                                                                   FacilityID = n.FacilityID,
                                                                   FacilityCode = n.FacilityCode,
                                                                   FacilityFirstName = n.FacilityFirstName,
                                                                   FacilityLastName = n.FacilityLastName,
                                                                   FacilityName = n.FacilityName,
                                                                   FacilityNPI = n.FacilityNPI,
                                                                   VendorName = n.VendorName,
                                                                   TIN = n.TIN,
                                                                   EffectiveDate = n.EffectiveDate,
                                                                   TermDate = n.TermDate,
                                                                   FacilityEligibilityID = n.FacilityEligibilityID,
                                                                   RecordStatus = n.RecordStatus,
                                                                   GroupEffectiveDate = n.GroupEffectiveDate,
                                                                   GroupTermDate = n.GroupTermDate,
                                                                   GroupEligibilityID = n.GroupEligibilityID,
                                                                   GroupRecordStatus = n.GroupRecordStatus,
                                                                   PREffectiveDate = n.PREffectiveDate,
                                                                   PRTermDate = n.PRTermDate,
                                                                   ProviderRelationID = n.ProviderRelationID,
                                                                   PRRecordStatus = n.PRRecordStatus,
                                                                   GroupID = n.GroupID
                                                               };

        public IQueryable<vwClaimList> ClaimList => from c in this._context.GetClaimList select c;

        public IQueryable<vwClaimLoockup> ClaimLoockups => from cl in this._context.GetClaimLoockups select cl;
        public IQueryable<vwClaimBenefit> GetVwClaimBenefits => from ben in this._context.vwClaimBenefits select ben;
        public IQueryable<vwClaimServiceContractTermFeeschedule> GetServiceTermContract => from trm in this._context.vwClaimServiceContractTermFeeschedule select trm;
        public IQueryable<vwClaimRefundList> GetClaimRefundList => from rl in this._context.GetclaimRefundLists select rl;
        public IQueryable<vwClaimRefundLetter> GetClaimRefundLetter => from rls in this._context.GetRefundLetters select rls;

        public IQueryable<vwRuleHeader> GetRuleHeaders => from n in this._KwicleContext.GetRuleHeaders select n;

        public IQueryable<vwCheckHistoryList> CheckHistoryList => from c in this._context.GetCheckHistoryList select c;
    }
}
