﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities.CommonStructure;
using Kwicle.Data.Contracts.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Common
{
    public class DocumentRepository : BaseRepository<Document>, IDocumentRepository
    {
        private readonly KwicleContext _context;

        public DocumentRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<Document> GetDocumentsByType(int DocumentTypeID)
        {
            var result = _context.Documents.Where(x => x.RecordStatus == (byte)RecordStatus.Active && x.DocumentTypeID == DocumentTypeID);
            return result;
        }

        public short GetForm1099DocumentType()
        {
            short result = _context.DocumentTypes.Where(x => x.TypeName == "Form-1099").FirstOrDefault().DocumentTypeID;
            return result;
        }
        
    }
}
