﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Kwicle.Common.Utility;

namespace Kwicle.Data.Repositories.Common
{
    public class ServiceTypeCodeRepository : BaseRepository<ServiceTypeCode>, IServiceTypeCodeRepository
    {
        private readonly KwicleContext _KwicleContext;
        public ServiceTypeCodeRepository(KwicleContext kwicleContext) : base(kwicleContext)
        {
            this._KwicleContext = kwicleContext;
        }

        public List<KeyVal<short, string>> GetKeyVal()
        {
            try
            {

                var query = from n in _KwicleContext.ServiceTypeCodes
                            select new KeyVal<short, string>()
                            {
                                Key = n.ServiceTypeCodeID,
                                Value = n.Description
                            };

                var result = query.ToList();

                return result;
            }
            catch (Exception ex)
            {
                this.DbState.AddErrorMessage("Can't Get Service type code", ex.ToErrorMessage());
                return null;
            }
        }
    }
}
