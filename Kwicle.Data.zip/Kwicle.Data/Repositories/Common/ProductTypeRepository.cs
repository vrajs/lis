﻿using Kwicle.Core.Entities.OrganizationStructure;
using Kwicle.Data.Contracts.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel;

namespace Kwicle.Data.Repositories.Common
{
    public class ProductTypeRepository : BaseRepository<ProductType> , IProductTypeRepository
    {
        private readonly KwicleContext _Context;
        public ProductTypeRepository(KwicleContext Context) : base(Context)
        {
            _Context = Context;
        }

        public List<KeyVal<short, string>> GetAllKeyVal()
        {
            var query = from n in _Context.ProductTypes.Where(i => i.RecordStatus == 0)
                        select new KeyVal<short, string>
                        {
                            Key = n.ProductTypeID,
                            Value = n.ProductTypeName
                        };
            var result = query.ToList();
            return result;
        }
    }
}
