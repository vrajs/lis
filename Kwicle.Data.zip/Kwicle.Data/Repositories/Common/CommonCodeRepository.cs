﻿using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Views;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Common
{   
    public class CommonCodeRepository : BaseRepository<CommonCode>, ICommonCodeRepository
    {
        private readonly KwicleContext _Context;
        private readonly KwicleViewContext _viewContext;


        public CommonCodeRepository(KwicleContext Context, KwicleViewContext viewContext) : base(Context)
        {
            _Context = Context;
            _viewContext = viewContext;
        }

        public List<KeyValuePair<int, string>> GetCommonCodesByCodeTypeId(Int16 CommonCodeTypeId, Int16 FetchingTypeId)
        {
            List<KeyValuePair<int, string>> Items = new List<KeyValuePair<int, string>>();
            if (FetchingTypeId == (int)CommonCodeFetchingType.ByCode)
            {
                Items = _Context.CommonCodes.Where(x => x.CodeTypeID == CommonCodeTypeId && x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.Code)
                    .Select(x => new KeyValuePair<int, string>(x.CommonCodeID, x.Code)).ToList();
            }
            else if (FetchingTypeId == (int)CommonCodeFetchingType.ByLongDescription)
            {
                Items = _Context.CommonCodes.Where(x => x.CodeTypeID == CommonCodeTypeId && x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.LongDescription)
                    .Select(x => new KeyValuePair<int, string>(x.CommonCodeID, x.LongDescription)).ToList();
            }
            else
            {                
                Items = _Context.CommonCodes.Where(x => x.CodeTypeID == CommonCodeTypeId && x.RecordStatus == (byte)RecordStatus.Active).OrderBy(x => x.LongDescription)
                    .Select(x => new KeyValuePair<int, string>(x.CommonCodeID, x.LongDescription)).ToList();                
            }
            return Items;
        }


        public List<CommonCodeModel> GetCommonCodesByCodeTypeIds(MultipleValueRequestModel request)
        {
            List<CommonCodeModel> Items = new List<CommonCodeModel>();
            if (request.FetchingTypeId == (int)CommonCodeFetchingType.ByCode)
            {
                Items = (from c in _Context.CommonCodes.Where(w => w.RecordStatus == (byte)RecordStatus.Active && request.CodeTypeIds.Contains(w.CodeTypeID))
                         join ct in _Context.CodeTypes on c.CodeTypeID equals ct.CodeTypeID
                         orderby ct.ShortName, c.Code
                         select new CommonCodeModel()
                         {
                             CommonCodeID = c.CommonCodeID,
                             AddedSource = c.AddedSource,
                             CharValue = c.CharValue,
                             Code = c.Code,
                             CodeTypeID = c.CodeTypeID,
                             DisplayOrder = c.DisplayOrder,
                             EffectiveDate = c.EffectiveDate,
                             IsFreezed = c.IsFreezed,
                             LongDescription = c.LongDescription,
                             NumericValue = c.NumericValue,
                             OtherValue = c.OtherValue,
                             ShortName = c.ShortName,
                             TermDate = c.TermDate,
                             CodeType = ct.ShortName,
                             ControlTypeID=c.ControlTypeID
                         }).ToList();
            }
            else if (request.FetchingTypeId == (int)CommonCodeFetchingType.ByLongDescription)
            {
                Items = (from c in _Context.CommonCodes.Where(w => w.RecordStatus == (byte)RecordStatus.Active && request.CodeTypeIds.Contains(w.CodeTypeID))
                         join ct in _Context.CodeTypes on c.CodeTypeID equals ct.CodeTypeID
                         orderby ct.ShortName, c.LongDescription
                         select new CommonCodeModel()
                         {
                             CommonCodeID = c.CommonCodeID,
                             AddedSource = c.AddedSource,
                             CharValue = c.CharValue,
                             Code = c.Code,
                             CodeTypeID = c.CodeTypeID,
                             DisplayOrder = c.DisplayOrder,
                             EffectiveDate = c.EffectiveDate,
                             IsFreezed = c.IsFreezed,
                             LongDescription = c.LongDescription,
                             NumericValue = c.NumericValue,
                             OtherValue = c.OtherValue,
                             ShortName = c.ShortName,
                             TermDate = c.TermDate,
                             CodeType = ct.ShortName,
                             ControlTypeID = c.ControlTypeID
                         }).ToList();
            }
            else if (request.FetchingTypeId == (int)CommonCodeFetchingType.ByDisplayOrder)
            {
                Items = (from c in _Context.CommonCodes.Where(w => w.RecordStatus == (byte)RecordStatus.Active && request.CodeTypeIds.Contains(w.CodeTypeID))
                         join ct in _Context.CodeTypes on c.CodeTypeID equals ct.CodeTypeID
                         orderby c.DisplayOrder
                         select new CommonCodeModel()
                         {
                             CommonCodeID = c.CommonCodeID,
                             AddedSource = c.AddedSource,
                             CharValue = c.CharValue,
                             Code = c.Code,
                             CodeTypeID = c.CodeTypeID,
                             DisplayOrder = c.DisplayOrder,
                             EffectiveDate = c.EffectiveDate,
                             IsFreezed = c.IsFreezed,
                             LongDescription = c.LongDescription,
                             NumericValue = c.NumericValue,
                             OtherValue = c.OtherValue,
                             ShortName = c.ShortName,
                             TermDate = c.TermDate,
                             CodeType = ct.ShortName,
                             ControlTypeID = c.ControlTypeID
                         }).ToList();
            }
            else
            {
                Items = (from c in _Context.CommonCodes.Where(w => w.RecordStatus == (byte)RecordStatus.Active && request.CodeTypeIds.Contains(w.CodeTypeID))
                         join ct in _Context.CodeTypes on c.CodeTypeID equals ct.CodeTypeID
                         orderby c.ShortName
                         select new CommonCodeModel()
                         {
                             CommonCodeID = c.CommonCodeID,
                             AddedSource = c.AddedSource,
                             CharValue = c.CharValue,
                             Code = c.Code,
                             CodeTypeID = c.CodeTypeID,
                             DisplayOrder = c.DisplayOrder,
                             EffectiveDate = c.EffectiveDate,
                             IsFreezed = c.IsFreezed,
                             LongDescription = c.LongDescription,
                             NumericValue = c.NumericValue,
                             OtherValue = c.OtherValue,
                             ShortName = c.ShortName,
                             TermDate = c.TermDate,
                             CodeType = ct.ShortName,
                             ControlTypeID = c.ControlTypeID
                         }).ToList();
            }
            return Items;
        }
        public List<KeyValuePair<string, string>> GetCommonCodesKeyAsCodeByCodeTypeId(Int16 CommonCodeTypeId, Int16 FetchingTypeId)
        {
            List<KeyValuePair<string, string>> Items = new List<KeyValuePair<string, string>>();
            if (FetchingTypeId == (int)CommonCodeFetchingType.ByCode)
            {
                Items = _Context.CommonCodes.Where(x => x.CodeTypeID == CommonCodeTypeId && x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.Code)
                    .Select(x => new KeyValuePair<string, string>(x.Code, x.Code)).ToList();
            }
            else if (FetchingTypeId == (int)CommonCodeFetchingType.ByLongDescription)
            {
                Items = _Context.CommonCodes.Where(x => x.CodeTypeID == CommonCodeTypeId && x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.LongDescription)
                    .Select(x => new KeyValuePair<string, string>(x.Code, x.LongDescription)).ToList();
            }
            else
            {
                Items = _Context.CommonCodes.Where(x => x.CodeTypeID == CommonCodeTypeId && x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.ShortName)
                    .Select(x => new KeyValuePair<string, string>(x.Code, x.ShortName)).ToList();
            }
            return Items;
        }

        public List<GetCommonCodeConfigurationModel> GetCommonCodeConfigurationByCodeTypeId(string PageId, int CodeTypeId)
        {
            var res = _viewContext.GetCommonCodeConfigurations.Where(x => x.PageId == PageId && x.CodeTypeID == CodeTypeId && x.RecordStatus == (int)RecordStatus.Active).ToList();
            return res;
        }

        public IQueryable<vwCommonCodeList> GetCommonCodeList(int CommonCodeTypeID)
        {
            try
            {
                IQueryable<vwCommonCodeList> query;
                query = this._viewContext.vwCommonCodes;
                if (CommonCodeTypeID > 0 )
                {
                    query = query.Where(x =>  x.CodeTypeID == CommonCodeTypeID);
                }
                query = query.OrderByDescending(x => x.CreatedDate);
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllCommonCodes", ex.Message);
                return null;
            }
         
        }

        public int BulkUpdate(List<CommonCode> commonCodeList)
        {
            try
            {
                _Context.CommonCodes.UpdateRange(commonCodeList);
                return _Context.SaveChanges();
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CannotInsertCommonCodeList", ex.Message);
                return -1;
            }

        }

        public Task<List<CommonCode>> GetCommonCodeByCodeTypeId(short codeTypeId)
        {
           return _Context.CommonCodes.Where(x => x.CodeTypeID == codeTypeId && x.RecordStatus == (int)RecordStatus.Active).ToListAsync();
        }      
    }
}