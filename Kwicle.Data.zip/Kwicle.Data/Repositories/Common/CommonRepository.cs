﻿using System;
using System.Data;
//using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using Kwicle.Core.Common;
using Kwicle.Data.Contracts.Common;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Common
{
    public class CommonRepository : ICommonRepository
    {
        private readonly KwicleContext _context;

        public CommonRepository(KwicleContext context)
        {
            _context = context;
        }


        public bool CheckReferenceExist(string ParentTableToCheck, Int64? PKDataID, Int64? UKDataID, short? CheckType)
        {
            bool retVal = false;
            short ReturnValue = 0;

            if (Convert.ToString(ParentTableToCheck).Trim() != string.Empty && PKDataID != null && PKDataID > 0)
            {
                object[] paraCheckReference = 
                    {
                        new SqlParameter("@ParentTableToCheck", ParentTableToCheck),
                        new SqlParameter("@PKDataID", PKDataID), 
                        new SqlParameter("@UKDataID", (UKDataID == null ? 0 : UKDataID)),
                        new SqlParameter("@CheckType", (CheckType == null ? (short)ReferenceCheckType.ForeignKeyReference : CheckType)),

                        new SqlParameter("@ReturnValue",SqlDbType.SmallInt) {Direction = ParameterDirection.Output}
                    };

                _context.Database.ExecuteSqlRaw("dbo.usp_CheckReferenceExist @ParentTableToCheck, @PKDataID, @UKDataID, @CheckType ,@ReturnValue out", paraCheckReference);

                ReturnValue = Convert.ToInt16(((SqlParameter)paraCheckReference[4]).Value);

                if (ReturnValue == (int)CheckReferenceStatus.OkToDelete)
                {
                    retVal = true;
                }
            }

            return retVal;
        }

    }
}
