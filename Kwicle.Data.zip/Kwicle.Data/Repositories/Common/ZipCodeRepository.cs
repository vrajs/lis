﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Common;
using Kwicle.Data.Extensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Common
{
    public class ZipCodeRepository : BaseRepository<ZipCode>, IZipCodeRepository
    {
        KwicleContext _context;
        KwicleViewContext _viewContext;

        public ZipCodeRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        public IQueryable<ZipCodeModel> GetZipCodes()
        {
            try
            {
                var query = from n in _context.ZipCodes.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                            select new ZipCodeModel()
                            {
                                ZipCodeID = n.ZipCodeID,
                                AreaCode = n.AreaCode,
                                City = n.City,
                                Country = n.Country,
                                County = n.County,
                                Code = n.Code,
                                State = n.State,
                                StateFullName = n.StateFullName,
                                DMERuralEndDate = (n.DMERuralEndDate.Value.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.DMERuralEndDate,
                                DMERuralStartDate = (n.DMERuralStartDate.Value.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.DMERuralStartDate,
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingZipCodes", ex.Message);
                return null;
            }
        }

        public IQueryable<vwCities> GetCities()
        {
            try
            {
                //.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                var query = from n in _viewContext.GetCities.Where(e => e.RecordStatus == (byte)RecordStatus.Active)
                            select n;
                //.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                //var query = from n in _context.ZipCodes
                //            select new KeyVal<int, string>()
                //            {
                //                Key = n.ZipCodeID,
                //                Value = n.City
                //            };


                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingCities", ex.Message);
                return null;
            }
        }

        public IQueryable<GetCountiesModel> GetCounties()
        {
            try
            {
                var query = from n in _viewContext.GetCounties.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                            select n;
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingCounties", ex.Message);
                return null;
            }
        }

        public IQueryable<KeyVal<string, string>> GetStates()
        {
            try
            {
                var query = from n in _viewContext.GetStates.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                            orderby n.StateFullName
                            select new KeyVal<string, string>
                            {
                                Key = n.State,
                                Value = n.StateFullName
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingStates", ex.Message);
                return null;
            }

        }

        public IQueryable<KeyVal<string, string>> GetCountries()
        {
            try
            {
                //    var query = (from n in _context.ZipCodes.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                //                 select n).GroupBy(n => new { n.Country }).
                //                Select(s => new KeyVal<string, string>
                //                {
                //                    Key = s.Key.Country,
                //                    Value = s.Key.Country
                //                });

                var query = (from n in _viewContext.GetCountries.Where(e => e.RecordStatus == (int)RecordStatus.Active)
                             select new KeyVal<string, string>
                             {
                                 Key = n.Country,
                                 Value = n.Country
                             });

                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingContries", ex.Message);
                return null;
            }

        }

        public async Task<vwZipCodeDetail> GetZipCodesFromView(string searchValue)
        {
            vwZipCodeDetail vwZipCodeDetailModel = new vwZipCodeDetail();
            try
            {                
                if (!string.IsNullOrEmpty(searchValue))
                {
                    vwZipCodeDetailModel = await _viewContext.vwZipCodeDetail.Where(x => x.Code.ToLower() == searchValue.ToLower()).FirstOrDefaultAsync();
                }               
                
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingZipCodes", ex.Message);
                return null;
            }
            return vwZipCodeDetailModel;
        }

    }
}
