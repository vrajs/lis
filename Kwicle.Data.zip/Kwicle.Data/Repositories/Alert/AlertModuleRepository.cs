﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.AlertStructure;
using Kwicle.Data.Contracts.Alert;
using Kwicle.Core.CustomModel.Alert;

namespace Kwicle.Data.Repositories.Alert
{
    public class AlertModuleRepository : BaseRepository<AlertModule>, IAlertModuleRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public AlertModuleRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation   

        public IEnumerable<AlertModule> GetAllAlertModule()
        {
            try
            {
                var res = _context.AlertModules.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAlertModule", ex.Message);
                return null;
            }
        }

        public IQueryable<AlertModuleViewModel> GetAlertModule(int? AlertModuleID, int? SourceModuleID, int? DestinationModuleID, int? AlertDataID)
        {
            try
            {
                var query = from am in _context.AlertModules
                            join ac in _context.AlertCodes on am.AlertCodeID equals ac.AlertCodeID
                            where am.RecordStatus == (int)RecordStatus.Active
                                                                    && (!AlertModuleID.HasValue || am.AlertModuleID == AlertModuleID)
                                                                    && (!SourceModuleID.HasValue || am.SourceModuleID == SourceModuleID)
                                                                    && (!DestinationModuleID.HasValue || am.DestinationModuleID == DestinationModuleID)
                                                                    && (!AlertDataID.HasValue || am.AlertDataID == AlertDataID)
                            select new AlertModuleViewModel()
                            {
                                AlertModuleID = am.AlertModuleID,
                                SourceModuleID = am.SourceModuleID,
                                DestinationModuleID = am.DestinationModuleID,
                                AlertDataID = am.AlertDataID,
                                AlertCodeID = am.AlertCodeID,
                                AlertCodeValue = ac.Code,
                                AlertCodeName = ac.Name,
                                EffectiveDate = am.EffectiveDate,
                                TermDate = (am.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : am.TermDate,
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAlertModule", ex.Message);
                return null;
            }
        }

        public IQueryable<AlertModuleViewModel> GetMemberAlerts(string FamilyCode)
        {
            var query = from am in _context.AlertModules
                        join ac in _context.AlertCodes on am.AlertCodeID equals ac.AlertCodeID
                        join mem in _context.Members on am.AlertDataID equals mem.MemberID
                        join rel in _context.CommonCodes on mem.RelationshipID equals rel.CommonCodeID
                        where mem.FamilyCode == FamilyCode && am.RecordStatus != (int)RecordStatus.Deleted
                        orderby (mem.RelationshipID == (int)MemberRelationship.Self) ? 0 : 1
                        select new AlertModuleViewModel()
                        {
                            AlertModuleID = am.AlertModuleID,
                            SourceModuleID = am.SourceModuleID,
                            DestinationModuleID = am.DestinationModuleID,
                            AlertDataID = am.AlertDataID,
                            AlertCodeID = am.AlertCodeID,
                            AlertCodeValue = ac.Code,
                            AlertCodeName = ac.Name,
                            EffectiveDate = am.EffectiveDate,
                            TermDate = (am.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : am.TermDate,
                            MemberName = mem.DisplayName,
                            Relationship = rel.ShortName,
                            MemberCode = mem.MemberCode
                        };
            return query;
        }
        #endregion
    }
}
