﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Alert;
using Kwicle.Core.CustomModel.Alert;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Alert
{
    public class AlertCodeRepository:BaseRepository<AlertCode>,IAlertCodeRepository
    {
        private KwicleContext _context;
        public AlertCodeRepository(KwicleContext context):base(context)
        {
            _context = context; 
        }

        public IQueryable<AlertCodeViewModel> GetAlertCodes()
        {
            try
            {
                var query = from ac in _context.AlertCodes
                            where ac.RecordStatus == (int)RecordStatus.Active
                            select new AlertCodeViewModel()
                            {
                                AlertCodeID = ac.AlertCodeID,
                                Code = ac.Code,
                                Name = ac.Name
                            };
                           return query;

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAlertCodes", ex.Message);
                return null;
            }
        }
    }
}
