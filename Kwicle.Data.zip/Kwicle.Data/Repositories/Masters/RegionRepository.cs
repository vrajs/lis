﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class RegionRepository : BaseRepository<Region>, IRegionRepository
    {
        private readonly KwicleContext _context;
        public RegionRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RegionModel> GetRegions(int ProductTypeID)
        {
            IQueryable<RegionModel> region = (from rn in _context.Regions
                                              where (ProductTypeID > 0 ? rn.ProductTypeID == ProductTypeID : true)
                                              let state = _context.ZipCodes.Where(zc => zc.State == rn.State).First()
                                              select new RegionModel()
                                              {
                                                  RegionID = rn.RegionID,
                                                  ProductTypeID = rn.ProductTypeID,
                                                  ProductTypeName = rn.ProductType.ProductTypeName,
                                                  State = rn.State,
                                                  StateFullName = state.StateFullName,
                                                  Code = rn.Code,
                                                  Name = rn.Name,
                                                  EffectiveDate = rn.EffectiveDate,
                                                  TermDate = (rn.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : rn.TermDate,
                                                  City = rn.City,
                                                  County = rn.County
                                              });
            return region;
        }
    }
}
