﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class HomeGrownCodeRepository: BaseRepository<HomeGrownCodeModel>, IHomeGrownCodeRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        public HomeGrownCodeRepository(KwicleContext context,KwicleViewContext viewContext):base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }
        public IQueryable<vwHomeGrownCodeList> GetHomeGrownCodes(int ClinicalCodeTypeID)
        {
            try
            {
                IQueryable<vwHomeGrownCodeList> query;
                 query = this._viewContext.vwHomeGrownCodes;
                if (ClinicalCodeTypeID > 0 )
                {
                    query = query.Where(x =>  x.CodeTypeID == ClinicalCodeTypeID);
                }
                query = query.OrderByDescending(x => x.CreatedDate);
                //var query = from n in _viewContext.vwHomeGrownCodes.Where(x => ClinicalCodeTypeID == 0 ? true == true : x.CodeTypeID == ClinicalCodeTypeID)
                //            select new HomeGrownCodeModel()
                //            {
                //                HomeGrownCodeID = n.HomeGrownCodeID,
                //                CodeTypeID = n.CodeTypeID,
                //                Code = n.Code,
                //                HomeGrown = n.HomeGrown,
                //                ShortDescription = n.ShortDescription,
                //                LongDescription = n.LongDescription,
                //                TermDate = n.TermDate,
                //                EffectiveDate = n.EffectiveDate,
                //                MappedCode = n.MappedCode,
                //                RecordStatus = n.RecordStatus,
                //                Type = n.Type,
                //                StandardCodeShortDescription = n.StandardCodeShortDescription
                //            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllHomeGrownCodes", ex.Message);
                return null;
            }
         
        }
    }
}
