﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class GPCIRepository : BaseRepository<GPCI>, IGPCIRepository
    {
        private readonly KwicleContext _context;

        public GPCIRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<GPCIModel> GetGPCIList()
        {
            IQueryable<GPCIModel> queryable = (from x in _context.GPCIs                                                   
                                                   select new GPCIModel()
                                                   {
                                                       GPCIID = x.GPCIID,
                                                       LocalityCode = x.LocalityCode,
                                                       Carrier = x.Carrier,                                                       
                                                       LocalityName = x.LocalityName,
                                                       Work = x.Work,
                                                       PE = x.PE,
                                                       MP = x.MP,
                                                       EffectiveDate = x.EffectiveDate,
                                                       TermDate = (x.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : x.TermDate
                                                   });
            return queryable;
        }
    }
}
