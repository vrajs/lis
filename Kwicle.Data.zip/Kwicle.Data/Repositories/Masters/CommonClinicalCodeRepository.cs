﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System.Linq;
using System;
using Kwicle.Data.Models;
using Kwicle.Core.CustomModel.Configuration;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace Kwicle.Data.Repositories.Masters
{
    public class CommonClinicalCodeRepository : BaseRepository<CommonClinicalCodeModel>, ICommonClinicalCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor

        public CommonClinicalCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region  Methods       

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<CommonClinicalCodeModel> GetCommonClinicalCodes(int ClinicalCodeTypeID)
        {
            IQueryable<CommonClinicalCodeModel> query = null;
            Kwicle.Core.Common.ClinicalCodeType ID = ClinicalCodeTypeID.ToEnum<Kwicle.Core.Common.ClinicalCodeType>();
            switch (ID)
            {
                case Kwicle.Core.Common.ClinicalCodeType.ICD9CMDX:
                case Kwicle.Core.Common.ClinicalCodeType.ICD9CMPCS:
                case Kwicle.Core.Common.ClinicalCodeType.ICD10CMDX:
                case Kwicle.Core.Common.ClinicalCodeType.ICD10CMPCS:
                    query = from n in _context.ICDCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.ICDCodeID,
                                Code = n.Code,
                                HomeGrown = n.HomeGrown,
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription,
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.CPT2:
                case Kwicle.Core.Common.ClinicalCodeType.CPT4:
                case Kwicle.Core.Common.ClinicalCodeType.Modifier:
                case Kwicle.Core.Common.ClinicalCodeType.HCPCS:
                    query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.CPTCodeID,
                                Code = n.Code,
                                HomeGrown = n.HomeGrown,
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription,
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.POS:
                    query = from n in _context.POSCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.POSCodeID,
                                Code = n.Code,
                                HomeGrown = n.HomeGrown,
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription,
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.MSDRGCodes:
                    query = from n in _context.DRGCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.DRGCodeID,
                                Code = n.Code,
                                HomeGrown = n.HomeGrown,
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription, //ask to dipesh bhai for same
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.UBRevenue:
                    query = from n in _context.RevenueCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.RevenueCodeID,
                                Code = n.Code,
                                HomeGrown = n.HomeGrown,
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription, //ask to dipesh bhai for same
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.UBTOB:  // Bill Type Code
                    query = from n in _context.BillTypeCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.BillTypeCodeID,
                                Code = n.Code,
                                ShortDescription = n.ShortDescription,
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.HUGS:
                case Kwicle.Core.Common.ClinicalCodeType.RUGS:
                    query = from n in _context.OtherCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.OtherCodeID,
                                Code = n.Code,
                                HomeGrown = n.HomeGrown,
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription,
                                SequenceNumber = n.SequenceNumber,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.NDC9:
                case Kwicle.Core.Common.ClinicalCodeType.NDC10:
                case Kwicle.Core.Common.ClinicalCodeType.NDC11:                
                    query = from n in _context.NDCCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == ClinicalCodeTypeID)
                            select new CommonClinicalCodeModel()
                            {
                                ID = n.NDCCodeID,
                                Code = n.Code,                                
                                ShortDescription = n.ShortDescription,
                                LongDescription = n.LongDescription,                                
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID
                            };
                    break;
            }
            return query;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public IQueryable<ClinicalCodeCheckModel> CheckCommonClinicalCode(int ClinicalCodeTypeID, string Code)
        {
            IQueryable<ClinicalCodeCheckModel> query = null;
            Kwicle.Core.Common.ClinicalCodeType ID = ClinicalCodeTypeID.ToEnum<Kwicle.Core.Common.ClinicalCodeType>();
            switch (ID)
            {
                case Kwicle.Core.Common.ClinicalCodeType.ICD9CMDX:
                case Kwicle.Core.Common.ClinicalCodeType.ICD9CMPCS:
                case Kwicle.Core.Common.ClinicalCodeType.ICD10CMDX:
                case Kwicle.Core.Common.ClinicalCodeType.ICD10CMPCS:
                    query = from n in _context.ICDCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.ICDCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };

                    break;
                case Kwicle.Core.Common.ClinicalCodeType.CPT2:
                case Kwicle.Core.Common.ClinicalCodeType.CPT4:
                case Kwicle.Core.Common.ClinicalCodeType.Modifier:
                case Kwicle.Core.Common.ClinicalCodeType.HCPCS:
                    query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.CPTCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.POS:
                    query = from n in _context.POSCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.POSCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.MSDRGCodes:
                    query = from n in _context.DRGCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.DRGCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.UBRevenue:
                case Kwicle.Core.Common.ClinicalCodeType.UBOccurrence:
                case Kwicle.Core.Common.ClinicalCodeType.UBValue:
                case Kwicle.Core.Common.ClinicalCodeType.UBCondition:
                    query = from n in _context.RevenueCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.RevenueCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.UBTOB:  // Bill Type Code
                    query = from n in _context.BillTypeCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.BillTypeCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.HUGS:
                case Kwicle.Core.Common.ClinicalCodeType.RUGS:
                    query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code.ToUpper() == Code.ToUpper())
                            select new ClinicalCodeCheckModel
                            {
                                ClinicalCodeTypeID = ClinicalCodeTypeID,
                                ID = n.CPTCodeID,
                                Code = Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate,
                                SequenceNumber = n.SequenceNumber
                            };
                    break;
                case Kwicle.Core.Common.ClinicalCodeType.NDC9:
                case Kwicle.Core.Common.ClinicalCodeType.NDC10:
                case Kwicle.Core.Common.ClinicalCodeType.NDC11:
                    query = from n in _context.NDCCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active)
                            select new ClinicalCodeCheckModel()
                            {
                                ID = n.NDCCodeID,
                                Code = n.Code,
                                EffectiveDate = n.EffectiveDate,
                                RecordStatus = n.RecordStatus,
                                TermDate = n.TermDate
                            };
                    break;
            }
            return query;
        }

        public IQueryable<ClinicalCodeCheckModel> CheckCommonClinicalCode(int clinicalCodeTypeID, string code, DateTime effectiveDate)
        {
            var query = this.CheckCommonClinicalCode(clinicalCodeTypeID, code).Where(c => effectiveDate >= c.EffectiveDate && c.TermDate <= effectiveDate);
            return query;
        }

        public MinCodeMaxCodeValidityModel CheckCodeValidity(int clinicalCodeTypeID, string minCode, string maxCode, DateTime validationDate, ValidityCheck validityMode)
        {
            MinCodeMaxCodeValidityModel minCodeMaxCodeValidityModel = new MinCodeMaxCodeValidityModel();
            switch (validityMode)
            {
                case ValidityCheck.EffectiveFrom:
                    var minCodeValidtyQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, minCode).Where(c => validationDate >= c.EffectiveDate && c.TermDate <= validationDate);
                    var isMinCodeValidtyValid = minCodeValidtyQuery.Any();
                    minCodeMaxCodeValidityModel.IsMinCodeValidityValid = isMinCodeValidtyValid;

                    var maxCodeValidtyQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, maxCode).Where(c => validationDate >= c.EffectiveDate && c.TermDate <= validationDate);
                    var isMaxCodeValidtyValid = maxCodeValidtyQuery.Any();
                    minCodeMaxCodeValidityModel.IsMaxCodeValidityValid = isMaxCodeValidtyValid;
                    break;
                case ValidityCheck.TermFrom:
                    minCodeValidtyQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, minCode).Where(c => validationDate <= c.TermDate);
                    isMinCodeValidtyValid = minCodeValidtyQuery.Any();
                    minCodeMaxCodeValidityModel.IsMinCodeValidityValid = isMinCodeValidtyValid;

                    maxCodeValidtyQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, maxCode).Where(c => validationDate <= c.TermDate);
                    isMaxCodeValidtyValid = minCodeValidtyQuery.Any();
                    minCodeMaxCodeValidityModel.IsMaxCodeValidityValid = isMaxCodeValidtyValid;
                    break;
            }

            return minCodeMaxCodeValidityModel;
        }

        public ClinicalCodeCheckModel CheckCodeValidity(int clinicalCodeTypeID, string code, DateTime validationDate, ValidityCheck validityMode)
        {
            ClinicalCodeCheckModel clinicalCodeCheckModel = null;
            switch (validityMode)
            {
                case ValidityCheck.EffectiveFrom:
                    var codeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, code);
                    //var codeValidityQuery = codeQuery.Where(c => validationDate >= c.EffectiveDate && (c.TermDate == DateTime.MaxValue || c.TermDate <= validationDate));
                    var codeValidityQuery = codeQuery.Where(c => validationDate < c.EffectiveDate || validationDate > c.TermDate);
                    var isCodeInRange = !codeValidityQuery.Any();
                    clinicalCodeCheckModel = isCodeInRange ? null : codeQuery.Single();
                    break;
                case ValidityCheck.TermFrom:
                    codeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, code);
                    codeValidityQuery = codeQuery.Where(c => validationDate > c.TermDate);
                    isCodeInRange = !codeValidityQuery.Any();
                    clinicalCodeCheckModel = isCodeInRange ? null : codeQuery.Single();
                    break;
            }

            return clinicalCodeCheckModel;
        }

        public ClinicalCodeCheckModel CheckCodeValidity(int clinicalCodeTypeID, string code, DateTime effectiveDate, DateTime termDate)
        {
            ClinicalCodeCheckModel clinicalCodeCheckModel = null;
            var codeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, code);
            var codeValidityQuery = codeQuery.Where(i => (effectiveDate.Date >= i.EffectiveDate.Date && effectiveDate.Date <= i.TermDate.Date)
            && (termDate.Date >= i.EffectiveDate.Date && termDate.Date <= i.TermDate.Date));
            var isCodeInRange = codeValidityQuery.Any();
            clinicalCodeCheckModel = isCodeInRange ? null : codeQuery.SingleOrDefault();
            return clinicalCodeCheckModel;
        }

        public bool Compare(int clinicalCodeTypeID, string minCode, string maxCode)
        {
            var minCodeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, minCode);
            var maxCodeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, maxCode);

            var minCodeSequenceNumber = minCodeQuery.Single();
            var maxCodeSequenceNumber = maxCodeQuery.Single();

            return minCodeSequenceNumber.SequenceNumber <= maxCodeSequenceNumber.SequenceNumber;
        }

        //public ClinicalCodeCheckModel CheckCodeEffectiveValidity(int clinicalCodeTypeID, string code, DateTime effectiveDate, DateTime termDate)
        //{
        //    ClinicalCodeCheckModel clinicalCodeCheckModel = null;
        //    var codeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, code);
        //    var codeValidityQuery = codeQuery.Where(i => (effectiveDate.Date >= i.EffectiveDate.Date && effectiveDate.Date <= i.TermDate.Date)
        //    && (termDate.Date >= i.EffectiveDate.Date && termDate.Date <= i.TermDate.Date));
        //    var isCodeInRange = codeValidityQuery.Any();
        //    clinicalCodeCheckModel = !isCodeInRange ? null : codeValidityQuery.Single();
        //    return clinicalCodeCheckModel;
        //}

        public bool ValidCodeCompare(int clinicalCodeTypeID, string minCode, string maxCode,string Code)
        {
            var minCodeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, minCode);
            var maxCodeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, maxCode);
            var codeQuery = this.CheckCommonClinicalCode(clinicalCodeTypeID, Code);

            var minCodeSequenceNumber = minCodeQuery?.Single();
            var maxCodeSequenceNumber = maxCodeQuery?.Single();
            var codeSequenceNumber = codeQuery?.Single();

            if(minCodeSequenceNumber == null && maxCodeSequenceNumber == null)
            {
                return false;
            }
            return (minCodeSequenceNumber.SequenceNumber <= codeSequenceNumber.SequenceNumber)
                && (maxCodeSequenceNumber.SequenceNumber >= codeSequenceNumber.SequenceNumber);
        }
        public IEnumerable<ExistsCommonClinicalCodeUsed> CheckExistsCommonClinicalCodeUsed(int ClinicalCodeTypeID, string Code, DateTime EffectiveDate, DateTime TermDate)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@" + "ClinicalCodeTypeID", ClinicalCodeTypeID),
                new SqlParameter("@" + "Code", Code),
                new SqlParameter("@" + "EffectiveDate", EffectiveDate),
                new SqlParameter("@" + "TermDate", TermDate)
            };

            List<ExistsCommonClinicalCodeUsed> ExistsCommonClinicalCodeUsed = _context.ExecuteStoreProcedure<ExistsCommonClinicalCodeUsed>("[hps].[usp_CheckExistsCommonClinicalCodeUsed]", parameters.ToArray());

            return ExistsCommonClinicalCodeUsed;
        }

        #endregion
    }
}