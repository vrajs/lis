﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class RBRVSCodeRepository: BaseRepository<RBRVSCode>, IRBRVSCodeRepository
    {
        private readonly KwicleContext _context;

        public RBRVSCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RBRVSCode> GetRBRVSCodes()
        {
            //IQueryable<RBRVSCode> queryable = (from md in _context.RBRVSCodes
            //                                               select new RBRVSCode()
            //                                               {
            //                                                   ModifierDiscountID = md.ModifierDiscountID,
            //                                                   ModifierDiscountGroupID = md.ModifierDiscountGroupID,
            //                                                   ModifierDiscountGroup = md.ModifierDiscountGroup.GroupName,
            //                                                   ModifierCode = md.ModifierCode,
            //                                                   Start = md.Start,
            //                                                   End = md.End,
            //                                                   ModifierPercentage = md.ModifierPercentage,
            //                                                   EffectiveDate = md.EffectiveDate,
            //                                                   TermDate = (md.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : md.TermDate
            //                                               });
            IQueryable<RBRVSCode> queryable = (from md in _context.RBRVSCodes select md);                                               
            return queryable;
        }

        public List<KeyValuePair<short, string>> GetByTypeNumber(short typeNumber)
        {
            var res = _context.RBRVSCodes.IgnoreQueryFilters().Where(x => x.TypeNumber == typeNumber && x.RecordStatus == (int)RecordStatus.Active).Select(y => new KeyValuePair<short, string>(y.TypeNumber, y.Code)).ToList();
            return res;
        }
    }
}
