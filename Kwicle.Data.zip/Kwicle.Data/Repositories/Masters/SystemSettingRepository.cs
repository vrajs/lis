﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Kwicle.Data.Repositories.Masters
{
    public class SystemSettingRepository : BaseRepository<SystemSetting>, ISystemSettingRepository
    {

        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public SystemSettingRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion

        #region Methods
        public List<SystemSettingModel> GetAllSetting()
        {
            var query = from ss in _context.SystemSettings
                        select new SystemSettingModel()
                        {
                            ID = ss.ID,
                            BitValue = ss.BitValue,
                            CreatedDate = ss.CreatedDate,
                            DateValue = ss.DateValue,
                            Description = ss.Description,
                            IsOneTimeOnly = ss.IsOneTimeOnly,
                            NumericValue = ss.NumericValue,
                            SettingCode = ss.SettingCode,
                            StringValue = ss.StringValue,
                            TimeValue = ss.TimeValue,
                            UpdatedBy = ss.UpdatedBy,
                            UpdatedDate = ss.UpdatedDate
                        };
            return query.ToList();
        }
        #endregion
    }
}
