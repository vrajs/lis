﻿using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class DRGPaymentPayPercentRepository : BaseRepository<DRGPaymentPayPercent> , IDRGPaymentPayPercentRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public DRGPaymentPayPercentRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion
    }
}
