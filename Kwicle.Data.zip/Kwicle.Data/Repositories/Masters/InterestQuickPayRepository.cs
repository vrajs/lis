﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class InterestQuickPayRepository : BaseRepository<InterestQuickPay>, IInterestQuickPayRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public InterestQuickPayRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        public IQueryable<InterestQuickPayModel> GetInterestQuickPays()
        {
            IQueryable<InterestQuickPayModel> queryable = (from iqp in _context.InterestQuickPays
                                                          select new InterestQuickPayModel()
                                                          {
                                                              InterestQuickPayID = iqp.InterestQuickPayID,
                                                              IsQuickPay = iqp.IsQuickPay,
                                                              IsEDI = iqp.IsEDI,
                                                              Schedule = iqp.Schedule,
                                                              Description = iqp.Description,
                                                              FromDay = iqp.FromDay,
                                                              ToDay = iqp.ToDay,
                                                              Rate = iqp.Rate,
                                                              EffectiveDate = iqp.EffectiveDate,
                                                              TermDate = (iqp.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : iqp.TermDate
                                                          });
            return queryable;
        }
    }
}
