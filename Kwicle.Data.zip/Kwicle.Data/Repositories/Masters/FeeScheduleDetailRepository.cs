﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class FeeScheduleDetailRepository : BaseRepository<FeeScheduleDetail>, IFeeScheduleDetailRepository
    {
        private KwicleContext _contex;
        public FeeScheduleDetailRepository(KwicleContext context) : base(context)
        {
            _contex = context;
        }

        public IQueryable<FeeScheduleDetailModel> GetFeeScheduleDetails(int feeScheduleHeaderID)
        {
            IQueryable<FeeScheduleDetailModel> feeScheduleDetails = (from fsd in _contex.FeeScheduleDetails
                                                                     where fsd.FeeScheduleHeaderID == feeScheduleHeaderID
                                                                     select new FeeScheduleDetailModel()
                                                                     {
                                                                         FeeScheduleDetailID = fsd.FeeScheduleDetailID,
                                                                         Code = fsd.Code,
                                                                         Modifier1 = fsd.Modifier1,
                                                                         Modifier2 = fsd.Modifier2,
                                                                         Rate = fsd.Rate,
                                                                         POSCode = fsd.POSCode,
                                                                         AgeFrom = fsd.AgeFrom,
                                                                         AgeTo = fsd.AgeTo,
                                                                         ProviderTypeID = fsd.ProviderTypeID,
                                                                         ProviderTypeName = fsd.ProviderType.ShortName,
                                                                         ProviderSpecialtyID = fsd.ProviderSpecialtyID,
                                                                         ProviderSpecialtyName = fsd.Specialty.SpecialtyName,
                                                                         AdditionalRequirement = fsd.AdditionalRequirement,
                                                                         MaxUnits = fsd.MaxUnits,
                                                                         ShareLimitID = fsd.ShareLimitID,
                                                                         ShareFeeScheduleLimitName = fsd.ShareLimit.Code,
                                                                         Rural = fsd.Rural,
                                                                         Comment = fsd.Comment,
                                                                         FeeScheduleHeaderID = fsd.FeeScheduleHeaderID,
                                                                         FeeScheduleHeaderCode = fsd.FeeScheduleHeader.Code,
                                                                         FeeScheduleLimitID = fsd.FeeScheduleLimitID,
                                                                         FeeScheduleLimitName = fsd.FeeScheduleLimit.Code,
                                                                         ClinicalCodeTypeID = fsd.ClinicalCodeTypeID,
                                                                         ClinicalCodeTypeName = fsd.FeeScheduleDetailClinicalCodeType.ShortName,
                                                                         EffectiveDate = fsd.EffectiveDate,
                                                                         TermDate = (fsd.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : fsd.TermDate
                                                                     });
            return feeScheduleDetails;
        }
    }
}
