﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class SpecialtyRepository : BaseRepository<Specialty>, ISpecialtyRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor

        public SpecialtyRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<SpecialtyModel> GetSpecialties()
        {
            var query = from s in _context.Specialties.Where(c => c.RecordStatus == (byte)RecordStatus.Active)
                        select new SpecialtyModel()
                        {
                            SpecialtyID = s.SpecialtyID,
                            SpecialtyCode = s.SpecialtyCode,
                            SpecialtyName = s.SpecialtyName,
                            CMSCode = s.CMSCode
                        };
            return query;
        }

        public List<KeyValuePair<int, string>> GetSpecialtiesKeyVal()
        {
            List<KeyValuePair<int, string>> Items = new List<KeyValuePair<int, string>>();

            //Start Migration 2.1 to 3.1
            //Items = _context.Specialties.Where(x => x.RecordStatus == (byte)RecordStatus.Active).Select(x => new KeyValuePair<int, string>(x.SpecialtyID, x.SpecialtyName)).OrderByDescending(o => o.Key == 0).ThenBy(t => t.Value).ToList();
            Items = _context.Specialties.Where(x => x.RecordStatus == (byte)RecordStatus.Active).OrderByDescending(o => o.SpecialtyID == 0).ThenBy(t => t.SpecialtyName)
                .Select(x => new KeyValuePair<int, string>(x.SpecialtyID, x.SpecialtyName)).ToList();
            //End Migration 2.1 to 3.1
            return Items;
        }
        #endregion
    }
}
