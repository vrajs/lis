﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Kwicle.Data.Repositories.Masters
{
    public class RefundStatusRepository : BaseRepository<RefundStatus>, IRefundStatusRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public RefundStatusRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Interface Methods Implementation    
        public List<RefundStatusModel> GetAllStatus()
        {
            var query = from n in _context.RefundStatuses.Where(x => x.RecordStatus == (int)RecordStatus.Active)
                        select new RefundStatusModel()
                        {
                            RefundStatusID = n.RefundStatusID,
                            RefundStatusCode = n.RefundStatusCode,
                            RefundStatusDescription = n.RefundStatusDescription,
                            RefundStatusCategory = n.RefundStatusCategory,
                        };
            return query.ToList();
        }
        #endregion
    }
}
