﻿using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;

namespace Kwicle.Data.Repositories.Masters
{
    public class CopayCoinsuranceRepository : BaseRepository<CopayCoinsurance>, ICopayCoinsuranceRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public CopayCoinsuranceRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public IQueryable<CopayCoinsuranceModel> GetAllCopayCoinsurance()
        {
            var res = from n in _context.CopayCoinsurances.Where(x => x.RecordStatus == (int)RecordStatus.Active)
                      from r in _context.CommonCodes
                          .Where(x => x.CommonCodeID == n.MaxCopayTimePeriodId).DefaultIfEmpty()
                      from p in _context.CommonCodes
                          .Where(x => x.CommonCodeID == n.MaxCopayPerDiemTimePeriodId).DefaultIfEmpty()
                      from z in _context.CommonCodes
                          .Where(x => x.CommonCodeID == n.NetworkID).DefaultIfEmpty()
                      select new CopayCoinsuranceModel()
                      {
                          CopayCoinsuranceID = n.CopayCoinsuranceID,
                          //SubCompanyID = n.SubCompanyID,
                          CopayCoinsuranceCode = n.CopayCoinsuranceCode,
                          FixedCopay = n.FixedCopay,
                          MaxCopay = n.MaxCopay,
                          MaxCopayTimePeriodId = n.MaxCopayTimePeriodId,
                          MaxCopayTimePeriod = r.ShortName,
                          MaxCopayPerDiem = n.MaxCopayPerDiem,
                          MaxCopayPerDiemTimePeriodId = n.MaxCopayPerDiemTimePeriodId,
                          MaxCopayPerDiemTimePeriod = p.ShortName,
                          CoinsurancePercentage = n.CoinsurancePercentage,
                          IsVariableCopayPerDiem = n.IsVariableCopayPerDiem,
                          IsParNonPar = n.IsParNonPar,
                          NetworkID = n.NetworkID,
                          Network = z.ShortName,
                          IsNoAuth = n.IsNoAuth,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };

            return res;
        }
        #endregion
    }
}
