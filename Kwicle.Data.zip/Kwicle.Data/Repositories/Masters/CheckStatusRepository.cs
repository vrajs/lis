﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Data.Contracts.Masters;

namespace Kwicle.Data.Repositories.Masters
{
    public class CheckStatusRepository : BaseRepository<Kwicle.Core.Entities.Master.CheckStatus>, ICheckStatusRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public CheckStatusRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Interface Methods Implementation    
        public List<KeyVal<int, string>> GetAllStatus()
        {
            var query = from n in _context.CheckStatuses.Where(x => x.RecordStatus == (int)RecordStatus.Active)
                        select new KeyVal<int, string>()
                        {
                            Key = n.CheckStatusID,
                            Value = n.Name,
                        };
            return query.ToList();
        }
        #endregion
    }
}
