﻿using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class CommonCodeDisplayConfigurationRepository : BaseRepository<CommonCodeDisplayConfiguration>, ICommonCodeDisplayConfigurationRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        public CommonCodeDisplayConfigurationRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }
        public List<CommonCodeDisplayConfiguration> GetDataCommonCodeDisplayConfigurationByCommonCodeIDs(List<int> CommonCodeIDs, string PageId)
        {
            var CommonCodeDisplayConfigurations = (from CommonCodeID in CommonCodeIDs
                                                   join CommonCodeDisplayConfiguration in _context.CommonCodeDisplayConfigurations on CommonCodeID equals CommonCodeDisplayConfiguration.CommonCodeID
                                                   where CommonCodeDisplayConfiguration.PageId == PageId
                                                   select CommonCodeDisplayConfiguration).ToList();

            return CommonCodeDisplayConfigurations;
        }
        public void InsertBunchOfCommonCodeDisplayConfiguration(List<CommonCodeDisplayConfiguration> entities)
        {
            _context.CommonCodeDisplayConfigurations.AddRange(entities);
            _context.SaveChanges();
        }
        public void DeleteBunchOfCommonCodeDisplayConfiguration(List<CommonCodeDisplayConfiguration> entities)
        {
            using (_context)
            {
                _context.CommonCodeDisplayConfigurations.RemoveRange(entities);
                _context.SaveChanges();
            }
        }
    }
}
