﻿using System;
using System.Linq;
using System.Collections.Generic;
using Kwicle.Core.Common;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.CustomModel.Masters;

namespace Kwicle.Data.Repositories.Masters
{
    public class SearchCriteriaRepository : BaseRepository<SearchCriteria>, ISearchCriteriaRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public SearchCriteriaRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public List<SearchCriteriaModel> GetAllSearchCriteriaByUser(string CreatedBy)
        {
            List<SearchCriteriaModel> searchedItems = new List<SearchCriteriaModel>();
            searchedItems = (from b in _context.SearchCriterias
                             where b.CreatedBy == CreatedBy && b.RecordStatus == (int)RecordStatus.Active
                             select new SearchCriteriaModel()
                             {
                                 SearchCriteriaID = b.SearchCriteriaID,
                                 Name = b.Name,
                                 ScreenID = b.ScreenID,
                                 CriteriaJson = b.CriteriaJson,
                             }).ToList();
            return searchedItems;
        }

        public List<SearchCriteriaModel> GetAllSearchCriteriaByUserPage(string CreatedBy, string PageId)
        {
            List<SearchCriteriaModel> searchedItems = new List<SearchCriteriaModel>();
            searchedItems = (from b in _context.SearchCriterias
                             where b.CreatedBy == CreatedBy && b.RecordStatus == (int)RecordStatus.Active && b.ScreenID.ToLower() == PageId.ToLower()
                             select new SearchCriteriaModel()
                             {
                                 SearchCriteriaID = b.SearchCriteriaID,
                                 Name = b.Name,
                                 ScreenID = b.ScreenID,
                                 CriteriaJson = b.CriteriaJson
                             }).ToList();
            return searchedItems;
        }
        #endregion
    }
}
