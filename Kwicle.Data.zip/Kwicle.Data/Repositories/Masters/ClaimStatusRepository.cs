﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class ClaimStatusRepository : BaseRepository<Kwicle.Core.Entities.Master.ClaimStatus>, IClaimStatusRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ClaimStatusRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Interface Methods Implementation    
        public List<KeyVal<int, string>> GetAllStatus()
        {
            var query = from n in _context.ClaimStatuses.Where(x => x.RecordStatus == (int)RecordStatus.Active)
                        select new KeyVal<int, string>()
                        {
                            Key = n.ClaimStatusID,
                            Value = n.ClaimStatusCode,
                        };
            return query.ToList();
        }
        #endregion
    }
}
