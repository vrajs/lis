﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class ModifierDiscountGroupRepository : BaseRepository<ModifierDiscountGroup>, IModifierDiscountGroupRepository
    {
        private readonly KwicleContext _context;

        public ModifierDiscountGroupRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public List<KeyValuePair<int, string>> GetModifierDiscountGroupKeyVal()
        {
            var res = _context.ModifierDiscountGroups.Where(t => t.RecordStatus == (int)RecordStatus.Active).Select(mdg => new KeyValuePair<int, string>(mdg.ModifierDiscountGroupID, mdg.GroupName)).ToList();
            return res;
        }
    }
}
