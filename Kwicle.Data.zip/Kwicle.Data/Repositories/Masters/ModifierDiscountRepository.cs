﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class ModifierDiscountRepository : BaseRepository<ModifierDiscount> , IModifierDiscountRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public ModifierDiscountRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        public IQueryable<ModifierDiscountModel> GetModifierDiscounts()
        {
            IQueryable<ModifierDiscountModel> queryable = (from md in _context.ModifierDiscounts
                                                           select new ModifierDiscountModel()
                                                           {
                                                               ModifierDiscountID = md.ModifierDiscountID,
                                                               ModifierDiscountGroupID = md.ModifierDiscountGroupID,
                                                               ModifierDiscountGroup = md.ModifierDiscountGroup.GroupName,
                                                               ModifierCode = md.ModifierCode,                                                               
                                                               Start = md.Start,
                                                               End = md.End,
                                                               ModifierPercentage = md.ModifierPercentage,
                                                               EffectiveDate = md.EffectiveDate,
                                                               TermDate = (md.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : md.TermDate
                                                           });
            return queryable;
        }
    }
}
