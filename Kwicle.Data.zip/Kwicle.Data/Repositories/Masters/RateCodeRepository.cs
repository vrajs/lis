﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Masters
{
    public class RateCodeRepository : BaseRepository<RateCode>, IRateCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor
        public RateCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<RateCodeModel> GetRateCode()
        {            
            var query = from r in _context.RateCodes
                        join c in _context.CommonCodes on r.RateTypeID equals c.CommonCodeID
                        join cs in _context.CommonCodes on r.SourceTypeID equals cs.CommonCodeID
                        join l in _context.Lobs on r.LOBID equals l.LobID
                        //where (RateCodeID == null ? true == true : r.RateCodeID == RateCodeID)
                        select new RateCodeModel()
                        {
                            RateCodeID = r.RateCodeID,
                            SourceTypeID = r.SourceTypeID,
                            SourceType = cs.ShortName,
                            LOBID = r.LOBID,                           
                            LOBName = l.LobName,
                            RateTypeID = r.RateTypeID,
                            RateType = c.ShortName,
                            Code = r.Code,
                            Rate = r.Rate,
                            EffectiveDate = r.EffectiveDate,
                            TermDate = (r.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : r.TermDate
                        };
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MemberID"></param>
        /// <returns></returns>
        public IQueryable<RateCodeModel> GetRateCode(int MemberID)
        {
            int MemberPrimaryEligibilityID = 0;
            Kwicle.Core.Entities.MemberStructure.Member eMember = _context.Members.Where(e => e.MemberID == MemberID).FirstOrDefault();
            if (eMember != null && eMember.MemberEligibilityID != null)
            {
                MemberPrimaryEligibilityID = (int)eMember.MemberEligibilityID;
            }
            var query = from r in _context.RateCodes
                        join c in _context.CommonCodes on r.RateTypeID equals c.CommonCodeID
                        join cs in _context.CommonCodes on r.SourceTypeID equals cs.CommonCodeID
                        join mele in _context.MemberEligibilitys.Where(e => e.MemberEligibilityID == MemberPrimaryEligibilityID) on r.LOBID equals mele.LOBID
                        where r.RecordStatus == (int)RecordStatus.Active && r.EffectiveDate >= mele.EffectiveDate && r.EffectiveDate <= mele.TermDate
                        select new RateCodeModel()
                        {
                            RateCodeID = r.RateCodeID,
                            Code = r.Code,
                            RateType = c.ShortName,
                            SourceType = cs.ShortName,
                            Rate = r.Rate,
                            EffectiveDate = r.EffectiveDate,
                            LOBID = r.LOBID,
                            RateTypeID = r.RateTypeID,
                            SourceTypeID = r.SourceTypeID,
                            TermDate = r.TermDate
                        };
            return query;
        }
    }
}
