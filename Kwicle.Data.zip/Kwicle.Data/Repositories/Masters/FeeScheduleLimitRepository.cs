﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    /// <summary>
    /// Implements IFeeScheduleRepository, do not create instance directly, instead use dependency injection of IFeeScheduleRepository
    /// </summary>
    public class FeeScheduleLimitRepository : BaseRepository<FeeScheduleLimit>, IFeeScheduleLimitRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public FeeScheduleLimitRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Interface Methods Implementation    
        public IQueryable<FeeScheduleLimitModel> FeeScheduleLimits { get { return this.GetFeeScheduleLimits(); } }

        public IQueryable<FeeScheduleLimitModel> GetFeeScheduleLimits()
        {
            var feeScheduleQuery = from n in _context.FeeScheduleLimits
                                   from r in _context.CommonCodes
                                       .Where(x => x.CommonCodeID == n.LimitTypeID).DefaultIfEmpty()
                                   from p in _context.CommonCodes
                                       .Where(x => x.CommonCodeID == n.LimitDurationTypeID).DefaultIfEmpty()
                                   from z in _context.CommonCodes
                                       .Where(x => x.CommonCodeID == n.LimitMaxTypeID).DefaultIfEmpty()
                                   select new FeeScheduleLimitModel()
                                   {
                                       FeeScheduleLimitID = n.FeeScheduleLimitID,
                                       Code = n.Code,
                                       Quantity = n.Quantity,
                                       LimitTypeID = (int?)n.LimitTypeID,
                                       LimitType = r.Code,
                                       LimitDuration = n.LimitDuration,
                                       LimitDurationTypeID = (int?)n.LimitDurationTypeID,
                                       LimitDurationType = p.Code,
                                       LimitMax = n.LimitMax,
                                       LimitMaxTypeID = (int?)n.LimitMaxTypeID,
                                       LimitMaxType = z.Code,
                                       EffectiveDate = n.EffectiveDate,
                                       TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                                   };
            return feeScheduleQuery;
        }

        public List<KeyValuePair<int, string>> GetFeeScheduleLimitKeyVal()
        {
            List<KeyValuePair<int, string>> Items = new List<KeyValuePair<int, string>>();
            Items = _context.FeeScheduleLimits.Where(x => x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.Code).Select(x => new KeyValuePair<int, string>(x.FeeScheduleLimitID, x.Code)).ToList();

            return Items;
        }
        #endregion
    }
}
