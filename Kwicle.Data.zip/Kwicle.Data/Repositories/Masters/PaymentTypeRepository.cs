﻿using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class PaymentTypeRepository : BaseRepository<PaymentType>, IPaymentTypeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion


        public PaymentTypeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
    }
}
