﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel;
using System.Collections.Generic;

namespace Kwicle.Data.Repositories.Masters
{
    public class LocationRepository : BaseRepository<Location>, ILocationRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region ctor
        public LocationRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        public List<KeyVal<int, string>> GetKeyVal()
        {
            var query = from n in _viewContext.GetLocations.Where(x => x.RecordStatus != (int)RecordStatus.Deleted && x.RecordStatus != (int)RecordStatus.VoidOrInvalid)
                        select new KeyVal<int, string>
                        {
                            Key = n.LocationID,
                            Value = n.LocationName
                        };

            var res = query.ToList();
            return res;
        }
        #endregion

        #region  Methods
        public IQueryable<LocationModel> GetLocation(int? LocationID)
        {
            var res = from n in _viewContext.GetLocations.Where(x => (!LocationID.HasValue || x.LocationID == LocationID) && x.RecordStatus != (int)RecordStatus.Deleted)
                      select new LocationModel()
                      {
                          LocationID = n.LocationID,
                          LocationTypeID = n.LocationTypeID,
                          LocationTypeName = n.LocationTypeName,
                          LocationName = n.LocationName,
                          RegionID = n.RegionID,
                          RegionName = n.RegionName,
                          Address1 = n.Address1,
                          Address2 = n.Address2,
                          City = n.City,
                          State = n.State,
                          StateFullName = n.StateFullName,
                          County = n.County,
                          Country = n.Country,
                          Zip = n.Zip,
                          Phone = n.Phone,
                          Fax = n.Fax,
                          EmergencyPhone = n.EmergencyPhone,
                          SecondaryPhone = n.SecondaryPhone,
                          PrimaryEmail = n.PrimaryEmail,
                          SecondaryEmail = n.SecondaryEmail,
                          AfterHoursCoverage = n.AfterHoursCoverage,
                          MinimumAge = n.MinimumAge,
                          MaximumAge = n.MaximumAge,
                          IsHandicapAccessible = n.IsHandicapAccessible,
                          IsPCP = n.IsPCP,
                          IsAcceptingNewPatient = n.IsAcceptingNewPatient,
                          IsIncludeInProviderDirectory = n.IsIncludeInProviderDirectory,
                          GenderRestriction = n.GenderRestriction,
                          SundayFromHour = n.SundayFromHour,
                          MondayFromHour = n.MondayFromHour,
                          TuesdayFromHour = n.TuesdayFromHour,
                          WednesdayFromHour = n.WednesdayFromHour,
                          ThursdayFromHour = n.ThursdayFromHour,
                          FridayFromHour = n.FridayFromHour,
                          SaturdayFromHour = n.SaturdayFromHour,
                          SundayToHour = n.SundayToHour,
                          MondayToHour = n.MondayToHour,
                          TuesdayToHour = n.TuesdayToHour,
                          WednesdayToHour = n.WednesdayToHour,
                          ThursdayToHour = n.ThursdayToHour,
                          FridayToHour = n.FridayToHour,
                          SaturdayToHour = n.SaturdayToHour,
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                          CreatedBy = n.CreatedBy
                      };
            return res;
        }
        #endregion
    }
}
