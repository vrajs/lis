﻿using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Xml.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class CPTCodeRepository : BaseRepository<CPTCode>, ICPTCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Constructor

        public CPTCodeRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CPTCodeID"></param>
        /// <returns></returns>
        public CPTCodeModel GetCPTCodeByID(int CPTCodeID)
        {
            var query = from n in _context.CPTCodes.Where(c => c.CPTCodeID == CPTCodeID)
                        select new CPTCodeModel()
                        {
                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query.FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<CPTCodeModel> GetCPTCodes(int ClinicalCodeTypeID)
        {
            var query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && (ClinicalCodeTypeID == 0 ? true == true : c.ClinicalCodeTypeID == ClinicalCodeTypeID) && c.HomeGrown != "Y")
                        select new CPTCodeModel()
                        {
                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate
                        };
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<CPTCodeModel> GetModifierCodes()
        {
            var query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.Modifier)
                        select new CPTCodeModel()
                        {
                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<CPTCodeModel> GetHCPCCodes()
        {
            var query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.HCPCS)
                        select new CPTCodeModel()
                        {
                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<CPTCodeModel> GetCPTAndHCPCCodes(int ClinicalCodeTypeID)
        {
            var query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && (ClinicalCodeTypeID == 0 ? true == true : c.ClinicalCodeTypeID == ClinicalCodeTypeID) && (c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.CPT2 || c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.CPT4 || c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.HCPCS))
                        select new CPTCodeModel()
                        {
                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<CPTCodeModel> GetCPTAndHCPCAndModCodes()
        {
            var query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && (c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.CPT2 || c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.CPT4 || c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.HCPCS || c.ClinicalCodeTypeID == (int)Core.Common.ClinicalCodeType.Modifier))
                        select new CPTCodeModel()
                        {
                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID

                        };
            return query;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ProcedureCodes"></param>
        /// <returns></returns>
        public List<CPTCodeModel> ValidateCPTCodes(List<ClaimServiceLineValidationModel> ProcedureCodes)
        {
            XElement xmlElements = new XElement("CPTCodes", from i in ProcedureCodes
                                                            select new XElement("CPTCode",
                                                                new XElement("ProcedureCode", i.L2400Sv101ProcCode),
                                                                new XElement("SequenceNumber", i.L2400Lx01AssignedNum)
                ));

            object[] paraMemberEligibility = { new SqlParameter("@CPTCodexml", xmlElements.ToString()) };


            return _context.ExecuteStoreProcedure<CPTCodeModel>("edi.usp_ValidateCPTCode", paraMemberEligibility);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ProcedureCodes"></param>
        /// <returns></returns>
        public List<CPTCodeModel> ValidateModifierCodes(List<ClaimServiceLineValidationModel> ProcedureCodes)
        {
            XElement xmlElements = new XElement("CPTCodes", from i in ProcedureCodes
                                                            select new XElement("CPTCode",
                                                                new XElement("ProcedureCode", i.Modifier),
                                                                new XElement("SequenceNumber", i.L2400Lx01AssignedNum)
                ));

            object[] paraMemberEligibility = { new SqlParameter("@CPTCodexml", xmlElements.ToString()) };


            return _context.ExecuteStoreProcedure<CPTCodeModel>("edi.usp_ValidateCPTCode", paraMemberEligibility);

            //return (from code in _viewContext.GetCPTCode
            //        join c in ProcedureCodes on code.Code equals c.Modifier
            //        select new CPTCodeModel
            //        {
            //            Code = code.Code,
            //            SequenceNumber = c.L2400Lx01AssignedNum
            //        }).ToList();
        }
        /// <summary>
        /// returns all CPTCodes based on the clinicalCodeTypeID
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<CPTCodeModel> GetAllCPTCodes(int ClinicalCodeTypeID)
        {
            var query = from n in _context.CPTCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && ((ClinicalCodeTypeID == 0) ? true : c.ClinicalCodeTypeID == ClinicalCodeTypeID) && c.HomeGrown != "Y")
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new CPTCodeModel()
                        {

                            CPTCodeID = n.CPTCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate.Date == DateTime.MaxValue.Date ? null : (DateTime?)n.TermDate,
                            Gender = n.Gender,
                            ClinicalCodeType = com_code.Code,
                            ClinicalCodeTypeName = com_code.ShortName,
                            IsFreezed = n.IsFreezed
                        };
            return query;
        }
        #endregion
    }
}