﻿using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Masters
{
    public class BillTypeCodeRepository : BaseRepository<BillTypeCode>, IBillTypeCodeRepository
    {

        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public BillTypeCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }       
        #endregion


        #region  Methods
        public BillTypeCodeModel GetBillTypeCodeByID(int BillTypeCodeID)
        {
            var query = from n in _context.BillTypeCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.BillTypeCodeID == BillTypeCodeID)
                        select new BillTypeCodeModel()
                        {
                            BillTypeCodeID = n.BillTypeCodeID,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            Code = n.Code,
                            ShortDescription = n.ShortDescription,
                            SequenceNumber = n.SequenceNumber
                        };

            return query.FirstOrDefault();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Code"></param>
        /// <returns></returns>
        public BillTypeCodeModel GetBillTypeCodeByCode(string Code)
        {
            var query = from n in _context.BillTypeCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.Code == Code)
                        select new BillTypeCodeModel()
                        {
                            BillTypeCodeID = n.BillTypeCodeID,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            Code = n.Code,
                            ShortDescription = n.ShortDescription,
                            SequenceNumber = n.SequenceNumber
                        };

            return query.FirstOrDefault();
        }

        public IQueryable<BillTypeCodeModel> GetBillTypeCodes(int ClinicalCodeTypeID)
        {
            var query = from n in _context.BillTypeCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && (ClinicalCodeTypeID == 0 ? true == true : c.ClinicalCodeTypeID == ClinicalCodeTypeID))
                        select new BillTypeCodeModel()
                        {
                            BillTypeCodeID = n.BillTypeCodeID,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            Code = n.Code,
                            ShortDescription = n.ShortDescription,
                            SequenceNumber = n.SequenceNumber
                        };
            return query;
        }
        #endregion
    }
}
