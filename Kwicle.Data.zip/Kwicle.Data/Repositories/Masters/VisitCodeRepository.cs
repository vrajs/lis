﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class VisitCodeRepository : BaseRepository<VisitCode>, IVisitCodeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public VisitCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public IQueryable<VisitCodeModel> GetAllVisitCode()
        {
            var query = from n in _context.VisitCodes.Where(x => x.RecordStatus == (int)RecordStatus.Active)
                      from r in _context.CommonCodes
                          .Where(x => x.CommonCodeID == n.VisitTypeID).DefaultIfEmpty()
                      from p in _context.CommonCodes
                          .Where(x => x.CommonCodeID == n.TimePeriodID).DefaultIfEmpty()
                      from z in _context.CommonCodes
                          .Where(x => x.CommonCodeID == n.BeneMaxTimePeriodID).DefaultIfEmpty()
                      select new VisitCodeModel()
                      {
                          VisitCodeID = n.VisitCodeID,
                          //SubCompanyID = n.SubCompanyID,
                          Code = n.Code,
                          Description = n.Description,
                          VisitTypeID = n.VisitTypeID,
                          VisitType = r.ShortName,
                          MaxAmount = n.MaxAmount,
                          MaxUnits = n.MaxUnits,
                          TimePeriodID = n.TimePeriodID,
                          TimePeriod = p != null ? p.ShortName : "",
                          IsServiceOutsideUS = n.IsServiceOutsideUS,
                          BenMaxUnit = n.BenMaxUnit,
                          BeneMaxTimePeriodID = n.BeneMaxTimePeriodID,
                          BeneMaxTimePeriod = z != null ? z.ShortName : "",
                          EffectiveDate = n.EffectiveDate,
                          TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                      };

            return query;
        }
        #endregion
    }
}
