﻿using Kwicle.Core.Entities;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class CodeTypeRepository : BaseRepository<CodeType>, ICodeTypeRepository
    {
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        public CodeTypeRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        public IQueryable<vwCodeTypeList> GetAllCodeTypes()
        {
            try
            {
                IQueryable<vwCodeTypeList> query;
                query = this._viewContext.vwCodeTypeLists;                
                query = query.OrderByDescending(x => x.CreatedDate);
                
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetAllCodeTypes", ex.Message);
                return null;
            }

        }
    }
}
