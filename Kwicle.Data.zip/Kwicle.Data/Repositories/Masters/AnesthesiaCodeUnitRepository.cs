﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class AnesthesiaCodeUnitRepository : BaseRepository<AnesthesiaCodeUnit> , IAnesthesiaCodeUnitRepository
    {
        private readonly KwicleContext _context;

        public AnesthesiaCodeUnitRepository(KwicleContext context) : base (context)
        {
            _context = context;
        }

        public IQueryable<AnesthesiaCodeUnitModel> GetAnesthesiaCodeUnits()
        {
            IQueryable<AnesthesiaCodeUnitModel> queryable = from x in _context.AnesthesiaCodeUnits
                                                            //where x.RecordStatus == (int)RecordStatus.Active
                                                            select new AnesthesiaCodeUnitModel()
                                                            {
                                                                AnesthesiaCodeUnitID = x.AnesthesiaCodeUnitID,
                                                                CPTCode = x.CPTCode,
                                                                BaseUnit = x.BaseUnit,
                                                                ProductID = x.ProductID,
                                                                ProductName = x.Product.ProductName,
                                                                EffectiveDate = x.EffectiveDate,
                                                                TermDate = (x.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : x.TermDate
                                                            };
            return queryable;
        }
    }
}
