﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class DBFieldRepository : BaseRepository<DBField>, IDBFieldRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public DBFieldRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Get Methods
        public List<KeyVal<int, string>> GetValues(int DBFieldID)
        {
            List<KeyVal<int, string>> items = new List<KeyVal<int, string>>();
            var dbFieldItem = _context.DBFields.Where(e => e.DBFieldID == DBFieldID).FirstOrDefault();
            if (dbFieldItem != null)
            {
                items = _context.ExecuteStoreProcedure<KeyVal<int, string>>(dbFieldItem.LovQuery, null, System.Data.CommandType.Text);
            }
            return items;
        }

        public List<DBField> GetDBFields(List<int> DBFields)
        {
            List<DBField> items = new List<DBField>();
            items = _context.DBFields.Where(e => DBFields.Contains(e.DBFieldID)).ToList();
            return items;
        }
        #endregion
    }
}
