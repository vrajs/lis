﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System.Linq;
using System;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Kwicle.Core.Common.EDI;

namespace Kwicle.Data.Repositories.Masters
{
    public class RevenueCodeRepository : BaseRepository<RevenueCode>, IRevenueCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor

        public RevenueCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="RevenueCodeID"></param>
        /// <returns></returns>
        public RevenueCodeModel GetRevenueCodeByID(int RevenueCodeID)
        {
            var query = from n in _context.RevenueCodes.Where(c => c.RevenueCodeID == RevenueCodeID)
                        select new RevenueCodeModel()
                        {
                            RevenueCodeID = n.RevenueCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            LongDescription = n.LongDescription,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                        };
            return query.FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<RevenueCodeModel> GetRevenueCodes()
        {
            var query = from n in _context.RevenueCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active)
                        select new RevenueCodeModel()
                        {
                            RevenueCodeID = n.RevenueCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query;
        }

        public IQueryable<RevenueCodeModel> GetRevenueUBCodes(int[] ClinicalCodeTypeID)
        {
            var query = from n in _context.RevenueCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && ClinicalCodeTypeID.Contains(c.ClinicalCodeTypeID) && c.HomeGrown != "Y")
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new RevenueCodeModel()
                        {
                            RevenueCodeID = n.RevenueCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate,
                            ClinicalCodeType = com_code.ShortName,
                            ClinicalCodeTypeName = com_code.ShortName,
                            IsFreezed = n.IsFreezed
                        };
            return query;
        }

        #region EDI

        public List<RevenueCodeModel> ValidateUBCode(List<EDIRevenueCodeModel> UBCodes)
        {
            XElement xmlElements = new XElement("UBCodes", from i in UBCodes
                                                           select new XElement("UBCode",
                                                           new XElement("Code", i.Code),
                                                           new XElement("SequenceNumber", i.SequenceNumber),
                                                           new XElement("ClinicalCodeTypeID", i.ClinicalCodeTypeID)
               ));
            object[] para = { new SqlParameter("@UBCodexml", xmlElements.ToString()) };
            return _context.ExecuteStoreProcedure<RevenueCodeModel>("edi.usp_ValidateUBCode", para);
        }
        #endregion
        #endregion
    }
}