﻿using Kwicle.Common.Utility;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class FeeScheduleHeaderRepository : BaseRepository<FeeScheduleHeader> , IFeeScheduleHeaderRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public FeeScheduleHeaderRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        public IQueryable<FeeScheduleHeaderModel> GetFeeScheduleHeaders()
        {
            IQueryable<FeeScheduleHeaderModel> query = (from fsh in _context.FeeScheduleHeaders
                                                  select new FeeScheduleHeaderModel()
                                                  {
                                                      FeeScheduleHeaderID = fsh.FeeScheduleHeaderID,
                                                      Description = fsh.Description,                                                      
                                                      Code = fsh.Code,                                                      
                                                      EffectiveDate = fsh.EffectiveDate,
                                                      TermDate = (fsh.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : fsh.TermDate
                                                  });
            return query;
        }

        public new void Delete(FeeScheduleHeader model)
        {
            using (this._context)
            {
                try
                {
                    var deletedData = _context.FeeScheduleDetails.Where(x => x.FeeScheduleHeaderID == model.FeeScheduleHeaderID);
                    _context.FeeScheduleDetails.RemoveRange(deletedData);
                    _context.Remove(model);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    if (ex.InnerException is SqlException)
                    {
                        SqlException se = (SqlException)ex.InnerException;
                        if (se.Errors.Count > 0)
                        {
                            switch (se.Errors[0].Number)
                            {
                                case 547: // Foreign Key violation
                                    base.DbState.AddErrorMessage("CanNotPerformDelete", "Can't delete this record due to dependencies !!!");
                                    break;
                                default:
                                    base.DbState.AddErrorMessage("CanNotPerformDelete", ex.ToErrorMessage());
                                    break;
                            }
                        }
                    }
                    else
                        base.DbState.AddErrorMessage("CanNotPerformDelete", ex.ToErrorMessage());
                }
            }
        }

        public int CopyFeeSchedule(FeeScheduleHeaderModel model, string createdBy, DateTime createdDate)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@FeeScheduleHeaderID", model.FeeScheduleHeaderID),
                    new SqlParameter("@Code", model.Code),
                    new SqlParameter("@Description", model.Description),
                    new SqlParameter("@EffectiveDate", model.EffectiveDate),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@CreatedDate",createdDate),
                    new SqlParameter("@CreatedFeeScheduleHeaderID",SqlDbType.Int) {Direction = ParameterDirection.Output},
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output},                   
                    
                    new SqlParameter("@TermDate", model.TermDate),
                    new SqlParameter("@FeeScheduleDetailRate",model.FeeScheduleDetailRate) ,                    
                };
                if (model.TermDate == null || model.TermDate == DateTime.MinValue)
                {
                    parameters[8].Value = DBNull.Value;
                }
                if (model.FeeScheduleDetailRate == null)
                {
                    parameters[9].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[master].[usp_CopyFeeSchedule] @FeeScheduleHeaderID,@Code,@Description, @EffectiveDate, @CreatedBy, @CreatedDate, @CreatedFeeScheduleHeaderID out, @ErrorMessage out,@TermDate,@FeeScheduleDetailRate", parameters);
                _context.SaveChanges();

                var errorMessage = Convert.ToString(parameters[7].Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotCopyFeeSchedule : CopyFeeSchedule", errorMessage);
                }

                var feeScheduleHeaderId = Convert.ToInt32(parameters[6].Value);
                return feeScheduleHeaderId;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotCopyFeeSchedule", ex.Message);
                return -1;
            }
        }
    }
}
