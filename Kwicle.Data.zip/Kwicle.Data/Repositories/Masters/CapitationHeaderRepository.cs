﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Kwicle.Data.Repositories.Masters
{
    /// <summary>
    /// Implements ICapitationHeaderRepository, do not create instance directly, instead use dependency injection of ICapitationHeaderRepository
    /// </summary>
    public class CapitationHeaderRepository : BaseRepository<CapitationHeader>, ICapitationHeaderRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public CapitationHeaderRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region Interface Methods Implementation    
        public List<KeyValuePair<int, string>> GetCapitationKeyVal()
        {
            List<KeyValuePair<int, string>> Items = new List<KeyValuePair<int, string>>();
            Items = _context.CapitationHeaders.Where(x => x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.CapitationName).Select(x => new KeyValuePair<int, string>(x.CapitationHeaderId, x.CapitationName)).ToList();
            return Items;
        }

        //public IQueryable<CapitationHeader> CapitationHeaders { get { return this.GetCapitationHeaders(); } }

        //public IQueryable<CapitationHeader> GetCapitationHeaders()
        //{
        //    var capitationHeaderQuery = from n in _context.CapitationHeaders.Where(x => x.RecordStatus == (int)RecordStatus.Active)
        //                           from r in _context.CommonCodes
        //                               .Where(x => x.CommonCodeID == n.LimitTypeID).DefaultIfEmpty()
        //                           from p in _context.CommonCodes
        //                               .Where(x => x.CommonCodeID == n.LimitDurationTypeID).DefaultIfEmpty()
        //                           from z in _context.CommonCodes
        //                               .Where(x => x.CommonCodeID == n.LimitMaxTypeID).DefaultIfEmpty()
        //                           select new CapitationHeader()
        //                           {
        //                               CapitationHeaderID = n.CapitationHeaderLimitID,
        //                               Code = n.Code,
        //                               Quantity = n.Quantity,
        //                               LimitTypeID = (int?)n.LimitTypeID,
        //                               LimitType = r.Code,
        //                               LimitDuration = n.LimitDuration,
        //                               LimitDurationTypeID = (int?)n.LimitDurationTypeID,
        //                               LimitDurationType = p.Code,
        //                               LimitMax = n.LimitMax,
        //                               LimitMaxTypeID = (int?)n.LimitMaxTypeID,
        //                               LimitMaxType = z.Code,
        //                               EffectiveDate = n.EffectiveDate,
        //                               TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
        //                           };
        //    return capitationHeaderQuery;
        //}
        #endregion
    }
}
