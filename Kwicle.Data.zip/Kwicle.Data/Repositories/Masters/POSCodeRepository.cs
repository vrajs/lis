﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class POSCodeRepository : BaseRepository<POSCode>, IPOSCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor

        public POSCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="POSCodeID"></param>
        /// <returns></returns>
        public POSCodeModel GetPOSCodeByID(int POSCodeID)
        {
            var query = from n in _context.POSCodes.Where(c => c.POSCodeID == POSCodeID)
                        select new POSCodeModel()
                        {
                            POSCodeID = n.POSCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            FacilityNonFacility = n.FacilityNonFacility,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                        };
            return query.FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<POSCodeModel> GetPOSCodes()
        {
            var query = from n in _context.POSCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.HomeGrown != "Y")
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new POSCodeModel()
                        {
                            POSCodeID = n.POSCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            FacilityNonFacility = n.FacilityNonFacility,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate,
                            ClinicalCodeType = com_code.Code,
                            ClinicalCodeTypeName = com_code.ShortName,
                            IsFreezed = n.IsFreezed
                        };
            return query;
        }

        #endregion
    }
}