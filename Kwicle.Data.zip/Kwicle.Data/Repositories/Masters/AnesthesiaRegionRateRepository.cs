﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class AnesthesiaRegionRateRepository : BaseRepository<AnesthesiaRegionRate>, IAnesthesiaRegionRateRepository
    {
        private readonly KwicleContext _context;
        public AnesthesiaRegionRateRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<AnesthesiaRegionRateModel> GetAnesthesiaRegionRates()
        {
            IQueryable<AnesthesiaRegionRateModel> queryable = (from x in _context.AnesthesiaRegionRates
                                                               let state = _context.ZipCodes.Where(zc => zc.State == x.State).First()
                                                               select new AnesthesiaRegionRateModel()
                                                               {
                                                                   AnesthesiaRegionRateID = x.AnesthesiaRegionRateID,
                                                                   State = x.State,
                                                                   StateFullName = state.StateFullName,
                                                                   LocalityCode = x.LocalityCode,
                                                                   Carrier = x.Carrier,
                                                                   Area = x.Area,
                                                                   Rate = x.Rate,                                                                   
                                                                   EffectiveDate = x.EffectiveDate,
                                                                   TermDate = (x.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : x.TermDate
                                                               });
            return queryable;
        }
    }
}
