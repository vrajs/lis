﻿using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Masters
{
    public class OtherCodeRepository : BaseRepository<OtherCode>, IOtherCodeRepository
    {

        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public OtherCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }       
        #endregion


        
    }
}
