﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class TimelyFilingRepository : BaseRepository<TimelyFiling>, ITimelyFilingRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public TimelyFilingRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation  
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<TimelyFilingModel> GetTimelyFilings()
        {
            var res = (from tf in _context.TimelyFilings
                       //where tf.RecordStatus == (int)RecordStatus.Active
                       //join ps in _context.CommonCodes on tf.ProviderStatusID equals ps.CommonCodeID
                       //join pt in _context.CommonCodes on tf.ProviderTypeID equals pt.CommonCodeID
                       select new TimelyFilingModel()
                       {
                           TimelyFilingID = tf.TimelyFilingID,
                           Days = tf.Days,
                           Description = tf.Description,
                           ProviderStatusID = tf.ProviderStatusID,
                           ProviderStatusName = tf.ProviderStatus.ShortName,
                           ProviderTypeID = tf.ProviderTypeID,
                           ProviderTypeName = tf.ProviderType.ShortName,
                           EffectiveDate = tf.EffectiveDate,
                           TermDate = (tf.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : tf.TermDate,
                       });
            return res;
        }
        #endregion
    }
}
