﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class RegionZipCodeRepository : BaseRepository<RegionZipCode>, IRegionZipCodeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion


        public RegionZipCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        /// <summary>
        /// returns list of RegionZipCode based on ZipCodeID
        /// </summary>
        /// <param name="ZipCodeID"></param>
        /// <returns></returns>
        public IQueryable<RegionZipCodeModel> GetRegionZipCodes(int ZipCodeID)
        {
            var query = from n in _context.RegionZipCodes.Where(c => c.ZipCodeID == ZipCodeID && c.RecordStatus != (byte)RecordStatus.Deleted)
                        select new RegionZipCodeModel()
                        {
                            RegionZipCodeID = n.RegionZipCodeID,
                            RegionID = n.RegionID,
                            RegionName = n.Region.Name,
                            ProductTypeID = n.Region.ProductType.ProductTypeID,
                            ProductTypeName = n.Region.ProductType.ProductTypeName,
                            ZipCodeID = n.ZipCodeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = (n.TermDate.Date == DateTime.MaxValue.Date ? (DateTime?)null : n.TermDate)
                        };
            return query;
        }
    }
}
