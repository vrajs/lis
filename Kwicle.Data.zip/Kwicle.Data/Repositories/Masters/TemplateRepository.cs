﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class TemplateRepository : BaseRepository<Template>, ITemplateRepository
    {

        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor

        public TemplateRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public List<KeyVal<string, string>> GetPlaceholderDictionary(int TemplateId, int Id)
        {   
            object[] parameters = new[]{ new SqlParameter("@TemplateId", TemplateId) , new SqlParameter("@Id", Id) };
            var placeholderKeyVal = _context.ExecuteStoreProcedure<KeyVal<string, string>>("[master].[usp_GetTemplatePlaceHolder]", parameters);
            return placeholderKeyVal;
        }

        #endregion

        #region  Methods
        public List<TemplateViewModel> GetTemplate(string SubTypeName)
        {
            var query = from t in _context.Templates
                        join st in _context.TemplateSubTypes on t.TemplateSubTypeID equals st.TemplateSubTypeID
                        where t.RecordStatus == (int)RecordStatus.Active && st.SubTypeName == SubTypeName
                        select new TemplateViewModel()
                        {
                            TemplateID = t.TemplateID,
                            TemplateTypeID = t.TemplateTypeID,
                            TemplateName = t.TemplateName,
                            HtmltemplateContent = t.RelativeFilePath,
                            IsDefault = t.IsDefault,
                            EffectiveDate = t.EffectiveDate,
                            TermDate = (t.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : t.TermDate,
                        };
            return query.ToList();
        }

        public Template GetTemplate(int TemplateTypeID, int TemplateSubTypeID, string TemplateName)
        {
            var template =  _context.Templates.Include(i => i.TemplatePlaceHolders).Single(i => i.TemplateTypeID == TemplateTypeID && i.TemplateSubTypeID == TemplateSubTypeID && i.TemplateName == TemplateName);
            return template;

        }
        #endregion
    }
}