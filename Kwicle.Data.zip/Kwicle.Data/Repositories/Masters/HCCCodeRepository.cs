﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class HCCCodeRepository : BaseRepository<HCCCode>, IHCCCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor

        public HCCCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="HCCCodeID"></param>
        /// <returns></returns>
        public HCCCodeModel GetHCCCodeByID(int HCCCodeID)
        {
            var query = from n in _context.HCCCodes.Where(c => c.HCCCodeID == HCCCodeID)
                        select new HCCCodeModel()
                        {
                            HCCCodeID = n.HCCCodeID,
                            Code = n.Code,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            HomeGrown = n.HomeGrown,
                            MappedCode = n.MappedCode,
                            //CommunityFactor = n.CommunityFactor,
                            //InstitutionalFactor = n.InstitutionalFactor,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate
                        };
            return query.FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<HCCCodeModel> GetHCCCodes()
        {
            var query = from n in _context.HCCCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active)
                        select new HCCCodeModel()
                        {
                            HCCCodeID = n.HCCCodeID,
                            Code = n.Code,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            HomeGrown = n.HomeGrown,
                            MappedCode = n.MappedCode,
                            //CommunityFactor = n.CommunityFactor,
                            //InstitutionalFactor = n.InstitutionalFactor,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate
                        };
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<HCCCodeModel> GetHCCCodes(int? ClinicalCodeTypeID)
        {
            var query = from n in _context.HCCCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && (ClinicalCodeTypeID > 0 ? c.ClinicalCodeTypeID == ClinicalCodeTypeID : true == true))
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new HCCCodeModel()
                        {
                            HCCCodeID = n.HCCCodeID,
                            Code = n.Code,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            HomeGrown = n.HomeGrown,
                            MappedCode = n.MappedCode,
                            //CommunityFactor = n.CommunityFactor,
                            //InstitutionalFactor = n.InstitutionalFactor,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate,
                            ClinicalCodeType = com_code.Code,
                            ClinicalCodeTypeName = com_code.Code,
                            IsFreezed = n.IsFreezed
                        };
            return query;
        }
        #endregion
    }
}