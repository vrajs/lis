﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Repositories;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public class InsuranceCarrierRepository : BaseRepository<InsuranceCarrier>, IInsuranceCarrierRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public InsuranceCarrierRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public IQueryable<InsuranceCarrierModel> GetInsuranceCarriers()
        {
            var query = from n in _context.InsuranceCarriers
                        where n.RecordStatus == (byte)RecordStatus.Active
                        select new InsuranceCarrierModel()
                        {
                            InsuranceCarrierID = n.InsuranceCarrierID,
                            Address1 = n.Address1,
                            Address2 = n.Address2,
                            City = n.City,
                            Country = n.Country,
                            County = n.County,
                            Email = n.Email,
                            Fax = n.Fax,
                            InsuranceName = n.InsuranceName,
                            InsuranceTypeId = n.InsuranceTypeId.ToString(),
                            State = n.State,
                            WorkPhone = n.WorkPhone,
                            Zip = n.Zip
                        };
            return query;
        }
        #endregion
    }
}
