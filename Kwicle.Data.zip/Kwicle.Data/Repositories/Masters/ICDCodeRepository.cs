﻿using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class ICDCodeRepository : BaseRepository<ICDCode>, IICDCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Constructor

        public ICDCodeRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ICDCodeID"></param>
        /// <returns></returns>
        public ICDCodeModel GetICDCodeByID(int ICDCodeID)
        {
            var query = from n in _context.ICDCodes.Where(c => c.ICDCodeID == ICDCodeID)
                        select new ICDCodeModel()
                        {
                            ICDCodeID = n.ICDCodeID,
                            Code = n.Code,
                            CodeWithoutDecimal = n.CodeWithoutDecimal,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query.FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<ICDCodeModel> GetICDCodes(int ClinicalCodeTypeID)
        {
            var query = from n in _context.ICDCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && c.HomeGrown != "Y" && (ClinicalCodeTypeID == 0 ? true == true : c.ClinicalCodeTypeID == ClinicalCodeTypeID))
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new ICDCodeModel()
                        {
                            ICDCodeID = n.ICDCodeID,
                            Code = n.Code,
                            CodeWithoutDecimal = n.CodeWithoutDecimal,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            MappedCode = n.MappedCode,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate,
                            ClinicalCodeType = com_code.Code,
                            ClinicalCodeTypeName = com_code.ShortName,
                            IsFreezed = n.IsFreezed
                        };
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ICDCodes"></param>
        /// <returns></returns>
        public List<ICDCodeModel> ValidateICDCode(List<ICDCodeModel> ICDCodes)
        {
            XElement xmlElements = new XElement("ICDCodes", from i in ICDCodes
                                                            select new XElement("ICDCode",
                                                                new XElement("CodeWithoutDecimal", i.CodeWithoutDecimal),
                                                                new XElement("SequenceNumber", i.SequenceNumber),
                                                                new XElement("ClinicalCodeTypeID", i.ClinicalCodeTypeID)
                ));

            object[] paraMemberEligibility = { new SqlParameter("@ICDCodexml", xmlElements.ToString()) };


            return _context.ExecuteStoreProcedure<ICDCodeModel>("edi.usp_ValidateICDCode", paraMemberEligibility);

            //return (from n in _viewContext.GetICDCode
            //        join d in ICDCodes on n.CodeWithoutDecimal equals d.CodeWithoutDecimal
            //        select new ICDCodeModel()
            //        {
            //            ICDCodeID = n.ICDCodeID,
            //            Code = n.Code,
            //            CodeWithoutDecimal = n.CodeWithoutDecimal,
            //            HomeGrown = n.HomeGrown,
            //            ShortDescription = n.ShortDescription,
            //            LongDescription = n.LongDescription,
            //            SequenceNumber = d.SequenceNumber,
            //            ClinicalCodeTypeID = d.ClinicalCodeTypeID
            //        }).ToList();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CodeWithoutDecimal"></param>
        /// <returns></returns>
        public ICDCodeModel GetICDCodeByCode(string CodeWithoutDecimal)
        {
            var query = from n in _viewContext.GetICDCode.Where(c => c.CodeWithoutDecimal == CodeWithoutDecimal)
                        select new ICDCodeModel()
                        {
                            ICDCodeID = n.ICDCodeID,
                            Code = n.Code,
                            CodeWithoutDecimal = n.CodeWithoutDecimal,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query.FirstOrDefault();
        }
        public List<EDIICDCodeModel> ValidateDiagCode(List<EDIICDCodeModel> ICDCodes)
        {
            XElement xmlElements = new XElement("ICDCodes", from i in ICDCodes
                                                            select new XElement("ICDCode",
                                                                new XElement("CodeWithoutDecimal", i.CodeWithoutDecimal),
                                                                new XElement("SequenceNumber", i.SequenceNumber),
                                                                new XElement("ClinicalCodeTypeID", i.ClinicalCodeTypeID),
                                                                 new XElement("Version", i.Version),
                                                                  new XElement("Qualifier", i.Qualifier)
                ));

            object[] paraMemberEligibility = { new SqlParameter("@ICDCodexml", xmlElements.ToString()) };
            return _context.ExecuteStoreProcedure<EDIICDCodeModel>("edi.usp_ValidateDiagCode", paraMemberEligibility);
        }
        #endregion
    }
}