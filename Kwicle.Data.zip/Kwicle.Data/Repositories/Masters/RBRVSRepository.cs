﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class RBRVSRepository : BaseRepository<RBRVS> , IRBRVSRepository
    {
        private readonly KwicleContext _context;

        public RBRVSRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<RBRVSModel> GetRBRVSList()
        {
            IQueryable<RBRVSModel> queryable = from x in _context.RBRVS                                                                
                                                            select new RBRVSModel()
                                                            {
                                                                RBRVSID = x.RBRVSID,
                                                                HCPCS = x.HCPCS,
                                                                Modifier = x.Modifier,
                                                                Description = x.Description,
                                                                StatusCode = x.StatusCode,
                                                                NotUseMedicarePayment = x.NotUseMedicarePayment,
                                                                WorkRVU = x.WorkRVU,
                                                                NonFacPERVU = x.NonFacPERVU,
                                                                NonFacNAIndicator = x.NonFacNAIndicator,
                                                                FacilityPERVU = x.FacilityPERVU,
                                                                FacNAIndicator = x.FacNAIndicator,
                                                                MPRVU = x.MPRVU,
                                                                NonFacilityTotal = x.NonFacilityTotal,
                                                                FacilityTotal = x.FacilityTotal,
                                                                PCTCInd = x.PCTCInd,
                                                                GlobDays = x.GlobDays,
                                                                PreOP = x.PreOP,
                                                                IntraOP = x.IntraOP,
                                                                PostOP = x.PostOP,
                                                                MultProc = x.MultProc,
                                                                BilatSurg = x.BilatSurg,
                                                                AsstSurg = x.AsstSurg,
                                                                CoSurg = x.CoSurg,
                                                                TeamSurg = x.TeamSurg,
                                                                EndoBase = x.EndoBase,
                                                                ConvFactor = x.ConvFactor,
                                                                PhysDiagProc = x.PhysDiagProc,
                                                                CalFlag = x.CalFlag,
                                                                DiagImagFamIndict = x.DiagImagFamIndict,
                                                                NonFacPEOPPSPay = x.NonFacPEOPPSPay,
                                                                FacPEOPPSPay = x.FacPEOPPSPay,
                                                                MPPEOPPSPay = x.MPPEOPPSPay,
                                                                EffectiveDate = x.EffectiveDate,
                                                                TermDate = (x.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : x.TermDate
                                                            };            
            return queryable;
        }
    }
}
