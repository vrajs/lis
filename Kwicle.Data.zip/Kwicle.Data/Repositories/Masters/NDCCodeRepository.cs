﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class NDCCodeRepository : BaseRepository<NDCCode>, INDCCodeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion


        public NDCCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        public IQueryable<NDCCodeModel> GetNDCCodes(int ClinicalCodeTypeID)
        {
            var query = from n in _context.NDCCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active && (ClinicalCodeTypeID == 0 ? true == true : c.ClinicalCodeTypeID == ClinicalCodeTypeID) && c.HomeGrown != "Y")
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new NDCCodeModel()
                        {
                            NDCCodeID = n.NDCCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate,
                            DosageForm = n.DosageForm,
                            NDCType= n.NDCType,
                            Route =n.Route,
                            Strength = n.Strength,
                            Unit = n.Unit,
                            ClinicalCodeType= com_code.Code,
                            ClinicalCodeTypeName = com_code.ShortName,
                            IsFreezed = n.IsFreezed
                        };

            return query;
        }

    }
}
