﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Masters
{
    public class EditCodeRepository:BaseRepository<EditCode>,IEditCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor
        public EditCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        public IQueryable<EditCodeModel> GetEditCode(int[] PageID)
        {
            //start migration from 2.1 to 3.1
            //var query = (from ed in _context.EditCode
            //            join pg in _context.EditCodeDisplayConfiguration on ed.EditCodeID equals pg.EditCodeID
            //            where ed.RecordStatus == (int)RecordStatus.Active && PageID.Contains(pg.PageID)
            //            select new EditCodeModel()
            //            {
            //                EditCodeID=ed.EditCodeID,
            //                Code=ed.Code,
            //                CodeName=ed.CodeName,
            //                DefaultOutComeCodeID=ed.DefaultOutComeCodeID,
            //                DefaultOutComeID=ed.DefaultOutComeID,
            //                EffectiveDate=ed.EffectiveDate,
            //                TermDate=ed.TermDate
            //            }).GroupBy(g => g.EditCodeID).Select(x => x.FirstOrDefault());
            //return query;

            var query = (from ed in _context.EditCode
                         join pg in _context.EditCodeDisplayConfiguration on ed.EditCodeID equals pg.EditCodeID
                         where ed.RecordStatus == (int)RecordStatus.Active && PageID.Contains(pg.PageID)
                         select new EditCodeModel()
                         {
                             EditCodeID = ed.EditCodeID,
                             Code = ed.Code,
                             CodeName = ed.CodeName,
                             DefaultOutComeCodeID = ed.DefaultOutComeCodeID,
                             DefaultOutComeID = ed.DefaultOutComeID,
                             EffectiveDate = ed.EffectiveDate,
                             TermDate = ed.TermDate
                         }).ToList().GroupBy(g => g.EditCodeID).Select(x => x.FirstOrDefault()).AsQueryable();            

            return query;
            //end migration from 2.1 to 3.1
        }

        public IQueryable<EditCode> GetEditCode(string Code)
        {
            return _context.EditCode.Where(ed => ed.Code == Code);
        }
    }
}
