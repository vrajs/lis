﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class LocalityRepository : BaseRepository<Locality>, ILocalityRepository
    {
        private readonly KwicleContext _context;

        public LocalityRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<LocalityModel> GetLocalityList()
        {
            IQueryable<LocalityModel> queryable = (from x in _context.Localities
                                                  let state = _context.ZipCodes.Where(zc => zc.State == x.State).First()
                                                  select new LocalityModel()
                                                  {
                                                      LocalityID = x.LocalityID,
                                                      Carrier = x.Carrier,
                                                      LocalityCode = x.LocalityCode,
                                                      County = x.County,
                                                      State = x.State,
                                                      StateFullName = state.StateFullName,
                                                      Area = x.Area,                                                      
                                                      EffectiveDate = x.EffectiveDate,
                                                      TermDate = (x.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : x.TermDate
                                                  });
            return queryable;
        }
    }
}
