﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class UserDataAuthorizationRepository : BaseRepository<UserDataAuthorization>, IUserDataAuthorizationRepository
    {
        private readonly KwicleContext _context;

        public UserDataAuthorizationRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public new void AddRange(UserDataAuthorization[] models)
        {
            using (this._context)
            {
                try
                {
                    DeleteUserDataAuthorization(models[0].UserID);
                    _context.AddRange(models);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotPerformAddRangeOperation", ex.Message);
                }
            }
        }

        public void DeleteByUserID(string userID)
        {
            DeleteUserDataAuthorization(userID);
            _context.SaveChanges();
        }

        private void DeleteUserDataAuthorization(string userID)
        {
            var deletedData = _context.UserDataAuthorizations.Where(x => x.UserID == userID);
            if (deletedData != null)
                _context.UserDataAuthorizations.RemoveRange(deletedData);
        }

        //public UserDataAuthorizationModel GetByUserID(string userID)
        //{
        //    var results = _context.UserDataAuthorizations.Where(w => w.UserID == userID).GroupBy(g => new { g.UserID, g.UserName, g.DataPreferenceByID })
        //                  .Select(s => new UserDataAuthorizationModel()
        //                  {
        //                      DataPreferenceByID = s.Key.DataPreferenceByID,
        //                      DataPreferenceIDs = s.Key.DataPreferenceByID == (int)DataPreferenceBy.ByCompany ? (s.Select(x => (int?)x.CompanyID).ToArray()[0] == null ? null : s.Select(x => (int?)x.CompanyID).ToArray())
        //                                            : s.Key.DataPreferenceByID == (int)DataPreferenceBy.BySubComapny ? (s.Select(x => (int?)x.SubCompanyID).ToArray()[0] == null ? null : s.Select(x => (int?)x.SubCompanyID).ToArray())
        //                                            : s.Key.DataPreferenceByID == (int)DataPreferenceBy.ByLOB ? (s.Select(x => (int?)x.LOBID).ToArray()[0] == null ? null : s.Select(x => (int?)x.LOBID).ToArray())
        //                                            : (s.Select(x => x.HealthPlanID).ToArray()[0] == null ? null : s.Select(x => x.HealthPlanID).ToArray())
        //                  }).FirstOrDefault();                                     
        //    return results;   
        //}

        public UserDataAuthorizationModel GetByUserID(string userID)
        {
            try
            {
                //start migration from 2.1 to 3.1
                //var results = _context.UserDataAuthorizations.Where(w => w.UserID == userID)
                var results = _context.UserDataAuthorizations.Where(w => w.UserID == userID).ToList()                
                                .GroupBy(g => new { g.UserID, g.UserName, g.DataPreferenceByID })
                                .Select(s => new UserDataAuthorizationModel()
                                {
                                    DataPreferenceByID = s.Key.DataPreferenceByID,
                                    //DataPreferenceIDs =
                                    //(
                                    //    s.Key.DataPreferenceByID == (int)DataPreferenceBy.ByCompany ?
                                    //        (s.Select(x => (int?)x.CompanyID).Any() ? s.Select(x => (int?)x.CompanyID).ToArray() : null)
                                    //        : s.Key.DataPreferenceByID == (int)DataPreferenceBy.BySubComapny ?
                                    //            (s.Select(x => (int?)x.SubCompanyID).Any() ? s.Select(x => (int?)x.SubCompanyID).ToArray() : null)
                                    //            : s.Key.DataPreferenceByID == (int)DataPreferenceBy.ByLOB ?
                                    //                (s.Select(x => (int?)x.LOBID).Any() ? s.Select(x => (int?)x.LOBID).ToArray() : null)
                                    //                : (s.Select(x => (int?)x.HealthPlanID).Any() ? s.Select(x => (int?)x.HealthPlanID).ToArray() : null)
                                    //)
                                    DataPreferenceIDs = s.Key.DataPreferenceByID == (int)DataPreferenceBy.ByCompany ? (s.Select(x => (int?)x.CompanyID).ToArray()[0] == null ? null : s.Select(x => (int?)x.CompanyID).ToArray())
                                                    : s.Key.DataPreferenceByID == (int)DataPreferenceBy.BySubComapny ? (s.Select(x => (int?)x.SubCompanyID).ToArray()[0] == null ? null : s.Select(x => (int?)x.SubCompanyID).ToArray())
                                                    : s.Key.DataPreferenceByID == (int)DataPreferenceBy.ByLOB ? (s.Select(x => (int?)x.LOBID).ToArray()[0] == null ? null : s.Select(x => (int?)x.LOBID).ToArray())
                                                    : (s.Select(x => x.HealthPlanID).ToArray()[0] == null ? null : s.Select(x => x.HealthPlanID).ToArray())
                                }).FirstOrDefault();
                //end migration from 2.1 to 3.1
                return results;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerformAddRangeOperation", ex.Message);
                return null;
            }
        }

    }
}