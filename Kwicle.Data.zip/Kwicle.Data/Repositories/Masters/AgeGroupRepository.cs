﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Masters
{
    public class AgeGroupRepository : BaseRepository<AgeGroup>, IAgeGroupRepository
    {
        private readonly KwicleContext _context;

        public AgeGroupRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<AgeGroupModel> GetAgeGroups()
        {
            IQueryable<AgeGroupModel> ageGroup = (from ag in _context.AgeGroups
                                                  select new AgeGroupModel()
                                                  {
                                                      AgeGroupID = ag.AgeGroupID,
                                                      TypeID = ag.TypeID,
                                                      AgeGroupType = ag.AgeGroupType.ShortName,
                                                      Code = ag.Code,
                                                      AgeFrom = ag.AgeFrom,
                                                      AgeTo = ag.AgeTo,
                                                      EffectiveDate = ag.EffectiveDate,
                                                      TermDate = (ag.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : ag.TermDate
                                                  });
            return ageGroup;
        }
    }
}
