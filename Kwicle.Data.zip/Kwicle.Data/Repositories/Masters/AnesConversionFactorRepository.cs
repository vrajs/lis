﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using Kwicle.Data.Contracts.Masters;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Masters
{
    public class AnesConversionFactorRepository : BaseRepository<AnesConversionFactor>, IAnesConversionFactorRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public AnesConversionFactorRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Methods
        public List<KeyValuePair<int, string>> GetAnesConversionFactorKeyVal()
        {
            List<KeyValuePair<int, string>> Items = new List<KeyValuePair<int, string>>();
            Items = _context.AnesConversionFactors.IgnoreQueryFilters().Where(x => x.RecordStatus == (byte)RecordStatus.Active).OrderBy(e => e.Name).Select(x => new KeyValuePair<int, string>(x.AnesConversionFactorID, x.Name)).ToList();

            return Items;
        }

        public IQueryable<AnesConversionFactorModel> GetAnesConversionFactors()
        {
            var res = (from acf in _context.AnesConversionFactors
                       select new AnesConversionFactorModel()
                       {
                           AnesConversionFactorID = acf.AnesConversionFactorID,
                           Name = acf.Name,
                           RoundToID = acf.RoundToID,
                           RoundToName = acf.RoundToID == 1 ? "Whole Number" : "One Decimal",
                           RoundingPoint = acf.RoundingPoint,
                           POSCode = acf.POSCode,
                           NoOfMinutePerUnit = acf.NoOfMinutePerUnit,
                           EffectiveDate = acf.EffectiveDate,
                           TermDate = (acf.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : acf.TermDate
                       });
            return res;
        }

        public IQueryable<AnesConversionFactor> GetAnesConversionFactorByPOSCode(string posCode)
        {
            var anesConversionFactors = _context.AnesConversionFactors.IgnoreQueryFilters().Where(x => x.RecordStatus == (byte)RecordStatus.Active && x.POSCode.ToLower() == posCode);
            return anesConversionFactors;
        }
        #endregion
    }
}
