﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    public class DRGCodeRepository : BaseRepository<DRGCode>, IDRGCodeRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Constructor

        public DRGCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion

        #region  Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DRGCodeID"></param>
        /// <returns></returns>
        public DRGCodeModel GetDRGCodeByID(int DRGCodeID)
        {
            var query = from n in _context.DRGCodes.Where(c => c.DRGCodeID == DRGCodeID)
                        select new DRGCodeModel()
                        {
                            DRGCodeID = n.DRGCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            MajorCategory = n.MajorCategory,
                            DRGType = n.DRGType,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID
                        };
            return query.FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<DRGCodeModel> GetDRGCodes()
        {
            var query = from n in _context.DRGCodes.Where(c => c.RecordStatus == (byte)RecordStatus.Active)
                        join com_code in _context.CommonCodes on n.ClinicalCodeTypeID equals com_code.CommonCodeID
                        select new DRGCodeModel()
                        {
                            DRGCodeID = n.DRGCodeID,
                            Code = n.Code,
                            HomeGrown = n.HomeGrown,
                            MajorCategory = n.MajorCategory,
                            DRGType = n.DRGType,
                            ShortDescription = n.ShortDescription,
                            LongDescription = n.LongDescription,
                            SequenceNumber = n.SequenceNumber,
                            ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = n.TermDate,
                            ClinicalCodeType = com_code.Code,
                            ClinicalCodeTypeName = com_code.ShortName,
                            IsFreezed = n.IsFreezed
                        };
            return query;
        }

        #endregion
    }
}