﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.Masters;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Masters
{
    /// <summary>
    /// Implements IPlanCapitationRepository, do not create instance directly, instead use dependency injection of IPlanCapitationRepository
    /// </summary>
    public class MembershipCapitationRepository : BaseRepository<MembershipCapitation>, IMembershipCapitationRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        
        #endregion

        #region Ctor
        public MembershipCapitationRepository(KwicleContext context) : base(context)
        {
            _context = context;
            
        }

        #endregion

    }
}
