﻿using Kwicle.Data.Contracts;
using System.Threading.Tasks;
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Kwicle.Data.Models;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Kwicle.Core.CustomModel;
using Kwicle.Core.Common;
using Kwicle.Common.Utility;
using System.Data.SqlClient;

namespace Kwicle.Data.Repositories
{
    /// <summary>
    /// This class designed to provide basic CRUD operations.
    /// Every repository in system should be inherited from this class.
    /// </summary>
    /// <typeparam name="T">Entity framework model class</typeparam>
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        public DbSet<T> DbSet
        {
            get
            {
                return _context.Set<T>();
            }
        }

        #region Variables
        // private ILogger<BaseRepository<T>> _logger;
        private ErrorMessageModel _ErrorMessageModel;
        private DbContext _context;
        #endregion

        #region Ctor
        public BaseRepository(DbContext context)
        {
            _context = context;
            _ErrorMessageModel = new ErrorMessageModel();
            //_logger = logger;
        }
        #endregion

        #region Interface Methods Implementation

        /// <summary>
        /// Performs INSERT operation.
        /// If any exception occurs, it logs into logger and set ErrorMessage property of Error property
        /// </summary>
        /// <param name="entity">Entity framework model class</param>
        public void Add(T entity)
        {
            try
            {
                _context.Add(entity);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("duplicate"))
                {
                    _ErrorMessageModel.AddErrorMessage("CanNotAddRecord", "Cannot Add duplicate record.");
                }
                else
                {
                    _ErrorMessageModel.AddErrorMessage("CanNotAddRecord", "Cannot Add Record to Database");
                }
                // _logger.LogError(ex.Message, ex);
            }

        }
        /// <summary>
        /// Performs Multiple INSERT operation.
        /// If any exception occurs, it logs into logger and set ErrorMessage property of Error property
        /// </summary>
        /// <param name="entity">Entity framework array model class</param>
        public void AddRange(T[] entity)
        {
            try
            {
                _context.AddRange(entity);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                _ErrorMessageModel.AddErrorMessage("CanNotPerformAddRange", "Cannot Perform Add Range to Database");
                // _logger.LogError(ex.Message, ex);
            }
        }

        /// <summary>
        /// SELECT single record.
        /// If any exception occurs, it logs into logger and set ErrorMessage property of Error property
        /// </summary>
        /// <param name="Id">Primary Key</param>
        /// <returns></returns>
        public virtual T GetById<C>(C Id)
        {
            try
            {

                var entity = _context.Find<T>(Id);
                //_logger.LogInformation("GetById Success", entity);
                return entity;

            }
            catch (Exception ex)
            {
                _ErrorMessageModel.AddErrorMessage("CanNotPerformGetById", ex.ToErrorMessage());
                //_logger.LogError(ex.Message, ex);
                return null;
            }

        }


        /// <summary>
        /// Performs update operation.
        /// If any exception occurs, it logs into logger and set ErrorMessage property of Error property.
        /// </summary>
        /// <param name="entity"></param>
        public virtual void Update(T entity)
        {
            try
            {
                DbSet.Attach(entity);
                _context.Entry(entity).State = EntityState.Modified;
                _context.SaveChanges();

            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("duplicate"))
                {
                    _ErrorMessageModel.AddErrorMessage("CanNotPerformUpdateOperation", "Cannot Add duplicate record.");
                }
                else
                {
                    _ErrorMessageModel.AddErrorMessage("CanNotPerformUpdateOperation", "Cannot Update Record to Database");
                }
                //_logger.LogError(ex.Message, ex);
            }

        }

        public async Task UpdateAsync(T entity)
        {
            try
            {
                DbSet.Attach(entity);
                _context.Entry(entity).State = EntityState.Modified;
                await _context.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                _ErrorMessageModel.AddErrorMessage("CanNotPerformUpdateOperation", ex.ToErrorMessage());
                //_logger.LogError(ex.Message, ex);
            }

        }
        /// <summary>
        /// Performs delete operation.
        /// If any exception occurs, it logs into logger and set ErrorMessage property of Error property. 
        /// </summary>
        /// <param name="entity"></param>
        public virtual void Delete(T entity)
        {
            try
            {
                using (_context)
                {
                    _context.Remove(entity);
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException is SqlException)
                {
                    SqlException se = (SqlException)ex.InnerException;
                    if (se.Errors.Count > 0)
                    {
                        switch (se.Errors[0].Number)
                        {
                            case 547: // Foreign Key violation
                                _ErrorMessageModel.AddErrorMessage("CanNotPerformDelete", "Can't delete this record due to dependencies !!!");
                                break;
                            default:
                                _ErrorMessageModel.AddErrorMessage("CanNotPerformDelete", "Cannot Delete Record");
                                break;
                        }
                    }
                }
                else
                    _ErrorMessageModel.AddErrorMessage("CanNotPerformDelete", "Cannot Delete Record");
            }
        }
        #endregion

        public async Task<bool> SaveAllAsync()
        {
            try
            {
                return (await _context.SaveChangesAsync()) > 0;
            }
            catch (Exception ex)
            {
                _ErrorMessageModel.AddErrorMessage("CanNotPerformUpdateAsync", ex.ToErrorMessage());
                return false;
            }
        }

        public async Task AddAsync(T entity)
        {
            try
            {
                _context.Add(entity);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _ErrorMessageModel.AddErrorMessage("CanNotPerformAddAsync", ex.ToErrorMessage());
                // _logger.LogError(ex.Message, ex);
            }
        }

        public IQueryable<T> GetByPredicateIgnoreQueryFilters(Expression<Func<T, bool>> filter, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> res = _context.Set<T>().IgnoreQueryFilters<T>();

            if (includes != null && includes.Any())
                res = includes.Aggregate(res, (current, include) => current.Include(include));

            if (filter != null)
                res = res.Where(filter);

            return res;
        }

        public IQueryable<T> GetByPredicate(Expression<Func<T, bool>> filter, params Expression<Func<T, object>>[] includes)
        {
            //IQueryable<T> res = _context.Set<T>();

            //if (includes == null || !includes.Any()) return res.Where(filter);
            //res = includes.Aggregate(res, (current, include) => current.Include(include));           

            //return res.Where(filter);

            IQueryable<T> res = _context.Set<T>();

            if (includes != null && includes.Any())
                res = includes.Aggregate(res, (current, include) => current.Include(include));

            if (filter != null)
                res = res.Where(filter);

            return res;
        }
        [Obsolete]
        public void DeleteById<C>(C Id)
        {
            T t = this.GetById(Id);
            t.GetType().GetProperty("RecordStatus").SetValue(t, (byte)RecordStatus.Deleted);
            t.GetType().GetProperty("RecordStatusChangeComment").SetValue(t, RecordStatus.Deleted.ToString());
            _context.SaveChanges();
        }
        public void DeleteById<C>(C Id, string UserName, DateTime TodaysDate)
        {
            T t = this.GetById(Id);
            t.GetType().GetProperty("UpdatedBy").SetValue(t, UserName);
            t.GetType().GetProperty("UpdatedDate").SetValue(t, TodaysDate);
            t.GetType().GetProperty("RecordStatus").SetValue(t, (byte)RecordStatus.Deleted);
            t.GetType().GetProperty("RecordStatusChangeComment").SetValue(t, RecordStatus.Deleted.ToString());
            _context.SaveChanges();
        }

        public void DeleteByReason(DeleteModel deleteModel)
        {
            T t = this.GetById(deleteModel.Id);
            t.GetType().GetProperty("RecordStatus").SetValue(t, (byte)RecordStatus.Deleted);
            t.GetType().GetProperty("RecordStatusChangeComment").SetValue(t, deleteModel.DeleteReason);
            _context.SaveChanges();
        }



        ///// <summary>
        ///// SELECT all records.
        ///// If any exception occurs, it logs into logger and set ErrorMessage property of Error property.
        ///// </summary>
        ///// <returns></returns>
        //public IQueryable<T> GetAll()
        //{
        //    try
        //    {
        //        ObjectContext objectContext = ((IObjectContextAdapter)_context).ObjectContext;
        //        var entity = this.DbSet.GetType().ToString();
        //        var query = this.DbSet.FromSql($"SELECT * FROM {entity} WHERE RecordStatus == 0");
        //        return query;
        //    }
        //    catch (Exception ex)
        //    {
        //        this.DbState.AddErrorMessage("CanNotGetAllRecords", ex.Message);
        //        return null;
        //    }

        //}
        #region Interface Properties Implementation
        public ErrorMessageModel DbState { get { return _ErrorMessageModel; } }
        #endregion

    }
}
