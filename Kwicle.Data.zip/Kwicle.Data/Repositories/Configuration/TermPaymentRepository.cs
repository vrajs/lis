﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Kwicle.Data.Repositories.Configuration
{
    public class TermPaymentRepository : BaseRepository<TermPayment>, ITermPaymentRepository
    {

        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public TermPaymentRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public IQueryable<TermPaymentModel> GetTermPayment(int? TermHeaderId, int? PaymentTypeId)
        {
            
            var res = (from n in _context.TermPayments.IgnoreQueryFilters().Where(x => (x.RecordStatus == (int)RecordStatus.Active || x.RecordStatus == (int)RecordStatus.InActive) && (!TermHeaderId.HasValue || x.TermHeaderID == TermHeaderId) && (!PaymentTypeId.HasValue || x.PaymentTypeID == PaymentTypeId))
                       from pt in _context.CommonCodes.IgnoreQueryFilters().Where(x => x.CommonCodeID == n.PaymentTypeID && n.RecordStatus == (int)RecordStatus.Active).DefaultIfEmpty()
                       from dg in _context.DRGGroups.IgnoreQueryFilters().Where(x => x.DRGGroupHeaderID == n.DRGGroupHeaderID && n.RecordStatus == (int)RecordStatus.Active).DefaultIfEmpty()
                       from dp in _context.DRGPaymentPayPercents.IgnoreQueryFilters().Where(x => x.DRGPaymentPayPercentID == n.DRGPaymentPayPercentID && n.RecordStatus == (int)RecordStatus.Active).DefaultIfEmpty()
                       from fs in _context.FeeScheduleHeaders.IgnoreQueryFilters().Where(x => x.FeeScheduleHeaderID == n.FeeScheduleHeaderID && n.RecordStatus == (int)RecordStatus.Active).DefaultIfEmpty()
                       select new TermPaymentModel()
                       {
                           TermPaymentID = n.TermPaymentID,
                           TermHeaderID = n.TermHeaderID,
                           PaymentTypeID = n.PaymentTypeID,
                           PaymentType = pt.ShortName,
                           IsBillChargesIgnored = n.IsBillChargesIgnored,
                           IsPerDateOfService = n.IsPerDateOfService,
                           PayPercent = n.PayPercent,
                           Rate = n.Rate,
                           IsProrateDays = n.IsProrateDays,
                           IsCalculateHighOutlier = n.IsCalculateHighOutlier,
                           IsUseActiveDRG = n.IsUseActiveDRG,
                           IsCalculateLowOutlier = n.IsCalculateLowOutlier,
                           IsCalculateTransfer = n.IsCalculateTransfer,
                           MaxReimbursement = n.MaxReimbursement,
                           DRGGroupID = n.DRGGroupHeaderID,
                           DRGGroupName = dg.DRGGroupName,
                           IsUseActivePricer = n.IsUseActivePricer,
                           DRGPaymentPayPercentID = n.DRGPaymentPayPercentID,
                           DRGPayPercentName = dp.DRGPayPercentName,
                           DefaultFFSPercent = n.DefaultFFSPercent,
                           FeeScheduleHeaderID = n.FeeScheduleHeaderID,
                           Code = fs.Code,
                           BilledCharge = n.BilledCharge,
                           StartDay = n.StartDay,
                           EndDay = n.EndDay,
                           IsUseGPI = n.IsUseGPI,
                           IsRegionUnit = n.IsRegionUnit,
                           EffectiveDate = n.EffectiveDate,
                           TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                       });
            return res;
        }


        public IQueryable<TermPaymentModel> GetTermPaymentHistory(int TermHeaderId)
        {
            var res = (from n in _context.TermPayments.IgnoreQueryFilters().Where(x => x.RecordStatus != (int)RecordStatus.Deleted && x.TermHeaderID == TermHeaderId).OrderBy(i => i.TermDate).ThenBy(i => i.EffectiveDate)
                       from pt in _context.CommonCodes.IgnoreQueryFilters().Where(x => x.CommonCodeID == n.PaymentTypeID).DefaultIfEmpty()
                       from dg in _context.DRGGroups.IgnoreQueryFilters().Where(x => x.DRGGroupHeaderID == n.DRGGroupHeaderID).DefaultIfEmpty()
                       from dp in _context.DRGPaymentPayPercents.IgnoreQueryFilters().Where(x => x.DRGPaymentPayPercentID == n.DRGPaymentPayPercentID).DefaultIfEmpty()
                       from fs in _context.FeeScheduleHeaders.IgnoreQueryFilters().Where(x => x.FeeScheduleHeaderID == n.FeeScheduleHeaderID).DefaultIfEmpty()
                       select new TermPaymentModel()
                       {
                           TermPaymentID = n.TermPaymentID,
                           TermHeaderID = n.TermHeaderID,
                           PaymentTypeID = n.PaymentTypeID,
                           PaymentType = pt.ShortName,
                           IsBillChargesIgnored = n.IsBillChargesIgnored,
                           IsPerDateOfService = n.IsPerDateOfService,
                           PayPercent = n.PayPercent,
                           Rate = n.Rate,
                           IsProrateDays = n.IsProrateDays,
                           IsCalculateHighOutlier = n.IsCalculateHighOutlier,
                           IsUseActiveDRG = n.IsUseActiveDRG,
                           IsCalculateLowOutlier = n.IsCalculateLowOutlier,
                           IsCalculateTransfer = n.IsCalculateTransfer,
                           MaxReimbursement = n.MaxReimbursement,
                           DRGGroupID = n.DRGGroupHeaderID,
                           DRGGroupName = dg.DRGGroupName,
                           IsUseActivePricer = n.IsUseActivePricer,
                           DRGPaymentPayPercentID = n.DRGPaymentPayPercentID,
                           DRGPayPercentName = dp.DRGPayPercentName,
                           DefaultFFSPercent = n.DefaultFFSPercent,
                           FeeScheduleHeaderID = n.FeeScheduleHeaderID,
                           Code = fs.Code,
                           BilledCharge = n.BilledCharge,
                           StartDay = n.StartDay,
                           EndDay = n.EndDay,
                           IsUseGPI = n.IsUseGPI,
                           IsRegionUnit = n.IsRegionUnit,
                           EffectiveDate = n.EffectiveDate,
                           TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                       });
            return res;
        }
        #endregion
    }
}
