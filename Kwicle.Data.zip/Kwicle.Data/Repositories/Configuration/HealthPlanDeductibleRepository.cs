﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class HealthPlanDeductibleRepository : BaseRepository<HealthPlanDeductible>, IHealthPlanDeductibleRepository
    {
        #region Variables
        private KwicleContext _context;
        #endregion

        #region Ctor
        public HealthPlanDeductibleRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Method
        public IQueryable<HealthPlanDeductibleModel> GetDeductibleOopByPlanOrBenefitID(string fromPage, int planOrBenefitID)
        {
            var query = (from dol in _context.HealthPlanDeductibles.Where(b => (fromPage=="Benefit" ? b.BenefitHeaderID == planOrBenefitID : b.HealthPlanID == planOrBenefitID))
                         join cc in _context.CommonCodes on dol.DeductibleTypeID equals cc.CommonCodeID
                         select new HealthPlanDeductibleModel()
                         {
                             HealthPlanDeductibleID = dol.HealthPlanDeductibleID,
                             HealthPlanID = dol.HealthPlanID,
                             BenefitHeaderID = dol.BenefitHeaderID,
                             DeductibleTypeID = dol.DeductibleTypeID,
                             DeductibleType = cc.ShortName,
                             IsApplyToNetwork = dol.IsApplyToNetwork,
                             ApplyNetwork = dol.IsApplyToNetwork == 1 ? "In Network" : dol.IsApplyToNetwork == 2 ? "Out Network" : "In/Out Network",
                             IncomePercentage = dol.IncomePercentage,
                             EffectiveDate = dol.EffectiveDate,
                             TermDate = (dol.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : dol.TermDate,                            
                         });
            return query;
        }
        #endregion
    }
}
