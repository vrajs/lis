﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Configuration
{
    public class TermLimitRepository : BaseRepository<TermLimit>, ITermLimitRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public TermLimitRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public IQueryable<TermLimitModel> GetTermLimitByTermHeaderID(int TermHeaderID)
        {
            var query = (from bv in _context.TermLimits.Include(c => c.VisitCode).Where(x => x.TermHeaderID == TermHeaderID)
                         select new TermLimitModel()
                         {
                             TermLimitID = bv.TermLimitID,
                             TermHeaderID = bv.TermHeaderID,
                             VisitCodeID = bv.VisitCodeID,
                             VisitCode = bv.VisitCode,
                             EffectiveDate = bv.EffectiveDate,
                             TermDate = (bv.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : bv.TermDate
                         });
            return query;
        }
        #endregion

    }
}
