﻿using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class ContractClaimTypeRepository : BaseRepository<ContractClaimType>, IContractClaimTypeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ContractClaimTypeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Methods
        public List<ContractClaimType> GetByContractID(int contractID)
        {
            var result = (from cct in _context.ContractClaimTypes
                          where cct.ContractID == contractID
                          select new ContractClaimType()
                          {
                              ContractClaimTypeID = cct.ContractClaimTypeID,
                              ContractID = cct.ContractID,
                              ClaimTypeID = cct.ClaimTypeID,
                              CreatedBy = cct.CreatedBy,
                              CreatedDate = cct.CreatedDate
                          }).ToList();
            return result;
        }
        #endregion
    }
}
