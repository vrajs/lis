﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitProviderRepository : BaseRepository<BenefitProvider> , IBenefitProviderRepository
    {
        private readonly KwicleContext _context;
        public BenefitProviderRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<BenefitProviderModel> GetBenefitProviderByBenefitHeaderId(int benefitHeaderID)
        {
            var res = (from bp in _context.BenefitProviders where  bp.BenefitHeaderID == benefitHeaderID
                       join cc in _context.CommonCodes on bp.IdentifierTypeID equals cc.CommonCodeID 
                       select new BenefitProviderModel()
                       {
                           BenefitProviderID = bp.BenefitProviderID,
                           BenefitHeaderID = bp.BenefitHeaderID,
                           IdentifierTypeID = bp.IdentifierTypeID,
                           IdentifierTypeName = cc.ShortName,
                           IdentifierCode = bp.IdentifierCode,
                           IsExclude = bp.IsExclude,
                           EffectiveDate = bp.EffectiveDate,
                           TermDate = (bp.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : bp.TermDate,
                       });
            return res;

        }
    }
}
