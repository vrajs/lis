﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitVisitRepository : BaseRepository<BenefitVisit>, IBenefitVisitRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public BenefitVisitRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region  Methods
        public IQueryable<BenefitVisitModel> GetByBenefitHeaderID(int benefitHeaderID)
        {
            var query = (from bv in _context.BenefitVisits.Where(x => x.BenefitHeaderID == benefitHeaderID)
                         select new BenefitVisitModel()
                         {
                             BenefitVisitID = bv.BenefitVisitID,
                             BenefitHeaderID = bv.BenefitHeaderID,
                             VisitCodeID = bv.VisitCodeID,
                             EffectiveDate = bv.EffectiveDate,
                             TermDate = (bv.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : bv.TermDate,
                             ShareBenefitHeaderID = bv.BenefitVisitLimitShares.Where(t => t.BenefitVisitID == bv.BenefitVisitID).Select(t => t.BenefitHeaderID.ToString()).ToArray(),
                         });
            return query;
        }

        public new void Update(BenefitVisit Model)
        {
            using (this._context)
            {
                try
                {
                    var deletedData = _context.BenefitVisitLimitShares.Where(x => x.BenefitVisitID == Model.BenefitVisitID);
                    _context.BenefitVisitLimitShares.RemoveRange(deletedData);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
                }
            }
        }
        #endregion
    }
}
