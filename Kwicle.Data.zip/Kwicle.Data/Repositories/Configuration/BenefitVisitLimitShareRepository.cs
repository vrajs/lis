﻿using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitVisitLimitShareRepository : BaseRepository<BenefitVisitLimitShare>, IBenefitVisitLimitShareRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Constructor
        public BenefitVisitLimitShareRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion
    }
}
