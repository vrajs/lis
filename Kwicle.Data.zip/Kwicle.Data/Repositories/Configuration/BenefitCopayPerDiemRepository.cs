﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitCopayPerDiemRepository : BaseRepository<BenefitCopayPerDiem>, IBenefitCopayPerDiemRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public BenefitCopayPerDiemRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<BenefitCopayPerDiem> GetAllBenefitCopayPerDiem()
        {
            try
            {
                var res = _context.BenefitCopayPerDiems.ToList();
                return res;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetBenefitCopayPerDiem", ex.Message);
                return null;
            }

        }

        public IQueryable<BenefitCopayPerDiemViewModel> GetBenefitCopayPerDiem(int BenefitHeaderID)
        {
            try
            {
                var query = from n in _context.BenefitCopayPerDiems.Where(x => x.BenefitHeaderID == BenefitHeaderID)
                            select new BenefitCopayPerDiemViewModel()
                            {
                                BenefitCopayPerDiemID = n.BenefitCopayPerDiemID,
                                BenefitHeaderID = n.BenefitHeaderID,
                                StartDay = n.StartDay,
                                EndDay = n.EndDay,
                                PerDiem = n.PerDiem,
                                EffectiveDate = n.EffectiveDate,
                                TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetBenefitCopayPerDiem", ex.Message);
                return null;
            }

        }

        #endregion


    }
}
