﻿using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Views;
using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Configuration
{
    public class ContractRepository : BaseRepository<Contract>, IContractRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Ctor
        public ContractRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }


        #endregion

        #region Methods    
        public IQueryable<vwContract> GetContracts()
        {
            IQueryable<vwContract> _vwContract = from n in _viewContext.GetContracts.Where(i => i.RecordStatus != (byte)RecordStatus.Deleted)
                                                 select n;
            return _vwContract;
        }

        public void CopyContract(int ContractHeaderID, string TermHeaderIDs, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate, DateTime? TermDate)
        {
            try
            {
                TermDate = TermDate ?? DateTime.MaxValue;

                SqlParameter[] parameters = {
                    new SqlParameter("@ContractHeaderID", ContractHeaderID),
                    new SqlParameter("@TermHeaderIDs", TermHeaderIDs),
                    new SqlParameter("@EffectiveDate", EffectiveDate),
                    new SqlParameter("@CreatedBy", CreatedBy),
                    new SqlParameter("@CreatedDate", CreatedDate),
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output},
                    new SqlParameter("@TermDate",TermDate)
                };
                
                _context.Database.ExecuteSqlRaw("[hps].[usp_CopyContract] @ContractHeaderID, @TermHeaderIDs, @EffectiveDate, @CreatedBy, @CreatedDate, @ErrorMessage out,@TermDate", parameters);

                var errorMessage = Convert.ToString(parameters[5].Value);

                if (!string.IsNullOrEmpty(errorMessage))
                    base.DbState.AddErrorMessage("CanNotCopyContract : CopyContract", errorMessage);

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotCopyContract", ex.Message);
            }
        }

        public void Add(Contract Model, string TermHeaderIDs)
        {
            //_context.Database.AutoTransactionsEnabled = false;
            //using (var transaction = _context.Database.BeginTransaction())
            //{
            try
            {
                _context.Contracts.Add(Model);
                _context.SaveChanges();

                if (!string.IsNullOrEmpty(TermHeaderIDs))
                    CopyContract(Model.ContractID, TermHeaderIDs, Model.EffectiveDate, Model.CreatedBy, Model.CreatedDate, Model.TermDate);

                //if (base.DbState.IsValid)
                //    transaction.Commit();
                //else
                //    transaction.Rollback();
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerformCreateOperation", ex.Message);
                //transaction.Rollback();
            }
            finally
            {
                //transaction.Dispose();
            }
            //}
        }

        public new void Update(Contract Model)
        {
            using (this._context)
            {
                try
                {
                    var deletedData = _context.ContractClaimTypes.Where(x => x.ContractID == Model.ContractID);
                    _context.ContractClaimTypes.RemoveRange(deletedData);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
                }
            }
        }

        public void DeleteOrTermContract(int ContractID, string UpdatedBy, DateTime UpdatedDate, byte RecordStatus, string RecordStatusChangeComment, DateTime? TermDate)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@ContractID", ContractID),
                    new SqlParameter("@UpdatedDate", UpdatedDate),
                    new SqlParameter("@UpdatedBy", UpdatedBy),
                    new SqlParameter("@RecordStatus", RecordStatus),
                    new SqlParameter("@RecordStatusChangeComment", RecordStatusChangeComment),
                    new SqlParameter("@TermDate",TermDate) ,
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output}
                };

                if (TermDate == null || TermDate == DateTime.MinValue)
                {
                    parameters[5].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_DeleteOrTermContract] @ContractID,@UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@TermDate,@ErrorMessage out", parameters);

                var errorMessage = Convert.ToString(parameters[6].Value);

                if (!string.IsNullOrEmpty(errorMessage))
                    base.DbState.AddErrorMessage("CanNotDeleteOrTermContract : DeleteOrTermContract", errorMessage);

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotDeleteOrTermContract", ex.Message);
            }
        }
        #endregion
    }
}
