﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class ClinicalCodeSubGroupRepository : BaseRepository<ClinicalCodeSubGroup>, IClinicalCodeSubGroupRepository
    {
        #region variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClinicalCodeSubGroupRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion
        #region Methods
        public List<KeyValuePair<short, string>> GetClinicalCodeSubGroup(short ClinicalCodeGroupID)
        {
            var result = _context.ClinicalCodeSubGroups.Where(x => x.ClinicalCodeGroupID == ClinicalCodeGroupID).OrderBy(e => e.SubGroupName).Select(x => new KeyValuePair<short, string>(x.ClinicalCodeSubGroupID, x.SubGroupName)).ToList();
            return result;
        }
        #endregion
    }
}
