﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
using System.Data;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitHeaderRepository : BaseRepository<BenefitHeader>, IBenefitHeaderRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        //private readonly KwicleViewContext _viewContext;
        #endregion

        #region Ctor
        public BenefitHeaderRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            //_viewContext = viewContext;
        }
        #endregion

        #region Methods
        public void AttachBenefitRange(int[] BenefitHeaderID, int HealthPlanID, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate)
        {
            try
            {
                var BenefitHeaderIDs = string.Join(",", BenefitHeaderID);
                object[] parameters = {
                new SqlParameter("@HealthPlanID", HealthPlanID),
                new SqlParameter("@BenefitHeaderIDs", BenefitHeaderIDs),
                new SqlParameter("@EffectiveDate", EffectiveDate),
                new SqlParameter("@CreatedBy", CreatedBy),
                new SqlParameter("@CreatedDate",CreatedDate)};

                _context.Database.ExecuteSqlRaw("[hps].[usp_AddBenefitsToPlan] @HealthPlanID, @BenefitHeaderIDs, @EffectiveDate, @CreatedBy, @CreatedDate", parameters);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotAttachBenefitRange", ex.Message);
            }
        }

        public int CopyBenefit(GetBenefitModel model, int copayCoinsuranceID, string createdBy, DateTime createdDate)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@BenefitHeaderID", model.BenefitHeaderID),
                    new SqlParameter("@EffectiveDate", model.EffectiveDate),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@CreatedDate",createdDate) ,
                    new SqlParameter("@CreatedBenefitHeaderID",SqlDbType.Int) {Direction = ParameterDirection.Output},
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output},
                    new SqlParameter("@BenefitCode", model.BenefitCode),
                    new SqlParameter("@BenefitName", model.BenefitName),
                    new SqlParameter("@TermDate", model.TermDate),
                    new SqlParameter("@IsDeductible",model.IsDeductible) ,
                    new SqlParameter("@IsMaxOOP",model.IsMaxOOP),
                    new SqlParameter("@CopayCoinsuranceID", copayCoinsuranceID)
                };
                if (model.TermDate == null || model.TermDate == DateTime.MinValue)
                {
                    parameters[8].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_CopyBenefit] @BenefitHeaderID, @EffectiveDate, @CreatedBy, @CreatedDate, @CreatedBenefitHeaderID out, @ErrorMessage out,@BenefitCode,@BenefitName,@TermDate,@IsDeductible,@IsMaxOOP,@CopayCoinsuranceID", parameters);
                _context.SaveChanges();

                var errorMessage = Convert.ToString(((SqlParameter)parameters[5]).Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotCopyBenefit : CopyBenefit", errorMessage);
                }

                var benefitHeaderId = Convert.ToInt32(((SqlParameter)parameters[4]).Value);
                return benefitHeaderId;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotCopyBenefit", ex.Message);
                return -1;
            }
        }

        public IQueryable<GetBenefitModel> GetBenefits()
        {
            //var query = (from bh in _context.BenefitHeaders.Where(b => b.RecordStatus == (int)Core.Common.RecordStatus.Active)
            //             select new BenefitViewModel()
            //             {
            //                 BenefitHeaderID = bh.BenefitHeaderID,
            //                 SubCompanyID = bh.SubCompanyID,
            //                 BenefitCode = bh.BenefitCode,
            //                 BenefitDescription = bh.BenefitDescription,
            //                 BenefitLongDescription = bh.BenefitLongDescription,
            //                 EffectiveDate = bh.EffectiveDate,
            //                 TermDate = (bh.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : bh.TermDate,
            //                 RemitReason = bh.RemitReason,
            //                 EOBReason = bh.EOBReason,
            //                 ClaimTypeID = bh.ClaimTypeID,
            //                 ProviderStatusID = bh.ProviderStatusID,
            //                 ProviderTypeID = bh.ProviderTypeID,
            //                 AgeFrom = bh.AgeFrom,
            //                 AgeTo = bh.AgeTo,
            //                 Gender = bh.Gender,
            //                 NetworkID = bh.NetworkID,
            //                 IsAuthRequired = bh.IsAuthRequired,
            //                 IsManualReview = bh.IsManualReview,
            //                 IsEmergency =bh.IsEmergency,
            //                 IsMemberPPCP = bh.IsMemberPPCP,
            //                 IsPCP = bh.IsPCP,
            //                 IsCoinsurance = bh.IsCoinsurance,
            //                 IsCopay = bh.IsCopay,
            //                 IsVisitLimit = bh.IsVisitLimit,
            //                 IsDeductible = bh.IsDeductible,
            //                 IsMaxOOP = bh.IsMaxOOP,
            //                 CompanyID = bh.CompanyID
            //             });

            //.Where(x => x.RecordStatus == (int)Core.Common.RecordStatus.Active)
            var query = from bh in _context.GetBenefits select bh;
            return query;
        }
        public IQueryable<GetBenefitModel> GetBenefits(int healthPlanId, bool isInclude)
        {
            IQueryable<GetBenefitModel> query = null;
            query = from n in _context.GetBenefits
                    where n.RecordStatus != (byte)RecordStatus.Deleted && n.RecordStatus != (byte)RecordStatus.VoidOrInvalid
                    select new GetBenefitModel()
                    {
                        AgeFrom = n.AgeFrom,
                        AgeTo = n.AgeTo,
                        BCPDCount = n.BCPDCount,
                        BenefitCategoryID = n.BenefitCategoryID,
                        BenefitCategoryName = n.BenefitCategoryName,
                        BenefitCode = n.BenefitCode,
                        BenefitHeaderID = n.BenefitHeaderID,
                        BenefitLongDescription = n.BenefitLongDescription,
                        BenefitName = n.BenefitName,
                        ClaimType = n.ClaimType,
                        ClaimTypeID = n.ClaimTypeID,
                        CoinsurancePercentage = n.CoinsurancePercentage,
                        EffectiveDate = n.EffectiveDate,
                        TermDate = n.TermDate,
                        EOBReason = n.EOBReason,
                        FixedCopay = n.FixedCopay,
                        Gender = n.Gender,
                        IsAuthRequired = n.IsAuthRequired,
                        IsCoinsurance = n.IsCoinsurance,
                        IsCopay = n.IsCopay,
                        IsDeductible = n.IsDeductible,
                        IsEmergency = n.IsEmergency,
                        IsExistBCPD = n.IsExistBCPD,
                        IsManualReview = n.IsManualReview,
                        IsMaxOOP = n.IsMaxOOP,
                        IsMemberPCP = n.IsMemberPCP,
                        IsPCP = n.IsPCP,
                        IsVisitLimit = n.IsVisitLimit,
                        MaxCopay = n.MaxCopay,
                        Network = n.Network,
                        NetworkID = n.NetworkID,
                        ProviderStatus = n.ProviderStatus,
                        ProviderStatusID = n.ProviderStatusID,
                        ProviderType = n.ProviderType,
                        ProviderTypeID = n.ProviderTypeID,
                        RecordStatus = n.RecordStatus,
                        RemitReason = n.RemitReason,
                        ClaimHitPriority = 0
                    };

            if (isInclude)
            {
                query = from bh in query
                        join p in _context.BenefitHeaderHealthPlans on bh.BenefitHeaderID equals p.BenefitHeaderID
                        where p.RecordStatus != (byte)RecordStatus.Deleted && p.RecordStatus != (byte)RecordStatus.VoidOrInvalid && p.HealthPlanID == healthPlanId
                        select new GetBenefitModel
                        {
                            AgeFrom = bh.AgeFrom,
                            AgeTo = bh.AgeTo,
                            BCPDCount = bh.BCPDCount,
                            BenefitCategoryID = bh.BenefitCategoryID,
                            BenefitCategoryName = bh.BenefitCategoryName,
                            BenefitCode = bh.BenefitCode,
                            BenefitHeaderID = bh.BenefitHeaderID,
                            BenefitLongDescription = bh.BenefitLongDescription,
                            BenefitName = bh.BenefitName,
                            ClaimType = bh.ClaimType,
                            ClaimTypeID = bh.ClaimTypeID,
                            CoinsurancePercentage = bh.CoinsurancePercentage,
                            EffectiveDate = p.EffectiveDate,
                            TermDate = p.TermDate,
                            EOBReason = bh.EOBReason,
                            FixedCopay = bh.FixedCopay,
                            Gender = bh.Gender,
                            IsAuthRequired = bh.IsAuthRequired,
                            IsCoinsurance = bh.IsCoinsurance,
                            IsCopay = bh.IsCopay,
                            IsDeductible = bh.IsDeductible,
                            IsEmergency = bh.IsEmergency,
                            IsExistBCPD = bh.IsExistBCPD,
                            IsManualReview = bh.IsManualReview,
                            IsMaxOOP = bh.IsMaxOOP,
                            IsMemberPCP = bh.IsMemberPCP,
                            IsPCP = bh.IsPCP,
                            IsVisitLimit = bh.IsVisitLimit,
                            MaxCopay = bh.MaxCopay,
                            Network = bh.Network,
                            NetworkID = bh.NetworkID,
                            ProviderStatus = bh.ProviderStatus,
                            ProviderStatusID = bh.ProviderStatusID,
                            ProviderType = bh.ProviderType,
                            ProviderTypeID = bh.ProviderTypeID,
                            RecordStatus = bh.RecordStatus,
                            RemitReason = bh.RemitReason,
                            ClaimHitPriority = p.ClaimHitPriority
                        };
            }
            return query;
        }
        public new void Update(BenefitHeader Model)
        {
            using (this._context)
            {
                try
                {
                    var deletedData = _context.BenefitProviderSpecialties.Where(x => x.BenefitHeaderID == Model.BenefitHeaderID);
                    _context.BenefitProviderSpecialties.RemoveRange(deletedData);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
                }
            }
        }

        /// <summary>
        /// Get benefit name list exclued current benefit
        /// use in visit tab for configuration (share limit purpose)
        /// </summary>
        /// <param name="BenefitHeaderID"></param>
        /// <returns></returns>
        public List<KeyValuePair<int, string>> GetBenefitNames(int BenefitHeaderID)
        {
            var result = _context.BenefitHeaders.Where(x => x.BenefitHeaderID != BenefitHeaderID).OrderBy(e => e.BenefitName).Select(x => new KeyValuePair<int, string>(x.BenefitHeaderID, x.BenefitName)).ToList();
            return result;
        }
        public void RemoveBenefit(int benefitHeaderID, DateTime todaysDate, string userName, int recordStatus, string recordStatusChangeComment, DateTime? TermDate, string termReason)
        {
            try
            {

                SqlParameter[] parameters = {
                    //new SqlParameter("HealthPlanID", 0), //issue with optional param 
                    new SqlParameter("BenefitHeaderID", benefitHeaderID),
                    new SqlParameter("UpdatedDate",todaysDate) ,
                    new SqlParameter("UpdatedBy", userName),
                    new SqlParameter("RecordStatus", recordStatus),
                    new SqlParameter("RecordStatusChangeComment", recordStatusChangeComment),
                    new SqlParameter("ErrorMessage", SqlDbType.VarChar ,4000) {Direction = ParameterDirection.Output},
                    new SqlParameter("@TermDate", TermDate),
                    new SqlParameter("@TermReason", string.IsNullOrEmpty(termReason) ? DBNull.Value : termReason),
            };

                if (TermDate == null || TermDate == DateTime.MinValue)
                {
                    parameters[6].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_DeleteOrTermBenefit]  @BenefitHeaderID, @UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@ErrorMessage out,@TermDate, @TermReason", parameters);
                var errorMessage = Convert.ToString(((SqlParameter)parameters[5]).Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotPerform : RemoveBenefit", errorMessage);
                }
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : RemoveBenefit", ex.Message);

            }
        }
        public HasBenefitConfigurationDataModel CheckBenefitConfigurationHasData(int benefitHeaderID)
        {
            HasBenefitConfigurationDataModel res = new HasBenefitConfigurationDataModel();
            res.HasCodeData = _context.BenefitCodes.Any(x => x.BenefitHeaderID == benefitHeaderID && (x.ClinicalCodeTypeID == (int)ClinicalCodeType.CPT2 || x.ClinicalCodeTypeID == (int)ClinicalCodeType.CPT4 || x.ClinicalCodeTypeID == (int)ClinicalCodeType.HCPCS || x.ClinicalCodeTypeID == (int)ClinicalCodeType.UBRevenue || x.ClinicalCodeTypeID == (int)ClinicalCodeType.MSDRGCodes || x.ClinicalCodeTypeID == (int)ClinicalCodeType.HUGS || x.ClinicalCodeTypeID == (int)ClinicalCodeType.RUGS));
            res.HasServiceGroupData = _context.BenefitServiceGroups.Any(x => x.BenefitHeaderID == benefitHeaderID);
            res.HasModifierData = _context.BenefitCodes.Any(x => x.BenefitHeaderID == benefitHeaderID && x.ClinicalCodeTypeID == (int)ClinicalCodeType.Modifier);
            res.HasDiagnosisData = _context.BenefitCodes.Any(x => x.BenefitHeaderID == benefitHeaderID && (x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD9CMDX || x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD9CMPCS || x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD10CMDX || x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD10CMPCS));
            res.HasPlaceOfServiceData = _context.BenefitCodes.Any(x => x.BenefitHeaderID == benefitHeaderID && x.ClinicalCodeTypeID == (int)ClinicalCodeType.POS);
            res.HasBillTypeData = _context.BenefitCodes.Any(x => x.BenefitHeaderID == benefitHeaderID && x.ClinicalCodeTypeID == (int)ClinicalCodeType.UBTOB);
            res.HasProviderData = _context.BenefitProviders.Any(x => x.BenefitHeaderID == benefitHeaderID);
            res.HasCopayCoInsuranceData = _context.BenefitCopayCoinsurances.Any(x => x.BenefitHeaderID == benefitHeaderID);
            res.HasCopayPerDiemData = _context.BenefitCopayPerDiems.Any(x => x.BenefitHeaderID == benefitHeaderID);
            res.HasVisitsData = _context.BenefitVisits.Any(x => x.BenefitHeaderID == benefitHeaderID);
            res.HasDeductibleMAXOOPData = _context.HealthPlanDeductibles.Any(x => x.BenefitHeaderID == benefitHeaderID);
            return res;
        }
        #endregion
    }
}
