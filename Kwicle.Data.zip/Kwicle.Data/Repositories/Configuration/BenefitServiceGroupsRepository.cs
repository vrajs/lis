﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitServiceGroupsRepository : BaseRepository<BenefitServiceGroup> , IBenefitServiceGroupsRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion
        #region Cstr
        public BenefitServiceGroupsRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Method Implementation
        public IQueryable<BenefitServiceGroupModel> GetBenefitServiceGroupsByBenefitHeaderId(int BenefitHeaderID)
        {
            var query = (from bsg in _context.BenefitServiceGroups
                         where bsg.RecordStatus == (int)RecordStatus.Active && bsg.BenefitHeaderID == BenefitHeaderID
                         select new BenefitServiceGroupModel()
                         {
                             BenefitServiceGroupID = bsg.BenefitServiceGroupID,
                             BenefitHeaderID = bsg.BenefitHeaderID,
                             ClinicalCodeGroupID = bsg.ClinicalCodeGroupID,
                             ClinicalCodeGroup=bsg.ClinicalCodeGroup.GroupName,
                             ClinicalCodeSubGroupID = bsg.ClinicalCodeSubGroupID,
                             ClinicalCodeSubGroup = bsg.ClinicalCodeSubGroup.SubGroupName,
                             ClinicalCodeGroupDetailID = bsg.ClinicalCodeGroupDetailID,
                             ClinicalCodeGroupDetail = bsg.ClinicalCodeGroupDetail.SubCategoryName,
                             IsExclude = bsg.IsExclude,
                             EffectiveDate = bsg.EffectiveDate,
                             TermDate = (bsg.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : bsg.TermDate
                         });
            return query;
        }
        #endregion

    }
}
