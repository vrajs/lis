﻿using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.Configuration
{
    public class TermCodeRepository : BaseRepository<TermCodes>, ITermCodeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public TermCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion


        #region Interface Methods Implementation    
        public IEnumerable<TermCodeViewModel> GetAllTermCodes(int? TermHeaderId, int? ClinicalCodeTypeId)
        {
            var res = (from n in _context.TermCodes.Where(x => (!TermHeaderId.HasValue || x.TermHeaderID == TermHeaderId) && (!ClinicalCodeTypeId.HasValue || x.ClinicalCodeTypeID == ClinicalCodeTypeId))
                       from r in _context.CommonCodes.Where(x => x.CommonCodeID == n.ClinicalCodeTypeID).DefaultIfEmpty()
                       select new TermCodeViewModel()
                       {
                           TermCodesID = n.TermCodesID,
                           TermHeaderID = n.TermHeaderID,
                           ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                           ClinicalCodeType = r.ShortName,
                           MaxCode = n.MaxCode,
                           MinCode = n.MinCode,
                           IsExclude = n.IsExclude,
                           EffectiveDate = n.EffectiveDate,
                           TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                       }).ToList();
            return res;
        }

        public IQueryable<TermCodeViewModel> GetTermCodes(int TermHeaderId, int ClinicalCodeTypeId)
        {
            IQueryable<TermCodeViewModel> query = null;
            switch (ClinicalCodeTypeId)
            {
                case (int)ClinicalCodeType.General:
                    List<int> ClinicalCodeTypeIDList = new List<int>();
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.CPT2);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.CPT4);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.HCPCS);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.UBRevenue);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.MSDRGCodes);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.HUGS);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.RUGS);
                    query = from n in _context.TermCodes.Where(x => x.TermHeaderID == TermHeaderId && ClinicalCodeTypeIDList.Contains(x.ClinicalCodeTypeID))
                            from r in _context.CommonCodes.Where(x => x.CommonCodeID == n.ClinicalCodeTypeID)
                            select new TermCodeViewModel()
                            {
                                TermCodesID = n.TermCodesID,
                                TermHeaderID = n.TermHeaderID,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                                ClinicalCodeType = r.ShortName,
                                MaxCode = n.MaxCode,
                                MinCode = n.MinCode,
                                IsExclude = n.IsExclude,
                                EffectiveDate = n.EffectiveDate,
                                TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                            };
                    break;
                default:
                    query = from n in _context.TermCodes.Where(x => x.TermHeaderID == TermHeaderId && x.ClinicalCodeTypeID == ClinicalCodeTypeId)
                            from r in _context.CommonCodes.Where(x => x.CommonCodeID == n.ClinicalCodeTypeID)
                            select new TermCodeViewModel()
                            {
                                TermCodesID = n.TermCodesID,
                                TermHeaderID = n.TermHeaderID,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                                ClinicalCodeType = r.ShortName,
                                MaxCode = n.MaxCode,
                                MinCode = n.MinCode,
                                IsExclude = n.IsExclude,
                                EffectiveDate = n.EffectiveDate,
                                TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                            };
                    break;

            }
            return query;
        }
        #endregion
    }
}
