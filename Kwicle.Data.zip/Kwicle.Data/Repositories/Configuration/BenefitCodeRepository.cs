﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitCodeRepository : BaseRepository<BenefitCodes>, IBenefitCodeRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public BenefitCodeRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IEnumerable<BenefitCodes> GetAllBenefitCodes()
        {
            var res = _context.BenefitCodes.ToList();
            return res;
        }

        public IEnumerable<BenefitCodes> GetBenefitCodeByBenefitHeaderId(int BenefitHeaderId)
        {
            var res = _context.BenefitCodes.Where(x => x.BenefitHeaderID == BenefitHeaderId).ToList();
            return res;
        }

        public IEnumerable<BenefitCodes> GetBenefitCodeByClinicalCodeTypeId(int BenefitHeaderId, int ClinicalCodeTypeId)
        {
            var res = _context.BenefitCodes.Where(x => x.BenefitHeaderID == BenefitHeaderId && x.ClinicalCodeTypeID == ClinicalCodeTypeId).ToList();
            return res;
        }

        public IQueryable<BenefitCodeViewModel> GetBenefitCodes(int BenefitHeaderId, int ClinicalCodeTypeId)
        {
            IQueryable<BenefitCodeViewModel> query = null;
            switch (ClinicalCodeTypeId)
            {
                case (int)ClinicalCodeType.General:
                    List<int> ClinicalCodeTypeIDList = new List<int>();
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.CPT2);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.CPT4);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.HCPCS);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.UBRevenue);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.MSDRGCodes);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.HUGS);
                    ClinicalCodeTypeIDList.Add((int)ClinicalCodeType.RUGS);
                    query = from n in _context.BenefitCodes.Where(x => x.BenefitHeaderID == BenefitHeaderId && ClinicalCodeTypeIDList.Contains(x.ClinicalCodeTypeID))
                            from r in _context.CommonCodes.Where(x => x.CommonCodeID == n.ClinicalCodeTypeID)
                            select new BenefitCodeViewModel()
                            {
                                BenefitCodeID = n.BenefitCodeID,
                                BenefitHeaderID = n.BenefitHeaderID,
                                ClinicalCodeGroupDetailID = (int?)n.ClinicalCodeGroupDetailID,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                                ClinicalCodeType = r.ShortName,
                                MaxCode = n.MaxCode,
                                MinCode = n.MinCode,
                                POSCode = "",
                                IsExclude = n.IsExclude,
                                EffectiveDate = n.EffectiveDate,
                                TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                            };
                    break;
                default:
                    query = from n in _context.BenefitCodes.Where(x => x.BenefitHeaderID == BenefitHeaderId && x.ClinicalCodeTypeID == ClinicalCodeTypeId)
                            from r in _context.CommonCodes.Where(x => x.CommonCodeID == n.ClinicalCodeTypeID)
                            select new BenefitCodeViewModel()
                            {
                                BenefitCodeID = n.BenefitCodeID,
                                BenefitHeaderID = n.BenefitHeaderID,
                                ClinicalCodeGroupDetailID = (int?)n.ClinicalCodeGroupDetailID,
                                ClinicalCodeTypeID = n.ClinicalCodeTypeID,
                                ClinicalCodeType = r.ShortName,
                                MaxCode = n.MaxCode,
                                MinCode = n.MinCode,
                                POSCode = ClinicalCodeTypeId == (int)ClinicalCodeType.POS ? n.MinCode : "",
                                IsExclude = n.IsExclude,
                                EffectiveDate = n.EffectiveDate,
                                TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                            };
                    break;

            }
            return query;
        }
        #endregion
    }
}
