﻿using System.Collections.Generic;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System.Linq;
using Kwicle.Core.Common;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitCopayCoinsuranceRepository : BaseRepository<BenefitCopayCoinsurance>, IBenefitCopayCoinsuranceRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public BenefitCopayCoinsuranceRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation   
        public IEnumerable<BenefitCopayCoinsurance> GetAllBenefitCopayCoinsurance()
        {
            var res = _context.BenefitCopayCoinsurances.OrderByDescending(t => t.CreatedDate).ToList();
            return res;
        }

        public BenefitCopayCoinsurance GetBenefitCopayCoinsuranceByBenefitHeaderId(int BenefitHeaderId)
        {
            var res = _context.BenefitCopayCoinsurances.Include(c => c.CopayCoinsurance).ThenInclude(a => a.MaxCopayPerDiemTimePeriod).Include(c => c.CopayCoinsurance).ThenInclude(a => a.MaxCopayTimePeriod).Include(b => b.BenefitHeader).Where(x => x.BenefitHeaderID == BenefitHeaderId).OrderByDescending(t => t.CreatedDate).FirstOrDefault();
            return res;
        }
        #endregion
    }
}
