﻿using System.Linq;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using Kwicle.Core.Common;
using System;
using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
using System.Data;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Configuration
{
    public class TermHeaderRepository : BaseRepository<TermHeader>, ITermHeaderRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public TermHeaderRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        public IQueryable<TermHeaderViewModel> GetAllTerm(int? TermHeaderID, int? ContractID)
        {
            IQueryable<TermHeaderViewModel> query = from n in _context.TermHeaders.Where(x => (!TermHeaderID.HasValue || x.TermHeaderID == TermHeaderID) && (!ContractID.HasValue || x.ContractID == ContractID))
                                                    select new TermHeaderViewModel()
                                                    {
                                                        TermHeaderID = n.TermHeaderID,
                                                        ContractID = n.ContractID,
                                                        TermCode = n.TermCode,
                                                        TermName = n.TermName,
                                                        TermDescription = n.TermDescription,
                                                        AgeFrom = n.AgeFrom,
                                                        AgeTo = n.AgeTo,
                                                        Gender = n.Gender,
                                                        EOBReason = n.EOBReason,
                                                        RemitReason = n.RemitReason,
                                                        IsEmergencyRoom = n.IsEmergencyRoom,
                                                        IsCapitated = n.IsCapitated,
                                                        IsMembersAssigned = n.IsMembersAssigned,
                                                        IsPCP = n.IsPCP,
                                                        IsManualReview = n.IsManualReview,
                                                        IsIgnoreCaseRate = n.IsIgnoreCaseRate,
                                                        IsAuthRequired = n.IsAuthRequired,
                                                        IsAuthRequiredWhenBenefitRequireAuth = n.IsAuthRequiredWhenBenefitRequireAuth,
                                                        IsDocumentRequired = n.IsDocumentRequired,
                                                        IsUseFeeSchedule = n.IsUseFeeSchedule,
                                                        IsIgnoreFeeScheduleLimitIfAuthQuantityExceeds = n.IsIgnoreFeeScheduleLimitIfAuthQuantityExceeds,
                                                        TermProviderSpecialtyID = n.TermProviderSpecialty.Where(t => t.TermHeaderID == n.TermHeaderID).Select(t => t.SpecialtyID.ToString()).ToArray(),
                                                        TermProviderSpecialty = n.TermProviderSpecialty.Where(t => t.TermHeaderID == n.TermHeaderID).Select(t => new TermProviderSpecialtyViewModel { SpecialtyID = t.SpecialtyID, SpecialtyName = t.SpecialtyName, TermHeaderID = t.TermHeaderID, TermProviderSpecialtyID = t.TermProviderSpecialtyID }).ToArray(),
                                                        EffectiveDate = n.EffectiveDate,
                                                        TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate
                                                    };

            return query;
        }


        public new void Update(TermHeader Model)
        {
            using (this._context)
            {
                try
                {
                    var deletedData = _context.TermProviderSpecialties.Where(x => x.TermHeaderID == Model.TermHeaderID);
                    _context.TermProviderSpecialties.RemoveRange(deletedData);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    base.DbState.AddErrorMessage("CanNotPerformUpdateOperation", ex.Message);
                }
            }
        }

        public int CopyTerm(TermHeaderViewModel model, string CreatedBy, DateTime CreatedDate)
        {
            try
            {
                int NewTermHeaderId = 0;
                string errorMessage = "";

                SqlParameter[] parameters = {
                    new SqlParameter("@TermHeaderId", model.TermHeaderID),
                    new SqlParameter("@CreatedBy", CreatedBy),
                    new SqlParameter("@CreatedDate", CreatedDate),
                    new SqlParameter("@EffectiveDate",model.EffectiveDate),
                    new SqlParameter("@ContractHeaderId", model.ContractID),
                    new SqlParameter("@NewTermHeaderId",SqlDbType.Int) {Direction = ParameterDirection.Output},
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output},
                    new SqlParameter("@TermCode", model.TermCode),
                    new SqlParameter("@TermName", model.TermName),
                    new SqlParameter("@TermDate", model.TermDate),
                };

                if (model.TermDate == null || model.TermDate == DateTime.MinValue)
                {
                    parameters[9].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_CopyTerm] @TermHeaderId,@CreatedBy,@CreatedDate, @EffectiveDate,@ContractHeaderId,@NewTermHeaderId out, @ErrorMessage out, @TermCode,@TermName,@TermDate", parameters);

                errorMessage = Convert.ToString(parameters[6].Value);

                if (!string.IsNullOrEmpty(errorMessage))
                    base.DbState.AddErrorMessage("CanNotCopyTerm : CopyTerm", errorMessage);

                NewTermHeaderId = Convert.ToInt32(parameters[5].Value);

                return NewTermHeaderId;

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotCopyTerm", ex.Message);
                return -1;
            }
        }

        public void DeleteOrTermTermHeader(int TermHeaderId, string UpdatedBy, DateTime UpdatedDate, DateTime? TermDate, byte RecordStatus, string RecordStatusChangeComment)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@TermHeaderID", TermHeaderId),
                    new SqlParameter("@UpdatedDate", UpdatedDate),
                    new SqlParameter("@UpdatedBy", UpdatedBy),
                    new SqlParameter("@RecordStatus", RecordStatus),
                    new SqlParameter("@RecordStatusChangeComment", RecordStatusChangeComment),
                    new SqlParameter("@TermDate",TermDate) ,
                    new SqlParameter("@ErrorMessage",SqlDbType.VarChar,400) {Direction = ParameterDirection.Output}
                };

                if (TermDate == null || TermDate == DateTime.MinValue)
                {
                    parameters[5].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_DeleteOrTermTermHeader] @TermHeaderID,@UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@TermDate,@ErrorMessage out", parameters);

                var errorMessage = Convert.ToString(parameters[6].Value);

                if (!string.IsNullOrEmpty(errorMessage))
                    base.DbState.AddErrorMessage("CanNotDeleteOrTermTermHeader : DeleteOrTermTermHeader", errorMessage);

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotDeleteOrTermTermHeader", ex.Message);
            }
        }

        public HasTermConfigurationDataModel CheckTermConfigurationHasData(int TermHeaderId)
        {
            HasTermConfigurationDataModel model = new HasTermConfigurationDataModel();
            model.HasCodeData = _context.TermCodes.Any(x => x.TermHeaderID == TermHeaderId && (x.ClinicalCodeTypeID == (int)ClinicalCodeType.CPT2 || x.ClinicalCodeTypeID == (int)ClinicalCodeType.CPT4 || x.ClinicalCodeTypeID == (int)ClinicalCodeType.HCPCS || x.ClinicalCodeTypeID == (int)ClinicalCodeType.UBRevenue || x.ClinicalCodeTypeID == (int)ClinicalCodeType.MSDRGCodes || x.ClinicalCodeTypeID == (int)ClinicalCodeType.HUGS || x.ClinicalCodeTypeID == (int)ClinicalCodeType.RUGS));
            model.HasServiceGroupData = _context.TermServiceGroups.Any(x => x.TermHeaderID == TermHeaderId);
            model.HasModifierData = _context.TermCodes.Any(x => x.TermHeaderID == TermHeaderId && x.ClinicalCodeTypeID == (int)ClinicalCodeType.Modifier);
            model.HasDiagnosisData = _context.TermCodes.Any(x => x.TermHeaderID == TermHeaderId && (x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD9CMDX || x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD9CMPCS || x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD10CMDX || x.ClinicalCodeTypeID == (int)ClinicalCodeType.ICD10CMPCS));
            model.HasPlaceOfServiceData = _context.TermCodes.Any(x => x.TermHeaderID == TermHeaderId && x.ClinicalCodeTypeID == (int)ClinicalCodeType.POS);
            model.HasBillTypeData = _context.TermCodes.Any(x => x.TermHeaderID == TermHeaderId && x.ClinicalCodeTypeID == (int)ClinicalCodeType.UBTOB);
            model.HasLimitsData = _context.TermLimits.Any(x => x.TermHeaderID == TermHeaderId);
            model.HasPaymentData = _context.TermPayments.Any(x => x.TermHeaderID == TermHeaderId && DateTime.Now.Date >= x.EffectiveDate.Date && DateTime.Now.Date <= x.TermDate);
            return model;
        }
        #endregion
    }
}
