﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class ClinicalCodeGroupDetailRepository : BaseRepository<ClinicalCodeGroupDetail>, IClinicalCodeGroupDetailRepository
    {
        #region variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClinicalCodeGroupDetailRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion
        #region Methods
        public IQueryable<ClinicalCodeGroupDetailModel> GetClinicalCodeGroupDetail(short ClinicalCodeSubGroupID)
        {
            var query = (from ccgd in _context.ClinicalCodeGroupDetails
                         where ccgd.ClinicalCodeSubGroupID == ClinicalCodeSubGroupID
                         //&& ccgd.IsAuth == false
                         select new ClinicalCodeGroupDetailModel()
                         {
                             ClinicalCodeGroupDetailID = ccgd.ClinicalCodeGroupDetailID,
                             GroupTypeID = ccgd.GroupTypeID,
                             ClinicalCodeSubGroupID = ccgd.ClinicalCodeSubGroupID,
                             ClinicalCodeSubGroup = ccgd.ClinicalCodeSubGroup.SubGroupName,
                             SubCategoryName = ccgd.SubCategoryName,
                             ClinicalCodeTypeID = ccgd.ClinicalCodeTypeID,
                             ClinicalCodeType = "",
                             StartCode = ccgd.StartCode,
                             EndCode = ccgd.EndCode,
                             ExcludeStartCode = ccgd.ExcludeStartCode,
                             ExcludeEndCode = ccgd.ExcludeEndCode,
                             EffectiveDate = ccgd.EffectiveDate,
                             TermDate = (ccgd.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : ccgd.TermDate,
                             IsAuth = ccgd.IsAuth,
                         });
            return query;
        }

        public List<KeyValuePair<int, string>> GetClinicalCodeGroupDetailKeyVal(short ClinicalCodeSubGroupID)
        {
            var result = _context.ClinicalCodeGroupDetails.Where(x => x.ClinicalCodeSubGroupID == ClinicalCodeSubGroupID).OrderBy(e => e.SubCategoryName).Select(x => new KeyValuePair<int, string>(x.ClinicalCodeGroupDetailID, x.SubCategoryName)).ToList();
            return result;
        }

        private IQueryable<ClinicalCodeGroupDetailModel> GetClinicalCodeGroupList()
        {
            var query = (from ccgd in _context.ClinicalCodeGroupDetails
                             //where ccgd.RecordStatus == (byte)RecordStatus.Active //&& ccgd.IsAuth == false
                         select new ClinicalCodeGroupDetailModel()
                         {
                             ClinicalCodeGroupDetailID = ccgd.ClinicalCodeGroupDetailID,
                             GroupTypeID = ccgd.GroupTypeID,
                             ClinicalCodeSubGroupID = ccgd.ClinicalCodeSubGroupID,
                             ExcludeStartCode = ccgd.ExcludeStartCode,
                             ExcludeEndCode = ccgd.ExcludeEndCode,
                             EffectiveDate = ccgd.EffectiveDate,
                             TermDate = ccgd.TermDate,
                             IsAuth = ccgd.IsAuth,
                         });
            return query;
        }

        public ClinicalCodeGroupDetailModel CheckGroupValidity(int clinicalCodeGroupDetailID, DateTime effectiveDate, DateTime termDate)
        {
            ClinicalCodeGroupDetailModel clinicalCodeGroupDetailModel = null;
            var query = this.GetClinicalCodeGroupList();
            //var groupValidateQuery = query.Where(i => i.ClinicalCodeGroupDetailID == clinicalCodeGroupDetailID && (((i.EffectiveDate <= effectiveDate.Date) && (i.TermDate >= effectiveDate.Date)) ||
            //            ((i.EffectiveDate <= termDate.Date) && (i.TermDate >= termDate.Date))
            //            || ((i.EffectiveDate >= effectiveDate.Date) && (i.TermDate <= termDate.Date))));
            var groupValidateQuery = query.Where(i => i.ClinicalCodeGroupDetailID == clinicalCodeGroupDetailID && (effectiveDate.Date >= i.EffectiveDate && effectiveDate.Date <= i.TermDate)
            && (termDate.Date >= i.EffectiveDate && termDate.Date <= i.TermDate));
            var isGroupInRange = groupValidateQuery.Any();
            clinicalCodeGroupDetailModel = isGroupInRange ? null : query.Where(i => i.ClinicalCodeGroupDetailID == clinicalCodeGroupDetailID).FirstOrDefault();
            return clinicalCodeGroupDetailModel;
        }
        #endregion
    }
}
