﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.Configuration
{
    public class TermServiceGroupsRepository : BaseRepository<TermServiceGroup>, ITermServiceGroupsRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public TermServiceGroupsRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Method Implementation
        public IQueryable<TermServiceGroupModel> GetTermServiceGroupsByTermHeaderId(int TermHeaderID)
        {
            var query = (from bsg in _context.TermServiceGroups
                         where bsg.TermHeaderID == TermHeaderID
                         select new TermServiceGroupModel()
                         {
                             TermServiceGroupID = bsg.TermServiceGroupID,
                             TermHeaderID = bsg.TermHeaderID,
                             ClinicalCodeGroupID = bsg.ClinicalCodeGroupID,
                             ClinicalCodeGroup = bsg.ClinicalCodeGroup.GroupName,
                             ClinicalCodeSubGroupID = bsg.ClinicalCodeSubGroupID,
                             ClinicalCodeSubGroup = bsg.ClinicalCodeSubGroup.SubGroupName,
                             ClinicalCodeGroupDetailID = bsg.ClinicalCodeGroupDetailID,
                             ClinicalCodeGroupDetail = bsg.ClinicalCodeGroupDetail.SubCategoryName,
                             IsExclude = bsg.IsExclude,
                             EffectiveDate = bsg.EffectiveDate,
                             TermDate = (bsg.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : bsg.TermDate
                         });
            return query;
        }
        #endregion

    }
}
