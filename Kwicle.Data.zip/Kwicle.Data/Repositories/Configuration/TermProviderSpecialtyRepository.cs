﻿using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Data.Contracts.Configuration;

namespace Kwicle.Data.Repositories.Configuration
{
    public class TermProviderSpecialtyRepository : BaseRepository<TermProviderSpecialty> , ITermProviderSpecialtyRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public TermProviderSpecialtyRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Interface Methods Implementation    
        #endregion
    }
}
