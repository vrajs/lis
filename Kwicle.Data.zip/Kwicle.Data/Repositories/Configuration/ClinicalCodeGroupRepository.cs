﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class ClinicalCodeGroupRepository : BaseRepository<ClinicalCodeGroup>, IClinicalCodeGroupRepository
    {
        #region variables
        private readonly KwicleContext _context;
        #endregion
        #region Ctor
        public ClinicalCodeGroupRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        #endregion
        #region Methods
        public List<KeyValuePair<short, string>> GetClinicalCodeGroup()
        {
            var result = _context.ClinicalCodeGroups.OrderBy(e => e.GroupName).Select(x => new KeyValuePair<short, string>(x.ClinicalCodeGroupID, x.GroupName)).ToList();
            return result;
        }
        #endregion

    }
}
