﻿using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitProviderSpecialtyRepository : BaseRepository<BenefitProviderSpecialty>, IBenefitProviderSpecialtyRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public BenefitProviderSpecialtyRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Methods
        public List<BenefitProviderSpecialty> GetByBenefitHeaderID(int BenefitHeaderID)
        {
            var result = (from bps in _context.BenefitProviderSpecialties
                          where bps.BenefitHeaderID == BenefitHeaderID
                          select new BenefitProviderSpecialty()
                          {
                              BenefitProviderSpecialtyID = bps.BenefitProviderSpecialtyID,
                              BenefitHeaderID = bps.BenefitHeaderID,
                              SpecialtyID = bps.SpecialtyID,
                              SpecialtyName = bps.SpecialtyName,
                              CreatedBy = bps.CreatedBy,
                              CreatedDate = bps.CreatedDate,
                              RecordStatus = bps.RecordStatus,
                              RecordStatusChangeComment = bps.RecordStatusChangeComment
                          }).ToList();
            return result;
        }

        //public void DeleteByBenefitHeaderID(int BenefitHeaderID)
        //{
        //    var deletedData = _context.BenefitProviderSpecialties.Where(x => x.BenefitHeaderID == BenefitHeaderID);
        //    _context.BenefitProviderSpecialties.RemoveRange(deletedData);
        //    _context.SaveChangesAsync();
        //}
        #endregion
    }
}
