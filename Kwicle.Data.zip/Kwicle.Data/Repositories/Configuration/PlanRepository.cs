using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
//using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.Configuration
{
    public class PlanRepository : BaseRepository<HealthPlan>, IPlanRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        private byte activeStatus = (byte)RecordStatus.Active;
        private byte inActiveStatus = (byte)RecordStatus.InActive;
        private byte termedStatus = (byte)RecordStatus.Termed;
        private byte cancelStatus = (byte)RecordStatus.Cancel;
        private byte deletedStatus = (byte)RecordStatus.Deleted;
        private byte invalidStatus = (byte)RecordStatus.VoidOrInvalid;
        #endregion

        #region Ctor
        public PlanRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;            
        }
        #endregion
        #region Methods
        public void AddBenefitsToPlan(int HealthPlanID, List<int> BenefitHeaderIds, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate)
        {
            try
            {

                var benefitHeaderId = string.Join(",", BenefitHeaderIds.Select(i => i.ToString()).ToArray());
                SqlParameter[] parameters = {
                new SqlParameter("@HealthPlanID", HealthPlanID),
                new SqlParameter("@BenefitHeaderIDs", benefitHeaderId),
                new SqlParameter("@EffectiveDate", EffectiveDate.Date),
                new SqlParameter("@CreatedBy", CreatedBy),
                new SqlParameter("@CreatedDate",CreatedDate) ,
            };

                _context.Database.ExecuteSqlRaw("[hps].[usp_AddBenefitsToPlan] @HealthPlanID, @BenefitHeaderIDs, @EffectiveDate, @CreatedBy, @CreatedDate", parameters);


            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : AddBenefitsToPlan", ex.Message);

            }
        }

        public int CopyHealthPlan(int SourceHealthPlanID, string PlanCode, string PlanName, string BenefitHeaderIds, int ApprovalStatusID, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate, DateTime? ApprovalDate, DateTime? TermDate)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@SourceHealthPlanID", SourceHealthPlanID),
                    new SqlParameter("@PlanCode", PlanCode),
                    new SqlParameter("@PlanName", PlanName),
                    new SqlParameter("@DeleminatedBenefits", BenefitHeaderIds),
                    new SqlParameter("@ApprovalStatusID", ApprovalStatusID),
                    new SqlParameter("@ApprovalDate", ApprovalDate),
                    new SqlParameter("@EffectiveDate", EffectiveDate.Date),
                    new SqlParameter("@TermDate", TermDate),
                    new SqlParameter("@CreatedBy", CreatedBy),
                    new SqlParameter("@CreatedDate",CreatedDate) ,
                    new SqlParameter("@CreatedHealthPlanID", SqlDbType.Int) {Direction = ParameterDirection.Output},
                    new SqlParameter("@ErrorMessage", SqlDbType.VarChar ,4000) {Direction = ParameterDirection.Output},
                };

                if (ApprovalDate == null || ApprovalDate == DateTime.MinValue)
                {
                    parameters[5].Value = DBNull.Value;
                }

                if (TermDate == null || TermDate == DateTime.MinValue)
                {
                    parameters[7].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_CopyHealthPlan] @SourceHealthPlanID,@PlanCode,@PlanName,@DeleminatedBenefits,@ApprovalStatusID,@ApprovalDate,@EffectiveDate,@TermDate,@CreatedBy,@CreatedDate,@CreatedHealthPlanID out,@ErrorMessage out", parameters);

                var errorMessage = Convert.ToString(parameters[11].Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotPerform : CopyHealthPlan", errorMessage);
                    return -1;
                }

                var createdHealthPlanID = Convert.ToInt32(parameters[10].Value);
                return createdHealthPlanID;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : CopyHealthPlan", ex.Message);
                return -1;
            }
        }

        public IQueryable<GetPlanModel> GetPlans()
        {

            var query = from n in _context.GetPlans.Where(i => i.RecordStatus != deletedStatus && i.RecordStatus != invalidStatus)
                        select n;
            return query;

        }

        public void RemovePlanBenefit(int healthPlanID, int benefitHeaderID, DateTime todaysDate, string userName, string removeReason, int recordStatus)
        {
            try
            {

                SqlParameter[] parameters = {
                    new SqlParameter("@HealthPlanID", healthPlanID),
                    new SqlParameter("@BenefitHeaderID", benefitHeaderID),
                    new SqlParameter("@UpdatedDate",todaysDate) ,
                    new SqlParameter("@UpdatedBy", userName),
                    new SqlParameter("@RecordStatus", recordStatus),
                    new SqlParameter("@RecordStatusChangeComment", SqlDbType.VarChar ,4000  ){ Value = removeReason },
                    new SqlParameter("@ErrorMessage", SqlDbType.VarChar ,4000) {Direction = ParameterDirection.Output},

                };

                _context.Database.ExecuteSqlRaw("[hps].[usp_DeleteOrTermPlanBenefit] @HealthPlanID, @BenefitHeaderID, @UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@ErrorMessage OUT", parameters);

                var errorMessage = Convert.ToString(parameters[6].Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotPerform:DeleteBenefitFromPlan : {0}", errorMessage);
                }

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : RemovePlanBenefit {0}", ex.Message);

            }
        }
        public void RemoveOrTermPlanBenefit(int healthPlanID, List<int> benefitHeaderIDs, DateTime todaysDate, string userName, int recordStatus, string recordStatusChangeComment, DateTime? termDate = null)
        {
            try
            {
                var benefitHeaderId = string.Join(",", benefitHeaderIDs.Select(i => i.ToString()).ToArray());

                SqlParameter[] parameters = {
                    new SqlParameter("@HealthPlanID", healthPlanID),
                    new SqlParameter("@BenefitHeaderIDs", benefitHeaderId),
                    new SqlParameter("@UpdatedDate",todaysDate) ,
                    new SqlParameter("@UpdatedBy", userName),
                    new SqlParameter("@RecordStatus", recordStatus),
                    new SqlParameter("@RecordStatusChangeComment", recordStatusChangeComment),
                    new SqlParameter("@ErrorMessage", SqlDbType.VarChar ,4000) {Direction = ParameterDirection.Output},
                    new SqlParameter("@TermDate", termDate)
                };

                if (!termDate.HasValue)
                {
                    parameters[7].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_BulkRemoveOrTermBenefitHealthPlan] @HealthPlanID, @BenefitHeaderIDs, @UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@ErrorMessage,@TermDate", parameters);

                var errorMessage = Convert.ToString(parameters[6].Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotPerform : DeletePlanBenefit : {0}", errorMessage);
                }

            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : usp_BulkRemoveOrTermBenefitHealthPlan", ex.Message);

            }
        }

        public void Delete(int HealthPlanID, DateTime TodaysDate, string UserName, int recordStatus, string RemoveReason, DateTime? termDate = null)
        {
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@HealthPlanID", HealthPlanID),
                    new SqlParameter("@UpdatedDate",TodaysDate) ,
                    new SqlParameter("@UpdatedBy", UserName),
                    new SqlParameter("@RecordStatus", recordStatus),
                    new SqlParameter("@RecordStatusChangeComment", SqlDbType.VarChar ,4000  ){ Value = RemoveReason },
                    new SqlParameter("@ErrorMessage", SqlDbType.VarChar ,4000) {Direction = ParameterDirection.Output},
                    new SqlParameter("@TermDate", termDate)
                };

                if (!termDate.HasValue)
                {
                    parameters[6].Value = DBNull.Value;
                }

                _context.Database.ExecuteSqlRaw("[hps].[usp_RemoveHealthPlan] @HealthPlanID,@UpdatedDate,@UpdatedBy,@RecordStatus,@RecordStatusChangeComment,@ErrorMessage OUT,@TermDate", parameters);

                var errorMessage = Convert.ToString(parameters[5].Value);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    base.DbState.AddErrorMessage("CanNotPerform : DeleteHealthPlan : {0}", errorMessage);
                }
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotPerform : Delete Health Plan {0}", ex.Message);

            }
        }

        public HasPlanConfigurationDataModel CheckPlanConfigurationHasData(int healthPlanID)
        {
            HasPlanConfigurationDataModel res = new HasPlanConfigurationDataModel();
            res.HasBenefitData = _context.BenefitHeaderHealthPlans.Any(x => x.HealthPlanID == healthPlanID);
            res.HasDeductibleMAXOOPData = _context.HealthPlanDeductibles.Any(x => x.HealthPlanID == healthPlanID);
            return res;
        }

        public IQueryable<GetPlanModel> GetPlans(int benefitHeaderID, bool isInclude)
        {            
            var query = from n in _context.GetPlans
                        where n.RecordStatus != (byte)RecordStatus.Deleted && n.RecordStatus != (byte)RecordStatus.VoidOrInvalid
                        select n;           
            if (isInclude)
            {
                query = from n in query
                        join p in _context.BenefitHeaderHealthPlans on n.HealthPlanID equals p.HealthPlanID
                        where p.RecordStatus != (byte)RecordStatus.VoidOrInvalid && p.BenefitHeaderID == benefitHeaderID
                        select new GetPlanModel
                        {
                            ApprovalDate = n.ApprovalDate,
                            ApprovalStatus = n.ApprovalStatus,
                            Company = n.Company,
                            County = n.County,
                            EffectiveDate = p.EffectiveDate,
                            HealthPlanID = n.HealthPlanID,
                            LOB = n.LOB,
                            LobID = n.LobID,
                            PBPCode = n.PBPCode,
                            PlanCode = n.PlanCode,
                            PlanName = n.PlanName,
                            ProductType = n.ProductType,
                            RecordStatus = n.RecordStatus,
                            State = n.State,
                            SubCompany = n.SubCompany,
                            TermDate = p.TermDate
                        };

            }
            return query;

        }

        /// <summary>
        /// 
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<GetPlanModel> GetActivePlansForMemberEligibility()
        {
            //var query = from n in _context.GetPlans
            //            where (n.RecordStatus == (byte)RecordStatus.Active || n.RecordStatus == (byte)RecordStatus.InActive)
            //                        && (n.LobRecordStatus == (byte)RecordStatus.Active || n.LobRecordStatus == (byte)RecordStatus.InActive)
            //                        && (n.SubCompanyRecordStatus == (byte)RecordStatus.Active || n.SubCompanyRecordStatus == (byte)RecordStatus.InActive)
            //                        && (n.CompanyRecordStatus == (byte)RecordStatus.Active || n.CompanyRecordStatus == (byte)RecordStatus.InActive)                                   
            //            select n;

            var query = from n in _context.GetPlans.Where(i => (i.RecordStatus == activeStatus || i.RecordStatus == inActiveStatus) 
                                                                                        && (i.LobRecordStatus == activeStatus || i.LobRecordStatus == inActiveStatus) 
                                                                                        && (i.SubCompanyRecordStatus == activeStatus || i.SubCompanyRecordStatus == inActiveStatus)                                                                                         
                                                                                        && (i.CompanyRecordStatus == activeStatus || i.CompanyRecordStatus == inActiveStatus))
                        select n;

            return query;
        }
        #endregion
    }
}