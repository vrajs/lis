﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.Configuration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Configuration
{
    public class BenefitHeaderHealthPlanRepository : BaseRepository<BenefitHeaderHealthPlan>, IBenefitHeaderHealthPlanRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public BenefitHeaderHealthPlanRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion

        #region Public Methods
        public int BulkInsert(List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans)
        {
            try
            {
                if (benefitHeaderHealthPlans.Count > 0)
                {
                    short maxmimumClaimPriority = this.GetMaxmimumClaimPriority(benefitHeaderHealthPlans[0].HealthPlanID);
                    benefitHeaderHealthPlans.ForEach(e =>
                    {
                        maxmimumClaimPriority++;
                        e.ClaimHitPriority = maxmimumClaimPriority;
                    });
                    _context.BenefitHeaderHealthPlans.AddRange(benefitHeaderHealthPlans);
                    return _context.SaveChanges();
                }
                return -1;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotAssociateBenefitAndPlan", ex.ToErrorMessage());
                return -1;
            }
        }

        public void BulkTerm(BenefitHeaderHealthPlanTermModel benefitHeaderHealthPlanTermModel)
        {
            try
            {
                var benefitHeaderHealthPlans = _context.BenefitHeaderHealthPlans.Where(i => benefitHeaderHealthPlanTermModel.BenefitHeaderID.Contains(i.BenefitHeaderID) && benefitHeaderHealthPlanTermModel.HealthPlanID.Contains(i.HealthPlanID));
                benefitHeaderHealthPlans.ToList().ForEach((benefitHeaderHealthPlan) =>
                {
                    benefitHeaderHealthPlan.RecordStatus = benefitHeaderHealthPlanTermModel.RecordStatus;
                    benefitHeaderHealthPlan.TermDate = benefitHeaderHealthPlanTermModel.TermDate;
                    benefitHeaderHealthPlan.RecordStatusChangeComment = benefitHeaderHealthPlanTermModel.TermReason;
                });
                _context.BenefitHeaderHealthPlans.UpdateRange(benefitHeaderHealthPlans);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("BulkTerm", ex.ToErrorMessage());
            }

        }

        public int BulkUpdate(List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans)
        {
            try
            {
                _context.BenefitHeaderHealthPlans.UpdateRange(benefitHeaderHealthPlans);
                return _context.SaveChanges();
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotAssociateBenefitAndPlan", ex.ToErrorMessage());
                return -1;
            }

        }

        public BenefitHeaderHealthPlan GetByBenefitAndHealthPlan(int healthPlanId, int benefitHeaderId)
        {
            try
            {
                //&& i.RecordStatus == (byte)RecordStatus.Active
                BenefitHeaderHealthPlan benefitHeaderHealthPlan = _context.BenefitHeaderHealthPlans.Single(i => i.HealthPlanID == healthPlanId && i.BenefitHeaderID == benefitHeaderId);
                return benefitHeaderHealthPlan;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("GetByBenefitAndHealthPlan", ex.ToErrorMessage());
                return null;
            }
        }

        public BenefitHeaderHealthPlan Delete(int healthPlanID, int benefitHeaderID, string userName, DateTime todaysDate)
        {
            BenefitHeaderHealthPlan entity = null;
            var executionStratagy = _context.Database.CreateExecutionStrategy();
            executionStratagy.Execute(() => { 
            
                    using (var dbCTransaction = _context.Database.BeginTransaction())
                    {
                        try
                        {
                            entity = this.GetByBenefitAndHealthPlan(healthPlanID, benefitHeaderID);
                            if (entity != null)
                            {
                                // Update entity with delete status
                                entity.UpdatedBy = userName;
                                entity.UpdatedDate = todaysDate;
                                entity.RecordStatus = (byte)RecordStatus.Deleted;
                                entity.RecordStatusChangeComment = "Deleted";
                                _context.BenefitHeaderHealthPlans.Update(entity);
                                _context.SaveChanges();

                                // Configure other benefits claim priority 
                                short claimPriority = -1;
                                List<BenefitHeaderHealthPlan> planBenefitList = _context.BenefitHeaderHealthPlans.Where(e => e.HealthPlanID == healthPlanID && e.BenefitHeaderID != benefitHeaderID && e.RecordStatus != (byte)RecordStatus.Deleted).OrderBy(o => o.ClaimHitPriority).ToList();
                                planBenefitList.ForEach(e =>
                                {
                                    claimPriority++;
                                    e.ClaimHitPriority = claimPriority;
                                });
                                _context.BenefitHeaderHealthPlans.UpdateRange(planBenefitList);

                                _context.SaveChanges();
                                dbCTransaction.Commit();
                            }
                            return entity;
                        }
                        catch (Exception ex)
                        {
                            dbCTransaction.Rollback();
                            base.DbState.AddErrorMessage("CanNotDeleteHealthPlanBenefit", ex.Message);
                            return null;
                        }
                    }
            });
            return entity;
        }

        public void ConfigureBenefitProrityForClaim(int healthPlanID, List<KeyVal<int, short>> listBenefit, string userName, DateTime todaysDate)
        {
            try
            {
                List<BenefitHeaderHealthPlan> entBenefitList = _context.BenefitHeaderHealthPlans.Where(i => i.HealthPlanID == healthPlanID).ToList();
                foreach (BenefitHeaderHealthPlan item in entBenefitList)
                {
                    KeyVal<int, short> currentPriority = listBenefit.Where(e => e.Key == item.BenefitHeaderID).FirstOrDefault();
                    if (currentPriority != null)
                    {
                        item.ClaimHitPriority = currentPriority.Value;
                        item.UpdatedBy = userName;
                        item.UpdatedDate = todaysDate;
                    }
                }
                _context.BenefitHeaderHealthPlans.UpdateRange(entBenefitList);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotConfigureBenefitProrityForClaim", ex.ToErrorMessage());
            }
        }
        #endregion

        #region Private Methods
        private short GetMaxmimumClaimPriority(int HealthPlanID)
        {
            var maxmimumClaimPriority = _context.BenefitHeaderHealthPlans.Where(i => i.HealthPlanID == HealthPlanID && i.RecordStatus != (byte)RecordStatus.Deleted).OrderByDescending(e => e.ClaimHitPriority).FirstOrDefault();
            if (maxmimumClaimPriority == null)
                return -1;
            else
                return maxmimumClaimPriority.ClaimHitPriority;
        }
        #endregion
    }
}
