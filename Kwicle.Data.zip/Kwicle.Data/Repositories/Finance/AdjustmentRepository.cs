﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class AdjustmentRepository : BaseRepository<Adjustment>, IAdjustmentRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public AdjustmentRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Adjustment> GetAllAdjustment()
        {
            try
            {
                var res = _context.Adjustments.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllAdjustment", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AdjustmentID"></param>
        /// <returns></returns>
        public IQueryable<AdjustmentViewModel> GetAdjustment(short AdjustmentID)
        {
            try
            {
                var query = from b in _context.Adjustments
                            where b.AdjustmentID == AdjustmentID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new AdjustmentViewModel()
                            {
                                AdjustmentID = b.AdjustmentID,
                                LOBID = b.LOBID,
                                ProviderID = b.ProviderID,
                                PaymentTypeID = b.PaymentTypeID,
                                ReasonID = b.ReasonID,
                                AdjustmentAmount = b.AdjustmentAmount,
                                CheckNumber = b.CheckNumber,
                                IsApplyPaymentType = b.IsApplyPaymentType,                                
                                TotalAppliedAmount = b.TotalAppliedAmount,
                                TotalBalanceAmount = b.TotalBalanceAmount
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAdjustment", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
