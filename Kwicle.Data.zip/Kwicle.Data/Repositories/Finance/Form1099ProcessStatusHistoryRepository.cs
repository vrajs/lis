﻿using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Finance
{
    public class Form1099ProcessStatusHistoryRepository : BaseRepository<Form1099ProcessStatusHistory>, IForm1099ProcessStatusHistoryRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public Form1099ProcessStatusHistoryRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Methods
        public IQueryable<vwForm1099ProcessStatusHistoryList> GetForm1099ProcessStatusHistoryList(long RecGroupKey)
        {
            try
            {
                var result = _viewContext.vwForm1099ProcessStatusHistoryList.Where(x => x.RecGroupKey == RecGroupKey).AsQueryable();
                return result;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetForm1099ProcessStatusHistoryList", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
