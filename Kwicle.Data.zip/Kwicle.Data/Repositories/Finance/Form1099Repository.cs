﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class Form1099Repository : BaseRepository<Form1099>, IForm1099Repository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public Form1099Repository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Form1099> GetAllForm1099()
        {
            try
            {
                var res = _context.Form1099s.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllForm1099", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Form1099ID"></param>
        /// <returns></returns>
        public IQueryable<Form1099Model> GetForm1099(int Form1099ID)
        {
            try
            {
                var query = from b in _context.Form1099s
                            where b.Form1099ID == Form1099ID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new Form1099Model()
                            {
                                Form1099ID = b.Form1099ID,
                                Form1099ProcessID = b.Form1099ProcessID,
                                RecipientID = b.RecipientID.HasValue ? b.RecipientID.Value : (int?)null,
                                DocumentID = b.DocumentID,
                                PrintCount = b.PrintCount,
                                IsSent = b.IsSent,
                                SentVia = b.SentVia,
                                LastPrintDate = b.LastPrintDate,
                                LastPrintBY = b.LastPrintBY
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetForm1099", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Form1099ProcessID"></param>
        /// <returns></returns>
        public IQueryable<Form1099Model> GetForm1099ByForm1099ProcessID(int Form1099ProcessID)
        {
            try
            {
                var query = from b in _context.Form1099s
                            where b.Form1099ProcessID == Form1099ProcessID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new Form1099Model()
                            {
                                Form1099ID = b.Form1099ID,
                                Form1099ProcessID = b.Form1099ProcessID,
                                RecipientID = b.RecipientID,
                                DocumentID = b.DocumentID,
                                PrintCount = b.PrintCount,
                                IsSent = b.IsSent,
                                SentVia = b.SentVia,
                                LastPrintDate = b.LastPrintDate,
                                LastPrintBY = b.LastPrintBY
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetForm1099", ex.Message);
                return null;
            }
        }

        #endregion
    }
}
