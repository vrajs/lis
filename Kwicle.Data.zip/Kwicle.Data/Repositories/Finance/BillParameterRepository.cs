﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class BillParameterRepository : BaseRepository<BillParameter>, IBillParameterRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public BillParameterRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<BillParameter> GetAllBillParameter()
        {
            try
            {
                var res = _context.BillParameters.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllBillParameter", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="BillParameterID"></param>
        /// <returns></returns>
        public IQueryable<BillParameterViewModel> GetBillParameter(short BillParameterID)
        {
            try
            {
                var query = from b in _context.BillParameters
                            join l in _context.Lobs on b.LOBID equals l.LobID
                            join cs in _context.CommonCodes on b.SourceTypeID equals cs.CommonCodeID
                            where ((BillParameterID == 0 ? true == true : b.BillParameterID == BillParameterID) && b.RecordStatus != (int)RecordStatus.Deleted)
                            select new BillParameterViewModel()
                            {
                                BillParameterID = b.BillParameterID,
                                LOBID = b.LOBID,
                                LOBName = l.LobName,
                                SourceTypeID = b.SourceTypeID,
                                SourceType = cs.ShortName,
                                BeginBillCycle = b.BeginBillCycle,
                                EndBillCycle = b.EndBillCycle,
                                DaysLate = b.DaysLate,
                                DueDate = b.DueDate,
                                LatePenalty = b.LatePenalty,
                                NSF = b.NSF,
                                Administration = b.Administration,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = (b.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : b.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetBillParameter", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
