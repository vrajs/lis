﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class AdjustmentAppliedDetailRepository : BaseRepository<AdjustmentAppliedDetail>, IAdjustmentAppliedDetailRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public AdjustmentAppliedDetailRepository(KwicleContext context,KwicleViewContext kwicleViewContext ) : base(context)
        {
            _context = context;
            _viewContext = kwicleViewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<AdjustmentAppliedDetail> GetAllAdjustmentAppliedDetail()
        {
            try
            {
                var res = _context.AdjustmentAppliedDetails.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllAdjustmentAppliedDetail", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AdjustmentAppliedDetailID"></param>
        /// <returns></returns>
        public IQueryable<AdjustmentAppliedDetailModel> GetAdjustmentAppliedDetail(short AdjustmentAppliedDetailID)
        {
            try
            {
                var query = from b in _context.AdjustmentAppliedDetails
                            where b.AdjustmentAppliedDetailID == AdjustmentAppliedDetailID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new AdjustmentAppliedDetailModel()
                            {
                                AdjustmentAppliedDetailID = b.AdjustmentAppliedDetailID,
                                AdjustmentCheckDetailID = b.AdjustmentCheckDetailID,
                                AppliedAmount = b.AppliedAmount,
                                BalanceAmount = b.BalanceAmount,
                                AppliedDate = b.AppliedDate,
                                AppliedToCheckDetailID = b.AppliedToCheckDetailID,
                                AppliedtoClaimHeaderID = b.AppliedtoClaimHeaderID

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAdjustmentAppliedDetail", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AdjustmentID"></param>
        /// <returns></returns>
        public IQueryable<AdjustmentAppliedDetailModel> GetAdjustmentAppliedDetailByAdjustmentID(short AdjustmentCheckDetailID)
        {
            try
            {
                var query = from b in _context.AdjustmentAppliedDetails
                            where b.AdjustmentCheckDetailID == AdjustmentCheckDetailID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new AdjustmentAppliedDetailModel()
                            {
                                AdjustmentAppliedDetailID = b.AdjustmentAppliedDetailID,
                                AdjustmentCheckDetailID = b.AdjustmentCheckDetailID,
                                AppliedAmount = b.AppliedAmount,
                                BalanceAmount = b.BalanceAmount,
                                AppliedDate = b.AppliedDate,
                                AppliedToCheckDetailID = b.AppliedToCheckDetailID,
                                AppliedtoClaimHeaderID = b.AppliedtoClaimHeaderID

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAdjustmentAppliedDetail", ex.Message);
                return null;
            }
        }

        public IQueryable<vwAdjustmentAppliedList> GetAdjustmentAppliedList(int CheckDetailID)
        {
            try
            {
                var query = this._viewContext.vwAdjustmentAppliedList.AsQueryable();
                if (CheckDetailID > 0)
                    query = query.Where(x => x.CheckDetailID == CheckDetailID).AsQueryable();
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingAdjustmentList", ex.Message);
                return null;
            }
        }

        #endregion
    }
}
