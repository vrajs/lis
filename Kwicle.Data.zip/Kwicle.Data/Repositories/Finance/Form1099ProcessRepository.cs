﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.Finance
{
    public class Form1099ProcessRepository : BaseRepository<Form1099Process>, IForm1099ProcessRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public Form1099ProcessRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Form1099Process> GetAllForm1099Process()
        {
            try
            {
                var res = _context.Form1099Processes.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllForm1099Process", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Form1099ProcessID"></param>
        /// <returns></returns>
        public IQueryable<Form1099ProcessModel> GetForm1099Process(int Form1099ProcessID)
        {
            try
            {
                var query = from b in _context.Form1099Processes
                            where b.Form1099ProcessID == Form1099ProcessID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new Form1099ProcessModel()
                            {
                                Form1099ProcessID = b.Form1099ProcessID,
                                IsVoid = b.IsVoid,
                                IsCorrected = b.IsCorrected,
                                ProcessMode = b.ProcessMode,
                                FormYear = b.FormYear,
                                PayerID = b.PayerID,
                                RecipientID = b.RecipientID,
                                PaymentThreshold = b.PaymentThreshold,
                                PrintDollarAmountinBoxNo = b.PrintDollarAmountinBoxNo,
                                AccountNameToFill = b.AccountNameToFill,
                                IsFATCA = b.IsFATCA,
                                SecondTinNot = b.SecondTinNot,
                                IsCreateIRSFile = b.IsCreateIRSFile

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetForm1099Processes", ex.Message);
                return null;
            }
        }

        public IQueryable<vwForm1099ProcessList> GetForm1099ProcessList()
        {
            try
            {
                var res = _viewContext.vwForm1099ProcessList.Where(x => x.RecordStatus == (byte)RecordStatus.Active && x.ProcessMode == ProcessMode.Prod.ToInteger().ToString()).OrderByDescending(x => x.Form1099ProcessID).OrderByDescending(x=>x.Form1099ProcessID).AsQueryable();
                return res;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetForm1099ProcessList", ex.Message);
                return null;
            }
        }

        public IQueryable<Form1099Data> GetForm1099ProcessData(int Form1099ProcessID, string CreatedBy)
        {
            Object[] paramList = {
                new SqlParameter("@form1099ProcessID", Form1099ProcessID),
                new SqlParameter("@createdBy", CreatedBy )
            };
            var testData = _context.ExecuteStoreProcedure<Form1099Data>("finance.usp_GetForm1099Data", paramList).ToList();
            return testData.AsQueryable();
        }
        public IQueryable<Form1099Data> SaveForm1099ProcessData(int Form1099ProcessID, string CreatedBy)
        {
            Object[] paramList = {
                new SqlParameter("@form1099ProcessID", Form1099ProcessID),
                new SqlParameter("@createdBy", CreatedBy )
            };
            _context.ExecuteStoreProcedure<Form1099Data>("finance.usp_SaveForm1099Data", paramList).ToList();
            var testData = GetForm1099ProcessData(Form1099ProcessID, CreatedBy);
            //var testData = _context.Form1099Data.Where(x => x.RecordStatus != (int)RecordStatus.Deleted 
            //                                                && x.Form1099ProcessID == Form1099ProcessID).ToList();
            return testData.AsQueryable();
        }
        #endregion
    }
}
