﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class LienHolderBalanceRepository : BaseRepository<LienHolderBalance>, ILienHolderBalanceRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public LienHolderBalanceRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion 

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<LienHolderBalance> GetAllLienHolderBalance()
        {
            try
            {
                var res = _context.LienHolderBalances.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllLienHolderBalance", ex.Message);
                return null;
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="LienHolderBalanceID"></param>
        /// <returns></returns>
        public IQueryable<LienHolderBalanceModel> GetLienHolderBalance(short LienHolderBalanceID)
        {
            try
            {
                var query = from b in _context.LienHolderBalances
                            join z in _context.ZipCodes on b.Zip equals z.Code
                            where b.LienHolderBalanceID == LienHolderBalanceID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new LienHolderBalanceModel()
                            {
                                LienHolderBalanceID = b.LienHolderBalanceID,
                                LienHolderID = b.LienHolderID,
                                LOBID = b.LOBID,
                                ProviderID = b.ProviderID,
                                ReceivedDate = b.ReceivedDate,
                                LienIssuedBy = b.LienIssuedBy,
                                LienAmount = b.LienAmount,
                                AppliedAmount = b.AppliedAmount,
                                BalanceAmount = b.BalanceAmount,
                                Address1 = b.Address1,
                                Address2 = b.Address2,
                                City = b.City,
                                State = b.State,
                                County = b.County,
                                Country = b.Country,
                                Zip = b.Zip,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = b.TermDate,                                
                                ZipCodeID = z.ZipCodeID
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetLienHolderBalance", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="LienHolderID"></param>
        /// <returns></returns>
        public IQueryable<LienHolderBalanceModel> GetLienHolderBalanceByLienHolderID(short LienHolderID)
        {
            try
            {
                var query = from b in _context.LienHolderBalances
                            where b.LienHolderID == LienHolderID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new LienHolderBalanceModel()
                            {
                                LienHolderBalanceID = b.LienHolderBalanceID,
                                LienHolderID = b.LienHolderID,
                                LOBID = b.LOBID,
                                ProviderID = b.ProviderID,
                                ReceivedDate = b.ReceivedDate,
                                LienIssuedBy = b.LienIssuedBy,
                                LienAmount = b.LienAmount,
                                AppliedAmount = b.AppliedAmount,
                                BalanceAmount = b.BalanceAmount,
                                Address1 = b.Address1,
                                Address2 = b.Address2,
                                City = b.City,
                                State = b.State,
                                County = b.County,
                                Country = b.Country,
                                Zip = b.Zip,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = b.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetLienHolderBalance", ex.Message);
                return null;
            }
        }


        public IQueryable<vwLienAccountList> GetLienAccountList()
        {
            try
            {
                var query = _viewContext.GetLienAccountList.Where(x=>x.RecordStatus ==(byte)RecordStatus.Active).AsQueryable();
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingLienAccountList", ex.Message);
                return null;
            }
        }

        
        /// <summary>
        /// method to get lienHolderBalanceAmountHistory
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwLienHolderBalanceAmountHistory> GetLienHolderBalanceAmountHistory()
        {
            try
            {
                var query = _viewContext.GetLienHolderBalanceAmountHistory.AsQueryable();
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingLienHolderBalanceAmountHistory", ex.Message);
                return null;
            }
        }

        #endregion
    }
}
