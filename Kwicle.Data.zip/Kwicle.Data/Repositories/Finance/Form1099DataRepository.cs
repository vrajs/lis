﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.Finance
{
    public class Form1099DataRepository : BaseRepository<Form1099Data>, IForm1099DataRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public Form1099DataRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<Form1099Data> GetForm1099DataByProcessID(int Form1099ProcessID)
        {
            try
            {
                var res = _context.Form1099Data.Where(x => x.RecordStatus == (int)RecordStatus.Active &&
                                                            x.Form1099ProcessID == Form1099ProcessID
                                                            //).Where(y =>
                                                            //    y.Box1Rents == 0 ||
                                                            //    y.Box2Royalties == 0 ||
                                                            //    y.Box3OtherIncome == 0 ||
                                                            //    y.Box4FederalIncomeTaxWithheld == 0 ||
                                                            //    y.Box5FishingBoatProceeds == 0 ||
                                                            //    y.Box6MedicalAndHealthCarePayments == 0 ||
                                                            //    y.Box7NonEmployeeCompensation == 0 ||
                                                            //    y.Box8SubstitutePaymentsInLieuOfDividendsOrInterest == 0 ||
                                                            //    y.Box9PayerMadeDirectSales == 0 ||
                                                            //    y.Box10CropInsuranceProceeds == 0 ||
                                                            //    y.Box11 == 0 || y.Box12 == 0 ||
                                                            //    y.Box13ExcessGoldenParachutePayments == 0 ||
                                                            //    y.Box14GrossProceedsPaidToAnAttorney == 0 ||
                                                            //    y.Box15aSection409ADeferrals == 0 ||
                                                            //    y.Box15bSection409AIncome == 0 ||
                                                            //    y.Box16StateTaxWithheld1 == 0 ||
                                                            //    y.Box16StateTaxWithheld2 == 0 ||
                                                            //    y.Box18StateIncome1 == 0 ||
                                                            //    y.Box18StateIncome2 != 0 &&
                                                            //(
                                                            //    y.Box1Rents == 0 ||
                                                            //    y.Box2Royalties == 0 ||
                                                            //    y.Box3OtherIncome == 0 ||
                                                            //    y.Box4FederalIncomeTaxWithheld == 0 ||
                                                            //    y.Box5FishingBoatProceeds == 0 ||
                                                            //    y.Box6MedicalAndHealthCarePayments == 0 ||
                                                            //    y.Box7NonEmployeeCompensation == 0 ||
                                                            //    y.Box8SubstitutePaymentsInLieuOfDividendsOrInterest == 0 ||
                                                            //    y.Box9PayerMadeDirectSales == 0 ||
                                                            //    y.Box10CropInsuranceProceeds == 0 ||
                                                            //    y.Box11 == 0 || y.Box12 == 0 ||
                                                            //    y.Box13ExcessGoldenParachutePayments == 0 ||
                                                            //    y.Box14GrossProceedsPaidToAnAttorney == 0 ||
                                                            //    y.Box15aSection409ADeferrals == 0 ||
                                                            //    y.Box15bSection409AIncome == 0 ||
                                                            //    y.Box16StateTaxWithheld1 == 0 ||
                                                            //    y.Box16StateTaxWithheld2 == 0 ||
                                                            //    y.Box18StateIncome1 == 0 ||
                                                            //    y.Box18StateIncome2 != 0
                                                            // )
                                                      ).ToList();
                return res.AsQueryable();

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllForm1099Data", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
