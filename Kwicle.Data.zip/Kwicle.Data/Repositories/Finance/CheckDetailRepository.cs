﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class CheckDetailRepository : BaseRepository<CheckDetail>, ICheckDetailRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public CheckDetailRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CheckDetail> GetAllCheckDetail()
        {
            try
            {
                var res = _context.CheckDetails.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllCheckDetail", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CheckDetailID"></param>
        /// <returns></returns>
        public IQueryable<CheckDetailModel> GetCheckDetail(int CheckDetailID)
        {
            try
            {
                var query = from b in _context.CheckDetails
                            where b.CheckDetailID == CheckDetailID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new CheckDetailModel()
                            {
                                CheckDetailID = b.CheckDetailID,
                                PaymentTypeID = b.PaymentTypeID,
                                CheckNumber = b.CheckNumber,
                                CheckDate = b.CheckDate,
                                AccountDetailID = b.AccountDetailID,
                                VendorID = b.VendorID,
                                VendorName = b.VendorName,
                                PrintDate = b.PrintDate,
                                AllowedAmount = b.AllowedAmount,
                                InterestAmount = b.InterestAmount,
                                AdjustmentAmount = b.AdjustmentAmount,
                                TotalAmount = b.TotalAmount,
                                ClearingDate = b.ClearingDate,
                                StopPayDate = b.StopPayDate,
                                ReissueCheckNumber = b.ReissueCheckNumber,
                                CheckStatusID = b.CheckStatusID,
                                LocationID = b.LocationID,
                                LocationDetail = b.LocationDetail,
                                Comments = b.Comments,
                                CheckWriteProcessID = b.CheckWriteProcessID,
                                LOBID = b.LOBID,
                                IsApplyPaymentType = b.IsApplyPaymentType,
                                ReasonID = b.ReasonID.HasValue ? b.ReasonID.Value : 0,
                                LOBName = b.LOB.LobName,
                                ProviderCode = b.Vendor.ProviderCode,
                                ProviderName = b.Vendor.FullName,
                                CheckStatusName = b.CheckStatus.Name,
                                PaymentTypeName = b.PaymentType.Name,
                                ReasonName = b.Reason.ShortName,
                                AccountNumber = b.AccountDetail.AccountNumber,
                                BankName = b.AccountDetail.BankName,
                                AccountTypeName = b.AccountDetail.AccountType.ShortName
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetCheckDetail", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CheckWriteProcessID"></param>
        /// <returns></returns>
        public IQueryable<CheckDetailModel> GetCheckDetailByCheckWriteProcessID(int CheckWriteProcessID)
        {
            try
            {
                var query = from b in _context.CheckDetails
                            where b.CheckWriteProcessID == CheckWriteProcessID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new CheckDetailModel()
                            {
                                CheckDetailID = b.CheckDetailID,
                                PaymentTypeID = b.PaymentTypeID,
                                CheckNumber = b.CheckNumber,
                                CheckDate = b.CheckDate,
                                AccountDetailID = b.AccountDetailID,
                                VendorID = b.VendorID,
                                VendorName = b.VendorName,
                                PrintDate = b.PrintDate,
                                AllowedAmount = b.AllowedAmount,
                                InterestAmount = b.InterestAmount,
                                AdjustmentAmount = b.AdjustmentAmount,
                                TotalAmount = b.TotalAmount,
                                ClearingDate = b.ClearingDate,
                                StopPayDate = b.StopPayDate,
                                ReissueCheckNumber = b.ReissueCheckNumber,
                                CheckStatusID = b.CheckStatusID,
                                LocationID = b.LocationID,
                                LocationDetail = b.LocationDetail,
                                Comments = b.Comments,
                                CheckWriteProcessID = b.CheckWriteProcessID

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetCheckDetail", ex.Message);
                return null;
            }
        }

        public IQueryable<vwAdjustmentList> GetAdjustmentList()
        {
            try
            {
                var query = this._viewContext.vwAdjustmentList.Where(x => x.RecordStatus == (byte)RecordStatus.Active).OrderByDescending(x => x.CheckDetailID).AsQueryable();
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingAdjustmentList", ex.Message);
                return null;
            }
        }


        #endregion
    }
}
