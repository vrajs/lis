﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class LienHolderRepository : BaseRepository<LienHolder>, ILienHolderRepository
    {
        #region Variables

        private readonly KwicleContext _context;

        #endregion

        #region Ctor

        public LienHolderRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<LienHolder> GetAllLienHolder()
        {
            try
            {
                var res = _context.LienHolders.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllLienHolder", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="LienHolderID"></param>
        /// <returns></returns>
        public IQueryable<LienHolderModel> GetLienHolder(short LienHolderID)
        {
            try
            {
                var query = from b in _context.LienHolders
                            join z in _context.ZipCodes on b.Zip equals z.Code
                            where b.LienHolderID == LienHolderID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new LienHolderModel()
                            {
                                LienHolderID = b.LienHolderID,
                                HolderName = b.HolderName,
                                Address1 = b.Address1,
                                Address2 = b.Address2,
                                City = b.City,
                                State = b.State,
                                County = b.County,
                                Country = b.Country,
                                Zip = b.Zip,
                                ZipCodeID = z.ZipCodeID
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetLienHolder", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// method to get lie holder list for dropdowns
        /// </summary>
        /// <returns></returns>
        public IQueryable<KeyVal<int, string>> GetLienHolderList()
        {
            try
            {
                var query = from holder in _context.LienHolders
                            select new KeyVal<int, string>()
                            {
                                Key = holder.LienHolderID,
                                Value = holder.HolderName
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetLienHolder", ex.Message);
                return null;
            }

        }



        #endregion
    }
}
