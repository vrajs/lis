﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class AccountDetailRepository : BaseRepository<AccountDetail>, IAccountDetailRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public AccountDetailRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<AccountDetail> GetAllAccountDetail()
        {
            try
            {
                var res = _context.AccountDetails.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllAccountDetail", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AccountDetailID"></param>
        /// <returns></returns>
        public IQueryable<AccountDetailModel> GetAccountDetail(short AccountDetailID)
        {
            try
            {
                var query = from b in _context.AccountDetails
                            where b.AccountDetailID == AccountDetailID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new AccountDetailModel()
                            {
                                AccountDetailID = b.AccountDetailID,
                                AccountTypeID = b.AccountTypeID,
                                AccountNumber = b.AccountNumber,
                                RoutingNumber = b.RoutingNumber,
                                BankName = b.BankName,
                                Is835 = b.Is835,
                                IsEFT = b.IsEFT,
                                EffectiveDate = b.EffectiveDate,
                                TermDate = b.TermDate
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAccountDetail", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AccountDetailID"></param>
        /// <returns></returns>
        public IQueryable<vwAccountDetailList> GetAccountDetailList()
        {
            try
            {                                        
                var query = this._viewContext.GetAccountDetailList.Where(x=>x.RecordStatus!=(byte)RecordStatus.Deleted).OrderByDescending(x=>x.CreatedDate).AsQueryable();
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingAccountDetailList", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
