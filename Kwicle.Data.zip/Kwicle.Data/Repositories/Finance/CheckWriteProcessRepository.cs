﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class CheckWriteProcessRepository : BaseRepository<CheckWriteProcess>, ICheckWriteProcessRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;
        #endregion

        #region Ctor

        public CheckWriteProcessRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CheckWriteProcess> GetAllCheckWriteProcess()
        {
            try
            {
                var res = _context.CheckWriteProcesses.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllCheckWriteProcess", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CheckWriteProcessID"></param>
        /// <returns></returns>
        public IQueryable<CheckWriteProcessModel> GetCheckWriteProcess(int CheckWriteProcessID)
        {
            try
            {
                var query = from b in _context.CheckWriteProcesses
                            where b.CheckWriteProcessID == CheckWriteProcessID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new CheckWriteProcessModel()
                            {
                                CheckWriteProcessID = b.CheckWriteProcessID,
                                ProcessType = b.ProcessType,
                                ProcessMode = b.ProcessMode,
                                LOBID = b.LOBID,
                                HealthPlanID = b.HealthPlanID,
                                AccountDetailID = b.AccountDetailID,
                                StartCheckNumber = b.StartCheckNumber,
                                CheckDate = b.CheckDate,
                                NetworkID = b.NetworkID,
                                PaymentTypeID = b.PaymentTypeID,
                                ClaimSourceID = b.ClaimSourceID,
                                PaymentDateTypeID = b.PaymentDateTypeID,
                                FromDate = b.FromDate,
                                ToDate = b.ToDate,
                                ClaimTypeID = b.ClaimTypeID,
                                ParameterTypeID = b.ParameterTypeID,
                                ParameterValueID = b.ParameterValueID,
                                RunDate = b.RunDate,
                                RunTime = b.RunTime,
                                RetroMonths = b.RetroMonths,
                                CapTypeID = b.CapTypeID,
                                CapContractID = b.CapContractID,
                                Comments = b.Comments

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetCheckWriteProcess", ex.Message);
                return null;
            }
        }

        public IQueryable<vwCheckWriteProcessList> GetVwCheckWriteProcessList()
        {
            try
            {
                var query = this._viewContext.vwCheckWriteProcessList.Where(x => x.RecordStatus == (byte)RecordStatus.Active).OrderByDescending(x => x.CheckWriteProcessID).AsQueryable();
                return query;
            }
            catch(Exception ex)
            {
                base.DbState.AddErrorMessage("CanNotGetCheckWriteProcess", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
