﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.Finance;

namespace Kwicle.Data.Repositories.Finance
{
    public class AccountDetailCompanyStructureRepository : BaseRepository<AccountDetailCompanyStructure>, IAccountDetailCompanyStructureRepository
    {
        #region Variables

        private readonly KwicleContext _context;
        private readonly KwicleViewContext _viewContext;

        #endregion

        #region Ctor

        public AccountDetailCompanyStructureRepository(KwicleContext context, KwicleViewContext viewContext) : base(context)
        {
            _context = context;
            _viewContext = viewContext;
        }

        #endregion

        #region Interface Methods Implementation    

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<AccountDetailCompanyStructure> GetAllAccountDetailCompanyStructure()
        {
            try
            {
                var res = _context.AccountDetailCompanyStructures.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAllAccountDetailCompanyStructure", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AccountDetailCompanyStructureID"></param>
        /// <returns></returns>
        public IQueryable<AccountDetailCompanyStructureModel> GetAccountDetailCompanyStructure(short AccountDetailCompanyStructureID)
        {
            try
            {
                var query = from b in _context.AccountDetailCompanyStructures
                            where b.AccountDetailCompanyStructureID == AccountDetailCompanyStructureID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new AccountDetailCompanyStructureModel()
                            {
                                AccountDetailCompanyStructureID = b.AccountDetailCompanyStructureID,
                                AccountDetailID = b.AccountDetailID,
                                OrganizationID = b.OrganizationID,
                                CompanyID = b.CompanyID,
                                SubCompanyID = b.SubCompanyID,
                                SponsorID = b.SponsorID,
                                ProductID = b.ProductID,
                                CategoryID = b.CategoryID,
                                LOBID = b.LOBID,
                                HealthPlanID = b.HealthPlanID,
                                ProductTypeID = b.ProductTypeID,
                                CategoryName = b.Category.CategoryName,
                                CompanyName = b.Company.OrganizationName,
                                SubCompanyName = b.SubCompany.OrganizationName,
                                OrganizationName = b.Organization.OrganizationName,
                                LOBName = b.LOB.LobName,
                                PlanName = b.HealthPlan.PlanName,
                                ProductName = b.Product.ProductName,
                                ProductTypeName = b.ProductType.ProductTypeName,
                                SponsorName = b.Sponsor.SponsorName
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAccountDetailCompanyStructure", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AccountDetailID"></param>
        /// <returns></returns>
        public IQueryable<AccountDetailCompanyStructureModel> GetAccountDetailCompanyStructureByAccountDetailID(short AccountDetailID)
        {
            try
            {
                var query = from b in _context.AccountDetailCompanyStructures
                            where b.AccountDetailID == AccountDetailID && b.RecordStatus != (int)RecordStatus.Deleted
                            select new AccountDetailCompanyStructureModel()
                            {
                                AccountDetailCompanyStructureID = b.AccountDetailCompanyStructureID,
                                AccountDetailID = b.AccountDetailID,
                                OrganizationID = b.OrganizationID,
                                CompanyID = b.CompanyID,
                                SubCompanyID = b.SubCompanyID,
                                SponsorID = b.SponsorID,
                                ProductID = b.ProductID,
                                CategoryID = b.CategoryID,
                                LOBID = b.LOBID,
                                HealthPlanID = b.HealthPlanID,
                                ProductTypeID = b.ProductTypeID

                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetAccountDetailCompanyStructure", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// Returns the list for Company Account List
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwCompanyAccountList> GetCompanyAccountList()
        {
            try
            {
                var query = this._viewContext.GetCompanyAccountList.Where(x => x.RecordStatus != (int)RecordStatus.Deleted).OrderByDescending(x => x.CreatedDate).AsQueryable();
                return query;
            }
            catch (Exception ex)
            {
                base.DbState.AddErrorMessage("ErrorWhileGettingCompanyAccountList", ex.Message);
                return null;
            }
        }



        #endregion
    }
}
