﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Data.Extensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi837ProfessionalRepositories : Disposable, IEdi837ProfessionalRepositories
    {
        private readonly DataImportContext _context;
        private readonly KwicleContext _hpscontext;

        public Edi837ProfessionalRepositories(DataImportContext context, KwicleContext hpscontext)
        {
            _context = context;
            _hpscontext = hpscontext;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12InterchangeId"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public Edi837PEncounterFileGenerateEntity GetEdi837PDetails(int X12DocumentID, CurrentTradingPartner currentTradingPartner)
        {
            return new Edi837PEncounterFileGenerateEntity
            {
                mvw_Mtab_x12_TradingPartner_summary = currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_837),
                ClaimProfessionals = _context.VwClaimProfessionalOutbounds.Where(x => x.X12_document_oid == X12DocumentID).ToList(),
                ClaimProfessionalServices = (from srv in _context.VwClaimProfessionalServicesOutbounds
                                             join clm in _context.VwClaimProfessionalOutbounds on srv.ClaimProfessionalOutboundId equals clm.ClaimProfessionalOutboundId
                                             where clm.X12_document_oid == X12DocumentID
                                             select srv
                                             ).ToList(),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_837_5010 && loop.RecordStatus == (int)RecordStatus.Active).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_837_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                           .OrderBy(segment => segment.LoopGroup)
                                                           .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_837_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(element => element.LoopGroup)
                                                          .ThenBy(element => element.SegmentSequence)
                                                          .ThenBy(element => element.SegmentoccurrenceSeq)
                                                          .ThenBy(element => element.ElementPosition)
                                                          .ThenBy(element => element.SubElementPosition).ToList()
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimProfessionals"></param>
        public void ClaimBulkInsert(List<ClaimProfessionalOutbound> ClaimProfessionals)
        {
            _context.ClaimProfessionalOutbound.AddRange(ClaimProfessionals);
            _context.SaveChanges();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimProfessionalServices"></param>
        public void ClaimServiceulkInsert(List<ClaimProfessionalServicesOutbound> ClaimProfessionalServices)
        {
            _context.ClaimProfessionalServicesOutbound.AddRange(ClaimProfessionalServices);
            _context.SaveChanges();
        }

        public void ClaimTrnasfer(int x12_interchange_id)
        {
            var parax12InterchangeId = new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12_interchange_id);
            _context.Database.ExecuteSqlRaw(EDI837PStructure.uspMup837PTransfer, parax12InterchangeId);
        }

        public List<FileExists> IsFileExists(string isa09_interchange_date, string isa10_interchange_time, string isa13_control_no, string gs04_date, string gs05_time, string filetype, int TradingPartnerId, int DataFileConfigurationID)
        {
            try
            {
                var parameters = new SqlParameter[]
            {
                    new SqlParameter("@" + x12_interchangeStructure.ISA09_INTERCHANGE_DATE, isa09_interchange_date),
                    new SqlParameter("@" + x12_interchangeStructure.ISA10_INTERCHANGE_TIME, isa10_interchange_time),
                    new SqlParameter("@" + x12_interchangeStructure.ISA13_CONTROL_NO, isa13_control_no),
                    new SqlParameter("@" + EDI837PStructure.GS04_DATE,gs04_date) ,
                    new SqlParameter("@" + EDI837PStructure.GS05_TIME, gs05_time),
                    new SqlParameter("@" + EDI837PStructure.FILETYPE,filetype),
                    new SqlParameter("@" + EDI837PStructure.TRADINGPARTNERID,TradingPartnerId),
                    new SqlParameter("@" + EDI837PStructure.DATAFILECONFIGURATIONID,DataFileConfigurationID)
             };
                return _context.ExecuteStoreProcedure<FileExists>(EDI837PStructure.uspValidateDuplicateFile, parameters);
            }
            catch
            {
                throw;
            }
        }
        public DataSourceResult GetClaimProfesstional(GridOption_View ObjView)
        {
            //string strX12_DOCUMENT_ID = ObjView.Requestparam.Single(a => a.Name == EDI837PStructure.X12_DOCUMENT_ID).Value;
            var parameters = new List<SqlParameter>
            {
                    new SqlParameter("@" + EDI837PStructure.OrderByColumn, (object)ObjView.OrderByColumn ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.OrderByDirection, (object)ObjView.OrderByDirection ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.Skip,ObjView.Skip) ,
                    new SqlParameter("@" + EDI837PStructure.Take, ObjView.Take),
                    new SqlParameter("@" + EDI837PStructure.totalItems,System.Data.SqlDbType.Int){ Direction = ParameterDirection.Output}
             };
            if (ObjView.Filter != null)
            {
                foreach (var item in ObjView.Filter)
                {
                    parameters.Add(new SqlParameter("@" + item.Name, (object)item.Value ?? DBNull.Value));
                }
            }
            string parameterName = string.Join(",", parameters.Select(o => o.Direction == ParameterDirection.Output ? o.ParameterName + " " + ParameterDirection.Output : o.ParameterName).ToArray()).ToString();

            var data = _context.ExecuteStoreProcedure<EDI837PUploadFileModel>(EDI837PStructure.uspGetClaimProfesstional + parameterName, parameters.ToArray()).ToList();
            int count = Convert.ToInt32(parameters.Single(p => p.ParameterName == "@" + EDI837PStructure.totalItems).Value);
            return new DataSourceResult
            {
                Data = data,
                totalItems = count
            };

        }

        public DataSourceResult GetClaimProfesstionalByStatus(GridOption_View ObjView)
        {
            string strX12_DOCUMENT_ID = ObjView.Requestparam.Single(a => a.Name == EDI837PStructure.X12_DOCUMENT_ID).Value;
            string strClaim_status = ObjView.Requestparam.Single(a => a.Name == EDI837PStructure.Claim_status).Value;

            var parameters = new List<SqlParameter>
            {
                    new SqlParameter("@" + EDI837PStructure.X12_DOCUMENT_ID,strX12_DOCUMENT_ID),
                    new SqlParameter("@" + EDI837PStructure.Claim_status, (object)strClaim_status ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.OrderByColumn, (object)ObjView.OrderByColumn ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.OrderByDirection, (object)ObjView.OrderByDirection ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.Skip,ObjView.Skip) ,
                    new SqlParameter("@" + EDI837PStructure.Take, ObjView.Take),
                    new SqlParameter("@" + EDI837PStructure.totalItems,System.Data.SqlDbType.Int){ Direction = ParameterDirection.Output}
            };
            if (ObjView.Filter != null)
            {
                foreach (var item in ObjView.Filter)
                {
                    parameters.Add(new SqlParameter("@" + item.Name, (object)item.Value ?? DBNull.Value));
                }
            }

            string parameterName = string.Join(",", parameters.Select(o => o.Direction == ParameterDirection.Output ? o.ParameterName + " " + ParameterDirection.Output : o.ParameterName).ToArray()).ToString();

            var data = _context.ExecuteStoreProcedure<ClaimProfesstionalDetailView>(EDI837PStructure.uspGetClaimProfesstionalByStatus + parameterName, parameters.ToArray()).ToList();
            int count = Convert.ToInt32(parameters.Single(p => p.ParameterName == "@" + EDI837PStructure.totalItems).Value);
            return new DataSourceResult
            {
                Data = data,
                totalItems = count
            };
        }
        public List<TradingPartnerList> GetTradingPartnerList()
        {
            return _context.ExecuteStoreProcedure<TradingPartnerList>(EDI837PStructure.uspGetTradingPartnerList, null).ToList();
        }
        public bool UpdateClaimPByStatus(ClaimActiveStatusParam objRequestparmList)
        {
            var parameters = new List<SqlParameter>
            {
                    new SqlParameter("@" + EDI837PStructure.Ids,objRequestparmList.Ids),
                    new SqlParameter("@" + EDI837PStructure.Status,objRequestparmList.Status),
                     new SqlParameter("@" + EDI837PStructure.Note,objRequestparmList.Note),
            };
            string parameterName = string.Join(",", parameters.Select(o => o.ParameterName).ToArray()).ToString();
            _context.Database.ExecuteSqlRaw(EDI837PStructure.uspUpdateClaimPByStatus + parameterName, parameters.ToArray());
            return true;
        }

        public void UpdateClaimStatus(int ClaimProfessionalId, int ClaimStatus, DateTime UpdatedDate, string ClaimReferenceNo)
        {
            var parameters = new List<SqlParameter>
            {
                    new SqlParameter("@" + EDI837PStructure.CLAIMPROFESSIONALID,ClaimProfessionalId),
                    new SqlParameter("@" + EDI837PStructure.Claim_status,ClaimStatus),
                     new SqlParameter("@" + EDI837PStructure.UpdatedDate,UpdatedDate),
                     new SqlParameter("@" + EDI837PStructure.ClaimReferenceNo,ClaimReferenceNo)
            };
            _context.Database.ExecuteSqlRaw(EDI837PStructure.uspUpdateClaimProfessional, parameters);

        }
        public List<vwFileHistory> GetFileHistory(int x12_DocumentID)
        {
            var parax12InterchangeId = new List<SqlParameter> { new SqlParameter("@" + EDI837PStructure.X12_DOCUMENT_ID, x12_DocumentID) };
            return _context.ExecuteStoreProcedure<vwFileHistory>(EDI837PStructure.uspGetFileHistory, parax12InterchangeId.ToArray()).ToList();
        }

        #region HPS
        #region claim edit detail
        public bool SaveClaimDetail(Kwicle.Core.Entities.EDI.ClaimProfessional ClaimDetail, bool isApplySameFix)
        {
            if (isApplySameFix)
            {
                object[] paraMemberEligibility =    {
                        new SqlParameter("@ClaimProfessionalId", ClaimDetail.ClaimProfessionalId),
                        new SqlParameter("@L2010BA_nm109_subscriber_id", ClaimDetail.L2010baNm109SubscriberId),
                        new SqlParameter("@L2010AA_nm109_billing_prov_id", ClaimDetail.L2010aaNm109BillingProvId),
                        new SqlParameter("@UpdatedBy", ClaimDetail.UpdatedBy),
                        new SqlParameter("@UpdatedDate", ClaimDetail.UpdatedDate)   };

                _context.Database.ExecuteSqlRaw("edi.usp_ApplySameFixProfessionalClaim @ClaimProfessionalId, @L2010BA_nm109_subscriber_id, @L2010AA_nm109_billing_prov_id, @UpdatedBy, @UpdatedDate", paraMemberEligibility);
            }

            _context.Update(ClaimDetail);
            _context.SaveChanges();
            return true;
        }
        public bool SaveClaimDetailServiceLine(ClaimProfessionalServices ClaimProfessionalServices)
        {
            _context.Update(ClaimProfessionalServices);
            _context.SaveChanges();
            return true;
        }
        public bool AddClaimDetailServiceLine(ClaimProfessionalServices ClaimProfessionalServices)
        {
            _context.Add(ClaimProfessionalServices);
            _context.SaveChanges();
            return true;
        }
        #endregion
        public IQueryable<EDI837PUploadFileModel> GetEdi837P()
        {
            return (from Doc in _context.Vw837PFileSummary
                    where Doc.RecordStatus == (int)RecordStatus.Active
                    && Doc.Filetype == "837P"
                    select new EDI837PUploadFileModel
                    {
                        FileID = Doc.FileID,
                        FileName = Doc.FileName,
                        TradingPartnerID = Doc.TradingPartnerID,
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        FileStatus = Doc.FileStatus,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        Total = Doc.Total,
                        Pending = Doc.Pending,
                        InProgress = Doc.InProgress,
                        Posted = Doc.Posted,
                        Failed = Doc.Failed,
                        BilledAmount = Doc.BilledAmount,
                        Version = Doc.Version,
                        HasError = Doc.Error == true ? "Yes" : "No"
                    });
        }
        public IQueryable<EDI837PClaimModel> GetEdi837PClaims()
        {
            return (from Clm in _context.VwProfessionalClaimSummary
                    where Clm.RecordStatus == (int)RecordStatus.Active && Clm.Filetype == "837P"

                    select new EDI837PClaimModel
                    {
                        ClaimID = Clm.ClaimID,
                        FileID = Clm.FileID,
                        TradingPartnerID = Clm.TradingPartnerID,
                        ClaimNo = Clm.ClaimNo,
                        MemberID = Clm.MemberID,
                        DOB = Clm.DOB.Value,
                        Name = Clm.Name,
                        Billed = Clm.Billed,
                        ClaimStatus = Clm.ClaimStatus.Value,
                        PatientControlNumber = Clm.PatientControlNumber,
                        RenderingProvider = Clm.RenderingProvider,
                        BillingProvider = Clm.BillingProvider,
                        BillingProviderNPI = Clm.BillingProviderNPI,
                        Billtype = Clm.Billtype,
                        UploadedDate = Clm.UploadedDate.Value,
                        ClaimErrorCount = Clm.ClaimErrorCount.Value,
                        ClaimErrorMsg = Clm.ClaimErrorMsg,
                        HasError = Clm.ClaimErrorCount > 0 ? "Yes" : "No"
                    });
        }
        public Kwicle.Core.Entities.EDI.ClaimProfessional GetClaimProfessional(int Claimid)
        {
            return _context.ClaimProfessional
                   .Where(x => x.ClaimProfessionalId == Claimid)
                   .SingleOrDefault();
        }
        public ClaimProfessionalServices GetClaimProfessionalServices(int? Claimid, int? ServiceId)
        {
            var q = (from a in _context.ClaimProfessionalServices select a);
            if (Claimid != 0)
            {
                q = q.Where(b => b.ClaimProfessionalId == Claimid);
            }
            if (ServiceId != 0)
            {
                q = q.Where(b => b.MtabX12837ServicesOid == ServiceId);
            }

            return q.SingleOrDefault();
        }
        public IQueryable<ServiceLine> GetClaimServiceLine(int Claimid, int ServiceId)
        {
            var q = (from a in _context.ClaimProfessionalServices
                     where a.RecordStatus == (int)RecordStatus.Active
                     && a.ClaimProfessionalId == (Claimid == 0 ? a.ClaimProfessionalId : Claimid)
                     select new ServiceLine
                     {
                         Mtab_x12_837_services_oid = a.MtabX12837ServicesOid,
                         ClaimProfessionalId = Convert.ToInt32(a.ClaimProfessionalId),
                         L2400_lx01_assigned_num = Convert.ToInt32(a.L2400Lx01AssignedNum),
                         L2400_sv101_proc_code = a.L2400Sv101ProcCode,
                         L2400_sv101_proc_mod1 = a.L2400Sv101ProcMod1,
                         L2400_sv101_proc_mod2 = a.L2400Sv101ProcMod2,
                         L2400_sv101_proc_mod3 = a.L2400Sv101ProcMod3,
                         L2400_sv101_proc_mod4 = a.L2400Sv101ProcMod4,
                         L2400_sv102_line_charge = Convert.ToDecimal(a.L2400Sv102LineCharge),
                         L2400_sv104_service_unit_count = a.L2400Sv104ServiceUnitCount,
                         L2400_sv105_place_of_service = a.L2400Sv105PlaceOfService,
                         L2400_sv107_dx_pointer1 = a.L2400Sv107DxPointer1,
                         L2400_sv107_dx_pointer2 = a.L2400Sv107DxPointer2,
                         L2400_sv107_dx_pointer3 = a.L2400Sv107DxPointer3,
                         L2400_sv107_dx_pointer4 = a.L2400Sv107DxPointer4,
                         L2400_dtp02_472_from_service_date = a.L2400Dtp02472FromServiceDate,
                         L2400_dtp02_472_to_service_date = a.L2400Dtp02472ToServiceDate,
                         L2410_1_lin03_N4_ndc = a.L24101Lin03N4Ndc,
                         L2400_sv109_emergency_indicator = a.L2400Sv109EmergencyIndicator == "Y" ? true : false,
                         L2400_sv111_epsdt_indicator = a.L2400Sv111EpsdtIndicator == "Y" ? true : false,
                         L2400_sv112_family_plan_indicator = a.L2400Sv112FamilyPlanIndicator == "Y" ? true : false,
                         L2420A_nm109_rendering_prov_id = a.L2420aNm109RenderingProvId,
                         L2420A_nm103_rendering_prov_last_nm = a.L2420aNm103RenderingProvLastNm + ", " + a.L2420aNm104RenderingProvFirstNm
                     })
                  ;
            //if (Claimid != 0)
            //{
            //    q = q.Where(b => b.ClaimProfessionalId == Claimid);
            //}
            if (ServiceId != 0)
            {
                q = q.Where(b => b.Mtab_x12_837_services_oid == ServiceId);
            }
            return q;
        }
        public bool DeleteClaimByFileID(List<int> Files, string strUserName, DateTime date)
        {
            try
            {
                _context.X12Document.Where(e => Files.Contains(e.X12DocumentId)).ToList()
                   .ForEach(a =>
                   {
                       a.RecordStatus = (int)RecordStatus.Deleted;
                       a.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                       a.UpdatedBy = strUserName;
                       a.UpdatedDate = date;
                   });

                _context.ClaimProfessional.Where(e => Files.Contains(e.X12DocumentId.Value)).ToList()
               .ForEach(a =>
                     {
                         a.RecordStatus = (int)RecordStatus.Deleted;
                         a.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                         a.UpdatedBy = strUserName;
                         a.UpdatedDate = date;
                     }
                     );

                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        public vwCMS1500 GetCMS1500Data(int ClaimId)
        {
            vwCMS1500 objvwCMS1500 = new vwCMS1500();
            try
            {
                //var parax12InterchangeId = new List<SqlParameter>
                //{ new SqlParameter("@" + EDI837PStructure.ClaimOid, ClaimId) };
                var parax12InterchangeId = new SqlParameter("@" + EDI837PStructure.ClaimOid, ClaimId);

                _context.Database.GetDbConnection().Open();
                var cmd = _context.Database.GetDbConnection().CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = EDI837PStructure.uspGetCMS1500ByClaimID;
                cmd.Parameters.Add(parax12InterchangeId);

                var reader = cmd.ExecuteReader();

                objvwCMS1500 = reader.MapToList<vwCMS1500>().ToList().FirstOrDefault();

                reader.NextResult();
                objvwCMS1500.ServiceLine =
                    reader.MapToList<ServiceLinelist>().ToList();

                return objvwCMS1500;
                //var parax12InterchangeId = new List<SqlParameter> { new SqlParameter("@" + EDI837PStructure.ClaimOid, ClaimId) };

                // var o =   _context.ExecuteStoreProcedure<vwCMS1500>
                //    (EDI837PStructure.uspGetCMS1500ByClaimID, parax12InterchangeId.ToArray());
                //  return o.FirstOrDefault();

            }
            catch (Exception)
            {

                throw;
            }
        }


        public List<ClaimProfessional> GetPendingProfessionalClaim(int NumberOfclaim)
        {
            var PendingClaim = (from clm in _context.ClaimProfessional.Include(c => c.ClaimProfessionalServices)
                                where clm.ClaimStatus == 0 && clm.RecordStatus == (int)RecordStatus.Active
                                select clm).Take(NumberOfclaim).ToList();

            PendingClaim.ForEach(clm => { clm.ClaimStatus = 201; });

            _context.SaveChanges();

            return PendingClaim;
        }

        //public EdiMemberMatched GetMemberId(EdiMemberLookupSearch EdiMemberLookupSearchPara)
        //{
        //    EdiMemberMatched Member = new EdiMemberMatched();

        //    var paraMemberEligibility = new List<SqlParameter>() {
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_NM109_SUBSCRIBER_ID,EdiMemberLookupSearchPara.MemberID ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_REF02_SY_SUBSCRIBER_SUP_ID,EdiMemberLookupSearchPara.SSN ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_NM103_SUBSCRIBER_LAST_NM,EdiMemberLookupSearchPara.LastName ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_NM104_SUBSCRIBER_FIRST_NM,EdiMemberLookupSearchPara.FirstName ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_NM105_SUBSCRIBER_MIDDLE_NM,EdiMemberLookupSearchPara.MiddleName ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_DMG02_SUBSCRIBER_DOB,EdiMemberLookupSearchPara.Dob ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010BA_DMG03_SUBSCRIBER_GENDER,EdiMemberLookupSearchPara.Gender ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.EFFECTIVEDATE,EdiMemberLookupSearchPara.EffectiveDate ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.TERMDATE,EdiMemberLookupSearchPara.TermDate ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.MemberId,SqlDbType.Int) {Direction = ParameterDirection.Output},
        //        new SqlParameter("@"+ EDI837PStructure.MemberEligibilityID,SqlDbType.Int) {Direction = ParameterDirection.Output}
        //    };

        //    _hpscontext.Database.ExecuteSqlRaw(EDI837PStructure.usp_GetMemberId, paraMemberEligibility);
        //    if (paraMemberEligibility.Where(p => p.ParameterName == "@" + EDI837PStructure.MemberId).FirstOrDefault().Value != DBNull.Value)
        //        Member.MemberId = Convert.ToInt32(paraMemberEligibility.Where(p => p.ParameterName == "@" + EDI837PStructure.MemberId).FirstOrDefault().Value);

        //    if (paraMemberEligibility.Where(p => p.ParameterName == "@" + EDI837PStructure.MemberEligibilityID).FirstOrDefault().Value != DBNull.Value)
        //        Member.MemberEligibilityID = Convert.ToInt32(paraMemberEligibility.Where(p => p.ParameterName == "@" + EDI837PStructure.MemberEligibilityID).FirstOrDefault().Value);

        //    return Member;
        //}


        //public int GetProviderID(EdiProviderLookupSearch EdiProviderLookupSearchPara)
        //{
        //    int ProviderId = 0;
        //    object[] paraGetProvider = {
        //        new SqlParameter("@"+ EDI837PStructure.L2010AA_nm109_billing_prov_id, EdiProviderLookupSearchPara.NPI ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010AA_ref02_EI_billing_prov_id, EdiProviderLookupSearchPara.TaxId ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010AA_ref02_SY_billing_prov_id, EdiProviderLookupSearchPara.SSN ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010AA_nm103_billing_prov_last_nm, EdiProviderLookupSearchPara.LastName ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.L2010AA_nm104_billing_prov_first_nm, EdiProviderLookupSearchPara.FirstName ?? (object)DBNull.Value),
        //        new SqlParameter("@"+ EDI837PStructure.ProviderId,SqlDbType.Int) {Direction = ParameterDirection.Output}
        //    };

        //    _hpscontext.Database.ExecuteSqlRaw(EDI837PStructure.usp_GetProviderId, paraGetProvider);

        //    if (((SqlParameter)paraGetProvider[5]).Value != DBNull.Value)
        //        ProviderId = Convert.ToInt32(((SqlParameter)paraGetProvider[5]).Value);

        //    return ProviderId;
        //}

        public IQueryable<EncounterFileList> GetEncounterFileList()
        {
            var Filetypes = new List<string>() { "837PO", "837IO" };
            return (from Doc in _context.X12Document
                    join TP in _context.VWTradingPartnerSummaries on Doc.DataFileConfigurationID equals TP.DataFileConfigurationID
                    join CLM in ((from c in _context.ClaimProfessionalOutbound
                                  where c.RecordStatus == (int)RecordStatus.Active
                                  group c by c.X12_document_oid into Cgroup
                                  select new
                                  {
                                      X12_document_oid = Cgroup.Key,
                                      Total = Cgroup.Count()
                                  }).Union
                                 (
                                from c in _context.ClaimInstitutionalOutbound
                                where c.RecordStatus == (int)RecordStatus.Active
                                group c by c.X12_document_oid into Cgroup
                                select new
                                {
                                    X12_document_oid = Cgroup.Key,
                                    Total = Cgroup.Count()
                                }
                                )) on Doc.X12DocumentId equals CLM.X12_document_oid into CLMP
                    from CLM in CLMP.DefaultIfEmpty()
                    where Filetypes.Contains(Doc.Filetype) && Doc.RecordStatus == (int)RecordStatus.Active
                    select new EncounterFileList
                    {
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        FileID = Doc.X12DocumentId,
                        FileName = Doc.Filename,
                        FileStatus = Doc.FileStatus,
                        Total = CLM == null ? 0 : CLM.Total,
                        TradingPartnerID = TP.trading_partner_name,
                        Virsion = TP.isa15_usage_indicator + "-" + TP.Module_Name + " (" + TP.VersionIdentifierCode + ")"
                    });
        }
        public IQueryable<EDIEncounterListModel> GetEncounterClaimList()
        {
            return (from Clm in _context.vwProfessionalClaimOutboundSummary
                    where Clm.Filetype == "837PO"
                    select new EDIEncounterListModel
                    {
                        ClaimID = Clm.ClaimID,
                        FileID = Clm.FileID,
                        TradingPartnerID = Clm.TradingPartnerID,
                        ClaimNo = Clm.PatientControlNumber,
                        MemberID = Clm.MemberID,
                        DOB = Clm.DOB,
                        Name = Clm.Name,
                        Billed = Clm.Billed,
                        ClaimStatus = Clm.ClaimStatus,
                        PatientControlNumber = Clm.PatientControlNumber,
                        RenderingProvider = Clm.RenderingProvider,
                        UploadedDate = Clm.UploadedDate,
                        ClaimErrorCount = Clm.ClaimErrorCount,
                        ClaimErrorMsg = Clm.ClaimErrorMsg
                    });
        }
        #endregion
    }
}
