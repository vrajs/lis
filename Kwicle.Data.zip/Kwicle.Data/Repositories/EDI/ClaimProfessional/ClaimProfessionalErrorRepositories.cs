﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class ClaimProfessionalErrorRepositories : IClaimProfessionalErrorRepositories
    {
        private readonly DataImportContext _context;
        public ClaimProfessionalErrorRepositories(DataImportContext context)
        {
            _context = context;
        }
        
        public void Add(ClaimProfessionalError ClaimError)
        {
            _context.ClaimProfessionalError.Add(ClaimError);
            _context.SaveChanges();
        }

        public void Add(XElement xmlElements)
        {
            object[] paraMemberEligibility = { new SqlParameter("@ClaimErrorxml", xmlElements.ToString()) };

            _context.Database.ExecuteSqlRaw("edi.usp_InsertClaimProfessionalError @ClaimErrorxml", paraMemberEligibility);
        }

        public void ErrorFixed(ClaimProfessionalError ClaimError)
        {
            var Error = _context.ClaimProfessionalError.Where(clm => clm.ClaimProfessionalErrorId == ClaimError.ClaimProfessionalErrorId && clm.RecordStatus == (int)RecordStatus.Active).ToList();
            Error.ForEach(err =>
            {
                err.ErrorFixedBy = ClaimError.ErrorFixedBy;
                err.ErrorFixedDate = ClaimError.ErrorFixedDate;
                err.RecordStatus = (int)RecordStatus.InActive;
            });
            _context.SaveChanges();
        }

        
    }
}
