﻿using Kwicle.Core.Common;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.EDI
{
    public class EDI837PEncounterRepositories : IEDI837PEncounterRepositories
    {
        private readonly DataImportContext _context;
        public EDI837PEncounterRepositories(DataImportContext context)
        {
            _context = context;
        }

        public void UpdateEncounter(int X12_document_oid, string UserName, DateTime UpdateDate)
        {
            var Encounters = _context.ClaimProfessionalOutbound.Where(CLM => CLM.X12_document_oid == X12_document_oid);

            foreach (var Encounter in Encounters)
            {
                Encounter.RecordStatus = (int)RecordStatus.Deleted;
                Encounter.UpdatedBy = UserName;
                Encounter.UpdatedDate = UpdateDate;
            }

            _context.SaveChanges();
        }
    }
}
