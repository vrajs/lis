﻿using Kwicle.Common.Utility;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;

namespace Kwicle.Data.Repositories.EDI
{
    public class X12_Level1AckRepositories : Disposable, IX12_Level1AckRepositories
    {
        private readonly DataImportContext _context;
        public X12_Level1AckRepositories(DataImportContext context)
        {
            _context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_Level1Acknoledgement"></param>
        public void Add(X12Level1Ack x12_Level1Acknoledgement)
        {

            _context.X12Level1Ack.Add(x12_Level1Acknoledgement);
            _context.SaveChanges();
        }
    }
}
