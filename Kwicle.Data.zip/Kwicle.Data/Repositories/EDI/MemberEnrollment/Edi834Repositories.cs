﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Data.Extensions.BulkExtensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi834Repositories : Disposable, IEdi834Repositories
    {
        private readonly DataImportContext _context;
        private readonly KwicleViewContext _kwicleView;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public Edi834Repositories(DataImportContext context, KwicleViewContext kwicleView)
        {
            _context = context;
            _kwicleView = kwicleView;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<EDI834FileModel> EDI834Files()
        {
            return (from Doc in _context.Vw834FileSummary
                    where Doc.RecordStatus == (int)RecordStatus.Active
                    select new EDI834FileModel
                    {
                        FileID = Doc.FileID,
                        FileName = Doc.FileName,
                        TradingPartnerID = Doc.TradingPartnerID,
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        FileStatus = Doc.FileStatus,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        Total = Doc.Total,
                        FileMonth = Doc.FileMonth,
                        PayerName = Doc.PayerName,
                        Version = Doc.Version,
                        Failed = Doc.Failed
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<Edi834MemberSummaryModel> Edi834MemberDetail()
        {
            return (from M in _context.Vw834MemberSummary
                    select new Edi834MemberSummaryModel
                    {
                        MemberBenefitEnrollmentId = M.MemberBenefitEnrollmentId,
                        FileID = M.x12_document_id,
                        SponsorName = M.SponsorName,
                        PayerName = M.PayerName,
                        MemberName = M.MemberName,
                        MemberAddress = M.MemberAddress,
                        MemberID = M.MemberID,
                        PlanCode = M.PlanCode,
                        EffectiveDate = M.EffectiveDate,
                        TermDate = M.TermDate,
                        PCPName = M.PCPName,
                        CreatedDate = M.CreatedDate,
                        DOB = M.DOB,
                        Gender = M.Gender,
                        MemberRelationship = M.MemberRelationship,
                        Error = M.Error
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="X12DocumentID"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public Edi834EnrollmentFileGenerateEntity GetEdi834Details(int X12DocumentID, CurrentTradingPartner currentTradingPartner)
        {
            return new Edi834EnrollmentFileGenerateEntity
            {
                mvw_Mtab_x12_TradingPartner_summary = currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_834),
                MemberBenefitEnrollment = _context.VwMemberEnrollmentOutbound.Where(x => x.x12_document_id == X12DocumentID && x.RecordStatus == (int)RecordStatus.Active && x.error == false).ToList(),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_834_5010 && loop.RecordStatus == (int)RecordStatus.Active).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_834_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                           .OrderBy(segment => segment.LoopGroup)
                                                           .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_834_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(element => element.LoopGroup)
                                                          .ThenBy(element => element.SegmentSequence)
                                                          .ThenBy(element => element.SegmentoccurrenceSeq)
                                                          .ThenBy(element => element.ElementPosition)
                                                          .ThenBy(element => element.SubElementPosition).ToList(),
                OutboundMappingconfiguration = _context.GetOutboundMappingConfiguration.Where(e => e.DataFileConfigurationID == currentTradingPartner.CurTradingPartner.DataFileConfigurationID && e.Edi_Format == EdiFormat.EDI_834_5010).ToList()
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_document_id"></param>
        /// <param name="MemberBenefitEnrollmentList"></param>
        public void ImportMemberDetail(int x12_document_id, List<MemberBenefitEnrollment> MemberBenefitEnrollmentList)
        {
            MemberBenefitEnrollmentList.ForEach(e =>
            {
                e.x12_document_id = x12_document_id;
                e.CreatedDate = DateTime.Now;
            });

            _context.BulkInsertMember(MemberBenefitEnrollmentList);
            //using (var transaction = _context.Database.BeginTransaction())
            //{
            //    BulkInsert(MemberBenefitEnrollmentList);
            //    //_context.BulkInsertMember(
            //    //    MemberBenefitEnrollmentList
            //    //);
            //}
            ValidateImportedData(x12_document_id);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_document_id"></param>
        private void ValidateImportedData(int x12_document_id)
        {
            var parax12InterchangeId = new List<SqlParameter>
                {
                    new SqlParameter("@" + Edi834MemberEnrollment.X12_DOCUMENT_ID, x12_document_id)
                };
            _context.Database.ExecuteSqlRaw(Edi834MemberEnrollment.USPMEMBERBENEFITENROLLMENTIMPORT, parax12InterchangeId.ToArray());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_document_id"></param>
        public void Delete(List<int> x12_document_ids)
        {
            var Files = _context.X12Document.Where(e => x12_document_ids.Contains(e.X12DocumentId)).ToList();

            Files.ForEach(e =>
            {
                e.RecordStatus = (int)RecordStatus.Deleted;
                e.UpdatedDate = DateTime.Now;
            });

            var EnrollmentHeader = _context.MemberBenefitEnrollments.Where(x => x12_document_ids.Contains(x.x12_document_id)).ToList();

            EnrollmentHeader.ForEach(e =>
            {
                e.RecordStatus = (int)RecordStatus.Deleted;
                e.UpdatedDate = DateTime.Now;
            });
            _context.SaveChanges();
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="MemberEnrollmentID"></param>
        /// <returns></returns>
        public List<KeyValuePair<string, string>> GetMemberEnrollmentErrors(int MemberEnrollmentID)
        {
            var objerrorlist = (from c in _context.MemberBenefitEnrollmentErrors
                                join m in _context.MtabMError on c.ErrorID equals m.ErrorId
                                where c.MemberBenefitEnrollmentId == MemberEnrollmentID && c.RecordStatus == (int)RecordStatus.Active
                                select new KeyValuePair<string, string>(m.ErrorCode, m.ErrorDesc)
                                ).ToList();
            return objerrorlist;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_interchange_id"></param>
        public void ClaimTrnasfer(int x12_interchange_id)
        {
            var parax12InterchangeId = new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12_interchange_id);
            _context.Database.ExecuteSqlRaw(Edi834MemberEnrollment.uspMup834Transfer, parax12InterchangeId);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="List"></param>
        private void BulkInsert<T>(IList<T> List) where T : class
        {
            _context.BulkInsert(List,
                new BulkConfig
                {
                    PreserveInsertOrder = true,
                    SetOutputIdentity = true,
                    BatchSize = 4000,
                    UseTempDB = true
                });            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objEntity"></param>
        /// <returns></returns>
        public int SaveX12BenefitEnrollment(X12834BenefitEnrollmentHeader objEntity)
        {

            List<X12834BenefitEnrollmentHeader> X12834BenefitEnrollmentHeaders = new List<X12834BenefitEnrollmentHeader>
            {
                objEntity
            };

            using (var transaction = _context.Database.BeginTransaction())
            {
                BulkInsert(X12834BenefitEnrollmentHeaders);

                var X12834BenefitEnrollments = new List<X12834BenefitEnrollment>();

                X12834BenefitEnrollmentHeaders.ForEach(e =>
                {
                    X12834BenefitEnrollments.AddRange(e.X12834BenefitEnrollment.Select(c => { c.X12834BenefitEnrollmentHeaderid = e.X12834BenefitEnrollmentHeaderid; return c; }));
                });

                BulkInsert(X12834BenefitEnrollments);

                //Coverage start      
                var X12834BenefitEnrollmentCoverages = new List<X12834BenefitEnrollmentCoverage>();

                X12834BenefitEnrollments.ForEach(e =>
                {
                    X12834BenefitEnrollmentCoverages.AddRange(e.X12834BenefitEnrollmentCoverage.Select(c => { c.X12834BenefitEnrollmentId = e.X12834BenefitEnrollmentId; return c; }));
                });

                BulkInsert(X12834BenefitEnrollmentCoverages);
                //Coverage end

                // Provider Start
                var Provides = new List<X12834BenefitEnrollmentProvider>();
                X12834BenefitEnrollmentCoverages.ForEach(e =>
                {
                    Provides.AddRange(e.X12834BenefitEnrollmentProvider.Select(c => { c.X12834BenefitEnrollmentCoverageId = e.X12834BenefitEnrollmentCoverageId; return c; }));
                });

                BulkInsert(Provides);
                // Provider En

                //Co-ordination Benefit start
                var X12834BenefitEnrollmentCobs = new List<X12834BenefitEnrollmentCob>();

                X12834BenefitEnrollmentCoverages.ForEach(e =>
                {
                    X12834BenefitEnrollmentCobs.AddRange(e.X12834BenefitEnrollmentCob.Select(c => { c.X12834BenefitEnrollmentCoverageId = e.X12834BenefitEnrollmentCoverageId; return c; }));
                });

                BulkInsert(X12834BenefitEnrollmentCobs);
                //Co-ordination Benefit end
                transaction.Commit();

            }
            return objEntity.X12834BenefitEnrollmentHeaderid;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<Edi834InboundMemberFileSummaryModel> Edi834ImportMemberDetail()
        {
            return (from Doc in _context.Vw834InboundFileSummary
                    where Doc.RecordStatus == (int)RecordStatus.Active
                    select new Edi834InboundMemberFileSummaryModel
                    {
                        FileID = Doc.FileID,
                        FileName = Doc.FileName,
                        TradingPartnerID = Doc.TradingPartnerID,
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        FileStatus = Doc.FileStatus,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        Total = Doc.Total,
                        Version = Doc.Version,
                        PayerName = Doc.PayerName,
                        Failed = Doc.Failed
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<Edi834MemberInboundSummaryModel> EDI834MemberListMemberSummary()
        {
            return (from M in _context.Vw834MemberInboundSummary
                    select new Edi834MemberInboundSummaryModel
                    {
                        MemberBenefitEnrollmentId = M.MemberBenefitEnrollmentId,
                        FileID = M.x12_document_id,
                        MemberName = M.MemberName,
                        MemberAddress = M.MemberAddress,
                        MemberCity = M.MemberCity,
                        MemberState = M.MemberState,
                        MemberZip = M.MemberZip,
                        MemberID = M.MemberID,
                        PlanCode = M.PlanCode,
                        EffectiveDate = M.EffectiveDate,
                        TermDate = M.TermDate,
                        PCPName = M.PCPName,
                        CreatedDate = M.CreatedDate,
                        DOB = M.DOB,
                        Gender = M.Gender,
                        MemberRelationship = M.MemberRelationship,
                        Error = M.Error
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_document_id"></param>
        public void DeleteMemeberInbound(List<int> x12_document_ids)
        {
            var Files = _context.X12Document.Where(e => x12_document_ids.Contains(e.X12DocumentId)).ToList();

            Files.ForEach(e =>
            {
                e.RecordStatus = (int)RecordStatus.Deleted;
                e.UpdatedDate = DateTime.Now;
            });

            var EnrollmentHeader = _context.X12834BenefitEnrollmentHeader.Where(x => x12_document_ids.Contains(x.X12DocumentId.Value)).ToList();

            EnrollmentHeader.ForEach(e =>
            {
                e.RecordStatus = (int)RecordStatus.Deleted;
                e.UpdatedDate = DateTime.Now;
            });                                    
            _context.SaveChanges();
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwMemberEnrollmentProvider> GetMemberEnrollmentProvider()
        {
            return _context.VwMemberEnrollmentProvider;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwMemberEnrollmentCOB> GetMemberEnrollmentCOB()
        {
            return _context.vwMemberEnrollmentCOB;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwMemberEnrollmentCoverage> GetMemberEnrollmentCoverage()
        {
            return _context.GetMemberEnrollmentCoverage;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwMemberEnrollment> GetMemberEnrollment()
        {
            return _context.GetMemberEnrollment;
        }
    }
}