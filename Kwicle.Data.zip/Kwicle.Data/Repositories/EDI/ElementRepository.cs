﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Repositories.EDI
{
    public class ElementRepository: BaseRepository<Element>, IElementRepository
    {
        private readonly DataImportContext _DataImportcontext;
        public ElementRepository(DataImportContext DataImportcontext) : base(DataImportcontext)
        {
            _DataImportcontext = DataImportcontext;
        }        
    }
}
