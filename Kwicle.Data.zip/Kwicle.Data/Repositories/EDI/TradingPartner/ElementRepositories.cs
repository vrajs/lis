﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Repositories.EDI
{
    public class ElementRepositories : BaseRepository<Element>, IElementRepositories
    {
        private readonly DataImportContext _DataImportcontext;
        public ElementRepositories(DataImportContext DataImportcontext) : base(DataImportcontext)
        {
            _DataImportcontext = DataImportcontext;
        }
    }
}
