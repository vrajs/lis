﻿using Kwicle.Common.Utility;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Repositories.EDI
{
    public class PlanBenefitConfigurationRepositories : Disposable, IPlanBenefitConfigurationRepositories
    {
        private readonly DataImportContext _context;
        public PlanBenefitConfigurationRepositories()
        {

        }


    }
}
