﻿using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using static Kwicle.Core.Common.EDI.EDICommon;

namespace Kwicle.Data.Repositories.EDI
{
    public class EdiTpRepositories : BaseRepository<TradingPartner>, IEdiTpRepositories
    {
        private readonly DataImportContext _context;
        
        public EdiTpRepositories(DataImportContext context) : base(context)
        {
            _context = context;                        
        }

        public List<KeyValuePair<short, string>> GetddlTradingPartnerList(string TranType, string FileType)
        {
            List<KeyValuePair<short, string>> Items = new List<KeyValuePair<short, string>>();
            
            Items = (from t in _context.TradingPartner
                     join d in _context.DataFileConfiguration on t.TradingPartnerId equals d.TradingPartnerId
                     where t.RecordStatus == (byte)RecordStatus.Active && d.RecordStatus == (byte)RecordStatus.Active &&
                     d.FileTypeId == (int)(EdiCommonCode)Enum.Parse(typeof(EdiCommonCode), FileType) &&
                     d.TranTypeId == (int)(EdiCommonCode)Enum.Parse(typeof(EdiCommonCode), TranType)
                     select new KeyValuePair<short, string>(d.DataFileConfigurationId, t.TradingPartnerName)
                    ).ToList();
            return Items;
        }        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual IQueryable<vwTradingPartnerSummary> GetTradingPartnerDetails()
        {
            return _context.VWTradingPartnerSummaries;            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="location"></param>
        public virtual int AddLocation(MtabMLocation location)
        {
            _context.MtabMLocation.Add(location);
            _context.SaveChanges();
            return location.LocationId;
        }

        #region UI
        public DataSourceResult GetTradingPartnerDetail(GridOption_View objGridOption_View)
        {
            //string Module_Name = ObjView.Requestparam.Single(a => a.Name == EDI837PStructure.X12_DOCUMENT_ID).Value;

            var parameters = new List<SqlParameter>
            {
                    //new SqlParameter("@" + EDITradingPartnerStructure.MODULE_NAME,"270"),                    
                    new SqlParameter("@" + EDI837PStructure.OrderByColumn, (object)objGridOption_View.OrderByColumn ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.OrderByDirection, (object)objGridOption_View.OrderByDirection ?? DBNull.Value),
                    new SqlParameter("@" + EDI837PStructure.Skip,objGridOption_View.Skip) ,
                    new SqlParameter("@" + EDI837PStructure.Take, objGridOption_View.Take),
                    new SqlParameter("@" + EDI837PStructure.totalItems,System.Data.SqlDbType.Int){ Direction = ParameterDirection.Output}
            };

            if (objGridOption_View.Filter != null)
            {
                foreach (var item in objGridOption_View.Filter)
                {
                    parameters.Add(new SqlParameter("@" + item.Name, (object)item.Value ?? DBNull.Value));
                }
            }

            string parameterName = string.Join(",", parameters.Select(o => o.Direction == ParameterDirection.Output ? o.ParameterName + " " + ParameterDirection.Output : o.ParameterName).ToArray()).ToString();

            var data = _context.ExecuteStoreProcedure<TradingPraterView>(EDITradingPartnerStructure.USP_GETTRADINGPARTNERDETAIL + parameterName, parameters.ToArray()).ToList();
            int count = Convert.ToInt32(parameters.Single(p => p.ParameterName == "@" + EDI837PStructure.totalItems).Value);
            return new DataSourceResult
            {
                Data = data,
                totalItems = count
            };

        }
        public IEnumerable<string> GetModuleNames()
        {
            return GetTradingPartnerDetails().Where(M => !string.IsNullOrEmpty(M.isa06_sender_id_live)).Select(M => M.Module_Name).Distinct();
        }
        #endregion

        #region HPS        
        public IQueryable<TradingPartner> GetTradingPartnerList()
        {            
            return (from a in _context.TradingPartner where a.RecordStatus == (int)RecordStatus.Active select a); 
        }
        public IQueryable<DataConfigurationModel> GetDataConfigByTId(short TradingPartnerId)
        {
            IQueryable<DataConfigurationModel> query = null;
            query = from t in _context.DataFileConfiguration
                    where t.TradingPartnerId == TradingPartnerId && t.RecordStatus == (int)RecordStatus.Active

                    select new DataConfigurationModel()
                    {
                        DataFileConfigurationID = t.DataFileConfigurationId,
                        FileNamingConventionID = t.FileNamingConventionId,
                        EffectiveDate = t.EffectiveDate,
                        FileTypeId = t.FileTypeId,
                        IsStandardFile = t.IsStandardFile,
                        TranTypeId = t.TranTypeId,
                        TermDate = t.TermDate.Value,
                        Isa06SenderId = t.Isa06SenderId,
                        Isa08ReceiverId = t.Isa08ReceiverId,
                        TradingPartnerId = t.TradingPartnerId,
                        Isa15UsageIndicator = t.Isa15UsageIndicator,
                        VersionIdentifierCode = t.VersionIdentifierCode
                    };
            return query;
        }

        public short SaveTradingPartnerDetail(TradingPartner objTradingPartner)
        {
            _context.TradingPartner.Add(objTradingPartner);
            _context.SaveChanges();
            return objTradingPartner.TradingPartnerId;
        }
        public void UpdateTradingPartnerDetail()
        {
            _context.SaveChanges();
        }
        public TradingPartner GetTradingPartnerByTId(short TradingPartnerId)
        {
            return _context.TradingPartner.Where(x => x.TradingPartnerId == TradingPartnerId).SingleOrDefault();
        }
        public DataFileConfiguration GetDataFileConfigurationById(short DataFileConfigurationId)
        {
            return _context.DataFileConfiguration.Where(x => x.DataFileConfigurationId == DataFileConfigurationId).SingleOrDefault();
        }
        public bool CheckDuplicateDataConfig(DataConfigurationModel DataConfiguration)
        {
            bool isExists = false;
            var DataConfigurationExists = _context.DataFileConfiguration.Where(b => b.TradingPartnerId == DataConfiguration.TradingPartnerId
                                && b.DataFileConfigurationId != DataConfiguration.DataFileConfigurationID 
                                && b.TranTypeId == DataConfiguration.TranTypeId && b.FileTypeId == DataConfiguration.FileTypeId
                                && b.RecordStatus == (int)RecordStatus.Active).FirstOrDefault();
            if (DataConfigurationExists != null) { isExists = true; }
            return isExists;
        }

        public async Task<short> SaveDataConfigurationDetail(DataFileConfiguration obj)
        {

            _context.DataFileConfiguration.Add(obj);
            await _context.SaveChangesAsync();
            return obj.DataFileConfigurationId;
        }
        public void UpdateConfigurationDetail(DataFileConfiguration obj)
        {
            _context.Update(obj);
            _context.SaveChanges();
        }
        public int GetDataFileConfigurationID(int TradingPartnerID,int TranTypeId, int FileTypeID) {
            return _context.DataFileConfiguration.Where(o => o.TradingPartnerId == TradingPartnerID &&
                                                o.TranTypeId == TranTypeId && o.FileTypeId == FileTypeID)
                                                .Select(x => x.DataFileConfigurationId).FirstOrDefault();
        }

        public short SaveFileNamingConventionDetail(FileNamingConvention obj, short DataFileConfigurationId)
        {
            _context.FileNamingConvention.Add(obj);
            _context.SaveChanges();
            var objdata = _context.DataFileConfiguration.Where(a => a.DataFileConfigurationId == DataFileConfigurationId).FirstOrDefault();
            objdata.FileNamingConventionId = obj.FileNamingConventionID;
            _context.SaveChanges();
            return obj.FileNamingConventionID;
        }
        public void UpdateContext()
        {
            _context.SaveChanges();
        }
        public FileNamingConvention GetFileNamingConventionById(short FileNamingConventionID)
        {
            return _context.FileNamingConvention
                   .Include(c => c.FileNamingSequence)
                   .Where(x => x.FileNamingConventionID == FileNamingConventionID)
                   .FirstOrDefault();
        }

        public void UpdateFileNamingConvention(FileNamingConvention obj)
        {
            _context.Update(obj);
            _context.SaveChanges();
        }
        public void DeleteFileNamingConvention(short DataFileConfigurationId, FileNamingConvention obj)
        {
            var objdata = _context.DataFileConfiguration.Where(a => a.DataFileConfigurationId == DataFileConfigurationId).FirstOrDefault();
            objdata.FileNamingConventionId = null;
            _context.SaveChanges();
            _context.Remove(obj);
            _context.SaveChanges();
        }


        public List<FileNamingSequence> GetlistFileNamingSequenceId(short FileNamingConventionID)
        {
            return _context.FileNamingSequence                  
                   .Where(x => x.FileNamingConventionId == FileNamingConventionID)
                   .ToList();
        }
        #endregion
    }
}
