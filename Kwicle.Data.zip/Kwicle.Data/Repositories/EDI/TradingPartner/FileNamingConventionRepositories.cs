﻿using Kwicle.Common.Utility;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class FileNamingConventionRepositories : Disposable, IFileNamingConventionRepositories
    {
        private readonly DataImportContext _context;

        public FileNamingConventionRepositories(DataImportContext context)
        {
            _context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<FileNamingConvention> GetDetails()
        {
            return new List<FileNamingConvention>(); // _context.FileNamingConvention;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileNameId"></param>
        /// <returns></returns>
        public FileNamingConvention GetDetails(short? fileNameId)
        {
            var fileNamingConvention = _context.FileNamingConvention.FirstOrDefault(fileName => fileName.FileNamingConventionID == fileNameId);
            if (fileNamingConvention != null && fileNamingConvention.FileNamingSequence.Count > 0)
            {
                fileNamingConvention.FileNamingSequence =
                    _context.FileNamingSequence.Where(
                        file => file.FileNamingConventionId == fileNamingConvention.FileNamingConventionID).ToList();
            }
            return fileNamingConvention;            
        }
    }
}
