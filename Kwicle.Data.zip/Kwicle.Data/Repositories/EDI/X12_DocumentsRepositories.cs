﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class X12DocumentsRepositories : Disposable, IX12DocumentsRepositories
    {
        private readonly DataImportContext _context;
        public X12DocumentsRepositories(DataImportContext context)
        {
            _context = context;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="x12Document"></param>
        /// <returns></returns>
        public int Add(X12Document x12Document)
        {
            _context.X12Document.Add(x12Document);
            _context.SaveChanges();

            return x12Document.X12DocumentId;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public X12Document Get(int ID)
        {
            return _context.X12Document.Where(Doc => Doc.X12DocumentId == ID).SingleOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12DocumentUid"></param>
        /// <param name="fileName"></param>
        /// <param name="fileType"></param>
        public void UpdateDocument(int x12Documentid, X12Document Document)
        {
            var x12Document =
                _context.X12Document.FirstOrDefault(doc => doc.X12DocumentId == x12Documentid);
            if (x12Document != null)
            {
                x12Document.Filename = string.IsNullOrEmpty(Document.Filename) ? x12Document.Filename : Document.Filename;
                x12Document.Filetype = string.IsNullOrEmpty(Document.Filetype) ? x12Document.Filetype : Document.Filetype;
                x12Document.FileStatus = Document.FileStatus == 0 ? x12Document.FileStatus : Document.FileStatus;
                x12Document.Filedata = string.IsNullOrEmpty(Document.Filedata) ? x12Document.Filedata : Document.Filedata;
                x12Document.X12DocumentUid = Document.X12DocumentUid == Guid.Empty ? x12Document.X12DocumentUid : Document.X12DocumentUid;
                x12Document.Error = Document.Error == false ? x12Document.Error : Document.Error;
                x12Document.CreatedBy = string.IsNullOrEmpty(Document.CreatedBy) ? x12Document.CreatedBy : Document.CreatedBy;
                x12Document.RecordStatus = Document.RecordStatus == 0 ? x12Document.RecordStatus : Document.RecordStatus;
                x12Document.RecordStatusChangeComment = string.IsNullOrEmpty(Document.RecordStatusChangeComment) ? x12Document.RecordStatusChangeComment : Document.RecordStatusChangeComment;
            }
            _context.SaveChanges();
        }

        public void UpdateDocument(Guid x12DocumentUid, X12Document Document)
        {
            var x12Document =
                _context.X12Document.FirstOrDefault(doc => doc.X12DocumentUid == x12DocumentUid);
            if (x12Document != null)
            {
                x12Document.Filename = string.IsNullOrEmpty(Document.Filename) ? x12Document.Filename : Document.Filename;
                x12Document.Filetype = string.IsNullOrEmpty(Document.Filetype) ? x12Document.Filetype : Document.Filetype;
                x12Document.FileStatus = Document.FileStatus == 0 ? x12Document.FileStatus : Document.FileStatus;
                x12Document.Filedata = string.IsNullOrEmpty(Document.Filedata) ? x12Document.Filedata : Document.Filedata;
                x12Document.Error = Document.Error == false ? x12Document.Error : Document.Error;
                x12Document.CreatedBy = string.IsNullOrEmpty(Document.CreatedBy) ? x12Document.CreatedBy : Document.CreatedBy;
                x12Document.Isa15UsageIndicator = string.IsNullOrEmpty(Document.Isa15UsageIndicator) ? x12Document.Isa15UsageIndicator : Document.Isa15UsageIndicator;
                x12Document.Gs08VersionIdCode = string.IsNullOrEmpty(Document.Gs08VersionIdCode) ? x12Document.Gs08VersionIdCode : Document.Gs08VersionIdCode;
            }
            _context.SaveChanges();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataFileToProcess"></param>
        public void AddDataFileToProcess(DataFileToProcess dataFileToProcess)
        {
            //_context.DataFileToProcess.Add(dataFileToProcess);
            //_context.SaveChanges();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ediContents"></param>
        /// <returns></returns>
        public Dictionary<string, object> ParseEdiDocument(string ediContents, int tradingpartnerid, int DataFileConfigurationID)
        {
            object[] paraMemberEligibility = {
                new SqlParameter("@"+ x12DocumentCons.X12_DOCUMENT_ID, DBNull.Value),
                new SqlParameter("@"+ x12DocumentCons.X12_CONTENT, ediContents),
                new SqlParameter("@"+ x12DocumentCons.TradingPartnerId, tradingpartnerid),
                new SqlParameter("@"+ x12DocumentCons.DataFileConfigurationID, DataFileConfigurationID),

                new SqlParameter("@"+ x12DocumentCons.X12_PARSE_TEMP_UID, SqlDbType.UniqueIdentifier) {Direction = ParameterDirection.Output},
                new SqlParameter("@"+ x12DocumentCons.ERRCODE, SqlDbType.Int){Direction = ParameterDirection.Output},
                new SqlParameter("@"+ x12DocumentCons.X12_INTERCHANGE_ID,SqlDbType.Int) {Direction = ParameterDirection.Output}
            };

            _context.Database.ExecuteSqlRaw(x12DocumentCons.uspX12DocumentParse, paraMemberEligibility);
            // _context.SaveChanges();

            return new Dictionary<string, object>()
            {
                {x12DocumentCons.X12_INTERCHANGE_ID,((SqlParameter)paraMemberEligibility[6]).Value},
                {x12DocumentCons.X12_PARSE_TEMP_UID,((SqlParameter)paraMemberEligibility[4]).Value}
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="edi271Response"></param>
        /// <param name="clientId"></param>
        /// <param name="companyId"></param>
        /// <returns></returns>
        public Dictionary<string, object> ParseEdiDocument(int? x12_Document_ID, int clientId)
        {
            object[] paraMemberEligibility = {
                new SqlParameter("@"+ x12DocumentCons.X12_DOCUMENT_ID, x12_Document_ID),
                new SqlParameter("@"+ x12DocumentCons.X12_CONTENT, DBNull.Value),
                new SqlParameter("@"+ x12DocumentCons.X12_PARSE_TEMP_UID, SqlDbType.UniqueIdentifier) {Direction = ParameterDirection.Output},
                new SqlParameter("@"+ x12DocumentCons.ERRCODE, SqlDbType.Int){Direction = ParameterDirection.Output},
                new SqlParameter("@"+ x12DocumentCons.X12_INTERCHANGE_ID,SqlDbType.Int) {Direction = ParameterDirection.Output},
                new SqlParameter("@"+ x12DocumentCons.CLIENT_ID, clientId) };
            //new SqlParameter("@"+ x12DocumentCons.COMPANY_ID,companyId)};

            _context.Database.ExecuteSqlRaw(x12DocumentCons.uspX12DocumentParse, paraMemberEligibility);
            _context.SaveChanges();

            return new Dictionary<string, object>()
            {
                {x12DocumentCons.X12_INTERCHANGE_ID,((SqlParameter)paraMemberEligibility[4]).Value},
                {x12DocumentCons.X12_PARSE_TEMP_UID,((SqlParameter)paraMemberEligibility[2]).Value}
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileProcessHistory"></param>
        public void AddFileHistory(FileProcessHistory fileProcessHistory)
        {
            try
            {
                _context.FileProcessHistory.Add(fileProcessHistory);
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
        #region Docuemnt UI
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_Document_ID"></param>
        /// <returns></returns>
        public List<vwX12ParseTemp> GetFileData(int x12_Document_ID)
        {
            return (from t in _context.X12ParseTemp
                    join doc in _context.X12Document on t.X12ParseTempUid equals doc.X12DocumentUid
                    join ISA in _context.X12Interchange on doc.X12DocumentUid equals ISA.X12InterchangeUid
                    where doc.X12DocumentId == x12_Document_ID && t.Col001 != ""
                    select new vwX12ParseTemp
                    {
                        Col001 = t.Col001,
                        Col002 = t.Col002,
                        Col003 = t.Col003,
                        Col004 = t.Col004,
                        Col005 = t.Col005,
                        Col006 = t.Col006,
                        Col007 = t.Col007,
                        Col008 = t.Col008,
                        Col009 = t.Col009,
                        Col010 = t.Col010,
                        Col011 = t.Col011,
                        Col012 = t.Col012,
                        Col013 = t.Col013,
                        Col014 = t.Col014,
                        Col015 = t.Col015,
                        Col016 = t.Col016,
                        Col017 = t.Col017,
                        Col018 = t.Col018,
                        Col019 = t.Col019,
                        Col020 = t.Col020,
                        Col021 = t.Col021,
                        Col022 = t.Col022,
                        Col023 = t.Col023,
                        Col024 = t.Col024,
                        Col025 = t.Col025,
                        element_separator = ISA.ElementSeparator,
                        segment_separator = ISA.SegmentSeparator
                    }).ToList();

            //object[] paraMemberEligibility = {
            //    new SqlParameter("@"+ x12DocumentCons.X12_DOCUMENT_ID, x12_Document_ID)
            //};

            //return _context.ExecuteStoreProcedure<vwX12ParseTemp>(x12DocumentCons.uspViewFileContent, paraMemberEligibility).ToList();
        }

        public int GetDocumentIdByGuid(Guid X12DocumentUid)
        {
            return _context.X12Document.Where(x => x.X12DocumentUid == X12DocumentUid).Select(o => o.X12DocumentId).FirstOrDefault();
        }

        public List<FileExists> IsFileExists(string isa09_interchange_date, string isa10_interchange_time, string isa13_control_no, string gs04_date, string gs05_time, string filetype, int TradingPartnerId, int DataFileConfigurationID)
        {
            try
            {
                var parameters = new SqlParameter[]
            {
                    new SqlParameter("@" + x12_interchangeStructure.ISA09_INTERCHANGE_DATE, isa09_interchange_date),
                    new SqlParameter("@" + x12_interchangeStructure.ISA10_INTERCHANGE_TIME, isa10_interchange_time),
                    new SqlParameter("@" + x12_interchangeStructure.ISA13_CONTROL_NO, isa13_control_no),
                    new SqlParameter("@" + EDI837PStructure.GS04_DATE,gs04_date) ,
                    new SqlParameter("@" + EDI837PStructure.GS05_TIME, gs05_time),
                    new SqlParameter("@" + EDI837PStructure.FILETYPE,filetype),
                    new SqlParameter("@" + EDI837PStructure.TRADINGPARTNERID,TradingPartnerId),
                    new SqlParameter("@" + EDI837PStructure.DATAFILECONFIGURATIONID,DataFileConfigurationID)
             };
                return _context.ExecuteStoreProcedure<FileExists>(EDI837PStructure.uspValidateDuplicateFile, parameters);
            }
            catch
            {
                throw;
            }
        }

        public EDIDocumentParseValidateModel ValidateDocumentAndParse(EDIDocumentParseModel objModel)
        {
            try
            {
                var parameters = new SqlParameter[]
            {
                    new SqlParameter("@" + x12_interchangeStructure.ISA01_AUTH_INFO_QUAL,objModel.isa01_auth_info_qual),
                    new SqlParameter("@" + x12_interchangeStructure.ISA02_AUTH_INFO,objModel.isa02_auth_info),
                    new SqlParameter("@" + x12_interchangeStructure.ISA03_SECURITY_INFO_QUAL,objModel.isa03_security_info_qual),
                    new SqlParameter("@" + x12_interchangeStructure.ISA04_SECURITY_INFO,objModel.isa04_security_info),
                    new SqlParameter("@" + x12_interchangeStructure.ISA05_SENDER_ID_QUAL,objModel.isa05_sender_id_qual),
                    new SqlParameter("@" + x12_interchangeStructure.ISA06_SENDER_ID,objModel.isa06_sender_id),
                    new SqlParameter("@" + x12_interchangeStructure.ISA07_RECEIVER_ID_QUAL,objModel.isa07_receiver_id_qual),
                    new SqlParameter("@" + x12_interchangeStructure.ISA08_RECEIVER_ID,objModel.isa08_receiver_id),
                    new SqlParameter("@" + x12_interchangeStructure.ISA09_INTERCHANGE_DATE,objModel.isa09_interchange_date),
                    new SqlParameter("@" + x12_interchangeStructure.ISA10_INTERCHANGE_TIME,objModel.isa10_interchange_time),
                    new SqlParameter("@" + x12_interchangeStructure.ISA11_CONTROL_STANDARDS_ID,objModel.isa11_control_standards_id),
                    new SqlParameter("@" + x12_interchangeStructure.ISA12_CONTROL_VERSION_NO,objModel.isa12_control_version_no),
                    new SqlParameter("@" + x12_interchangeStructure.ISA13_CONTROL_NO,objModel.isa13_control_no),
                    new SqlParameter("@" + x12_interchangeStructure.ISA14_ACK_REQUESTED,objModel.isa14_ack_requested),
                    new SqlParameter("@" + x12_interchangeStructure.ISA15_USAGE_INDICATOR,objModel.isa15_usage_indicator),
                    new SqlParameter("@" + x12_interchangeStructure.ISA16_COMPONENT_ELEMENT_SEPERATOR,objModel.isa16_component_element_seperator),
                    new SqlParameter("@" + x12_interchangeStructure.GS01_FUNCTIONAL_ID_CODE, objModel.gs01_functional_id_code),
                    new SqlParameter("@" + x12_interchangeStructure.GS02_APP_SENDER_CODE, objModel.gs02_app_sender_code),
                    new SqlParameter("@" + x12_interchangeStructure.GS03_APP_RECEIVER_CODE, objModel.gs03_app_receiver_code),
                    new SqlParameter("@" + x12_interchangeStructure.GS04_DATE, objModel.gs04_date),
                    new SqlParameter("@" + x12_interchangeStructure.GS05_TIME, objModel.gs05_time),
                    new SqlParameter("@" + x12_interchangeStructure.GS06_GROUP_CONTROL_NO, objModel.gs06_group_control_no),
                    new SqlParameter("@" + x12_interchangeStructure.GS07_RESP_AGENCY_CODE, objModel.gs07_resp_agency_code),
                    new SqlParameter("@" + x12_interchangeStructure.GS08_VERSION_ID_CODE, objModel.gs08_version_id_code),

                    //new SqlParameter("@" + x12_interchangeStructure.ST01_TRANSACTION_ID_CODE, objModel.st01_transaction_id_code),
                    //new SqlParameter("@" + x12_interchangeStructure.ST02_TRANSACTION_CONTROL_NO, objModel.st02_transaction_control_no),


                    new SqlParameter("@" + EDITradingPartnerStructure.TRADINGPARTNERID,objModel.TradingPartnerId),
                    new SqlParameter("@" + EDITradingPartnerStructure.DATAFILECONFIGURATIONID,objModel.DataFileConfigurationID),
                    new SqlParameter("@" + x12_interchangeStructure.X12_CONTENT, objModel.x12_content) ,

                    new SqlParameter("@"+ x12DocumentCons.X12_DOCUMENT_ID,SqlDbType.Int) {Direction = ParameterDirection.Output},
                    new SqlParameter("@"+ x12DocumentCons.X12_FUNCTIONAL_GROUP_ID,SqlDbType.Int) {Direction = ParameterDirection.Output},
                    new SqlParameter("@"+ x12DocumentCons.X12_INTERCHANGE_ID,SqlDbType.Int) {Direction = ParameterDirection.Output},

             };

                var objErrmsg = _context.ExecuteStoreProcedure<EDIErrormsg>("edi.uspX12ValidateAndParse", parameters);
                var x12documentid = Convert.ToInt32(parameters.FirstOrDefault(a => a.ParameterName == "@" + x12DocumentCons.X12_DOCUMENT_ID).Value);
                var x12functionalgroupid = Convert.ToInt32(parameters.FirstOrDefault(a => a.ParameterName == "@" + x12DocumentCons.X12_FUNCTIONAL_GROUP_ID).Value);
                var x12interchangeid = Convert.ToInt32(parameters.FirstOrDefault(a => a.ParameterName == "@" + x12DocumentCons.X12_INTERCHANGE_ID).Value);

                return new EDIDocumentParseValidateModel
                {
                    X12DocumentId = x12documentid,
                    X12FunctionalGroupId = x12functionalgroupid,
                    X12InterChangeId = x12interchangeid,
                    Errormsg = objErrmsg
                };
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}
