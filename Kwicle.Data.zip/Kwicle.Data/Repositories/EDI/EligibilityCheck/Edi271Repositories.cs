﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi271Repositories : Disposable, IEdi271Repositories
    {
        private readonly DataImportContext _context;
        //private readonly IEdiHPSRepositories _ediHPSRepositories;
        public Edi271Repositories(DataImportContext context, IEdiHPSRepositories EdiHPSRepositories)
        {
            _context = context;
            //_ediHPSRepositories = EdiHPSRepositories;
        }
        public Edi271MemberEligibilityResponse GetEdi271Details(int X12DocumentID, CurrentTradingPartner _currentTradingPartner)
        {
            return new Edi271MemberEligibilityResponse
            {
                mvw_Mtab_x12_TradingPartner_summary = _currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema
                                               .FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_271),
                EligibilityResponse = _context.vwEligibilityResponse.Where(x => x.x12_document_id == X12DocumentID).ToList(),

                EligibilityResponseDetail = (from d in _context.vwEligibilityResponseDetail
                                             join res in _context.vwEligibilityResponse on d.EligibilityResponseId equals res.EligibilityResponseId
                                             where res.x12_document_id == X12DocumentID
                                             select d
                                             ).ToList(),

                EligibilityResponseDependent = (from d in _context.vwEligibilityResponseDependent
                                                join res in _context.vwEligibilityResponse on d.EligibilityResponseId equals res.EligibilityResponseId
                                                where res.x12_document_id == X12DocumentID
                                                select d
                                             ).ToList(),

                EligibilityResponseDependentDetail = (from det in _context.vwEligibilityResponseDependentDetail
                                                      join d in _context.vwEligibilityResponseDependent on det.EligibilityResponseDependentId equals d.EligibilityResponseDependentID
                                                      join res in _context.vwEligibilityResponse on d.EligibilityResponseId equals res.EligibilityResponseId
                                                      where res.x12_document_id == X12DocumentID
                                                      select det
                                             ).ToList(),


                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_271_5010 && loop.RecordStatus == (int)RecordStatus.Active).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_271_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(segment => segment.LoopGroup)
                                                          .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_271_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                         .OrderBy(element => element.LoopGroup)
                                                         .ThenBy(element => element.SegmentSequence)
                                                         .ThenBy(element => element.SegmentoccurrenceSeq)
                                                         .ThenBy(element => element.ElementPosition)
                                                         .ThenBy(element => element.SubElementPosition).ToList()
            };
        }
        public List<EligibilityRequest> GetEligibilityRequestlistById(int x12DocumentId)
        {
            return (from req in _context.EligibilityRequest
                    where req.RecordStatus == (int)RecordStatus.Active
                     && req.X12DocumentId == x12DocumentId
                    select req).ToList();
        }       
        public int ImportEDI271Data(EDI271Validatemodel objValidatemodel)
        {
            int EligibilityResponseid = 0;
            var para = new List<SqlParameter>
                  {
                      new SqlParameter("@" + EDI271MemberEligibilityStructure.X12_DOCUMENT_ID, objValidatemodel.x12DocumentId),
                      new SqlParameter("@" + EDI271MemberEligibilityStructure.EligibilityRequestId,objValidatemodel.EligibilityRequestId ),
                      new SqlParameter("@" + EDI271MemberEligibilityStructure.SubScriberRejectReasonCode,objValidatemodel.RejectReasonCode ?? (object)DBNull.Value ),
                      new SqlParameter("@" + EDI271MemberEligibilityStructure.EligibilityBeginDate,objValidatemodel.EligibilityBeginDate ?? (object)DBNull.Value),
                      new SqlParameter("@" + EDI271MemberEligibilityStructure.EligibilityEndDate,objValidatemodel.EligibilityEndDate ?? (object)DBNull.Value),
                      new SqlParameter("@" + EDI271MemberEligibilityStructure.EligibilityResponseId,System.Data.SqlDbType.Int){ Direction = ParameterDirection.Output}
                 };
            _context.Database.ExecuteSqlRaw(EDI271MemberEligibilityStructure.USPMUP271TRANSFER, para);

            if (para.Where(p => p.ParameterName == "@" + EDI271MemberEligibilityStructure.EligibilityResponseId).FirstOrDefault().Value != DBNull.Value)
                EligibilityResponseid = Convert.ToInt32(para.Where(p => p.ParameterName == "@" + EDI271MemberEligibilityStructure.EligibilityResponseId).FirstOrDefault().Value);

            return EligibilityResponseid;
        }
        public void SaveSubscriberBenefitInformation(EligibilityResponseDetail[] objentity)
        {
            _context.AddRange(objentity);
            _context.SaveChanges();
        }
        public void SaveDependentBenefitInformation(EligibilityResponseDependentDetail[] objentity)
        {
            _context.AddRange(objentity);
            _context.SaveChanges();
        }
    }
}

