﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi270Repositories : Disposable, IEdi270Repositories
    {
        private readonly DataImportContext _context;
        public Edi270Repositories(DataImportContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12InterchangeId"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public Edi270MemberEligibilityRequest GetEdi270Details(int x12InterchangeId, CurrentTradingPartner currentTradingPartner)
        {
            var parax12InterchangeId = new List<SqlParameter> { new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12InterchangeId) };

            return new Edi270MemberEligibilityRequest
            {
                mvw_Mtab_x12_TradingPartner_summary = currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_270),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_270_5010 && loop.RecordStatus == (int)RecordStatus.Active).OrderBy(loop => loop.LoopSequence).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_270_5010 && segment.RecordStatus == (int)RecordStatus.Active).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_270_5010 && element.RecordStatus == (int)RecordStatus.Active).ToList(),
                x12_270_eligibility_requests = _context.ExecuteStoreProcedure<X12270EligibilityRequest>(EDI270MemberEligibility.GETX12_270_ELIGIBILITY_REQUEST, parax12InterchangeId.ToArray()).ToList()
            };

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmLx12270EligibilityRequest"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public Dictionary<string, object> AddEdi270Details(string xmLx12270EligibilityRequest, CurrentTradingPartner currentTradingPartner)
        {
            object[] paraMemberEligibility = {
                new SqlParameter("@" + EDI270MemberEligibility.XMLX12_270_ELIGIBILITY_REQUEST, xmLx12270EligibilityRequest),
                new SqlParameter("@"+ EDI270MemberEligibility.MODULE_NAME, currentTradingPartner.CurTradingPartner.Module_Name),
                //new SqlParameter("@"+ EDI270MemberEligibility.CLIENT_ID, currentTradingPartner.CurTradingPartner.Client_id),
                //new SqlParameter("@"+ EDI270MemberEligibility.COMPANY_ID, currentTradingPartner.CurTradingPartner.Company_Id),
                new SqlParameter("@"+ x12_interchangeStructure.X12_INTERCHANGE_ID, SqlDbType.Int){Direction = ParameterDirection.Output},
                new SqlParameter("@"+ x12_interchangeStructure.X12_INTERCHANGE_UID, SqlDbType.UniqueIdentifier){Direction = ParameterDirection.Output}};

            _context.Database.ExecuteSqlRaw(EDI270MemberEligibility.INSERTMEMBERELIGIBILITYREQUEST, paraMemberEligibility);
            _context.SaveChanges();

            return new Dictionary<string, object>()
            {
                {x12_interchangeStructure.X12_INTERCHANGE_ID,((SqlParameter)paraMemberEligibility[4]).Value},
                {x12_interchangeStructure.X12_INTERCHANGE_UID,((SqlParameter)paraMemberEligibility[5]).Value}
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="memberAlertGridoption"></param>
        /// <returns></returns>
        public List<vwMemberAlert> GetMemberAlert(MemberAlertGridoption memberAlertGridoption)
        {
            object[] paraMemberEligibility = {
                    new SqlParameter("@" + MemberMedicationHistoryStructure.OrderByColumn, (object)memberAlertGridoption.OrderByColumn ?? DBNull.Value),
                    new SqlParameter("@"+ MemberMedicationHistoryStructure.OrderByDirection, (object)memberAlertGridoption.OrderByDirection  ??DBNull.Value),
                    new SqlParameter("@" + MemberMedicationHistoryStructure.Skip,memberAlertGridoption.skip) {SqlDbType = System.Data.SqlDbType.Int},
                    new SqlParameter("@" + MemberMedicationHistoryStructure.Take, memberAlertGridoption.take) {SqlDbType = System.Data.SqlDbType.Int}
                };

            return _context.ExecuteStoreProcedure<vwMemberAlert>(EDI270MemberEligibility.USP_GETMEMBERALERTS, paraMemberEligibility).ToList();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ObjView"></param>
        /// <returns></returns>
        public DataSourceResult GetMemberAlertListing(GridOption_View ObjView)
        {
            string strX12_DOCUMENT_ID = ObjView.Requestparam.Single(a => a.Name == x12DocumentCons.X12_DOCUMENT_ID).Value;
            SqlParameter[] param = {
                    new SqlParameter("@" + x12DocumentCons.X12_DOCUMENT_ID, strX12_DOCUMENT_ID),
                    new SqlParameter("@" + EDI270MemberEligibility.OrderByColumn, (object)ObjView.OrderByColumn ?? DBNull.Value),
                    new SqlParameter("@"+ EDI270MemberEligibility.OrderByDirection, (object)ObjView.OrderByDirection ?? DBNull.Value),
                    new SqlParameter("@" + EDI270MemberEligibility.Skip,ObjView.Skip) ,
                    new SqlParameter("@" + EDI270MemberEligibility.Take, ObjView.Take),
                    new SqlParameter("@" +EDI270MemberEligibility.totalItems,System.Data.SqlDbType.Int){ Direction = ParameterDirection.Output}
                };

            //object[] paraMemberEligibility = {                    
            //        new SqlParameter("@" + x12DocumentCons.X12_DOCUMENT_ID, memberAlertListingoption.x12_document_id) {SqlDbType = System.Data.SqlDbType.Int}
            //    };

            var objdata = _context.ExecuteStoreProcedure<vwMemberAlertListing>(EDI270MemberEligibility.USP_MEDICATIONHISTORYLISTING, param).ToList();
            int count = System.Convert.ToInt32(param.Single(p => p.ParameterName == "@" + EDI270MemberEligibility.totalItems).Value);

            return new DataSourceResult
            {
                Data = objdata,
                totalItems = count
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Docmentid"></param>
        /// <returns></returns>
        public vwMemberAlertDocument GetMemberAlertDocument(int Docmentid)
        {
            object[] paraMemberEligibility = {
                    new SqlParameter("@" + x12DocumentCons.X12_DOCUMENT_ID, Docmentid) {SqlDbType = System.Data.SqlDbType.Int}
                };
            return _context.ExecuteStoreProcedure<vwMemberAlertDocument>(EDI270MemberEligibility.USP_GetmemberAlertDocument, paraMemberEligibility).ToList().FirstOrDefault();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_interchange_id"></param>
        public void ClaimTrnasfer(int x12_interchange_id)
        {
            var parax12InterchangeId = new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12_interchange_id);
            _context.Database.ExecuteSqlRaw(EDI270MemberEligibility.uspMup270Transfer, parax12InterchangeId);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<EDI270UploadFileModel> GetEDI270UploadFiles()
        {
            return (from Doc in _context.Vw270FileSummary
                    where Doc.RecordStatus == (int)RecordStatus.Active
                    select new EDI270UploadFileModel
                    {
                        FileID = Doc.FileID,
                        FileName = Doc.FileName,
                        TradingPartnerID = Doc.TradingPartnerID,
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        FileStatus = Doc.FileStatus,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        Total = Doc.Total,
                        Version = Doc.Version,
                        ResponseFileName = Doc.ResponseFileName
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<EDI270SummaryModel> GetEDI270Summary()
        {
            return (from Doc in _context.vw270Summary
                    select new EDI270SummaryModel
                    {
                        FileID = Doc.FileID,
                        Billed = Doc.Billed,
                        Receiver = Doc.Receiver,
                        ReceiverId = Doc.ReceiverId,
                        EligibilityRequestID = Doc.EligibilityRequestID,
                        DOB = Doc.DOB,
                        Gender =Doc.Gender,
                        MemberID = Doc.MemberID,
                        Name = Doc.Name,
                        TraceNumber = Doc.TraceNumber,
                        UploadedDate = Doc.UploadedDate,
                        TradingPartnerID = Doc.TradingPartnerID,
                        DependentName = Doc.DependentName,
                        Benefitinquiry = Doc.Benefitinquiry
                    });
        }

    }
}
