﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class X12DocumentResponseRepositories : Disposable,IX12DocumentResponseRepositories
    {
        private readonly DataImportContext _context;
        public X12DocumentResponseRepositories(DataImportContext context)
        {
            _context = context;
        }
        public int Add(X12DocumentResponse X12DocumentResponse)
        {
            _context.X12DocumentResponse.Add(X12DocumentResponse);
            _context.SaveChanges();
            return X12DocumentResponse.X12DocumentResponseId;
        }
        public int Update(X12DocumentResponse X12DocumentResponse)
        {
            _context.X12DocumentResponse.Update(X12DocumentResponse);
            _context.SaveChanges();
            return X12DocumentResponse.X12DocumentResponseId;
        }

    }
}
