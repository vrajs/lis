﻿using Kwicle.Common.Utility;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class ClearningHouseRepositories : Disposable, IClearningHouseRepositories
    {
        private readonly DataImportContext _context;
        public ClearningHouseRepositories(DataImportContext context)
        {
            _context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clearingHouseId"></param>
        /// <returns></returns>
        public ClearingHouse GetDetails(Guid clearingHouseId)
        {
            return _context.ClearingHouse.FirstOrDefault(chouse => chouse.ClearingHouseId == clearingHouseId);
        }
    }
}
