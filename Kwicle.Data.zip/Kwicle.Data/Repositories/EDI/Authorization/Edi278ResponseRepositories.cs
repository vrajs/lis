﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common.EDI;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi278ResponseRepositories : Disposable, IEdi278ResponseRepositories
    {
        private readonly DataImportContext _context;
        public Edi278ResponseRepositories(DataImportContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Transfer278AuthDetails()
        {
            _context.Database.ExecuteSqlRaw(Edi278AuthorizationResponse.mup_x12_278_Transfer);
        }
    }
}
