﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi278Repositories : Disposable, IEdi278Repositories
    {
        private readonly DataImportContext _context;
        public Edi278Repositories(DataImportContext context)
        {
            _context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_document_id"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public Edi278AuthorizationRequest GetEdi278Details(int x12_document_id, CurrentTradingPartner currentTradingPartner)
        {
            return new Edi278AuthorizationRequest
            {
                mvw_Mtab_x12_TradingPartner_summary = currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_278),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_278_5010 && loop.RecordStatus == (int)RecordStatus.Active).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_278_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(segment => segment.LoopGroup)
                                                          .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_278_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(element => element.LoopGroup)
                                                          .ThenBy(element => element.SegmentSequence)
                                                          .ThenBy(element => element.SegmentoccurrenceSeq)
                                                          .ThenBy(element => element.ElementPosition)
                                                          .ThenBy(element => element.SubElementPosition) .ToList(),
                AuthorizationRequest = _context.Mtab278AuthorizationRequest.Where( auth => auth.X12DocumentId == x12_document_id).ToList(),
                AuthorizationRequestPhysicians = (from auth in _context.Mtab278AuthorizationRequest.Where(auth => auth.X12DocumentId == x12_document_id)
                                                  join physician in _context.Mtab278AuthorizationPhysician on auth.MtabAuthorizationRequestId equals physician.MtabAuthorizationRequestId
                                                  select physician).ToList(),
                AuthorizationRequestService =  (from auth in _context.Mtab278AuthorizationRequest.Where(auth => auth.X12DocumentId == x12_document_id)
                                               join service in  _context.Mtab278AuthorizationRequestService  on auth.MtabAuthorizationRequestId equals service.MtabAuthorizationRequestId
                                               select service).ToList()
            };
        }
        /// <summary>
        /// Insert Authorization request
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <returns></returns>
        public int InsertAuthorizationRequest(Mtab278AuthorizationRequest authorizationRequest)
        {
            _context.Mtab278AuthorizationRequest.Add(authorizationRequest);
            _context.SaveChanges();

            return authorizationRequest.MtabAuthorizationRequestId;
        }
        /// <summary>
        /// To Add the Authorization Services
        /// </summary>
        /// <param name="authorizationRequestService"></param>
        public void InsertAuthorzationService(Mtab278AuthorizationRequestService authorizationRequestService)
        {
            _context.Mtab278AuthorizationRequestService.Add(authorizationRequestService);
            _context.SaveChanges();
        }
        /// <summary>
        /// To add the  Authorization Physicians
        /// </summary>
        /// <param name="authorizationRequestPhysician"></param>
        public void InsertAuthorizationPhysician(Mtab278AuthorizationPhysician authorizationRequestPhysician)
        {
            _context.Mtab278AuthorizationPhysician.Add(authorizationRequestPhysician);
            _context.SaveChanges();
        }
    }
}
