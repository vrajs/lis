﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class X12TransactionRepositories : BaseRepository<X12Transaction> , IX12TransactionRepositories
    {
        private readonly DataImportContext _context;
        public X12TransactionRepositories(DataImportContext context) : base(context)
        {
            _context = context;
        }

        private bool CheckDuplicateTransaction(EDIDocumentParseModel objModel, X12Transaction objtran)
        {
            return (from t in _context.X12Transaction
                    join f in _context.X12FunctionalGroup on t.X12FunctionalGroupId equals f.X12FunctionalGroupId
                    join i in _context.X12Interchange on f.X12InterchangeId equals i.X12InterchangeId
                    where i.Isa06SenderId == objModel.isa06_sender_id &&
                        i.Isa08ReceiverId == objModel.isa08_receiver_id &&
                        i.Isa13ControlNo == objModel.isa13_control_no &&
                        f.Gs06GroupControlNo == objModel.gs06_group_control_no &&
                        t.St01TransactionIdCode == objtran.St01TransactionIdCode &&
                        t.St02TransactionControlNo == objtran.St02TransactionControlNo &&
                        t.Processed == true && t.RecordStatus == (int)(RecordStatus.Active)
                    select t).Any();
        }        
        public int ValidateTransaction(EDIDocumentParseModel objModel, X12Transaction objtran)
        {
            int x12transactionid = 0;
            if (CheckDuplicateTransaction(objModel, objtran))
            {
                X12InterchangeMessage objMessagemodel = new X12InterchangeMessage();
                objMessagemodel.X12InterchangeId = objModel.X12InterchangeId;
                objMessagemodel.Isa13ControlNo = objModel.isa13_control_no;
                objMessagemodel.Gs06GroupControlNo = objModel.gs06_group_control_no;
                objMessagemodel.St02TransactionControlNo = objtran.St02TransactionControlNo;
                objMessagemodel.MessageCode = "999";
                objMessagemodel.MessageText = "Transaction Control Number ['" + objtran.St02TransactionControlNo + "'] has already been processed";
                _context.Add(objMessagemodel);
            }
            else
            {
                _context.Add(objtran);
                _context.SaveChanges();
                x12transactionid = objtran.X12TransactionId;
            }

            return x12transactionid;
        }
    }
}
