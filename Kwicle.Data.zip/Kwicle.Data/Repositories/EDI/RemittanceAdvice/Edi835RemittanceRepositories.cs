﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi835RemittanceRepositories : Disposable, IEdi835RemittanceRepositories
    {
        private readonly DataImportContext _context;

        private static Dictionary<SqlDbType, Type> _clrTypeToSqlTypeMaps;
        public Edi835RemittanceRepositories(DataImportContext context)
        {
            _context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_document_id"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public EDI835RemittanceAdviceGenerate GetEdi835Details(int x12_document_id, CurrentTradingPartner currentTradingPartner)
        {
            return new EDI835RemittanceAdviceGenerate
            {
                mvw_Mtab_x12_TradingPartner_summary = currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_835),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_835_5010 && loop.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(loop => loop.Loop).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_835_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(segment => segment.LoopGroup)
                                                          .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_835_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(element => element.LoopGroup)
                                                          .ThenBy(element => element.SegmentSequence)
                                                          .ThenBy(element => element.SegmentoccurrenceSeq)
                                                          .ThenBy(element => element.ElementPosition)
                                                          .ThenBy(element => element.SubElementPosition).ToList(),
                PaymentSummary = _context.VwRemittanceAdviceCheck.Where(summary => summary.x12_document_id == x12_document_id).ToList(),
                PaymentClaim = (from Summary in _context.VwRemittanceAdviceCheck.Where(summary => summary.x12_document_id == x12_document_id)
                                join Claim in _context.VwRemittanceAdviceClaim on Summary.RemittanceAdviceCheckID equals Claim.RemittanceAdviceCheckID
                                select Claim).ToList(),
                PaymentService = (from Summary in _context.VwRemittanceAdviceCheck.Where(summary => summary.x12_document_id == x12_document_id)
                                  join Claim in _context.VwRemittanceAdviceClaim on Summary.RemittanceAdviceCheckID equals Claim.RemittanceAdviceCheckID
                                  join Service in _context.VwRemittanceAdviceService on Claim.RemittanceAdviceClaimID equals Service.RemittanceAdviceClaimID
                                  select Service).ToList()
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_interchange_id"></param>
        public void PaymentTrnasfer(int x12_interchange_id)
        {
            var parax12InterchangeId = new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12_interchange_id);
            _context.Database.ExecuteSqlRaw(Edi835RemittanceStructure.MUP_X12_835_TRANSFER, parax12InterchangeId);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<EDI835CheckModel> GetEdi835Check()
        {
            return (from c in _context.Vw835CheckSummary
                    where c.RecordStatus == (int)RecordStatus.Active
                    select new EDI835CheckModel
                    {
                        FileID = c.FileID,
                        FileName = c.FileName,
                        TradingPartnerID = c.TradingPartnerID,
                        CreatedBy = c.CreatedBy,
                        CreatedDate = c.CreatedDate,
                        FileStatusID = c.FileStatusID,
                        FileStatus = c.FileStatus,
                        Error = c.Error,
                        ErrorMessage = c.ErrorMessage,
                        Total = c.Total,
                        Version = c.Version,
                        RecordStatus = c.RecordStatus,
                        Filetype = c.Filetype,
                        PayerName = c.PayerName
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objModel"></param>
        /// <returns></returns>
        public int ImportRemittanceAdvice(ImportRemittanceAdviceModel objModel)
        {
            int x12documentID = 0;
            if (objModel.RemittanceAdviceClaimlist.Count > 0)
            {
                #region UpdateRemittanceModel
                foreach (var item in objModel.RemittanceAdviceClaimlist)
                {
                    if (objModel.RemittanceAdviceServicelist.Count > 0)
                    {
                        var servicelist = objModel.RemittanceAdviceServicelist.Where(x => x.ClaimHeaderID == item.ClaimHeaderID).ToList();
                        decimal? clp05amt = servicelist.Sum(x => x.L2110_1_cas03_adj_amt + x.L2110_2_cas03_adj_amt + x.L2110_3_cas03_adj_amt);
                        decimal? interestAmount = servicelist.Sum(x => x.L2100_AMT01_I_Amount);
                        item.L2100_clp05_pt_resp_amt = clp05amt;
                        item.L2100_AMT01_I_Amount = interestAmount;

                        var service = objModel.RemittanceAdviceServicelist.Where(x => x.ClaimHeaderID == item.ClaimHeaderID).FirstOrDefault();
                        if (service != null)
                        {
                            item.L2100_clp08_facility_type_code = service.L2100_clp08_facility_type_code;
                        }
                    }
                }
                #endregion

                DataTable dtRemittanceAdviceChecklist = _context.ToDataTableWithSchemaFromIList("udtRemittanceAdviceCheck", objModel.RemittanceAdviceChecklist);
                DataTable dtRemittanceAdviceClaimlist = _context.ToDataTableWithSchemaFromIList("udtRemittanceAdviceClaim", objModel.RemittanceAdviceClaimlist);
                DataTable dtRemittanceAdviceServicelist = _context.ToDataTableWithSchemaFromIList("udtRemittanceAdviceService", objModel.RemittanceAdviceServicelist);

                var para = new SqlParameter[] {
                          new SqlParameter(Edi835RemittanceStructure.udtRemittanceAdviceCheck, dtRemittanceAdviceChecklist) { TypeName = "edi.udtRemittanceAdviceCheck" },
                          new SqlParameter(Edi835RemittanceStructure.udtRemittanceAdviceClaim, dtRemittanceAdviceClaimlist) { TypeName = "edi.udtRemittanceAdviceClaim" },
                          new SqlParameter(Edi835RemittanceStructure.udtRemittanceAdviceService,dtRemittanceAdviceServicelist) { TypeName = "edi.udtRemittanceAdviceService"},
                          new SqlParameter(Edi835RemittanceStructure.CreatedBy,objModel.CreatedBy ),
                          new SqlParameter(Edi835RemittanceStructure.DataFileConfigurationId,objModel.DataFileConfigurationID )
                        };
                var Remittance = _context.ExecuteStoreProcedure<ImportInsertRemittanceModel>(Edi835RemittanceStructure.uspRemittanceAdviceImport, para).FirstOrDefault();
                x12documentID = Remittance.x12Documentid;
            }
            return x12documentID;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<EDI835CheckClaimSummaryModel> GetEdi835CheckClaimSummary()
        {
            return (from c in _context.Vw835CheckClaimSummary
                    where c.RecordStatus == (int)RecordStatus.Active
                    select new EDI835CheckClaimSummaryModel
                    {
                        RemittanceAdviceClaimID = c.RemittanceAdviceClaimID,
                        FileID = c.FileID,
                        PayerName = c.PayerName,
                        PayeeName = c.PayeeName,
                        MemberName = c.MemberName,
                        MemberID = c.MemberID,
                        PCPName = c.PCPName,
                        CheckDate = c.CheckDate,
                        CheckNo = c.CheckNo,
                        BilledAmount = c.BilledAmount,
                        PaidAmount = c.PaidAmount,
                        CheckAmount = c.CheckAmount,
                        ReceivedDate = c.ReceivedDate,
                        ClaimNumber = c.ClaimNumber,
                        PatientControlNumber = c.PatientControlNumber,
                        RecordStatus = c.RecordStatus
                    });
        }
    }
}
