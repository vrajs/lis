﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Data.Contracts.EDI.RemittanceAdvice;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI.RemittanceAdvice
{
    public class Edi835RemittanceCheckRepositories : BaseRepository<RemittanceAdviceCheck>, IEdi835RemittanceCheckRepositories
    {
        #region Variables
        private readonly DataImportContext _context;
        #endregion
        #region Ctor
        public Edi835RemittanceCheckRepositories(DataImportContext context) : base(context) {
            _context = context;
        }
        #endregion
        #region Interface Methods Implementation   
      
        #endregion
    }

}
