﻿using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi837IErrorRepositories : IEdi837IErrorRepositories
    {
        private readonly DataImportContext _context;
        private readonly KwicleViewContext _contexthps;
        public Edi837IErrorRepositories(DataImportContext context, KwicleViewContext contexthps)
        {
            _context = context;
            _contexthps = contexthps;
        }

        public List<vwClaimProfessionalError> GetInstitutionalClaimError(int ClaimProfessionalId, string strErrorCode)
        {
            var objparam = new List<SqlParameter>
            { new SqlParameter("@" + EDI837IStructure.CLAIMINSTITUTIONALID, ClaimProfessionalId),
             new SqlParameter("@" + EDI837IStructure.Errorcode, strErrorCode)
            };

            return _context.ExecuteStoreProcedure<vwClaimProfessionalError>(EDI837IStructure.GetInstitutionalClaimError, objparam.ToArray()).ToList();
        }
        public List<KeyValuePair<string, string>> GetInstitutionalClaimErrorByClaimId(int ClaimId)
        {
            var objerrorlist = (from c in _context.ClaimInstitutionalError
                                join m in _context.MtabMError on c.ErrorId equals m.ErrorId
                                where c.ClaimInstitutionalId == ClaimId && c.RecordStatus == (int)RecordStatus.Active
                                select new KeyValuePair<string, string>(m.ErrorCode, m.ErrorDesc)
                                ).ToList();
            return objerrorlist;
        }
        public List<vwClaimProfessionalError> GetInstitutionalClaimErrorHistory(int ClaimProfessionalId)
        {
            var objparam = new List<SqlParameter> { new SqlParameter("@" + EDI837PStructure.CLAIMPROFESSIONALID, ClaimProfessionalId) };
            return _context.ExecuteStoreProcedure<vwClaimProfessionalError>(EDI837PStructure.GetProfessionalClaimErrorHistory, objparam.ToArray()).ToList();
        }

        public IQueryable<vwClaimErrorsModule> GetInstitutionalClaimErrors()
        {
            return (from clm in _context.VwInstitutionalClaimError
                    select new vwClaimErrorsModule
                    {
                        ErrorCode = clm.ErrorCode,
                        ErrorDescription = clm.ErrorDescription,
                        TotalClaim = clm.TotalClaim
                    });
        }



        public IQueryable<EDI837IErrorClaimModel> GetInstitutionalErrorClaim()
        {
            return (from clm in _context.VwInstitutionalErrorClaim
                    select new EDI837IErrorClaimModel
                    {
                        ClaimId = clm.ClaimInstitutionalID,
                        ErrorCode = clm.ErrorCode,
                        L2010BA_nm109_subscriber_id = clm.L2010BA_nm109_subscriber_id,
                        L2010BA_nm103_subscriber_last_nm = clm.L2010BA_nm103_subscriber_last_nm,
                        L2010BA_nm104_subscriber_first_nm = clm.L2010BA_nm104_subscriber_first_nm,
                        L2010BA_nm105_subscriber_middle_nm = clm.L2010BA_nm105_subscriber_middle_nm,
                        L2010BA_n301_subscriber_address1 = clm.L2010BA_n301_subscriber_address1,
                        L2010BA_n302_subscriber_address2 = clm.L2010BA_n302_subscriber_address2,
                        L2010BA_n401_subscriber_city = clm.L2010BA_n401_subscriber_city,
                        L2010BA_n402_subscriber_state = clm.L2010BA_n402_subscriber_state,
                        L2010BA_n403_subscriber_zip = clm.L2010BA_n403_subscriber_zip,
                        L2010BA_dmg02_subscriber_dob = clm.L2010BA_dmg02_subscriber_dob,
                        L2010BA_dmg03_subscriber_gender = clm.L2010BA_dmg03_subscriber_gender,
                        L2010BA_ref02_SY_subscriber_sup_id = clm.L2010BA_ref02_SY_subscriber_sup_id,
                        L2000B_sbr02_ind_relationship_code = clm.L2000B_sbr02_ind_relationship_code,
                        L2010AA_nm103_billing_prov_last_nm = clm.L2010AA_nm103_billing_prov_last_nm,
                        // L2010AA_nm104_billing_prov_first_nm = clm.L2010AA_nm104_billing_prov_first_nm,
                        L2010AA_nm109_billing_prov_id = clm.L2010AA_nm109_billing_prov_id,
                        L2010AA_n301_billing_prov_address1 = clm.L2010AA_n301_billing_prov_address1,
                        L2010AA_n302_billing_prov_address2 = clm.L2010AA_n302_billing_prov_address2,
                        L2010AA_n401_billing_prov_city = clm.L2010AA_n401_billing_prov_city,
                        L2010AA_n402_billing_prov_state = clm.L2010AA_n402_billing_prov_state,
                        L2010AA_n403_billing_prov_zip = clm.L2010AA_n403_billing_prov_zip,
                        L2010AA_ref02_EI_billing_prov_id = clm.L2010AA_ref02_EI_billing_prov_id,
                        // L2010AA_ref02_SY_billing_prov_id = clm.L2010AA_ref02_SY_billing_prov_id,
                        L2000A_prv01_provider_code = clm.L2000A_prv01_provider_code,
                        L2000A_prv03_taxonomy_code = clm.L2000A_prv03_taxonomy_code,
                        L2010AA_n404_billing_prov_country = clm.L2010AA_n404_billing_prov_country,
                        L2010AA_nm102_entity_type_qual = clm.L2010AA_nm102_entity_type_qual,

                        L2010AA_nm108_id_code_qual = clm.L2010AA_nm108_id_code_qual,
                        L2010AA_per02_billing_prov_contact_nm = clm.L2010AA_per02_billing_prov_contact_nm,
                        L2010AA_per03_billing_prov_comm_num_qual = clm.L2010AA_per03_billing_prov_comm_num_qual,
                        L2010AA_per04_billing_prov_comm = clm.L2010AA_per04_billing_prov_comm



                    }
                    );
        }

        public vwEDIMember GetMemberById(int memberid)
        {
            return _contexthps.vwEDIMember.Where(x => x.MemberID == memberid).FirstOrDefault();
        }

        public vwEDIProvider GetproviderById(int providerid)
        {
            return _contexthps.vwEDIProvider.Where(x => x.ProviderID == providerid).FirstOrDefault();
        }
        public void UpdateClaimInstitutionalError(vwClaimProfessionalErrorModel objModel)
        {
            #region xml


            XElement objDiagCodexml = null; XElement objCPTCodexml = null; XElement objModCodexml = null;
            if (objModel.objErrorDiagcodelist != null)
            {
                objDiagCodexml = new XElement("Diagcode", from i in objModel.objErrorDiagcodelist.Where(E => !string.IsNullOrEmpty(E.code))
                                                          select new XElement("Values",
                                                              new XElement("code", i.code),
                                                              new XElement("id", i.id),
                                                              new XElement("pageControlID", i.pageControlID),
                                                              new XElement("Errorid", i.Errorid)
                                                              ));
            }
            if (objModel.objErrorCptcodeList != null)
            {
                objCPTCodexml = new XElement("CPTcode", from i in objModel.objErrorCptcodeList.Where(E => !string.IsNullOrEmpty(E.code))
                                                        select new XElement("Values",
                                                            new XElement("code", i.code),
                                                            new XElement("id", i.id),
                                                            new XElement("Errorid", i.Errorid)
                                                            ));
            }
            if (objModel.objErrorModcodeList != null)
            {
                objModCodexml = new XElement("Modcode", from i in objModel.objErrorModcodeList.Where(E => !string.IsNullOrEmpty(E.code))
                                                        select new XElement("Values",
                                                            new XElement("code", i.code),
                                                            new XElement("id", i.id),
                                                            new XElement("pageControlID", i.pageControlID),
                                                            new XElement("Errorid", i.Errorid)
                                                            ));
            }
            #endregion
            var para = new List<SqlParameter>
            {
                new SqlParameter("@" + EDI837IStructure.CLAIMINSTITUTIONALID, objModel.ClaimProfessionalId){SqlDbType = System.Data.SqlDbType.Int},
                new SqlParameter("@" + EDI837IStructure.Errorcode, objModel.Errorcode),
                new SqlParameter("@" + EDI837IStructure.L2010BA_nm109_subscriber_id , (object)objModel.L2010BA_nm109_subscriber_id  ?? DBNull.Value ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_nm104_subscriber_first_nm ,(object)objModel.L2010BA_nm104_subscriber_first_nm?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_nm103_subscriber_last_nm , (object)objModel.L2010BA_nm103_subscriber_last_nm ?? DBNull.Value ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_nm105_subscriber_middle_nm , (object)objModel.L2010BA_nm105_subscriber_middle_nm?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_dmg02_subscriber_dob , (object)objModel.L2010BA_dmg02_subscriber_dob?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_dmg03_subscriber_gender , (object)objModel.L2010BA_dmg03_subscriber_gender?? DBNull.Value ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_ref02_SY_subscriber_sup_id  , (object)objModel.L2010BA_ref02_SY_subscriber_sup_id ?? DBNull.Value ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_n301_subscriber_address1  , (object)objModel.L2010BA_n301_subscriber_address1?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010BA_n302_subscriber_address2  , (object)objModel.L2010BA_n302_subscriber_address2?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2000B_sbr02_ind_relationship_code  , (object)objModel.L2000B_sbr02_ind_relationship_code?? DBNull.Value  ),

                new SqlParameter("@" + EDI837IStructure.L2010AA_nm102_entity_type_qual  , (object)objModel.L2010AA_nm102_entity_type_qual?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010AA_nm109_billing_prov_id  , (object)objModel.L2010AA_nm109_billing_prov_id?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010AA_nm103_billing_prov_last_nm  ,(object) objModel.L2010AA_nm103_billing_prov_last_nm?? DBNull.Value  ),
                new SqlParameter("@" + EDI837IStructure.L2010AA_ref02_EI_billing_prov_id    , (object)objModel.L2010AA_ref02_EI_billing_prov_id?? DBNull.Value ),
                new SqlParameter("@" + EDI837IStructure.L2000A_prv01_provider_code      , (object)objModel.L2000A_prv01_provider_code?? DBNull.Value   ),
                new SqlParameter("@" + EDI837IStructure.L2000A_prv03_taxonomy_code      , (object)objModel.L2000A_prv03_taxonomy_code?? DBNull.Value   ),

                new SqlParameter("@DiagCodexml", objDiagCodexml != null ?  (object)objDiagCodexml.ToString() :  DBNull.Value),
                new SqlParameter("@Cptcodexml", objCPTCodexml != null ?(object)objCPTCodexml.ToString() : DBNull.Value ),
                new SqlParameter("@Modifierxml", objModCodexml != null ?(object)objModCodexml.ToString() : DBNull.Value ),
                new SqlParameter("@" + EDI837IStructure.isApplyfix,(object)objModel.isApplyfix ?? false)

        };
            _context.Database.ExecuteSqlRaw(EDI837IStructure.usp_UpdateClaimInstitutionalError, para.ToArray());
        }

        public EDIMembermodel GetMemberInstitutionalByClaimId(int ClaimId)
        {
            return (from c in _context.ClaimInstitutional
                    where c.ClaimInstitutionalId == ClaimId
                    select new EDIMembermodel
                    {
                        LastName = c.L2010baNm103SubscriberLastNm,
                        FirstName = c.L2010baNm104SubscriberFirstNm,
                        MiddleName = c.L2010baNm105SubscriberMiddleNm,
                        Suffix = c.L2010baNm107SubscriberSuffix,
                        SubscriberId = c.L2010baNm109SubscriberId,
                        Address1 = c.L2010baN301SubscriberAddress1,
                        Address2 = c.L2010baN302SubscriberAddress2,
                        City = c.L2010baN401SubscriberCity,
                        State = c.L2010baN402SubscriberState,
                        Zip = c.L2010baN403SubscriberZip,
                        Country = c.L2010baN404SubscriberCountry,
                        Dob = c.L2010baDmg02SubscriberDob,
                        Gender = c.L2010baDmg03SubscriberGender,
                        SSN = c.L2010baRef02SySubscriberSupId,
                        PropCasualtyClaimNum = c.L2010baRef02Y4PropCasualtyClaimNum,
                        Relationshipcode =c.L2000bSbr02IndRelationshipCode
                    }).FirstOrDefault();
        }

    }
}
