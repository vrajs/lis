﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.EDI
{
    public class EDI837IServiceLineRepositories : BaseRepository<ClaimInstitutionalServices>, IEDI837IServiceLineRepository
    {
        private readonly DataImportContext _context;

        public EDI837IServiceLineRepositories(DataImportContext context) : base(context)
        {
            _context = context;
        }
        public IQueryable<vwClaimIServiceLine> GetServiceLine(int claimid)
        {
            return from clm in _context.ClaimInstitutionalServices
                   where clm.ClaimInstitutionalId == claimid && clm.RecordStatus == Convert.ToInt32(RecordStatus.Active)
                   select new vwClaimIServiceLine
                   {
                       ID = clm.Id,
                       ClaimInstitutionalID = clm.ClaimInstitutionalId,
                       L2400_lx01_assigned_num  = Convert.ToInt32(clm.L2400Lx01AssignedNum),
                       L2400_dtp02_472_from_service_date = clm.L2400Dtp02472FromServiceDate,
                       L2400_dtp02_472_to_service_date = clm.L2400Dtp02472ToServiceDate,
                       L2400_sv201_rev_code = clm.L2400Sv201RevCode,
                       L2400_sv202_proc_code = clm.L2400Sv202ProcCode,
                       L2400_sv202_proc_mod1 = clm.L2400Sv202ProcMod1,
                       L2400_sv202_proc_mod2 = clm.L2400Sv202ProcMod2,
                       L2400_sv202_proc_mod3 = clm.L2400Sv202ProcMod3,
                       L2400_sv202_proc_mod4 = clm.L2400Sv202ProcMod4,
                       L2400_sv203_line_charge = clm.L2400Sv203LineCharge,
                       L2400_sv205_service_unit_count = clm.L2400Sv205ServiceUnitCount,
                       L2400_sv207_denied_amt = clm.L2400Sv207DeniedAmt,
                       L2410_1_lin03_N4_ndc = clm.L24101Lin03N4Ndc
                   };
        }
        //public bool CheckDuplicateDiag(vwClaimIServiceLine obj)
        //{
        //    return _context.ClaimInstitutionalServices.
        //       Where(b => b.CommonCodeID == obj.CommonCodeID && b.InstitutionalDiagnosisCodeId != obj.InstitutionalDiagnosisCodeId
        //       && b.ClaimInstitutionalID == obj.ClaimInstitutionalID && b.Code == obj.Code).Any();
        //}
    }
}
