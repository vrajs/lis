﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
namespace Kwicle.Data.Repositories.EDI
{
    public class ClaimInstitutionalErrorRepositories : IClaimInstitutionalErrorRepositories
    {
        private readonly DataImportContext _context;
        public ClaimInstitutionalErrorRepositories(DataImportContext context)
        {
            _context = context;
        }
        public void Add(ClaimInstitutionalError ClaimError)
        {
            _context.ClaimInstitutionalError.Add(ClaimError);
            _context.SaveChanges();
           // throw new NotImplementedException();
        }

        public void Add(XElement xmlElements)
        {
            object[] paraMemberEligibility = { new SqlParameter("@ClaimErrorxml", xmlElements.ToString()) };

            _context.Database.ExecuteSqlRaw("edi.usp_InsertClaimInstitutionalError @ClaimErrorxml", paraMemberEligibility);
            // throw new NotImplementedException();
        }

        public void ErrorFixed(ClaimInstitutionalError ClaimError)
        {
            var Error = _context.ClaimInstitutionalError.Where(clm => clm.ClaimInstitutionalId == ClaimError.ClaimInstitutionalId && clm.RecordStatus == (int)RecordStatus.Active).ToList();
            Error.ForEach(err =>
            {
                err.ErrorFixedBy = ClaimError.ErrorFixedBy;
                err.ErrorFixedDate = ClaimError.ErrorFixedDate;
                err.RecordStatus = (int)RecordStatus.InActive;
            });
            _context.SaveChanges();
            // throw new NotImplementedException();
        }
    }
}
