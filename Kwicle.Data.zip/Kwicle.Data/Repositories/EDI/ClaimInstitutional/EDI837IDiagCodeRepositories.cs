﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.EDI
{
    public class EDI837IDiagCodeRepositories : BaseRepository<InstitutionalDiagnosisCode>, IEDI837IDiagCodeRepository
    {
        private readonly DataImportContext _context;

        public EDI837IDiagCodeRepositories(DataImportContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<vwInstitutionalDiagnosisCode> GetInstitutionalDiagnosisCode(InstitutionalDiagnosisCodeParam objparam)
        {
            return from Clm in _context.InstitutionalDiagnosisCode
                       //join  common in _context.EdiCommonCodes 
                   where Clm.ClaimInstitutionalID == objparam.ClaimInstitutionalID
                   && objparam.categoryids.Contains(Clm.CommonCodeID)
                   && Clm.RecordStatus == Convert.ToInt32(RecordStatus.Active)
                   select new vwInstitutionalDiagnosisCode
                   {
                       ClaimInstitutionalID = Convert.ToInt32(Clm.ClaimInstitutionalID),
                       Code = Clm.Code,
                       CommonCodeID = Clm.CommonCodeID,
                       InstitutionalDiagnosisCodeId = Clm.InstitutionalDiagnosisCodeId,
                       Qualifier = Clm.Qualifier,
                       Sequence = Clm.Sequence,
                       Amount = Clm.Amount,
                       FromDate = Clm.FromDate,
                       ToDate = Clm.ToDate
                   };
        }

        public bool CheckDuplicateDiag(vwInstitutionalDiagnosisCode obj)
        {
            return _context.InstitutionalDiagnosisCode.
                 Where(b => b.CommonCodeID == obj.CommonCodeID && b.InstitutionalDiagnosisCodeId != obj.InstitutionalDiagnosisCodeId
                 && b.ClaimInstitutionalID == obj.ClaimInstitutionalID && b.Code == obj.Code).Any();
        }
    }
}
