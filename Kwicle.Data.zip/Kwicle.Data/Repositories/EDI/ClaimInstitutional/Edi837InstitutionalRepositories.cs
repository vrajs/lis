﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi837InstitutionalRepositories : Disposable, IEdi837InstitutionalRepositories
    {
        private readonly DataImportContext _context;

        public Edi837InstitutionalRepositories(DataImportContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="X12_documentID"></param>
        /// <param name="currentTradingPartner"></param>
        /// <returns></returns>
        public Edi837IEncounterFileGenerateEntity GetEdi837IDetails(int X12_documentID, CurrentTradingPartner currentTradingPartner)
        {
            return new Edi837IEncounterFileGenerateEntity
            {
                mvw_Mtab_x12_TradingPartner_summary = currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_837I),
                ClaimInstitutionalOutbounds = _context.VwClaimInstitutionalOutbounds.Where(CLM => CLM.X12_document_oid == X12_documentID).ToList(),
                ClaimInstitutionalServicesOutbounds = (from clm in _context.VwClaimInstitutionalOutbounds.Where(CLM => CLM.X12_document_oid == X12_documentID)
                                                       join srv in _context.VwClaimInstitutionalServicesOutbounds on clm.ClaimInstitutionalOutboundId equals srv.ClaimInstitutionalOutboundId
                                                       select srv).ToList(),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_837I_5010 && loop.RecordStatus == (int)RecordStatus.Active).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_837I_5010 && segment.RecordStatus == (int)RecordStatus.Active).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_837I_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                         .OrderBy(element => element.LoopGroup)
                                                         .ThenBy(element => element.SegmentSequence)
                                                         .ThenBy(element => element.SegmentoccurrenceSeq)
                                                         .ThenBy(element => element.ElementPosition)
                                                         .ThenBy(element => element.SubElementPosition).ToList()
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_interchange_id"></param>
        public void ClaimTrnasfer(int x12_interchange_id)
        {
            var parax12InterchangeId = new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12_interchange_id);
            _context.Database.ExecuteSqlRaw(EDI837IStructure.uspMup837ITransfer, parax12InterchangeId);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isa09_interchange_date"></param>
        /// <param name="isa10_interchange_time"></param>
        /// <param name="gs04_date"></param>
        /// <param name="gs05_time"></param>
        /// <param name="filetype"></param>
        /// <param name="Client_id"></param>
        /// <param name="Company_id"></param>
        /// <returns></returns>
        public List<FileExists> IsFileExists(string isa09_interchange_date, string isa10_interchange_time, string isa13_control_no, string gs04_date, string gs05_time, CurrentTradingPartner objtp)
        {
            try
            {
                var parameters = new List<SqlParameter>
            {
                    new SqlParameter("@" + x12_interchangeStructure.ISA09_INTERCHANGE_DATE, isa09_interchange_date),
                    new SqlParameter("@" + x12_interchangeStructure.ISA10_INTERCHANGE_TIME, isa10_interchange_time),
                    new SqlParameter("@" + x12_interchangeStructure.ISA13_CONTROL_NO, isa13_control_no),
                    new SqlParameter("@" + EDI837PStructure.GS04_DATE,gs04_date) ,
                    new SqlParameter("@" + EDI837PStructure.GS05_TIME, gs05_time),
                    new SqlParameter("@" + EDI837PStructure.FILETYPE,objtp.CurTradingPartner.Module_Name),
                    new SqlParameter("@" + EDI837PStructure.TRADINGPARTNERID,objtp.CurTradingPartner.TradingPartnerId),
                    new SqlParameter("@" + EDI837PStructure.DATAFILECONFIGURATIONID,objtp.CurTradingPartner.DataFileConfigurationID)
                    //new SqlParameter("@" + EDI837PStructure.CLIENT_ID,Client_id),
                    //new SqlParameter("@" + EDI837PStructure.COMPANY_ID,Company_id)
             };
                return _context.ExecuteStoreProcedure<FileExists>(EDI837PStructure.uspValidateDuplicateFile, parameters.ToArray()).ToList();
            }
            catch
            {
                throw;
            }
        }


        #region HPS
        public IQueryable<EDI837PUploadFileModel> GetEdi837IFilesList()
        {
            return (from Doc in _context.Vw837IFileSummary
                    select new EDI837PUploadFileModel
                    {
                        FileID = Doc.FileID,
                        FileName = Doc.FileName,
                        TradingPartnerID = Doc.TradingPartnerID,
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        FileStatus = Doc.FileStatus,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        Total = Doc.Total,
                        Pending = Doc.Pending,
                        InProgress = Doc.InProgress,
                        Posted = Doc.Posted,
                        Failed = Doc.Failed,
                        BilledAmount = Doc.BilledAmount,
                        Version = Doc.Version,
                        HasError = Doc.Error == true ? "Yes" : "No"
                    });
        }

        public IQueryable<EDI837PClaimModel> GetEdi837IClaimsList()
        {
            return (from Clm in _context.VwInstitutionalClaimSummary
                    select new EDI837PClaimModel
                    {
                        ClaimID = Clm.ClaimID,
                        FileID = Clm.FileID,
                        TradingPartnerID = Clm.TradingPartnerID,
                        ClaimNo = Clm.ClaimNo,
                        MemberID = Clm.MemberID,
                        DOB = Clm.DOB.Value,
                        Name = Clm.Name,
                        Billed = Clm.Billed,
                        ClaimStatus = Clm.ClaimStatus.Value,
                        PatientControlNumber = Clm.PatientControlNumber,
                        RenderingProvider = Clm.RenderingProvider,
                        BillingProvider = Clm.BillingProvider,
                        BillingProviderNPI = Clm.BillingProviderNPI,
                        Billtype = Clm.Billtype,
                        UploadedDate = Clm.UploadedDate.Value,
                        ClaimErrorCount = Clm.ClaimErrorCount.Value,
                        ClaimErrorMsg = Clm.ClaimErrorMsg,
                        HasError = Clm.ClaimErrorCount > 0 ? "Yes" : "No"
                    });
            //join doc in _context.X12Document on Clm.X12DocumentId equals doc.X12DocumentId
            //join trad in _context.TradingPartner on doc.TradingPartnerId equals trad.TradingPartnerId

            //join CLMError in
            //(from M in _context.MtabMError
            // join D in _context.ClaimProfessionalError
            // on M.ErrorId equals D.ErrorId

            // group M.ErrorDescLong by D.ClaimProfessionalErrorId into g
            // select new
            // {
            //     Claimid = g.Key,
            //     ErrorCount = g.Count(),
            //     ErrorMSg = string.Join(",", g.ToArray())
            // }
            //  )
            //  on Clm.ClaimInstitutionalID equals CLMError.Claimid into CLMErrordata
            //from CLMError in CLMErrordata.DefaultIfEmpty()
            //where doc.RecordStatus == (int)RecordStatus.Active
            //&& doc.Filetype == "837I"

            //select new EDI837PClaimModel
            //{
            //    ClaimID = Clm.ClaimInstitutionalID,
            //    FileID = Clm.X12DocumentId,
            //    TradingPartnerID = trad.TradingPartnerName,
            //    ClaimNo = Clm.ClaimReferenceNo,
            //    MemberID = Clm.L2010baNm109SubscriberId,
            //    DOB = Clm.L2010baDmg02SubscriberDob,
            //    Name = Clm.L2010baNm103SubscriberLastNm + ", " + Clm.L2010baNm104SubscriberFirstNm,
            //    Billed = Clm.L2300Clm02TotalClaimChgAmt,
            //    ClaimStatus = Clm.ClaimStatus,
            //    PatientControlNumber = Clm.L2300Clm01PtAcctNum,
            //    RenderingProvider = Clm.L2310aNm103AttendingProvLastNm + ", " + Clm.L2310aNm104AttendingProvFirstNm,
            //    UploadedDate = Clm.CreatedDate,
            //    ClaimErrorCount = CLMError != null ? CLMError.ErrorCount : 0,
            //    ClaimErrorMsg = CLMError != null ? CLMError.ErrorMSg : ""

            //});
        }


        public bool DeleteClaimByFileID(List<int> Files, string strUserName, DateTime date)
        {
            try
            {
                _context.X12Document.Where(e => Files.Contains(e.X12DocumentId)).ToList()
                   .ForEach(a =>
                   {
                       a.RecordStatus = (int)RecordStatus.Deleted;
                       a.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                       a.UpdatedBy = strUserName;
                       a.UpdatedDate = date;
                   });

                _context.ClaimInstitutional.Where(x => Files.Contains(x.X12DocumentId)).ToList()
                   .ForEach(a =>
                   {
                       a.RecordStatus = (int)RecordStatus.Deleted;
                       a.RecordStatusChangeComment = RecordStatus.Deleted.ToString();
                       a.UpdatedBy = strUserName;
                       a.UpdatedDate = date;
                   });

                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
            }

        }

        public List<vwClaimProfessionalError> GetInstitutionalClaimError(int ClaimInstitutionalId)
        {
            var paraClaimProfessionalId = new List<SqlParameter> { new SqlParameter("@" + EDI837IStructure.CLAIMINSTITUTIONALID, ClaimInstitutionalId) };
            return _context.ExecuteStoreProcedure<vwClaimProfessionalError>(EDI837IStructure.GETINSTITUTIONALCLAIMERROR, paraClaimProfessionalId.ToArray()).ToList();
        }
        public List<vwClaimProfessionalError> GetInstitutionalClaimErrorHistory(int ClaimInstitutionalId)
        {
            var paraClaimProfessionalId = new List<SqlParameter> { new SqlParameter("@" + EDI837IStructure.CLAIMINSTITUTIONALID, ClaimInstitutionalId) };
            return _context.ExecuteStoreProcedure<vwClaimProfessionalError>(EDI837IStructure.GETINSTITUTIONALCLAIMERRORHISTORY, paraClaimProfessionalId.ToArray()).ToList();
        }

        #region claim edit detail
        public ClaimInstitutional GetClaimInstitutional(int ClaimInstitutionalID)
        {
            return _context.ClaimInstitutional
                   // .Include("InstitutionalDiagnosisCode")
                   .Where(x => x.ClaimInstitutionalId == ClaimInstitutionalID)
                   .SingleOrDefault();
        }
        public ClaimInstitutionalServices GetClaimInstitutionalServices(int? Claimid, int? ServiceId)
        {
            var q = (from a in _context.ClaimInstitutionalServices select a);
            if (Claimid != 0)
            {
                q = q.Where(b => b.ClaimInstitutionalId == Claimid); ;
            }
            if (ServiceId != 0)
            {
                q = q.Where(b => b.Id == ServiceId);
            }

            return q.SingleOrDefault();
        }
        public bool SaveClaimDetail(ClaimInstitutional ClaimDetail, bool isApplySameFix)
        {
            if (isApplySameFix)
            {
                object[] paraMemberEligibility =    {
                        new SqlParameter("@ClaimInstitutionalId", ClaimDetail.ClaimInstitutionalId),
                        new SqlParameter("@L2010BA_nm109_subscriber_id", ClaimDetail.L2010baNm109SubscriberId),
                        new SqlParameter("@L2010AA_nm109_billing_prov_id", ClaimDetail.L2010aaNm109BillingProvId),
                        new SqlParameter("@UpdatedBy", ClaimDetail.UpdatedBy),
                        new SqlParameter("@UpdatedDate", ClaimDetail.UpdatedDate)   };

                _context.Database.ExecuteSqlRaw("edi.usp_ApplySameFixInstitutionalClaim @ClaimProfessionalId, @L2010BA_nm109_subscriber_id, @L2010AA_nm109_billing_prov_id, @UpdatedBy, @UpdatedDate", paraMemberEligibility);
            }


            _context.Update(ClaimDetail);
            _context.SaveChanges();
            return true;
        }
        public bool SaveClaimDetailServiceLine(ClaimInstitutionalServices ClaimInstitutionalServices)
        {
            _context.Update(ClaimInstitutionalServices);
            _context.SaveChanges();
            return true;
        }
        public bool AddClaimDetailServiceLine(ClaimInstitutionalServices ClaimInstitutionalServices)
        {
            _context.Add(ClaimInstitutionalServices);
            _context.SaveChanges();
            return true;
        }
        #endregion
        #endregion

        #region Claim Submission To HPS
        public List<ClaimInstitutional> GetPendingInstitutionalClaim(int NumberOfclaim)
        {
            var PendingClaim = (from clm in _context.ClaimInstitutional
                                    .Include(srv => srv.ClaimInstitutionalServices)
                                    .Include(d => d.InstitutionalDiagnosisCode)
                                where clm.ClaimStatus == 0 && clm.RecordStatus == (int)RecordStatus.Active
                                select clm).Take(NumberOfclaim).ToList();

            PendingClaim.ForEach(clm => { clm.ClaimStatus = 201; });

            _context.SaveChanges();

            return PendingClaim;
        }
        public void UpdateClaimStatus(int ClaimInstitutionalID, int ClaimStatus, DateTime UpdatedDate, string ClaimReferenceNo)
        {
            var Claim = _context.ClaimInstitutional.FirstOrDefault(clm => clm.ClaimInstitutionalId == ClaimInstitutionalID);
            Claim.ClaimStatus = ClaimStatus;
            Claim.UpdatedDate = UpdatedDate;
            Claim.ClaimReferenceNo = ClaimReferenceNo;
            _context.SaveChanges();
        }
        #endregion
    }
}
