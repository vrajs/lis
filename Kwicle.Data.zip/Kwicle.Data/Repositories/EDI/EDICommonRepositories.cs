﻿using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.EDI
{
    public class EDICommonRepositories : IEDICommonRepositories
    {
        private readonly DataImportContext _context;
        public EDICommonRepositories(DataImportContext context)
        {
            _context = context;
        }

        public void Dispose()
        {

        }
        public vwMemberAlertDocument GetDocument(int Docmentid, string DownloadType)
        {
            object[] paraMemberEligibility = {
                    new SqlParameter("@" + x12DocumentCons.X12_DOCUMENT_ID, Docmentid) {SqlDbType = System.Data.SqlDbType.Int},
                     new SqlParameter("@" + x12DocumentCons.Downloadtype, DownloadType) {SqlDbType = System.Data.SqlDbType.VarChar}
                };
            return _context.ExecuteStoreProcedure<vwMemberAlertDocument>(EDICommon.USP_GetmemberAlertDocument, paraMemberEligibility).ToList().FirstOrDefault();
        }
        public EDIFIle GetEDIFileDetail(int Docmentid)
        {
            return (from a in _context.X12Document
                    join b in _context.DataFileConfiguration on new { a1 = a.TradingPartnerId, a2 = a.DataFileConfigurationID }
                    equals new { a1 = b.TradingPartnerId, a2 = b.DataFileConfigurationId }

                    where a.X12DocumentId == Docmentid && b.RecordStatus == (int)RecordStatus.Active
                    && a.RecordStatus == (int)RecordStatus.Active
                    select new EDIFIle
                    {
                        FileName = a.Filename,
                        FilePath = b.ProcessPath
                    }
                    ).SingleOrDefault();
        }
    }
}
