﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Data.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;


namespace Kwicle.Data.Repositories.EDI
{
    public class EdiHPSRepositories : Disposable, IEdiHPSRepositories
    {
        private readonly KwicleContext _hpscontext;
        private readonly KwicleViewContext _hpsviewcontext;

        public EdiHPSRepositories(KwicleContext hpscontext, KwicleViewContext hpsviewcontext)
        {
            _hpscontext = hpscontext;
            _hpsviewcontext = hpsviewcontext;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="EdiMemberLookupSearchPara"></param>
        /// <returns></returns>
        public EdiMemberMatched GetMemberId(EdiMemberLookupSearch EdiMemberLookupSearchPara)
        {
            var paraMemberEligibility = new List<SqlParameter>() {
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM109_SUBSCRIBER_ID,EdiMemberLookupSearchPara.MemberID ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_REF02_SY_SUBSCRIBER_SUP_ID,EdiMemberLookupSearchPara.SSN ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM103_SUBSCRIBER_LAST_NM,EdiMemberLookupSearchPara.LastName ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM104_SUBSCRIBER_FIRST_NM,EdiMemberLookupSearchPara.FirstName ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM105_SUBSCRIBER_MIDDLE_NM,EdiMemberLookupSearchPara.MiddleName ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_DMG02_SUBSCRIBER_DOB,EdiMemberLookupSearchPara.Dob ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_DMG03_SUBSCRIBER_GENDER,EdiMemberLookupSearchPara.Gender ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.EFFECTIVEDATE,EdiMemberLookupSearchPara.EffectiveDate ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.TERMDATE,EdiMemberLookupSearchPara.TermDate ?? (object)DBNull.Value)
            };

            var Member = _hpscontext.ExecuteStoreProcedure<EdiMemberMatched>(EDI837PStructure.usp_GetMemberId, paraMemberEligibility.ToArray()).FirstOrDefault();

            return Member;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="EdiProviderLookupSearchPara"></param>
        /// <returns></returns>
        public EdiProviderMatched GetProviderID(EdiProviderLookupSearch EdiProviderLookupSearchPara)
        {
            EdiProviderMatched Provider = new EdiProviderMatched();
            object[] paraGetProvider = {
                new SqlParameter("@"+ EDI837PStructure.ProviderNPI, string.IsNullOrEmpty(EdiProviderLookupSearchPara.ProviderNPI) ? (object)DBNull.Value : (object)EdiProviderLookupSearchPara.ProviderNPI),
                new SqlParameter("@"+ EDI837PStructure.ProviderTin, string.IsNullOrEmpty(EdiProviderLookupSearchPara.ProviderTin) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.ProviderTin),
                new SqlParameter("@" + EDI837PStructure.ProviderSSN, string.IsNullOrEmpty(EdiProviderLookupSearchPara.ProviderSSN) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.ProviderSSN),
                new SqlParameter("@" + EDI837PStructure.ProviderLastName, string.IsNullOrEmpty(EdiProviderLookupSearchPara.ProviderLastName) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.ProviderLastName),
                new SqlParameter("@" + EDI837PStructure.ProviderFirstName, string.IsNullOrEmpty(EdiProviderLookupSearchPara.ProviderFirstName) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.ProviderFirstName),
                new SqlParameter("@" + EDI837PStructure.PhysicianNPI, string.IsNullOrEmpty(EdiProviderLookupSearchPara.PhysicianNPI) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.PhysicianNPI),
                new SqlParameter("@" + EDI837PStructure.PhysicianLastName, string.IsNullOrEmpty(EdiProviderLookupSearchPara.PhysicianLastName) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.PhysicianLastName),
                new SqlParameter("@" + EDI837PStructure.PhysicianFirstName, string.IsNullOrEmpty(EdiProviderLookupSearchPara.PhysicianFirstName) ? (object)DBNull.Value:(object)EdiProviderLookupSearchPara.PhysicianFirstName),
                new SqlParameter("@" + EDI837PStructure.ProviderId, SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@" + EDI837PStructure.PhysicianId, SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@" + EDI837PStructure.ProviderPhysicianAssociation, SqlDbType.Bit) { Direction = ParameterDirection.Output }
            };

            _hpscontext.Database.ExecuteSqlRaw(EDI837PStructure.usp_GetProviderId, paraGetProvider);

            if (((SqlParameter)paraGetProvider[8]).Value != DBNull.Value)
                Provider.ProviderID = Convert.ToInt32(((SqlParameter)paraGetProvider[8]).Value);

            if (((SqlParameter)paraGetProvider[9]).Value != DBNull.Value)
                Provider.PhysicianID = Convert.ToInt32(((SqlParameter)paraGetProvider[9]).Value);

            if (((SqlParameter)paraGetProvider[10]).Value != DBNull.Value)
                Provider.ProviderPhysicianAssociation = Convert.ToBoolean(((SqlParameter)paraGetProvider[10]).Value);

            if (!string.IsNullOrEmpty(EdiProviderLookupSearchPara.PhysicianLastName))
                Provider.IsPhysicianExits = true;

            return Provider;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="EdiMemberLookupSearchPara"></param>
        /// <returns></returns>
        public EDI271Validatemodel GetMemberEligiblityValidate(EdiMemberLookupSearch EdiMemberLookupSearchPara)
        {
            var para = new SqlParameter[] {
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM109_SUBSCRIBER_ID,EdiMemberLookupSearchPara.MemberID ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_REF02_SY_SUBSCRIBER_SUP_ID,EdiMemberLookupSearchPara.SSN ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM103_SUBSCRIBER_LAST_NM,EdiMemberLookupSearchPara.LastName ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM104_SUBSCRIBER_FIRST_NM,EdiMemberLookupSearchPara.FirstName ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_NM105_SUBSCRIBER_MIDDLE_NM,EdiMemberLookupSearchPara.MiddleName ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_DMG02_SUBSCRIBER_DOB,EdiMemberLookupSearchPara.Dob ?? (object)DBNull.Value),
                new SqlParameter("@"+ EDI837PStructure.L2010BA_DMG03_SUBSCRIBER_GENDER,EdiMemberLookupSearchPara.Gender ?? (object)DBNull.Value)
            };
            return _hpscontext.ExecuteStoreProcedure<EDI271Validatemodel>(EDI271MemberEligibilityStructure.usp_GetMemberEligibilityValidate, para).FirstOrDefault();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="EdiMemberLookupSearchPara"></param>
        /// <returns></returns>
        public List<vwEligibilityResponse> GetMemberEligiblityBenefitInformation(int MemberID)
        {
            return _hpsviewcontext.GetEligibilityResponse.Where(e => e.MemberID == MemberID).ToList();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objModel"></param>
        /// <returns></returns>
        public ImportRemittanceAdviceModel GetRemittanceAdvice(ImportRemittanceAdviceModel objModel)
        {
            objModel.ClaimheaderIds = _hpscontext.ClaimHeaders.Where(x => x.ClaimStatusID == (int)ClaimStatus.Paid).Select(o => o.ClaimHeaderID).ToArray();
            #region RemittanceAdviceChecklist          
            objModel.RemittanceAdviceChecklist = (from o in _hpsviewcontext.GetRemittanceAdviceCheck
                                                  select new EDI835RemittanceAdviceCheckModel
                                                  {                                                      
                                                      BPR02_Total_prov_pmt_amt = o.BPR02_Total_prov_pmt_amt,                                                      
                                                      BPR06_Sender_dfi_id_qual = o.BPR06_Sender_dfi_id_qual,
                                                      BPR07_Sender_dfi_id = o.BPR07_Sender_dfi_id,
                                                      BPR08_Sender_account_num_qual = o.BPR08_Sender_account_num_qual,
                                                      BPR09_Sender_account_num = o.BPR09_Sender_account_num,
                                                      BPR10_Payer_id = o.BPR10_Payer_id,
                                                      BPR11_Orig_co_supp_code = o.BPR11_Orig_co_supp_code,
                                                      BPR12_Receiver_dfi_id_qual = o.BPR12_Receiver_dfi_id_qual,
                                                      BPR13_Receiver_dfi_id = o.BPR13_Receiver_dfi_id,
                                                      BPR14_Receiver_account_num_qual = o.BPR14_Receiver_account_num_qual,
                                                      BPR15_Receiver_account_num = o.BPR15_Receiver_account_num,
                                                      BPR16_Check_date = o.BPR16_Check_date,
                                                      TRN02_Trace_number = o.TRN02_Trace_number,
                                                      TRN03_Payer_id = o.TRN03_Payer_id,                                                                                                            
                                                      DTM02_Production_date = o.DTM02_Production_date,
                                                      L1000A_N102_Payer_nm = o.L1000A_N102_Payer_nm,
                                                      L1000A_N104_Payer_id = o.L1000A_N104_Payer_id,
                                                      L1000A_N301_Payer_address1 = o.L1000A_N301_Payer_address1,
                                                      L1000A_N401_Payer_city = o.L1000A_N401_Payer_city,
                                                      L1000A_N402_Payer_state = o.L1000A_N402_Payer_state,
                                                      L1000A_N403_Payer_zip = o.L1000A_N403_Payer_zip,
                                                      L1000A_REF01_2U_PayerIdentificationQua = o.L1000A_REF01_2U_PayerIdentificationQua,                                                      
                                                      L1000B_N102_Payee_nm = o.L1000B_N102_Payee_nm,
                                                      L1000B_N103_payee_id_qual = o.L1000B_N103_payee_id_qual,
                                                      L1000B_N104_payee_id = o.L1000B_N104_payee_id,
                                                      L1000B_N301_payee_address1 = o.L1000B_N301_payee_address1,
                                                      L1000B_N401_payee_city = o.L1000B_N401_payee_city,
                                                      L1000B_N402_payee_state = o.L1000B_N402_payee_state,
                                                      L1000B_N403_payee_zip = o.L1000B_N403_payee_zip,                                                      
                                                      L1000B_REF01_TJ_TaxIdQua = o.L1000B_REF01_TJ_TaxIdQua                                                      
                                                  }).ToList();
            #endregion

            #region RemittanceAdviceClaimlist


            objModel.RemittanceAdviceClaimlist = (from o in _hpsviewcontext.GetRemittanceAdviceClaim
                                                  where objModel.ClaimheaderIds.Contains(o.ClaimHeaderID)
                                                  select new EDI835RemittanceAdviceClaimModel
                                                  {
                                                      ClaimHeaderID = o.ClaimHeaderID,
                                                      CheckNumber = o.CheckNumber,
                                                      L2100_clp01_pt_control_no = o.PatientAccountNumber,
                                                      L2100_clp03_total_claim_chg_amt = o.BilledAmount,
                                                      L2100_clp04_claim_pmt_amt = o.PaidAmount,
                                                      L2100_clp07_payer_claim_control_no = o.ClaimNumber,
                                                      L2100_clp09_claim_freq_code = o.L2100_clp09_claim_freq_code,
                                                      L2100_nm103_IL_subscriber_last_nm = o.PatientLastName,
                                                      L2100_nm104_IL_subscriber_first_nm = o.PatientFirstName,
                                                      L2100_nm109_IL_subscriber_id = o.PatientID,
                                                      L2100_nm103_Insured_LastName = o.MemberLastName,
                                                      L2100_nm104_Insured_FirstName = o.MemberFirstName,
                                                      L2100_nm109_Insured_ID = o.MemberID,
                                                      L2100_dtm050_ClaimReceivedDate = o.ReceivedDate
                                                  }
                                                  )
                                                  .ToList();
            #endregion

            #region RemittanceAdviceServicelist          
            objModel.RemittanceAdviceServicelist = (from srv in _hpsviewcontext.GetRemittanceAdviceService
                                                    where objModel.ClaimheaderIds.Contains(srv.ClaimHeaderID)
                                                    select new EDI835RemittanceAdviceServiceModel
                                                    {
                                                        ClaimHeaderID = srv.ClaimHeaderID,
                                                        ClaimNumber = srv.ClaimNumber,
                                                        L2110_svc01_proc_code = srv.ProcedureCode,
                                                        L2110_svc01_proc_mod1 = srv.Modifiers1,
                                                        L2110_svc01_proc_mod2 = srv.Modifiers2,
                                                        L2110_svc01_proc_mod3 = srv.Modifiers3,
                                                        L2110_svc01_proc_mod4 = srv.Modifiers4,
                                                        L2110_svc02_charge_amt = srv.BilledAmount,
                                                        L2110_svc03_provider_pmt_amt = srv.PaidAmount,
                                                        L2110_svc04_ub_rev_code = srv.RevenueCode,
                                                        L2110_svc05_units_paid = srv.Unit,
                                                        L2110_dtm02_150_service_date = srv.DOSFrom,
                                                        L2110_dtm02_151_service_date = srv.DOSTO,
                                                        L2110_1_cas03_adj_amt = srv.DeductibleAmount,
                                                        L2110_2_cas03_adj_amt = srv.CopayAmount,
                                                        L2110_3_cas03_adj_amt = srv.CoinsuranceAmount,
                                                        L2110_4_cas03_adj_amt = srv.NonCoveredAmount,
                                                        L2110_5_cas03_adj_amt = srv.DifferenceAmount,
                                                        L2100_clp08_facility_type_code = srv.POSCode,
                                                        L2100_AMT01_I_Amount = srv.InterestAmount,
                                                        L2110_ref02_6R_LineControlNumber = srv.LineNumber,
                                                        L2110_ref02_HPI_RenderingProviderNPI = srv.RenderingProviderNPI,
                                                    })
                                                   .ToList();
            #endregion
            return objModel;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CalenderDateID"></param>
        /// <param name="TradingPartnerID"></param>
        /// <returns></returns>
        public List<vwMemberBenefitEnrollment> GetMemberBenefitEnrollment(int CalenderDateID, string TradingPartnerID)
        {
            return _hpsviewcontext.GetMemberBenefitEnrollment.Where(x => x.CalenderDateID == CalenderDateID && x.TradingPartnerID == TradingPartnerID).ToList();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<TradingPartnerBenefitConfigurationModel> GetPlanBenefitCode()
        {
            return (from ben in _hpsviewcontext.GetPlanBenefit
                    select new TradingPartnerBenefitConfigurationModel
                    {
                        TradingPartnerBenefitConfigurationId = ben.TradingPartnerBenefitConfigurationId,
                        HealthPlanID = ben.HealthPlanID,
                        PlanName = ben.PlanName,
                        PlanCode = ben.PlanCode,
                        BenefitHeaderID = ben.BenefitHeaderID,
                        BenefitName = ben.BenefitName,
                        BenefitCode = ben.BenefitCode,
                        CoverageLevelCode = ben.CoverageLevelCode,
                        ServiceCode = ben.ServiceCode,
                        InsuranceTypeCode = ben.InsuranceTypeCode,
                        TimePeriodQualifier = ben.TimePeriodQualifier,
                        QuantityQualifier = ben.QuantityQualifier,
                        Network = ben.Network,
                    });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TradingPartnerBenefitConfigurationModel"></param>
        public void AddOrUpdate(TradingPartnerBenefitConfiguration TradingPartnerBenefitConfigurationModel)
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<DbColumnInfo> GetTableSchema<T>()
        {
            return _hpsviewcontext.GetTableSchema<T>();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<vwMemberPCP> GetMemberPCP()
        {
            return _hpsviewcontext.GetMemberPCP;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IQueryable<HealthPlanDeductible> GetHealthPlanDeductible()
        {
            return _hpscontext.HealthPlanDeductibles;
        }
    }
}
