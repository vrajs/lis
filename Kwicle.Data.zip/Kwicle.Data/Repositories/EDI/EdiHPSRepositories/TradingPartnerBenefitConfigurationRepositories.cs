﻿using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Repositories.EDI
{
    public class TradingPartnerBenefitConfigurationRepositories: BaseRepository<TradingPartnerBenefitConfiguration>, ITradingPartnerBenefitConfigurationRepositories
    {
        #region Variables
        private readonly KwicleContext _context;

        #endregion

        #region Ctor
        public TradingPartnerBenefitConfigurationRepositories(KwicleContext context) : base(context)
        {
            _context = context;

        }

        #endregion
    }
}
