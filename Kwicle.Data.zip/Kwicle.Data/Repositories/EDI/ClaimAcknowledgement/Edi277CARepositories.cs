﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.Entities.EDI;
using System.Linq;
using Kwicle.Core.Common;
using System.Collections.Generic;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi277CARepositories : Disposable, IEdi277CARepositories
    {
        private readonly DataImportContext _context;        
        public Edi277CARepositories(DataImportContext context)
        {
            _context = context;            
        }
        public Edi277CAClaimStatusAcknowledgement GetEdi277CADetails(int x12InterchangeId)
        {
            //var parax12InterchangeId = new SqlParameter("@" + Edi277CAClaimStatusAckStructure.x12_interchange_id, x12InterchangeId);

            Edi277CAClaimStatusAcknowledgement edi277ClaimStatusResponse = new Edi277CAClaimStatusAcknowledgement
            {
                x12_transaction_schema = _context.X12TransactionSchema.FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_277CA),
                //ToDo: Vic-Core2Change Uncomment 
                x12_277CA_ClaimAck = _context.VWX12_277CA_ClaimAcks.Where(clm => clm.x12_document_id == x12InterchangeId) .ToList(),
                mvw_Mtab_x12_TradingPartner_summary = (from Doc in _context.X12Document
                                                       join ISA in _context.X12Interchange on Doc.X12DocumentUid equals ISA.X12InterchangeUid
                                                       join GS in _context.X12FunctionalGroup on ISA.X12InterchangeId equals GS.X12InterchangeId
                                                       where Doc.X12DocumentId == x12InterchangeId
                                                       select new Core.Entities.EDI.View.vwTradingPartnerSummary
                                                       {
                                                           isa01_auth_info_qual = ISA.Isa01AuthInfoQual,
                                                           isa02_auth_info = ISA.Isa02AuthInfo.PadLeft(10,' '),
                                                           isa03_security_info_qual = ISA.Isa03SecurityInfoQual,
                                                           isa04_security_info = ISA.Isa04SecurityInfo.PadLeft(10, ' '),
                                                           isa05_sender_id_qual = ISA.Isa05SenderIdQual,
                                                           isa06_sender_id_live = ISA.Isa06SenderId,
                                                           isa07_receiver_id_qual = ISA.Isa07ReceiverIdQual,
                                                           isa08_receiver_id = ISA.Isa08ReceiverId,
                                                           isa14_ack_requested = ISA.Isa14AckRequested,
                                                           isa15_usage_indicator = ISA.Isa15UsageIndicator,
                                                           isa16_component_element_seperator = ISA.Isa16ComponentElementSeperator,
                                                           gs02_app_sender_code =GS.Gs02AppSenderCode,
                                                           gs03_app_receiver_code = GS.Gs03AppReceiverCode,
                                                           element_separator = ISA.ElementSeparator,
                                                           segment_separator = ISA.SegmentSeparator
                                                       }
                                                       ).FirstOrDefault(),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_277CA_5010 && loop.RecordStatus == (int)RecordStatus.Active).OrderBy(loop => loop.LoopSequence).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_277CA_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                           .OrderBy(segment => segment.LoopGroup)
                                                           .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_277CA_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(element => element.LoopGroup)
                                                          .ThenBy(element => element.SegmentSequence)
                                                          .ThenBy(element => element.SegmentoccurrenceSeq)
                                                          .ThenBy(element => element.ElementPosition)
                                                          .ThenBy(element => element.SubElementPosition).ToList()
            };

            //Retrive Logic


            //_context.Database.GetDbConnection().Open();
            //var cmd = _context.Database.GetDbConnection().CreateCommand();
            //cmd.CommandText = Edi277CAClaimStatusAckStructure.Usp_Get277DetailById;
            //cmd.Parameters.Add(parax12InterchangeId);
            //var reader = cmd.ExecuteReader();

            ////////edi277ClaimStatusResponse.x12_transaction_schema = ((IObjectContextAdapter)_context).ObjectContext.Translate<X12TransactionSchema>(reader).FirstOrDefault();

            ////////reader.NextResult();
            ////////edi277ClaimStatusResponse.x12_277CA_ClaimAck = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<vwX12_277CA_ClaimAck>(reader).ToList();

            ////////reader.NextResult();
            ////////edi277ClaimStatusResponse.Loops = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<Loops>(reader).ToList();

            ////////reader.NextResult();
            ////////edi277ClaimStatusResponse.Segments = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<Segments>(reader).ToList();

            ////////reader.NextResult();
            ////////edi277ClaimStatusResponse.Elements = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<Elements>(reader).ToList();


            return edi277ClaimStatusResponse;
        }

        public void AddClaimStatus(int x12_document_id, int ClaimId)
        {
            var parameters = new List<SqlParameter>
            {
                    new SqlParameter("@" + Edi277CAClaimStatusAckStructure.x12_document_id, x12_document_id),
                    new SqlParameter("@" + Edi277CAClaimStatusAckStructure.ClaimProfessionalId,ClaimId)                     
            };
            
            _context.Database.ExecuteSqlRaw(Edi277CAClaimStatusAckStructure.uspAddClaimStatusAck, parameters.ToArray());
        }

        public void UpdateRecordStatus(int x12_document_id)
        {
            var ClmAck = _context.X12277caClaimAck.Where(clm => clm.X12DocumentId == x12_document_id && clm.RecordStatus == (int)RecordStatus.Active).ToList();
            ClmAck.ForEach(clm => clm.RecordStatus = (int)RecordStatus.Termed);
            _context.SaveChanges();
        }
    }
}
