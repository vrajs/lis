﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Data.Contracts.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.EDI
{
    public class EdiErrorRepositories: IEdiErrorRepositories
    {
        private readonly DataImportContext _context;
        public EdiErrorRepositories(DataImportContext context)
        {
            _context = context;
        }

        public IQueryable<MtabMError> GetClaimErrorID(string ErrorMessage)
        {
            return _context.MtabMError.Where(err => err.ErrorDesc.Equals(ErrorMessage));
        }

        public int Add(MtabMError Error)
        {
            _context.MtabMError.Add(Error);
            _context.SaveChanges();

            return Error.ErrorId;
        }
    }
}
