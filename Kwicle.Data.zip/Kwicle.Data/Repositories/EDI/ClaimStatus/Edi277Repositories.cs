﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Xml.Linq;

namespace Kwicle.Data.Repositories.EDI
{

    public class Edi277Repositories : Disposable, IEdi277Repositories
    {
        private readonly DataImportContext _context;
        private readonly KwicleViewContext _viewContext;
        public Edi277Repositories(DataImportContext context, KwicleViewContext viewContext)
        {
            _context = context;
            _viewContext = viewContext;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12InterchangeId"></param>
        /// <param name="_currentTradingPartner"></param>
        /// <returns></returns>
        public Edi277ClaimStatusResponse GetEdi277Details(int X12DocumentID, CurrentTradingPartner _currentTradingPartner)
        {
            //var parax12InterchangeId = new SqlParameter("@" + Edi277ClaimStatusStructure.x12_interchange_id, x12InterchangeId);
            //Edi277ClaimStatusResponse edi277ClaimStatusResponse = new Edi277ClaimStatusResponse();

            //edi277ClaimStatusResponse.mvw_Mtab_x12_TradingPartner_summary = _currentTradingPartner.CurTradingPartner;


            //Retrive Logic
            //////////_ediDbContext.Database.Connection.Open();
            //////////var cmd = _ediDbContext.Database.Connection.CreateCommand();
            //////////cmd.CommandText = Edi277ClaimStatusStructure.Usp_Get277DetailById;
            //////////cmd.Parameters.Add(parax12InterchangeId);
            //////////var reader = cmd.ExecuteReader();

            //////////edi277ClaimStatusResponse.x12_transaction_schema = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<X12_transaction_schema>(reader).FirstOrDefault();

            //////////reader.NextResult();
            //////////edi277ClaimStatusResponse.ClaimStatusResponses = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<vwClaimStatusResponse>(reader).ToList();

            //////////reader.NextResult();
            //////////edi277ClaimStatusResponse.ClaimStatusResponseServices = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<vwClaimStatusResponseService>(reader).ToList();

            //////////reader.NextResult();
            //////////edi277ClaimStatusResponse.Loops = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<Loops>(reader).ToList();

            //////////reader.NextResult();
            //////////edi277ClaimStatusResponse.Segments = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<Segments>(reader).ToList();

            //////////reader.NextResult();
            //////////edi277ClaimStatusResponse.Elements = ((IObjectContextAdapter)_ediDbContext).ObjectContext.Translate<Elements>(reader).ToList();

            return new Edi277ClaimStatusResponse
            {
                mvw_Mtab_x12_TradingPartner_summary = _currentTradingPartner.CurTradingPartner,
                x12_transaction_schema = _context.X12TransactionSchema
                                                .FirstOrDefault(st => st.X12TransactionSchemaUd == transaction_schema.TRN_X12_5010_277),
                ClaimStatusResponses = _context.vw277ClaimStatusResponse.Where(x => x.x12_document_id == X12DocumentID).ToList(),

                ClaimStatusResponseServices = (from srv in _context.vwClaimStatusResponseService
                                               join clm in _context.vw277ClaimStatusResponse on srv.ClaimStatusResponseID equals clm.ID
                                               where clm.x12_document_id == X12DocumentID
                                               select srv
                                             ).ToList(),
                Loops = _context.Loops.Where(loop => loop.EdiFormat == EdiFormat.EDI_277_5010 && loop.RecordStatus == (int)RecordStatus.Active).ToList(),
                Segments = _context.Segments.Where(segment => segment.EdiFormat == EdiFormat.EDI_277_5010 && segment.RecordStatus == (int)RecordStatus.Active)
                                                           .OrderBy(segment => segment.LoopGroup)
                                                           .ThenBy(segment => segment.SegmentSequence).ToList(),
                Elements = _context.Elements.Where(element => element.EdiFormat == EdiFormat.EDI_277_5010 && element.RecordStatus == (int)RecordStatus.Active)
                                                          .OrderBy(element => element.LoopGroup)
                                                          .ThenBy(element => element.SegmentSequence)
                                                          .ThenBy(element => element.SegmentoccurrenceSeq)
                                                          .ThenBy(element => element.ElementPosition)
                                                          .ThenBy(element => element.SubElementPosition).ToList()
            };
        }

        public void ImportEDI277Data(int x12DocumentId, List<ClaimStatusResponseDetailModel> ClaimResponse)
        {
            XElement xmlClaimResponse = new XElement("ClaimResponses", from i in ClaimResponse
                                                                       select new XElement("ClaimResponse",
                                                                      new XElement("L2200D_STC011_ClaimStatusCategoryCode", i.L2200D_STC011_ClaimStatusCategoryCode),
                                                                      new XElement("L2200D_STC012_StatusCode", i.L2200D_STC012_StatusCode),
                                                                      new XElement("L2200D_STC013_EntityIdentifierCode", i.L2200D_STC013_EntityIdentifierCode),
                                                                      new XElement("L2200D_STC014_DrugRejectCode", i.L2200D_STC014_DrugRejectCode),
                                                                      new XElement("L2200D_STC02_EffectiveDate", i.L2200D_STC02_EffectiveDate),
                                                                      new XElement("L2200D_STC04_TotalCharge", i.L2200D_STC04_TotalCharge),
                                                                      new XElement("L2200D_STC05_ClaimPaidAmount", i.L2200D_STC05_ClaimPaidAmount),
                                                                      new XElement("L2200D_STC06_AdjudicationDate", i.L2200D_STC06_AdjudicationDate),
                                                                      new XElement("L2200D_STC08_RmittanceDate", i.L2200D_STC08_RmittanceDate),
                                                                      new XElement("L2200D_STC09_CheckNumber", i.L2200D_STC09_CheckNumber),
                                                                      new XElement("x12_276_ClaimStatus_RequestID", i.x12_276_ClaimStatus_RequestID)
                      ));
            
            var parax12InterchangeId = new List<SqlParameter>
            {
                new SqlParameter("@" + Edi277ClaimStatusStructure.X12_DOCUMENT_ID, x12DocumentId),
                new SqlParameter("@" + Edi277ClaimStatusStructure.xmlClaimResponse, xmlClaimResponse.ToString()){ DbType = System.Data.DbType.Xml}
            };
            _context.Database.ExecuteSqlRaw(Edi277ClaimStatusStructure.USPMUP277TRANSFER, parax12InterchangeId.ToArray());
        }

        public List<ClaimStatusRequestDetailModel> GetClaimStatusDetail(int x12DocumentId)
        {
            var parax12InterchangeId = new List<SqlParameter>
            {
                    new SqlParameter("@" + Edi277ClaimStatusStructure.X12_DOCUMENT_ID, x12DocumentId)
            };
            return _context.ExecuteStoreProcedure<ClaimStatusRequestDetailModel>(Edi277ClaimStatusStructure.GETCLAIMSTATUSDETAIL, parax12InterchangeId.ToArray()).ToList();
        }

        public List<ClaimHeaderDetails> GetHpsClaimStatusDetail(List<string> ClaimNumbers)
        {
            return (from clm in _viewContext.GetClaimStatus.Where(c => ClaimNumbers.Contains(c.ClaimNumber))
                    select new ClaimHeaderDetails
                    {
                        ClaimNumber = clm.ClaimNumber,
                        ClaimStatusID = clm.ClaimStatusID,
                        UpdatedDate = clm.UpdatedDate,
                        CreatedDate = clm.CreatedDate,
                        BilledAmount = clm.BilledAmount,
                        PaidAmount = clm.PaidAmount,
                        PaidDate = clm.PaidDate,
                        CheckDate = clm.CheckDate,
                        CheckNumber = clm.CheckNumber
                    }).ToList();
        }

        public IQueryable<ClaimStatusMapping> GetClaimStatusMapping()
        {
            return _context.ClaimStatusMappings;
        }
    }
}
