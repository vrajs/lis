﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Data.Contracts.EDI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kwicle.Data.Repositories.EDI
{
    public class Edi276Repositories : Disposable, IEdi276Repositories
    {
        private readonly DataImportContext _context;
        public Edi276Repositories(DataImportContext context)
        {
            _context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12_interchange_id"></param>
        public void Edi276Trnasfer(int x12_interchange_id)
        {
            var parax12InterchangeId = new SqlParameter("@" + x12_interchangeStructure.X12_INTERCHANGE_ID, x12_interchange_id);
            _context.Database.ExecuteSqlRaw(Edi276ClaimStatusStructure.MUP_X12_276_TRANSFER, parax12InterchangeId);
        }

        public IQueryable<EDI276UploadFileModel> GetEDI276UploadFiles()
        {
            return (from Doc in _context.Vw276FileSummary
                    where Doc.RecordStatus == (int)RecordStatus.Active
                    select new EDI276UploadFileModel
                    {
                        FileID = Doc.FileID,
                        FileName = Doc.FileName,
                        TradingPartnerID = Doc.TradingPartnerID,
                        CreatedBy = Doc.CreatedBy,
                        CreatedDate = Doc.CreatedDate,
                        FileStatus = Doc.FileStatus,
                        Error = Doc.Error,
                        ErrorMessage = Doc.ErrorMessage,
                        Total = Doc.Total,
                        Version = Doc.Version,
                        ResponseFileName = Doc.ResponseFileName
                    });
        }

        public IQueryable<EDI276ClaimSummaryModel> GetEDI276ClaimSummary()
        {
            return (from Doc in _context.vw276ClaimStatusSummary
                    select new EDI276ClaimSummaryModel
                    {
                        FileID = Doc.FileID,
                        Billed = Doc.Billed,
                        BillingProvider = Doc.BillingProvider,
                        BillingProviderNPI = Doc.BillingProviderNPI,
                        Billtype = Doc.Billtype,
                        ClaimID = Doc.ClaimID,
                        ClaimNo = Doc.ClaimNo,
                        DOB = Doc.DOB,
                        MemberID = Doc.MemberID,
                        Name = Doc.Name,
                        PatientControlNumber = Doc.PatientControlNumber,
                        UploadedDate = Doc.UploadedDate,
                        TradingPartnerID = Doc.TradingPartnerID
                    });
        }
    }
}
