﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Data.Contracts.EDI;
using Kwicle.Data.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.EDI
{
    public class EdiOutBoundConfiguration : BaseRepository<OutboundMappingconfiguration>, IEdiOutBoundConfiguration
    {
        private readonly DataImportContext _DataImportcontext;
        public EdiOutBoundConfiguration(DataImportContext DataImportcontext) : base(DataImportcontext)
        {
            _DataImportcontext = DataImportcontext;
        }
        public List<DbColumnInfo> GetTableSchema<T>()
        {
            return _DataImportcontext.GetTableSchema<T>();
        }

        public IQueryable<vwElementMappingSource> GetMappingSource()
        {
            return _DataImportcontext.GetElementMappingSource;
        }

        public IQueryable<vwOutboundMappingConfiguration> GetOutboundConfiguration()
        {
            return _DataImportcontext.GetOutboundMappingConfiguration
                .OrderBy(e => e.LoopGroup)
                .ThenBy(e=>e.Loop)
                .ThenBy(e => e.SegmentSequence)
                .ThenBy(e => e.SegmentoccurrenceSeq)
                .ThenBy(e => e.ElementPosition)
                .ThenBy(e => e.SubElementPosition);
        }

        public void AddMapping(OutboundMappingconfiguration MappingConfigurations)
        {
            _DataImportcontext.OutboundMappingconfigurations.Add(MappingConfigurations);
            _DataImportcontext.SaveChanges();
            //_DataImportcontext.BulkInsert(MappingConfigurations);
        }

        public IQueryable<Element> GetElement()
        {
            return _DataImportcontext.Elements;
        }
    }
}
