﻿using Kwicle.Data.Contracts;
using System.Linq;
using Kwicle.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories
{
    public class KwicleUserRepository : BaseRepository<KwicleUser>, IKwicleUserRepository
    {
        private readonly KwicleCoreContext _context;
        public KwicleUserRepository(KwicleCoreContext context) : base(context)
        {
            _context = context;
        }

        public KwicleUser GetUser(string userName)
        {
            return _context.Users
              .Include(u => u.Claims)
              .Include(u => u.Roles)
              .Where(u => u.UserName == userName)
              .Cast<KwicleUser>()
              .FirstOrDefault();

        }
        
    }
}
