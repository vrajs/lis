﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.Core;
using Kwicle.Data.Contracts.CoreModule;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.CoreModule
{
    public class RoleTypeClaimsRepository : BaseRepository<RoleTypeClaims> , IRoleTypeClaimsRepository
    {
        private readonly KwicleCoreContext _coreContex;

        public RoleTypeClaimsRepository(KwicleCoreContext coreContext) : base(coreContext)
        {
            _coreContex = coreContext;
        }

        public List<RoleTypeClaims> GetRoleTypeClaim()//short roleTypeID
        {
            //var query = (from c in _coreContex.RoleTypeClaims where c.RecordStatus == (int)RecordStatus.Active && c.RoleTypeID == roleTypeID
            //             select new RoleTypeClaims()
            //             {
            //                 RoleTypeClaimsID = c.RoleTypeClaimsID,
            //                 ModuleID = c.ModuleID,
            //                 MenuID = c.MenuID
            //                 RoleTypeID = c.RoleTypeID,
            //                 ClaimValue = c.ClaimValue,
            //                 Name = c.Name,
            //                 Description = c.Description
            //             });
            IQueryable<RoleTypeClaims> query = _coreContex.RoleTypeClaims.Where(x => x.RecordStatus == (int)RecordStatus.Active) //&& x.RoleTypeID == roleTypeID)
                                                .Include(r => r.Module)
                                                .Include(r => r.Menu);
            var res = query.ToList();
            return res;
        }
    }
}
