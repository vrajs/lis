﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Data.Models;
using Kwicle.Core.Entities.Core;
using Kwicle.Data.Contracts.CoreModule;

namespace Kwicle.Data.Repositories.CoreModule
{
    public class MenuRepository : BaseRepository<Menu>, IMenuRepository
    {
        private readonly KwicleCoreContext _coreCtx;
        public MenuRepository(KwicleCoreContext coreCtx) : base(coreCtx)
        {
            _coreCtx = coreCtx;
        }

        //public List<MenuList> GetMenu()
        //{
        //    var result = new List<MenuList>();
        //    var sublevel1 = new List<MenuList>();
        //    var sublevel2 = new List<MenuList>();
        //    //var sublevel3 = new List<MenuList>();

        //    var Parentmenu = (from mn in _coreCtx.Menus
        //                      where mn.SiteID == 8 && mn.ParentMenuID == 0 && mn.IsDeleted == false
        //                      select new Menu()
        //                      {
        //                          ID = mn.ID,
        //                          MenuName = mn.MenuName,
        //                          Icon = mn.Icon,
        //                          AngularTemplateUrl = mn.AngularTemplateUrl
        //                      }).ToList();
        //    if (Parentmenu.Count > 0)
        //    {
        //        foreach (var item in Parentmenu)
        //        {
        //            var level1 = (from lv1 in _coreCtx.Menus
        //                          where lv1.ParentMenuID == item.ID && lv1.IsDeleted == false
        //                          select new Menu()
        //                          {
        //                              ID = lv1.ID,
        //                              MenuName = lv1.MenuName,
        //                              Icon = lv1.Icon,
        //                              AngularTemplateUrl = lv1.AngularTemplateUrl
        //                          }).ToList();
        //            if (level1.Count > 0)
        //            {
        //                foreach (var item1 in level1)
        //                {
        //                    var level2 = (from lv2 in _coreCtx.Menus
        //                                  where lv2.ParentMenuID == item1.ID && lv2.IsDeleted == false
        //                                  select new Menu()
        //                                  {
        //                                      ID = lv2.ID,
        //                                      MenuName = lv2.MenuName,
        //                                      Icon = lv2.Icon,
        //                                      AngularTemplateUrl = lv2.AngularTemplateUrl
        //                                  }).ToList();
        //                    if (level2.Count > 0)
        //                    {
        //                        foreach (var item2 in level2)
        //                        {
        //                            var level3 = (from lv3 in _coreCtx.Menus
        //                                          where lv3.ParentMenuID == item2.ID && lv3.IsDeleted == false
        //                                          select new MenuList()
        //                                          {
        //                                              //ID = lv3.ID,
        //                                              text = lv3.MenuName,
        //                                              icon = lv3.Icon,
        //                                              route = lv3.AngularTemplateUrl,
        //                                              submenu = null
        //                                          }).ToList();
        //                            sublevel2.Add(new MenuList { text = item2.MenuName, icon = item2.Icon, route = item2.AngularTemplateUrl, submenu = level3 });

        //                        }
        //                    }
        //                    sublevel1.Add(new MenuList { text = item1.MenuName, icon = item1.Icon, route = item1.AngularTemplateUrl, submenu = sublevel2 });
        //                    sublevel2 = new List<MenuList>();
        //                }
        //            }
        //            result.Add(new MenuList { text = item.MenuName, icon = item.Icon, route = item.AngularTemplateUrl, submenu = sublevel1 });
        //            sublevel1 = new List<MenuList>();

        //        }
        //    }
        //    return result;
        //}
        
        public List<MenuModel> GetMenu()
        {
            //var result = new List<MenuList>();
            List<Menu> AllMenu = (from mn in _coreCtx.Menus where mn.SiteID == 8 && mn.IsDeleted == false  select mn).ToList();

            List<MenuModel> objMenuList = new List<MenuModel>();
            MenuModel objCurrentMenuListItem;
            
            foreach (Menu topLevelMenu in AllMenu.Where(mn => mn.ParentMenuID == 0))
            {
                if (topLevelMenu.ParentMenuID == 0)
                {
                    objCurrentMenuListItem = new MenuModel();
                    objCurrentMenuListItem.ID = topLevelMenu.ID;
                    objCurrentMenuListItem.Title = topLevelMenu.MenuName;
                    objCurrentMenuListItem.Icon = topLevelMenu.Icon;
                    objCurrentMenuListItem.Status = topLevelMenu.Status;
                    objCurrentMenuListItem.ColorCode = topLevelMenu.ColorCode;
                    objCurrentMenuListItem.Route = topLevelMenu.AngularTemplateUrl;
                    objCurrentMenuListItem.Type = "collapsable";

                    RoleTypeClaims rtc_record = (from rtc in _coreCtx.RoleTypeClaims
                                                 where rtc.Name == "View" && rtc.MenuID == topLevelMenu.ID
                                                 select rtc).FirstOrDefault();
                    if (rtc_record != null)
                    {
                        objCurrentMenuListItem.ClaimValue = rtc_record.ClaimValue;
                    }

                    FillChild(topLevelMenu, topLevelMenu.ID, objCurrentMenuListItem, AllMenu);

                    objMenuList.Add(objCurrentMenuListItem);
                }
            }
            return objMenuList;
        }      
        public void FillChild(Menu parent, int IID, MenuModel objMenuList, List<Menu> AllMenu)
        {
            var level = (from mn in AllMenu where mn.ParentMenuID == IID && mn.SiteID == 8 && mn.IsDeleted == false orderby mn.DisplayOrder select mn).ToList();

            MenuModel objChildMenuListItem;

            if (level != null && level.Count > 0)
            {
                foreach (Menu child in level)
                {
                    objChildMenuListItem = new MenuModel();
                    objChildMenuListItem.ID = child.ID;
                    objChildMenuListItem.Title = child.MenuName;
                    objChildMenuListItem.Icon = child.Icon;

                    objChildMenuListItem.Status = child.Status;
                    objChildMenuListItem.ColorCode = child.ColorCode;

                    objChildMenuListItem.Route = child.AngularTemplateUrl;
                    objChildMenuListItem.Type = "basic";
                    if (objMenuList.Children == null)
                    {
                        objMenuList.Children = new List<MenuModel>();
                        objChildMenuListItem.Type = "collapsable";
                    }

                    RoleTypeClaims rtc_record = (from rtc in _coreCtx.RoleTypeClaims
                                                 where rtc.Name == "View" && rtc.MenuID == child.ID
                                                 select rtc).FirstOrDefault();
                    if (rtc_record != null)
                    {
                        objChildMenuListItem.ClaimValue = rtc_record.ClaimValue;
                    }

                    objMenuList.Children.Add(objChildMenuListItem);
                    FillChild(child, child.ID, objChildMenuListItem, AllMenu);
                    
                }
                //return 0;
            }
            //else
            //{
            //    return 0;
            //}
        }

    }
}
