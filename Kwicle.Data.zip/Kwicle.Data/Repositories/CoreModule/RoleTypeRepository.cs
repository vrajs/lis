﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities.Core;
using Kwicle.Data.Contracts.CoreModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Repositories.CoreModule
{
    public class RoleTypeRepository : BaseRepository<RoleType>, IRoleTypeRepository
    {
        private readonly KwicleCoreContext _coreContex;

        public RoleTypeRepository(KwicleCoreContext coreContext) : base(coreContext)
        {
            _coreContex = coreContext;
        }

        public List<KeyValuePair<short, string>> GetRoleType()
        {
            List<KeyValuePair<short, string>> Items = _coreContex.RoleTypes.Where(x => x.RecordStatus == (byte)RecordStatus.Active).Select(x => new KeyValuePair<short, string>(x.RoleTypeID, x.Name)).ToList();             
            return Items;
        }
    }
}
