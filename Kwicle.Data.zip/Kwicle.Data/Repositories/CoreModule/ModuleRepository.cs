﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Core;
using Kwicle.Core.Entities.Core;
using Kwicle.Data.Contracts.CoreModule;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Repositories.CoreModule
{
    public class ModuleRepository : BaseRepository<Module>, IModuleRepository
    {
        #region Variables

        private readonly KwicleCoreContext _coreContext;

        #endregion

        #region Ctor

        public ModuleRepository(KwicleCoreContext coreCtx) : base(coreCtx)
        {
            _coreContext = coreCtx;
        }

        #endregion

        #region Interface Methods Implementation   

        public IEnumerable<Module> GetAllModule()
        {
            try
            {
                var res = _coreContext.Modules.Where(x => x.IsDeleted != true).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetModule", ex.Message);
                return null;
            }
        }

        public List<KeyVal<int, string>> GetKeyValue()
        {
            try
            {
                var res = _coreContext.Modules.Where(x => x.IsDeleted != true).Select(x => new KeyVal<int,string>(x.ID, x.Name)).ToList();
                return res;

            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetGetKeyValue", ex.Message);
                return null;
            }
        }

        public IQueryable<ModuleViewModel> GetModule(int? ID)
        {
            try
            {
                var query = from mod in _coreContext.Modules
                            where mod.IsDeleted == false
                                    && (!ID.HasValue || mod.ID == ID)                                                                    
                            select new ModuleViewModel()
                            {
                                ID = mod.ID,
                                Name = mod.Name,
                                Description = mod.Description,
                                IsDeleted = mod.IsDeleted,
                                CreatedByID = mod.CreatedByID,
                                CreatedDate = mod.CreatedDate,
                                UpdatedByID = mod.UpdatedByID,
                                UpdatedDate = mod.UpdatedDate,
                                SiteID = mod.SiteID
                            };
                return query;
            }
            catch (Exception ex)
            {

                base.DbState.AddErrorMessage("CanNotGetModule", ex.Message);
                return null;
            }
        }
        #endregion
    }
}
