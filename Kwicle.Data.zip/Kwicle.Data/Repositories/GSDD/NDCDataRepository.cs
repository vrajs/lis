﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts.GSDD;

namespace Kwicle.Data.Repositories.GSDD
{
    public class NDCDataRepository : INDCDataRepository
    {
        KwicleGSDDContext _context;
        public NDCDataRepository(KwicleGSDDContext context)
        {
            _context = context;
        }
        public IQueryable<vwHPSGetClaimNDCData> GetClaimNDCData => from ndc in _context.GetClaimNDCData where ndc.NDC9 != string.Empty select ndc ;
    }
}
