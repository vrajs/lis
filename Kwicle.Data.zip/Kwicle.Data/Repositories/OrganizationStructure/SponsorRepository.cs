﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.OrganizationStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Repositories.OrganizationStructure
{


    public class SponsorRepository : BaseRepository<Sponsor>, ISponsorRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public SponsorRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion


        #region Get Methods
        /// <summary>
        /// Method use for get sponsor.
        /// </summary>
        /// <returns>List of KeyVal<int, string></returns>
        public List<KeyVal<Int16, string>> GetSponsor()
        {
            var sponsors = from s in _context.Sponsors.Where(i => i.RecordStatus == 0)
                           select new KeyVal<Int16, string>()
                           {
                               Key = s.SponsorID,
                               Value = s.SponsorName
                           };
            return sponsors.ToList();
        }
        #endregion
    }
}
