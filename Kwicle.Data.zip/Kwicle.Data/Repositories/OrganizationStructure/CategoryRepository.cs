﻿using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.OrganizationStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel;

namespace Kwicle.Data.Repositories.OrganizationStructure
{
    public class CategoryRepository : BaseRepository<Category>, ICategoryRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public CategoryRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public List<KeyVal<Int16, string>> GetKeyValuedCategories()
        {
            var categories = from n in _context.Categories.Where(i => i.RecordStatus ==0 )
                             select new KeyVal<Int16, string>()
                             {
                                 Key = n.CategoryID,
                                 Value = n.CategoryName
                             };
            var categoriesList = categories.ToList();

            return categoriesList;
        }
        #endregion

    }
}
