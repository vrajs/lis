﻿using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.OrganizationStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel;

namespace Kwicle.Data.Repositories.OrganizationStructure
{
    public class LobRepository : BaseRepository<Lob>, ILobRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public LobRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        #endregion


        #region  Methods
        public LobModel GetLobByID(int LobID)
        {
            var query = from n in _context.Lobs.Where(c => c.LobID == LobID)
                        join o in _context.Organizations on n.SubCompanyID equals o.OrganizationID
                        select new LobModel()
                        {
                            LobID = n.LobID,
                            LobCode = n.LobCode,
                            LobName = n.LobName,
                            SubmitterCode = n.SubmitterCode,
                            CaidContractNumber = n.CaidContractNumber,
                            CareContractNumber = n.CareContractNumber,
                            NICNumber = n.NICNumber,
                            EffectiveDate = n.EffectiveDate,
                            TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                            OrganizationID = n.SubCompanyID,
                            OrganizationName = o.OrganizationName,
                            SponsorID = n.SponsorID,
                            CategoryID = n.CategoryID,
                            ProductID = n.ProductID,
                            CompanyID = o.ParentOrganizationID,
                            CategoryName = n.Category.CategoryName,
                            ProductName = n.Product.ProductName,
                            SponsorName = n.Sponsor.SponsorName
                        };
            return query.FirstOrDefault();
        }

        public IQueryable<LobModel> GetLobs()
        {
            var lobQuery = from n in _context.Lobs
                           join o in _context.Organizations on n.SubCompanyID equals o.OrganizationID
                           join s in _context.Sponsors on n.SponsorID equals s.SponsorID
                           join c in _context.Categories on n.CategoryID equals c.CategoryID
                           join p in _context.Products on n.ProductID equals p.ProductID
                           select new LobModel()
                           {
                               LobID = n.LobID,
                               LobCode = n.LobCode,
                               LobName = n.LobName,
                               SubmitterCode = n.SubmitterCode,
                               CaidContractNumber = n.CaidContractNumber,
                               CareContractNumber = n.CareContractNumber,
                               NICNumber = n.NICNumber,
                               EffectiveDate = n.EffectiveDate,
                               TermDate = (n.TermDate.Date == DateTime.MaxValue.Date) ? (DateTime?)null : n.TermDate,
                               OrganizationID = n.SubCompanyID,
                               OrganizationName = o.OrganizationName,
                               SponsorID = n.SponsorID,
                               SponsorName = s.SponsorName,
                               CategoryID = n.CategoryID,
                               CategoryName = c.CategoryName,
                               ProductID = n.ProductID,
                               ProductName = p.ProductName
                           };
            return lobQuery;
        }

        public Lob GetByID(int LobID)
        {
            return _context.Lobs.Where(c => c.LobID == LobID).FirstOrDefault();
        }

        public List<KeyVal<short, string>> GetBySubCompanyId(int? subCompanyId)
        {
            var query = from n in this._context.Lobs.Where(i => (!subCompanyId.HasValue || i.SubCompanyID == subCompanyId) && i.RecordStatus == (int)RecordStatus.Active)
                        select new KeyVal<short, string>
                        {
                            Key = n.LobID,
                            Value = n.LobName
                        };
            var result = query.ToList();
            return result;
        }
        #endregion
    }
}
