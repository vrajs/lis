﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.OrganizationStructure;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.OrganizationStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.IO;
using Kwicle.Core.Common;

namespace Kwicle.Data.Repositories.OrganizationStructure
{
    public class OrganizationRepository : BaseRepository<Organization>, IOrganizationRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public OrganizationRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }


        #endregion


        #region Get Methods
        public List<OrganizationStructureModel> GetCompanies()
        {
            var companiesQuery = from n in this._context.Organizations.Where(i => i.RecordStatus == 0 && i.OrganizationTypeID != (int)OrganizationType.Organization)
                                 select new OrganizationStructureModel
                                 {
                                     Id = n.OrganizationID,
                                     Text = n.OrganizationName,
                                     ParentId = n.ParentOrganizationID
                                 };
            var companies = companiesQuery.ToList();
            return companies;
        }
        /// <summary>
        /// Method use for get parent organization.
        /// </summary>
        /// <returns>List of KeyVal<int, string></returns>
        public List<KeyVal<Int16, string>> GetCompany()
        {
            var companys = from o in _context.Organizations.Where(i => i.OrganizationTypeID == (int)OrganizationType.Company && i.RecordStatus == 0)
                           select new KeyVal<Int16, string>()
                           {
                               Key = o.OrganizationID,
                               Value = o.OrganizationName
                           };
            return companys.ToList();
        }

        /// <summary>
        /// Method use for get child organization.
        /// </summary>
        /// <returns>List of KeyVal<int, string></returns>
        public List<KeyVal<Int16, string>> GetSubCompany(int? OrganizationID)
        {
            var companys = from o in _context.Organizations.Where(i => i.RecordStatus == (int)RecordStatus.Active && (!OrganizationID.HasValue || i.ParentOrganizationID == OrganizationID))
                           select new KeyVal<Int16, string>()
                           {
                               Key = o.OrganizationID,
                               Value = o.OrganizationName
                           };
            return companys.ToList();
        }

        public List<OrganizationHierarchyModel> GetHierarchyOrganizations()
        {
            var childModel = new List<OrganizationHierarchyModel>();
            List<Organization> AllOrg = (from org in _context.Organizations where org.RecordStatus == (int)RecordStatus.Active && org.OrganizationTypeID == (int)OrganizationType.Organization select org).ToList();

            List<OrganizationHierarchyModel> objOrgList = new List<OrganizationHierarchyModel>();
            OrganizationHierarchyModel objCurrentOrgListItem;

            foreach (Organization topLevelOrg in AllOrg)
            {
                if (topLevelOrg.ParentOrganizationID == 0)
                {
                    objCurrentOrgListItem = new OrganizationHierarchyModel();

                    objCurrentOrgListItem.ID = topLevelOrg.OrganizationID;
                    objCurrentOrgListItem.Name = topLevelOrg.OrganizationName;
                    objCurrentOrgListItem.ParentCompanyId = topLevelOrg.ParentOrganizationID;
                    objCurrentOrgListItem.OrganizationTypeID = topLevelOrg.OrganizationTypeID;


                    FillChild(topLevelOrg, topLevelOrg.OrganizationID, objCurrentOrgListItem);

                    objOrgList.Add(objCurrentOrgListItem);
                }
            }
            return objOrgList;
        }
        public void FillChild(Organization parent, int IID, OrganizationHierarchyModel objOrgList)
        {
            var level = (from mn in _context.Organizations where mn.ParentOrganizationID == IID && mn.RecordStatus == (int)RecordStatus.Active select mn).ToList();

            OrganizationHierarchyModel objChildMenuListItem;

            if (level != null && level.Count > 0)
            {
                foreach (Organization child in level)
                {
                    objChildMenuListItem = new OrganizationHierarchyModel();
                    objChildMenuListItem.ID = child.OrganizationID;
                    objChildMenuListItem.Name = child.OrganizationName;

                    objChildMenuListItem.OrganizationTypeID = child.OrganizationTypeID;
                    objChildMenuListItem.ParentCompanyId = child.ParentOrganizationID;


                    if (objOrgList.Children == null)
                    {
                        objOrgList.Children = new List<OrganizationHierarchyModel>();
                    }
                    objOrgList.Children.Add(objChildMenuListItem);
                    FillChild(child, child.OrganizationID, objChildMenuListItem);

                }
            }
        }

        public bool CheckLOBCompany(short Id)
        {

            var isCmp = _context.Lobs.Where(i => i.SubCompanyID == Id && i.RecordStatus == (int)RecordStatus.Active);
            if (!isCmp.Any())
            {
                var isSubCmp = from lob in _context.Lobs
                               from cmp in _context.Organizations
                               where cmp.ParentOrganizationID == Id
                               where lob.SubCompanyID == cmp.OrganizationID &&
                               lob.RecordStatus == (int)RecordStatus.Active && cmp.RecordStatus == (int)RecordStatus.Active
                               select lob;
                return isSubCmp.Any();
            }
            else
            {
                return isCmp.Any();
            }

        }

        public OrganizationViewModel GetOrganizationDetailsByID(Int16 OrganizationID)
        {
            OrganizationViewModel OrganizationDetails = new OrganizationViewModel();

            //var OrganizationDetailsQuery = from n in this._context.Organizations.Where(i => i.OrganizationID == OrganizationID)
            var OrganizationDetailsQuery = from org in this._context.Organizations
                                           join toc in _context.CommonCodes on org.StructureTypeID equals toc.CommonCodeID
                                           where org.OrganizationID == OrganizationID
                                           select new OrganizationViewModel
                                           {
                                               OrganizationID = org.OrganizationID,
                                               OrganizationCode = org.OrganizationCode,
                                               ParentOrganizationID = org.ParentOrganizationID,
                                               StructureTypeID = org.StructureTypeID,
                                               TypeofCompany = toc.ShortName,
                                               OrganizationName = org.OrganizationName,
                                               ShortName = org.ShortName,
                                               OrganizationTypeID = org.OrganizationTypeID,
                                               NPI = org.NPI,
                                               TIN = org.TIN,
                                               PhysicalAddress1 = org.PhysicalAddress1,
                                               PhysicalAddress2 = org.PhysicalAddress2,
                                               PhysicalCity = org.PhysicalCity,
                                               PhysicalState = org.PhysicalState,
                                               PhysicalZip = org.PhysicalZip,
                                               MailingAddress1 = org.MailingAddress1,
                                               MailingAddress2 = org.MailingAddress2,
                                               MailingCity = org.MailingCity,
                                               MailingState = org.MailingState,
                                               MailingZip = org.MailingZip,
                                               Phone = org.Phone,
                                               Fax = org.Fax,
                                               TTY = org.TTY,
                                               Website = org.Website,
                                               ContactName = org.ContactName,
                                               SubmitterCode = org.SubmitterCode,
                                               CaidContractNumber = org.CaidContractNumber,
                                               CareContractNumber = org.CareContractNumber,
                                               NICNumber = org.NICNumber,
                                               AppLogo = org.AppLogo,
                                               ReportLogo = org.ReportLogo,
                                               EffectiveDate = org.EffectiveDate,
                                               TermDate = org.TermDate,
                                               TimeZoneLocation = org.TimeZoneLocation
                                           };

            OrganizationDetails = OrganizationDetailsQuery != null ? OrganizationDetailsQuery.FirstOrDefault() : null;

            return OrganizationDetails;
        }

        #endregion
    }
}
