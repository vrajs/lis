﻿using Kwicle.Core.Entities;
using Kwicle.Data.Contracts.OrganizationStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel;

namespace Kwicle.Data.Repositories.OrganizationStructure
{
    public class ProductRepository : BaseRepository<Product>, IProductRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public ProductRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public List<KeyVal<int, string>> GetKeyValuedProducts()
        {
            var products = from n in _context.Products.Where(i =>  i.RecordStatus ==0)
                             select new KeyVal<int, string>()
                             {
                                 Key = n.ProductID,
                                 Value = n.ProductName
                             };
            var productList = products.ToList();

            return productList;
        }
        #endregion

    }
}
