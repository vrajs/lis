﻿using Kwicle.Data.Contracts;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Kwicle.Data.Repositories
{

    public class ProcedureRepository : BaseRepository<Procedure>, IProcedureRepository
    {
        private readonly KwicleContext _context;
        public ProcedureRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }
        
        public Procedure GetProcedure(int ProcedureId)
        {
            return _context.Procedures
              .Include(t => t.Provider)
              .ThenInclude(s => s.Clinic)
              .Where(t => t.ProcedureID == ProcedureId)
              .OrderBy(t => t.Name)
              .FirstOrDefault();
        }

        public IEnumerable<Procedure> GetProcedures(int ProviderId)
        {
            return _context.Procedures
              .Include(t => t.Provider)
              .ThenInclude(s => s.Clinic)
              .Where(t => t.Provider.ProviderID == ProviderId)
              .OrderBy(t => t.Name)
              .ToList();
        }
    }
}
