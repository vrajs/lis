﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;

namespace Kwicle.Data.Repositories
{
    public class ClinicRepository : BaseRepository<Clinic>, IClinicRepository
    {
        private readonly KwicleContext _context;
        public ClinicRepository(KwicleContext context) : base(context)
        {
            _context = context;
        }

        public IEnumerable<Clinic> GetAllClinics()
        {
            return _context.Clinics
                      .Include(c => c.OldLocation)
                      .OrderBy(c => c.Name)
                      .ToList();
        }

        public Clinic GetClinic(int id)
        {
            return _context.Clinics
              .Include(c => c.OldLocation)
              .Where(c => c.ClinicID == id)
              .FirstOrDefault();
        }

        public Clinic GetClinicWithProviders(int id)
        {
            return _context.Clinics
              .Include(c => c.OldLocation)
              .Include(c => c.Providers)
              .ThenInclude(s => s.Procedures)
              .Where(c => c.ClinicID == id)
              .FirstOrDefault();
        }

        public Clinic GetClinicByUID(string UID)
        {
            return _context.Clinics
              .Include(c => c.OldLocation)
              .Where(c => c.UID.Equals(UID, StringComparison.CurrentCultureIgnoreCase))
              .FirstOrDefault();
        }

        public Clinic GetClinicByUIDWithProviders(string UID)
        {
            return _context.Clinics
              .Include(c => c.OldLocation)
              .Include(c => c.Providers)
              .ThenInclude(s => s.Procedures)
              .Where(c => c.UID.Equals(UID, StringComparison.CurrentCultureIgnoreCase))
              .FirstOrDefault();
        }
    }
}
