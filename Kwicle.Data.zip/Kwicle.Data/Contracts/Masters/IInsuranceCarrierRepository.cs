﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IInsuranceCarrierRepository : IBaseRepository<InsuranceCarrier>
    {
        IQueryable<InsuranceCarrierModel> GetInsuranceCarriers();
    }
}
