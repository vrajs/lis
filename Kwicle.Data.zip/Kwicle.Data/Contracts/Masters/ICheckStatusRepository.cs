﻿using System.Collections.Generic;
using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ICheckStatusRepository : IBaseRepository<CheckStatus>
    {
        List<KeyVal<int, string>> GetAllStatus();
    }
}
