﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IClaimStatusRepository : IBaseRepository<ClaimStatus>
    {
        List<KeyVal<int, string>> GetAllStatus();
    }
}
