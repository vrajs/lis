﻿using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ICommonCodeDisplayConfigurationRepository : IBaseRepository<CommonCodeDisplayConfiguration>
    {
        List<CommonCodeDisplayConfiguration> GetDataCommonCodeDisplayConfigurationByCommonCodeIDs(List<int> CommonCodeIDs, string PageId);
        void InsertBunchOfCommonCodeDisplayConfiguration(List<CommonCodeDisplayConfiguration> entities);
        void DeleteBunchOfCommonCodeDisplayConfiguration(List<CommonCodeDisplayConfiguration> entities);
    }
}
