﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ITemplateRepository : IBaseRepository<Template>
    {
        List<TemplateViewModel> GetTemplate(string SubTypeName);
        Template GetTemplate(int TemplateTypeId, int TemplateSubTypeId, string TemplateName);

        List<KeyVal<string, string>> GetPlaceholderDictionary(int TemplateId, int Id);
    }
}
