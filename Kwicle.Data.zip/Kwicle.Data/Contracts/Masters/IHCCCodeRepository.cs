﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IHCCCodeRepository : IBaseRepository<HCCCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="HCCCodeID"></param>
        /// <returns></returns>
        HCCCodeModel GetHCCCodeByID(int HCCCodeID);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<HCCCodeModel> GetHCCCodes();
        IQueryable<HCCCodeModel> GetHCCCodes(int? ClinicalCodeTypeID);
    }
}