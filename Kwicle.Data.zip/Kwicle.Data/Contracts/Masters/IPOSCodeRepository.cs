﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IPOSCodeRepository : IBaseRepository<POSCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="POSCodeID"></param>
        /// <returns></returns>
        POSCodeModel GetPOSCodeByID(int POSCodeID);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<POSCodeModel> GetPOSCodes();
    }
}