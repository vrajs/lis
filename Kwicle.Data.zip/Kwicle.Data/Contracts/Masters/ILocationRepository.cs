﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ILocationRepository : IBaseRepository<Location>
    {
        IQueryable<LocationModel> GetLocation(int? LocationID);

        List<KeyVal<int, string>> GetKeyVal();
    }
}
