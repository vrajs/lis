﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IFeeScheduleHeaderRepository : IBaseRepository<FeeScheduleHeader>
    {
        IQueryable<FeeScheduleHeaderModel> GetFeeScheduleHeaders();

        int CopyFeeSchedule(FeeScheduleHeaderModel model, string createdBy, DateTime createdDate);
    }
}
