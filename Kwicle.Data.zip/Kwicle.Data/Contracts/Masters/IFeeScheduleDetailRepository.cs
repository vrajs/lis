﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IFeeScheduleDetailRepository : IBaseRepository<FeeScheduleDetail>
    {
        IQueryable<FeeScheduleDetailModel> GetFeeScheduleDetails(int feeScheduleHeaderID);
    }
}
