﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IRateCodeRepository : IBaseRepository<RateCode>
    {

        IQueryable<RateCodeModel> GetRateCode();

        IQueryable<RateCodeModel> GetRateCode(int MemberID);
    }
}
