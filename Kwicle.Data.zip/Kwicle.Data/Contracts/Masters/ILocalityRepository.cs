﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ILocalityRepository : IBaseRepository<Locality>
    {
        IQueryable<LocalityModel> GetLocalityList();
    }
}
