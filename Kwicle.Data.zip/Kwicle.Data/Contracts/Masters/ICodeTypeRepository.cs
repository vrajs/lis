﻿
using Kwicle.Core.Entities;
using Kwicle.Core.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ICodeTypeRepository:IBaseRepository<CodeType>
    {
        IQueryable<vwCodeTypeList> GetAllCodeTypes();
    }
}
