﻿using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IPaymentTypeRepository : IBaseRepository<PaymentType>
    {
    }
}
