﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IDRGCodeRepository : IBaseRepository<DRGCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="DRGCodeID"></param>
        /// <returns></returns>
        DRGCodeModel GetDRGCodeByID(int DRGCodeID);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<DRGCodeModel> GetDRGCodes();
    }
}