﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;
using System;
using Kwicle.Data.Models;
using Kwicle.Core.Common;
using Kwicle.Core.CustomModel.Configuration;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ICommonClinicalCodeRepository : IBaseRepository<CommonClinicalCodeModel>
    {
        /// <summary>
        /// 
        /// </summary>
        ///<param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        IQueryable<CommonClinicalCodeModel> GetCommonClinicalCodes(int ClinicalCodeTypeID);

        IQueryable<ClinicalCodeCheckModel> CheckCommonClinicalCode(int ClinicalCodeTypeID, string Code);
        IQueryable<ClinicalCodeCheckModel> CheckCommonClinicalCode(int clinicalCodeTypeID, string code, DateTime effectiveDate);
        MinCodeMaxCodeValidityModel CheckCodeValidity(int clinicalCodeTypeID, string minCode, string maxCode, DateTime validationDate, ValidityCheck validityMode);
        ClinicalCodeCheckModel CheckCodeValidity(int clinicalCodeTypeID, string minCode, DateTime effectiveDate, ValidityCheck effectiveFrom);
        ClinicalCodeCheckModel CheckCodeValidity(int clinicalCodeTypeID, string code, DateTime effectiveDate, DateTime termDate);
        //ClinicalCodeCheckModel CheckCodeEffectiveValidity(int clinicalCodeTypeID, string code, DateTime effectiveDate, DateTime termDate);
        IEnumerable<ExistsCommonClinicalCodeUsed> CheckExistsCommonClinicalCodeUsed(int clinicalCodeTypeID, string code, DateTime effectiveDate, DateTime termDate);

        /// <summary>
        /// Compares Min Code and Max Code , if Min Code is less than Max Code return true else false
        /// </summary>
        /// <param name="clinicalCodeTypeID"></param>
        /// <param name="minCode"></param>
        /// <param name="maxCode"></param>
        /// <returns></returns>
        bool Compare(int clinicalCodeTypeID, string minCode, string maxCode);

        //Compare input Code is valid or not lie between minCode and maxCode
        bool ValidCodeCompare(int clinicalCodeTypeID, string minCode, string maxCode, string Code);
    }
}