﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IFeeScheduleLimitRepository : IBaseRepository<FeeScheduleLimit>
    {
        IQueryable<FeeScheduleLimitModel> GetFeeScheduleLimits();
        //IQueryable<FeeSchedule> GetFeeSchedulesModel();

        IQueryable<FeeScheduleLimitModel> FeeScheduleLimits { get; }

        List<KeyValuePair<int, string>> GetFeeScheduleLimitKeyVal();
    }
}
