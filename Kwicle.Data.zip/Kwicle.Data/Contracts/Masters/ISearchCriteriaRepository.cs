﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ISearchCriteriaRepository : IBaseRepository<SearchCriteria>
    {
        List<SearchCriteriaModel> GetAllSearchCriteriaByUser(string CreatedBy);

        List<SearchCriteriaModel> GetAllSearchCriteriaByUserPage(string CreatedBy, string PageId);
    }
}
