﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Masters
{
    public interface ICapitationHeaderRepository : IBaseRepository<CapitationHeader>
    {

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //IQueryable<CapitationModel> GetCapitations();


        List<KeyValuePair<int, string>> GetCapitationKeyVal();
    }
}
