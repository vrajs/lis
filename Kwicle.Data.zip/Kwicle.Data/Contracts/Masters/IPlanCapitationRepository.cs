﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IPlanCapitationRepository : IBaseRepository<PlanCapitation>
    {
    }
}
