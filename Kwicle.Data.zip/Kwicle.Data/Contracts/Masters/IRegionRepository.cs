﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IRegionRepository : IBaseRepository<Region>
    {
        IQueryable<RegionModel> GetRegions(int ProductTypeID);
    }
}
