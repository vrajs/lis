﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IUserDataAuthorizationRepository : IBaseRepository<UserDataAuthorization>
    {
        UserDataAuthorizationModel GetByUserID(string userID);
        void DeleteByUserID(string userID);
    }
}
