﻿using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IModifierDiscountGroupRepository : IBaseRepository<ModifierDiscountGroup>
    {
        List<KeyValuePair<int, string>> GetModifierDiscountGroupKeyVal();
    }
}
