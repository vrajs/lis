﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IRefundStatusRepository : IBaseRepository<RefundStatus>
    {
        List<RefundStatusModel> GetAllStatus();
    }
}
