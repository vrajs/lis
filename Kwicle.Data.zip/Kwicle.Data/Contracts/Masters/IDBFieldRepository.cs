﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Text;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IDBFieldRepository : IBaseRepository<DBField>
    {
        List<KeyVal<int, string>> GetValues(int DBFieldID);
        List<DBField> GetDBFields(List<int> DBFields);
    }
}
