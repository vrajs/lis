﻿using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Collections.Generic;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface ICPTCodeRepository : IBaseRepository<CPTCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CPTCodeID"></param>
        /// <returns></returns>
        CPTCodeModel GetCPTCodeByID(int CPTCodeID);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        IQueryable<CPTCodeModel> GetCPTCodes(int ClinicalCodeTypeID);

        /// <summary>
        /// 
        /// </summary>        
        /// <returns></returns>
        IQueryable<CPTCodeModel> GetModifierCodes();

        /// <summary>
        /// 
        /// </summary>        
        /// <returns></returns>
        IQueryable<CPTCodeModel> GetHCPCCodes();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClinicalCodeTypeID"></param>
        /// <returns></returns>
        IQueryable<CPTCodeModel> GetCPTAndHCPCCodes(int ClinicalCodeTypeID);

        IQueryable<CPTCodeModel> GetCPTAndHCPCAndModCodes();

        List<CPTCodeModel> ValidateCPTCodes(List<ClaimServiceLineValidationModel> ProcedureCodes);

        List<CPTCodeModel> ValidateModifierCodes(List<ClaimServiceLineValidationModel> ProcedureCodes);

        IQueryable<CPTCodeModel> GetAllCPTCodes(int ClinicalCodeTypeID);
    }
}