﻿using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Collections.Generic;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IICDCodeRepository : IBaseRepository<ICDCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ICDCodeID"></param>
        /// <returns></returns>
        ICDCodeModel GetICDCodeByID(int ICDCodeID);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<ICDCodeModel> GetICDCodes(int ClinicalCodeTypeID);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ICDCodes"></param>
        /// <returns></returns>
        List<ICDCodeModel> ValidateICDCode(List<ICDCodeModel> ICDCodes);
        List<EDIICDCodeModel> ValidateDiagCode(List<EDIICDCodeModel> ICDCodes);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CodeWithoutDecimal"></param>
        /// <returns></returns>
        ICDCodeModel GetICDCodeByCode(string CodeWithoutDecimal);
    }
}