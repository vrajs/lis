﻿using Kwicle.Core.Common.EDI;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Collections.Generic;
using System.Linq;


namespace Kwicle.Data.Contracts.Masters
{
    public interface IRevenueCodeRepository : IBaseRepository<RevenueCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="RevenueCodeID"></param>
        /// <returns></returns>
        RevenueCodeModel GetRevenueCodeByID(int RevenueCodeID);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<RevenueCodeModel> GetRevenueCodes();

        IQueryable<RevenueCodeModel> GetRevenueUBCodes(int[] ClinicalCodeTypeID);

        #region MyRegion
        List<RevenueCodeModel> ValidateUBCode(List<EDIRevenueCodeModel> UBCodes);
        #endregion
    }
}