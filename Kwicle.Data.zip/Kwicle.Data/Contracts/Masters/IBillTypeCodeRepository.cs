﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Masters
{
    public interface IBillTypeCodeRepository : IBaseRepository<BillTypeCode>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ICDCodeID"></param>
        /// <returns></returns>
        BillTypeCodeModel GetBillTypeCodeByID(int BillTypeCodeID);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Code"></param>
        /// <returns></returns>
        BillTypeCodeModel GetBillTypeCodeByCode(string Code);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<BillTypeCodeModel> GetBillTypeCodes(int ClinicalCodeTypeID);
    }
}
