﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities.Master;

namespace Kwicle.Data.Contracts.Masters
{
   public interface IEditCodeRepository:IBaseRepository<EditCode>
    {
        IQueryable<EditCodeModel> GetEditCode(int[] PageID);
        IQueryable<EditCode> GetEditCode(string Code);
    }
}
