﻿using Kwicle.Core.Entities;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts
{
    public interface IProcedureRepository : IBaseRepository<Procedure>
    {
        // Procedures
        IEnumerable<Procedure> GetProcedures(int ProviderId);
        Procedure GetProcedure(int ProcedureId);

    }
}
