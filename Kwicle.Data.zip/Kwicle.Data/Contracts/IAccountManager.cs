﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts
{
    public interface IAccountManager
    {
        Task<Tuple<KwicleUser, string[]>> GetUserAndRolesAsync(string userId);
        Task<KwicleUser> GetUserByUserNameAsync(string userName);
        Task<Tuple<bool, string[]>> CreateUserAsync(KwicleUser user, IEnumerable<string> roles, string password);
        Task<KwicleRole> GetRoleByNameAsync(string roleName);                        
        Task<List<Tuple<KwicleUser, string[]>>> GetUsersAndRolesAsync();
        Task<Tuple<bool, string[]>> UpdateUserAsync(KwicleUser user);
        Task<Tuple<bool, string[]>> UpdateUserAsync(KwicleUser user, IEnumerable<string> roles);
        Task<KwicleUser> GetUserByIdAsync(string userId);
        Task<IList<string>> GetUserRolesAsync(KwicleUser user);

        //Task<List<KwicleRole>> GetRolesLoadRelatedAsync();
        Task<bool> CheckPasswordAsync(KwicleUser user, string password);
        //Task<Tuple<bool, string[]>> ResetPasswordAsync(KwicleUser user, string newPassword);
        Task<string> GeneratePasswordResetTokenAsync(KwicleUser user);
        Task<Tuple<bool, string[]>> ResetPasswordAsync(KwicleUser user,string resetToken, string newPassword);
        Task<Tuple<bool, string[]>> UpdatePasswordAsync(KwicleUser user, string currentPassword, string newPassword);

        #region Role
        Task<List<KwicleRole>> GetRolesAsync();
        Task<KwicleRole> GetRoleByIdAsync(string roleId);
        Task<KwicleRole> GetRoleAndClaimsAsync(string roleId);
        Task<Tuple<bool, string[]>> CreateRoleAsync(KwicleRole role, IEnumerable<string> claims);
        Task<Tuple<bool, string[]>> UpdateRoleAsync(KwicleRole role, IEnumerable<string> claims);
        Task<Tuple<bool, string[]>> DeleteRoleAsync(KwicleRole role);
        Task<bool> TestCanDeleteRoleAsync(string roleId);
        #endregion
    }
}
