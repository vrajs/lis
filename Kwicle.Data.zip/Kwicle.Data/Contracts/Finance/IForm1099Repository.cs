﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IForm1099Repository : IBaseRepository<Form1099>
    {
        IEnumerable<Form1099> GetAllForm1099();

        IQueryable<Form1099Model> GetForm1099(int Form1099ID);

        IQueryable<Form1099Model> GetForm1099ByForm1099ProcessID(int Form1099ProcessID);

    }
}
