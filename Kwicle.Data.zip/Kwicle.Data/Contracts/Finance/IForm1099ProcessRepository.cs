﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IForm1099ProcessRepository : IBaseRepository<Form1099Process>
    {
        IEnumerable<Form1099Process> GetAllForm1099Process();

        IQueryable<Form1099ProcessModel> GetForm1099Process(int Form1099ProcessID);
        IQueryable<vwForm1099ProcessList> GetForm1099ProcessList();

        IQueryable<Form1099Data> GetForm1099ProcessData(int Form1099ProcessID, string CreatedBy);
        IQueryable<Form1099Data> SaveForm1099ProcessData(int Form1099ProcessID, string CreatedBy);

    }
}
