﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IAdjustmentRepository : IBaseRepository<Adjustment>
    {
        IEnumerable<Adjustment> GetAllAdjustment();

        IQueryable<AdjustmentViewModel> GetAdjustment(short AdjustmentID);

    }
}
