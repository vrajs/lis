﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IAccountDetailCompanyStructureRepository : IBaseRepository<AccountDetailCompanyStructure>
    {       

        IEnumerable<AccountDetailCompanyStructure> GetAllAccountDetailCompanyStructure();

        IQueryable<AccountDetailCompanyStructureModel> GetAccountDetailCompanyStructure(short AccountDetailCompanyStructureID);

        IQueryable<AccountDetailCompanyStructureModel> GetAccountDetailCompanyStructureByAccountDetailID(short AccountDetailID);

        IQueryable<vwCompanyAccountList> GetCompanyAccountList();

    }
}
