﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IBillParameterRepository : IBaseRepository<BillParameter>
    {
        IEnumerable<BillParameter> GetAllBillParameter();

        IQueryable<BillParameterViewModel> GetBillParameter(short BillParameterID);

    }
}
