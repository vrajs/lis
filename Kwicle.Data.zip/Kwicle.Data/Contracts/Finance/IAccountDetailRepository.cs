﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IAccountDetailRepository : IBaseRepository<AccountDetail>
    {
        IEnumerable<AccountDetail> GetAllAccountDetail();

        IQueryable<AccountDetailModel> GetAccountDetail(short AccountDetailID);

        IQueryable<vwAccountDetailList> GetAccountDetailList();


    }
}
