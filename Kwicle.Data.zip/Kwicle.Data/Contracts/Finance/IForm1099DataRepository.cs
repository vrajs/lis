﻿using Kwicle.Core.Entities.FinanceStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IForm1099DataRepository:IBaseRepository<Form1099Data>
    {
        IQueryable<Form1099Data> GetForm1099DataByProcessID(int Form1099ProcessID);
    }
}
