﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Finance
{
    public interface ILienHolderBalanceRepository : IBaseRepository<LienHolderBalance>
    {
        IEnumerable<LienHolderBalance> GetAllLienHolderBalance();

        IQueryable<LienHolderBalanceModel> GetLienHolderBalance(short LienHolderBalanceID);

        IQueryable<LienHolderBalanceModel> GetLienHolderBalanceByLienHolderID(short LienHolderID);

        IQueryable<vwLienAccountList> GetLienAccountList();        

        IQueryable<vwLienHolderBalanceAmountHistory> GetLienHolderBalanceAmountHistory();

    }
}
