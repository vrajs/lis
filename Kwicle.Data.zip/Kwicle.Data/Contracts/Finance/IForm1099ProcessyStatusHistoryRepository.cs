﻿using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IForm1099ProcessStatusHistoryRepository : IBaseRepository<Form1099ProcessStatusHistory>
    {
        IQueryable<vwForm1099ProcessStatusHistoryList> GetForm1099ProcessStatusHistoryList(long RecGroupKey);
    }
}
