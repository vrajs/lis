﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;

namespace Kwicle.Data.Contracts.Finance
{
    public interface ILienHolderRepository : IBaseRepository<LienHolder>
    {
        IEnumerable<LienHolder> GetAllLienHolder();

        IQueryable<LienHolderModel> GetLienHolder(short LienHolderID);

        IQueryable<KeyVal<int, string>> GetLienHolderList();
    }
}
