﻿using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Finance;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Finance
{
    public interface IAdjustmentAppliedDetailRepository : IBaseRepository<AdjustmentAppliedDetail>
    {
        IEnumerable<AdjustmentAppliedDetail> GetAllAdjustmentAppliedDetail();

        IQueryable<AdjustmentAppliedDetailModel> GetAdjustmentAppliedDetail(short AdjustmentAppliedDetailID);

        IQueryable<AdjustmentAppliedDetailModel> GetAdjustmentAppliedDetailByAdjustmentID(short AdjustmentID);

        IQueryable<vwAdjustmentAppliedList> GetAdjustmentAppliedList(int CheckDetailID);
    }
}
