﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Alert;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Views;
using System.Collections.Generic;
using System.Linq;
using Kwicle.Core.CustomModel.Core;

namespace Kwicle.Data.Contracts
{
    public interface IODataService
    {
        #region Master
        IQueryable<FeeScheduleLimitModel> FeeSchedules { get; }
        IQueryable<CommonClinicalCodeModel> CommonClinicalCodes { get; }
        IQueryable<ICDCodeModel> ICDCodes { get; }
        IQueryable<POSCodeModel> POSCodes { get; }
        IQueryable<RevenueCodeModel> RevenueCodes { get; }
        IQueryable<DRGCodeModel> DRGCodes { get; }
        IQueryable<HCCCodeModel> HCCCodes { get; }
        IQueryable<CPTCodeModel> CPTCodes { get; }
        IQueryable<CPTCodeModel> HCPCCodes { get; }
        IQueryable<LobModel> Lobs { get; }
        IQueryable<LazyLoadODataModel<string, string>> Counties { get; }
        IQueryable<CPTCodeModel> CPTAndHCPCCodes { get; }
        IQueryable<vwCapitation> GetCapitations { get; }
        IQueryable<ZipCodeModel> ZipCodes { get; }
        IQueryable<ZipCodeModel> Cities { get; }
        IQueryable<ZipCodeModel> States { get; }
        IQueryable<CPTCodeModel> CPTAndHCPCAndModCodes { get; }
        IQueryable<ClinicalCodeGroupDetailModel> ClinicalCodeGroupDetails { get; }
        IQueryable<LocationModel> Locations { get; }
        #endregion

        #region Benefit
        IQueryable<GetPlanModel> Plans { get; }
        IQueryable<GetBenefitModel> BenefitHeaders { get; }
        IQueryable<BenefitCodeViewModel> BenefitCodes { get; }
        IQueryable<BillTypeCodeModel> BillTypeCodes { get; }
        IQueryable<BenefitCopayPerDiemViewModel> BenefitCopayPerDiems { get; }
        IQueryable<TermCodeViewModel> TermCodes { get; }
        IQueryable<BenefitServiceGroupModel> BenefitServiceGroups { get; }

        #endregion

        #region Contract
        IQueryable<vwContract> GetContracts { get; }
        IQueryable<vwTerm> Terms { get; }
        #endregion

        IQueryable<MemberEligibilityViewModel> MemberEligibility { get; }
        IQueryable<MemberContactViewModel> MemberContact { get; }
        IQueryable<MemberNotesViewModel> MemberNotes { get; }
        IQueryable<vwMemberList> Members { get; set; }
        IQueryable<RateCodeModel> RateCode { get; }
        IQueryable<MemberBillingViewModel> MemberBilling { get; }
        IQueryable<MemberBillingPaymentViewModel> MemberBillingPayments { get; set; }
        IQueryable<MemberCodeReferenceViewModel> MemberCodeReference { get; }
        IQueryable<MemberViewModel> DependentMembers { get; }
        IQueryable<MemberCostShareViewModel> MemberCostShare { get; }
        IQueryable<MemberDiscloserInfoViewModel> MemberDiscloserInfo { get; }
        IQueryable<InsuranceCarrierModel> InsuranceCarriers { get; }
        IQueryable<MemberCOBLetterViewModel> MemberCOBLetters { get; }
        IQueryable<ClaimDiagnosisViewModel> ClaimDiagnosis { get; }

        IEnumerable<MemberPCPViewModel> MemberPCP { get; }
        IQueryable<MemberProviderViewModel> GetProviderForMember { get; }
        IQueryable<MemberProviderLocationViewModel> GetProviderLocationForMember { get; }

        #region EDI
        IQueryable<TradingPartnerListModel> TradingPartners { get; }
        IQueryable<DataConfigurationModel> DataConfigurations { get; }
        IQueryable<EDI837PUploadFileModel> EDI837PUploadFiles { get; }
        IQueryable<EDI837PClaimModel> EDI837PUploadClaims { get; }
        IQueryable<EDI837PUploadFileModel> EDI837IUploadFilesList { get; }
        IQueryable<EDI837PClaimModel> EDI837IUploadClaimsList { get; }
        IQueryable<ServiceLine> EDIClaimServiceLine { get; }
        IQueryable<EncounterFileList> GetEncounterFilelist { get; }
        IQueryable<EDIEncounterListModel> GetEncounterClaimList { get; }
        IQueryable<vwInstitutionalDiagnosisCode> EDI837IInstitutionalDiagnosisCode { get; }
        IQueryable<vwClaimIServiceLine> EDI837IServiceLine { get; }
        IQueryable<EDI276UploadFileModel> EDI276UploadFiles { get; }
        IQueryable<vwClaimErrorsModule> GetProfessionalClaimErrors { get; }
        IQueryable<EDI837PErrorClaimModel> GetProfessionalErrorClaims { get; }

        IQueryable<EDI276ClaimSummaryModel> EDI276ClaimSummary { get; }
        #endregion

        IQueryable<MemberLookupViewModel> MemberLookup { get; }
        IQueryable<vwProviderLookup> ProviderLookup { get; }
        IQueryable<vwFacilityLookup> FacilityLookUp { get; }

        #region Claim
        IQueryable<ClaimReferenceViewModel> ClaimReference { get; }
        IQueryable<ClaimServiceViewModel> ClaimService { get; }
        IQueryable<ClaimAuditViewModel> ClaimAudit { get; }
        IQueryable<ClaimOtherInsuranceViewModel> ClaimOtherInsurance { get; }
        IQueryable<ClaimEditsViewModel> ClaimEdits { get; }
        IQueryable<ClaimNotesViewModel> ClaimNotes { get; }
        IQueryable<ClaimDiagnosisViewModel> ClaimDiagnosisProcedure { get; }
        IQueryable<ClaimUBCodesViewModel> ClaimUBCodes { get; }
        IQueryable<RevenueCodeModel> RevenueUBCodes { get; }
        IQueryable<ClaimOtherPhysicianViewModel> ClaimOtherPhysician { get; }
        IQueryable<ClaimProviderNPIViewModel> ClaimProviderNPI { get; }
        IQueryable<vwProviderLookup> ClaimProviders { get; }
        IQueryable<ClaimProcessingStepsViewModel> ClaimProcessingSteps { get; }
        IQueryable<ClaimEOBEOPViewModel> ClaimEOBEOP { get; }
        IQueryable<EditCodeModel> EditCode { get; }

        #region Claim Refund

        IQueryable<RefundReceivedViewModel> RefundReceived { get; }

        IQueryable<RefundPostingViewModel> RefundPosting { get; }

        IQueryable<RefundNoteViewModel> RefundNote { get; }

        IQueryable<RefundLetterViewModel> RefundLetter { get; }

        #endregion

        #endregion

        #region Alert
        IQueryable<AlertModuleViewModel> Alert { get; }
        IQueryable<AlertCodeViewModel> AlertCode { get; }
        #endregion

        #region GSDD
        IQueryable<vwHPSGetClaimNDCData> NDCData { get; }
        #endregion

        IQueryable<vwClaimList> ClaimList { get; }
        IQueryable<ProviderViewModel> ClaimReferringPhysicians { get; }
        IQueryable<vwFacilityLookup> FacilityLookups { get; }
        IQueryable<vwProvider> Providers { get; }
        IQueryable<vwIPA> IPAs { get; }
        IQueryable<vwClaimLoockup> ClaimLoockup { get; }

        IQueryable<ModuleViewModel> Module { get; }

        IQueryable<MemberEnrollmentViewModel> MemberEnrollmentHeader { get; }

        #region Finance

        IQueryable<vwCheckHistoryList> CheckHistoryList { get; }

        #endregion
    }
}
