﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderRelationRepository : IBaseRepository<ProviderRelation>
    {
        IQueryable<ProviderRelationModel> GetProviderRelation(int? parentProviderID, int? relatedProviderID);

        IQueryable<int> GetRelatedProviderIDByParentProviderID(int parentProviderID);
    }
}
