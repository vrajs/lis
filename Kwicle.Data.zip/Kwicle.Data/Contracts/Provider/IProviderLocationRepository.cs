﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderLocationRepository : IBaseRepository<ProviderLocation>
    {
        IQueryable<ProviderLocationModel> GetProviderLocation(int? ProviderID, int? ProviderLocationID);
        IQueryable<ProviderLocationModel> GetGroupProviderLocation(int GroupID, int? GroupLocationID);
        void DeleteOrTermGroupProviderLocation(int groupID, int? locationID ,DateTime todaysDate, string userName, int recordStatus, string recordStatusChangeComment, DateTime? termDate);
    }
}
