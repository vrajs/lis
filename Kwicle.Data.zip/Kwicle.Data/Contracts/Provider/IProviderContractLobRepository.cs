﻿using Kwicle.Core.Entities.ProviderStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderContractLobRepository : IBaseRepository<ProviderContractLob>
    {
        
    }
}
