﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderTINRepository : IBaseRepository<ProviderTIN>
    {
        IQueryable<ProviderTINViewModel> GetProviderTIN(int? ProviderID, int? TINTypeID);
    }
}
