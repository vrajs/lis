﻿using Kwicle.Core.Entities.ProviderStructure;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderContractTimelyFilingRepository : IBaseRepository<ProviderContractTimelyFiling>
    {
    }
}
