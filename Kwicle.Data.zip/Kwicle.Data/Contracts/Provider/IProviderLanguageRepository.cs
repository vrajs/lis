﻿using Kwicle.Core.Entities.ProviderStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderLanguageRepository: IBaseRepository<ProviderLanguage>
    {
        List<ProviderLanguage> GetByProviderID(int providerID);
        List<ProviderLanguage> GetLangByProviderId(int providerID);
    }
}
