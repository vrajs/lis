﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderSpecialtyRepository : IBaseRepository<ProviderSpecialty>
    {
        IQueryable<ProviderSpecialtyModel> GetByProvider(int providerID);
        void Add(ProviderSpecialty model, bool isPrimry);
        void Update(ProviderSpecialty model, bool isPrimry);
    }
}
