﻿using Kwicle.Core.Entities.ProviderStructure;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderContractInterestRepository : IBaseRepository<ProviderContractInterest>
    {
    }
}
