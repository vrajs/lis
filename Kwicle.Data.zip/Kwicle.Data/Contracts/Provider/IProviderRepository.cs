﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderRepository : IBaseRepository<Core.Entities.ProviderStructure.Provider>
    {
        IQueryable<ProviderViewModel> GetClaimReferringPhysician();
        IQueryable<vwProviderList> GetProviders();
        IQueryable<vwProviderRelation> GetProviderRelation();
        IQueryable<ProviderLocationModel> GetProviderLocation(int ProviderID);
        IQueryable<GroupProviderContractModel> GetProviderContract(int ProviderID);
        IQueryable<ProviderDataCheckModel> CheckProviderData(int identifierType, string identifierCode);

        HasProviderConfigurationDataModel CheckProviderConfigurationHasData(int providerID);
        HasGroupConfigurationDataModel CheckGroupConfigurationHasData(int providerID);
        ProviderViewModel GetView(int providerID);

        int CreateGroupFromProvider(int providerID);

        ProviderViewModel GetProviderNameByProCode(string searchValue);
    }
}
