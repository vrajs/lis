﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderCodeRepository : IBaseRepository<ProviderCode>
    {
        IQueryable<ProviderCodeViewModel> GetProviderCode(int? ProviderID, int? CodeTypeID);
    }
}
