﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderIPARepository : IBaseRepository<ProviderIPA>
    {
        IQueryable<ProviderIPAModel> GetProviderIPA(int? providerID, int? ipaid);
    }
}
