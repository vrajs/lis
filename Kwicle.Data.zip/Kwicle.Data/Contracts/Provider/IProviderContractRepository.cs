﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System;
using System.Linq;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderContractRepository : IBaseRepository<ProviderContract>
    {
        IQueryable<ProviderContractModel> GetGroupContract(int? ProviderID, int? ProviderContractID);

        IQueryable<ProviderContractModel> GetProviderContract(int ProviderID);


    }
}
