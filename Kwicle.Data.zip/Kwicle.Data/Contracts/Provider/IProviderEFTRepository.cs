﻿using Kwicle.Core.CustomModel.Provider;
using Kwicle.Core.Entities.ProviderStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Provider
{
    public interface IProviderEFTRepository : IBaseRepository<ProviderEFT>
    {
        IQueryable<ProviderEFTViewModel> GetProviderEFT(int? ProviderID, int? ProviderEFTID);
    }
}
