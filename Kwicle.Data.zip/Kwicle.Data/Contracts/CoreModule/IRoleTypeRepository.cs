﻿using Kwicle.Core.Entities.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.CoreModule
{
    public interface IRoleTypeRepository : IBaseRepository<RoleType>
    {
        List<KeyValuePair<short, string>> GetRoleType();
    }
}
