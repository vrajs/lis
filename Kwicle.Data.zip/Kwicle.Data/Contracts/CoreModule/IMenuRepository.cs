﻿using System.Collections.Generic;
using Kwicle.Data.Models;
using Kwicle.Core.Entities.Core;
using Kwicle.Data.Contracts;

namespace Kwicle.Data.Contracts.CoreModule
{
    public interface IMenuRepository : IBaseRepository<Menu>
    {
        List<MenuModel> GetMenu();
    }
}
