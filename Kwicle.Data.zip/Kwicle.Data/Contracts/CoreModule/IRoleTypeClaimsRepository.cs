﻿using Kwicle.Core.Entities.Core;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.CoreModule
{
    public interface IRoleTypeClaimsRepository : IBaseRepository<RoleTypeClaims>
    {
        List<RoleTypeClaims> GetRoleTypeClaim();        //short roleTypeID
    }
}
