﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Core;
using Kwicle.Core.Entities.Core;
using Kwicle.Data.Contracts;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.CoreModule
{
    public interface IModuleRepository : IBaseRepository<Module>
    {
        IEnumerable<Module> GetAllModule();
        IQueryable<ModuleViewModel> GetModule(int? ID);
        List<KeyVal<int, string>> GetKeyValue();
    }
}
