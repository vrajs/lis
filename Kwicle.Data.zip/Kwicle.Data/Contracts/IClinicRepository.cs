﻿using System.Collections.Generic;
using Kwicle.Core.Entities;

namespace Kwicle.Data.Contracts
{
    public interface IClinicRepository : IBaseRepository<Clinic>
    {
        // Clinics
        IEnumerable<Clinic> GetAllClinics();
        Clinic GetClinic(int id);
        Clinic GetClinicWithProviders(int id);
        Clinic GetClinicByUID(string UID);
        Clinic GetClinicByUIDWithProviders(string UID);

    }
}