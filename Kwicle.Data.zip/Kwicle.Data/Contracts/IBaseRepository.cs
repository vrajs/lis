﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;


namespace Kwicle.Data.Contracts
{
    public interface IBaseRepository<T> where T : class
    {
        // Basic DB Operations
        DbSet<T> DbSet { get; }
        void Add(T entity);
        Task AddAsync(T entity);
        void Delete(T entity);
        Task<bool> SaveAllAsync();
        T GetById<C>(C Id);
        IQueryable<T> GetByPredicateIgnoreQueryFilters(Expression<Func<T, bool>> filter, params Expression<Func<T, object>>[] includes);
        IQueryable<T> GetByPredicate(Expression<Func<T, bool>> filter, params Expression<Func<T, object>>[] includes);     
        void Update(T entity);
        Task UpdateAsync(T entity);
        [Obsolete]
        void DeleteById<C>(C Id);
        void DeleteById<C>(C Id, string UserName, DateTime TodaysDate);
        void DeleteByReason(DeleteModel deleteModel);
        void AddRange(T[] entity);
        ErrorMessageModel DbState { get; }
    }
}
