﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities;
using Kwicle.Core.Views;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Common
{
    public interface IZipCodeRepository : IBaseRepository<ZipCode>
    {
        IQueryable<ZipCodeModel> GetZipCodes();
        IQueryable<vwCities> GetCities();
        IQueryable<GetCountiesModel> GetCounties();
        IQueryable<KeyVal<string, string>> GetStates();
        IQueryable<KeyVal<string, string>> GetCountries();

        Task<vwZipCodeDetail> GetZipCodesFromView(string searchValue);
    }
}
