﻿using System;

namespace Kwicle.Data.Contracts.Common
{
    public interface ICommonRepository
    {
        bool CheckReferenceExist(string ParentTableToCheck, Int64? PKDataID, Int64? UKDataID, short? CheckType);
    }
}
