﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.OrganizationStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Common
{
    public interface IProductTypeRepository : IBaseRepository<ProductType>
    {
        List<KeyVal<short,string>> GetAllKeyVal();
    }
}
