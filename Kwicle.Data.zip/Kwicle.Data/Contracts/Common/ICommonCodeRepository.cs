﻿using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Common
{
    public interface ICommonCodeRepository : IBaseRepository<CommonCode>
    {
        List<KeyValuePair<int, string>> GetCommonCodesByCodeTypeId(Int16 CommonCodeTypeId, Int16 FetchingTypeId);
        List<CommonCodeModel> GetCommonCodesByCodeTypeIds(MultipleValueRequestModel request);
        List<KeyValuePair<string, string>> GetCommonCodesKeyAsCodeByCodeTypeId(Int16 CommonCodeTypeId, Int16 FetchingTypeId);
        List<GetCommonCodeConfigurationModel> GetCommonCodeConfigurationByCodeTypeId(string PageId, int CodeTypeId);

        IQueryable<vwCommonCodeList> GetCommonCodeList(int CommonCodeTypeID);

        int BulkUpdate(List<CommonCode> model);
        Task<List<CommonCode>> GetCommonCodeByCodeTypeId(short codeTypeId);
    }
}
