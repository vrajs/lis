﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.Master;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.Common
{
    public interface IServiceTypeCodeRepository : IBaseRepository<ServiceTypeCode>
    {
        List<KeyVal<short, string>> GetKeyVal();
    }
}
