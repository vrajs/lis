﻿using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities.CommonStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.Common
{
    public interface IDocumentRepository: IBaseRepository<Document>
    {
        IQueryable<Document> GetDocumentsByType(int DocumentTypeID);
        short GetForm1099DocumentType();
    }
}
