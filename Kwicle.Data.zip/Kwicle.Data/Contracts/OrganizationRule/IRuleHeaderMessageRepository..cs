﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.OrganizationRule
{
   public interface IRuleHeaderMessageRepository : IBaseRepository<RuleHeaderMessage>
    {
        IQueryable<RuleHeaderMessageViewModel> GetRuleHeaderMessages(short RuleHeaderID);
        IQueryable<RuleHeaderMessageViewModel> GetRuleHeaderMessageByMessageType(short RuleHeaderID,byte MessageTypeID);

    }
}
