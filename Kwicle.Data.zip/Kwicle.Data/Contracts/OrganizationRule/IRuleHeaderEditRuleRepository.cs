﻿using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.OrganizationRule
{
    public interface IRuleHeaderEditRuleRepository : IBaseRepository<RuleHeaderEditRule>
    {
        List<RuleHeaderEditRuleCategoryViewModel> GetCategory(short ruleHeaderID);
        List<RuleHeaderEditRuleViewModel> GetEdits(short ruleHeaderID, string category);
        int InsertOrUpdate(RuleHeaderEditRule entRHEditRule, RuleHeaderEditRuleCriteria entRHEditRuleCriteria);
        RuleHeaderEditRuleViewModel GetByID(int EditCodeID, int RuleHeaderID);
        void Delete(int ruleHeaderEditRuleID, string UserName, DateTime TodaysDate);
    }
}
