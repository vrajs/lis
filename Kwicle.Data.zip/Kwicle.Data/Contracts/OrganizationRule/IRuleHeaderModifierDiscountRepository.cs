﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.CustomModel.OrganizationRuleStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.OrganizationRule
{
   public interface IRuleHeaderModifierDiscountRepository : IBaseRepository<RuleHeaderModifierDiscount>
    {
        IQueryable<RuleHeaderModifierDiscountViewModel> GetRuleHeaderModifierDiscounts(short RuleHeaderID);
    }
}
