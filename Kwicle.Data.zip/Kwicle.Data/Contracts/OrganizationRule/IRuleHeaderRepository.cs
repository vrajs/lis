﻿using Kwicle.Core.Entities;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.OrganizationRule
{
    public interface IRuleHeaderRepository : IBaseRepository<RuleHeader>
    {
    }
}
