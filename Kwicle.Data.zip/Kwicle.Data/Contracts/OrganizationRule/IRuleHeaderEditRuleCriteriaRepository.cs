﻿using System;
using System.Collections.Generic;
using System.Text;
using Kwicle.Core.Entities.OrganizationRuleStructure;

namespace Kwicle.Data.Contracts.OrganizationRule
{
    public interface IRuleHeaderEditRuleCriteriaRepository : IBaseRepository<RuleHeaderEditRuleCriteria>
    {
    }
}
