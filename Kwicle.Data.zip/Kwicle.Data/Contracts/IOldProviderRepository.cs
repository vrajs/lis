﻿using Kwicle.Core.Entities;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts
{
    public interface IOldProviderRepository : IBaseRepository<OldProvider>
    {
        // Providers
        IEnumerable<OldProvider> GetProviders(int id);
        IEnumerable<OldProvider> GetProvidersWithProcedures(int id);
        IEnumerable<OldProvider> GetProvidersByUID(string UID);
        IEnumerable<OldProvider> GetProvidersByUIDWithProcedures(string UID);
        OldProvider GetProvider(int ProviderId);
        OldProvider GetProviderWithProcedures(int ProviderId);
    }
}
