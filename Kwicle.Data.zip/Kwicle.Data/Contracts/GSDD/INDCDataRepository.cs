﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.GSDD
{
   public interface INDCDataRepository
    {
        IQueryable<vwHPSGetClaimNDCData> GetClaimNDCData { get; }
    }
}
