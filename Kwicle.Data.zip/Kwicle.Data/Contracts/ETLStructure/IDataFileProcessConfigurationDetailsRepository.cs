﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;

namespace Kwicle.Data.Contracts.ETLStructure
{
    public interface IDataFileProcessConfigurationDetailsRepository : IBaseRepository<DataFileProcessConfigurationDetails>
    {
        IEnumerable<DataFileProcessConfigurationDetails> GetAllDataFileProcessConfigurationDetails();

        DataFileProcessConfigurationDetails GetDataByDataFileProcessConfigurationId(int DataFileProcessConfigurationId);
    }
}
