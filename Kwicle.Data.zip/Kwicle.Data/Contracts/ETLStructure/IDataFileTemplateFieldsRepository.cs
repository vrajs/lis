﻿using Kwicle.Core.Entities.ETLStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.ETLStructure
{
    public interface IDataFileTemplateFieldsRepository : IBaseRepository<DataFileTemplateFields>
    {
        IEnumerable<DataFileTemplateFields> GetAllDataFileTemplateFields();
    }
}
