﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;

namespace Kwicle.Data.Contracts.ETLStructure
{
    public interface IDataFileProcessConfigurationRepository : IBaseRepository<DataFileProcessConfiguration>
    {
        IQueryable<DataFileProcessConfiguration> GetAllDataFileProcessConfiguration();
        DataFileProcessConfiguration GetDataByDatafileTemplateId(int DatafileTemplateId);
    }
}
