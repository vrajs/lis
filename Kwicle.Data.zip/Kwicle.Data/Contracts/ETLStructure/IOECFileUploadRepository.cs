﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Common;
using Kwicle.Core.Common.OECFile;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.ETLStructure
{
    public interface IOECFileUploadRepository
    {
        IQueryable<DataFileTemplateFields> GetAllDataFileTemplateFields();
        long InsertOECFileProcessDataInDataFileProcess(int DataFileProcessConfigurationId, string FileName);
        void OECActualLoadData(long DataFileToProcessDetailsID);
        IEnumerable<OECLayout> GetOECUplodedDataByDataFileToProcessDetailsID(long DataFileToProcessDetailsID, int DataFileTemplateID);

    }
}
