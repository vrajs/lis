﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.CustomModel.ETLStructure;
using Kwicle.Core.Kwicle.Core.Entities.Files;
using Kwicle.Core.Entities.Files;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.ETLStructure
{
    public interface IFileTemplateTypeRepository : IBaseRepository<FileTemplateType>
    {
        IEnumerable<FileTemplateType> GetAllFileTemplateType();
        Task<FileTemplateTypeListViewModel> GetFileTemplateDetails(FileTemplateTypeSearchModel searchModel);

        Task<List<FileSubCategory>> GetCMSFileType();
        Task<List<FullEnrollmentDetailLayout>> GetEnrollmentFileData(int dataFileToProcessDetailsID);
        Task<List<LossOfSubsidyDetailLayout>> GetLossOfSubsidyFileData(int dataFileToProcessDetailsID);
        Task<List<LTIResident>> GetLTIResidentFileData(int dataFileToProcessDetailsID);
        Task<List<MMSRDetailLayout>> GetMMSRDetailFileData(int dataFileToProcessDetailsID);
        Task<List<TRRDetailLayout>> GetTRRDetailFileData(int dataFileToProcessDetailsID);
        Task<List<OECLayout>> GetOECFileData(int dataFileToProcessDetailsID);
        Task<List<NoRxDetailLayout>> GetNoRxFileData(int dataFileToProcessDetailsID);
        Task<List<MPWRDDetailLayout>> GetMPWRDFileData(int dataFileToProcessDetailsID);
        Task<List<MMSRDetailLayout>> GetMMSRFileData(int dataFileToProcessDetailsID);
        Task<List<MembershipDetailLayout>> GetMembershipFileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT94Layout>> GetMARxT94FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT93Layout>> GetMARxT93FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT92Layout>> GetMARxT92FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT81Layout>> GetMARxT81FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT80Layout>> GetMARxT80FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT79Layout>> GetMARxT79FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT78Layout>> GetMARxT78FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT77Layout>> GetMARxT77FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT76Layout>> GetMARxT76FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT75Layout>> GetMARxT75FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT74Layout>> GetMARxT74FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT73Layout>> GetMARxT73FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT72Layout>> GetMARxT72FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT51Layout>> GetMARxT51FileData(int dataFileToProcessDetailsID);
        Task<List<MARxRequestT61Layout>> GetMARxT61FileData(int dataFileToProcessDetailsID);
        Task<List<MAMSDetailLayout>> GetMAMSFileData(int dataFileToProcessDetailsID);
        Task<List<LISPartDPremiumDetailLayout>> GetLisPartDPremiumFileData(int dataFileToProcessDetailsID);
        Task<List<LISHISTDetailLayout>> GetLisHistFileData(int dataFileToProcessDetailsID);
        Task<List<LEPDetailLayout>> GetLEPDetailFileData(int dataFileToProcessDetailsID);
        Task<List<BEQRequestDetailLayout>> GetBeqRequestFileData(int dataFileToProcessDetailsID);
        Task<List<BEQResponseDetailLayout>> GetBeqResponseFileData(int dataFileToProcessDetailsID);
        Task<List<AgentCompDetailLayout>> GetAgentCompFileData(int dataFileToProcessDetailsID);
    }
}
