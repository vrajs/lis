﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.OrganizationStructure
{
    public interface ISponsorRepository : IBaseRepository<Sponsor>
    {
        List<KeyVal<Int16, string>> GetSponsor();
    }
}
