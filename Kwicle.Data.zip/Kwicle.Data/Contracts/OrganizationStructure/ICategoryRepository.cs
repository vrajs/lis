﻿using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel;

namespace Kwicle.Data.Contracts.OrganizationStructure
{
    public interface ICategoryRepository : IBaseRepository<Category>
    {
        List<KeyVal<Int16, string>> GetKeyValuedCategories();
    }
}
