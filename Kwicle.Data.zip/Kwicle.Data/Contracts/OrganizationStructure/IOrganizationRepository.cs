﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.CustomModel.OrganizationStructure;
using Kwicle.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.OrganizationStructure
{
    public interface IOrganizationRepository : IBaseRepository<Organization>
    {
        List<KeyVal<short, string>> GetCompany();
        List<KeyVal<short, string>> GetSubCompany(int? OrganizationID);
        List<OrganizationStructureModel> GetCompanies();
        List<OrganizationHierarchyModel> GetHierarchyOrganizations();
        bool CheckLOBCompany(short Id);

        OrganizationViewModel GetOrganizationDetailsByID(Int16 OrganizationID);
    }
}
