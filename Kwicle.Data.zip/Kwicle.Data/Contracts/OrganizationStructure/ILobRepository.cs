﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;
using Kwicle.Core.CustomModel;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.OrganizationStructure
{
    public interface ILobRepository : IBaseRepository<Lob>
    {
        LobModel GetLobByID(int LobID);
        IQueryable<LobModel> GetLobs();
        Lob GetByID(int LobID);
        List<KeyVal<short, string>> GetBySubCompanyId(int? subCompanyId);
    }
}
