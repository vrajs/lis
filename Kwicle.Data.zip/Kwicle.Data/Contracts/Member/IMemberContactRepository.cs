﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberContactRepository : IBaseRepository<MemberContact>
    {
        IEnumerable<MemberContact> GetAllMemberContact();
        IQueryable<MemberContactViewModel> GetMemberContact(int MemberID);
        List<MemberContactViewModel> GetMemberContactByType(string FamilyCode, int ContactTypeID);
        MemberContactViewModel GetMemberActiveMailingContact(int MemberId);
    }
}
