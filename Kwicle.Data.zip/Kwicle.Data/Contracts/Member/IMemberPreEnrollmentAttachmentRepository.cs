﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Entities.MemberStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberPreEnrollmentAttachmentRepository : IBaseRepository<MemberPreEnrollmentAttachment>
    {

        Task<List<MemberPreEnrollmentAttachmentViewModel>> GetMemberAttachmentByMemberId(int MemberId);
        Task<List<OtherDocument>> GetMemberAttachmentListByMemberId(int memberId);

    }
}
