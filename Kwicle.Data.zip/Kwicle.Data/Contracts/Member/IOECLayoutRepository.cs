﻿using Kwicle.Core.Entities.MemberStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IOECLayoutRepository : IBaseRepository<OECLayout>
    {
        IEnumerable<OECLayout> GetAllOECLayoutByDataFileToProcessDetailsID(int DataFileToProcessDetailsID);
    }
}
