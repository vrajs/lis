﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface ITRRDetailLayoutRepository : IBaseRepository<TRRDetailLayout>
    {
        Task<List<VwTRRDetailLayoutList>> GetTRRDetailLayoutByMemberId(int MemberId);
}
}
