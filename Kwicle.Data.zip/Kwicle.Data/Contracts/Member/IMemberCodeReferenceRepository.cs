﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberCodeReferenceRepository : IBaseRepository<MemberCode>
    {
        IEnumerable<MemberCode> GetAllMemberCodeRef();
        IQueryable<MemberCodeReferenceViewModel> GetMemberCodeRef(string FamilyCode);
    }
}
