﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberPCPRepository : IBaseRepository<MemberPCP>
    {
        IQueryable<MemberPCPViewModel> GetMemberPCP(string FamilyCode);

        IQueryable<MemberProviderViewModel> GetProviderForMember(int MemberID);

        IQueryable<MemberProviderLocationViewModel> GetProviderLocationForMember(int ProviderID, int MemberID);

        List<MemberPCPProviderAndLocationViewModel> GetMemberPCPProviderAndLocation(string FamilyCode);
        MemberPCPViewModel GetPrimaryActivePCP(int MemberID);
    }
}
