﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberCOBRepository : IBaseRepository<MemberCOB>
    {
        List<MemberCOBViewModel> GetMemberCOB(string FamilyCode);
    }
}
