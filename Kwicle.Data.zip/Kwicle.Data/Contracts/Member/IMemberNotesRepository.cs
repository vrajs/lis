﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.Member
{
public interface IMemberNotesRepository:IBaseRepository<MemberNote>
    {
        IEnumerable<MemberNote> GetAllMemberNotes();
        IQueryable<MemberNotesViewModel> GetMemberNotes(string FamilyCode);
    }
}
