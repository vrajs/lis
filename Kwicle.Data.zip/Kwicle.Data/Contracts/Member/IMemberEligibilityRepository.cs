﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;


namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberEligibilityRepository : IBaseRepository<MemberEligibility>
    {
        IEnumerable<MemberEligibility> GetAllMemberEligibility();
        IQueryable<MemberEligibilityViewModel> GetMemberEligibility(string FamilyCode);
        MemberEligibilityViewModel GetSelfMemberPrimaryEligibility(int MemberID);
        MemberEligibilityViewModel GetByID(int MemberEligibilityID);
        int GetTotalEligibilityCount(string FamilyCode);
        List<MemberEligibilityViewModel> GetAllMemberActiveEligibility(string FamilyCode);
        MemberEligibility GetMostRecentEligibility(int MemberID);
    }
}
