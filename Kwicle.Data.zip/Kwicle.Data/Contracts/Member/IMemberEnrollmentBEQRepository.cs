﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure.View;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberEnrollmentBEQRepository : IBaseRepository<MemberPreEnrollment>
    {
        public Task<int> InsertMemberPreEnrollment(MemberPreEnrollment model);
        public Task<int> InsertMemberPreEnrollmentFinal(MemberPreEnrollmentTableViewModel model);
        public Task<int> GetMemberByMBI(string MBI);

        public Task<MemberEnrollmentList[]> GetMemberEnrollmentBEQFiles(MemberEnrollmentSearchModel model);
        
        Task<List<VwBEQdetails>> GetMemberBEQByMemberId(int MemberId);
        Task<VwBEQdetails> GetBEQRequestByDetailLayoutID(int BEQRequestDetailLayoutID);
        Task<MemberPreEnrollment> GetMemberPreEnrollmentByMemberID(int memberID);
    }
}
