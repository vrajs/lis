﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberDiscloserInfoRepository : IBaseRepository<MemberDiscloserInfo>
    {
        IEnumerable<MemberDiscloserInfo> GetAllMemberDiscloserInfo();
        IQueryable<MemberDiscloserInfoViewModel> GetMemberDiscloserInfo(int MemberID);
        List<MemberDiscloserInfoViewModel> GetMemberDiscloserInfoByPHI(string FamilyCode, int DisclosePersonalHealthID);
     }
}
