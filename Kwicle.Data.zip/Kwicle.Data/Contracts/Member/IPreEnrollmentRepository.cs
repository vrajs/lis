﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IPreEnrollmentRepository : IBaseRepository<Kwicle.Core.Entities.MemberStructure.PreEnrollment>
    {
        public int InsertPreEnrollment(PreEnrollment model);
    }
}
