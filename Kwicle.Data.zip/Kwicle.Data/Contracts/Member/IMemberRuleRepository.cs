﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kwicle.Core.Entities.MemberStructure;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberRuleRepository : IBaseRepository<MemberRule>
    {
        public Task<List<MemberRule>> GetMemberRuleById(int sepReasonCodeId);
    }
}


