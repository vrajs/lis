﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Entities.MemberStructure;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberTransactionRepository : IBaseRepository<MemberTransactionDetail>
    {
        Task<List<MemberTransactionViewModel>> GetTransactionByMemberId(int MemberId);
        Task<List<LetterCorrespondanceViewModel>> GetAllLetterCorrespondance();
        Task<List<MemberCorrespondanceViewModel>> GetCorrespondanceByMemberId(int memberId);
        Task<int> AddTransaction(MemberTransactionDetail model, MemberTransactionDetailViewModel mainModel, PlaceHolderReplaceViewModel placeHolderReplaceViewModel);
        Task<int> UpdateTransaction(MemberTransactionDetail model, MemberTransactionDetailViewModel mainModel, PlaceHolderReplaceViewModel placeHolderReplaceViewModel);
    }
}
