﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Entities.MemberStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberEnrollmentHeaderRepository : IBaseRepository<MemberEnrollmentHeader>
    {
        public Task<List<AuditHistory>> GetMemberAuditHistory(int memberId);
        public Task<List<AuditHistory>> GetAuditHistory(AuditHistoryFilterModel auditHistoryFilterModel);
        public Task<MemberEnrollmentHeader> GetPreEnrollmentHeaderByMBI(MemberEnrollmentHeader model);
        public Task<int> InsertEnrollmentHeader(MemberEnrollmentViewModel model);
        public Task<int> UpdateEnrollmentHeader(MemberEnrollmentViewModel model);
        public Task<MemberEnrollmentListViewModel> GetMemberEnrollmentHeader(MemberEnrollmentSearchModel searchModel);
        public Task<List<SEPReasonCode>> GetSepReasonCodeById(int ElectionTypeCodeId);
        public Task<MemberEnrollmentEditViewModel> GetMemberEnrollmentHeaderById(int MemberEnrollmentHeaderID);
        public Task<string> GetNextSequenceNumber(string SettingCode, int Padding);
        public MemberSpan MemberSpanDataMapper(int memberSpanID, int spanType, string spanValue, MemberEnrollmentViewModel model, DateTime? effectiveDate, DateTime? spanTermDate, byte isFreezed);
        Task UpdateAndInsertMemberSpan(MemberEnrollmentViewModel model, int spanType, string spanValue, DateTime? spanEffectivedate, ICollection<MemberSpan> memberSpans, byte isFreezed);
        public Task<List<SEPReasonCode>> GetSepReason();
    }
}
