﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface ITRRFalloutsRepository : IBaseRepository<vwTRRFallouts>
    {
        Task<List<vwTRRFallouts>> GetTRRFalloutsAsync(MemberTRRSearchModel searchModel);
        public Task<bool> UpdateFalloutStatusAsync(MemberTRRUpdateModel updateModel);
    }
}
