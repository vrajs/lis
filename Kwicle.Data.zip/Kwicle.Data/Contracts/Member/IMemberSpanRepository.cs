﻿using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.MemberStructure;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberSpanRepository : IBaseRepository<MemberSpan>
    {
        Task<List<MemberSpanListViewModel>> GetMemberSpanByMemberId(int MemberId);
        Task<MemberSpan> SaveMemberSpan(MemberSpan memberSpan);
        Task<MemberSpan> UpdateMemberSpan(MemberSpan memberSpan);
    }
}
