﻿using Kwicle.Core.CustomModel.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Member
{
    public interface IMemberEnrollmentMarxRepository
    {
        public Task<string> GetPipelineName(int tranTypeId);
        public Task<MemberEnrollmentList[]> GetMemberEnrollmentMarxFiles(MemberEnrollmentSearchModel model);
    }
}
