﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Alert;
using Kwicle.Core.Entities.Master;

namespace Kwicle.Data.Contracts.Alert
{
   public interface IAlertCodeRepository:IBaseRepository<AlertCode>
    {
        IQueryable<AlertCodeViewModel> GetAlertCodes();
    }
}
