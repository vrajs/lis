﻿using Kwicle.Core.CustomModel.Alert;
using Kwicle.Core.Entities.AlertStructure;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Alert
{
    public interface IAlertModuleRepository : IBaseRepository<AlertModule>
    {
        IEnumerable<AlertModule> GetAllAlertModule();
        IQueryable<AlertModuleViewModel> GetAlertModule(int? AlertModuleID, int? SourceModuleID, int? DestinationModuleID, int? AlertDataID);
        IQueryable<AlertModuleViewModel> GetMemberAlerts(string FamilyCode);
    }
}
