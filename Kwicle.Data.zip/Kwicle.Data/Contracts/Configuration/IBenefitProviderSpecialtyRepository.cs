﻿using Kwicle.Core.Entities.BenefitStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitProviderSpecialtyRepository : IBaseRepository<BenefitProviderSpecialty>
    {
        List<BenefitProviderSpecialty> GetByBenefitHeaderID(int BenefitHeaderID);
        //void DeleteByBenefitHeaderID(int BenefitHeaderID);
    }
}
