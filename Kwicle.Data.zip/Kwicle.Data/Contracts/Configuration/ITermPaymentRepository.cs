﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface ITermPaymentRepository : IBaseRepository<TermPayment>
    {
        IQueryable<TermPaymentModel> GetTermPayment(int? TermHeaderId, int? PaymentTypeId);

        IQueryable<TermPaymentModel> GetTermPaymentHistory(int TermHeaderId);
    }
}
