﻿using Kwicle.Core.Entities.ContractStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IContractRepository : IBaseRepository<Contract>
    {
        IQueryable<vwContract> GetContracts();

        void Add(Contract Model, string TermHeaderIDs);

        void CopyContract(int ContractHeaderID, string TermHeaderIDs, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate, DateTime? TermDate);

        void DeleteOrTermContract(int ContractID, string UpdatedBy, DateTime UpdatedDate, byte RecordStatus, string RecordStatusChangeComment, DateTime? TermDate);
    }
}
