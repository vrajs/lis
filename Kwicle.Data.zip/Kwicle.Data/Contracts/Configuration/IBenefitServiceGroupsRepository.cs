﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitServiceGroupsRepository : IBaseRepository<BenefitServiceGroup>
    {
        IQueryable<BenefitServiceGroupModel> GetBenefitServiceGroupsByBenefitHeaderId(int BenefitHeaderID);
    }
}
