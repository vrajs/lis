﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface ITermLimitRepository : IBaseRepository<TermLimit>
    {
        IQueryable<TermLimitModel> GetTermLimitByTermHeaderID(int TermHeaderID);
    }
}
