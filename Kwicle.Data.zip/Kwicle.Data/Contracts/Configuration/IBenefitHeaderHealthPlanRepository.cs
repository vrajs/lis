﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.BenefitStructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitHeaderHealthPlanRepository : IBaseRepository<BenefitHeaderHealthPlan>
    {
        int BulkInsert(List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans);
        int BulkUpdate(List<BenefitHeaderHealthPlan> benefitHeaderHealthPlans);

        BenefitHeaderHealthPlan GetByBenefitAndHealthPlan(int healthPlanId, int benefitHeaderId);
        void BulkTerm(BenefitHeaderHealthPlanTermModel benefitHeaderHealthPlanTermModel);
        void ConfigureBenefitProrityForClaim(int healthPlanID, List<KeyVal<int, short>> listBenefit, string userName, DateTime todaysDate);
        BenefitHeaderHealthPlan Delete(int healthPlanID, int benefitHeaderID, string userName, DateTime todaysDate);
    }
}
