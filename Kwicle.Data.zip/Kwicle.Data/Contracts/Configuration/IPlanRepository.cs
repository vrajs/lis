﻿using Kwicle.Core.CustomModel.Masters;
using Kwicle.Core.Entities;
using System.Linq;
using Kwicle.Core.CustomModel;
using System.Collections.Generic;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Core.CustomModel.Configuration;
using System;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IPlanRepository : IBaseRepository<HealthPlan>
    {
        IQueryable<GetPlanModel> GetPlans();
        IQueryable<GetPlanModel> GetPlans(int benefitHeaderID, bool isInclude);
        void AddBenefitsToPlan(int HealthPlanID, List<int> BenefitHeaderIds, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate);
        void RemovePlanBenefit(int healthPlanID, int benefitHeaderID, DateTime todaysDate, string userName, string removeReason, int recordStatus);
        void RemoveOrTermPlanBenefit(int healthPlanID, List<int> benefitHeaderIDs, DateTime todaysDate, string userName, int recordStatus, string recordStatusChangeComment, DateTime? termDate = null);
        int CopyHealthPlan(int SourceHealthPlanID, string PlanCode, string PlanName, string BenefitHeaderIds, int ApprovalStatusID, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate, DateTime? ApprovalDate, DateTime? TermDate);
        void Delete(int HealthPlanID, DateTime TodaysDate, string UserName, int recordStatus, string RemoveReason, DateTime? termDate = null);
        HasPlanConfigurationDataModel CheckPlanConfigurationHasData(int healthPlanID);

        IQueryable<GetPlanModel> GetActivePlansForMemberEligibility();
    }
}
