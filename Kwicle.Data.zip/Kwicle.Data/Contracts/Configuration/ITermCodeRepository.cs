﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface ITermCodeRepository : IBaseRepository<TermCodes>
    {
        IEnumerable<TermCodeViewModel> GetAllTermCodes(int? TermHeaderId, int? ClinicalCodeTypeId);

        IQueryable<TermCodeViewModel> GetTermCodes(int TermHeaderId, int ClinicalCodeTypeId);
    }
}
