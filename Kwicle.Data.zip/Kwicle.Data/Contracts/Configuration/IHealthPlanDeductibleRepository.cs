﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.HealthPlanStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IHealthPlanDeductibleRepository : IBaseRepository<HealthPlanDeductible>
    {
        IQueryable<HealthPlanDeductibleModel> GetDeductibleOopByPlanOrBenefitID(string fromPage, int planOrBenefitID);
    }
}
