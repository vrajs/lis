﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;

namespace Kwicle.Data.Contracts.Configuration
{
   public interface IBenefitCopayPerDiemRepository : IBaseRepository<BenefitCopayPerDiem>
    {
        IEnumerable<BenefitCopayPerDiem> GetAllBenefitCopayPerDiem();
        IQueryable<BenefitCopayPerDiemViewModel> GetBenefitCopayPerDiem(int BenefitHeaderID);       
    }
}
