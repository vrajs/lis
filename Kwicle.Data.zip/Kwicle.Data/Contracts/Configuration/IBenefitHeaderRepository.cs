﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Core.CustomModel.Configuration;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitHeaderRepository : IBaseRepository<BenefitHeader>
    {
        IQueryable<GetBenefitModel> GetBenefits();
        IQueryable<GetBenefitModel> GetBenefits(int healthPlanId, bool isInclude);
        int CopyBenefit(GetBenefitModel model, int copayCoinsuranceID, string createdBy, DateTime createdDate);
        List<KeyValuePair<int, string>> GetBenefitNames(int BenefitHeaderID);
        void AttachBenefitRange(int[] BenefitHeaderID, int HealthPlanID, DateTime EffectiveDate, string CreatedBy, DateTime CreatedDate);
        void RemoveBenefit(int BenefitHeaderID, DateTime TodaysDate, string UserName, int recordStatus, string recordStatusChangeComment, DateTime? TermDate, string termRason);
        HasBenefitConfigurationDataModel CheckBenefitConfigurationHasData(int benefitHeaderID);
    }
}
