﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using System;
using System.Linq;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface ITermHeaderRepository : IBaseRepository<TermHeader>
    {
        IQueryable<TermHeaderViewModel> GetAllTerm(int? TermHeaderID, int? ContractID);

        int CopyTerm(TermHeaderViewModel model, string CreatedBy, DateTime CreatedDate);

        void DeleteOrTermTermHeader(int TermHeaderId, string UpdatedBy, DateTime UpdatedDate, DateTime? TermDate, byte RecordStatus, string RecordStatusChangeComment);

        HasTermConfigurationDataModel CheckTermConfigurationHasData(int TermHeaderId);
    }
}
