﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IClinicalCodeGroupRepository : IBaseRepository<ClinicalCodeGroup>
    {
        List<KeyValuePair<short,string>> GetClinicalCodeGroup();        
    }
}
