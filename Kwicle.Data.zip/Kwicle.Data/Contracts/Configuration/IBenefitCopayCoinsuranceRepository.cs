﻿using Kwicle.Core.Entities.BenefitStructure;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitCopayCoinsuranceRepository : IBaseRepository<BenefitCopayCoinsurance>
    {
        IEnumerable<BenefitCopayCoinsurance> GetAllBenefitCopayCoinsurance();

        BenefitCopayCoinsurance GetBenefitCopayCoinsuranceByBenefitHeaderId(int BenefitHeaderId);

    }
}
