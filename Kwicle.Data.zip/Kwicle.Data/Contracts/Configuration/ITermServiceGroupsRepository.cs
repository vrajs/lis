﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.ContractStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface ITermServiceGroupsRepository : IBaseRepository<TermServiceGroup>
    {
        IQueryable<TermServiceGroupModel> GetTermServiceGroupsByTermHeaderId(int TermHeaderID);
    }
}
