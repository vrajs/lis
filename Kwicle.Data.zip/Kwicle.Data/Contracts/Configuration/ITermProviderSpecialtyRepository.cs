﻿using Kwicle.Core.Entities.ContractStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface ITermProviderSpecialtyRepository : IBaseRepository<TermProviderSpecialty>
    {
    }
}
