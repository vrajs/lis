﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using System.Linq;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitVisitRepository : IBaseRepository<BenefitVisit>
    {
        IQueryable<BenefitVisitModel> GetByBenefitHeaderID(int benefitHeaderID);
    }
}
