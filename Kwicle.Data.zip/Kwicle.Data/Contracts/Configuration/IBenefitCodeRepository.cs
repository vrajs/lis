﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities.BenefitStructure;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.Configuration
{
    public interface IBenefitCodeRepository : IBaseRepository<BenefitCodes>
    {
        IEnumerable<BenefitCodes> GetAllBenefitCodes();
        IEnumerable<BenefitCodes> GetBenefitCodeByBenefitHeaderId(int BenefitHeaderId);
        IEnumerable<BenefitCodes> GetBenefitCodeByClinicalCodeTypeId(int BenefitHeaderId, int ClinicalCodeTypeId);
        IQueryable<BenefitCodeViewModel> GetBenefitCodes(int BenefitHeaderId, int ClinicalCodeTypeId);
    }
}
