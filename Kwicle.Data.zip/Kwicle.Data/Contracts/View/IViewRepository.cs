﻿using Kwicle.Core.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.View
{
    public interface IViewRepository
    {
        IQueryable<vwCapitation> Capitations { get; }
        IQueryable<vwTerm> Terms { get; }

        IQueryable<vwContract> GetContracts { get; }

        IQueryable<vwPlanCapitation> PlanCapitations { get; }

        IQueryable<vwMembershipCapitation> MembershipCapitations { get; }

        IQueryable<MemberLookupViewModel> MemberLookups { get; }

        IQueryable<ProviderLookupModel> ProviderLookups { get; }

        IQueryable<vwFacilityLookup> FacilityLookups { get; }

        IQueryable<vwClaimList> ClaimList { get; }

        IQueryable<vwClaimLoockup> ClaimLoockups { get; }
        IQueryable<vwClaimBenefit> GetVwClaimBenefits { get; }
        IQueryable<vwClaimServiceContractTermFeeschedule> GetServiceTermContract { get; }
        IQueryable<vwClaimRefundList> GetClaimRefundList { get; }

        IQueryable<vwRuleHeader> GetRuleHeaders { get; }
        IQueryable<vwClaimRefundLetter> GetClaimRefundLetter { get; }

        IQueryable<vwCheckHistoryList> CheckHistoryList { get; }
    }
}
