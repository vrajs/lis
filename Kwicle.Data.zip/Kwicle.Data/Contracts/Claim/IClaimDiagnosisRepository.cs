﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;

namespace Kwicle.Data.Contracts.Claim
{
   public interface IClaimDiagnosisRepository:IBaseRepository<ClaimDiagnosis>
    {
        IEnumerable<ClaimDiagnosis> GetAllClaimDiagnosis();
        IQueryable<ClaimDiagnosisViewModel> GetClaimDiagnosis(long ClaimHeaderID);
        IQueryable<ClaimDiagnosisViewModel> GetClaimDiagnosisProcedure(long ClaimHeaderID);


    }
}
