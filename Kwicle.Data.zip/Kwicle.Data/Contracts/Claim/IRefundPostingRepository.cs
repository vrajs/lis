﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;

namespace Kwicle.Data.Contracts.Claim
{
    public interface IRefundPostingRepository : IBaseRepository<RefundPosting>
    {
        IEnumerable<RefundPosting> GetAllRefundPosting();
        IQueryable<RefundPostingViewModel> GetRefundPosting(int RefundRequestID);
    }
}
