﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;

namespace Kwicle.Data.Contracts.Claim
{
    public interface IClaimProcessingStepsRepository : IBaseRepository<ClaimProcessingSteps>
    {
        IEnumerable<ClaimProcessingSteps> GetAllClaimProcessingSteps();
        IQueryable<ClaimProcessingStepsViewModel> GetClaimProcessingSteps(long ClaimHeaderID);


    }
}
