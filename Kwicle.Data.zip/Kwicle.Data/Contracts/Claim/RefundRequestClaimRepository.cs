﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Common;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Data.Contracts.Claim;

namespace Kwicle.Data.Repositories.Claim
{
    public class RefundRequestClaimRepository : BaseRepository<RefundRequestClaim>, IRefundRequestClaimRepository
    {
        #region Variables
        private readonly KwicleContext _context;
        #endregion

        #region Ctor
        public RefundRequestClaimRepository(KwicleContext context) : base(context)
        {
            _context = context;

        }
        #endregion

        #region Interface Methods Implementation   

        public List<RefundRequestClaimViewModel> GetAllClaims(int RefundRequestID)
        {
            var query = (from rrc in _context.RefundRequestClaims
                         join c in _context.ClaimHeaders on rrc.ClaimHeaderID equals c.ClaimHeaderID
                         where rrc.RefundRequestID == RefundRequestID && rrc.RecordStatus == (byte)RecordStatus.Active
                         select new RefundRequestClaimViewModel()
                         {
                             RefundRequestClaimID = rrc.RefundRequestClaimID,
                             RefundRequestID = rrc.RefundRequestID,
                             ClaimHeaderID = rrc.ClaimHeaderID,
                             MemberID = rrc.MemberID,
                             RequestedAmount = rrc.RequestedAmount,
                             BilledAmount = c.BilledAmount,
                             PaidAmount = c.PaidAmount,
                             ClaimNumber = rrc.ClaimNumber,
                             RecordStatus = rrc.RecordStatus,
                             IsFreezed = rrc.IsFreezed,
                             RecordStatusChangeComment = rrc.RecordStatusChangeComment,
                             CreatedBy = rrc.CreatedBy,
                             CreatedDate = rrc.CreatedDate,
                             UpdatedBy = rrc.UpdatedBy,
                             UpdatedDate = rrc.UpdatedDate,
                             AddedSource = rrc.AddedSource,
                             UpdatedSource = rrc.UpdatedSource,
                             LoadComment = rrc.LoadComment,
                             VendorName = c.VendorName,
                             ProviderGroupTIN = c.ProviderGroupTIN
                         });
            return query.ToList();
        }
        #endregion
    }
}
