﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;

namespace Kwicle.Data.Contracts.Claim
{
    public interface IClaimHeaderRepository : IBaseRepository<ClaimHeader>
    {
        IEnumerable<ClaimHeader> GetAllClaimHeader();
        IQueryable<ClaimHeaderViewModel> GetClaimHeader(long ClaimHeaderID);
        long InsertUpdateClaim(ClaimHeader entity, List<ClaimEditsViewModel> ClaimEditsList = null);
        ClaimHeaderViewModel GetClaimByClaimNumber(string ClaimNumber);
        string GenerateClaimNumber(DateTime ReceivedDate, int ClaimSourceID);
        ClaimHeader GetClaimByID(long ClaimHeaderID);
    }
}
