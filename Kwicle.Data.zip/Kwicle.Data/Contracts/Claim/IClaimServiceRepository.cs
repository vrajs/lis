﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Core.Views;

namespace Kwicle.Data.Contracts.Claim
{
   public interface IClaimServiceRepository:IBaseRepository<ClaimService>
    {
        IEnumerable<ClaimService> GetAllClaimService();
        IQueryable<ClaimServiceViewModel> GetClaimService(long ClaimHeaderID);
        KeyValuePair<int, string> GetServiceContract(int lOBID, DateTime DosFrom, DateTime DosTo);
        Tuple<int, string, decimal> GetServiceFeeSchedule(int ContractID, KeyValuePair<int, string>[] Code, DateTime DosFrom, DateTime DosTo);
        IQueryable<ClaimServiceDollarsViewModel> GetDollarValues(DollarsCalculationModel model);
        decimal AnesthesiaCalculatedValue(long ClaimHeaderID, int Unit, DateTime DosFrom, DateTime DosTo);
        short AnesthesiaUnit(string Code, int lOBID, DateTime DosFrom, DateTime DosTo);
        decimal GetAllowableAmount(int FeeScheduleId, string ProcedureCode, string POSCode, DateTime DosFrom, DateTime DosTo, string[] Modifiers);
    }
}
