﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.CustomModel.Claim;
using Kwicle.Core.Entities.ClaimStructure;

namespace Kwicle.Data.Contracts.Claim
{
    public interface IClaimOtherPhysicianRepository : IBaseRepository<ClaimOtherPhysician>
    {
        IEnumerable<ClaimOtherPhysician> GetAllClaimOtherPhysician();
        IQueryable<ClaimOtherPhysicianViewModel> GetClaimOtherPhysician(long ClaimHeaderID);


    }
}
