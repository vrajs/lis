﻿using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Kwicle.Data.Contracts.EDI.Common
{
    public interface IEDICommonCodeRepository : IBaseRepository<EDICommonCode>
    {
        List<KeyValuePair<int, string>> GetCommonCodesByCodeTypeId(Int16 CommonCodeTypeId, Int16 FetchingTypeId);
       
        List<EDICommonCodeModel> GetCommonCodesByCodeTypeIds(MultipleValueRequestModel request);
        List<KeyValuePair<string, string>> GetCommonCodesKeyAsCodeByCodeTypeId(Int16 CommonCodeTypeId, Int16 FetchingTypeId);
       // List<GetCommonCodeConfigurationModel> GetCommonCodeConfigurationByCodeTypeId(string PageId, int CodeTypeId);
    }
}
