﻿using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEDICommonRepositories : IDisposable
    {
        vwMemberAlertDocument GetDocument(int DocumentID,string DownloadType);
        EDIFIle GetEDIFileDetail(int Docmentid);
    }
}
