﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;


namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi278Repositories : IDisposable
    {
        Edi278AuthorizationRequest GetEdi278Details(int x12_document_id, CurrentTradingPartner currentTradingPartner);

        int InsertAuthorizationRequest(Mtab278AuthorizationRequest authorizationRequest);

        void InsertAuthorzationService(Mtab278AuthorizationRequestService authorizationRequestService);

        void InsertAuthorizationPhysician(Mtab278AuthorizationPhysician authorizationRequestPhysician);

    }
}
