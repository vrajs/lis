﻿using System;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi278ResponseRepositories : IDisposable
    {
        void Transfer278AuthDetails();
    }
}
