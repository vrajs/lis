﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi271Repositories : IDisposable
    {
        Edi271MemberEligibilityResponse GetEdi271Details(int x12InterchangeId, CurrentTradingPartner _currentTradingPartner);
        List<EligibilityRequest> GetEligibilityRequestlistById(int x12DocumentId);        
        int ImportEDI271Data(EDI271Validatemodel objEDI271Validatemodel);
        void SaveSubscriberBenefitInformation(EligibilityResponseDetail[] objentity);
        void SaveDependentBenefitInformation(EligibilityResponseDependentDetail[] objentity);
    }
}

