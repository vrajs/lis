﻿using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi270Repositories : IDisposable
    {
        Edi270MemberEligibilityRequest GetEdi270Details(int x12InterchangeId,CurrentTradingPartner currentTradingPartner);
        Dictionary<string, object> AddEdi270Details(string xmLx12EligibilityRequest, CurrentTradingPartner currentTradingPartner);
        List<vwMemberAlert> GetMemberAlert(MemberAlertGridoption memberAlertGridoption);
        DataSourceResult GetMemberAlertListing(GridOption_View memberAlertListingoption);
        vwMemberAlertDocument GetMemberAlertDocument(int DocumentID);
        void ClaimTrnasfer(int x12_interchange_id);
        IQueryable<EDI270UploadFileModel> GetEDI270UploadFiles();
        IQueryable<EDI270SummaryModel> GetEDI270Summary();
      
    }
}
