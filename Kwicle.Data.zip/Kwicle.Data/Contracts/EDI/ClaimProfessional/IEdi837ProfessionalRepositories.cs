﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi837ProfessionalRepositories : IDisposable
    {
        Edi837PEncounterFileGenerateEntity GetEdi837PDetails(int X12DocumentID, CurrentTradingPartner currentTradingPartner);
        void ClaimBulkInsert(List<ClaimProfessionalOutbound> ClaimProfessionals);
        void ClaimServiceulkInsert(List<ClaimProfessionalServicesOutbound> ClaimProfessionalServices);
        void ClaimTrnasfer(int x12_interchange_id);
        DataSourceResult GetClaimProfesstional(GridOption_View objGridOption_View);
        DataSourceResult GetClaimProfesstionalByStatus(GridOption_View objGridOption_View);
        List<TradingPartnerList> GetTradingPartnerList();
        bool UpdateClaimPByStatus(ClaimActiveStatusParam objRequestparmList);
        void UpdateClaimStatus(int ClaimProfessionalId, int ClaimStatus,DateTime UpdatedDateClaimReferenceNo,string ClaimReferenceNo);
        List<FileExists> IsFileExists(string isa09_interchange_date, string isa10_interchange_time, string isa13_control_no, string gs04_date, string gs05_time, string filetype, int TradingPartnerId,int DataFileConfigurationID);
        List<vwFileHistory> GetFileHistory(int x12_DocumentID);       
        ClaimProfessional GetClaimProfessional(int Claimid);
        ClaimProfessionalServices GetClaimProfessionalServices(int? Claimid, int? ServiceId);

        bool SaveClaimDetail(ClaimProfessional ClaimDetail, bool isApplySameFix);
        bool SaveClaimDetailServiceLine(ClaimProfessionalServices ClaimProfessionalServices);
        bool AddClaimDetailServiceLine(ClaimProfessionalServices ClaimProfessionalServices);
        #region HPS
        IQueryable<EDI837PUploadFileModel> GetEdi837P();
        IQueryable<EDI837PClaimModel> GetEdi837PClaims();
        IQueryable<ServiceLine> GetClaimServiceLine(int Claimid, int ServiceId);
        bool DeleteClaimByFileID(List<int> Files, string strUserName, DateTime date);
        vwCMS1500 GetCMS1500Data(int Claimoid);       

        List<ClaimProfessional> GetPendingProfessionalClaim(int NumberOfclaim);
        //EdiMemberMatched GetMemberId(EdiMemberLookupSearch EdiMemberLookupSearchPara);
        //int GetProviderID(EdiProviderLookupSearch EdiProviderLookupSearchPara);
        IQueryable<EncounterFileList> GetEncounterFileList();
        IQueryable<EDIEncounterListModel> GetEncounterClaimList();
        #endregion
    }
}
