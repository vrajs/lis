﻿using Kwicle.Core.Entities.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IClaimProfessionalErrorRepositories
    {
        void Add(ClaimProfessionalError ClaimError);

        void Add(XElement xmlElements);

        void ErrorFixed(ClaimProfessionalError ClaimError);
    }
}
