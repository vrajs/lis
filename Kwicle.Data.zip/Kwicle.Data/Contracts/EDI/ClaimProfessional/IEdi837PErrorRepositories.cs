﻿using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi837PErrorRepositories
    {
        List<vwClaimProfessionalError> GetProfessionalClaimError(int ClaimProfessionalId, string strErrorCode);
        List<KeyValuePair<string, string>> GetProfessionalClaimErrorByClaimId(int ClaimId);
        List<vwClaimProfessionalError> GetProfessionalClaimErrorHistory(int ClaimProfessionalId);
        IQueryable<vwClaimErrorsModule> GetProfessionalClaimErrors();

        IQueryable<EDI837PErrorClaimModel> GetProfessionalErrorClaim();
        vwEDIMember GetMemberById(int memberid);
        vwEDIProvider GetproviderById(int providerid);
        void UpdateClaimProfessionalError(vwClaimProfessionalErrorModel objModel);

        EDIMembermodel GetMemberProfessionalByClaimId(int ClaimId);
        
    }
}
