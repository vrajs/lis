﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEDI837PEncounterRepositories
    {
        void UpdateEncounter(int X12_document_oid, string UserName, DateTime UpdateDate);
    }
}
