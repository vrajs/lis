﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEDI837IDiagCodeRepository : IBaseRepository<InstitutionalDiagnosisCode>
    {
        IQueryable<vwInstitutionalDiagnosisCode> GetInstitutionalDiagnosisCode(InstitutionalDiagnosisCodeParam objparam);

        bool CheckDuplicateDiag(vwInstitutionalDiagnosisCode obj);
    }
}
