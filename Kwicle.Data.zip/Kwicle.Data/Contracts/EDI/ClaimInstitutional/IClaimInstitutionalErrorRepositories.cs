﻿using Kwicle.Core.Entities.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IClaimInstitutionalErrorRepositories
    {
        void Add(ClaimInstitutionalError ClaimError);

        void Add(XElement xmlElements);

        void ErrorFixed(ClaimInstitutionalError ClaimError);
    }
}
