﻿using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi837IErrorRepositories
    {
        List<vwClaimProfessionalError> GetInstitutionalClaimError(int ClaimProfessionalId, string strErrorCode);
        List<KeyValuePair<string, string>> GetInstitutionalClaimErrorByClaimId(int ClaimId);
        List<vwClaimProfessionalError> GetInstitutionalClaimErrorHistory(int ClaimProfessionalId);
        IQueryable<vwClaimErrorsModule> GetInstitutionalClaimErrors();

        IQueryable<EDI837IErrorClaimModel> GetInstitutionalErrorClaim();
        vwEDIMember GetMemberById(int memberid);
        vwEDIProvider GetproviderById(int providerid);
        void UpdateClaimInstitutionalError(vwClaimProfessionalErrorModel objModel);
        EDIMembermodel GetMemberInstitutionalByClaimId(int ClaimId);
    }
}
