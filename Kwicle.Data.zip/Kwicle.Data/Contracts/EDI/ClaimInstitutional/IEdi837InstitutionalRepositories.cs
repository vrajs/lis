﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi837InstitutionalRepositories : IDisposable
    {
        Edi837IEncounterFileGenerateEntity GetEdi837IDetails(int X12_documentID, CurrentTradingPartner currentTradingPartner);
        void ClaimTrnasfer(int x12_interchange_id);
        List<FileExists> IsFileExists(string isa09_interchange_date, string isa10_interchange_time, string isa13_control_no, string gs04_date, string gs05_time, CurrentTradingPartner currentTradingPartner);
        IQueryable<EDI837PUploadFileModel> GetEdi837IFilesList();
        IQueryable<EDI837PClaimModel> GetEdi837IClaimsList();
        bool DeleteClaimByFileID(List<int> Files, string strUserName, DateTime date);

        List<vwClaimProfessionalError> GetInstitutionalClaimError(int ClaimInstitutionalId);
        List<vwClaimProfessionalError> GetInstitutionalClaimErrorHistory(int ClaimInstitutionalId);

        #region CLaim edit detail
        ClaimInstitutional GetClaimInstitutional(int ClaimInstitutionalID);
        ClaimInstitutionalServices GetClaimInstitutionalServices(int? Claimid, int? ServiceId);
        bool SaveClaimDetail(ClaimInstitutional ClaimDetail, bool isApplySameFix);
        bool SaveClaimDetailServiceLine(ClaimInstitutionalServices ClaimInstitutionalServices);
        bool AddClaimDetailServiceLine(ClaimInstitutionalServices ClaimInstitutionalServices);
        #endregion

        #region Claim Submisstion To HPs
        List<ClaimInstitutional> GetPendingInstitutionalClaim(int NumberOfclaim);
        void UpdateClaimStatus(int ClaimInstitutionalID, int ClaimStatus,DateTime UpdatedDate, string ClaimReferenceNo);
        #endregion

    }
}
