﻿using Kwicle.Core.Entities.EDI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdiErrorRepositories
    {
        IQueryable<MtabMError> GetClaimErrorID(string ErrorMessage);

        int Add(MtabMError Error);
    }
}
