﻿using Kwicle.Core.Entities.EDI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IElementRepository: IBaseRepository<Element>
    {
    }
}
