﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Core.Views;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi834Repositories : IDisposable
    {
        IQueryable<EDI834FileModel> EDI834Files();

        IQueryable<Edi834MemberSummaryModel> Edi834MemberDetail();

        Edi834EnrollmentFileGenerateEntity GetEdi834Details(int X12DocumentID, CurrentTradingPartner currentTradingPartner);

        void ImportMemberDetail(int x12_document_id, List<MemberBenefitEnrollment> MemberBenefitEnrollmentList);

        void Delete(List<int> x12_document_id);

        List<KeyValuePair<string, string>> GetMemberEnrollmentErrors(int MemberEnrollmentID);

        void ClaimTrnasfer(int x12_interchange_id);

        int SaveX12BenefitEnrollment(X12834BenefitEnrollmentHeader objEntity);

        IQueryable<Edi834InboundMemberFileSummaryModel> Edi834ImportMemberDetail();

        IQueryable<Edi834MemberInboundSummaryModel> EDI834MemberListMemberSummary();

        void DeleteMemeberInbound(List<int> x12_document_ids);

        IQueryable<vwMemberEnrollmentProvider> GetMemberEnrollmentProvider();

        IQueryable<vwMemberEnrollmentCOB> GetMemberEnrollmentCOB();

        IQueryable<vwMemberEnrollmentCoverage> GetMemberEnrollmentCoverage();

        IQueryable<vwMemberEnrollment> GetMemberEnrollment();
    }
}
