﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi835RemittanceRepositories :  IDisposable
    {
        EDI835RemittanceAdviceGenerate GetEdi835Details(int x12_document_id, CurrentTradingPartner currentTradingPartner);
        void PaymentTrnasfer(int x12_interchange_id);
        IQueryable<EDI835CheckModel> GetEdi835Check();

        int ImportRemittanceAdvice(ImportRemittanceAdviceModel objImportRemittanceAdviceModel);
        IQueryable<EDI835CheckClaimSummaryModel> GetEdi835CheckClaimSummary();  
    }
}
