﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
namespace Kwicle.Data.Contracts.EDI
{
    public interface IX12DocumentResponseRepositories : IDisposable
    {
        int Add(X12DocumentResponse X12DocumentResponse);
        int Update(X12DocumentResponse X12DocumentResponse);
    }
}
