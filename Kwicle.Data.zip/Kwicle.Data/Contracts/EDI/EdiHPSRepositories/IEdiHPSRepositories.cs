﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Core.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdiHPSRepositories : IDisposable
    {
        EdiMemberMatched GetMemberId(EdiMemberLookupSearch EdiMemberLookupSearchPara);
        EDI271Validatemodel GetMemberEligiblityValidate(EdiMemberLookupSearch MemberInfo);
        List<vwEligibilityResponse> GetMemberEligiblityBenefitInformation(int MemberID);
        EdiProviderMatched GetProviderID(EdiProviderLookupSearch EdiProviderLookupSearchPara);        
        ImportRemittanceAdviceModel GetRemittanceAdvice(ImportRemittanceAdviceModel objImportRemittanceAdviceModel);
        List<vwMemberBenefitEnrollment> GetMemberBenefitEnrollment(int CalenderDateID, string TradingPartnerID);
        IQueryable<TradingPartnerBenefitConfigurationModel> GetPlanBenefitCode();
        void AddOrUpdate(TradingPartnerBenefitConfiguration TradingPartnerBenefitConfigurationModel);
        List<DbColumnInfo> GetTableSchema<T>();
        IQueryable<vwMemberPCP> GetMemberPCP();
        IQueryable<HealthPlanDeductible> GetHealthPlanDeductible();
    }
}
