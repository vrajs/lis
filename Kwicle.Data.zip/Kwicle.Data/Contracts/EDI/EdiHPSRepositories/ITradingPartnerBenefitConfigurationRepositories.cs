﻿using Kwicle.Core.Entities.BenefitStructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.EDI
{
    public interface ITradingPartnerBenefitConfigurationRepositories: IBaseRepository<TradingPartnerBenefitConfiguration>
    {
    }
}
