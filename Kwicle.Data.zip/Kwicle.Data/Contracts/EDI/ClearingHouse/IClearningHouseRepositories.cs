﻿using Kwicle.Core.Entities.EDI;
using System;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IClearningHouseRepositories : IDisposable
    {
        ClearingHouse GetDetails(Guid clearingHouseId);
    }
}
