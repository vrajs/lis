﻿using Kwicle.Core.Entities.EDI;
using System;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IX12_Level1AckRepositories : IDisposable
    {
        void Add(X12Level1Ack x12_Level1Acknoledgement);
    }
}
