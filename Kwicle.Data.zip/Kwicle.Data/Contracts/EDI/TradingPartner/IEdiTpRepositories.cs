﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdiTpRepositories : IBaseRepository<TradingPartner>
    {        
        IQueryable<vwTradingPartnerSummary> GetTradingPartnerDetails();

        DataSourceResult GetTradingPartnerDetail(GridOption_View objGridOption_View);

        IEnumerable<string> GetModuleNames();
        
        #region HPS
        IQueryable<TradingPartner> GetTradingPartnerList();

        List<KeyValuePair<short, string>> GetddlTradingPartnerList(string TranType, string FileType);

        IQueryable<DataConfigurationModel> GetDataConfigByTId(short TradingPartnerId);

        short SaveTradingPartnerDetail(TradingPartner objTradingPartner);

        void UpdateTradingPartnerDetail();

        TradingPartner GetTradingPartnerByTId(short TradingPartnerId);

        //Datafileconfiguration
        DataFileConfiguration GetDataFileConfigurationById(short DataFileConfigurationId);

        bool CheckDuplicateDataConfig(DataConfigurationModel obj);

        Task<short> SaveDataConfigurationDetail(DataFileConfiguration objDataFileConfiguration);

        void UpdateConfigurationDetail(DataFileConfiguration obj);

        void UpdateContext();

        int GetDataFileConfigurationID(int TradingPartnerID, int TranTypeId, int FileTypeID);
        
        //FileNamingConvention
        short SaveFileNamingConventionDetail(FileNamingConvention obj, short DataFileConfigurationId);

        FileNamingConvention GetFileNamingConventionById(short FileNamingConventionID);

        void UpdateFileNamingConvention(FileNamingConvention obj);

        void DeleteFileNamingConvention(short DataFileConfigurationId,FileNamingConvention obj);

        List<FileNamingSequence> GetlistFileNamingSequenceId(short FileNamingConventionID);

        #endregion
    }
}
