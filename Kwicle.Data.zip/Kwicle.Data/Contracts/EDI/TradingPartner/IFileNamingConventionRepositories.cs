﻿using Kwicle.Core.Entities.EDI;
using System;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IFileNamingConventionRepositories : IDisposable
    {
        IEnumerable<FileNamingConvention> GetDetails();
        FileNamingConvention GetDetails(short? fileNameId);
    }
}
