﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IPlanBenefitConfigurationRepositories
    {
    }
}
