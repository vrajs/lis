﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi277Repositories : IDisposable
    {
        Edi277ClaimStatusResponse GetEdi277Details(int x12InterchangeId, CurrentTradingPartner _currentTradingPartner);
        void ImportEDI277Data(int x12DocumentId, List<ClaimStatusResponseDetailModel> ClaimResponse);
        List<ClaimStatusRequestDetailModel> GetClaimStatusDetail(int x12DocumentId);
        List<ClaimHeaderDetails> GetHpsClaimStatusDetail(List<string> ClaimNumbers);
        IQueryable<ClaimStatusMapping> GetClaimStatusMapping();
    }
}
