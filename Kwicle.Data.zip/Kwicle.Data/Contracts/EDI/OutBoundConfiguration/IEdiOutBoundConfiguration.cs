﻿using Kwicle.Core.CustomModel;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdiOutBoundConfiguration : IBaseRepository<OutboundMappingconfiguration>
    {
        List<DbColumnInfo> GetTableSchema<T>();
        IQueryable<vwElementMappingSource> GetMappingSource();
        IQueryable<vwOutboundMappingConfiguration> GetOutboundConfiguration();
        IQueryable<Element> GetElement();
        void AddMapping(OutboundMappingconfiguration MappingConfigurations);
    }
}
