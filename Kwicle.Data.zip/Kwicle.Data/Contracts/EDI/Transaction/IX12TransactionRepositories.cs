﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IX12TransactionRepositories
    {
        int ValidateTransaction(EDIDocumentParseModel objModel, X12Transaction objtran);
    }
}
