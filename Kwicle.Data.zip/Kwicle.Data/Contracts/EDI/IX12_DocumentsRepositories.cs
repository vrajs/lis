﻿using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using System;
using System.Collections.Generic;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IX12DocumentsRepositories : IDisposable
    {
        int Add(X12Document x12Document);

        X12Document Get(int ID);

        void UpdateDocument(int x12Documentid, X12Document Document);

        void UpdateDocument(Guid x12DocumentUid, X12Document Document);

        void AddDataFileToProcess(DataFileToProcess dataFileToProcess);

        Dictionary<string, object> ParseEdiDocument(string ediContents, int tradingpartnerid, int DataFileConfigurationID);

        Dictionary<string, object> ParseEdiDocument(int? x12_Document_ID, int clientId);

        List<vwX12ParseTemp> GetFileData(int x12_Document_ID);

        void AddFileHistory(FileProcessHistory fileProcessHistory);
        int GetDocumentIdByGuid(Guid X12DocumentUid);
        List<FileExists> IsFileExists(string isa09_interchange_date, string isa10_interchange_time, string isa13_control_no, string gs04_date, string gs05_time, string filetype, int TradingPartnerId, int DataFileConfigurationID);

        EDIDocumentParseValidateModel ValidateDocumentAndParse(EDIDocumentParseModel ediDocumentParseModel);
    }
       
}
