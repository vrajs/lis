﻿using Kwicle.Core.Entities.EDI.Custom;
using System;

namespace Kwicle.Data.Contracts.EDI
{
    public interface IEdi277CARepositories : IDisposable
    {
        Edi277CAClaimStatusAcknowledgement GetEdi277CADetails(int x12InterchangeId);
        void AddClaimStatus(int x12_document_id,int ClaimId);
        void UpdateRecordStatus(int x12_document_id);
    }
}
