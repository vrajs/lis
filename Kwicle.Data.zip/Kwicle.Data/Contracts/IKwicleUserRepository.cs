﻿using Kwicle.Core.Entities;

namespace Kwicle.Data.Contracts
{
    public interface IKwicleUserRepository : IBaseRepository<KwicleUser>
    {
        // KwicleUser
        KwicleUser GetUser(string userName);
    }
}
