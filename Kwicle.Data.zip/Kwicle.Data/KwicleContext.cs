﻿using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.Entities;
using Kwicle.Core.Entities.AlertStructure;
using Kwicle.Core.Entities.BenefitStructure;
using Kwicle.Core.Entities.ClaimStructure;
using Kwicle.Core.Entities.CommonStructure;
using Kwicle.Core.Entities.ContractStructure;
using Kwicle.Core.Entities.DataFileStructure;
using Kwicle.Core.Entities.FinanceStructure;
using Kwicle.Core.Entities.HealthPlanStructure;
using Kwicle.Core.Entities.Master;
using Kwicle.Core.Entities.MemberStructure;
using Kwicle.Core.Entities.OrganizationRuleStructure;
using Kwicle.Core.Entities.OrganizationStructure;
using Kwicle.Core.Entities.ProviderStructure;
using Kwicle.Core.Entities.ETLStructure;
using Kwicle.Core.Views;
using Kwicle.Data.Contracts;
using Kwicle.Data.Extensions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
//using System.Data;
using Microsoft.Data;
using System.Linq;
using System.Reflection;
using System.Data;
using Kwicle.Core.Entities.MemberStructure.View;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.CustomModel.ETLStructure;
using Kwicle.Core.Kwicle.Core.Entities.Files;
using Kwicle.Core.Entities.Files;

namespace Kwicle.Data
{
    //[AuditDbContext(Mode = AuditOptionMode.OptOut, IncludeEntityObjects = false, AuditEventType = "{database}_{context}")]
    public class KwicleContext : DbContext
    {
        public IConfiguration Configurationuration { get; }

        public KwicleContext(DbContextOptions<KwicleContext> options, IConfiguration configuration)
          : base(options)
        {
            Configurationuration = configuration;
        }

        public DbSet<Clinic> Clinics { get; set; }
        public DbSet<OldProvider> OldProviders { get; set; }
        public DbSet<Procedure> Procedures { get; set; }
        public DbSet<Audit_EventLog> Audit_EventLog { get; set; }

        public DbSet<CodeType> CodeTypes { get; set; }
        public DbSet<CommonCode> CommonCodes { get; set; }
        public DbSet<CommonCodeDisplayConfiguration> CommonCodeDisplayConfigurations { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Lob> Lobs { get; set; }
        public DbSet<Sponsor> Sponsors { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductType> ProductTypes { get; set; }
        public DbSet<Organization> Organizations { get; set; }
        public DbSet<DRGGroupHeader> DRGGroups { get; set; }

        public DbSet<ICDCode> ICDCodes { get; set; }
        public DbSet<CPTCode> CPTCodes { get; set; }
        public DbSet<POSCode> POSCodes { get; set; }
        public DbSet<RevenueCode> RevenueCodes { get; set; }
        public DbSet<DRGCode> DRGCodes { get; set; }
        public DbSet<DRGCodeWeight> DRGCodeWeights { get; set; }
        public DbSet<HCCCode> HCCCodes { get; set; }
        public DbSet<OtherCode> OtherCodes { get; set; }
        public DbSet<NDCCode> NDCCodes { get; set; }

        public virtual DbSet<HealthPlan> HealthPlans { get; set; }
        public DbSet<HealthPlanDeductible> HealthPlanDeductibles { get; set; }
        public DbSet<VisitCode> VisitCodes { get; set; }
        public DbSet<CopayCoinsurance> CopayCoinsurances { get; set; }
        public DbSet<BenefitHeader> BenefitHeaders { get; set; }

        public virtual DbSet<BenefitHeaderHealthPlan> BenefitHeaderHealthPlans { get; set; }

        public DbSet<BenefitProvider> BenefitProviders { get; set; }
        public DbSet<BenefitVisit> BenefitVisits { get; set; }
        public DbSet<BenefitCodes> BenefitCodes { get; set; }
        public DbSet<BenefitProviderSpecialty> BenefitProviderSpecialties { get; set; }
        public DbSet<BenefitCopayPerDiem> BenefitCopayPerDiems { get; set; }
        public DbSet<BenefitCopayCoinsurance> BenefitCopayCoinsurances { get; set; }
        public DbSet<ClinicalCodeGroup> ClinicalCodeGroups { get; set; }
        public DbSet<ClinicalCodeSubGroup> ClinicalCodeSubGroups { get; set; }
        public DbSet<ClinicalCodeGroupDetail> ClinicalCodeGroupDetails { get; set; }
        public DbSet<Specialty> Specialties { get; set; }
        public DbSet<BillTypeCode> BillTypeCodes { get; set; }
        public DbSet<BenefitVisitLimitShare> BenefitVisitLimitShares { get; set; }
        public DbSet<ZipCode> ZipCodes { get; set; }
        public DbSet<BenefitServiceGroup> BenefitServiceGroups { get; set; }

        public DbSet<InsuranceCarrier> InsuranceCarriers { get; set; }

        public DbSet<SystemSetting> SystemSettings { get; set; }

        public DbSet<SeqNumber> SeqNumbers { get; set; }

        public DbSet<TemplateSubType> TemplateSubTypes { get; set; }

        public DbSet<Template> Templates { get; set; }

        public DbSet<PlaceHolder> PlaceHolders { get; set; }

        public DbSet<TemplatePlaceHolder> TemplatePlaceHolders { get; set; }

        public DbSet<JulianCalendar> JulianCalendars { get; set; }

        public DbSet<JulianCalendarSeqNumber> JulianCalendarSeqNumber { get; set; }

        public DbSet<EditCode> EditCode { get; set; }

        public DbSet<EditCodeDisplayConfiguration> EditCodeDisplayConfiguration { get; set; }

        public DbSet<SearchCriteria> SearchCriterias { get; set; }

        public DbSet<Location> Locations { get; set; }

        public DbSet<TradingPartnerBenefitConfiguration> TradingPartnerBenefitConfigurations { get; set; }

        public DbSet<RegionZipCode> RegionZipCodes { get; set; }
        public DbSet<LetterCorrespondance> LetterCorrespondance { get; set; }
        #region DbQuery
        public DbSet<vwRuleHeader> GetRuleHeaders { get; set; }

        public DbSet<GetBenefitModel> GetBenefits { get; set; }

        public DbSet<GetPlanModel> GetPlans { get; set; }
        #endregion

        #region Supporting Tables
        public DbSet<AgeGroup> AgeGroups { get; set; }
        public DbSet<AnesthesiaRegionRate> AnesthesiaRegionRates { get; set; }
        public DbSet<AnesthesiaCodeUnit> AnesthesiaCodeUnits { get; set; }
        public DbSet<AnesConversionFactor> AnesConversionFactors { get; set; }
        public DbSet<TimelyFiling> TimelyFilings { get; set; }
        public DbSet<FeeScheduleLimit> FeeScheduleLimits { get; set; }
        public DbSet<FeeScheduleHeader> FeeScheduleHeaders { get; set; }
        public DbSet<FeeScheduleDetail> FeeScheduleDetails { get; set; }
        public DbSet<InterestQuickPay> InterestQuickPays { get; set; }
        public DbSet<ModifierDiscountGroup> ModifierDiscountGroups { get; set; }
        public DbSet<ModifierDiscount> ModifierDiscounts { get; set; }
        public DbSet<Region> Regions { get; set; }
        public DbSet<Locality> Localities { get; set; }
        public DbSet<GPCI> GPCIs { get; set; }
        public DbSet<RBRVSCode> RBRVSCodes { get; set; }
        public DbSet<RBRVS> RBRVS { get; set; }
        #endregion

        #region Member Structure
        public DbSet<Member> Members { get; set; }
        public DbSet<MemberContact> MemberContacts { get; set; }
        public DbSet<MemberDependent> MemberDependents { get; set; }
        public DbSet<MemberEligibility> MemberEligibilitys { get; set; }
        public DbSet<MemberPCP> MemberPCPs { get; set; }
        public DbSet<MemberCode> MemberCodes { get; set; }
        public DbSet<MemberNote> MemberNotes { get; set; }
        public DbSet<MemberCOB> MemberCOBs { get; set; }
        public DbSet<MemberCOBLetter> MemberCOBLetters { get; set; }
        public DbSet<MemberBilling> MemberBillings { get; set; }
        public DbSet<RateCode> RateCodes { get; set; }
        public DbSet<MemberBillingPayment> MemberBillingPayments { get; set; }
        public DbSet<MemberCostShare> MemberCostShares { get; set; }
        public DbSet<MemberDiscloserInfo> MemberDiscloserInfos { get; set; }
        public DbSet<MemberEnrollmentHeader> MemberEnrollmentHeader { get; set; }

        public DbSet<MemberEnrollmentHeaderAttachment> MemberEnrollmentHeaderAttachment { get; set; }
        public DbSet<MemberPreEnrollment> MemberPreEnrollment { get; set; }
        public DbSet<MemberPreEnrollmentAttachment> MemberPreEnrollmentAttachment { get; set; }
        public DbSet<MemberCMSDetail> MemberCMSDetails { get; set; }
        public DbSet<MemberTransactionDetail> MemberTransactionDetails { get; set; }
        public DbSet<OECLayout> OECLayout { get; set; }
        public DbSet<MemberOtherCoverage> MemberOtherCoverages { get; set; }
        public DbSet<MemberEnrollmentDetail> MemberEnrollmentDetails { get; set; }
        public DbSet<TRRDetailLayout> TRRDetailLayouts { get; set; }
        public DbSet<MemberPremiumDetail> MemberPremiumDetails { get; set; }
        public DbSet<MemberSpan> MemberSpans { get; set; }
        public DbSet<MemberRule> MemberRules { get; set; }
        public DbSet<CommonList> CommonList { get; set; }


        #endregion

        #region Member Structure View
        public DbSet<VwBEQdetails> VwBEQdetails { get; set; }
        public DbSet<VwTRRDetailLayoutList> VwTRRDetailLayoutList { get; set; }

        public DbSet<vwTRRFallouts> VwTRRFallouts { get; set; }

        #endregion
        #region Files
        public DbSet<FullEnrollmentDetailLayout> FullEnrollmentDetailLayout { get; set; }
        public DbSet<LossOfSubsidyDetailLayout> LossOfSubsidyDetailLayout { get; set; }
        public DbSet<LTIResident> LTIResident { get; set; }
        public DbSet<MMSRDetailLayout> MMSRDetailLayout { get; set; }
        public DbSet<NoRxDetailLayout> NoRxDetailLayout { get; set; }
        public DbSet<MPWRDDetailLayout> MPWRDDetailLayout { get; set; }
        public DbSet<MembershipDetailLayout> MembershipDetailLayout { get; set; }
        public DbSet<MARxRequestT94Layout> MARxRequestT94Layout { get; set; }
        public DbSet<MARxRequestT93Layout> MARxRequestT93Layout { get; set; }
        public DbSet<MARxRequestT92Layout> MARxRequestT92Layout { get; set; }
        public DbSet<MARxRequestT81Layout> MARxRequestT81Layout { get; set; }
        public DbSet<MARxRequestT80Layout> MARxRequestT80Layout { get; set; }
        public DbSet<MARxRequestT79Layout> MARxRequestT79Layout { get; set; }
        public DbSet<MARxRequestT78Layout> MARxRequestT78Layout { get; set; }
        public DbSet<MARxRequestT77Layout> MARxRequestT77Layout { get; set; }
        public DbSet<MARxRequestT76Layout> MARxRequestT76Layout { get; set; }
        public DbSet<MARxRequestT75Layout> MARxRequestT75Layout { get; set; }
        public DbSet<MARxRequestT74Layout> MARxRequestT74Layout { get; set; }
        public DbSet<MARxRequestT73Layout> MARxRequestT73Layout { get; set; }
        public DbSet<MARxRequestT72Layout> MARxRequestT72Layout { get; set; }
        public DbSet<MARxRequestT51Layout> MARxRequestT51Layout { get; set; }
        public DbSet<MARxRequestT61Layout> MARxRequestT61Layout { get; set; }
        public DbSet<MAMSDetailLayout> MAMSDetailLayout { get; set; }
        public DbSet<LISPartDPremiumDetailLayout> LISPartDPremiumDetailLayout { get; set; }
        public DbSet<LISHISTDetailLayout> LISHISTDetailLayout { get; set; }
        public DbSet<LEPDetailLayout> LEPDetailLayout { get; set; }
        public DbSet<BEQResponseDetailLayout> BEQResponseDetailLayout { get; set; }
        public DbSet<BEQRequestDetailLayout> BEQRequestDetailLayout { get; set; }
        public DbSet<AgentCompDetailLayout> AgentCompDetailLayout { get; set; }

        #endregion
        #region Contract Structure        
        public DbSet<Contract> Contracts { get; set; }
        public DbSet<ContractClaimType> ContractClaimTypes { get; set; }
        public DbSet<TermHeader> TermHeaders { get; set; }
        public DbSet<TermCodes> TermCodes { get; set; }
        public DbSet<TermProviderSpecialty> TermProviderSpecialties { get; set; }
        public DbSet<TermServiceGroup> TermServiceGroups { get; set; }
        public DbSet<TermLimit> TermLimits { get; set; }
        public DbSet<DRGPaymentPayPercent> DRGPaymentPayPercents { get; set; }
        public DbSet<TermPayment> TermPayments { get; set; }
        public DbSet<CapitationHeader> CapitationHeaders { get; set; }
        public DbSet<PlanCapitation> PlanCapitations { get; set; }
        public DbSet<MembershipCapitation> MembershipCapitations { get; set; }
        #endregion
        #region Audit
        public DbSet<AuditHistory> AuditHistorys { get; set; }
        #endregion
        #region Claim Structure

        public DbSet<ClaimHeader> ClaimHeaders { get; set; }
        public DbSet<ClaimDiagnosis> ClaimDiagnoses { get; set; }
        public DbSet<ClaimService> ClaimServices { get; set; }
        public DbSet<ClaimAudit> ClaimAudits { get; set; }
        public DbSet<ClaimNotes> ClaimNotes { get; set; }
        public DbSet<ClaimOtherInsurance> ClaimOtherInsurances { get; set; }
        public DbSet<ClaimEdits> ClaimEditss { get; set; }
        public DbSet<ClaimReference> ClaimReferences { get; set; }
        public DbSet<ClaimProcessingSteps> ClaimProcessingStepss { get; set; }
        public DbSet<ClaimEOBEOP> ClaimEOBEOPs { get; set; }
        public DbSet<ClaimUBCodes> ClaimUBCodess { get; set; }
        public DbSet<ClaimOtherPhysician> ClaimOtherPhysicians { get; set; }
        public DbSet<ClaimStatus> ClaimStatuses { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<ClaimHeaderPayment> ClaimHeaderPayments { get; set; }
        public DbSet<MassAdjudication> MassAdjudications { get; set; }
        public DbSet<AdjudicationRequestHeader> AdjudicationRequestHeaders { get; set; }
        public DbSet<AdjudicationRequestDetail> AdjudicationRequestDetails { get; set; }
        public DbSet<RefundStatus> RefundStatuses { get; set; }
        public DbSet<RefundRequest> RefundRequests { get; set; }
        public DbSet<RefundRequestClaim> RefundRequestClaims { get; set; }
        public DbSet<RefundReceived> RefundReceiveds { get; set; }
        public DbSet<RefundPosting> RefundPostings { get; set; }
        public DbSet<RefundNote> RefundNotes { get; set; }
        public DbSet<RefundLetter> RefundLetters { get; set; }

        public DbSet<AlertCode> AlertCodes { get; set; }

        public DbSet<AlertModule> AlertModules { get; set; }



        public DbSet<UserDataAuthorization> UserDataAuthorizations { get; set; }

        public DbSet<OtherDocument> OtherDocuments { get; set; }
        public DbSet<OtherNote> OtherNotes { get; set; }

        #endregion

        #region Provider Structure
        public DbSet<IPA> IPAs { get; set; }
        public DbSet<IPALOB> IPALOBs { get; set; }
        public DbSet<ProviderIPA> ProviderIPAs { get; set; }
        public DbSet<Provider> Providers { get; set; }
        public DbSet<ProviderLocation> ProviderLocations { get; set; }
        //public DbSet<ProviderMap> ProviderMaps { get; set; }
        public DbSet<ProviderContract> ProviderContracts { get; set; }
        public DbSet<ProviderCode> ProviderCodes { get; set; }
        public DbSet<ProviderEligibility> ProviderEligibilities { get; set; }
        public DbSet<ProviderSpecialty> ProviderSpecialties { get; set; }
        public DbSet<ProviderNote> ProviderNotes { get; set; }
        public DbSet<ProviderEFT> ProviderEFTs { get; set; }
        public DbSet<ProviderLanguage> ProviderLanguages { get; set; }
        public DbSet<ProviderContractInterest> ProviderContractInterests { get; set; }
        public DbSet<ProviderContractTimelyFiling> ProviderContractTimelyFilings { get; set; }
        public DbSet<ProviderTIN> ProviderTINs { get; set; }
        public DbSet<ProviderContractLob> ProviderContractLobs { get; set; }
        public DbSet<ProviderRelation> ProviderRelations { get; set; }
        public DbSet<GroupProviderContract> GroupProviderContracts { get; set; }
        #endregion

        #region DataFileStructure
        public DbSet<Core.Entities.DataFileStructure.FileCategory> FileCategories { get; set; }
        public DbSet<FileProcessStatus> FileProcessStatus { get; set; }
        public DbSet<FileProviderType> FileProviderTypes { get; set; }
        public DbSet<DataFileProvider> DataFileProviders { get; set; }
        public DbSet<Core.Entities.DataFileStructure.DataFileTemplate> DataFileTemplates { get; set; }
        public DbSet<DataFileTemplateConfiguration> DataFileTemplateConfigurations { get; set; }
        public DbSet<DataFileFields> DataFileFields { get; set; }
        public DbSet<DataFilesToProcess> DataFilesToProcess { get; set; }
        public DbSet<DataFileDBConnection> DataFileDBConnection { get; set; }
        public DbSet<DataFileConnection> DataFileConnections { get; set; }
        #endregion

        #region Organization Rule
        public virtual DbSet<RuleHeader> RuleHeader { get; set; }
        public virtual DbSet<RuleHeaderAutoPay> RuleHeaderAutoPay { get; set; }
        public virtual DbSet<RuleHeaderAutoPayDetail> RuleHeaderAutoPayDetail { get; set; }
        public virtual DbSet<RuleHeaderCapitation> RuleHeaderCapitation { get; set; }
        public virtual DbSet<RuleHeaderClaimAddress> RuleHeaderClaimAddress { get; set; }
        public virtual DbSet<RuleHeaderFeeSchedule> RuleHeaderFeeSchedule { get; set; }
        public virtual DbSet<RuleHeaderInterest> RuleHeaderInterest { get; set; }
        public virtual DbSet<RuleHeaderMessage> RuleHeaderMessage { get; set; }
        public virtual DbSet<RuleHeaderModifierDiscount> RuleHeaderModifierDiscount { get; set; }
        public virtual DbSet<RuleHeaderTimelyFiling> RuleHeaderTimelyFiling { get; set; }
        public DbSet<RuleHeaderEditRule> RuleHeaderEditRules { get; set; }
        public DbSet<RuleHeaderEditRuleCriteria> RuleHeaderEditRuleCriterias { get; set; }
        #endregion

        #region Masters

        public DbSet<ServiceTypeCode> ServiceTypeCodes { get; set; }

        public DbSet<DBField> DBFields { get; set; }

        public DbSet<PaymentType> PaymentTypes { get; set; }

        public DbSet<CheckStatus> CheckStatuses { get; set; }

        public DbSet<DocumentType> DocumentTypes { get; set; }

        public DbSet<ClaimAdjudicationDataFetchingType> ClaimAdjudicationDataFetchingTypes { get; set; }

        public DbSet<EditCodeLogicQuery> EditCodeLogicQueries { get; set; }

        public DbSet<EditCodeLogicColumn> EditCodeLogicColumns { get; set; }

        public DbSet<EditCodeExpression> EditCodeExpressions { get; set; }
        public DbSet<SEPReasonCode> SEPReasonCode { get; set; }

        #endregion

        #region CommonStructure

        public DbSet<Document> Documents { get; set; }

        #endregion

        #region Finance Structure

        public DbSet<AccountDetail> AccountDetails { get; set; }

        public DbSet<AccountDetailCompanyStructure> AccountDetailCompanyStructures { get; set; }

        public DbSet<CheckWriteProcess> CheckWriteProcesses { get; set; }

        public DbSet<CheckDetail> CheckDetails { get; set; }

        //public DbSet<Adjustment> Adjustments { get; set; }

        public DbSet<AdjustmentAppliedDetail> AdjustmentAppliedDetails { get; set; }

        public DbSet<LienHolder> LienHolders { get; set; }

        public DbSet<LienHolderBalance> LienHolderBalances { get; set; }

        public DbSet<LienHolderDocument> LienHolderDocuments { get; set; }

        public DbSet<BillParameter> BillParameters { get; set; }

        public DbSet<Form1099Process> Form1099Processes { get; set; }

        public DbSet<Form1099> Form1099s { get; set; }
        public DbSet<LienHolderBalanceCheckDetail> LienHolderBalanceCheckDetail { get; set; }

        public DbSet<Form1099Data> Form1099Data { get; set; }

        public DbSet<Form1099ProcessStatusHistory> Form1099ProcessStatusHistory { get; set; }
        #endregion

        #region ETLStructure
        public virtual DbSet<DataFileProcessConfiguration> DataFileProcessConfigurations { get; set; } = null!;
        public virtual DbSet<DataFileProcessConfigurationDetails> DataFileProcessConfigurationDetails { get; set; } = null!;
        public virtual DbSet<Core.Entities.ETLStructure.DataFileTemplate> DataFileTemplate { get; set; } = null!;
        public virtual DbSet<DataFileTemplateFields> DataFileTemplateFields { get; set; } = null!;
        public virtual DbSet<DataFileToProcess> DataFileToProcesses { get; set; } = null!;
        public virtual DbSet<DataFileToProcessDetails> DataFileToProcessDetails { get; set; } = null!;
        public virtual DbSet<FileTemplateType> FileTemplateTypes { get; set; } = null!;
        public virtual DbSet<Core.Entities.ETLStructure.FileCategory> FileCategorie { get; set; } = null!;
        public virtual DbSet<FileSubCategory> FileSubCategories { get; set; } = null!;
        #endregion

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Ignore<IdentityUserLogin<string>>();
            builder.Ignore<IdentityUserRole<string>>();
            builder.Ignore<IdentityUserClaim<string>>();
            builder.Ignore<IdentityUserToken<string>>();
            builder.Ignore<IdentityUser<string>>();
            builder.Ignore<KwicleUser>();

            #region Supporting Tables
            builder.Entity<AgeGroup>().HasIndex(c => new { c.TypeID, c.Code, c.EffectiveDate }).IsUnique();
            builder.Entity<AgeGroup>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<AgeGroup>().HasOne(d => d.AgeGroupType).WithMany(p => p.AgeGroups).HasForeignKey(d => d.TypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AgeGroup>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<AnesthesiaRegionRate>().HasIndex(c => new { c.State, c.Carrier, c.LocalityCode, c.EffectiveDate }).IsUnique();
            builder.Entity<AnesthesiaRegionRate>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<AnesthesiaRegionRate>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<AnesthesiaCodeUnit>().Property(a => a.RecordStatus).HasDefaultValue(0);
            builder.Entity<AnesthesiaCodeUnit>().HasIndex(a => new { a.CPTCode, a.EffectiveDate, a.ProductID }).IsUnique();
            builder.Entity<AnesthesiaCodeUnit>().HasOne(a => a.Product).WithMany(p => p.AnesthesiaCodeUnits).HasForeignKey(d => d.ProductID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AnesthesiaCodeUnit>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<AnesConversionFactor>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                builder.Entity<AnesConversionFactor>().HasIndex(a => new { a.Name, a.POSCode, a.EffectiveDate }).IsUnique();
                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<TimelyFiling>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<TimelyFiling>().HasIndex(a => new { a.Description }).IsUnique();
            builder.Entity<TimelyFiling>().HasIndex(a => new { a.ProviderStatusID, a.ProviderTypeID, a.EffectiveDate }).IsUnique();
            builder.Entity<TimelyFiling>().HasOne(a => a.ProviderStatus).WithMany(p => p.TimelyFilingProviderStatus).HasForeignKey(d => d.ProviderStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TimelyFiling>().HasOne(a => a.ProviderType).WithMany(p => p.TimelyFilingProviderTypes).HasForeignKey(d => d.ProviderTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TimelyFiling>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<FeeScheduleLimit>().Property(c => c.LimitDuration).HasColumnType("decimal(8,2)").IsRequired();
            builder.Entity<FeeScheduleLimit>().Property(c => c.LimitMax).HasColumnType("decimal(8,2)").IsRequired();
            builder.Entity<FeeScheduleLimit>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<FeeScheduleLimit>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<FeeScheduleHeader>().HasIndex(s => new { s.EffectiveDate, s.Code }).IsUnique();
            builder.Entity<FeeScheduleHeader>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<FeeScheduleHeader>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<FeeScheduleDetail>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<FeeScheduleDetail>().HasOne(d => d.FeeScheduleHeader).WithMany(p => p.FeeScheduleDetails).HasForeignKey(d => d.FeeScheduleHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<FeeScheduleDetail>().HasOne(d => d.FeeScheduleLimit).WithMany(p => p.FeeScheduleDetails).HasForeignKey(d => d.FeeScheduleLimitID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<FeeScheduleDetail>().HasOne(d => d.FeeScheduleDetailClinicalCodeType).WithMany(p => p.FeeScheduleDetailClinicalCodeTypes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<FeeScheduleDetail>().HasOne(d => d.ProviderType).WithMany(p => p.FeeScheduleDetailProviderTypes).HasForeignKey(d => d.ProviderTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<FeeScheduleDetail>().HasOne(d => d.ShareLimit).WithMany(p => p.FeeScheduleDetailShareLimits).HasForeignKey(d => d.ShareLimitID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<FeeScheduleDetail>().HasOne(d => d.Specialty).WithMany(p => p.FeeScheduleDetails).HasForeignKey(d => d.ProviderSpecialtyID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<FeeScheduleDetail>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<InterestQuickPay>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<InterestQuickPay>().HasIndex(s => new { s.EffectiveDate, s.Schedule }).IsUnique();
            builder.Entity<InterestQuickPay>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<ModifierDiscountGroup>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<ModifierDiscountGroup>().HasIndex(a => new { a.GroupName }).IsUnique();

            builder.Entity<ModifierDiscount>(entity =>
            {
                entity.Property(e => e.ModifierCode).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                //entity.HasOne(d => d.ClinicalCodeType)
                //    .WithMany(p => p.ModifierDiscountClinicalCodeType)
                //    .HasForeignKey(d => d.ClinicalCodeTypeID)
                //    .OnDelete(DeleteBehavior.Restrict)
                //    .HasConstraintName("FK_ModifierDiscount_CommonCode1");

                entity.HasOne(d => d.ModifierDiscountGroup)
                    .WithMany(p => p.ModifierDiscounts)
                    .HasForeignKey(d => d.ModifierDiscountGroupID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ModifierDiscount_ModifierDiscountGroup");

                //entity.HasIndex(s => new { s.EffectiveDate, s.ModifierCode }).IsUnique();

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            //builder.Entity<Region>().Property(c => c.RecordStatus).HasDefaultValue(0);
            //builder.Entity<Region>().HasOne(d => d.RegionType).WithMany(p => p.Regions).HasForeignKey(d => d.TypeID).OnDelete(DeleteBehavior.Restrict);
            //builder.Entity<Region>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            builder.Entity<Region>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.State).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ProductType)
                    .WithMany(p => p.Region)
                    .HasForeignKey(d => d.ProductTypeID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Region_ProductType");
            });

            builder.Entity<Locality>().Property(l => l.RecordStatus).HasDefaultValue(0);
            builder.Entity<Locality>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<GPCI>().Property(l => l.RecordStatus).HasDefaultValue(0);
            builder.Entity<GPCI>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<RBRVSCode>().Property(l => l.RecordStatus).HasDefaultValue(0);
            builder.Entity<RBRVSCode>().HasIndex(r => new { r.TypeNumber, r.Code }).IsUnique();
            builder.Entity<RBRVSCode>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<RBRVS>().Property(l => l.RecordStatus).HasDefaultValue(0);
            builder.Entity<RBRVS>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            #endregion

            builder.Entity<GetStatesModel>().Property(i => i.StateFullName).IsUnicode(false);
            builder.Entity<GetStatesModel>().Property(i => i.State).IsUnicode(false);
            builder.Entity<GetCountiesModel>().Property(i => i.County).IsUnicode(false);


            builder.Entity<Clinic>().Property(c => c.UID).IsRequired();
            builder.Entity<Clinic>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();
            builder.Entity<Kwicle.Core.Entities.OldProvider>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();
            builder.Entity<Procedure>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();



            builder.Entity<CodeType>().Property(x => x.CodeTypeID).ValueGeneratedNever();
            builder.Entity<CodeType>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();
            //builder.Entity<CodeType>().HasAlternateKey(s => s.Code);
            builder.Entity<CodeType>().HasIndex(s => s.Code).IsUnique();
            builder.Entity<CodeType>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<CommonCode>().Property(x => x.CommonCodeID).ValueGeneratedNever();
            //builder.Entity<CommonCode>().HasKey(t => new { t.CommonCodeID, t.CodeTypeID }); // for pk and fk
            builder.Entity<CommonCode>().HasIndex(t => new { t.CodeTypeID });
            //builder.Entity<CommonCode>().HasAlternateKey(t => new { t.Code, t.CodeTypeID });
            builder.Entity<CommonCode>().HasIndex(e => new { e.CodeTypeID, e.Code }).IsUnique();
            builder.Entity<CommonCode>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();
            builder.Entity<CommonCode>().Property(c => c.NumericValue).HasColumnType("decimal(8,2)");
            builder.Entity<CommonCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<CommonCode>().HasOne(d => d.CodeType).WithMany(p => p.CommonCodes).HasForeignKey(d => d.CodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<CommonCodeDisplayConfiguration>().Property(x => x.CommonCodeID).ValueGeneratedNever();
            builder.Entity<CommonCodeDisplayConfiguration>().HasKey(t => new { t.CommonCodeID, t.PageId });
            builder.Entity<CommonCodeDisplayConfiguration>().HasOne(d => d.CommonCode).WithMany(p => p.CommonCodeDisplayConfigurations).HasForeignKey(d => d.CommonCodeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CommonCodeDisplayConfiguration>().HasIndex(t => new { t.CommonCodeID, t.PageId }).IsUnique();

            builder.Entity<Category>().HasAlternateKey(p => new { p.CategoryCode, p.CategoryName });
            builder.Entity<Category>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<Product>().Property(p => p.RecordStatus).HasDefaultValue(0);
            builder.Entity<Product>().HasAlternateKey(p => new { p.ProductCode, p.ProductName });

            builder.Entity<Sponsor>().HasAlternateKey(s => s.SponsorCode);
            builder.Entity<Sponsor>().Property(s => s.RecordStatus).HasDefaultValue(0);

            builder.Entity<Lob>().HasIndex(s => s.LobCode).IsUnique();
            builder.Entity<Lob>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<Lob>().HasOne(d => d.Category).WithMany(p => p.Lobs).HasForeignKey(d => d.CategoryID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Lob>().HasOne(d => d.Product).WithMany(p => p.Lobs).HasForeignKey(d => d.ProductID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Lob>().HasOne(d => d.Sponsor).WithMany(p => p.Lobs).HasForeignKey(d => d.SponsorID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Lob>().HasOne(d => d.SubCompany).WithMany(p => p.Lobs).HasForeignKey(d => d.SubCompanyID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Lob>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<Organization>().HasIndex(s => s.OrganizationCode).IsUnique();
            builder.Entity<Organization>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<ProductType>().HasIndex(s => s.ProductTypeCode).IsUnique();
            builder.Entity<ProductType>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<DRGGroupHeader>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.DRGGroupName).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ICDCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<ICDCode>().HasIndex(c => c.ClinicalCodeTypeID);
            //builder.Entity<ICDCode>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.ICDCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<CPTCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<CPTCode>().HasIndex(c => c.ClinicalCodeTypeID);
            //builder.Entity<CPTCode>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.CPTCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<RevenueCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<RevenueCode>().HasIndex(c => c.ClinicalCodeTypeID);
            //builder.Entity<RevenueCode>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.RevenueCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<DRGCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<DRGCode>().HasIndex(c => c.ClinicalCodeTypeID);
            //builder.Entity<DRGCode>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.DRGCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<DRGCodeWeight>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<DRGCodeWeight>().HasIndex(c => new { c.DRGCodeID, c.EffectiveDate }).IsUnique();
            builder.Entity<DRGCodeWeight>().Property(c => c.Weight).HasColumnType("decimal(8,4)").IsRequired();
            builder.Entity<DRGCodeWeight>().Property(c => c.GLOS).HasColumnType("decimal(8,3)").IsRequired();
            builder.Entity<DRGCodeWeight>().Property(c => c.ALOS).HasColumnType("decimal(8,3)").IsRequired();
            builder.Entity<DRGCodeWeight>().HasIndex(c => new { c.DRGCodeID, c.EffectiveDate }).IsUnique();
            builder.Entity<DRGCodeWeight>().HasOne(d => d.DRGCode).WithMany(p => p.DRGCodeWeights).HasForeignKey(d => d.DRGCodeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<HCCCode>().Property(c => c.RecordStatus).HasDefaultValue((byte)0);
            builder.Entity<HCCCode>().HasIndex(c => c.ClinicalCodeTypeID);
            builder.Entity<HCCCode>().Property(c => c.HomeGrown).HasDefaultValueSql("('')");
            builder.Entity<HCCCode>().Property(c => c.MappedCode).HasDefaultValueSql("('')");

            //builder.Entity<HCCCode>().Property(c => c.CommunityFactor).HasColumnType("decimal(8,3)").IsRequired();
            //builder.Entity<HCCCode>().Property(c => c.InstitutionalFactor).HasColumnType("decimal(8,3)").IsRequired();
            //builder.Entity<HCCCode>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.HCCCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<POSCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<POSCode>().HasIndex(c => c.ClinicalCodeTypeID);
            //builder.Entity<POSCode>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.POSCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<OtherCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<OtherCode>().HasIndex(c => c.ClinicalCodeTypeID);

            builder.Entity<NDCCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<NDCCode>().HasIndex(c => c.Code).IsUnique();
            builder.Entity<NDCCode>().HasOne(d => d.NDCCommonCode).WithMany(p => p.NDCCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<ZipCode>().Property(c => c.RecordStatus).HasDefaultValue(0);

            //builder.Entity<TimePeriod>().Property(c => c.RecordStatus).HasDefaultValue(0);
            //builder.Entity<TimePeriod>().HasAlternateKey(s => s.TimePeriodCode);
            //builder.Entity<TimePeriod>().HasIndex(c => c.TimePeriodCode).IsUnique();

            builder.Entity<VisitCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            //builder.Entity<VisitCode>().HasAlternateKey(s => s.Code);
            builder.Entity<VisitCode>().HasIndex(c => c.Code).IsUnique();
            builder.Entity<VisitCode>().HasOne(d => d.TimePeriod).WithMany(p => p.VisitCodes).HasForeignKey(d => d.TimePeriodID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<CopayCoinsurance>().Property(c => c.RecordStatus).HasDefaultValue(0);
            //builder.Entity<CopayCoinsurance>().HasAlternateKey(s => s.CopayCoinsuranceCode);
            builder.Entity<CopayCoinsurance>().HasIndex(c => c.CopayCoinsuranceCode).IsUnique();
            builder.Entity<CopayCoinsurance>().HasOne(d => d.MaxCopayPerDiemTimePeriod).WithMany(p => p.CopayCoinsuranceMaxCopayPerDiemTimePeriods).HasForeignKey(d => d.MaxCopayPerDiemTimePeriodId).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CopayCoinsurance>().HasOne(d => d.MaxCopayTimePeriod).WithMany(p => p.CopayCoinsuranceMaxCopayTimePeriods).HasForeignKey(d => d.MaxCopayTimePeriodId).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CopayCoinsurance>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<Audit_EventLog>().Property(c => c.InsertedDate).HasDefaultValueSql("getutcdate()");
            builder.Entity<Audit_EventLog>().Property(c => c.LastUpdatedDate).HasDefaultValueSql("getutcdate()");

            builder.Entity<Specialty>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<BillTypeCode>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<BenefitServiceGroup>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitServiceGroup>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitServiceGroups).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitServiceGroup>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<InsuranceCarrier>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // System Settings tabel
            builder.Entity<SystemSetting>().HasIndex(p => new { p.SettingCode }).IsUnique();
            builder.Entity<SystemSetting>().Property(c => c.IsOneTimeOnly).HasDefaultValue(1).ValueGeneratedNever();

            // Seq Number table
            builder.Entity<SeqNumber>().Property(e => e.SettingCode).IsUnicode(false).ValueGeneratedNever();
            builder.Entity<SeqNumber>().HasOne(d => d.SettingCodeNavigation).WithOne(p => p.SeqNumber).HasPrincipalKey<SystemSetting>(p => p.SettingCode).HasForeignKey<SeqNumber>(d => d.SettingCode).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<TemplateSubType>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<TemplateSubType>().HasIndex(e => e.TemplateSubTypeID).HasName("UK_TemplateSubType_SubTypeName").IsUnique();


            builder.Entity<Template>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<Template>().HasOne(d => d.TemplateSubType).WithMany(p => p.Templates).HasForeignKey(d => d.TemplateSubTypeID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Template_TemplateSubType");



            builder.Entity<PlaceHolder>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<TemplatePlaceHolder>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<TemplatePlaceHolder>().HasOne(d => d.PlaceHolders).WithMany(p => p.TemplatePlaceHolders).HasForeignKey(d => d.PlaceHolderID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_TemplatePlaceHolder_PlaceHolder");
            builder.Entity<TemplatePlaceHolder>().HasOne(d => d.Templates).WithMany(p => p.TemplatePlaceHolders).HasForeignKey(d => d.TemplateID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_TemplatePlaceHolder_Template");

            builder.Entity<JulianCalendar>().HasKey(e => new { e.Day, e.IsLeapYear });

            builder.Entity<JulianCalendarSeqNumber>().HasKey(e => new { e.JulianDay, e.Year });
            builder.Entity<JulianCalendarSeqNumber>().Property(e => e.JulianCalendarSeqNumberID).ValueGeneratedOnAdd();

            builder.Entity<EditCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<EditCode>().HasIndex(e => e.Code).HasName("IX_EditCode").IsUnique();
            builder.Entity<EditCode>().HasOne(d => d.DefaultOutComeCode).WithMany(p => p.ECDefaultOutComeCode).HasForeignKey(d => d.DefaultOutComeCodeID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_EditCode_CommonCode_DefaultOutComeCode");
            builder.Entity<EditCode>().HasOne(d => d.DefaultOutCome).WithMany(p => p.ECDefaultOutCome).HasForeignKey(d => d.DefaultOutComeID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_EditCode_CommonCode_DefaultOutCome");

            builder.Entity<EditCodeDisplayConfiguration>().HasKey(e => new { e.EditCodeID, e.PageID });


            builder.Entity<Location>(entity =>
            {
                entity.Property(e => e.Address1).IsUnicode(false);

                entity.Property(e => e.Address2).IsUnicode(false);

                entity.Property(e => e.AfterHoursCoverage).IsUnicode(false);

                entity.Property(e => e.City).IsUnicode(false);

                entity.Property(e => e.Country).IsUnicode(false);

                entity.Property(e => e.County).IsUnicode(false);

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.EmergencyPhone).IsUnicode(false);

                entity.Property(e => e.Fax).IsUnicode(false);

                entity.Property(e => e.LocationName).IsUnicode(false);

                entity.Property(e => e.Phone).IsUnicode(false);

                entity.Property(e => e.PrimaryEmail).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.SecondaryEmail).IsUnicode(false);

                entity.Property(e => e.SecondaryPhone).IsUnicode(false);

                entity.Property(e => e.State).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.Property(e => e.Zip).IsUnicode(false);

                entity.HasOne(d => d.LocationType)
                    .WithMany(p => p.LocationLocationType)
                    .HasForeignKey(d => d.LocationTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_Location_CommonCode_LocationType");

                entity.HasOne(d => d.Region)
                    .WithMany(p => p.LocationRegion)
                    .HasForeignKey(d => d.RegionID)
                    .HasConstraintName("FK_Location_CommonCode_Region");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<RegionZipCode>(entity =>
            {
                entity.Property(e => e.AddedSource).IsUnicode(false);

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.LoadComment).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.Property(e => e.UpdatedSource).IsUnicode(false);

                entity.HasOne(d => d.Region)
                    .WithMany(p => p.RegionZipCode)
                    .HasForeignKey(d => d.RegionID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RegionZipCode_Region");

                entity.HasOne(d => d.ZipCode)
                    .WithMany(p => p.RegionZipCode)
                    .HasForeignKey(d => d.ZipCodeID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RegionZipCode_ZipCode");
            });

            #region HealthPLan            
            //builder.Entity<HealthPlan>().HasIndex(c => new { c.PlanCode }).IsUnique();
            builder.Entity<HealthPlan>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<HealthPlan>().Property(c => c.PlanDescription).HasDefaultValueSql("('')");
            //builder.Entity<HealthPlan>().HasMany(e => e.HealthPlanBenefitPackages).WithOne(x=>x.Healthplan).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<HealthPlan>().HasOne(d => d.Lob).WithMany(p => p.HealthPlans).HasForeignKey(d => d.LobID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<HealthPlan>().HasOne(d => d.ProductType).WithMany(p => p.HealthPlans).HasForeignKey(d => d.ProductTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<HealthPlan>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<HealthPlanDeductible>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<HealthPlanDeductible>().HasOne(d => d.HealthPlan).WithMany(p => p.HealthPlanDeductibles).HasForeignKey(d => d.HealthPlanID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<HealthPlanDeductible>().HasOne(d => d.BenefitHeader).WithMany(p => p.HealthPlanDeductibles).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<HealthPlanDeductible>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            #endregion

            #region Benefit                        
            builder.Entity<BenefitHeader>().Property(e => e.RecordStatus).HasDefaultValue(0);

            builder.Entity<BenefitHeader>().HasOne(d => d.BenefitCategory).WithMany(p => p.BenefitHeaders).HasForeignKey(d => d.BenefitCategoryID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_BenefitHeader_CommonCode");
            builder.Entity<BenefitHeader>().HasOne(d => d.ServiceTypeCode)
                    .WithMany(p => p.BenefitHeaders)
                    .HasForeignKey(d => d.ServiceTypeCodeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_BenefitHeader_ServiceTypeCode");

            builder.Entity<BenefitHeader>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);


            builder.Entity<BenefitHeaderHealthPlan>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment)
                    .IsRequired()
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.BenefitHeader)
                    .WithMany(p => p.BenefitHeaderHealthPlans)
                    .HasForeignKey(d => d.BenefitHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_BenefitHeaderHealthPlan_BenefitHeader");

                entity.HasOne(d => d.HealthPlan)
                    .WithMany(p => p.BenefitHeaderHealthPlans)
                    .HasForeignKey(d => d.HealthPlanID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_BenefitHeaderHealthPlan_HealthPlan");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<BenefitProvider>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitProvider>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitProviders).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitProvider>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<BenefitCodes>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitCodes>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitCodes).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            //builder.Entity<BenefitCodes>().HasOne(d => d.ClinicalCodeType).WithMany(p => p.BenefitCodes).HasForeignKey(d => d.ClinicalCodeTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitCodes>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<BenefitVisit>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitVisit>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitVisits).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitVisit>().HasOne(d => d.VisitCode1).WithMany(p => p.BenefitVisits).HasForeignKey(d => d.VisitCodeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitVisit>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<BenefitProviderSpecialty>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitProviderSpecialty>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitProviderSpecialties).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitProviderSpecialty>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<BenefitCopayPerDiem>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitCopayPerDiem>().HasIndex(s => new { s.BenefitHeaderID, s.EffectiveDate, s.StartDay }).IsUnique();
            builder.Entity<BenefitCopayPerDiem>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitCopayPerDiems).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitCopayPerDiem>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<BenefitCopayCoinsurance>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitCopayCoinsurance>().HasOne(d => d.BenefitHeader).WithMany(p => p.BenefitCopayCoinsurances).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitCopayCoinsurance>().HasOne(d => d.CopayCoinsurance).WithMany(p => p.BenefitCopayCoinsurances).HasForeignKey(d => d.CopayCoinsuranceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitCopayCoinsurance>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<ClinicalCodeGroup>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<ClinicalCodeGroup>().HasIndex(e => e.GroupCode).IsUnique();
            //builder.Entity<ClinicalCodeGroup>().HasAlternateKey(s => s.GroupCode);
            builder.Entity<ClinicalCodeGroup>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<ClinicalCodeSubGroup>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<ClinicalCodeSubGroup>().HasIndex(s => new { s.ClinicalCodeGroupID, s.SubGroupCode }).IsUnique();
            builder.Entity<ClinicalCodeSubGroup>().HasOne(d => d.ClinicalCodeGroup).WithMany(p => p.ClinicalCodeSubGroups).HasForeignKey(d => d.ClinicalCodeGroupID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClinicalCodeSubGroup>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<ClinicalCodeGroupDetail>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<ClinicalCodeGroupDetail>().Property(e => e.IsAuth).HasDefaultValue(0);
            builder.Entity<ClinicalCodeGroupDetail>().HasIndex(s => new { s.GroupTypeID, s.ClinicalCodeSubGroupID, s.SubCategoryName }).IsUnique();
            builder.Entity<ClinicalCodeGroupDetail>().HasOne(d => d.ClinicalCodeSubGroup).WithMany(p => p.ClinicalCodeGroupDetails).HasForeignKey(d => d.ClinicalCodeSubGroupID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClinicalCodeGroupDetail>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<BenefitVisitLimitShare>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<BenefitVisitLimitShare>().HasOne(d => d.BenefitVisit).WithMany(p => p.BenefitVisitLimitShares).HasForeignKey(d => d.BenefitVisitID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BenefitVisitLimitShare>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<TradingPartnerBenefitConfiguration>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<TradingPartnerBenefitConfiguration>().HasOne(d => d.BenefitHeader).WithMany(p => p.TradingPartnerBenefitConfigurations).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TradingPartnerBenefitConfiguration>().HasOne(d => d.HealthPlan).WithMany(p => p.TradingPartnerBenefitConfigurations).HasForeignKey(d => d.HealthPlanID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TradingPartnerBenefitConfiguration>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            #endregion            

            #region Member Structure
            // Member Table
            builder.Entity<Member>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Default Constraints
            builder.Entity<Member>().Property(c => c.IsDeceased).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsHippaEmail).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsHippaMail).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsHippaText).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsHippaVoiceMessage).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsAdvanceDirective).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsHandicap).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsTestMember).HasDefaultValue(0);
            builder.Entity<Member>().Property(c => c.IsExcludeFromClaimEditing).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<Member>().HasOne(d => d.Gender).WithMany(p => p.MGender).HasForeignKey(d => d.GenderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.Relationship).WithMany(p => p.MRelationship).HasForeignKey(d => d.RelationshipID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.PrimaryLanguage).WithMany(p => p.MPrimaryLanguage).HasForeignKey(d => d.PrimaryLanguageID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.SecondaryLanguage).WithMany(p => p.MSecondaryLanguage).HasForeignKey(d => d.SecondaryLanguageID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Member>().HasOne(d => d.MaritalStatus).WithMany(p => p.MMaritalStatus).HasForeignKey(d => d.MaritalStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.ResidingAt).WithMany(p => p.MResidingAt).HasForeignKey(d => d.ResidingAtID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.Race).WithMany(p => p.MRace).HasForeignKey(d => d.RaceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.Ethnicity).WithMany(p => p.MEthnicity).HasForeignKey(d => d.EthnicityID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.StudentStatus).WithMany(p => p.MStudentStatus).HasForeignKey(d => d.StudentStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.EmployeeStatus).WithMany(p => p.MEmployeeStatus).HasForeignKey(d => d.EmployeeStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.MemberStatus).WithMany(p => p.MMemberStatus).HasForeignKey(d => d.MemberStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.AccessibilityFormat).WithMany(p => p.MAccessibilityFormat).HasForeignKey(d => d.AccessibilityFormatID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.ApplicationStatus).WithMany(p => p.MApplicationStatusID).HasForeignKey(d => d.ApplicationStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.Contract).WithMany(p => p.MContractID).HasForeignKey(d => d.ContractID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Member>().HasOne(d => d.PBP).WithMany(p => p.MPBPID).HasForeignKey(d => d.PBPID).OnDelete(DeleteBehavior.Restrict);

            // Member Eligibility Table
            builder.Entity<MemberEligibility>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberEligibility>().HasOne(d => d.Member).WithMany(p => p.MemberEligibilitys).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.Company).WithMany(p => p.MemberEligibilityCompanies).HasForeignKey(d => d.CompanyID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.SubCompany).WithMany(p => p.MemberEligibilitySubCompanies).HasForeignKey(d => d.SubCompanyID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.Lob).WithMany(p => p.MemberEligibilitys).HasForeignKey(d => d.LOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.HealthPlan).WithMany(p => p.MemberEligibilitys).HasForeignKey(d => d.HealthPlanID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.CoverageType).WithMany(p => p.MECoverageType).HasForeignKey(d => d.CoverageTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.RiskType).WithMany(p => p.MERiskType).HasForeignKey(d => d.RiskTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEligibility>().HasOne(d => d.DisenrollmentReason).WithMany(p => p.MEDisenrollmentReason).HasForeignKey(d => d.DisenrollmentReasonID).OnDelete(DeleteBehavior.Restrict);


            builder.Entity<UserDataAuthorization>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<UserDataAuthorization>().Property(c => c.IsFreezed).HasDefaultValue(0);
            builder.Entity<UserDataAuthorization>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.Property(e => e.UserName).IsUnicode(false);

                entity.HasOne(d => d.HealthPlan)
                    .WithMany(p => p.UserDataAuthorizations)
                    .HasForeignKey(d => d.HealthPlanID)
                    .HasConstraintName("FK_UserDataAuthorization_HealthPlan");

                entity.HasOne(d => d.Lob)
                    .WithMany(p => p.UserDataAuthorizations)
                    .HasForeignKey(d => d.LOBID)
                    .HasConstraintName("FK_UserDataAuthorization_LOB");

                entity.HasOne(d => d.Organization)
                    .WithMany(p => p.UserDataAuthorizationOrganizations)
                    .HasForeignKey(d => d.OrganizationID)
                    .HasConstraintName("FK_UserDataAuthorization_Organization");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.UserDataAuthorizationCompanies)
                    .HasForeignKey(d => d.CompanyID)
                    .HasConstraintName("FK_UserDataAuthorization_Organization_CompanyID");

                entity.HasOne(d => d.SubCompany)
                    .WithMany(p => p.UserDataAuthorizationSubCompanies)
                    .HasForeignKey(d => d.SubCompanyID)
                    .HasConstraintName("FK_UserDataAuthorization_Organization_SubCompanyID");
            });

            // Member PCP Table
            builder.Entity<MemberPCP>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberPCP>().Property(c => c.IsPrimary).HasDefaultValue(0);
            builder.Entity<MemberPCP>().HasOne(d => d.Member).WithMany(p => p.MemberPCPs).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberPCP>().HasOne(d => d.DisenrollmentReason).WithMany(p => p.MPCPDisenrollmentReason).HasForeignKey(d => d.DisenrollmentReasonID).OnDelete(DeleteBehavior.Restrict);


            // Member Contact Table
            builder.Entity<MemberContact>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberContact>().Property(c => c.IsPrimary).HasDefaultValue(0);
            builder.Entity<MemberContact>().HasOne(d => d.Member).WithMany(p => p.MemberContacts).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberContact>().HasOne(d => d.ContactType).WithMany(p => p.MCContactType).HasForeignKey(d => d.ContactTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberContact>().HasOne(d => d.Relationship).WithMany(p => p.MCRelationship).HasForeignKey(d => d.RelationshipID).OnDelete(DeleteBehavior.Restrict);

            // Member Dependent Table
            builder.Entity<MemberDependent>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberDependent>().HasKey(t => new { t.MemberDependentID, t.ParentMemberID });
            builder.Entity<MemberDependent>().HasOne(d => d.DependentMember).WithMany(p => p.MemberDependents).HasForeignKey(d => d.MemberDependentID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberDependent>().HasOne(d => d.ParentMember).WithMany(p => p.ParentMembers).HasForeignKey(d => d.ParentMemberID).OnDelete(DeleteBehavior.Restrict);

            // Member Code Table
            builder.Entity<MemberCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberCode>().HasOne(d => d.Member).WithMany(p => p.MemberCodes).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCode>().HasOne(d => d.ControlType).WithMany(p => p.MCodeControlType).HasForeignKey(d => d.ControlTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCode>().HasOne(d => d.CodeType).WithMany(p => p.MCodeCodeType).HasForeignKey(d => d.CodeTypeID).OnDelete(DeleteBehavior.Restrict);

            // Member Notes Table
            builder.Entity<MemberNote>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberNote>().HasOne(d => d.Member).WithMany(p => p.MemberNotes).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);

            // Member COB Table
            builder.Entity<MemberCOB>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberCOB>().HasOne(d => d.Member).WithMany(p => p.MemberCOBs).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCOB>().HasOne(d => d.InsuranceType).WithMany(p => p.MCOBInsuranceType).HasForeignKey(d => d.InsuranceTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCOB>().HasOne(d => d.CoverageType).WithMany(p => p.MCOBCoverageType).HasForeignKey(d => d.CoverageTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCOB>().HasOne(d => d.PolicyHolderStatus).WithMany(p => p.MCOBPolicyHolderStatus).HasForeignKey(d => d.PolicyHolderStatusID).OnDelete(DeleteBehavior.Restrict);

            // Member COB Letter Table
            builder.Entity<MemberCOBLetter>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberCOBLetter>().HasOne(d => d.MemberCOB).WithMany(p => p.MemberCOBLetters).HasForeignKey(d => d.MemberCOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCOBLetter>().HasOne(d => d.Template).WithMany(p => p.MemberCOBLetters).HasForeignKey(d => d.TemplateID).OnDelete(DeleteBehavior.Restrict);

            // Member Billing Table
            builder.Entity<MemberBilling>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberBilling>().HasOne(d => d.Member).WithMany(p => p.MemberBillings).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberBilling>().HasOne(d => d.RateCode).WithMany(p => p.MemberBillings).HasForeignKey(d => d.RateCodeID).OnDelete(DeleteBehavior.Restrict);

            // Rate Code Table
            builder.Entity<RateCode>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<RateCode>().HasOne(d => d.SourceType).WithMany(p => p.RateCodeSourceType).HasForeignKey(d => d.SourceTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RateCode>().HasOne(d => d.RateType).WithMany(p => p.RateCodeRateType).HasForeignKey(d => d.RateTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RateCode>().HasOne(d => d.LOB).WithMany(p => p.RateCodes).HasForeignKey(d => d.LOBID).OnDelete(DeleteBehavior.Restrict);

            // Member Billing Payment
            builder.Entity<MemberBillingPayment>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberBillingPayment>().HasOne(d => d.Member).WithMany(p => p.MemberBillingPayments).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberBillingPayment>().HasOne(d => d.AccountType).WithMany(p => p.MBPaymentAccountType).HasForeignKey(d => d.AccountTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberBillingPayment>().HasOne(d => d.InvoiceType).WithMany(p => p.MBPaymentInvoiceType).HasForeignKey(d => d.InvoiceTypeID).OnDelete(DeleteBehavior.Restrict);

            // Member Cost Share
            builder.Entity<MemberCostShare>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberCostShare>().HasOne(d => d.Member).WithMany(p => p.MemberCostShares).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCostShare>().HasOne(d => d.DurationType).WithMany(p => p.MCSDurationType).HasForeignKey(d => d.DurationTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCostShare>().HasOne(d => d.EditCode).WithMany(p => p.MCSEditCode).HasForeignKey(d => d.EditCodeID).OnDelete(DeleteBehavior.Restrict);

            // Member Cost Share
            builder.Entity<MemberDiscloserInfo>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberDiscloserInfo>().HasOne(d => d.Member).WithMany(p => p.MemberDiscloserInfos).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberDiscloserInfo>().HasOne(d => d.DisclosePersonalHealth).WithMany(p => p.MDIDisclosePersonalHealth).HasForeignKey(d => d.DisclosePersonalHealthID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberDiscloserInfo>().HasOne(d => d.DiscloseInfoTime).WithMany(p => p.MDIDiscloseInfoTime).HasForeignKey(d => d.DiscloseInfoTimeID).OnDelete(DeleteBehavior.Restrict);

            // Member MemberEnrollmentDetail Table
            builder.Entity<MemberEnrollmentDetail>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberEnrollmentDetail>().HasOne(d => d.Member).WithMany(p => p.MemberEnrollmentDetails).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentDetail>().HasOne(d => d.EnrollmentSource).WithMany(p => p.MEDEnrollmentSource).HasForeignKey(d => d.EnrollmentSourceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentDetail>().HasOne(d => d.EnrollmentMechanism).WithMany(p => p.MEDEnrollmentMechanism).HasForeignKey(d => d.EnrollmentMechanismID).OnDelete(DeleteBehavior.Restrict);

            // Member MemberOtherCoverage Table
            builder.Entity<MemberOtherCoverage>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberOtherCoverage>().HasOne(d => d.Member).WithMany(p => p.MemberOtherCoverages).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberOtherCoverage>().HasOne(d => d.PlanSpecificChronicCondition).WithMany(p => p.MOCPlanSpecificChronicCondition).HasForeignKey(d => d.PlanSpecificChronicConditionID).OnDelete(DeleteBehavior.Restrict);

            // Member MemberOtherCoverage Table
            builder.Entity<MemberPremiumDetail>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberPremiumDetail>().HasOne(d => d.Member).WithMany(p => p.MemberPremiumDetails).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);

            // Member MemberCMSDetail Table
            builder.Entity<MemberCMSDetail>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<MemberCMSDetail>().HasOne(d => d.Member).WithMany(p => p.MemberCMSDetails).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberCMSDetail>().HasOne(d => d.LISLevel).WithMany(p => p.MCDLISLevel).HasForeignKey(d => d.LISLevelID).OnDelete(DeleteBehavior.Restrict);

            // Member Transaction Details
            builder.Entity<MemberTransactionDetail>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<MemberTransactionDetail>().HasOne(d => d.DenialReason).WithMany(p => p.MTDDenialReason).HasForeignKey(d => d.DenialReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.DisEnrollmentReasonCode).WithMany(p => p.MTDDisEnrollmentReasonCode).HasForeignKey(d => d.DisEnrollmentReasonCodeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.ElectionType).WithMany(p => p.MTDElectionType).HasForeignKey(d => d.ElectionTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.IncompleteReason).WithMany(p => p.MTDIncompleteReason).HasForeignKey(d => d.IncompleteReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.PendReason).WithMany(p => p.MTDPendReason).HasForeignKey(d => d.PendReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.PremiumWithholdOption).WithMany(p => p.MTDPremiumWithholdOption).HasForeignKey(d => d.PremiumWithholdOptionID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.TransactionType).WithMany(p => p.MTDTransactionType).HasForeignKey(d => d.TransactionTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.TransactionStatus).WithMany(p => p.MTDTransactionStatus).HasForeignKey(d => d.TransactionStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.Member).WithMany(p => p.MemberTransactionDetails).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.PBP).WithMany(p => p.MTDPBP).HasForeignKey(d => d.PBPID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.Contract).WithMany(p => p.MTDContract).HasForeignKey(d => d.ContractID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberTransactionDetail>().HasOne(d => d.SepReasonCode).WithMany(p => p.MTDSepReasonCode).HasForeignKey(d => d.SepReasonCodeID).OnDelete(DeleteBehavior.Restrict);

            // Member TRRDetailLayout Details
            builder.Entity<TRRDetailLayout>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<TRRDetailLayout>().HasOne(d => d.Member).WithMany(p => p.TRRDetailLayouts).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TRRDetailLayout>().HasOne(d => d.MemberTransactionDetail).WithMany(p => p.TRRDetailLayouts).HasForeignKey(d => d.MemberTransactionDetailID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TRRDetailLayout>().HasOne(d => d.DataFileToProcessDetails).WithMany(p => p.TRRDetailLayouts).HasForeignKey(d => d.DataFileToProcessDetailsID).OnDelete(DeleteBehavior.Restrict);

            // Member Span Details
            builder.Entity<MemberSpan>().Property(c => c.RecordStatus).HasDefaultValue(0);

            builder.Entity<MemberSpan>().HasOne(d => d.Member).WithMany(p => p.MemberSpans).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberSpan>().HasOne(d => d.SpanType).WithMany(p => p.MSpanType).HasForeignKey(d => d.SpanTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberSpan>().HasOne(d => d.SpanSource).WithMany(p => p.MSpanSource).HasForeignKey(d => d.SpanSourceID).OnDelete(DeleteBehavior.Restrict);

            // Member Rule Details
            builder.Entity<MemberRule>().HasOne(d => d.SepReasonCode).WithMany(p => p.MRule).HasForeignKey(d => d.SEPReasonCodeID).OnDelete(DeleteBehavior.Restrict);

            // Member VwBEQdetails Details
            builder.Entity<VwBEQdetails>().ToView("VwBEQdetails", "CMS");

            // Member VwTRRDetailLayout List
            builder.Entity<VwTRRDetailLayoutList>().ToView("VwTRRDetailLayoutList", "CMS");

            //OECLayout
            builder.Entity<OECLayout>(entity =>
            {
                entity.ToTable("OECLayout", "CMS");

                entity.Property(e => e.OECLayoutID).ValueGeneratedNever();
                entity.Property(e => e.ConfirmationNumber).HasMaxLength(12).IsUnicode(false);
                entity.Property(e => e.SubmitDate).HasMaxLength(8).IsUnicode(false);
                entity.Property(e => e.ContractID).HasMaxLength(5).IsUnicode(false);
                entity.Property(e => e.PlanID).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.SegmentID).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.ApplicantFirstName).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.ApplicantMiddleInitial).HasMaxLength(1).IsUnicode(false);
                entity.Property(e => e.ApplicantLastName).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.ApplicantBirthDate).HasMaxLength(8).IsUnicode(false);
                entity.Property(e => e.ApplicantGender).HasMaxLength(1).IsUnicode(false);
                entity.Property(e => e.ApplicantAddress1).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.ApplicantAddress2).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.ApplicantAddress3).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.ApplicantCity).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.ApplicantCounty).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.ApplicantState).HasMaxLength(2).IsUnicode(false);
                entity.Property(e => e.ApplicantZip).HasMaxLength(5).IsUnicode(false);
                entity.Property(e => e.ApplicantPhone).HasMaxLength(10).IsUnicode(false);
                entity.Property(e => e.ApplicantEmailAddress).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.ApplicantMBI).HasMaxLength(11).IsUnicode(false);
                entity.Property(e => e.ApplicantSSN).HasMaxLength(9).IsUnicode(false);
                entity.Property(e => e.MailingAddress1).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.MailingAddress2).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.MailingCity).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.MailingState).HasMaxLength(2).IsUnicode(false);
                entity.Property(e => e.MailingZip).HasMaxLength(5).IsUnicode(false);
                entity.Property(e => e.PremiumDeducted).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.OtherCoverage).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.OtherCoverageName).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.OtherCoverageID).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepName).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepAddress).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepCity).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepState).HasMaxLength(2).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepZip).HasMaxLength(5).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepPhone).HasMaxLength(10).IsUnicode(false);
                entity.Property(e => e.AuthorizedRepRelationship).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.Language).HasMaxLength(7).IsUnicode(false);
                entity.Property(e => e.WorkStatus).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.PrimaryCarePhysician).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.OtherCoverageGroup).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.SubmitTime).HasMaxLength(22).IsUnicode(false);
                entity.Property(e => e.SEPReasonCode).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.SEPCMSReasonCODE).HasMaxLength(80).IsUnicode(false);
                entity.Property(e => e.PremiumDirectPay).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.EnrollmentPlanYear).HasMaxLength(4).IsUnicode(false);
                entity.Property(e => e.PremiumWithhold).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.SpouseWorkStatus).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.AccessibilityFormat).HasMaxLength(10).IsUnicode(false);
                entity.Property(e => e.EmailOptIn).HasMaxLength(3).IsUnicode(false);
                entity.Property(e => e.IsFreezed);
                entity.Property(e => e.AddedSource).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.UpdatedSource).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.LoadComment).HasMaxLength(200).IsUnicode(false);
                entity.Property(e => e.RecordStatus);
                entity.Property(e => e.CreatedBy).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.CreatedBy).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.RecordStatusChangeComment).HasMaxLength(400).IsUnicode(false);
                entity.Property(e => e.UpdatedBy).HasMaxLength(40).IsUnicode(false);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });
            #endregion

            #region Contract Structure


            builder.Entity<Contract>(entity =>
                {
                    entity.Property(e => e.ContractDescription).IsUnicode(false).HasDefaultValueSql("('')");

                    entity.Property(e => e.ContractCode).IsUnicode(false);

                    entity.Property(e => e.ContractName).IsUnicode(false);

                    entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                    entity.HasOne(d => d.AnesConversionFactor)
                        .WithMany(p => p.Contract)
                        .HasForeignKey(d => d.AnesConversionFactorID)
                        .OnDelete(DeleteBehavior.Restrict)
                        .HasConstraintName("FK_Contract_AnesConversionFactor");

                    entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
                });

            builder.Entity<ContractClaimType>(entity =>
            {
                entity.HasKey(e => new { e.ContractClaimTypeID, e.ContractID, e.ClaimTypeID });
                entity.Property(e => e.ContractClaimTypeID)
                    .HasColumnName("ContractClaimTypeID")
                    .ValueGeneratedOnAdd();

                entity.HasOne(d => d.Contract)
                    .WithMany(p => p.ContractClaimType)
                    .HasForeignKey(d => d.ContractID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ContractClaimType_Contract");
            });

            builder.Entity<TermHeader>(entity =>
            {
                entity.Property(e => e.TermCode).IsUnicode(false);

                entity.Property(e => e.TermName).IsUnicode(false);

                entity.Property(e => e.TermDescription).IsUnicode(false);

                entity.Property(e => e.EOBReason).IsUnicode(false);

                entity.Property(e => e.RemitReason).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.HasOne(d => d.Contract)
                    .WithMany(p => p.TermHeader)
                    .HasForeignKey(d => d.ContractID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermHeader_Contract");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<TermCodes>(entity =>
            {
                entity.Property(e => e.TermCodesID).ValueGeneratedOnAdd();

                entity.Property(e => e.MaxCode).IsUnicode(false);

                entity.Property(e => e.MinCode).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.HasOne(d => d.TermHeader)
                    .WithMany(p => p.TermCodes)
                    .HasForeignKey(d => d.TermHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermCodes_TermHeader");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<TermProviderSpecialty>(entity =>
            {
                entity.HasIndex(e => new { e.TermHeaderID, e.SpecialtyID })
                    .HasName("UK_TermProviderSpecialty")
                    .IsUnique();

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.SpecialtyName).IsUnicode(false);

                entity.HasOne(d => d.TermHeader)
                    .WithMany(p => p.TermProviderSpecialty)
                    .HasForeignKey(d => d.TermHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermProviderSpecialty_TermHeader");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<TermServiceGroup>().Property(c => c.RecordStatus).HasDefaultValue(0);
            builder.Entity<TermServiceGroup>().HasOne(d => d.TermHeader).WithMany(p => p.TermServiceGroups).HasForeignKey(d => d.TermHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<TermServiceGroup>().HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            builder.Entity<TermLimit>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.HasOne(d => d.TermHeader)
                    .WithMany(p => p.TermLimit)
                    .HasForeignKey(d => d.TermHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermLimit_TermHeader");

                entity.HasOne(d => d.VisitCode)
                    .WithMany(p => p.TermLimit)
                    .HasForeignKey(d => d.VisitCodeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermLimit_VisitCode");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<CapitationHeader>(entity =>
            {
                entity.Property(e => e.CapitationCode).IsUnicode(false);

                entity.Property(e => e.CapitationName).IsUnicode(false);

                entity.Property(e => e.CapitationDescription)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.CapitationType)
                    .WithMany(p => p.CapitationHeader)
                    .HasForeignKey(d => d.CapitationTypeId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_CapitationHeader_CommonCode");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<MembershipCapitation>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.CapitationHeader)
                    .WithMany(p => p.MembershipCapitation)
                    .HasForeignKey(d => d.CapitationHeaderId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TieredCapitation_CapitationHeader");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });
            builder.Entity<PlanCapitation>(entity =>
            {
                entity.Property(e => e.County)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.MemberZip)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.PCPZip)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.CapitationHeader)
                    .WithMany(p => p.PlanCapitation)
                    .HasForeignKey(d => d.CapitationHeaderId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_CapitationPlan_CapitationHeader");

                entity.HasOne(d => d.HealthPlan)
                    .WithMany(p => p.PlanCapitation)
                    .HasForeignKey(d => d.HealthPlanId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_CapitationPlan_HealthPlan");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<DRGPaymentPayPercent>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.DRGPayPercentCode).IsUnicode(false);

                entity.Property(e => e.DRGPayPercentName).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<TermPayment>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.IsBillChargesIgnored).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsCalculateHighOutlier).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsCalculateLowOutlier).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsCalculateTransfer).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsPerDateOfService).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsProrateDays).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsRegionUnit).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsUseActiveDRG).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsUseActivePricer).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsUseGPI).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.DRGGroupHeader)
                    .WithMany(p => p.TermPayments)
                    .HasForeignKey(d => d.DRGGroupHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermPayment_DRGGroupHeader");

                entity.HasOne(d => d.DRGPaymentPayPercent)
                    .WithMany(p => p.TermPayment)
                    .HasForeignKey(d => d.DRGPaymentPayPercentID)
                    .HasConstraintName("FK_TermPayment_DRGPaymentPayPercent");

                entity.HasOne(d => d.FeeScheduleHeader)
                    .WithMany(p => p.TermPayment)
                    .HasForeignKey(d => d.FeeScheduleHeaderID)
                    .HasConstraintName("FK_TermPayment_FeeScheduleHeader");

                entity.HasOne(d => d.PaymentType)
                    .WithMany(p => p.TermPayment)
                    .HasForeignKey(d => d.PaymentTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermPayment_CommonCode");

                entity.HasOne(d => d.TermHeader)
                    .WithMany(p => p.TermPayment)
                    .HasForeignKey(d => d.TermHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_TermPayment_TermHeader");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });
            #endregion

            #region Claim Structure

            // ClaimHeader Table
            builder.Entity<ClaimHeader>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Default Constraints

            // Pending: Set Default to current date
            // builder.Entity<ClaimHeader>().Property(c => c.ReceivedDate).HasDefaultValue(0);

            // Pending: Set Default to current date
            // builder.Entity<ClaimHeader>().Property(c => c.EnteredDate).HasDefaultValue(0);

            builder.Entity<ClaimHeader>().Property(c => c.BilledAmount).HasDefaultValue(0);
            builder.Entity<ClaimHeader>().Property(c => c.PaidAmount).HasDefaultValue(0);
            builder.Entity<ClaimHeader>().Property(c => c.OtherInsurancePaid).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimHeader>().HasOne(d => d.FormType).WithMany(p => p.CHFormType).HasForeignKey(d => d.FormTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.ClaimStatus).WithMany(p => p.ClaimHeaderStatuses).HasForeignKey(d => d.ClaimStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.ClaimSource).WithMany(p => p.CHClaimSource).HasForeignKey(d => d.ClaimSourceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.Member).WithMany(p => p.ClaimHeaderMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.MemberEligibility).WithMany(p => p.ClaimHeaderMemberEligibilities).HasForeignKey(d => d.MemberEligibilityID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.MemberPCP).WithMany(p => p.ClaimHeaderMemberPCPs).HasForeignKey(d => d.MemberPCPID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.PCP).WithMany(p => p.ClaimHeaderPCPs).HasForeignKey(d => d.PCPID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.Provider).WithMany(p => p.ClaimHeaderProviders).HasForeignKey(d => d.ProviderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.ProviderType).WithMany(p => p.CHProviderType).HasForeignKey(d => d.ProviderTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.BillType).WithMany(p => p.ClaimHeaderBillTypes).HasForeignKey(d => d.BillTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.AdmitType).WithMany(p => p.CHAdmitType).HasForeignKey(d => d.AdmitTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.AdmitSource).WithMany(p => p.CHAdmitSource).HasForeignKey(d => d.AdmitSourceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeader>().HasOne(d => d.DischargeStatus).WithMany(p => p.CHDischargeStatus).HasForeignKey(d => d.DischargeStatusID).OnDelete(DeleteBehavior.Restrict);
            //builder.Entity<ClaimHeader>().HasOne(d => d.ServiceRendered).WithMany(p => p.CHServiceRendered).HasForeignKey(d => d.ServiceRenderedID).OnDelete(DeleteBehavior.Restrict);

            // ClaimHeader Table
            builder.Entity<ClaimDiagnosis>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimDiagnosis>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimDiagnoses).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimDiagnosis>().HasOne(d => d.Member).WithMany(p => p.ClaimDiagnosisMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimDiagnosis>().HasOne(d => d.DiagnosisType).WithMany(p => p.CDDiagnosisType).HasForeignKey(d => d.DiagnosisTypeID).OnDelete(DeleteBehavior.Restrict);


            // ClaimService Table
            builder.Entity<ClaimService>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Default Constraints
            builder.Entity<ClaimService>().Property(c => c.BilledAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.AllowedAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.DifferenceAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.NonCoveredAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.DeductibleAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.CopayAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.CoinsuranceAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.PayableAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.InterestAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.TotalPaidAmount).HasDefaultValue(0);

            builder.Entity<ClaimService>().Property(c => c.IngredientCost).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.DispensingFee).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.IncentiveAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.PatientPaitAmount).HasDefaultValue(0);
            builder.Entity<ClaimService>().Property(c => c.GrossAmountDue).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimService>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimServices).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimService>().HasOne(d => d.Member).WithMany(p => p.ClaimServiceMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimService>().HasOne(d => d.BenefitHeader).WithMany(p => p.ClaimServices).HasForeignKey(d => d.BenefitHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimService>().HasOne(d => d.ServiceLineStatus).WithMany(p => p.CSServiceLineStatus).HasForeignKey(d => d.ServiceLineStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimService>().HasOne(d => d.FeeSchedule).WithMany(p => p.ClaimServiceFeeSchedules).HasForeignKey(d => d.FeeScheduleID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimService>().HasOne(d => d.ProdQualifier).WithMany(p => p.CSProdQualifier).HasForeignKey(d => d.ProdQualifierID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimService>().HasOne(d => d.ProcedureCodeType).WithMany(p => p.CSProcedureCodeType).HasForeignKey(d => d.ProcedureCodeTypeID).OnDelete(DeleteBehavior.Restrict);

            // ClaimAudit Table

            // Foreign Key Constraints
            builder.Entity<ClaimAudit>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimAudits).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimAudit>().HasOne(d => d.Action).WithMany(p => p.CAAction).HasForeignKey(d => d.ActionID).OnDelete(DeleteBehavior.Restrict);

            // ClaimNotes Table
            builder.Entity<ClaimNotes>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimNotes>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimNotess).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimNotes>().HasOne(d => d.Member).WithMany(p => p.ClaimNotesMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);

            // ClaimOtherInsurance Table
            builder.Entity<ClaimOtherInsurance>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Default Constraints
            builder.Entity<ClaimOtherInsurance>().Property(c => c.BilledAmount).HasDefaultValue(0);
            builder.Entity<ClaimOtherInsurance>().Property(c => c.AllowedAmount).HasDefaultValue(0);
            builder.Entity<ClaimOtherInsurance>().Property(c => c.DeductibleAmount).HasDefaultValue(0);
            builder.Entity<ClaimOtherInsurance>().Property(c => c.CopayAmount).HasDefaultValue(0);
            builder.Entity<ClaimOtherInsurance>().Property(c => c.CoinsuranceAmount).HasDefaultValue(0);
            builder.Entity<ClaimOtherInsurance>().Property(c => c.NetAllowedAmount).HasDefaultValue(0);
            builder.Entity<ClaimOtherInsurance>().Property(c => c.TotalPaidAmount).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimOtherInsurance>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimOtherInsurances).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimOtherInsurance>().HasOne(d => d.InsuranceCarrier).WithMany(p => p.ClaimOtherInsurances).HasForeignKey(d => d.InsuranceCarrierID).OnDelete(DeleteBehavior.Restrict);

            // ClaimEdits Table
            builder.Entity<ClaimEdits>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimEdits>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimEditss).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimEdits>().HasOne(d => d.EditCodes).WithMany(p => p.ClaimEdits).HasForeignKey(d => d.EditCodeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimEdits>().HasOne(d => d.OutCome).WithMany(p => p.ClaimEditOutCome).HasForeignKey(d => d.OutComeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimEdits>().HasOne(d => d.OutComeReason).WithMany(p => p.ClaimEditOutComeReason).HasForeignKey(d => d.OutComeCodeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimEdits>().Property(d => d.IsOverride).HasDefaultValue(0);

            // ClaimReference Table
            builder.Entity<ClaimReference>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimReference>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimReferences).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimReference>().HasOne(d => d.Member).WithMany(p => p.ClaimReferenceMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimReference>().HasOne(d => d.ControlType).WithMany(p => p.CRControlType).HasForeignKey(d => d.ControlTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimReference>().HasOne(d => d.CodeType).WithMany(p => p.CRCodeType).HasForeignKey(d => d.CodeTypeID).OnDelete(DeleteBehavior.Restrict);

            // ClaimProcessingSteps Table

            // Foreign Key Constraints
            builder.Entity<ClaimProcessingSteps>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimProcessingStepss).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimProcessingSteps>().HasOne(d => d.AdjudicationRequestHeader).WithMany(p => p.ClaimProcessingStepss).HasForeignKey(d => d.AdjudicationRequestHeaderID).OnDelete(DeleteBehavior.Restrict);

            // ClaimEOBEOP Table
            builder.Entity<ClaimEOBEOP>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimEOBEOP>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimEOBEOPs).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimEOBEOP>().HasOne(d => d.EOBEOPType).WithMany(p => p.CEEEOBEOPType).HasForeignKey(d => d.EOBEOPTypeID).OnDelete(DeleteBehavior.Restrict);

            // ClaimUBCodes Table
            builder.Entity<ClaimUBCodes>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Default Constraints
            builder.Entity<ClaimUBCodes>().Property(c => c.Amount).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimUBCodes>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimUBCodess).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimUBCodes>().HasOne(d => d.Type).WithMany(p => p.CUCType).HasForeignKey(d => d.TypeID).OnDelete(DeleteBehavior.Restrict);

            // ClaimOtherPhysician Table
            builder.Entity<ClaimOtherPhysician>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimOtherPhysician>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimOtherPhysicians).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimOtherPhysician>().HasOne(d => d.PhysicianType).WithMany(p => p.COPPhysicianType).HasForeignKey(d => d.PhysicianTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimOtherPhysician>().HasOne(d => d.Qualifier).WithMany(p => p.COPQualifier).HasForeignKey(d => d.QualifierID).OnDelete(DeleteBehavior.Restrict);

            // Payment Table
            builder.Entity<Payment>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<Payment>().HasOne(d => d.PayFor).WithMany(p => p.PMTPayFor).HasForeignKey(d => d.PayForID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Payment>().HasOne(d => d.PayTo).WithMany(p => p.PMTPayTo).HasForeignKey(d => d.PayToID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Payment>().HasOne(d => d.Member).WithMany(p => p.PaymentMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Payment>().HasOne(d => d.Provider).WithMany(p => p.PaymentProviders).HasForeignKey(d => d.ProviderID).OnDelete(DeleteBehavior.Restrict);

            // ClaimHeaderPayment Table
            builder.Entity<ClaimHeaderPayment>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<ClaimHeaderPayment>().HasOne(d => d.ClaimHeader).WithMany(p => p.ClaimHeaderPayments).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<ClaimHeaderPayment>().HasOne(d => d.CheckDetail).WithMany(p => p.ClaimHeaderPayments).HasForeignKey(d => d.CheckDetailID).OnDelete(DeleteBehavior.Restrict);


            // MassAdjudication Table
            builder.Entity<MassAdjudication>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // AdjudicationRequestHeader Table
            builder.Entity<AdjudicationRequestHeader>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<AdjudicationRequestHeader>().HasOne(d => d.MassAdjudication).WithMany(p => p.AdjudicationRequestHeaders).HasForeignKey(d => d.MassAdjudicationID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AdjudicationRequestHeader>().HasOne(d => d.RequestStatus).WithMany(p => p.ARHRequestStatus).HasForeignKey(d => d.RequestStatusID).OnDelete(DeleteBehavior.Restrict);

            // AdjudicationRequestDetail Table
            // Foreign Key Constraints
            builder.Entity<AdjudicationRequestDetail>().HasOne(d => d.AdjudicationRequestHeader).WithMany(p => p.AdjudicationRequestDetails).HasForeignKey(d => d.AdjudicationRequestHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AdjudicationRequestDetail>().HasOne(d => d.ClaimHeader).WithMany(p => p.AdjudicationRequestDetails).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AdjudicationRequestDetail>().HasOne(d => d.Status).WithMany(p => p.ARDStatus).HasForeignKey(d => d.StatusID).OnDelete(DeleteBehavior.Restrict);


            // RefundRequest Table
            builder.Entity<RefundRequest>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints
            builder.Entity<RefundRequest>().HasOne(d => d.RefundRequestFor).WithMany(p => p.RRRefundRequestFor).HasForeignKey(d => d.RefundRequestForID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundRequest>().HasOne(d => d.RefundStatus).WithMany(p => p.RefundRequestStatuses).HasForeignKey(d => d.RefundStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundRequest>().HasOne(d => d.RequestReason).WithMany(p => p.RRRequestReason).HasForeignKey(d => d.RequestReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundRequest>().HasOne(d => d.Provider).WithMany(p => p.RefundRequestProviders).HasForeignKey(d => d.ProviderID).OnDelete(DeleteBehavior.Restrict);

            // RefundRequestClaim Table
            builder.Entity<RefundRequestClaim>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints           
            builder.Entity<RefundRequestClaim>().HasOne(d => d.RefundRequest).WithMany(p => p.RefundRequestClaims).HasForeignKey(d => d.RefundRequestID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundRequestClaim>().HasOne(d => d.ClaimHeader).WithMany(p => p.RefundRequestClaims).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundRequestClaim>().HasOne(d => d.Member).WithMany(p => p.RefundRequestClaimMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);

            // RefundReceived Table
            builder.Entity<RefundReceived>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints            
            builder.Entity<RefundReceived>().HasOne(d => d.RefundRequest).WithMany(p => p.RefundReceiveds).HasForeignKey(d => d.RefundRequestID).OnDelete(DeleteBehavior.Restrict);

            // RefundPosting Table
            builder.Entity<RefundPosting>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints           
            builder.Entity<RefundPosting>().HasOne(d => d.RefundRequest).WithMany(p => p.RefundPostings).HasForeignKey(d => d.RefundRequestID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundPosting>().HasOne(d => d.RefundReceived).WithMany(p => p.RefundPostings).HasForeignKey(d => d.RefundReceivedID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundPosting>().HasOne(d => d.EntryType).WithMany(p => p.RPEntryType).HasForeignKey(d => d.EntryTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundPosting>().HasOne(d => d.ClaimHeader).WithMany(p => p.RefundPostings).HasForeignKey(d => d.ClaimHeaderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundPosting>().HasOne(d => d.Member).WithMany(p => p.RefundPostingMembers).HasForeignKey(d => d.MemberID).OnDelete(DeleteBehavior.Restrict);

            // RefundNote Table
            builder.Entity<RefundNote>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints           
            builder.Entity<RefundNote>().HasOne(d => d.RefundRequest).WithMany(p => p.RefundNotes).HasForeignKey(d => d.RefundRequestID).OnDelete(DeleteBehavior.Restrict);

            // RefundLetter Table
            builder.Entity<RefundLetter>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints           
            builder.Entity<RefundLetter>().HasOne(d => d.RefundRequest).WithMany(p => p.RefundLetters).HasForeignKey(d => d.RefundRequestID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<RefundLetter>().HasOne(d => d.LetterType).WithMany(p => p.RLLetterType).HasForeignKey(d => d.LetterTypeID).OnDelete(DeleteBehavior.Restrict);




            #endregion

            #region Provider Structure
            builder.Entity<IPA>(entity =>
            {
                entity.HasIndex(e => e.IPACode)
                    .HasName("UK_IPACode")
                    .IsUnique();

                entity.Property(e => e.ContactName).IsUnicode(false);
                entity.Property(e => e.Fax).IsUnicode(false);
                entity.Property(e => e.IPACode).IsUnicode(false);
                entity.Property(e => e.IPAName).IsUnicode(false);
                entity.Property(e => e.NPI).IsUnicode(false);
                entity.Property(e => e.Phone).IsUnicode(false);
                entity.Property(e => e.PrimaryEmail).IsUnicode(false);
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.Property(e => e.SecondaryEmail).IsUnicode(false);
                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<IPALOB>(entity =>
            {
                entity.HasIndex(e => new { e.IPAID, e.LOBID, e.EffectiveDate })
                    .HasName("UK_IPAIDLOBID_EffDate")
                    .IsUnique();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.IPA)
                    .WithMany(p => p.IPALOB)
                    .HasForeignKey(d => d.IPAID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_IPALOB_IPA");

                entity.HasOne(d => d.Lob)
                    .WithMany(p => p.IPALOB)
                    .HasForeignKey(d => d.LOBID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_IPALOB_LOB");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderIPA>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.IPA)
                    .WithMany(p => p.ProviderIPA)
                    .HasForeignKey(d => d.IPAID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderIPA_IPA");

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderIPA)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderIPA_Provider");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderEligibility>(entity =>
            {
                entity.Property(e => e.ProviderEligibilityCode).IsUnicode(false);
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderEligibility)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_NotToUse_ProviderEligibility_Provider");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<Provider>(entity =>
            {
                entity.HasIndex(e => e.ProviderCode)
                    .HasName("IX_Provider_Code")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Ethnicity).IsUnicode(false);

                entity.Property(e => e.Fax).IsUnicode(false);

                entity.Property(e => e.FirstName).IsUnicode(false);

                //entity.Property(e => e.FullName).IsUnicode(false);

                //entity.Property(p => p.FullName).HasComputedColumnSql("Case WHEN IsPerson = 1 THEN [LastName] + ' ' + [FirstName] ELSE [LastName] END");

                entity.Property(e => e.Gender).IsUnicode(false);

                entity.Property(e => e.LastName).IsUnicode(false);

                entity.Property(e => e.MiddleName).IsUnicode(false);

                entity.Property(e => e.NPI).IsUnicode(false);

                entity.Property(e => e.Phone).IsUnicode(false);

                entity.Property(e => e.PrimaryEmail).IsUnicode(false);

                entity.Property(e => e.ProviderCode).IsUnicode(false);

                entity.Property(e => e.Race).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.SecondaryEmail).IsUnicode(false);

                entity.Property(e => e.SSN).IsUnicode(false);

                entity.Property(e => e.Suffix).IsUnicode(false);

                entity.Property(e => e.Title).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderLocation>(entity =>
            {
                entity.Property(e => e.ProviderLocationID).ValueGeneratedOnAdd();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Location)
                   .WithMany(p => p.ProviderLocation)
                   .HasForeignKey(d => d.LocationID)
                   .OnDelete(DeleteBehavior.Restrict)
                   .HasConstraintName("FK_ProviderLocation_Location");

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.GroupLocation)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderLocation_Provider");

                entity.HasOne(d => d.GroupProvider)
                    .WithMany(p => p.GroupProviderLocation)
                    .HasForeignKey(d => d.GroupID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderLocation_GroupProvider");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });
            //builder.Entity<ProviderMap>(entity =>
            //{
            //    entity.HasIndex(e => new { e.ProviderRelationID, e.ProviderLocationID, e.ProviderContractID, e.EffectiveDate })
            //        .HasName("UK_ProviderMap")
            //        .IsUnique();

            //    entity.Property(e => e.CreatedBy).IsUnicode(false);

            //    entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

            //    entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

            //    entity.Property(e => e.UpdatedBy).IsUnicode(false);

            //    entity.HasOne(d => d.ProviderContract)
            //        .WithMany(p => p.ProviderMap)
            //        .HasForeignKey(d => d.ProviderContractID)
            //        .OnDelete(DeleteBehavior.Restrict)
            //        .HasConstraintName("FK_ProviderMap_ProviderContract");

            //    entity.HasOne(d => d.Provider)
            //        .WithMany(p => p.ProviderMap)
            //        .HasForeignKey(d => d.ProviderID)
            //        .OnDelete(DeleteBehavior.Restrict)
            //        .HasConstraintName("FK_ProviderMap_Provider");

            //    entity.HasOne(d => d.ProviderLocation)
            //        .WithMany(p => p.ProviderMap)
            //        .HasForeignKey(d => d.ProviderLocationID)
            //        .OnDelete(DeleteBehavior.Restrict)
            //        .HasConstraintName("FK_ProviderMap_ProviderLocation");

            //    entity.HasOne(d => d.ProviderRelation)
            //        .WithMany(p => p.ProviderMap)
            //        .HasForeignKey(d => d.ProviderRelationID)
            //        .OnDelete(DeleteBehavior.Restrict)
            //        .HasConstraintName("FK_ProviderMap_ProviderRelation");
            //});
            builder.Entity<ProviderRelation>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ParentProvider)
                    .WithMany(p => p.ProviderRelationParentProvider)
                    .HasForeignKey(d => d.ParentProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderRelation_ParentProviderID");

                entity.HasOne(d => d.RelatedProvider)
                    .WithMany(p => p.ProviderRelationRelatedProvider)
                    .HasForeignKey(d => d.RelatedProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderRelation_RelatedProviderID");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderContract>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ContractHeader)
                    .WithMany(p => p.ProviderContract)
                    .HasForeignKey(d => d.ContractHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContract_Contract");

                entity.HasOne(d => d.FeeScheduleHeader)
                    .WithMany(p => p.ProviderContract)
                    .HasForeignKey(d => d.FeeScheduleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContract_FeeScheduleHeader");

                entity.HasOne(d => d.ModifierDiscountGroup)
                    .WithMany(p => p.ProviderContract)
                    .HasForeignKey(d => d.ModifierDiscountGroupID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContract_ModifierDiscountGroup");

                entity.HasOne(d => d.Network)
                    .WithMany(p => p.ProviderContractNetwork)
                    .HasForeignKey(d => d.NetworkID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContract_CommonCode1");

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.GroupContract)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContract_Provider");

                //entity.HasOne(d => d.GroupProvider)
                //    .WithMany(p => p.GroupProviderContract)
                //    .HasForeignKey(d => d.GroupID)
                //    .OnDelete(DeleteBehavior.Restrict)
                //    .HasConstraintName("FK_ProviderContract_GroupProvider");

                entity.HasOne(d => d.ProviderStatus)
                    .WithMany(p => p.ProviderContractProviderStatus)
                    .HasForeignKey(d => d.ProviderStatusID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContract_CommonCode");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderCode>(entity =>
            {
                entity.Property(e => e.CodeName).IsUnicode(false);

                entity.Property(e => e.CodeValue).IsUnicode(false);

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderCodes)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderCode_Provider");

                entity.HasOne(d => d.ControlType)
                    .WithMany(p => p.ProviderCodeControlType)
                    .HasForeignKey(d => d.ControlTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderCode_CommonCode_ControlType");

                entity.HasOne(d => d.CodeType)
                    .WithMany(p => p.ProviderCodeCodeType)
                    .HasForeignKey(d => d.CodeTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderCode_CommonCode_CodeType");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);

            });

            builder.Entity<ProviderSpecialty>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderSpecialty)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderSpecialty_Provider");

                entity.HasOne(d => d.Specialty)
                    .WithMany(p => p.ProviderSpecialty)
                    .HasForeignKey(d => d.SpecialtyID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderSpecialty_Specialty");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderNote>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.LongDescription).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.ShortDescription).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderNote)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderNote_Provider");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderEFT>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.AccountType)
                    .WithMany(p => p.ProviderEFT)
                    .HasForeignKey(d => d.AccountTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderEFT_CommonCode");

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderEFT)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderEFT_Provider");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderLanguage>(entity =>
            {
                entity.HasIndex(e => new { e.ProviderID, e.LanguageID })
                    .HasName("IX_ProviderLanguage")
                    .IsUnique();

                entity.Property(e => e.ProviderLanguageID).ValueGeneratedOnAdd();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Language).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderLanguage)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderLanguage_Provider");

                entity.HasOne(d => d.ProviderLanguages)
                    .WithMany(p => p.ProviderLanguage)
                    .HasForeignKey(d => d.LanguageID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderLanguage_CommonCode");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderContractInterest>(entity =>
            {
                entity.Property(e => e.ProviderContractInterestID).ValueGeneratedOnAdd();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.InterestQuickPay)
                    .WithMany(p => p.ProviderContractInterest)
                    .HasForeignKey(d => d.InterestQuickPayID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContractInterest_InterestQuickPay");

                entity.HasOne(d => d.ProviderContract)
                    .WithMany(p => p.ProviderContractInterest)
                    .HasForeignKey(d => d.ProviderContractID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContractInterest_ProviderContract");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderContractTimelyFiling>(entity =>
            {
                entity.Property(e => e.ProviderContractTimelyFilingID).ValueGeneratedOnAdd();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ProviderContract)
                    .WithMany(p => p.ProviderContractTimelyFiling)
                    .HasForeignKey(d => d.ProviderContractID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContractTimelyFiling_ProviderContract");

                entity.HasOne(d => d.TimelyFiling)
                    .WithMany(p => p.ProviderContractTimelyFiling)
                    .HasForeignKey(d => d.TimelyFilingID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContractTimelyFiling_TimelyFiling");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderTIN>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.TINName).IsUnicode(false);

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.ProviderTIN)
                    .HasForeignKey(d => d.ProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderTIN_Provider");

                entity.HasOne(d => d.TINType)
                    .WithMany(p => p.ProviderTIN)
                    .HasForeignKey(d => d.TINTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderTIN_CommonCode");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<ProviderContractLob>(entity =>
            {
                entity.Property(e => e.ProviderContractLOBID).ValueGeneratedOnAdd();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Lob)
                    .WithMany(p => p.ProviderContractLobs)
                    .HasForeignKey(d => d.LOBID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContractLOB_LOB");

                entity.HasOne(d => d.ProviderContract)
                    .WithMany(p => p.ProviderContractLobs)
                    .HasForeignKey(d => d.ProviderContractID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_ProviderContractLOB_ProviderContract");

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });

            builder.Entity<GroupProviderContract>(entity =>
            {
                entity.Property(e => e.GroupProviderContractID).ValueGeneratedOnAdd();

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");

                entity.HasOne(d => d.ProviderRelation)
                    .WithMany(p => p.GroupProviderContract)
                    .HasForeignKey(d => d.ProviderRelationID)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.ProviderContract)
                    .WithMany(p => p.GroupProviderContract)
                    .HasForeignKey(d => d.ProviderContractID)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasQueryFilter(x => x.RecordStatus != (byte)Core.Common.RecordStatus.Deleted);
            });
            #endregion

            #region Alert Structure

            // AlertCode Table
            builder.Entity<AlertCode>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Unique Key Constraints
            builder.Entity<AlertCode>().HasIndex(e => e.Code).IsUnique();

            // AlertCode Table
            builder.Entity<AlertModule>().Property(c => c.RecordStatus).HasDefaultValue(0);

            // Foreign Key Constraints            
            builder.Entity<AlertModule>().HasOne(d => d.AlertCode).WithMany(p => p.AlertModuleAlertCodes).HasForeignKey(d => d.AlertCodeID).OnDelete(DeleteBehavior.Restrict);

            #endregion

            #region DataFileStructure
            builder.Entity<Core.Entities.DataFileStructure.FileCategory>(entity =>
            {
                entity.Property(e => e.FileCategoryID).ValueGeneratedNever();
                entity.HasIndex(e => e.Name).IsUnique();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
            });
            builder.Entity<FileProcessStatus>(entity =>
            {
                entity.Property(e => e.FileProcessStatusID).ValueGeneratedNever();
                entity.HasIndex(e => e.StatusName).IsUnique();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
            });
            builder.Entity<FileProviderType>(entity =>
            {
                entity.Property(e => e.FileProviderTypeID).ValueGeneratedNever();
                entity.HasIndex(e => e.Code).IsUnique();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
            });
            builder.Entity<DataFileProvider>(entity =>
            {
                entity.Property(e => e.DataFileProviderID).ValueGeneratedNever();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.FileProviderType)
                    .WithMany(p => p.DataFileProviders)
                    .HasForeignKey(d => d.FileProviderTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_DataFileProvider_FileProviderType");
            });
            builder.Entity<Core.Entities.DataFileStructure.DataFileTemplate>(entity =>
            {
                entity.Property(e => e.DataFileTemplateID).ValueGeneratedNever();
                entity.HasIndex(e => e.DataFileCode).IsUnique();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.FileCategory)
                    .WithMany(p => p.DataFileTemplates)
                    .HasForeignKey(d => d.FileCategoryID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_DataFileTemplate_FileCategory");
            });
            builder.Entity<DataFileTemplateConfiguration>(entity =>
            {
                entity.Property(e => e.DataFileTemplateConfigurationID).ValueGeneratedOnAdd();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.DataFileTemplate)
                    .WithMany(p => p.DataFileTemplateConfigurations)
                    .HasForeignKey(d => d.DataFileTemplateID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_DataFileTemplateConfiguration_DataFileTemplate");
                entity.HasOne(d => d.DataFileProvider)
                    .WithMany(p => p.DataFileTemplateConfigurations)
                    .HasForeignKey(d => d.DataFileProviderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_DataFileTemplateConfiguration_DataFileProvider");
            });
            builder.Entity<DataFileFields>(entity =>
            {
                entity.Property(e => e.DataFileFieldsID).ValueGeneratedNever();
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("((0))");
                entity.HasOne(d => d.DataFileTemplate)
                    .WithMany(p => p.DataFileFields)
                    .HasForeignKey(d => d.DataFileTemplateID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_DataFileFields_DataFileTemplate");
            });
            builder.Entity<DataFilesToProcess>(entity =>
            {
                entity.Property(e => e.DataFilesToProcessID).ValueGeneratedOnAdd();
                entity.HasOne(d => d.DataFileTemplate)
                    .WithMany(p => p.DataFilesToProcess)
                    .HasForeignKey(d => d.DataFileTemplateID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_DataFilesToProcess_DataFileTemplate");
            });
            builder.Entity<DataFileDBConnection>(entity =>
            {
                entity.Property(e => e.DataFileDBConnectionID).ValueGeneratedOnAdd();
                entity.HasIndex(i => new { i.ConnectionKey, i.ProcessingEnvironment }).IsUnique();
            });
            builder.Entity<DataFileConnection>(entity =>
            {
                entity.Property(e => e.DataFileConnectionID).ValueGeneratedOnAdd();
                entity.HasIndex(i => i.ConnectionKey).IsUnique();
            });

            // Global Query Filter Concept
            //foreach (var type in builder.Model.GetEntityTypes())
            //{
            //    if (typeof(CoreEntity).IsAssignableFrom(type.ClrType) && (type.BaseType == null || !typeof(CoreEntity).IsAssignableFrom(type.BaseType.ClrType)))
            //        builder.SetSoftDeleteCoreEntityFilter(type.ClrType);

            //    if (typeof(UserCoreEntity).IsAssignableFrom(type.ClrType) && (type.BaseType == null || !typeof(UserCoreEntity).IsAssignableFrom(type.BaseType.ClrType)))
            //        builder.SetSoftDeleteUserCoreEntityFilter(type.ClrType);
            //}

            #endregion

            #region Organization Rule
            builder.Entity<RuleHeader>(entity =>
            {
                entity.HasIndex(e => new { e.CompanyID, e.SubCompanyID, e.Lobid, e.ProductTypeID, e.HealthPlanID })
                    .HasName("UK_RuleHeader")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.RuleHeaderCompanies)
                    .HasForeignKey(d => d.CompanyID)
                    .HasConstraintName("FK_RuleHeader_Organization_Company");

                entity.HasOne(d => d.HealthPlan)
                    .WithMany(p => p.RuleHeaders)
                    .HasForeignKey(d => d.HealthPlanID)
                    .HasConstraintName("FK_RuleHeader_HealthPlan");

                entity.HasOne(d => d.Lob)
                    .WithMany(p => p.RuleHeaders)
                    .HasForeignKey(d => d.Lobid)
                    .HasConstraintName("FK_RuleHeader_LOB");

                entity.HasOne(d => d.ProductType)
                    .WithMany(p => p.RuleHeaders)
                    .HasForeignKey(d => d.ProductTypeID)
                    .HasConstraintName("FK_RuleHeader_ProductType");

                entity.HasOne(d => d.SubCompany)
                    .WithMany(p => p.RuleHeaderSubCompanies)
                    .HasForeignKey(d => d.SubCompanyID)
                    .HasConstraintName("FK_RuleHeader_Organization_SubCompany");
            });

            builder.Entity<RuleHeaderAutoPay>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderAutoPays)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderAutoPay_RuleHeader");
            });

            builder.Entity<RuleHeaderAutoPayDetail>(entity =>
            {
                entity.Property(e => e.BillTypeCode).IsUnicode(false);

                entity.Property(e => e.Cptcode).IsUnicode(false);

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Dxbegin).IsUnicode(false);

                entity.Property(e => e.Dxend).IsUnicode(false);

                entity.Property(e => e.ModifierCode).IsUnicode(false);

                entity.Property(e => e.Poscode).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ClinicalCodeSubGroup)
                    .WithMany(p => p.RuleHeaderAutoPayDetails)
                    .HasForeignKey(d => d.ClinicalCodeSubGroupID)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_ClinicalCodeSubGroup");

                entity.HasOne(d => d.FormType)
                    .WithMany(p => p.RuleHeaderAutoPayDetailFormTypes)
                    .HasForeignKey(d => d.FormTypeID)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_CommonCode_FormType");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.RuleHeaderAutoPayDetailGroups)
                    .HasForeignKey(d => d.GroupID)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_Provider_Group");

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.RuleHeaderAutoPayDetailProviders)
                    .HasForeignKey(d => d.ProviderID)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_Provider");

                entity.HasOne(d => d.ProviderStatus)
                    .WithMany(p => p.RuleHeaderAutoPayDetailProviderStatuses)
                    .HasForeignKey(d => d.ProviderStatusID)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_CommonCode_ProviderStatus");

                entity.HasOne(d => d.RuleHeaderAutoPay)
                    .WithMany(p => p.RuleHeaderAutoPayDetails)
                    .HasForeignKey(d => d.RuleHeaderAutoPayID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_RuleHeaderAutoPay");

                entity.HasOne(d => d.Specialty)
                    .WithMany(p => p.RuleHeaderAutoPayDetails)
                    .HasForeignKey(d => d.SpecialtyID)
                    .HasConstraintName("FK_RuleHeaderAutoPayDetail_Specialty");
            });

            builder.Entity<RuleHeaderCapitation>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderCapitations)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RuleHeaderCapitation_RuleHeader");
            });

            builder.Entity<RuleHeaderClaimAddress>(entity =>
            {
                entity.HasIndex(e => new { e.RuleHeaderID, e.Name, e.EffectiveDate })
                    .HasName("UK_RuleHeaderClaimAddress")
                    .IsUnique();

                entity.Property(e => e.Address1).IsUnicode(false);

                entity.Property(e => e.Address2).IsUnicode(false);

                entity.Property(e => e.City).IsUnicode(false);

                entity.Property(e => e.Country).IsUnicode(false);

                entity.Property(e => e.County).IsUnicode(false);

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.Fax).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Phone).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.State).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.Property(e => e.Zip).IsUnicode(false);

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderClaimAddresses)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RuleHeaderClaimAddress_RuleHeader");
            });

            builder.Entity<RuleHeaderFeeSchedule>(entity =>
            {
                entity.HasIndex(e => new { e.RuleHeaderID, e.ClaimTypeID, e.ContractID, e.ProviderTypeID, e.EffectiveDate })
                    .HasName("UX_RuleHeaderFeeSchedule")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ClaimType)
                    .WithMany(p => p.RuleHeaderFeeScheduleClaimTypes)
                    .HasForeignKey(d => d.ClaimTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderFeeSchedule_CommonCode_ClaimType");

                entity.HasOne(d => d.Contract)
                    .WithMany(p => p.RuleHeaderFeeSchedules)
                    .HasForeignKey(d => d.ContractID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderFeeSchedule_Contract");

                entity.HasOne(d => d.ProviderType)
                    .WithMany(p => p.RuleHeaderFeeScheduleProviderTypes)
                    .HasForeignKey(d => d.ProviderTypeID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderFeeSchedule_CommonCode_ProviderType");

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderFeeSchedules)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderFeeSchedule_RuleHeader");
            });

            builder.Entity<RuleHeaderInterest>(entity =>
            {
                entity.HasIndex(e => new { e.RuleHeaderID, e.InterestQuickPayID, e.EffectiveDate })
                    .HasName("UK_RuleHeaderInterest")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.InterestQuickPay)
                    .WithMany(p => p.RuleHeaderInterests)
                    .HasForeignKey(d => d.InterestQuickPayID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderInterest_InterestQuickPay");

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderInterests)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderInterest_RuleHeader");
            });

            builder.Entity<RuleHeaderMessage>(entity =>
            {
                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.EnglishMessage).IsUnicode(false);

                entity.Property(e => e.FormNumber).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderMessages)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderMessage_RuleHeader");
            });

            builder.Entity<RuleHeaderModifierDiscount>(entity =>
            {
                entity.HasIndex(e => new { e.RuleHeaderID, e.ModifierDiscountGroupID, e.EffectiveDate })
                    .HasName("UK_RuleHeaderModifierDiscount")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.ModifierDiscountGroup)
                    .WithMany(p => p.RuleHeaderModifierDiscounts)
                    .HasForeignKey(d => d.ModifierDiscountGroupID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderModifierDiscount_ModifierDiscountGroup");

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderModifierDiscounts)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderModifierDiscount_RuleHeader");
            });

            builder.Entity<RuleHeaderTimelyFiling>(entity =>
            {
                entity.HasIndex(e => new { e.RuleHeaderID, e.TimelyFilingID, e.EffectiveDate })
                    .HasName("UK_RuleHeaderTimelyFiling")
                    .IsUnique();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);

                entity.Property(e => e.UpdatedBy).IsUnicode(false);

                entity.HasOne(d => d.RuleHeader)
                    .WithMany(p => p.RuleHeaderTimelyFilings)
                    .HasForeignKey(d => d.RuleHeaderID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderTimelyFiling_RuleHeader");

                entity.HasOne(d => d.TimelyFiling)
                    .WithMany(p => p.RuleHeaderTimelyFilings)
                    .HasForeignKey(d => d.TimelyFilingID)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_RuleHeaderTimelyFiling_TimelyFiling");
            });
            builder.Entity<RuleHeaderEditRule>(entity =>
            {
                entity.Property(e => e.RuleHeaderEditRuleID).HasColumnName("RuleHeaderEditRuleID").ValueGeneratedOnAdd();
                entity.Property(e => e.RecordStatus).HasDefaultValue(0);
                entity.Property(e => e.CreatedBy).IsUnicode(false);
                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);
                entity.Property(e => e.UpdatedBy).IsUnicode(false);
                entity.HasOne(d => d.RuleHeader).WithMany(p => p.RuleHeaderEditRules).HasForeignKey(d => d.RuleHeaderID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_RuleHeaderEditRule_RuleHeader");
                entity.HasOne(d => d.EditCode).WithMany(p => p.RuleHeaderEditRules).HasForeignKey(d => d.EditCodeID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_RuleHeaderEditRule_EditCode");
                entity.HasOne(d => d.CommonCodeOutCome).WithMany(p => p.RuleHeaderEditRulesOutCome).HasForeignKey(d => d.OutComeID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_RuleHeaderEditRule_CommonCode_OutCome");
                entity.HasOne(d => d.CommonCodeOutComeCode).WithMany(p => p.RuleHeaderEditRulesOutComeCode).HasForeignKey(d => d.OutComeCodeID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_RuleHeaderEditRule_CommonCode_OutComeCode");

            });
            builder.Entity<RuleHeaderEditRuleCriteria>(entity =>
            {
                entity.Property(e => e.RuleHeaderEditRuleCriteriaID).HasColumnName("RuleHeaderEditRuleCriteriaID").ValueGeneratedOnAdd();
                entity.Property(e => e.RecordStatus).HasDefaultValue(0);
                entity.Property(e => e.CreatedBy).IsUnicode(false);
                entity.Property(e => e.RecordStatusChangeComment).IsUnicode(false);
                entity.Property(e => e.UpdatedBy).IsUnicode(false);
                entity.HasOne(d => d.RuleHeaderEditRule).WithMany(p => p.RuleHeaderEditRuleCriterias).HasForeignKey(d => d.RuleHeaderEditRuleID).OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_RuleHeaderEditRule_RuleHeaderEditRuleCriterias");
            });
            #endregion

            #region Masters

            builder.Entity<ServiceTypeCode>(entity =>
            {

                entity.HasIndex(e => e.Code)
                    .HasName("UK_ServiceTypeCode_Code")
                    .IsUnique();

                entity.Property(e => e.AddedSource).IsUnicode(false);

                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.HomeGrown).IsUnicode(false);

                entity.Property(e => e.UpdatedSource).IsUnicode(false);

                //entity.HasOne(d => d.BenefitHeader)
                //  .WithMany(p => p.RuleHeaderInterests)
                //  .HasForeignKey(d => d.RuleHeaderID)
                //  .OnDelete(DeleteBehavior.Restrict)
                //  .HasConstraintName("FK_RuleHeaderInterest_RuleHeader");

                //entity.HasOne(d => d.BenefitHeader)
                //    .WithMany(p => p.ServiceTypeCodes)
                //    .HasForeignKey(d => d.ServiceTypeCodeID)
                //    .OnDelete(DeleteBehavior.Restrict)
                //    .HasConstraintName("FK_ServiceTypeCode_BenefitHeader_ServiceTypeCodeID");
            });


            // DBField Table
            builder.Entity<DBField>().HasIndex(e => new { e.TableName, e.FieldName }).HasName("IX_DBField").IsUnique();

            // PaymentType Table
            builder.Entity<PaymentType>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<PaymentType>().HasIndex(e => new { e.Code }).HasName("UK_PaymentType_Code").IsUnique();

            // CheckStatus Table
            builder.Entity<CheckStatus>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<CheckStatus>().HasIndex(e => new { e.Code }).HasName("UK_CheckStatus_Code").IsUnique();

            //DocumentType Table
            builder.Entity<DocumentType>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<DocumentType>().HasIndex(e => new { e.TypeName }).HasName("UK_DocumentType_TypeName").IsUnique();

            builder.Entity<DocumentType>().HasOne(e => e.ParentDocumentType).WithMany(p => p.ParentDocumentTypes).HasForeignKey(d => d.ParentDocumentTypeID).OnDelete(DeleteBehavior.Restrict);

            // Edit Code Logic Query
            builder.Entity<EditCodeLogicQuery>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<EditCodeLogicQuery>().HasOne(e => e.EditCode).WithMany(p => p.EditCodeLogicQueries).HasForeignKey(d => d.EditCodeID).OnDelete(DeleteBehavior.Restrict);

            // Edit Code Logic Column
            builder.Entity<EditCodeLogicColumn>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<EditCodeLogicColumn>().HasOne(e => e.EditCode).WithMany(p => p.EditCodeLogicColumns).HasForeignKey(d => d.EditCodeID).OnDelete(DeleteBehavior.Restrict);

            // Edit Code Logic Expression
            builder.Entity<EditCodeExpression>().Property(e => e.RecordStatus).HasDefaultValue(0);
            builder.Entity<EditCodeExpression>().HasOne(e => e.EditCode).WithMany(p => p.EditCodeExpression).HasForeignKey(d => d.EditCodeID).OnDelete(DeleteBehavior.Restrict);

            //SEPReasonCode
            builder.Entity<SEPReasonCode>().Property(c => c.RecordStatus).HasDefaultValue(0);


            #endregion

            #region CommonStructure

            //Document Table
            builder.Entity<Document>().Property(d => d.RecordStatus).HasDefaultValue(0);
            builder.Entity<Document>().HasOne(d => d.DocumentType).WithMany(p => p.DDocumentType).HasForeignKey(d => d.DocumentTypeID).OnDelete(DeleteBehavior.Restrict);
            ////OtherDocument Table
            //builder.Entity<OtherDocument>().Property(d => d.DocumentId).HasDefaultValue(0);
            //builder.Entity<OtherDocument>().HasOne(d => d.DocumentType).WithMany(p => p.DDocumentType).HasForeignKey(d => d.DocumentTypeID).OnDelete(DeleteBehavior.Restrict);

            #endregion

            #region Finance Structure

            // AccountDetail Table
            builder.Entity<AccountDetail>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<AccountDetail>().HasOne(f => f.AccountType).WithMany(p => p.ADAccountType).HasForeignKey(f => f.AccountTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<AccountDetailCompanyStructure>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.AccountDetail).WithMany(p => p.AccountDetailCompanyStructures).HasForeignKey(f => f.AccountDetailID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.Organization).WithMany(p => p.ADCSOrganization).HasForeignKey(f => f.OrganizationID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.Company).WithMany(p => p.ADCSCompany).HasForeignKey(f => f.CompanyID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.SubCompany).WithMany(p => p.ADCSSubCompany).HasForeignKey(f => f.SubCompanyID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.Sponsor).WithMany(p => p.ADCSSponsor).HasForeignKey(f => f.SponsorID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.Product).WithMany(p => p.ADCSProduct).HasForeignKey(f => f.ProductID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.Category).WithMany(p => p.ADCSCategory).HasForeignKey(f => f.CategoryID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.LOB).WithMany(p => p.ADCSLOB).HasForeignKey(f => f.LOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.HealthPlan).WithMany(p => p.ADCSHealthPlan).HasForeignKey(f => f.HealthPlanID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<AccountDetailCompanyStructure>().HasOne(f => f.ProductType).WithMany(p => p.ADCSProductType).HasForeignKey(f => f.ProductTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<AccountDetailCompanyStructure>().HasIndex(f => new
            {
                f.OrganizationID,
                f.CompanyID,
                f.SubCompanyID,
                f.SponsorID
                                                                                                            ,
                f.ProductID,
                f.CategoryID,
                f.LOBID,
                f.HealthPlanID,
                f.ProductTypeID
            }).HasName("UK_AccountDetailCompanyStructure_Organizations").IsUnique();

            // CheckWriteProcess Table
            builder.Entity<CheckWriteProcess>().Property(f => f.RecordStatus).HasDefaultValue(0);

            builder.Entity<CheckWriteProcess>().HasOne(f => f.LOB).WithMany(p => p.CWPLOB).HasForeignKey(f => f.LOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.HealthPlan).WithMany(p => p.CheckWriteProcess).HasForeignKey(f => f.HealthPlanID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.AccountDetail).WithMany(p => p.CheckWriteProcesses).HasForeignKey(f => f.AccountDetailID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.Network).WithMany(p => p.CWPNetwork).HasForeignKey(f => f.NetworkID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.PaymentType).WithMany(p => p.CWPPaymentType).HasForeignKey(f => f.PaymentTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.ClaimSource).WithMany(p => p.CWPClaimSource).HasForeignKey(f => f.ClaimSourceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.PaymentDateType).WithMany(p => p.CWPPaymentDateType).HasForeignKey(f => f.PaymentDateTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckWriteProcess>().HasOne(f => f.ClaimType).WithMany(p => p.CWPClaimType).HasForeignKey(f => f.ClaimTypeID).OnDelete(DeleteBehavior.Restrict);


            // CheckDetail Table
            builder.Entity<CheckDetail>().Property(f => f.RecordStatus).HasDefaultValue(0);

            builder.Entity<CheckDetail>().HasOne(f => f.PaymentType).WithMany(p => p.CDPaymentType).HasForeignKey(f => f.PaymentTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckDetail>().HasOne(f => f.AccountDetail).WithMany(p => p.CheckDetails).HasForeignKey(f => f.AccountDetailID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckDetail>().HasOne(f => f.Vendor).WithMany(p => p.CDVendor).HasForeignKey(f => f.VendorID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckDetail>().HasOne(f => f.CheckStatus).WithMany(p => p.CDCheckStatus).HasForeignKey(f => f.CheckStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckDetail>().HasOne(f => f.Location).WithMany(p => p.CDLocation).HasForeignKey(f => f.LocationID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<CheckDetail>().HasOne(f => f.CheckWriteProcess).WithMany(p => p.CheckDetails).HasForeignKey(f => f.CheckWriteProcessID).OnDelete(DeleteBehavior.Restrict);


            // Adjustment Table
            //builder.Entity<Adjustment>().Property(f => f.RecordStatus).HasDefaultValue(0);

            //builder.Entity<Adjustment>().HasOne(f => f.LOB).WithMany(p => p.ALOB).HasForeignKey(f => f.LOBID).OnDelete(DeleteBehavior.Restrict);
            //builder.Entity<Adjustment>().HasOne(f => f.Provider).WithMany(p => p.AProvider).HasForeignKey(f => f.ProviderID).OnDelete(DeleteBehavior.Restrict);
            //builder.Entity<Adjustment>().HasOne(f => f.PaymentType).WithMany(p => p.APaymentType).HasForeignKey(f => f.PaymentTypeID).OnDelete(DeleteBehavior.Restrict);
            //builder.Entity<Adjustment>().HasOne(f => f.Reason).WithMany(p => p.AReason).HasForeignKey(f => f.ReasonID).OnDelete(DeleteBehavior.Restrict);


            // AdjustmentAppliedDetail Table
            builder.Entity<AdjustmentAppliedDetail>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<AdjustmentAppliedDetail>().HasOne(f => f.CheckDetail).WithMany(p => p.AdjustmentAppliedDetails).HasForeignKey(f => f.AdjustmentCheckDetailID).OnDelete(DeleteBehavior.Restrict);

            // LienHolder Table
            builder.Entity<LienHolder>().Property(f => f.RecordStatus).HasDefaultValue(0);

            // LienHolderBalance Table
            builder.Entity<LienHolderBalance>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<LienHolderBalance>().HasOne(f => f.LienHolder).WithMany(p => p.LienHolderBalances).HasForeignKey(f => f.LienHolderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<LienHolderBalance>().HasOne(f => f.LOB).WithMany(p => p.LHBLOB).HasForeignKey(f => f.LOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<LienHolderBalance>().HasOne(f => f.Provider).WithMany(p => p.LHBProvider).HasForeignKey(f => f.ProviderID).OnDelete(DeleteBehavior.Restrict);

            // LienHolderDocument Table
            builder.Entity<LienHolderDocument>().HasKey(f => new { f.LienHolderID, f.DocumentID });
            builder.Entity<LienHolderDocument>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<LienHolderDocument>().HasOne(f => f.LienHolder).WithMany(p => p.LienHolderDocuments).HasForeignKey(f => f.LienHolderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<LienHolderDocument>().HasOne(f => f.Document).WithMany(p => p.LHDDocument).HasForeignKey(f => f.DocumentID).OnDelete(DeleteBehavior.Restrict);


            // BillParameter Table
            builder.Entity<BillParameter>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<BillParameter>().HasOne(f => f.LOB).WithMany(p => p.BPLOB).HasForeignKey(f => f.LOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<BillParameter>().HasOne(f => f.SourceType).WithMany(p => p.BPSourceType).HasForeignKey(f => f.SourceTypeID).OnDelete(DeleteBehavior.Restrict);

            // Form1099Process Table
            builder.Entity<Form1099Process>().Property(f => f.RecordStatus).HasDefaultValue(0);

            // Form1099 Table
            builder.Entity<Form1099>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<Form1099>().HasOne(f => f.Form1099Process).WithMany(p => p.Form1099s).HasForeignKey(f => f.Form1099ProcessID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Form1099>().HasOne(f => f.Recipient).WithMany(p => p.FProvider).HasForeignKey(f => f.RecipientID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Form1099>().HasOne(f => f.Document).WithMany(p => p.FDocument).HasForeignKey(f => f.DocumentID).OnDelete(DeleteBehavior.Restrict);


            //LienHolderBalanceCheckDetail Table
            builder.Entity<LienHolderBalanceCheckDetail>().HasKey(f => new { f.CheckDetailID, f.LienHolderBalanceID });
            builder.Entity<LienHolderBalanceCheckDetail>().HasOne(f => f.LienHolderBalance).WithMany(p => p.LienHolderBalanceCheckDetails).HasForeignKey(f => f.LienHolderBalanceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<LienHolderBalanceCheckDetail>().HasOne(f => f.CheckDetail).WithMany(p => p.LienHolderBalanceCheckDetails).HasForeignKey(f => f.CheckDetailID).OnDelete(DeleteBehavior.Restrict);

            //Form1099Data Table            
            builder.Entity<Form1099Data>().HasOne(f => f.Form1099Process).WithMany(p => p.Form1099DataList).HasForeignKey(f => f.Form1099ProcessID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Form1099Data>().HasOne(f => f.Recipient).WithMany(p => p.FDProvider).HasForeignKey(f => f.RecipientID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Form1099Data>().Property(f => f.RecordStatus).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box10CropInsuranceProceeds).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box11).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box12).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box13ExcessGoldenParachutePayments).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box14GrossProceedsPaidToAnAttorney).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box15aSection409ADeferrals).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box15bSection409AIncome).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box16StateTaxWithheld1).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box16StateTaxWithheld2).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box18StateIncome1).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box18StateIncome2).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box1Rents).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box2Royalties).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box3OtherIncome).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box4FederalIncomeTaxWithheld).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box5FishingBoatProceeds).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box6MedicalAndHealthCarePayments).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box7NonEmployeeCompensation).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box8SubstitutePaymentsInLieuOfDividendsOrInterest).HasDefaultValue(0);
            builder.Entity<Form1099Data>().Property(f => f.Box9PayerMadeDirectSales).HasDefaultValue(0);

            #endregion

            #region ETLStructure
            builder.Entity<DataFileProcessConfiguration>(entity =>
            {
                entity.ToTable("DataFileProcessConfiguration", "ETL");

                entity.Property(e => e.DataFileProcessConfigurationId).HasColumnName("DataFileProcessConfigurationID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                //entity.Property(e => e.DatafileTemplateId).HasColumnName("DatafileTemplateID");

                entity.Property(e => e.FileFrequencySchedule)
                    .HasMaxLength(800)
                    .IsUnicode(false);

                entity.Property(e => e.LastRunDate).HasColumnType("datetime");

                entity.Property(e => e.NextRunDate).HasColumnType("datetime");

                entity.Property(e => e.RecordStatusChangeComment)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.ScheduleEndDate).HasColumnType("date");

                entity.Property(e => e.ScheduleStartDate).HasColumnType("date");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                //entity.HasOne(d => d.DatafileTemplate)
                //    .WithMany(p => p.DataFileProcessConfigurations)
                //    .HasForeignKey(d => d.DatafileTemplateId)
                //    .OnDelete(DeleteBehavior.ClientSetNull)
                //    .HasConstraintName("FK_DataFileTemplate_DatafileTemplateID");
            });

            builder.Entity<DataFileProcessConfigurationDetails>(entity =>
            {
                //entity.HasKey(e => e.DataFileProcessConfigurationDetailsId);

                entity.ToTable("DataFileProcessConfigurationDetails", "ETL");

                entity.Property(e => e.DataFileProcessConfigurationDetailsId).HasColumnName("DataFileProcessConfigurationDetailsID");

                entity.Property(e => e.DataConnectionId).HasColumnName("DataConnectionID");

                entity.Property(e => e.DataFileProcessConfigurationId).HasColumnName("DataFileProcessConfigurationID");

                entity.Property(e => e.ProcessApp)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessCategory)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessPath)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ProviderType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ProviderValue)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                //entity.HasOne(d => d.DataFileProcessConfiguration)
                //    .WithMany(p => p.DataFileProcessConfigurationDetails)
                //    .HasForeignKey(d => d.DataFileProcessConfigurationId)
                //    .OnDelete(DeleteBehavior.ClientSetNull)
                //    .HasConstraintName("FK_DataFileProcessConfigurationDetails_DataFileProcessConfigurationID");
            });

            builder.Entity<Core.Entities.ETLStructure.DataFileTemplate>(entity =>
            {
                entity.ToTable("DataFileTemplate", "ETL");

                entity.HasIndex(e => e.DataFileCode, "UK_DataFileTemplate_DataFileCode")
                    .IsUnique();

                entity.Property(e => e.DataFileTemplateId)
                    .ValueGeneratedNever()
                    .HasColumnName("DataFileTemplateID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DataFileCode)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.FieldSeprator)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.FileCategoryId).HasColumnName("FileCategoryID");

                entity.Property(e => e.FileDesc)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.FileExtn)
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.FileFormatFullPath)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.FileNamingConvention)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FileSubCategoryId).HasColumnName("FileSubCategoryID");

                entity.Property(e => e.FileTemplateTypeId).HasColumnName("FileTemplateTypeID");

                entity.Property(e => e.IsImportExport)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("IsImport_Export")
                    .IsFixedLength();

                entity.Property(e => e.RecordStatusChangeComment)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                //entity.HasOne(d => d.FileTemplateType)
                //    .WithMany(p => p.DataFileTemplates)
                //    .HasForeignKey(d => d.FileTemplateTypeId)
                //    .OnDelete(DeleteBehavior.ClientSetNull)
                //    .HasConstraintName("FK_DataFileTemplate_FileTemplateTypeID");
            });

            builder.Entity<DataFileTemplateFields>(entity =>
            {
                entity.ToTable("DataFileTemplateFields", "ETL");

                entity.Property(e => e.DataFileTemplateFieldsID).ValueGeneratedNever();

                entity.Property(e => e.DataFileTemplateID);

                entity.Property(e => e.SectionID);

                entity.Property(e => e.FieldName).HasMaxLength(100).IsUnicode(false);

                entity.Property(e => e.FieldType).HasMaxLength(32).IsUnicode(false);

                entity.Property(e => e.FieldSize);

                entity.Property(e => e.LayOutFor).HasMaxLength(100).IsUnicode(false);

                entity.Property(e => e.FieldUsageLogic1).HasMaxLength(200).IsUnicode(false);

                entity.Property(e => e.FieldUsageLogic1Desc).HasMaxLength(2000).IsUnicode(false);

                entity.Property(e => e.FieldSequence);

                entity.Property(e => e.ExcelSheetPosition);

                entity.Property(e => e.DestinationTableName).HasMaxLength(100).IsUnicode(false);

                entity.Property(e => e.DestinationColumnName).HasMaxLength(100).IsUnicode(false);

                entity.Property(e => e.RecordStatusChangeComment).HasMaxLength(400).IsUnicode(false);

                entity.Property(e => e.CreatedBy).HasMaxLength(40).IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedBy).HasMaxLength(40).IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.DataFileTemplate).WithMany(p => p.DataFileTemplateFields)
                   .HasForeignKey(d => d.DataFileTemplateID)
                   .OnDelete(DeleteBehavior.ClientSetNull)
                   .HasConstraintName("FK_DataFileTemplateFields_DataFileTemplateID");

            });

            builder.Entity<DataFileToProcess>(entity =>
            {
                entity.ToTable("DataFileToProcess", "ETL");

                entity.Property(e => e.DataFileToProcessId).HasColumnName("DataFileToProcessID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DataFileProcessConfigurationId).HasColumnName("DataFileProcessConfigurationID");

                entity.Property(e => e.FileProcessStatusId).HasColumnName("FileProcessStatusID");

                entity.Property(e => e.RecordStatusChangeComment)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.DataFileProcessConfiguration)
                    .WithMany(p => p.DataFileToProcesses)
                    .HasForeignKey(d => d.DataFileProcessConfigurationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DataFileToProcess_DataFileProcessConfigurationID");
            });

            builder.Entity<DataFileToProcessDetails>(entity =>
            {
                entity.HasKey(e => e.DataFileToProcessDetailsId);

                entity.ToTable("DataFileToProcessDetails", "ETL");

                entity.Property(e => e.DataFileToProcessDetailsId).HasColumnName("DataFileToProcessDetailsID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                //entity.Property(e => e.DataFileToProcessId).HasColumnName("DataFileToProcessID");

                entity.Property(e => e.FileName)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FilePath)
                    .HasMaxLength(800)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessEndTime).HasColumnType("datetime");

                entity.Property(e => e.ProcessStartTime).HasColumnType("datetime");

                entity.Property(e => e.RecordStatusChangeComment)
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.DataFileToProcess)
                    .WithMany(p => p.DataFileToProcessDetails)
                    .HasForeignKey(d => d.DataFileToProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DataFileToProcessDetails_DataFileToProcessID");
            });

            builder.Entity<FileTemplateType>(entity =>
            {
                entity.ToTable("FileTemplateType", "ETL");

                entity.HasIndex(e => e.TypeName, "UK_FileTemplateType_TypeName")
                    .IsUnique();

                entity.Property(e => e.FileTemplateTypeId)
                    .ValueGeneratedNever()
                    .HasColumnName("FileTemplateTypeID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.TypeName)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            builder.Entity<Core.Entities.ETLStructure.FileCategory>(entity =>
            {
                entity.Property(e => e.FileCategoryID).ValueGeneratedNever().HasColumnName("FileCategoryID");
                entity.Property(e => e.RecordStatus).HasDefaultValue(0);

            });

            builder.Entity<FileSubCategory>(entity =>
            {
                entity.Property(e => e.FileSubCategoryID).ValueGeneratedNever().HasColumnName("FileSubCategoryID");
                entity.Property(e => e.RecordStatus).HasDefaultValue(0);

            });
            #endregion

            #region Views
            builder.Entity<vwRuleHeader>().ToView("vwRuleHeader", "master");
            builder.Entity<vwRuleHeader>().Property(i => i.CompanyName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.SubCompanyName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.LobName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.ProductTypeName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.HealthPlanName).IsUnicode(false);

            builder.Entity<GetBenefitModel>().ToView("vwBenefit", "hps");

            builder.Entity<GetPlanModel>().ToView("vwPlan", "master");
            builder.Entity<GetPlanModel>().Property(i => i.Company).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.County).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.LOB).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.PBPCode).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.PlanCode).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.PlanName).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.ProductType).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.State).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.SubCompany).IsUnicode(false);
            builder.Entity<GetPlanModel>().Property(i => i.ApprovalStatus).IsUnicode(false);

            #endregion

            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.ApplicationStatus).WithMany(p => p.EApplicationStatus).HasForeignKey(d => d.ApplicationStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.Lob).WithMany(p => p.MemberEnrollmentHeaders).HasForeignKey(d => d.LOBID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.Gender).WithMany(p => p.EGender).HasForeignKey(d => d.GenderID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.Race).WithMany(p => p.ERace).HasForeignKey(d => d.RaceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.Ethnicity).WithMany(p => p.EEthnicity).HasForeignKey(d => d.EthnicityID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.MemberStatus).WithMany(p => p.EMemberStatus).HasForeignKey(d => d.MemberStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.PrimaryLanguage).WithMany(p => p.EPrimaryLanguage).HasForeignKey(d => d.PrimaryLanguageID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.AccessibilityFormat).WithMany(p => p.EAccessibilityFormat).HasForeignKey(d => d.AccessibilityFormatID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.ContactType).WithMany(p => p.EContactType).HasForeignKey(d => d.ContactTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.EmergencyContactRelationship).WithMany(p => p.EEmergencyContactRelationship).HasForeignKey(d => d.EmergencyContactRelationshipID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.LISLevel).WithMany(p => p.ELISLevel).HasForeignKey(d => d.LISLevelID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.LowIncomeCopay).WithMany(p => p.ELowIncomeCopay).HasForeignKey(d => d.LowIncomeCopayID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.EnrollmentSource).WithMany(p => p.EEnrollmentSource).HasForeignKey(d => d.EnrollmentSourceID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.EnrollmentMechanism).WithMany(p => p.EEnrollmentMechanism).HasForeignKey(d => d.EnrollmentMechanismID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.PlanSpecificChronicCondition).WithMany(p => p.EPlanSpecificChronicCondition).HasForeignKey(d => d.PlanSpecificChronicConditionID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.ElectionType).WithMany(p => p.EElectionType).HasForeignKey(d => d.ElectionTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.PremiumWithholdOption).WithMany(p => p.EPremiumWithholdOption).HasForeignKey(d => d.PremiumWithholdOptionID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.DisenrollmentReasonCode).WithMany(p => p.EDisenrollmentReasonCode).HasForeignKey(d => d.DisenrollmentReasonCodeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.TransactionStatus).WithMany(p => p.ETransactionStatus).HasForeignKey(d => d.TransactionStatusID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.PendReason).WithMany(p => p.EPendReason).HasForeignKey(d => d.PendReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.IncompleteReason).WithMany(p => p.EIncompleteReason).HasForeignKey(d => d.IncompleteReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.DenialFlag).WithMany(p => p.EDenialFlag).HasForeignKey(d => d.DenialFlagID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.DenialReason).WithMany(p => p.EDenialReason).HasForeignKey(d => d.DenialReasonID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.SpanType).WithMany(p => p.ESpanType).HasForeignKey(d => d.SpanTypeID).OnDelete(DeleteBehavior.Restrict);
            builder.Entity<MemberEnrollmentHeader>().HasOne(d => d.AttachmentType).WithMany(p => p.EAttachmentType).HasForeignKey(d => d.AttachmentTypeID).OnDelete(DeleteBehavior.Restrict);

            builder.Entity<MemberPreEnrollmentAttachment>().HasOne(d => d.MemberPreEnrollment).WithMany(p => p.MemberPreEnrollmentAttachment)
                .HasForeignKey(d => d.MemberPreEnrollmentID).OnDelete(DeleteBehavior.Cascade);

            //modelBuilder.Entity<Student>()
            //.HasOne<Grade>(s => s.Grade)
            //.WithMany(g => g.Students)
            //.HasForeignKey(s => s.CurrentGradeId);

            base.OnModelCreating(builder);

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        public List<T> ExecuteStoreProcedure<T>(string CommandText, Array parameters, CommandType cmdType = CommandType.StoredProcedure) where T : new()
        {
            try
            {
                this.Database.OpenConnection();
                var cmd = this.Database.GetDbConnection().CreateCommand();
                cmd.CommandText = CommandText;
                cmd.CommandType = cmdType;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                using (var reader = cmd.ExecuteReader())
                {
                    return reader.MapToList<T>();
                }
            }
            finally
            {
                this.Database.CloseConnection();
            }
        }

        #region PreEnrollment

        public DbSet<PreEnrollment> PreEnrollment { get; set; }
        #endregion PreEnrollment

    }
}
