

/****** Object:  UserDefinedFunction [EDI].[fn_trim_leading_zero]    Script Date: 7/5/2017 1:22:36 AM ******/
IF EXISTS(SELECT '*' FROM sys.objects WHERE object_id = OBJECT_ID(N'[EDI].[fn_trim_leading_zero]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [EDI].[fn_trim_leading_zero]
GO

/****** Object:  UserDefinedFunction [EDI].[fn_trim_leading_zero]    Script Date: 7/5/2017 1:22:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [EDI].[fn_trim_leading_zero] (@varIn money)
RETURNS varchar(max) AS
BEGIN
	return EDI.fn_LTrimPat(replace(@varIn, '-0.', '-.'), '0')
END



GO


