

/****** Object:  UserDefinedFunction [EDI].[fn_LTrimPat]    Script Date: 7/5/2017 1:22:16 AM ******/
IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[EDI].[fn_LTrimPat]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [EDI].[fn_LTrimPat]
GO

/****** Object:  UserDefinedFunction [EDI].[fn_LTrimPat]    Script Date: 7/5/2017 1:22:16 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO


CREATE FUNCTION [EDI].[fn_LTrimPat] (@StringToTrim varchar(4000), @PatternToTrim varchar(500))
RETURNS varchar(4000) AS  
/*********************
-- START DOC --
FUNCTION: fn_LTrimPat
	Parameter:	[IN] @StringToTrim varchar(4000)
			[IN] @PatternToTrim varchar(500)
			[RETURN] varchar(4000)
	Type:		varchar
	
	Characteristic:	DETERMINISTIC
	Description:	Returns the string @StringToTrim trimmed of the leading string @PatternToTrim.
	
	Example:	select EDI.fn_LTrimPat('000001234', '0'); returns '1234'
-- END DOC --
*********************/
BEGIN 
	declare @TrimmedString varchar(4000)

	set @TrimmedString = @StringToTrim

	while	(
			LEFT(@TrimmedString, Len(@PatternToTrim)) = @PatternToTrim AND
			Len(@PatternToTrim) > 0
		)
	begin
		set @TrimmedString = STUFF(@TrimmedString, 1, Len(@PatternToTrim), '')
	end

	return @TrimmedString
END




GO


