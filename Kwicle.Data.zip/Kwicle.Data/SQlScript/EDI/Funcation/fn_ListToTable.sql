

/****** Object:  UserDefinedFunction [EDI].[fn_ListToTable]    Script Date: 7/5/2017 1:21:01 AM ******/
IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[EDI].[fn_ListToTable]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [EDI].[fn_ListToTable]
GO

/****** Object:  UserDefinedFunction [EDI].[fn_ListToTable]    Script Date: 7/5/2017 1:21:01 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [EDI].[fn_ListToTable] (@ValueList nvarchar(4000), @Delim char(1)= ',' )
RETURNS @Values TABLE ( item nvarchar(4000) )
AS
/*********************
-- START DOC --
FUNCTION: fn_ListToTable
	Parameter:	[IN] @ValueList nvarchar(4000)
			[IN] @Delim char(1), default delimiter is ","
			[RETURN] TABLE @Values COLUMN ( item nvarchar(4000) )
	Type:		TABLE
	
	Characteristic:	DETERMINISTIC
	Description:	Returns a single-column table of values created from the delimited list argument.
	
	Example:	declare @mylist nvarchar(100)
			set @mylist = 'A,B, 2,345, EFG, H,'
			select * from EDI.fn_ListToTable(@mylist, ',')  -- Returns a table with rows in the following format:
				[item]
				A
				B
				2
				345
				EFG
				H
-- END DOC --
*********************/

BEGIN
	DECLARE @chrind INT
	DECLARE @Piece nvarchar(4000)

	SELECT @chrind = 1 
	WHILE @chrind > 0
	BEGIN
		SELECT @chrind = CHARINDEX(@Delim, @ValueList)

		IF @chrind  > 0
			SELECT @Piece = LEFT(@ValueList,@chrind - 1)
		ELSE
			SELECT @Piece = @ValueList

		INSERT  @Values(item) VALUES(LTrim(RTrim(@Piece)))

		SELECT @ValueList = RIGHT(@ValueList,LEN(@ValueList) - @chrind)

		IF LEN(@ValueList) = 0 BREAK
	END
	RETURN

END









GO


