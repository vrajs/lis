
/****** Object:  UserDefinedFunction [EDI].[fn_GetProfessionalClaimError]    Script Date: 7/5/2017 1:21:45 AM ******/
IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[EDI].[fn_GetProfessionalClaimError]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [EDI].[fn_GetProfessionalClaimError]
GO

/****** Object:  UserDefinedFunction [EDI].[fn_GetProfessionalClaimError]    Script Date: 7/5/2017 1:21:45 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Shiraj>
-- Create date: <Create Date, 29/05/2017,>
-- Description:	<Description, To fetch the Claim error>
-- =============================================

CREATE FUNCTION [EDI].[fn_GetProfessionalClaimError]
(
	-- Add the parameters for the function here
	@ClaimProfessionalID INT
)
RETURNS Varchar(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Error_desc  varchar(max) = ''

	-- Add the T-SQL statements to compute the return value here	

		SELECT @Error_desc= @Error_desc + ' ('+ CONVERT(VARCHAR,ROW_NUMBER() OVER(ORDER BY c.ClaimErrorId)) + ')'+Error_desc 
		FROM EDI.ClaimErrors AS c
		INNER JOIN EDI.Mtab_M_error AS E ON C.MtabMErrorId = e.Error_id
		WHERE ClaimProfessionalID = @ClaimProfessionalID

		SELECT @Error_desc = LTRIM(RTRIM(@Error_desc)) 

	-- Return the result of the function
	RETURN @Error_desc;

END


GO


