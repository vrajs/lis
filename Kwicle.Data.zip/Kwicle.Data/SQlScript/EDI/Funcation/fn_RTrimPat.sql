

/****** Object:  UserDefinedFunction [EDI].[fn_RTrimPat]    Script Date: 7/5/2017 1:22:31 AM ******/
IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[EDI].[fn_RTrimPat]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [EDI].[fn_RTrimPat]
GO

/****** Object:  UserDefinedFunction [EDI].[fn_RTrimPat]    Script Date: 7/5/2017 1:22:31 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO


CREATE FUNCTION [EDI].[fn_RTrimPat] (@StringToTrim varchar(4000), @PatternToTrim varchar(500))
RETURNS varchar(4000) AS  
/*********************
-- START DOC --
FUNCTION: fn_RTrimPat
	Parameter:	[IN] @StringToTrim varchar(4000)
			[IN] @PatternToTrim varchar(500)
			[RETURN] varchar(4000)
	Type:		varchar
	
	Characteristic:	DETERMINISTIC
	Description:	Returns the string @StringToTrim trimmed of the leading string @PatternToTrim.
	
	Example:	select EDI.fn_RTrimPat('000001234', '0'); returns '1234'
-- END DOC --
*********************/
BEGIN 
	declare @TrimmedString varchar(4000)

	set @TrimmedString = @StringToTrim

	while	(
			RIGHT(@TrimmedString, Len(@PatternToTrim)) = @PatternToTrim AND
			Len(@PatternToTrim) > 0
		)
	begin
		set @TrimmedString = STUFF(@TrimmedString, Len(@TrimmedString)-Len(@PatternToTrim)+1, Len(@TrimmedString), '')
	end

	return @TrimmedString
END




GO


