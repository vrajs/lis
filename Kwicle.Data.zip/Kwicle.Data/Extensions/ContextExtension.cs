﻿using Kwicle.Core.CustomModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kwicle.Data.Extensions
{
    public static class ContextExtension
    {
        public static List<DbColumnInfo> GetTableSchema<T>(this DbContext _dbContext)
        {
            var entitytype = _dbContext.Model.FindEntityType(typeof(T));
            return entitytype.GetProperties().Select(e => new DbColumnInfo
            {
                //start Migration from 2.1 to 3.1
                //ColumnName = e.Relational().ColumnName,
                //ColumnType = e.Relational().ColumnType
                ColumnName = e.GetColumnName(),
                ColumnType = e.GetColumnType()
                //end Migration from 2.1 to 3.1
            }).ToList();

        }
    }
}
