﻿using Kwicle.Common.Utility;
using Kwicle.Core.Common;
using Kwicle.Core.Common.EDI;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.Custom;
using Kwicle.Core.Entities.EDI.View;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Kwicle.Data.Extensions
{
    public static class ListExtension
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="eligibility"></param>
        /// <returns></returns>
        public static List<X12270EligibilityRequest> ToConvert(this MemberEligibility eligibility)
        {

            var x12EligibilityRequests = (from memEligibility in eligibility.Eligibilities
                                          select new X12270EligibilityRequest
                                          {
                                              L2000cTrn02TraceNumber = memEligibility.MemberId,
                                              L2100cNm103SubscriberLastName = memEligibility.MemberLastName,
                                              L2100cNm104SubscriberFirstName = memEligibility.MemberFirstName,
                                              L2100cNm105SubscriberMiddleName = memEligibility.MemberMiddleName,
                                              L2100cNm109SubscriberId = memEligibility.InsuranceMemberId,
                                              L2100cRef02SySubscriberAddId = memEligibility.MemberSSN,
                                              L2100cDmg03SubscriberGender = memEligibility.MemberGender,
                                              L2100cDmg02SubscriberDob = memEligibility.MemberDOB,
                                              L2100cN301SubscriberAddress1 = memEligibility.MemberAddress1,
                                              L2100cN302SubscriberAddress2 = memEligibility.MemberAddress2,
                                              L2100cN401SubscriberCity = memEligibility.MemberCity,
                                              L2100cN402SubscriberState = memEligibility.MemberState,
                                              L2100cN403SubscriberZip = memEligibility.MemberZipCode,
                                              L2100cN404SubscriberCountry = memEligibility.MemberCountry,
                                              L2110cDtp03291PlanBeginDate = memEligibility.InsuranceEffectiveDate,
                                              L2100bNm103InfoReceiverLastNm = memEligibility.PhysicianLastName,
                                              L2100bNm104InfoReceiverFirstNm = memEligibility.PhysicianFirstname,
                                              L2100bNm109InfoReceiverId = memEligibility.PhysicianNPI,
                                              L2100bRef02TjInfoReceiverId = memEligibility.PhysicianTaxNumber,
                                              L2100bN301InfoReceiverAddress1 = memEligibility.PhysicianAddress1,
                                              L2100bN302InfoReceiverAddress2 = memEligibility.PhysicianAddress2,
                                              L2100bN401InfoReceiverCity = memEligibility.PhysicianCity,
                                              L2100bN402InfoReceiverState = memEligibility.PhysicianState,
                                              L2100bN403InfoReceiverZip = memEligibility.PhysicianZipCode,
                                              L2100aNm103InfoSourceLastNm = memEligibility.InsurancePlanName,
                                              L2100aNm109InfoSourceId = memEligibility.PayerIdentification
                                          }).ToList();

            return x12EligibilityRequests;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="edi271MemberEligibilityResponse"></param>
        /// <returns></returns>
        //public static List<Eligibility> ToConvert(this Edi271MemberEligibilityResponse edi271MemberEligibilityResponse)
        //{

        //    var eligibilities = (from response in edi271MemberEligibilityResponse.x12_271_eligibility_responses.GroupBy(mem => mem.X12TransactionId).Select(mem => mem.FirstOrDefault())
        //                         select new Eligibility
        //                         {
        //                             MemberId = response.L2000cTrn02TraceNumber,
        //                             ControlNumber = response.Isa13ControlNo,
        //                             MemberLastName = response.L2100cNm103SubscriberLastName,
        //                             MemberFirstName = response.L2100cNm104SubscriberFirstName,
        //                             MemberMiddleName = response.L2100cNm105SubscriberMiddleName,
        //                             InsuranceMemberId = response.L2100cNm109SubscriberId,
        //                             MemberSSN = response.L2100cRef02SySubscriberAddId,
        //                             MemberGender = response.L2100cDmg03SubscriberGender,
        //                             MemberDOB = CommonUtil.fn_EDItoDateTime(response.L2100cDmg02SubscriberDob),
        //                             MemberAddress1 = response.L2100cN301SubscriberAddress1,
        //                             MemberAddress2 = response.L2100cN302SubscriberAddress2,
        //                             MemberCity = response.L2100cN401SubscriberCity,
        //                             MemberState = response.L2100cN402SubscriberState,
        //                             MemberZipCode = response.L2100cN403SubscriberZip,
        //                             MemberCountry = response.L2100cN404SubscriberCountry,
        //                             MemberIdentityCardNumber = response.L2100cRef02HjSubscriberAddId,
        //                             MemberFamilyUnitNumber = response.L2100cRef0249SubscriberAddId,
        //                             MemberRelationshipCode = response.L2100cIns02IndividualRelationshipCode,
        //                             DemographyChanges = response.L2100cIns04MaintReasonCode,
        //                             PhysicianLastName = response.L2100bNm103InfoReceiverLastNm,
        //                             PhysicianFirstname = response.L2100bNm104InfoReceiverFirstNm,
        //                             PhysicianNPI = response.L2100bNm109InfoReceiverId,
        //                             PhysicianTaxNumber = response.L2100bRef02TjInfoReceiverId,
        //                             InsurancePlanName = response.L2100aNm103InfoSourceLastNm,
        //                             PayerIdentification = response.L2100aNm109InfoSourceId,
        //                             Benifits = GetBenefits(response.X12TransactionId, edi271MemberEligibilityResponse),
        //                             RejectMessage = CommonUtil.ToString(response.L2000aAaa03RejectReasonCode) +
        //                                             CommonUtil.ToString(response.L2100aAaa03RejectReasonCode) +
        //                                             CommonUtil.ToString(response.L2100bAaa03RejectReasonCode) +
        //                                             CommonUtil.ToString(response.L2100cAaa03RejectReasonCode)

        //                         }).ToList();
        //    return eligibilities;
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x12TransactionId"></param>
        /// <param name="edi271MemberEligibilityResponse"></param>
        /// <returns></returns>
        //public static List<Benefit> GetBenefits(int x12TransactionId, Edi271MemberEligibilityResponse edi271MemberEligibilityResponse)
        //{

        //    return edi271MemberEligibilityResponse.x12_271_eligibility_responses.Where(mem => mem.X12TransactionId == x12TransactionId).Select(mem => new Benefit
        //    {
        //        MemberPlanId = mem.L2110cRef0218PlanNum,
        //        GroupNumber = mem.L2110cRef026pGroupNum,
        //        InsuranceEffectiveFromDate = CommonUtil.fn_EDItoDateTime(CommonUtil.Fn_IsValuePresent(mem.L2110cDtp03291PlanDate) ? mem.L2110cDtp03291PlanDate : mem.L2110cDtp03307EligEffDate),
        //        InsuranceEffectiveToDate = CommonUtil.fn_EDItoDateTime(CommonUtil.Fn_IsValuePresent(mem.L2110cDtp03291PlanToDate) ? mem.L2110cDtp03291PlanToDate : mem.L2110cDtp03307EligTermDate),
        //        Message = mem.L2110cMsg01Text,
        //        MemberHealthplanName = mem.L2110cEb05PlanCoverageDesc,// + " ("+ Convert.ToString(mem.L2110Cref0218plannum) + ")",
        //        CoverageType = mem.L2110cEb02BenefitCoverageLevelCode,
        //        MemberServiceType = mem.L2110cEb03ServiceTypeCode,
        //        InsuranceType = mem.L2110cEb04InsuranceTypeCode,
        //        BenefitInformation = mem.L2110cEb01EligInfo,
        //        BenefitAmount = Convert.ToDecimal(mem.L2110cEb07BenefitAmt),
        //        BenefitPercent = Convert.ToDecimal(mem.L2110cEb08BenefitPercent),
        //        FormularyId = mem.L2110cRef02FoFormularyId,
        //        CopayId = mem.L2110cRef02IgCoPayId,
        //        CoverageId = mem.L2110cRef02CliCoverageId,
        //        AlternativeListId = mem.L2110cRef02AlsAlternativeNdrId,
        //        IsMemberEligible = CommonUtil.Fn_IsValuePresent(
        //                                             CommonUtil.ToString(mem.L2000aAaa03RejectReasonCode) +
        //                                             CommonUtil.ToString(mem.L2100aAaa03RejectReasonCode) +
        //                                             CommonUtil.ToString(mem.L2100bAaa03RejectReasonCode) +
        //                                             CommonUtil.ToString(mem.L2100cAaa03RejectReasonCode)
        //                                                       ) ? null : Array.IndexOf(StaticList.MemberEligibilityInactiveCode, mem.L2110cEb01EligInfo) >= 0 ? (bool?)false : (bool?)true
        //    }).ToList();
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileNamingConvention"></param>
        /// <returns></returns>
        public static DefaultFileNamingConvention SetValue(this FileNamingConvention fileNamingConvention)
        {
            var defaultFileNamingConvention = new DefaultFileNamingConvention
            {
                Prefix = fileNamingConvention.Prefix,
                FileExtension = fileNamingConvention.FileExtension,
                NameSeparator = fileNamingConvention.NameSeparator.ToString()
            };

            if (CommonUtil.Fn_IsValuePresent(fileNamingConvention.DateTimeFormat))
                defaultFileNamingConvention.DateTimeFormat = DateTime.Now.ToString(fileNamingConvention.DateTimeFormat);

            if (CommonUtil.Fn_IsValuePresent(fileNamingConvention.RandomNumber))
                defaultFileNamingConvention.RandomNumber = CommonUtil.RandomeNumber(int.Parse(fileNamingConvention.RandomNumber));


            return defaultFileNamingConvention;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorization"></param>
        /// <returns></returns>
        public static Mtab278AuthorizationRequest  ToConvert(this AuthorizationServiceEntity authorization)
        {
            var authorizationRequest = new Mtab278AuthorizationRequest();

            AuthPayer(authorizationRequest, authorization);

            AuthPhysician(authorizationRequest, authorization);

            AuthMember(authorizationRequest, authorization);

            AuthPatient(authorizationRequest, authorization);

            AuthDetail(authorizationRequest, authorization);

            return authorizationRequest;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authorization"></param>
        private static void AuthPayer(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceEntity authorization)
        {
            IReadOnlyList<string> PayerIdentifierCode = new List<string> { "2B", "PR", "X3" };

            if (authorization.Payer != null)
            {
                authorizationRequest.L2010aNm101PayerIdentifierCode = authorization.Payer.PayerIdentifierCode;
                authorizationRequest.L2010aNm102PayerTypeQualifier = PayerIdentifierCode.Contains(authorization.Payer.PayerIdentifierCode) ? "2" : "1";

                authorizationRequest.L2010aNm103PayerLastName = authorization.Payer.LastName;
                authorizationRequest.L2010aNm104PayerFirstname = authorization.Payer.FirstName;
                authorizationRequest.L2010aNm105PayerMiddlename = authorization.Payer.MiddleName;

                if (CommonUtil.Fn_IsValuePresent(authorization.Payer.PayerId))
                {
                    authorizationRequest.L2010aNm108PayerIdentificationQualifier = "PI";
                    authorizationRequest.L2010aNm109PayerId = authorization.Payer.PayerId;
                }
                else if (CommonUtil.Fn_IsValuePresent(authorization.Payer.EmployerIdentification))
                {
                    authorizationRequest.L2010aNm108PayerIdentificationQualifier = "24";
                    authorizationRequest.L2010aNm109PayerId = authorization.Payer.EmployerIdentification;
                }
                else if (CommonUtil.Fn_IsValuePresent(authorization.Payer.SSN))
                {
                    authorizationRequest.L2010aNm108PayerIdentificationQualifier = "34";
                    authorizationRequest.L2010aNm109PayerId = authorization.Payer.SSN;
                }
                else if (CommonUtil.Fn_IsValuePresent(authorization.Payer.ETIN))
                {
                    authorizationRequest.L2010aNm108PayerIdentificationQualifier = "46";
                    authorizationRequest.L2010aNm109PayerId = authorization.Payer.ETIN;
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authorization"></param>
        private static void AuthPhysician(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceEntity authorization)
        {
            IReadOnlyList<string> PhysicianIdentifierCode = new List<string> { "1P", "2B", "36" };
            if (authorization.Physician != null)
            {
                authorizationRequest.L2010bNm101RequesterIdentifierCode = authorization.Physician.PhysicianIdentifierCode;
                authorizationRequest.L2010bNm102RequesterTypeQualifier = PhysicianIdentifierCode.Contains(authorization.Physician.PhysicianIdentifierCode) ? "1" : "2";
                authorizationRequest.L2010bNm103RequesterLastName = authorization.Physician.LastName;
                authorizationRequest.L2010bNm104RequesterFirstname = authorization.Physician.FirstName;
                authorizationRequest.L2010bNm105RequesterMiddlename = authorization.Physician.MiddleName;

                if (CommonUtil.Fn_IsValuePresent(authorization.Physician.NPI))
                {
                    authorizationRequest.L2010bNm108RequesterIdentificationQualifier = "XX";
                    authorizationRequest.L2010bNm109RequesterNpi = authorization.Physician.NPI;
                }
                else if (CommonUtil.Fn_IsValuePresent(authorization.Physician.SSN))
                {
                    authorizationRequest.L2010bNm108RequesterIdentificationQualifier = "34";
                    authorizationRequest.L2010bNm109RequesterNpi = authorization.Physician.SSN;
                }
                else if (CommonUtil.Fn_IsValuePresent(authorization.Physician.EmployerIdentification))
                {
                    authorizationRequest.L2010bNm108RequesterIdentificationQualifier = "24";
                    authorizationRequest.L2010bNm109RequesterNpi = authorization.Physician.EmployerIdentification;
                }
                else if (CommonUtil.Fn_IsValuePresent(authorization.Physician.ETIN))
                {
                    authorizationRequest.L2010bNm108RequesterIdentificationQualifier = "46";
                    authorizationRequest.L2010bNm109RequesterNpi = authorization.Physician.ETIN;
                }

                if (authorization.Physician.Address != null)
                {
                    authorizationRequest.L2010bN301RequesterAddress1 = authorization.Physician.Address.Address1;
                    authorizationRequest.L2010bN302RequesterAddress2 = authorization.Physician.Address.Address2;
                    authorizationRequest.L2010bN401RequesterCity = authorization.Physician.Address.City;
                    authorizationRequest.L2010bN402RequesterState = authorization.Physician.Address.State;
                    authorizationRequest.L2010bN403RequesterZipCode = authorization.Physician.Address.ZipCode;
                }

                if (CommonUtil.Fn_IsValuePresent(authorization.Physician.TaxonomyCode))
                {
                    authorizationRequest.L2010bPrv01ProviderCode = "CO";
                    authorizationRequest.L2010bPrv02ReferenceIdentificationQualifier = "PXC";
                    authorizationRequest.L2010bPrv03TaxonomyCode = authorization.Physician.TaxonomyCode;
                }

                //
                AuthPhysicianCommunication(authorizationRequest, authorization.Physician.Communication);

                //
                AuthPhysicianSupplementalIdentification(authorizationRequest, authorization.Physician);

            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="physician"></param>
        private static void AuthPhysicianSupplementalIdentification(Mtab278AuthorizationRequest authorizationRequest, AuthorizationPhysician physician)
        {
            if (physician != null)
            {
                authorizationRequest.L2010bRef011gProviderUpinnumberQualifier = CommonUtil.Fn_IsValuePresent(physician.UPINNumber) ? "1G" : string.Empty;
                authorizationRequest.L2010bRef021gProviderUpinnumber = physician.UPINNumber;

                authorizationRequest.L2010bRef01EiEmployersIdentificationNumberQualifier = CommonUtil.Fn_IsValuePresent(physician.EmployerIdentification) ? "1J" : string.Empty;
                authorizationRequest.L2010bRef02EiEmployersIdentificationNumber = physician.EmployerIdentification;

                authorizationRequest.L2010bRef01G5ProviderSiteNumberQualifier = CommonUtil.Fn_IsValuePresent(physician.SiteNumber) ? "G5" : string.Empty;
                authorizationRequest.L2010bRef02G5ProviderSiteNumber = physician.SiteNumber;

                authorizationRequest.L2010bRef01N5ProviderPlanNetworkIdentificationNumberQualifier = CommonUtil.Fn_IsValuePresent(physician.NetworkIdentification) ? "N5" : string.Empty;
                authorizationRequest.L2010bRef02N5ProviderPlanNetworkIdentificationNumber = physician.NetworkIdentification;

                authorizationRequest.L2010bRef01N7FacilityNetworkIdentificationNumberQualifier = CommonUtil.Fn_IsValuePresent(physician.facilityNetworkIdentification) ? "N7" : string.Empty;
                authorizationRequest.L2010bRef02N7FacilityNetworkIdentificationNumber = physician.facilityNetworkIdentification;

                authorizationRequest.L2010bRef01SySocialSecurityNumberQualifier = CommonUtil.Fn_IsValuePresent(physician.SSN) ? "SY" : string.Empty;
                authorizationRequest.L2010bRef02SySocialSecurityNumber = physician.SSN;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="communication"></param>
        private static void AuthPhysicianCommunication(Mtab278AuthorizationRequest authorizationRequest, EntityCommunication communication)
        {
            if (communication != null)
            {
                authorizationRequest.L2010bPer01ContactFunctionCode = "IC";
                authorizationRequest.L2010bPer02Name = communication.ContactPersonName;

                if (CommonUtil.Fn_IsValuePresent(communication.TelephoneNumber))
                {
                    authorizationRequest.L2010bPer03EmCommunicationNumberQualifier = "TE";
                    authorizationRequest.L2010bPer04EmCommunicationNumber = communication.TelephoneNumber;
                }
                if (CommonUtil.Fn_IsValuePresent(communication.FxNumber))
                {
                    if (CommonUtil.Fn_IsValuePresent(communication.TelephoneNumber))
                    {
                        authorizationRequest.L2010bPer05FxCommunicationNumberQualifier = "FX";
                        authorizationRequest.L2010bPer06FxCommunicationNumber = communication.FxNumber;
                    }
                    else
                    {
                        authorizationRequest.L2010bPer03EmCommunicationNumberQualifier = "EM";
                        authorizationRequest.L2010bPer04EmCommunicationNumber = communication.EmailID;
                    }
                }

                if (CommonUtil.Fn_IsValuePresent(communication.EmailID))
                {
                    if (CommonUtil.Fn_IsNull_LenZero(authorizationRequest.L2010bPer04EmCommunicationNumber))
                    {
                        authorizationRequest.L2010bPer03EmCommunicationNumberQualifier = "EM";
                        authorizationRequest.L2010bPer04EmCommunicationNumber = communication.EmailID;
                    }
                    else if (CommonUtil.Fn_IsNull_LenZero(authorizationRequest.L2010bPer06FxCommunicationNumber))
                    {
                        authorizationRequest.L2010bPer05FxCommunicationNumberQualifier = "EM";
                        authorizationRequest.L2010bPer06FxCommunicationNumber = communication.EmailID;
                    }
                    else
                    {
                        authorizationRequest.L2010bPer07TeCommunicationNumberQualifier = "EM";
                        authorizationRequest.L2010bPer08TeCommunicationNumber = communication.EmailID;
                    }
                }

            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authorization"></param>
        private static void AuthMember(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceEntity authorization)
        {
            if (authorization.Member != null)
            {
                authorizationRequest.L2010cNm101SubscriberIdentifierCode = "IL";
                authorizationRequest.L2010cNm102SubscriberEntityTypeQualifier = "1";
                authorizationRequest.L2010cNm103SubscriberLastName = authorization.Member.LastName;
                authorizationRequest.L2010cNm104SubscriberFirstName = authorization.Member.FirstName;
                authorizationRequest.L2010cNm105SubscriberMiddleName = authorization.Member.MiddleName;
                authorizationRequest.L2010cNm108SubscriberIdentificationQualifier = "MI";
                authorizationRequest.L2010cNm109SubscriberId = authorization.Member.MemberId;

                if (authorization.Member.Address != null)
                {
                    authorizationRequest.L2010cN301SubscriberAddress1 = authorization.Member.Address.Address1;
                    authorizationRequest.L2010cN302SubscriberAddress2 = authorization.Member.Address.Address2;
                    authorizationRequest.L2010cN401SubscriberCity = authorization.Member.Address.City;
                    authorizationRequest.L2010cN402SubcriberState = authorization.Member.Address.State;
                    authorizationRequest.L2010cN403SubscriberZipcode = authorization.Member.Address.ZipCode;
                }

                if (authorization.Member.DOB != DateTime.MinValue)
                {
                    authorizationRequest.L2010cDmg01SubscriberBirthDateQualifier = "D8";
                    authorizationRequest.L2010cDmg02SubscriberBirthDate = CommonUtil.fn_ConvertEDIDateFormat(authorization.Member.DOB);
                    authorizationRequest.L2010cDmg03SubscriberGender = authorization.Member.Gender;

                    authorizationRequest.L2010cIns01SubscriberResponseCode = "Y";
                    authorizationRequest.L2010cIns02SubscriberRelationshipCode = "18";
                    authorizationRequest.L2010cIns08EmploymentStatusCode = "AO";
                }

                //
                AuthorizationSubscriberSupplementalIndentification(authorizationRequest, authorization.Member);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="member"></param>
        private static void AuthorizationSubscriberSupplementalIndentification(Mtab278AuthorizationRequest authorizationRequest, AuthorizationSubscriber member)
        {
            if (member != null)
            {
                authorizationRequest.L2010cRef011lGrouporPolicyNumberQualifier = CommonUtil.Fn_IsValuePresent(member.Policynumber) ? "1L" : string.Empty;
                authorizationRequest.L2010cRef021lGrouporPolicyNumber = member.Policynumber;

                authorizationRequest.L2010cRef013lBranchIdentifierQualifier = CommonUtil.Fn_IsValuePresent(member.BranchIdentification) ? "3L" : string.Empty;
                authorizationRequest.L2010cRef023lBranchIdentifier = member.BranchIdentification;

                authorizationRequest.L2010cRef016pGroupNumberQualifier = CommonUtil.Fn_IsValuePresent(member.GroupNumber) ? "6P" : string.Empty;
                authorizationRequest.L2010cRef026pGroupNumber = member.GroupNumber;

                authorizationRequest.L2010cRef01EjPatientAccountNumberQualifier = CommonUtil.Fn_IsValuePresent(member.AccountNumber) ? "EJ" : string.Empty;
                authorizationRequest.L2010cRef02EjPatientAccountNumber = member.AccountNumber;

                authorizationRequest.L2010cRef01F6HealthInsuranceClaimHicnumberQualifier = CommonUtil.Fn_IsValuePresent(member.HICNumber) ? "F6" : string.Empty;
                authorizationRequest.L2010cRef02F6HealthInsuranceClaimHicnumber = member.HICNumber;

                authorizationRequest.L2010cRef01HjIdentityCardNumberQualifier = CommonUtil.Fn_IsValuePresent(member.CardNumber) ? "HJ" : string.Empty;
                authorizationRequest.L2010cRef02HjIdentityCardNumber = member.CardNumber;

                authorizationRequest.L2010cRef01SySocialSecurityNumberQualifier = CommonUtil.Fn_IsValuePresent(member.SSN) ? "SY" : string.Empty;
                authorizationRequest.L2010cRef02SySocialSecurityNumber = member.SSN;

            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authorization"></param>
        private static void AuthPatient(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceEntity authorization)
        {
            if (authorization.Patient != null)
            {
                authorizationRequest.L2000dHl01HierarchicalIdnumber = "4";
                authorizationRequest.L2000dHl02HierarchicalParentIdnumber = "3";
                authorizationRequest.L2000dHl03HierarchicalLevelCode = "23";
                authorizationRequest.L2000dHl04HierarchicalChildCode = "1";

                authorizationRequest.L2010dNm101PatientIdentifierCode = "QC";
                authorizationRequest.L2010dNm102PatientTypeQualifier = "1";
                authorizationRequest.L2010dNm103PatientLastName = authorization.Patient.LastName;
                authorizationRequest.L2010dNm104PatientFirstName = authorization.Patient.FirstName;

                if (authorization.Patient.Address != null)
                {
                    authorizationRequest.L2010dN301PatientAddress1 = authorization.Patient.Address.Address1;
                    authorizationRequest.L2010dN302PatientAddress2 = authorization.Patient.Address.Address2;
                    authorizationRequest.L2010dN401PatientCity = authorization.Patient.Address.City;
                    authorizationRequest.L2010dN402PatientState = authorization.Patient.Address.State;
                    authorizationRequest.L2010dN403PatientZipCode = authorization.Patient.Address.ZipCode;
                }

                authorizationRequest.L2010dDmg01PatientDobdateQualifier = "D8";
                authorizationRequest.L2010dDmg02PatientDob = CommonUtil.fn_ConvertEDIDateFormat(authorization.Patient.DOB);
                authorizationRequest.L2010dDmg03PatientGender = authorization.Patient.Gender;

                authorizationRequest.L2010dIns01PatientIndicator = "N";
                authorizationRequest.L2010dIns02PatientRelationshipCode = authorization.Patient.RelationShip;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authorization"></param>
        private static void AuthDetail(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceEntity authorization)
        {
            if (authorization.AuthDetail != null)
            {
                if (authorization.Patient != null)
                {
                    authorizationRequest.L2000eHl01HierarchicalIdnumber = "5";
                    authorizationRequest.L2000eHl02HierarchicalParentIdnumber = "4";
                    authorizationRequest.L2000eHl03HierarchicalLevelCode = "EV";
                    authorizationRequest.L2000eHl04HierarchicalChildCode = "1";
                }
                else
                {

                    authorizationRequest.L2000eHl01HierarchicalIdnumber = "4";
                    authorizationRequest.L2000eHl02HierarchicalParentIdnumber = "3";
                    authorizationRequest.L2000eHl03HierarchicalLevelCode = "EV";
                    authorizationRequest.L2000eHl04HierarchicalChildCode = "1";
                }

                authorizationRequest.L2000eTrn01CurrentTransactionTraceNumbers = "1";
                authorizationRequest.L2000eTrn02PatientEventTraceNumber = authorization.AuthDetail.Tracenumber;
                authorizationRequest.L2000eTrn03TraceAssigningEntityIdentifier = authorization.AuthDetail.CompanyId;

                if (authorization.AuthDetail.PreviousAuth != null)
                {
                    authorizationRequest.L2000eRef01AuthorizationNumberQualifier = "BB";
                    authorizationRequest.L2000eRef02AuthorizationNumber = authorization.AuthDetail.PreviousAuth.PreviousReviewAuthNumber;

                    authorizationRequest.L2000eRef01AdministratorsReferenceNumberQualifier = "NT";
                    authorizationRequest.L2000eRef02AdministratorsReferenceNumber = authorization.AuthDetail.PreviousAuth.PreviousReviewAdministrativeReferenceNumber;
                }

                if (authorization.AuthDetail.Diagnosis != null)
                {
                    AuthDiagnosis(authorizationRequest, authorization.AuthDetail.Diagnosis);
                }

                // Add the Auth different Dates
                AuthDates(authorizationRequest, authorization.AuthDetail);

                // Add the Auth Certificate
                AuthCertification(authorizationRequest, authorization.AuthDetail);

                //
                AuthHealthCareServiceReviewInformation(authorizationRequest, authorization.AuthDetail.HealthCareServicesReviewInformation);

                //
                AuthHealthCareServiceDelivery(authorizationRequest, authorization.AuthDetail.HealthCareServices);

                // Add the Auth Institutional claim Code
                InstitutionalClaimCode(authorizationRequest, authorization.AuthDetail.InstitutionalClaimCode);

                // Add the Auth Ambulance Transport
                AmbulanceTransport(authorizationRequest, authorization.AuthDetail.AmbulanceInformation);

                //Add the Auth Oxygemtherapy
                Oxygemtherapy(authorizationRequest, authorization.AuthDetail.Oxygentherapy);

                //Add the Document/ Acctachment 
                Document(authorizationRequest, authorization.AuthDetail.Document);

                // auth Note
                authorizationRequest.L2000eMsg01FreeMessageText = authorization.AuthDetail.AuthNote;

                //Event Provider Detail
                EventProvider(authorizationRequest, authorization.AuthDetail.Physician);

                // Transport Details
                EvertTransport(authorizationRequest, authorization.AuthDetail.TransportInformation);

                // add Other Payer details
                OtherPayer(authorizationRequest, authorization.AuthDetail.OtherPayer);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="healthCareServicesReviewInformation"></param>
        private static void AuthHealthCareServiceReviewInformation(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetailHealthCareServiceReviewInformation healthCareServicesReviewInformation)
        {
            if (healthCareServicesReviewInformation != null)
            {

                authorizationRequest.L2000eUm01RequestCategoryCode = healthCareServicesReviewInformation.HealthServicesReviewCode;
                authorizationRequest.L2000eUm02CertificationTypeCode = "I";
                authorizationRequest.L2000eUm03ServiceTypeCode = healthCareServicesReviewInformation.ServiceTypeCode;
                if (CommonUtil.Fn_IsValuePresent(healthCareServicesReviewInformation.PlaceOfServicecode))
                {
                    authorizationRequest.L2000eUm041PlaceOfServiceCode = healthCareServicesReviewInformation.PlaceOfServicecode;
                    authorizationRequest.L2000eUm042PlaceofServiceQualifier = "B";
                    authorizationRequest.L2000eUm043ClaimFrequencyCode = healthCareServicesReviewInformation.ClaimFrequenceCode;
                }
                authorizationRequest.L2000eUm09ReleaseofInformationCode = "Y";
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequestServices"></param>
        /// <param name="healthCareServicesReviewInformation"></param>
        private static void AuthHealthCareServiceReviewInformation(Mtab278AuthorizationRequestService authorizationRequestServices, AuthorizationEventDetailHealthCareServiceReviewInformation healthCareServicesReviewInformation)
        {
            if (healthCareServicesReviewInformation != null)
            {
                authorizationRequestServices.L2000fUm01RequestCategoryCode = healthCareServicesReviewInformation.HealthServicesReviewCode;
                authorizationRequestServices.L2000fUm02CertificationTypeCode = "I";
                authorizationRequestServices.L2000fUm03ServiceTypeCode = healthCareServicesReviewInformation.ServiceTypeCode;

                if (CommonUtil.Fn_IsValuePresent(healthCareServicesReviewInformation.PlaceOfServicecode))
                {
                    authorizationRequestServices.L2000fUm04FacilityCodeQualifier = "B";
                    authorizationRequestServices.L2000fUm04FacilityCodeValue = healthCareServicesReviewInformation.PlaceOfServicecode;
                }
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="healthCareServices"></param>
        private static void AuthHealthCareServiceDelivery(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetailHealthCareServiceDelivery healthCareServices)
        {
            if (healthCareServices != null)
            {
                authorizationRequest.L2000eHsd01QuantityQualifier = healthCareServices.QuantityQualifier;
                authorizationRequest.L2000eHsd02Quantity = healthCareServices.Quantity;
                authorizationRequest.L2000eHsd03UnitorBasisforMeasurementCode = healthCareServices.MeasurementCode;
                authorizationRequest.L2000eHsd04SampleSelectionModulus = healthCareServices.SelectionModulus;
                authorizationRequest.L2000eHsd05TimePeriodQualifier = healthCareServices.TimePeriodQualifier;
                authorizationRequest.L2000eHsd06NumberofPeriods = healthCareServices.NumberofPeriods;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="otherPayer"></param>
        private static void OtherPayer(Mtab278AuthorizationRequest authorizationRequest, AuthorizationOtherPayer otherPayer)
        {
            if (otherPayer != null)
            {
                authorizationRequest.L2010ecNm101UmoidentifierCode = "CA";
                authorizationRequest.L2010ecNm102UmotypeQualifier = "2";
                authorizationRequest.L2010ecNm103Umoname = otherPayer.Name;
                authorizationRequest.L2010ecDtp01Umodenialdatequalifier = "598";
                authorizationRequest.L2010ecDtp02UmodenialdatetypeFormate = "D8";
                authorizationRequest.L2010ecDtp03Umodenialdate = CommonUtil.fn_ConvertEDIDateFormat(otherPayer.DenialDate);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="transportInformation"></param>
        private static void EvertTransport(Mtab278AuthorizationRequest authorizationRequest, AuthorizationTransport transportInformation)
        {
            if (transportInformation != null)
            {
                authorizationRequest.L2010ebNm101TransportIdentifierCode = "PW";
                authorizationRequest.L2010ebNm102TransportTypeQualifier = "2";
                authorizationRequest.L2010ebNm103TransportCompanyName = transportInformation.LocationName;

                if (transportInformation.Address != null)
                {
                    authorizationRequest.L2010ebN301TransportcompanyAddress1 = transportInformation.Address.Address1;
                    authorizationRequest.L2010ebN302TransportCompanyAddress2 = transportInformation.Address.Address2;
                    authorizationRequest.L2010ebN401TransportCompanyCity = transportInformation.Address.City;
                    authorizationRequest.L2010ebN402TransportCompanyState = transportInformation.Address.State;
                    authorizationRequest.L2010ebN403TransportCompanyZipCode = transportInformation.Address.ZipCode;
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="physician"></param>
        private static void EventProvider(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceProvider physician)
        {
            if (physician != null)
            {
                authorizationRequest.L2010eaNm101ProviderIdentificationCode = physician.PhysicianTypeCode;
                authorizationRequest.L2010eaNm102ProviderTypeQualifier = "1";
                authorizationRequest.L2010eaNm103ProviderLastName = physician.LastName;
                authorizationRequest.L2010eaNm104ProviderFirstName = physician.FirstName;
                authorizationRequest.L2010eaNm105ProviderMiddleName = physician.MiddleName;

                if (CommonUtil.Fn_IsValuePresent(physician.NPI))
                {
                    authorizationRequest.L2010eaNm108ProviderIdentificationCodeQualifier = "XX";
                    authorizationRequest.L2010eaNm109ProviderNpi = physician.NPI;
                }
                else if (CommonUtil.Fn_IsValuePresent(physician.SSN))
                {
                    authorizationRequest.L2010eaNm108ProviderIdentificationCodeQualifier = "34";
                    authorizationRequest.L2010eaNm109ProviderNpi = physician.SSN;
                }
                else if (CommonUtil.Fn_IsValuePresent(physician.EmployerIdentificationNumber))
                {
                    authorizationRequest.L2010eaNm108ProviderIdentificationCodeQualifier = "24";
                    authorizationRequest.L2010eaNm109ProviderNpi = physician.EmployerIdentificationNumber;
                }
                else if (CommonUtil.Fn_IsValuePresent(physician.ETIN))
                {
                    authorizationRequest.L2010eaNm108ProviderIdentificationCodeQualifier = "46";
                    authorizationRequest.L2010eaNm109ProviderNpi = physician.ETIN;
                }

                if (physician.Address != null)
                {
                    authorizationRequest.L2010eaN301ProviderAddress1 = physician.Address.Address1;
                    authorizationRequest.L2010eaN302ProviderAddress2 = physician.Address.Address2;
                    authorizationRequest.L2010eaN401ProviderCity = physician.Address.City;
                    authorizationRequest.L2010eaN402ProviderState = physician.Address.State;
                    authorizationRequest.L2010eaN403ProviderZipCode = physician.Address.ZipCode;
                }

                if (CommonUtil.Fn_IsValuePresent(physician.TaxonomyCode))
                {
                    authorizationRequest.L2010eaPrv01ProviderCode = "PE";
                    authorizationRequest.L2010eaPrv02HealthCareProviderTaxonomyCode = "PXC";
                    authorizationRequest.L2010eaPrv03ProviderTaxonomyCode = physician.TaxonomyCode;
                }

                if (physician.Communication != null)
                {
                    authorizationRequest.L2010eaPer01ContactFunctionCode = "IC";
                    authorizationRequest.L2010eaPer02Name = physician.Communication.ContactPersonName;

                    if (CommonUtil.Fn_IsValuePresent(physician.Communication.TelephoneNumber))
                    {
                        authorizationRequest.L2010eaPer03ElectronicMail = "TE";
                        authorizationRequest.L2010eaPer04CommunicationNumber = physician.Communication.TelephoneNumber;
                    }
                    if (CommonUtil.Fn_IsValuePresent(physician.Communication.FxNumber))
                    {
                        if (CommonUtil.Fn_IsValuePresent(physician.Communication.TelephoneNumber))
                        {
                            authorizationRequest.L2010eaPer05Facsimile = "FX";
                            authorizationRequest.L2010eaPer06CommunicationNumber = physician.Communication.FxNumber;
                        }
                        else
                        {
                            authorizationRequest.L2010eaPer03ElectronicMail = "FX";
                            authorizationRequest.L2010eaPer04CommunicationNumber = physician.Communication.FxNumber;
                        }
                    }

                    if (CommonUtil.Fn_IsValuePresent(physician.Communication.EmailID))
                    {
                        if (CommonUtil.Fn_IsNull_LenZero(authorizationRequest.L2010bPer04EmCommunicationNumber))
                        {
                            authorizationRequest.L2010eaPer03ElectronicMail = "EM";
                            authorizationRequest.L2010eaPer04CommunicationNumber = physician.Communication.EmailID;
                        }
                        else if (CommonUtil.Fn_IsNull_LenZero(authorizationRequest.L2010bPer06FxCommunicationNumber))
                        {
                            authorizationRequest.L2010eaPer05Facsimile = "EM";
                            authorizationRequest.L2010bPer06FxCommunicationNumber = physician.Communication.EmailID;
                        }
                        else
                        {
                            authorizationRequest.L2010eaPer07Telephone = "EM";
                            authorizationRequest.L2010bPer08TeCommunicationNumber = physician.Communication.EmailID;
                        }
                    }

                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authDetail"></param>
        private static void AuthDates(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetail authDetail)
        {
            if (authDetail.AccidentDate != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01AccidentDateQualifier = "439";
                authorizationRequest.L2000eDtp02AccidentDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03Accident = CommonUtil.fn_ConvertEDIDateFormat(authDetail.AccidentDate);
            }

            if (authDetail.LastMenstrualPeriod != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01LastMenstrualPeriodDateQualifier = "484";
                authorizationRequest.L2000eDtp02LastMenstrualPeriodDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03LastMenstrualPeriod = CommonUtil.fn_ConvertEDIDateFormat(authDetail.LastMenstrualPeriod);
            }

            if (authDetail.EstimatedDateOfBirth != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01EstimatedDateofBirthDateQualifier = "ABC";
                authorizationRequest.L2000eDtp02EstimatedDateofBirthDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03EstimatedDateofBirth = CommonUtil.fn_ConvertEDIDateFormat(authDetail.EstimatedDateOfBirth);
            }

            if (authDetail.IllnessDate != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01IllnessDateQualifier = "431";
                authorizationRequest.L2000eDtp02IllnessDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03Illness = CommonUtil.fn_ConvertEDIDateFormat(authDetail.IllnessDate);
            }

            if (authDetail.EventDate != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01EventDateQualifier = "AAH";
                authorizationRequest.L2000eDtp02EventDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03EventDate = CommonUtil.fn_ConvertEDIDateFormat(authDetail.EventDate);
            }

            if (authDetail.AdmissionDate != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01AdmissionDateQualifier = "435";
                authorizationRequest.L2000eDtp02AdmissionDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03AdmissionDate = CommonUtil.fn_ConvertEDIDateFormat(authDetail.AdmissionDate);
            }

            if (authDetail.DischargeDate != DateTime.MinValue)
            {
                authorizationRequest.L2000eDtp01DischargeDateQualifier = "096";
                authorizationRequest.L2000eDtp02DischargeDateFormatQualifier = "D8";
                authorizationRequest.L2000eDtp03DischargeDate = CommonUtil.fn_ConvertEDIDateFormat(authDetail.DischargeDate);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="document"></param>
        private static void Document(Mtab278AuthorizationRequest authorizationRequest, AuthorizationServiceDocument document)
        {
            if (document != null)
            {
                authorizationRequest.L2000ePwk01AttachmentReportTypeCode = "OB";
                authorizationRequest.L2000ePwk02ReportTransmissionCode = "BM";
                authorizationRequest.L2000ePwk05IdentificationCodeQualifier = "AC";
                authorizationRequest.L2000ePwk06IdentificationCode = document.AttachmentControlNumber;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="oxygentherapy"></param>
        private static void Oxygemtherapy(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetailOxygemtherapy oxygentherapy)
        {
            if (oxygentherapy != null)
            {
                authorizationRequest.L2000eCr503OxygenEquipmentTypeCode = "D";
                authorizationRequest.L2000eCr503OxygenEquipmentTypeCode = oxygentherapy.OxygenEquipCode;
                authorizationRequest.L2000eCr506OxygenFlowRate = oxygentherapy.Quantity;
                authorizationRequest.L2000eCr5017OxygenDeliverySystemCode = oxygentherapy.Oxygensyscode;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="ambulanceInformation"></param>
        private static void AmbulanceTransport(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetailAmbulanceTransport ambulanceInformation)
        {
            if (ambulanceInformation != null)
            {
                authorizationRequest.L2000eCl101UnitorBasisforMeasurementCode = ambulanceInformation.MeasurementCode;
                authorizationRequest.L2000eCl102Weight = Convert.ToString(ambulanceInformation.Weight);
                authorizationRequest.L2000eCl103AmbulanceTransportCode = ambulanceInformation.AmbulanceTransportCode;
                authorizationRequest.L2000eCl104AmbulanceTransportReasonCode = ambulanceInformation.TransportReasonCode;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="institutionalClaimCode"></param>
        private static void InstitutionalClaimCode(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetailInstitutionalClaimCode institutionalClaimCode)
        {
            if (institutionalClaimCode != null)
            {
                authorizationRequest.L2000eCl101AdmissionTypeCode = institutionalClaimCode.AdmissionTypeCpde;
                authorizationRequest.L2000eCl102AdmissionSourceCode = institutionalClaimCode.AdmissionSourceCode;
                authorizationRequest.L2000eCl103PatientStatusCode = institutionalClaimCode.PatientStatusCode;
                authorizationRequest.L2000eCl104NursingHomeResidentialStatusCode = institutionalClaimCode.NurseHomeStatusCode;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="authDetail"></param>
        private static void AuthCertification(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetail authDetail)
        {
            if (authDetail.AmbulanceCertification != null)
            {
                authorizationRequest.L2000eCrc01AmbulanceCertification = "07";
                authorizationRequest.L2000eCrc02AmbulanceCertificationConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03AmbulanceConditionCode = authDetail.AmbulanceCertification.ConditionCode1;
            }

            if (authDetail.ChiropracticCertification != null)
            {
                authorizationRequest.L2000eCrc01ChiropracticCertification = "08";
                authorizationRequest.L2000eCrc02ChiropracticCertificationConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03ChiropracticConditionCode = authDetail.ChiropracticCertification.ConditionCode1;
            }

            if (authDetail.DurableMedicalCertification != null)
            {
                authorizationRequest.L2000eCrc01DurableMedicalEquipmentCertification = "09";
                authorizationRequest.L2000eCrc02DurableMedicalEquipmentCertificationConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03DurableMedicalEquipmentConditionCode = authDetail.DurableMedicalCertification.ConditionCode1;
            }

            if (authDetail.OxygenTherapyCertification != null)
            {
                authorizationRequest.L2000eCrc01OxygenTherapyCertification = "11";
                authorizationRequest.L2000eCrc02OxygenTherapyCertificationConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03OxygenTherapyCertificationConditionCode = authDetail.OxygenTherapyCertification.ConditionCode1;
            }

            if (authDetail.FunctionalLimitation != null)
            {
                authorizationRequest.L2000eCrc01FunctionalLimitations = "11";
                authorizationRequest.L2000eCrc02FunctionalLimitationsConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03FunctionalLimitationsConditionCode = authDetail.FunctionalLimitation.ConditionCode1;
            }

            if (authDetail.ActivitiesPermitted != null)
            {
                authorizationRequest.L2000eCrc01ActivitiesPermitted = "11";
                authorizationRequest.L2000eCrc02ActivitiesPermittedConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03ActivitiesPermittedConditionCode = authDetail.ActivitiesPermitted.ConditionCode1;
            }

            if (authDetail.MentalStatus != null)
            {
                authorizationRequest.L2000eCrc01MentalStatus = "11";
                authorizationRequest.L2000eCrc02MentalStatusConditionIndicator = "Y";
                authorizationRequest.L2000eCrc03MentalStatusConditionCode = authDetail.MentalStatus.ConditionCode1;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequest"></param>
        /// <param name="Diagnosis"></param>
        private static void AuthDiagnosis(Mtab278AuthorizationRequest authorizationRequest, AuthorizationEventDetailDiagnosis Diagnosis)
        {
            if (Diagnosis.Diagnosis1 != null)
            {
                authorizationRequest.L2000eHi01DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi01DiagnosisCode = Diagnosis.Diagnosis1.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi01DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis1.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi01DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis1.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis2 != null)
            {
                authorizationRequest.L2000eHi02DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi02DiagnosisCode = Diagnosis.Diagnosis2.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi02DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis2.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi02DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis2.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis3 != null)
            {
                authorizationRequest.L2000eHi03DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi03DiagnosisCode = Diagnosis.Diagnosis3.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi03DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis3.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi03DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis3.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis4 != null)
            {
                authorizationRequest.L2000eHi04DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi04DiagnosisCode = Diagnosis.Diagnosis4.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi04DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis4.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi04DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis4.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis5 != null)
            {
                authorizationRequest.L2000eHi05DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi05DiagnosisCode = Diagnosis.Diagnosis5.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi05DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis5.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi05DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis5.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis6 != null)
            {
                authorizationRequest.L2000eHi06DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi06DiagnosisCode = Diagnosis.Diagnosis6.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi06DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis6.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi06DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis6.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis7 != null)
            {
                authorizationRequest.L2000eHi07DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi07DiagnosisCode = Diagnosis.Diagnosis7.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi07DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis7.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi07DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis7.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis8 != null)
            {
                authorizationRequest.L2000eHi08DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi08DiagnosisCode = Diagnosis.Diagnosis8.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi08DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis8.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi08DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis8.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis9 != null)
            {
                authorizationRequest.L2000eHi09DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi09DiagnosisCode = Diagnosis.Diagnosis9.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi09DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis9.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi09DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis9.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis10 != null)
            {
                authorizationRequest.L2000eHi010DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi010DiagnosisCode = Diagnosis.Diagnosis10.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi010DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis10.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi010DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis10.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis11 != null)
            {
                authorizationRequest.L2000eHi011DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi011DiagnosisCode = Diagnosis.Diagnosis11.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi011DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis11.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi011DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis11.DiagnosisDate);
            }

            if (Diagnosis.Diagnosis12 != null)
            {
                authorizationRequest.L2000eHi012DiagnosisTypeCode = "BF";
                authorizationRequest.L2000eHi012DiagnosisCode = Diagnosis.Diagnosis12.DiagnosisCode.Replace(".", "");
                authorizationRequest.L2000eHi012DiagnosisCodeDateFormat = CommonUtil.Fn_IsValuePresent(Diagnosis.Diagnosis12.DiagnosisDate) ? "D8" : string.Empty;
                authorizationRequest.L2000eHi012DiagnosisCodeDate = CommonUtil.fn_ConvertEDIDateFormat(Diagnosis.Diagnosis12.DiagnosisDate);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationServicePhysician"></param>
        /// <returns></returns>
        public static Mtab278AuthorizationPhysician ToConvert(this AuthorizationServiceProvider authorizationServicePhysician)
        {
            var authorizationRequestPhysician = new Mtab278AuthorizationPhysician();
            return authorizationRequestPhysician;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationService"></param>
        /// <returns></returns>
        public static Mtab278AuthorizationRequestService ToConvert(this AuthorizationService authorizationService)
        {
            var authorizationRequestServices = new Mtab278AuthorizationRequestService();

            authorizationRequestServices.L2000fHl03HierarchicalLevelCode = "SS";
            authorizationRequestServices.L2000fHl04HierarchicalChildCode = "0";

            if (CommonUtil.Fn_IsValuePresent(authorizationService.ServiceId))
            {
                authorizationRequestServices.L2000fTrn01CurrentTransactionTraceNumbers = "1";
                authorizationRequestServices.L2000fTrn02ReferenceIdentification = authorizationService.ServiceId;
                authorizationRequestServices.L2000fTrn03OriginatingCompanyIdentifier = authorizationService.CompanyId;
            }

            if (authorizationService.PreviousAuth != null)
            {
                authorizationRequestServices.L2000fRef01AuthorizationNumber = CommonUtil.Fn_IsValuePresent(authorizationService.PreviousAuth.PreviousReviewAuthNumber) ? "BB" : string.Empty;
                authorizationRequestServices.L2000fRef02PreviousReviewAuthorizationNumber = authorizationService.PreviousAuth.PreviousReviewAuthNumber;
                authorizationRequestServices.L2000fRef01AdministratorsReferenceNumber = CommonUtil.Fn_IsValuePresent(authorizationService.PreviousAuth.PreviousReviewAdministrativeReferenceNumber) ? "NT" : string.Empty;
                authorizationRequestServices.L2000fRef02PreviousAdministrativeReferenceNumber = authorizationService.PreviousAuth.PreviousReviewAdministrativeReferenceNumber;
            }

            if (authorizationService.ServiceDate != DateTime.MinValue)
            {
                authorizationRequestServices.L2000fDtp01ServiceDateQualifier = "472";
                authorizationRequestServices.L2000fDtp02ServiceDateTyepidentifier = "D8";
                authorizationRequestServices.L2000fDtp03ServiceDate = CommonUtil.fn_ConvertEDIDateFormat(authorizationService.ServiceDate);
            }

            //
            AuthProfessionalService(authorizationRequestServices, authorizationService.ProfessionalService);

            //
            AuthInstitutionalService(authorizationRequestServices, authorizationService.InstitutionalService);

            //
            AuthServiceProvider(authorizationRequestServices, authorizationService.Physician);

            //
            AuthHealthCareServiceReviewInformation(authorizationRequestServices, authorizationService.HealthCareServicesReviewInformation);

            //
            AuthServiceDocument(authorizationRequestServices, authorizationService.ServiceDocuemnt);

            //
            authorizationRequestServices.L2000fMsg01MessageText = authorizationService.Note;



            return authorizationRequestServices;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequestServices"></param>
        /// <param name="serviceDocuemnt"></param>
        private static void AuthServiceDocument(Mtab278AuthorizationRequestService authorizationRequestServices, AuthorizationServiceDocument serviceDocuemnt)
        {
            if (serviceDocuemnt != null)
            {
                authorizationRequestServices.L2000fPwk01ReportTypeCode = "OB";
                authorizationRequestServices.L2000fPwk02ReportTransmissionCode = serviceDocuemnt.TransmissionCode;
                authorizationRequestServices.L2000fPwk05ReportCopiesNeeded = "AC";
                authorizationRequestServices.L2000fPwk06EntityIdentifierCode = serviceDocuemnt.AttachmentControlNumber;
                authorizationRequestServices.L2000fPwk07IdentificationCodeQualifier = serviceDocuemnt.Description;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequestServices"></param>
        /// <param name="physician"></param>
        private static void AuthServiceProvider(Mtab278AuthorizationRequestService authorizationRequestServices, AuthorizationServiceProvider physician)
        {
            if (physician != null)
            {
                authorizationRequestServices.L2010fNm101ProviderIdentifierCode = physician.PhysicianTypeCode;
                authorizationRequestServices.L2010fNm102ProviderTypeQualifier = "1";
                authorizationRequestServices.L2010fNm103ProviderLastName = physician.LastName;
                authorizationRequestServices.L2010fNm104ProviderFirstName = physician.FirstName;
                authorizationRequestServices.L2010fNm105ProviderMiddleName = physician.MiddleName;

                if (CommonUtil.Fn_IsValuePresent(physician.NPI))
                {
                    authorizationRequestServices.L2010fNm108Provideridentifierqualifier = "XX";
                    authorizationRequestServices.L2010fNm109ProviderNpi = physician.NPI;
                }
                else if (CommonUtil.Fn_IsValuePresent(physician.SSN))
                {
                    authorizationRequestServices.L2010fNm108Provideridentifierqualifier = "34";
                    authorizationRequestServices.L2010fNm109ProviderNpi = physician.SSN;
                }
                else if (CommonUtil.Fn_IsValuePresent(physician.EmployerIdentificationNumber))
                {
                    authorizationRequestServices.L2010fNm108Provideridentifierqualifier = "24";
                    authorizationRequestServices.L2010fNm109ProviderNpi = physician.EmployerIdentificationNumber;
                }
                else if (CommonUtil.Fn_IsValuePresent(physician.ETIN))
                {
                    authorizationRequestServices.L2010fNm108Provideridentifierqualifier = "46";
                    authorizationRequestServices.L2010fNm109ProviderNpi = physician.ETIN;
                }

                if (physician.Address != null)
                {
                    authorizationRequestServices.L2010fN301Provideraddress1 = physician.Address.Address1;
                    authorizationRequestServices.L2010fN302Provideraddress2 = physician.Address.Address2;
                    authorizationRequestServices.L2010fN401ProviderCity = physician.Address.City;
                    authorizationRequestServices.L2010fN402ProviderState = physician.Address.State;
                    authorizationRequestServices.L2010fN403ProviderZipCode = physician.Address.ZipCode;
                }

                if (CommonUtil.Fn_IsValuePresent(physician.TaxonomyCode))
                {
                    authorizationRequestServices.L2010fPrv01ProviderCode = "PE";
                    authorizationRequestServices.L2010fPrv02HealthCareProviderTaxonomyCode = "PXC";
                    authorizationRequestServices.L2010fPrv03ProviderTaxonomyCode = physician.TaxonomyCode;
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequestServices"></param>
        /// <param name="institutionalService"></param>
        private static void AuthInstitutionalService(Mtab278AuthorizationRequestService authorizationRequestServices, AuthorizationServiceInstitutionalService institutionalService)
        {
            if (institutionalService != null)
            {
                authorizationRequestServices.L2000fSv201RevenuCode = institutionalService.RevenueCode;
                authorizationRequestServices.L2000fSv202ServiceIdqualifier = CommonUtil.Fn_IsValuePresent(institutionalService.ProcedureCode) ? "HC" : string.Empty;
                authorizationRequestServices.L2000fSv202ServiceId = institutionalService.ProcedureCode;
                authorizationRequestServices.L2000fSv202Description = institutionalService.Description;

                if (institutionalService.Modifier != null)
                {
                    authorizationRequestServices.L2000fSv202ProcedureModifier1 = institutionalService.Modifier.Modifier1;
                    authorizationRequestServices.L2000fSv202ProcedureModifier2 = institutionalService.Modifier.Modifier2;
                    authorizationRequestServices.L2000fSv202ProcedureModifier3 = institutionalService.Modifier.Modifier3;
                    authorizationRequestServices.L2000fSv202ProcedureModifier4 = institutionalService.Modifier.Modifier4;
                }

                authorizationRequestServices.L2000fSv203UnitorBasisforMeasurementCode = institutionalService.ServiceLineChange;
                authorizationRequestServices.L2000fSv204ServiceLineAmount = institutionalService.MeasurementCode;
                authorizationRequestServices.L2000fSv205ServiceUnitCount = institutionalService.Quantity;
                authorizationRequestServices.L2000fSv206UnitRate = institutionalService.UnitRate;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authorizationRequestServices"></param>
        /// <param name="professionalService"></param>
        private static void AuthProfessionalService(Mtab278AuthorizationRequestService authorizationRequestServices, AuthorizationServiceProfessionalService professionalService)
        {
            if (professionalService != null)
            {
                authorizationRequestServices.L2000fSv101ProductServiceIdqualifier = "HC";
                authorizationRequestServices.L2000fSv101ServiceId = professionalService.ProcedureCode;
                if (professionalService.Modifier != null)
                {
                    authorizationRequestServices.L2000fSv101ProcedureModifier1 = professionalService.Modifier.Modifier1;
                    authorizationRequestServices.L2000fSv101ProcedureModifier2 = professionalService.Modifier.Modifier2;
                    authorizationRequestServices.L2000fSv101ProcedureModifier3 = professionalService.Modifier.Modifier3;
                    authorizationRequestServices.L2000fSv101ProcedureModifier4 = professionalService.Modifier.Modifier4;
                }
                authorizationRequestServices.L2000fSv102ServiceLineAmount = professionalService.ServiceLineChange;

                authorizationRequestServices.L2000fSv103UnitorBasisforMeasurementCode = professionalService.Quantity == null ? string.Empty : "UN";
                authorizationRequestServices.L2000fSv104ServiceUnitCount = professionalService.Quantity;

                if (professionalService.DiagnosisCodePointer != null)
                {
                    authorizationRequestServices.L2000fSv107DiagnosisCodePointer1 = professionalService.DiagnosisCodePointer.Pointer1;
                    authorizationRequestServices.L2000fSv107DiagnosisCodePointer2 = professionalService.DiagnosisCodePointer.Pointer2;
                    authorizationRequestServices.L2000fSv107DiagnosisCodePointer3 = professionalService.DiagnosisCodePointer.Pointer3;
                    authorizationRequestServices.L2000fSv107DiagnosisCodePointer4 = professionalService.DiagnosisCodePointer.Pointer4;
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mVWMtabx12TradingPartnersummary"></param>
        /// <returns></returns>
        //public static MtabMTradingPartnerMaster ToTradingPartnerMaster(this vwMtabx12TradingPartnerSummary mVWMtabx12TradingPartnersummary)
        //{
        //    return new MtabMTradingPartnerMaster
        //    {
        //        RecordStatus = (int)RecordStatus.Active,
        //        ClientId = mVWMtabx12TradingPartnersummary.Client_id,
        //        CompanyId = mVWMtabx12TradingPartnersummary.Company_Id,
        //        CreatedDate = DateTime.Now,
        //        EffectiveDate = DateTime.Now,
        //        UpdateDate = DateTime.Now

        //    };
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="TP"></param>
        /// <returns></returns>
        //public static MtabMTradingPartnerReqModule ToTradingPartnerReqModule(this vwMtabx12TradingPartnerSummary TP)
        //{
        //    return new MtabMTradingPartnerReqModule
        //    {
        //        RecordStatus = (int)RecordStatus.Active,
        //        Chid = TP.CHid,
        //        ClaimFilingIndicator = TP.ClaimFilingIndicator,
        //        EffectiveDate = DateTime.Now,
        //        ElementSeparator = "*",
        //        EnrolledDate = DateTime.Now,
        //        FileNameId = TP.FileNameId,
        //        Gs02AppSenderCode = TP.gs02_app_sender_code,
        //        Gs03AppReceiverCode = TP.gs03_app_receiver_code,
        //        Isa01AuthInfoQual = TP.isa01_auth_info_qual,
        //        Isa02AuthInfo = TP.isa02_auth_info,
        //        Isa03SecurityInfoQual = TP.isa03_security_info_qual,
        //        Isa04SecurityInfo = TP.isa04_security_info,
        //        Isa05SenderIdQual = TP.isa05_sender_id_qual,
        //        Isa06SenderIdLive = TP.isa06_sender_id_live,
        //        Isa07ReceiverIdQual = TP.isa07_receiver_id_qual,
        //        Isa08ReceiverId = TP.isa08_receiver_id,
        //        Isa14AckRequested = TP.isa14_ack_requested.ToUpper().Equals("TRUE") ? "1" : "0",
        //        Isa15UsageIndicator = TP.isa15_usage_indicator,
        //        Isa16ComponentElementSeperator = TP.isa16_component_element_seperator,
        //        UpdateDate = DateTime.Now,
        //        ModuleName = TP.Module_Name,
        //        Nm109Receiver1000b = TP.Nm109_receiver_1000B,
        //        Nm109Submitter1000a = TP.Nm109_submitter_1000A,
        //        Status = "VST03"
        //    };
        //}
    }
}
