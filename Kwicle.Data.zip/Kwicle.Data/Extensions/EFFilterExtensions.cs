﻿using Kwicle.Core.Common;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Reflection;

namespace Kwicle.Data.Extensions
{
    public static class EFFilterExtensions
    {
        #region CoreEntity

        public static void SetSoftDeleteCoreEntityFilter(this ModelBuilder modelBuilder, Type entityType)
        {
            SetSoftDeleteCoreEntityFilterMethod.MakeGenericMethod(entityType).Invoke(null, new object[] { modelBuilder });
        }

        static readonly MethodInfo SetSoftDeleteCoreEntityFilterMethod = typeof(EFFilterExtensions)
               .GetMethods(BindingFlags.Public | BindingFlags.Static)
               .Single(t => t.IsGenericMethod && t.Name == "SetSoftDeleteCoreEntityFilter");

        public static void SetSoftDeleteCoreEntityFilter<TEntity>(this ModelBuilder modelBuilder) where TEntity : CoreEntity
        {
            modelBuilder.Entity<TEntity>().HasQueryFilter(x => x.RecordStatus != (byte)RecordStatus.Deleted);
        }

        #endregion

        #region UserCoreEntity

        public static void SetSoftDeleteUserCoreEntityFilter(this ModelBuilder modelBuilder, Type entityType)
        {
            SetSoftDeleteUserCoreEntityFilterMethod.MakeGenericMethod(entityType).Invoke(null, new object[] { modelBuilder });
        }

        static readonly MethodInfo SetSoftDeleteUserCoreEntityFilterMethod = typeof(EFFilterExtensions)
               .GetMethods(BindingFlags.Public | BindingFlags.Static)
               .Single(t => t.IsGenericMethod && t.Name == "SetSoftDeleteUserCoreEntityFilter");

        public static void SetSoftDeleteUserCoreEntityFilter<TEntity>(this ModelBuilder modelBuilder) where TEntity : UserCoreEntity
        {
            modelBuilder.Entity<TEntity>().HasQueryFilter(x => x.RecordStatus != (byte)RecordStatus.Deleted);
        }

        #endregion
    }
}
