﻿using Kwicle.Core.CustomModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Models
{
    public class ErrorMessageModel
    {
        #region Ctor
        public ErrorMessageModel()
        {
            this._isValid = true;
            this._ErrorMessages = new List<KeyVal<string,string>>();
        }
        #endregion

        #region Variables
        private bool _isValid;
        private List<KeyVal<string, string>> _ErrorMessages;
        #endregion

        #region Properties        
        public bool IsValid { get { return _isValid; } }
        public List<KeyVal<string,string>> ErrorMessages { get { return _ErrorMessages; } }
        #endregion

        #region Methods
        public void AddErrorMessage(string key, string message)
        {
            this._ErrorMessages.Add(new KeyVal<string, string>() { Value = message, Key = key });
            this._isValid = false;
        }
        #endregion


    }
}
