﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Models
{
    public class ClinicalCodeCheckModel
    {
        public int ID { get; set; }
        public int  ClinicalCodeTypeID { get; set; }
        public string Code { get; set; }
        public byte RecordStatus { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TermDate { get; set; }
        public int SequenceNumber { get; set; }
    }
    public class ExistsCommonClinicalCodeUsed
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
    }
}
