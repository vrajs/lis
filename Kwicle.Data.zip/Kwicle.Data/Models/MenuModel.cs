﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kwicle.Data.Models
{
    public class MenuModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Icon { get; set; }

        public string Status { get; set; }
        public string ColorCode { get; set; }
        public string ClaimValue { get; set; }
        public string Type { get; set; }

        public string Route { get; set; }
        public List<MenuModel> Children { get; set; }
    }
}
