﻿using Kwicle.Core.CustomModel.Common;
using Kwicle.Core.CustomModel.Configuration;
using Kwicle.Core.CustomModel.Member;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Core.Views;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Kwicle.Data
{
    public class KwicleViewContext : DbContext
    {
        public KwicleViewContext(DbContextOptions<KwicleViewContext> options)
          : base(options)
        {
        }

        public DbSet<vwCapitation> GetCapitations { get; set; }
        public DbSet<vwTerm> vwTerm { get; set; }
        public DbSet<vwPlanCapitation> GetPlanCapitations { get; set; }
        public DbSet<vwMembershipCapitation> GetMembershipCapitations { get; set; }
        public DbSet<vwClaimList> GetClaimList { get; set; }
        public DbSet<vwMemberLookup> GetMemberLookups { get; set; }
        public DbSet<vwProviderLookup> GetProviderLookups { get; set; }
        public DbSet<vwFacilityLookup> GetFacilityLookups { get; set; }
        public DbSet<vwLocation> GetLocations { get; set; }
        public DbSet<vwProviderList> GetProviders { get; set; }
        public DbSet<vwCountries> GetCountries { get; set; }
        public DbSet<vwCities> GetCities { get; set; }
        public DbSet<vwIPA> GetIPAs { get; set; }
        public DbSet<vwClaimLoockup> GetClaimLoockups { get; set; }
        public DbSet<vwICDCode> GetICDCode { get; set; }
        public DbSet<vwCPTCode> GetCPTCode { get; set; }

        public DbSet<vwContract> GetContracts { get; set; }
        public DbSet<GetStatesModel> GetStates { get; set; }
        public DbSet<GetCountiesModel> GetCounties { get; set; }
        public DbSet<vwZipCodeDetail> vwZipCodeDetail { get; set; }

        public DbSet<GetCommonCodeConfigurationModel> GetCommonCodeConfigurations { get; set; }
        public DbSet<vwMemberList> vwMemberList { get; set; }

        public DbSet<vwProviderRelation> vwProviderRelation { get; set; }
        public DbSet<vwClaimServiceContractTermFeeschedule> vwClaimServiceContractTermFeeschedule { get; set; }
        public DbSet<vwClaimBenefit> vwClaimBenefits { get; set; }
        public DbSet<vwClaimRefundList> GetclaimRefundLists { get; set; }

        public DbSet<vwRuleHeader> GetRuleHeaders { get; set; }

        public DbSet<vwClaimRefundLetter> GetRefundLetters { get; set; }

        #region EDI
        public DbSet<vwEDIMember> vwEDIMember { get; set; }
        public DbSet<vwEDIProvider> vwEDIProvider { get; set; }
        public DbSet<vwClaimStatus> GetClaimStatus { get; set; }
        public DbSet<vwMemberIPA> GetMemberIPA { get; set; }
        public DbSet<vwMemberBenefitEnrollment> GetMemberBenefitEnrollment { get; set; }
        public DbSet<vwImportRemittanceAdviceCheck> GetRemittanceAdviceCheck { get; set; }
        public DbSet<vwImportRemittanceAdviceClaim> GetRemittanceAdviceClaim { get; set; }
        public DbSet<vwImportRemittanceAdviceService> GetRemittanceAdviceService { get; set; }
        public DbSet<vwPlanBenefit> GetPlanBenefit { get; set; }
        public DbSet<vwMemberPCP> GetMemberPCP { get; set; }
        public DbSet<vwEligibilityResponse> GetEligibilityResponse { get; set; }
        #endregion

        public DbSet<vwHomeGrownCodeList> vwHomeGrownCodes { get; set; }
        public DbSet<vwCodeTypeList> vwCodeTypeLists { get; set; }
        public DbSet<vwCommonCodeList> vwCommonCodes { get; set; }

        #region Finance

        public DbSet<vwCompanyAccountList> GetCompanyAccountList { get; set; }

        public DbSet<vwAccountDetailList> GetAccountDetailList { get; set; }
        public DbSet<vwLienAccountList> GetLienAccountList { get; set; }
        public DbSet<vwLienHolderBalanceAmountHistory> GetLienHolderBalanceAmountHistory { get; set; }

        public DbSet<vwCheckHistoryList> GetCheckHistoryList { get; set; }
        public DbSet<vwAdjustmentList> vwAdjustmentList { get; set; }
        public DbSet<vwAdjustmentAppliedList> vwAdjustmentAppliedList { get; set; }
        public DbSet<vwCheckWriteProcessList> vwCheckWriteProcessList { get; set; }

        public DbSet<vwForm1099ProcessList> vwForm1099ProcessList { get; set; }

        public DbSet<vwForm1099ProcessStatusHistoryList> vwForm1099ProcessStatusHistoryList { get; set; }
        #endregion


        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<vwCapitation>().ToTable("vwCapitation", "hps");
            builder.Entity<vwCapitation>().HasKey(i => i.CapitationHeaderID);
            builder.Entity<vwCapitation>().Property(i => i.CapitationName).IsUnicode(false);
            builder.Entity<vwCapitation>().Property(i => i.CapitationDescription).IsUnicode(false);
            builder.Entity<vwCapitation>().Property(i => i.CapitationCode).IsUnicode(false);
            builder.Entity<vwCapitation>().Property(i => i.CapitationType).IsUnicode(false);


            builder.Entity<vwTerm>().ToTable("vwTerm", "hps");
            builder.Entity<vwTerm>().HasKey(i => i.TermHeaderID);

            builder.Entity<vwPlanCapitation>().ToTable("vwPlanCapitation", "master");
            builder.Entity<vwPlanCapitation>().HasKey(i => i.CapitationPlanID);

            builder.Entity<vwMembershipCapitation>().ToTable("vwMembershipCapitation", "master");
            builder.Entity<vwMembershipCapitation>().HasKey(i => i.MembershipCapitationID);

            builder.Entity<vwMemberLookup>().ToTable("vwMemberLookup", "hps");
            builder.Entity<vwMemberLookup>().HasKey(i => new { i.MemberID, i.MemberEligibilityID });

            builder.Entity<vwProviderLookup>().ToTable("vwProviderLookup", "hps");
            builder.Entity<vwProviderLookup>().HasKey(i => new { i.ProviderID, i.ProviderEligibilityID, i.GroupID });

            builder.Entity<vwFacilityLookup>().ToTable("vwFacilityLookup", "hps");
            builder.Entity<vwFacilityLookup>().HasKey(i => new { i.FacilityID, i.FacilityEligibilityID });

            builder.Entity<vwClaimList>().ToTable("vwClaimList", "hps");
            builder.Entity<vwClaimList>().HasKey(i => i.ClaimHeaderID);

            builder.Entity<vwLocation>().ToTable("vwLocation", "master");
            builder.Entity<vwLocation>().HasKey(i => i.LocationID);

            builder.Entity<vwProvider>().ToTable("vwProvider", "hps");
            builder.Entity<vwProvider>().HasKey(i => i.ProviderID);

            builder.Entity<vwProviderList>().ToTable("vwProviderList", "hps");
            builder.Entity<vwProviderList>().HasKey(i => i.ProviderID);

            builder.Entity<vwCountries>().ToTable("vwCountries", "master");
            builder.Entity<vwCountries>().HasKey(i => i.Country);


            builder.Entity<vwCities>().Property(i => i.City).IsUnicode(false);

            builder.Entity<vwIPA>().ToTable("vwIPA", "hps");
            builder.Entity<vwIPA>().HasKey(i => i.IPAID);

            builder.Entity<vwClaimLoockup>().ToTable("vwClaimLookup", "hps");
            builder.Entity<vwClaimLoockup>().HasKey(i => i.ClaimHeaderID);

            builder.Entity<vwICDCode>().ToTable("vwICDCode", "edi");
            builder.Entity<vwICDCode>().HasKey(i => i.ICDCodeID);

            builder.Entity<vwCPTCode>().ToTable("vwCPTCode", "edi");
            builder.Entity<vwCPTCode>().HasKey(i => i.CPTCodeID);


            builder.Entity<GetStatesModel>().Property(i => i.StateFullName).IsUnicode(false);
            builder.Entity<GetStatesModel>().Property(i => i.State).IsUnicode(false);

            builder.Entity<GetCountiesModel>().Property(i => i.County).IsUnicode(false);


            builder.Entity<GetCommonCodeConfigurationModel>().ToTable("vwCommonCodeConfiguration", "master");
            builder.Entity<GetCommonCodeConfigurationModel>().HasKey(i => i.CommonCodeID);

            builder.Entity<vwContract>().ToTable("vwContract", "hps");
            builder.Entity<vwContract>().HasKey(i => i.ContractHeaderID);
            builder.Entity<vwContract>().Property(i => i.CapitationName).IsUnicode(false);
            builder.Entity<vwContract>().Property(i => i.ContractDescription).IsUnicode(false);
            builder.Entity<vwContract>().Property(i => i.ContractName).IsUnicode(false);
            builder.Entity<vwContract>().Property(i => i.AnesConversionFactorCode).IsUnicode(false);
            builder.Entity<vwContract>().Property(i => i.ClaimType).IsUnicode(false);

            // Code Of Member Summary View
            builder.Entity<vwMemberList>().ToTable("vwMemberList", "hps");
            builder.Entity<vwMemberList>().HasKey(i => i.MemberID);

            builder.Entity<vwProviderRelation>().ToTable("vwProviderRelation", "hps");
            builder.Entity<vwProviderRelation>().HasKey(i => i.ProviderID);

            builder.Entity<vwClaimServiceContractTermFeeschedule>().ToTable("vwClaimServiceContractTermFeeschedule", "hps");
            builder.Entity<vwClaimServiceContractTermFeeschedule>().HasKey(i => i.RowID);

            builder.Entity<vwClaimBenefit>().ToTable("vwClaimBenefit", "hps");
            builder.Entity<vwClaimBenefit>().HasKey(i => i.RowID);

            builder.Entity<vwClaimRefundList>().ToTable("vwClaimRefundList", "hps");
            builder.Entity<vwClaimRefundList>().HasKey(i => i.RowID);

            builder.Entity<vwRuleHeader>().ToTable("vwRuleHeader", "master");
            builder.Entity<vwRuleHeader>().HasKey(i => i.RuleHeaderID);
            builder.Entity<vwRuleHeader>().Property(i => i.CompanyName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.SubCompanyName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.LobName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.ProductTypeName).IsUnicode(false);
            builder.Entity<vwRuleHeader>().Property(i => i.HealthPlanName).IsUnicode(false);


            builder.Entity<vwClaimRefundLetter>().ToTable("vwClaimRefundLetter", "hps");
            builder.Entity<vwClaimRefundLetter>().HasKey(i => i.RefundRequestClaimID);

            #region EDI
            builder.Entity<vwClaimStatus>().ToTable("vwClaimStatus", "edi");
            builder.Entity<vwClaimStatus>().HasKey(i => i.ClaimHeaderID);

            builder.Entity<vwEligibilityResponse>().HasKey(i => new { i.MemberID, i.HealthPlanID, i.BenefitHeaderID });
            #endregion

            builder.Entity<vwHomeGrownCodeList>().ToTable("vwHomeGrownCodeList", "master");
            builder.Entity<vwHomeGrownCodeList>().HasKey(i => i.HomeGrownCodeID);


            builder.Entity<vwCodeTypeList>().ToTable("vwCodeTypeList", "master");
            builder.Entity<vwCodeTypeList>().HasKey(i => i.CodeTypeID);


            builder.Entity<vwCommonCodeList>().ToTable("vwCommonCodeList", "master");
            builder.Entity<vwCommonCodeList>().HasKey(i => i.CommonCodeID);
            #region Finance

            builder.Entity<vwCompanyAccountList>().ToTable("vwCompanyAccountList", "finance");
            builder.Entity<vwCompanyAccountList>().HasKey(i => i.AccountDetailCompanyStructureID);

            builder.Entity<vwAccountDetailList>().ToTable("vwAccountDetailList", "finance");
            builder.Entity<vwAccountDetailList>().HasKey(i => i.AccountDetailID);

            builder.Entity<vwCheckHistoryList>().ToTable("vwCheckHistoryList", "finance");
            builder.Entity<vwCheckHistoryList>().HasKey(i => i.CheckDetailID);


            builder.Entity<vwLienAccountList>().ToTable("vwLienAccountList", "finance");
            builder.Entity<vwLienAccountList>().HasKey(i => i.LienHolderBalanceID);

            builder.Entity<vwLienHolderBalanceAmountHistory>().ToTable("vwLienHolderBalanceAmountHistory", "finance");
            builder.Entity<vwLienHolderBalanceAmountHistory>().HasKey(i => i.LienHolderBalanceID);

            builder.Entity<vwAdjustmentList>().ToTable("vwAdjustmentList", "finance");
            builder.Entity<vwAdjustmentList>().HasKey(i => i.CheckDetailID);

            builder.Entity<vwAdjustmentAppliedList>().ToTable("vwAdjustmentAppliedList", "finance");
            builder.Entity<vwAdjustmentAppliedList>().HasKey(i => i.CheckDetailID);

            builder.Entity<vwCheckWriteProcessList>().ToTable("vwCheckWriteProcessList", "finance");
            builder.Entity<vwCheckWriteProcessList>().HasKey(i => i.CheckWriteProcessID);

            builder.Entity<vwForm1099ProcessList>().ToTable("vwForm1099ProcessList", "finance");
            builder.Entity<vwForm1099ProcessList>().HasKey(i => i.Form1099ProcessID);

            builder.Entity<vwForm1099ProcessStatusHistoryList>().ToTable("vwForm1099ProcessStatusHistoryList", "finance");
            builder.Entity<vwForm1099ProcessStatusHistoryList>().HasKey(i => i.Form1099ProcessStatusHistoryID);
            #endregion Finance


            base.OnModelCreating(builder);
        }
    }
}
