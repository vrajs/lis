﻿using System.Threading.Tasks;

namespace Kwicle.Data
{
    public interface IDatabaseInitializer
    {
        Task SeedAsync();
    }
}
