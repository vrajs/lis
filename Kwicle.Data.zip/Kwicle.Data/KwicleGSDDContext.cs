﻿using Kwicle.Core.Views;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Kwicle.Data
{
    public class KwicleGSDDContext : DbContext
    {
        public KwicleGSDDContext(DbContextOptions<KwicleGSDDContext> options)
          : base(options)
        {
        }

        public DbSet<vwHPSGetClaimNDCData> GetClaimNDCData { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<vwHPSGetClaimNDCData>().ToTable("vwHPSGetClaimNDCData", "dbo");
            builder.Entity<vwHPSGetClaimNDCData>().HasKey(i => i.DrugItemID);

            base.OnModelCreating(builder);
        }

    }
}
