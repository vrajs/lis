﻿using Kwicle.Common.Utility;
using Kwicle.Core.Entities.EDI;
using Kwicle.Core.Entities.EDI.View;
using Kwicle.Data.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Kwicle.Data
{
    public class DataImportContext : DbContext
    {
        public IConfiguration Configurationuration { get; }
        private static Dictionary<SqlDbType, Type> _clrTypeToSqlTypeMaps;

        public DataImportContext(DbContextOptions<DataImportContext> options, IConfiguration configuration)
          : base(options)
        {
            Configurationuration = configuration;
        }

        public DbSet<EDICodeType> CodeTypes { get; set; }
        public DbSet<EDICommonCode> EdiCommonCodes { get; set; }

        #region EDI
        public virtual DbSet<ClaimErrors> ClaimErrors { get; set; }
        public virtual DbSet<ClaimInstitutional> ClaimInstitutional { get; set; }
        public virtual DbSet<ClaimInstitutionalOutbound> ClaimInstitutionalOutbound { get; set; }
        public virtual DbSet<ClaimInstitutionalServices> ClaimInstitutionalServices { get; set; }
        public virtual DbSet<ClaimInstitutionalServicesOutbound> ClaimInstitutionalServicesOutbound { get; set; }
        public virtual DbSet<ClaimPaymentServices> ClaimPaymentServices { get; set; }
        public virtual DbSet<ClaimPaymentSummary> ClaimPaymentSummary { get; set; }
        public virtual DbSet<ClaimProfessional> ClaimProfessional { get; set; }
        public virtual DbSet<ClaimProfessionalError> ClaimProfessionalError { get; set; }
        public virtual DbSet<ClaimProfessionalOutbound> ClaimProfessionalOutbound { get; set; }
        public virtual DbSet<ClaimProfessionalServices> ClaimProfessionalServices { get; set; }
        public virtual DbSet<ClaimProfessionalServicesOutbound> ClaimProfessionalServicesOutbound { get; set; }
        public virtual DbSet<ClaimStatusRequest> ClaimStatusRequest { get; set; }
        public virtual DbSet<ClaimStatusRequestService> ClaimStatusRequestService { get; set; }
        public virtual DbSet<ClaimStatusResponse> ClaimStatusResponse { get; set; }
        public virtual DbSet<ClaimStatusResponseService> ClaimStatusResponseService { get; set; }
        public virtual DbSet<ClearingHouse> ClearingHouse { get; set; }
        //public virtual DbSet<DataFileToProcess> DataFileToProcess { get; set; }
        public virtual DbSet<Element> Elements { get; set; }
        public virtual DbSet<FileProcessHistory> FileProcessHistory { get; set; }
        public virtual DbSet<Loops> Loops { get; set; }
        public virtual DbSet<Segments> Segments { get; set; }
        public virtual DbSet<Mtab278AuthorizationPhysician> Mtab278AuthorizationPhysician { get; set; }
        public virtual DbSet<Mtab278AuthorizationRequest> Mtab278AuthorizationRequest { get; set; }
        public virtual DbSet<Mtab278AuthorizationRequestService> Mtab278AuthorizationRequestService { get; set; }
        public virtual DbSet<Mtab278AuthorizationResponse> Mtab278AuthorizationResponse { get; set; }
        public virtual DbSet<Mtab278AuthorizationResponseService> Mtab278AuthorizationResponseService { get; set; }
        public virtual DbSet<MtabMError> MtabMError { get; set; }
        public virtual DbSet<MtabMLocation> MtabMLocation { get; set; }
        public virtual DbSet<MtabMStatus> MtabMStatus { get; set; }
        //public virtual DbSet<MtabMTradingPartnerMaster> MtabMTradingPartnerMaster { get; set; }
        //public virtual DbSet<MtabMTradingPartnerProcessConfig> MtabMTradingPartnerProcessConfig { get; set; }
        //public virtual DbSet<MtabMTradingPartnerReqModule> MtabMTradingPartnerReqModule { get; set; }
        public virtual DbSet<RemittanceAdviceClaim> RemittanceAdviceClaim { get; set; }
        public virtual DbSet<RemittanceAdviceService> RemittanceAdviceService { get; set; }
        public virtual DbSet<RemittanceAdviceCheck> RemittanceAdviceCheck { get; set; }
        public virtual DbSet<X12270EligibilityRequest> X12270EligibilityRequest { get; set; }
        public virtual DbSet<X12270EligibilityResponse> X12270EligibilityResponse { get; set; }
        public virtual DbSet<X12271EligibilityResponse> X12271EligibilityResponse { get; set; }
        public virtual DbSet<X12276ClaimStatusRequest> X12276ClaimStatusRequest { get; set; }
        public virtual DbSet<X12277ClaimAck> X12277ClaimAck { get; set; }
        public virtual DbSet<X12277caClaimAck> X12277caClaimAck { get; set; }
        public virtual DbSet<X12278AuthorizationResponse> X12278AuthorizationResponse { get; set; }
        public virtual DbSet<X12820RemittanceAdvice> X12820RemittanceAdvice { get; set; }

        public virtual DbSet<X12834BenefitEnrollmentHeader> X12834BenefitEnrollmentHeader { get; set; }
        public virtual DbSet<X12834BenefitEnrollment> X12834BenefitEnrollment { get; set; }
        public virtual DbSet<X12834BenefitEnrollmentCoverage> X12834BenefitEnrollmentCoverage { get; set; }
        public virtual DbSet<X12834BenefitEnrollmentCob> X12834BenefitEnrollmentCob { get; set; }
        public virtual DbSet<X12834BenefitEnrollmentProvider> X12834BenefitEnrollmentProvider { get; set; }
        public virtual DbSet<X12835ClaimPaymentAdvice> X12835ClaimPaymentAdvice { get; set; }
        public virtual DbSet<X12837ClaimDental> X12837ClaimDental { get; set; }
        public virtual DbSet<X12837ClaimInstitutional> X12837ClaimInstitutional { get; set; }
        public virtual DbSet<X12837ClaimProfessional> X12837ClaimProfessional { get; set; }
        public virtual DbSet<X12841CodeList> X12841CodeList { get; set; }
        public virtual DbSet<X12997FunctionalAck> X12997FunctionalAck { get; set; }
        public virtual DbSet<X12Codeset> X12Codeset { get; set; }
        public virtual DbSet<X12Document> X12Document { get; set; }
        public virtual DbSet<X12DocumentResponse> X12DocumentResponse { get; set; }
        public virtual DbSet<X12FunctionalGroup> X12FunctionalGroup { get; set; }
        public virtual DbSet<X12Identifier> X12Identifier { get; set; }
        public virtual DbSet<X12Interchange> X12Interchange { get; set; }
        public virtual DbSet<X12InterchangeMessage> X12InterchangeMessage { get; set; }
        public virtual DbSet<X12InterchangeStatus> X12InterchangeStatus { get; set; }
        public virtual DbSet<X12Level1Ack> X12Level1Ack { get; set; }
        public virtual DbSet<X12Location> X12Location { get; set; }
        public virtual DbSet<X12Organization> X12Organization { get; set; }
        public virtual DbSet<X12OrganizationDefault> X12OrganizationDefault { get; set; }
        public virtual DbSet<X12OrganizationDropLocation> X12OrganizationDropLocation { get; set; }
        public virtual DbSet<X12ParseTemp> X12ParseTemp { get; set; }
        public virtual DbSet<X12ProfessionalDocument> X12ProfessionalDocument { get; set; }
        public virtual DbSet<X12Ta1InterchangeAck> X12Ta1InterchangeAck { get; set; }
        public virtual DbSet<X12Transaction> X12Transaction { get; set; }
        public virtual DbSet<X12TransactionSchema> X12TransactionSchema { get; set; }

        public virtual DbSet<TradingPartner> TradingPartner { get; set; }
        public virtual DbSet<DataFileConfiguration> DataFileConfiguration { get; set; }
        public virtual DbSet<DataFileProcess> DataFileProcess { get; set; }
        public virtual DbSet<FileNamingConvention> FileNamingConvention { get; set; }
        public virtual DbSet<FileNamingSequence> FileNamingSequence { get; set; }
        public virtual DbSet<InstitutionalDiagnosisCode> InstitutionalDiagnosisCode { get; set; }
        public virtual DbSet<ClaimInstitutionalError> ClaimInstitutionalError { get; set; }

        public virtual DbSet<ClaimStatusMapping> ClaimStatusMappings { get; set; }

        public virtual DbSet<MemberBenefitEnrollment> MemberBenefitEnrollments { get; set; }
        public virtual DbSet<EligibilityRequest> EligibilityRequest { get; set; }
        public virtual DbSet<EligibilityResponse> EligibilityResponse { get; set; }
        public virtual DbSet<EligibilityResponseDependent> EligibilityResponseDependent { get; set; }
        public virtual DbSet<EligibilityResponseDependentDetail> EligibilityResponseDependentDetail { get; set; }
        public virtual DbSet<EligibilityResponseDetail> EligibilityResponseDetail { get; set; }

        public virtual DbSet<MemberBenefitEnrollmentErrors> MemberBenefitEnrollmentErrors { get; set; }

        public virtual DbSet<OutboundMappingconfiguration> OutboundMappingconfigurations { get; set; }

        public virtual DbSet<ElementMappingSource> ElementMappingSource { get; set; }
        public virtual DbSet<vwElementMappingSource> GetElementMappingSource { get; set; }
        public virtual DbSet<vwMemberEnrollmentCoverage> GetMemberEnrollmentCoverage { get; set; }
        public virtual DbSet<vwMemberEnrollment> GetMemberEnrollment { get; set; }
        #endregion END EDI

        #region EDI Views
        public virtual DbSet<vw837PFileSummary> Vw837PFileSummary { get; set; }
        public virtual DbSet<vwProfessionalClaimSummary> VwProfessionalClaimSummary { get; set; }
        public virtual DbSet<vwX12_277CA_ClaimAck> VWX12_277CA_ClaimAcks { get; set; }
        public virtual DbSet<vwTradingPartnerSummary> VWTradingPartnerSummaries { get; set; }
        public virtual DbSet<vwClaimProfessionalOutbound> VwClaimProfessionalOutbounds { get; set; }
        public virtual DbSet<vwClaimProfessionalServicesOutbound> VwClaimProfessionalServicesOutbounds { get; set; }

        public virtual DbSet<vwProfessioalClaimError> VwProfessioalClaimErrors { get; set; }
        public virtual DbSet<vwProfessionalErrorClaim> VwProfessionalErrorClaims { get; set; }


        public virtual DbSet<vwClaimInstitutionalOutbound> VwClaimInstitutionalOutbounds { get; set; }
        public virtual DbSet<vwClaimInstitutionalServicesOutbound> VwClaimInstitutionalServicesOutbounds { get; set; }

        public virtual DbSet<vw837IFileSummary> Vw837IFileSummary { get; set; }
        public virtual DbSet<vwInstitutionalClaimSummary> VwInstitutionalClaimSummary { get; set; }
        public virtual DbSet<vwProfessionalClaimOutboundSummary> vwProfessionalClaimOutboundSummary { get; set; }
        //claim error
        public virtual DbSet<vwInstitutionalClaimError> VwInstitutionalClaimError { get; set; }
        public virtual DbSet<vwInstitutionalErrorClaim> VwInstitutionalErrorClaim { get; set; }

        // Claim Status 
        public virtual DbSet<vw276FileSummary> Vw276FileSummary { get; set; }
        public virtual DbSet<vw276ClaimStatusSummary> vw276ClaimStatusSummary { get; set; }
        public virtual DbSet<VwClaimStatusResponse> vw277ClaimStatusResponse { get; set; }
        public virtual DbSet<VwClaimStatusResponseService> vwClaimStatusResponseService { get; set; }
        //Eligibilty
        public virtual DbSet<vw270FileSummary> Vw270FileSummary { get; set; }
        public virtual DbSet<vw270Summary> vw270Summary { get; set; }
        public virtual DbSet<VwEligibilityResponse> vwEligibilityResponse { get; set; }
        public virtual DbSet<VwEligibilityResponseDetail> vwEligibilityResponseDetail { get; set; }
        public virtual DbSet<VwEligibilityResponseDependent> vwEligibilityResponseDependent { get; set; }
        public virtual DbSet<VwEligibilityResponseDependentDetail> vwEligibilityResponseDependentDetail { get; set; }

        //Enrollment
        public virtual DbSet<vw834FileSummary> Vw834FileSummary { get; set; }
        public virtual DbSet<vw834MemberSummary> Vw834MemberSummary { get; set; }
        public virtual DbSet<vwMemberEnrollmentOutbound> VwMemberEnrollmentOutbound { get; set; }
        public virtual DbSet<vw834InboundFileSummary> Vw834InboundFileSummary { get; set; }
        public virtual DbSet<vw834MemberInboundSummary> Vw834MemberInboundSummary { get; set; }
        public virtual DbSet<vwMemberEnrollmentProvider> VwMemberEnrollmentProvider { get; set; }
        public virtual DbSet<vwMemberEnrollmentCOB> vwMemberEnrollmentCOB { get; set; }
        // Claim Payment
        public virtual DbSet<vwRemittanceAdviceClaim> VwRemittanceAdviceClaim { get; set; }
        public virtual DbSet<vwRemittanceAdviceService> VwRemittanceAdviceService { get; set; }
        public virtual DbSet<vwRemittanceAdviceCheck> VwRemittanceAdviceCheck { get; set; }

        public virtual DbSet<vw835CheckSummary> Vw835CheckSummary { get; set; }
        public virtual DbSet<vw835CheckClaimSummary> Vw835CheckClaimSummary { get; set; }

        public virtual DbSet<vwOutboundMappingConfiguration> GetOutboundMappingConfiguration { get; set; }
        #endregion
        protected override void OnModelCreating(ModelBuilder builder)
        {
            #region Master
            //builder.Entity<EDICodeType>().Property(x => x.CodeTypeID).ValueGeneratedNever();
            //builder.Entity<EDICodeType>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();            
            //builder.Entity<EDICodeType>().HasIndex(s => s.Code).IsUnique();
            //builder.Entity<EDICodeType>().Property(c => c.RecordStatus).HasDefaultValue(0);

            //builder.Entity<EDICommonCode>().Property(x => x.CommonCodeID).ValueGeneratedNever();            
            //builder.Entity<EDICommonCode>().HasIndex(t => new { t.CodeTypeID });            
            //builder.Entity<EDICommonCode>().HasIndex(e => new { e.CodeTypeID, e.Code }).IsUnique();
            //builder.Entity<EDICommonCode>().Property(c => c.RowVersion).ValueGeneratedOnAddOrUpdate().IsConcurrencyToken();
            //builder.Entity<EDICommonCode>().Property(c => c.NumericValue).HasColumnType("decimal(8,2)").IsRequired();
            //builder.Entity<EDICommonCode>().Property(c => c.RecordStatus).HasDefaultValue(0);


            #endregion
            #region EDI

            builder.Entity<ClaimErrors>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimProfessional>(entity =>
            {
                entity.HasKey(e => e.ClaimProfessionalId)
                    .HasName("PK_ClaimPro_Mtab_x12_837_Claim_oid");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimProfessionalError>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimProfessionalServicesOutbound>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.HasQueryFilter(e => e.RecordStatus == (byte)Core.Common.RecordStatus.Active);
            });

            builder.Entity<ClaimStatusRequest>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimStatusRequestService>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimStatusResponse>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimStatusResponseService>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimProfessionalServices>(entity =>
            {
                entity.HasKey(e => e.MtabX12837ServicesOid)
                    .HasName("PK_ClaimPro_Mtab_x12_837_services_oid");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12837ClaimProfessional>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClaimProfessionalOutbound>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });


            builder.Entity<X12InterchangeMessage>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12InterchangeStatus>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Element>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<FileProcessHistory>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Loops>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Segments>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<ClearingHouse>(entity =>
            {
                entity.Property(e => e.ClearingHouseId).HasDefaultValueSql("newid()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            //builder.Entity<DataFileToProcess>(entity =>
            //{
            //    entity.HasKey(e => e.DataFileToProcessId)
            //         .HasName("PK_DataFileToProcessId_DataFileToProcess");
            //    entity.Property(e => e.IsGeneratedReport).HasDefaultValueSql("0");

            //    entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

            //    entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            //});

            builder.Entity<FileNamingConvention>(entity =>
            {
                //entity.HasKey(e => e.FileNamingConventionId).HasName("PK_FileNamingConventionId_FileNamingConvention");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<FileNamingSequence>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                //entity.HasKey(e => e.FileNamingSequenceId).HasName("PK_FileNamingSequenceId_FileNameSequence");
            });

            builder.Entity<Mtab278AuthorizationPhysician>(entity =>
            {
                entity.HasKey(e => e.MtabAuthorizationPhysicianId)
                    .HasName("PK_Mtab_278_MtabAuthorizationPhysicianId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Mtab278AuthorizationRequest>(entity =>
            {
                entity.HasKey(e => e.MtabAuthorizationRequestId)
                    .HasName("PK_Mtab_278_MtabAuthorizationRequestId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Mtab278AuthorizationRequestService>(entity =>
            {
                entity.HasKey(e => e.MtabAuthrizationrequestServiceId)
                    .HasName("PK_Mtab_278_MtabAuthrizationrequestServiceId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Mtab278AuthorizationResponse>(entity =>
            {
                entity.HasKey(e => e.MtabAuthorizationResponseId)
                    .HasName("PK_Mtab_278_MtabAuthorizationResponseId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<Mtab278AuthorizationResponseService>(entity =>
            {
                entity.HasKey(e => e.MtabAuthrizationResponseServiceId)
                    .HasName("PK_Mtab_278_MtabAuthrizationResponseServiceId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<MtabMError>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<MtabMLocation>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<MtabMStatus>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });
            //builder.Entity<MtabMTradingPartnerReqModule>(entity =>
            //{
            //    entity.Property(e => e.Enable277).HasDefaultValueSql("0");

            //    entity.Property(e => e.IsAckactive).HasDefaultValueSql("0");

            //    entity.Property(e => e.IsNonPayment).HasDefaultValueSql("0");

            //    entity.Property(e => e.MultiCompany).HasDefaultValueSql("0");

            //    entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

            //    entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            //});

            builder.Entity<RemittanceAdviceClaim>(entity =>
            {
                entity.HasKey(e => e.RemittanceAdviceClaimID)
                    .HasName("PK_RemittanceAdviceCheckID");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<RemittanceAdviceService>(entity =>
            {
                entity.HasKey(e => e.RemittanceAdviceServiceID)
                    .HasName("PK_RemittanceAdviceServiceId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<RemittanceAdviceCheck>(entity =>
            {
                entity.HasKey(e => e.RemittanceAdviceCheckID)
                    .HasName("PK_RemittanceAdviceCheckID");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12270EligibilityRequest>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12270EligibilityResponse>(entity =>
            {
                entity.HasIndex(e => e.X12TransactionId)
                    .HasName("idx_x12_transaction_id");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12271EligibilityResponse>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12276ClaimStatusRequest>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.Error).HasDefaultValueSql("0");

                entity.Property(e => e.Processed).HasDefaultValueSql("0");
            });

            builder.Entity<X12277ClaimAck>(entity =>
            {
                entity.HasIndex(e => e.X12TransactionId)
                    .HasName("idx_x12_transaction_id");

                entity.HasIndex(e => new { e.Bht03TransBatchId, e.L2200dRef021kPayerClaimControlNum })
                    .HasName("idx_bht03_ref02_clm_ctrl_no");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });


            builder.Entity<X12277caClaimAck>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12278AuthorizationResponse>(entity =>
            {
                entity.Property(e => e.Processed).HasDefaultValueSql("0");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12841CodeList>(entity =>
            {
                entity.Property(e => e.Processed).HasDefaultValueSql("0");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12820RemittanceAdvice>(entity =>
            {
                entity.HasIndex(e => e.L2000bEnt04OrgIdCodeOmapPhp)
                    .HasName("idx_L2000B_ent04_org_id_code_omap_php");

                entity.HasIndex(e => e.L2000bEnt04OrgIdCodeOmapRateGroup)
                    .HasName("idx_L2000B_ent04_org_id_code_omap_rate_group");

                entity.HasIndex(e => new { e.L2300bDtm06CoveragePeriodBegin, e.L2300bDtm06CoveragePeriodEnd })
                    .HasName("idx_coverage_dates");

                entity.HasIndex(e => new { e.X12TransactionId, e.Trn02TraceNumber, e.L2100bNm109IndividualId, e.L2300aRmr04PremPaymentAmount, e.Bpr02TotalProvPmtAmt, e.Bpr16CheckEffDate, e.L1000aN102ReceiverOrgNm, e.L1000aN104ReceiverId, e.L1000bN102PayerNm, e.L1000bN103PayerId, e.L2000bEnt04OrgIdCodeOmapRateGroup, e.L2000bEnt04OrgIdCodeOmapPerc, e.L2000bEnt04OrgIdCodeOmapPhp, e.L2000bEnt04OrgIdCodeOmapFips, e.L2300bDtm06CoveragePeriodBegin, e.L2300bDtm06CoveragePeriodEnd })
                    .HasName("idx_x12_820_remittance_advice");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<X12834BenefitEnrollment>(entity =>
            {
                entity.HasIndex(e => e.L2000Ref02SubscriberId)
                    .HasName("idx_L2000_ref02_subscriber_id");

                entity.HasIndex(e => e.X12TransactionId)
                    .HasName("idx_x12_transaction_header_id");

                entity.HasIndex(e => new { e.L2000Ref02InsuredGrpPolicyNum, e.X12TransactionId })
                    .HasName("idx_L2000_ref02_insured_grp_policy_num");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.Error).HasDefaultValueSql("0");

                entity.Property(e => e.Processed).HasDefaultValueSql("0");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

            });

            builder.Entity<X12835ClaimPaymentAdvice>(entity =>
            {
                entity.Property(e => e.L1000aN101EntityIdCode).HasDefaultValueSql("'PR'");

                entity.Property(e => e.L1000bN101EntityIdCode).HasDefaultValueSql("'PE'");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12837ClaimDental>(entity =>
            {
                entity.HasIndex(e => e.X12TransactionId)
                    .HasName("idx_x12_transaction_id");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12837ClaimInstitutional>(entity =>
            {
                entity.HasIndex(e => e.X12TransactionId)
                    .HasName("idx_x12_transaction_id");

                entity.HasIndex(e => new { e.X12TransactionId, e.L1000aNm103SubmitterLastNm, e.L1000aNm109SubmitterId })
                    .HasName("idx_submitter_info");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<ClaimInstitutionalOutbound>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<ClaimInstitutionalServices>(entity =>
            {
                entity.ToTable("ClaimInstitutionalServices", "edi");
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");


                entity.HasOne(d => d.ClaimInstitutional)
                 .WithMany(p => p.ClaimInstitutionalServices)
                 .HasForeignKey(d => d.ClaimInstitutionalId)
                 .HasConstraintName("FK_Claiminstitutional_ClaimInstitutionalServices_ClaimInstitutionalID");
                entity.HasQueryFilter(e => e.RecordStatus == (byte)Core.Common.RecordStatus.Active);
            });

            builder.Entity<ClaimInstitutionalServicesOutbound>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<ClaimPaymentServices>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<ClaimPaymentSummary>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12997FunctionalAck>(entity =>
            {
                entity.HasIndex(e => e.X12TransactionId)
                    .HasName("idx_x12_transaction_header_id");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.Error).HasDefaultValueSql("0");

                entity.Property(e => e.Processed).HasDefaultValueSql("0");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12Codeset>(entity =>
            {
                entity.HasKey(e => e.X12CodeId)
                    .HasName("PK_x12_codset");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

            });

            builder.Entity<X12Document>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.Error).HasDefaultValueSql("0");

                entity.Property(e => e.Processed).HasDefaultValueSql("0");
            });

            builder.Entity<X12FunctionalGroup>(entity =>
            {
                entity.HasIndex(e => new { e.X12FunctionalGroupId, e.X12InterchangeId, e.X12TransactionSchemaId })
                    .HasName("idx_schema");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12Identifier>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });


            builder.Entity<X12Interchange>(entity =>
            {
                entity.HasIndex(e => e.CreatedDate)
                    .HasName("idx_created_date");

                entity.HasIndex(e => e.DestX12OrganizationId)
                    .HasName("idx_dest_x12_organization_id");

                entity.HasIndex(e => e.Isa09InterchangeDate)
                    .HasName("IX_x12_isa09_interchange_date");

                entity.HasIndex(e => e.SrcX12OrganizationId)
                    .HasName("idx_src_x12_organization_id");


                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

            });

            builder.Entity<X12Level1Ack>(entity =>
            {
                entity.HasKey(e => e.X12Level1Uid)
                    .HasName("PK_x12_Leve_X12Level1Uid");

                entity.Property(e => e.X12Level1Uid).HasDefaultValueSql("newid()");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12Location>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12Location>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12Organization>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12OrganizationDefault>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12OrganizationDropLocation>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12ParseTemp>(entity =>
            {
                entity.HasIndex(e => e.X12ParseTempUid)
                    .HasName("IX_x12_parse_temp_uid");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12ProfessionalDocument>(entity =>
            {

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.Error).HasDefaultValueSql("0");

                entity.Property(e => e.Processed).HasDefaultValueSql("0");

                entity.Property(e => e.X12DocumentUid).HasDefaultValueSql("newid()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12Ta1InterchangeAck>(entity =>
            {
                entity.HasIndex(e => e.X12InterchangeId)
                    .HasName("idx_x12_transaction_header_id");

                entity.Property(e => e.Error).HasDefaultValueSql("0");

                entity.Property(e => e.Processed).HasDefaultValueSql("0");

                entity.Property(e => e.X12InterchangeId).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<X12Transaction>(entity =>
            {
                entity.HasIndex(e => new { e.X12TransactionId, e.X12FunctionalGroupId })
                    .HasName("idx_functional_group_id");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });

            builder.Entity<TradingPartner>(entity =>
            {
                entity.HasKey(e => e.TradingPartnerId).HasName("PK_TradingPartnerID_TradingPartner");
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
            });
            builder.Entity<DataFileProcess>(entity =>
            {
                entity.HasKey(e => e.DataFileProcessId).HasName("PK_DataFileProcessId_DataFileProcess");
            });
            builder.Entity<DataFileConfiguration>(entity =>
            {
                entity.HasKey(e => e.DataFileConfigurationId).HasName("PK_DataFileConfigurationId_DataFileConfiguration");
            });
            builder.Entity<InstitutionalDiagnosisCode>(entity =>
            {
                entity.HasKey(e => e.InstitutionalDiagnosisCodeId).HasName("PK_InstitutionalDiagnosisCodeId_InstitutionalDiagnosisCode");
                entity.HasQueryFilter(e => e.RecordStatus == (byte)Core.Common.RecordStatus.Active);
            });
            builder.Entity<ClaimInstitutionalError>(entity =>
            {
                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });

            builder.Entity<MemberBenefitEnrollmentErrors>(entity =>
            {
                entity.HasKey(e => e.MemberBenefitEnrollmentErrorsId).HasName("PK_MemberBenefitEnrollmentErrorsId");

                entity.Property(e => e.RecordStatus).HasDefaultValueSql("0");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("getdate()");
            });
            #endregion END EDI
            base.OnModelCreating(builder);
        }

        public List<T> ExecuteStoreProcedure<T>(string CommandText, Array parameters) where T : new()
        {
            try
            {
                this.Database.OpenConnection();
                var cmd = this.Database.GetDbConnection().CreateCommand();
                cmd.CommandText = CommandText;
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                using (var reader = cmd.ExecuteReader())
                {
                    return reader.MapToList<T>();
                }
            }
            finally
            {
                this.Database.CloseConnection();
            }
        }

        public DataTable ToDataTableWithSchemaFromIList<TSource>(string userDefinedTableTypeName, IList<TSource> objModellist)
        {
            _clrTypeToSqlTypeMaps = CommonUtil.CreateClrTypeToSqlTypeMaps();
            var dataTable = new DataTable();
            this.Database.OpenConnection();
            var cmd = this.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "edi.uspGetSchemaByName";
            cmd.CommandType = CommandType.StoredProcedure;
            var objparam = new System.Data.SqlClient.SqlParameter("@Name", userDefinedTableTypeName);
            cmd.Parameters.Add(objparam);
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var columnName = reader["name"].ToString();
                    var sqlDbType = (SqlDbType)Enum.Parse(typeof(SqlDbType), reader["datatype"].ToString(), true);
                    Type result;
                    _clrTypeToSqlTypeMaps.TryGetValue(sqlDbType, out result);
                    dataTable.Columns.Add(columnName, result);
                }
            }
            string[] columnNames = dataTable.Columns.Cast<DataColumn>()
                                 .Select(x => x.ColumnName)
                                 .ToArray();

            if (objModellist != null)
            {
                PropertyInfo[] Props = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (TSource item in objModellist)
                {
                    DataRow dr = dataTable.NewRow();
                    for (int i = 0; i < Props.Length; i++)
                    {
                        if (columnNames.Contains(Props[i].Name))
                        {
                            if (Props[i].GetValue(item, null) != null)
                                dr[Props[i].Name] = Props[i].GetValue(item, null);
                            else
                                dr[Props[i].Name] = DBNull.Value;
                        }
                    }
                    dataTable.Rows.Add(dr);
                }
            }

            return dataTable;
        }

        public void BulkInsertMember<T>(List<T> EntityList)
        {
            if (EntityList.Count > 0)
            {
                //start Migration from 2.1 to 3.1
                //var mapping = this.Model.FindEntityType(EntityList.FirstOrDefault().GetType()).Relational();
                var mapping = this.Model.FindEntityType(EntityList.FirstOrDefault().GetType());
                //end Migration from 2.1 to 3.1

                try
                {
                    Database.OpenConnection();

                    using (var sqlCopy = new SqlBulkCopy((SqlConnection)this.Database.GetDbConnection()))
                    {
                        //start Migration from 2.1 to 3.1
                        //sqlCopy.DestinationTableName = $"[{ mapping.Schema }].[{ mapping.TableName }]";
                        sqlCopy.DestinationTableName = $"[{ mapping.GetSchema() }].[{ mapping.GetTableName() }]";
                        //end Migration from 2.1 to 3.1
                        sqlCopy.BatchSize = 500;

                        sqlCopy.WriteToServer(CommonUtil.ToDataTable(EntityList));
                    }

                }
                finally
                {
                    Database.CloseConnection();
                }
            }
        }


    }
}
