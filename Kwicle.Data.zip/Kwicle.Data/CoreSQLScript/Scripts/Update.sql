IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4033 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
UPDATE Menu set AngularTemplateUrl ='configurations/benefit-list' where ID= 4033
END 
GO 

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4142 and IsNUll(AngularTemplateUrl,'') = 'configurations/plan' ) 
BEGIN 
UPDATE Menu set AngularTemplateUrl ='configurations/plan-list' where ID= 4142
END 
GO 
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4026 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
UPDATE Menu set AngularTemplateUrl ='administration/tradingpartner-list' where ID= 4026
END 
GO 


/******************************************************************************
* CREATED DATE: 17/08/2017  (DD/MM/YYYY)
* CREATED AUTHOR: Rinkesh Mistry
* Description : Update URL of 'HCFA - Professional Claims', 'UB - Institutional Claims' menu.
* Affected Tables : [Menu]
******************************************************************************
*	CHANGE DATE  Developer			TaskID/UserSoryID		Modification Puspose		
--------------	--	----------------	--------------------	--------------------
	11/29/2017		Mohit Joshi											Update "AngularTemplateUrl" and remove If Condition.
 

******************************************************************************/

UPDATE Menu set AngularTemplateUrl ='claims/details/3401/0/create' where ID= 4054

UPDATE Menu set AngularTemplateUrl ='claims/details/3403/0/create' where ID= 4055

UPDATE Menu set AngularTemplateUrl ='claims/details/3402/0/create' where ID= 4056

UPDATE Menu set AngularTemplateUrl ='claims/details/3404/0/create' where ID= 4058



/******************************************************************************
* CREATED DATE: 13/12/2017  (DD/MM/YYYY)
* CREATED AUTHOR: Mohit Joshi
* Description : Update MenuName and MenuShortName from 'Organization' to 'LOB'.
* Affected Tables : [Menu]
******************************************************************************
*	CHANGE DATE  Developer			TaskID/UserSoryID		Modification Puspose		
--------------	--	----------------	--------------------	--------------------
	

******************************************************************************/

UPDATE	[dbo].[Menu] SET		MenuName = 'LOB', MenuShortName = 'LOB' WHERE	MenuShortName='Organization'


/******************************************************************************
* CREATED DATE: 24/08/2017  (DD/MM/YYYY)
* CREATED AUTHOR: Rinkesh Mistry
* Description : Update URL of 'Claim => Refund', 'Claim => Mass Adjudication' menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4059 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='claims/refund/search' where ID= 4059
END 
GO 

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4061 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='claims/massadjudication/search' where ID= 4061
END 
GO 


/******************************************************************************
* CREATED DATE: 04/09/2017  (DD/MM/YYYY)
* CREATED AUTHOR: Rupesh Mandal
* Description : Update URL of 'Member => Member' menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4046 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='member/search' where ID= 4046
END 
GO 

/******************************************************************************
* CREATED DATE: 29/09/2017  (DD/MM/YYYY)
* CREATED AUTHOR: Akash Patel
* Description : Update URL of 'Contract => list' menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4032 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='configurations/contract-list' where ID= 4032
END 
GO 
/******************************************************************************
* CREATED DATE: 11/01/2017  
* CREATED AUTHOR: Nishant Thakkar
* Description : Update URL of 'Contract => list' menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4150 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='masters/capitation-list' where ID= 4150
END 
GO 
/******************************************************************************
* CREATED DATE: 11/06/2017  
* CREATED AUTHOR: Dhruvin Bhatt
* Description : Update URL of '837 p and 837I' menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4145 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='interface/clearinghouse/professional-list' where ID= 4145
END 
GO 
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4146 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='interface/clearinghouse/institutional-list' where ID= 4146
END 
GO 

/******************************************************************************
* CREATED DATE: 20/12/2017  
* CREATED AUTHOR: Akash Patel
* Description : Update Provider Parent menu AngularTemplateUrl.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4042 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='provider/ipa-list' where ID= 4042
END 
GO 

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4043 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='provider/search/group' where ID= 4043
END 
GO 

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4044 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE Menu set AngularTemplateUrl ='provider/search/provider' where ID= 4044
END 
GO 

/******************************************************************************
* CREATED DATE: 01/08/2017  (MM/DD/YYYY)
* CREATED AUTHOR: Adithya Valsaraj
* Description : Updated icons for left menu items.
* Affected Tables : [Menu]
******************************************************************************/

-- help
UPDATE dbo.Menu SET Icon = 'fa fa-question' WHERE ID = 4138

--member portal
UPDATE dbo.Menu SET Icon = 'fa fa-users' WHERE ID = 4124

--provider portal
UPDATE dbo.Menu SET Icon = 'fa fa-user-md' WHERE ID = 4112

--Interfaces
UPDATE dbo.Menu SET Icon = 'fa fa fa-hand-pointer-o' WHERE ID = 4103

--reporting
UPDATE dbo.Menu SET Icon = 'fa fa-files-o' WHERE ID = 4101

--Sales & Marketing
UPDATE dbo.Menu SET Icon = 'fa fa-money' WHERE ID = 4095

/******************************************************************************
* CREATED DATE: 01/08/2018 (MM/DD/YYYY)
* CREATED AUTHOR: Pavan
* Description : Update icon of menu.
* Affected Tables : [Menu]
******************************************************************************/

--Administration
UPDATE dbo.Menu SET Icon = 'fa fa-user-circle-o' WHERE ID = 4001

--Operation
UPDATE dbo.Menu SET Icon = 'fa fa-cogs' WHERE ID = 4040

--Medical Management
UPDATE dbo.Menu SET Icon = 'fa fa-medkit' WHERE ID = 4074

--Finanace
UPDATE dbo.Menu SET Icon = 'fa fa-usd' WHERE ID = 4082

--Compliance
UPDATE dbo.Menu SET Icon = 'fa fa-file-text-o' WHERE ID = 4093


/******************************************************************************
* CREATED DATE: 02/01/2018  
* CREATED AUTHOR: Rinkesh Mistry
* Description : Update Template URL of User and Role Menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4038 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE  [dbo].[Menu] SET AngularTemplateURl='security/users/search'  WHERE ID=4038
END 
GO 

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4039 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
	UPDATE  [dbo].[Menu] SET AngularTemplateURl='security/roles/search'  WHERE ID=4039
END 
GO 


UPDATE Menu set AngularTemplateUrl ='claims/professional/0/create' where ID= 4054

UPDATE Menu set AngularTemplateUrl ='claims/institutional/0/create' where ID= 4055

UPDATE Menu set AngularTemplateUrl ='claims/dental/0/create' where ID= 4056

UPDATE Menu set AngularTemplateUrl ='claims/pharmacy/0/create' where ID= 4058

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4016 and IsNUll(AngularTemplateUrl,'') = '' ) 
BEGIN 
UPDATE Menu set AngularTemplateUrl ='masters/timely-filing-list' where ID= 4016
END 
GO 

IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4154 and MenuName = 'Organization Structure' ) 
BEGIN
UPDATE dbo.Menu  SET MenuName = 'Organization Structure' , MenuShortName = 'Organization Structure' WHERE ID = 4154
END
GO

/******************************************************************************
* CREATED DATE: 03/20/2018 
* CREATED AUTHOR: Tej Parikh
* Description : Update Template URL of User and Role Menu.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4038 and AngularTemplateUrl = 'security/users/search' ) 
BEGIN 
	UPDATE  [dbo].[Menu] SET AngularTemplateURl='security/user-list'  WHERE ID=4038
END 
GO 

IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4039 and AngularTemplateUrl = 'security/roles/search' ) 
BEGIN 
	UPDATE  [dbo].[Menu] SET AngularTemplateURl='security/role-list'  WHERE ID=4039
END 
GO 

/******************************************************************************
* CREATED DATE: 06/04/2018  
* CREATED AUTHOR: Akash Patel
* Description : Update Plan menu name.
* Affected Tables : [Menu]
******************************************************************************/
IF EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4142 and MenuName = 'Plan' ) 
BEGIN 
	UPDATE Menu set MenuName ='Plan Benefit Package' where ID= 4142
END 
GO 
