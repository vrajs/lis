IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4001 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4001,'NULL','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'glyphicons-user-key','Administration','Administration',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4002 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4002,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Masters','Masters',4001,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4003 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4003,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Tables and Codes','Tables and Codes',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4004 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4004,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','CPT, HCPC, HIPPS, Mods','CPT, HCPC, HIPPS, Mods',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4005 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4005,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','ICD9 and ICD10','ICD9 and ICD10',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4006 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4006,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Revenue','Revenue',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4007 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4007,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','DRG','DRG',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4008 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4008,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','APR-DRG','APR-DRG',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4009 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4009,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Place of Service','Place of Service',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4010 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4010,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','NDC','NDC',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4011 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4011,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),8  ,'','HCC','HCC',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4012 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4012,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),9  ,'','Zip Codes','Zip Codes',4002,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4013 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4013,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Supporting Tables','Supporting Tables',4001,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4014 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4014,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Age Categories','Age Categories',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4015 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4015,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Anesthesia Region Rates','Anesthesia Region Rates',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4016 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4016,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Timely Filing','Timely Filing',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4017 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4017,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Fee Schedule','Fee Schedule',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4018 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4018,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','UCR Fee Schedule','UCR Fee Schedule',4017,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4019 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4019,'masters','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Fee Schedule Limits','Fee Schedule Limits',4017,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4020 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4020,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','RBRVS','RBRVS',4017,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4021 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4021,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','GPCI','GPCI',4017,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4022 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4022,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Locality','Locality',4017,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4023 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4023,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Interest/Quick Pay','Interest/Quick Pay',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4024 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4024,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Modifier Discount Group','Modifier Discount Group',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4025 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4025,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Capitation','Capitation',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4026 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4026,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','EDI - Trading Partner','EDI - Trading Partner',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4027 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4027,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),8  ,'','Regions','Regions',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4028 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4028,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),9  ,'','Anesthesia Conversion Factor','Anesthesia Conversion',4013,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4029 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4029,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Configuration','Configuration',4001,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4030 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4030,'configurations','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Organization','Organization',4029,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4031 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4031,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Service & Auth Groups','Service & Auth Groups',4029,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4032 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4032,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Contracts','Contracts',4029,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4033 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4033,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Benefits','Benefits',4029,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4034 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4034,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','GL Accounts','GL Accounts',4029,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4035 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4035,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Security','Security',4001,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4036 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4036,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Environments','Environments',4035,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4037 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4037,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Databases','Databases',4035,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4038 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4038,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Users','Users',4035,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4039 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4039,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Roles','Roles',4035,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4040 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4040,'NULL','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'glyphicons-user-key','Operation','Operation',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4041 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4041,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Provider','Provider',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4042 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4042,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','IPA','IPA',4041,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4043 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4043,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Group','Group',4041,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4044 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4044,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Provider','Provider',4041,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4045 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4045,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Member','Member',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4046 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4046,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Member','Member',4045,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4047 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4047,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','COB','COB',4045,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4048 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4048,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','CMS Processing AaNeel','CMS Processing AaNeel',4045,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4049 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4049,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','CRM-AaNeel','CRM-AaNeel',4045,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4050 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4050,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Customer Service','Customer Service',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4051 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4051,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Customer Service','Customer Service',4050,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4052 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4052,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Claims','Claims',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4141 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4141,'claims/search','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Search','Search',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4053 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4053,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Claims','Claims',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4054 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4054,'claims/details/3401/0/create','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','HCFA - Professional Claims','HCFA - Professional Claims',4053,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4055 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4055,'claims/details/3403/0/create','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','UB - Institutional Claims','UB - Institutional Claims',4053,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4056 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4056,'claims/details/3402/0/create','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Dental','Dental',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4057 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4057,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Lab','Lab',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4058 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4058,'claims/details/3404/0/create','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Pharmacy','Pharmacy',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4059 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4059,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Refunds','Refunds',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4060 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4060,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','Recovery','Recovery',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4061 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4061,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','Mass Adjudication','Mass Adjudication',4052,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4062 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4062,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Appeals & Grievances','Appeals & Grievances',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4063 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4063,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Appeals & Grievances','Appeals & Grievances',4062,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4064 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4064,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Scheduler','Scheduler',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4065 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4065,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Work Queue','Work Queue',4064,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4066 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4066,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Job Queue','Job Queue',4064,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4067 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4067,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','Communication','Communication',4040,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4068 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4068,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Phone','Phone',4067,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4069 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4069,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Mailing','Mailing',4067,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4070 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4070,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Letters','Letters',4067,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4071 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4071,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Fax','Fax',4067,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4072 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4072,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Email','Email',4067,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4073 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4073,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Document Management','Document Management',4067,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4074 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4074,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'glyphicons-user-key','Medical Management','Medical Management',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4075 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4075,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Auth Template Configuration','Auth Template',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4076 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4076,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Referral & Auth','Referral & Auth',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4077 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4077,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Quality Management','Quality Management',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4078 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4078,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Disease Management','Disease Management',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4079 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4079,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Care Management','Care Management',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4080 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4080,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','MRA','MRA',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4081 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4081,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','HRA','HRA',4074,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4082 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4082,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'glyphicons-user-key','Finanace','Finanace',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4083 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4083,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Accounts','Accounts',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4084 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4084,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Checkwrite','Checkwrite',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4085 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4085,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Enter & Search Liens','Enter & Search Liens',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4086 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4086,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Enter & Search Incetives, Payment Advances, Manual Checks','Enter & Search',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4087 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4087,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','Check History','Check History',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4088 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4088,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Premium Billing','Premium Billing',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4089 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4089,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','Inbound Premium','Inbound Premium',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4090 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4090,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','Medical Economics','Medical Economics',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4091 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4091,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),8  ,'','Service Fund','Service Fund',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4092 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4092,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),9  ,'','1099','1099',4082,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4093 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4093,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'glyphicons-user-key','Compliance','Compliance',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4094 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4094,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','CTM','CTM',4093,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4095 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4095,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'glyphicons-user-key','Sales & Marketing','Sales & Marketing',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4096 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4096,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Campaigns','Campaigns',4095,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4097 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4097,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Seminars','Seminars',4095,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4098 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4098,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Agents','Agents',4095,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4099 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4099,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','Commission Structure','Commission Structure',4095,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4100 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4100,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Commission Payments','Commission Payments',4095,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4101 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4101,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'glyphicons-user-key','Reporting','Reporting',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4102 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4102,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Reporting','Reporting',4101,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4103 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4103,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'glyphicons-user-key','Interfaces','Interfaces',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4104 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4104,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','CMS','CMS',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4105 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4105,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','AHCA','AHCA',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4106 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4106,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Clearning House','Clearning House',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4107 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4107,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','APC Pricer','APC Pricer',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4108 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4108,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','McKesson Claim Check','McKesson Claim Check',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4109 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4109,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','MicroDyn','MicroDyn',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4110 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4110,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','Millimen/Interqual','Millimen/Interqual',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4111 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4111,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','Emdeon Fulfillment','Emdeon Fulfillment',4103,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4112 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4112,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),8  ,'glyphicons-user-key','Provider Portal','Provider Portal',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4113 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4113,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Bulletin Board','Bulletin Board',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4114 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4114,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Hospital Census','Hospital Census',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4115 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4115,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','Service Fund','Service Fund',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4116 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4116,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','MRA Portal','MRA Portal',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4117 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4117,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','HEDIS Portal','HEDIS Portal',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4118 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4118,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Auth/Referrals','Auth/Referrals',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4119 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4119,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','Eligibility Status','Eligibility Status',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4120 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4120,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','Claim Status Check','Claim Status Check',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4121 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4121,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),8  ,'','Communication','Communication',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4122 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4122,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),9  ,'','Membership List','Membership List',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4123 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4123,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),  10  ,'','Documents','Documents',4112,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4124 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4124,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),9  ,'glyphicons-user-key','Member Portal','Member Portal',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4125 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4125,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Bulletin Board','Bulletin Board',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4126 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4126,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Communication','Communication',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4127 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4127,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','EOB''s','EOB''s',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4128 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4128,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','ID Card','ID Card',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4129 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4129,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','EOC','EOC',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4130 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4130,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Medical Records','Medical Records',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4131 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4131,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),6  ,'','PCP Change Request','PCP Change Request',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4132 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4132,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),7  ,'','Claims History','Claims History',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4133 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4133,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),8  ,'','HEDIS Alerts','HEDIS Alerts',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4134 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4134,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),9  ,'','Member Education','Member Education',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4135 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4135,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),  10  ,'','Bill Pay - pay premium','Bill Pay - pay premium',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4136 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4136,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),  11  ,'','Member Grievance','Member Grievance',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4137 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4137,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),  12  ,'','Provider Search/Directory','Provider Search/Directory',4124,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4138 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4138,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),  10  ,'glyphicons-user-key','Help','Help',0,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4139 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4139,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Support','Support - Search Screen',4138,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4140 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4140,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','Documentation','Documentation',4138,8 ,0) END 
GO 
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4142 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4142,'configurations/plan','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','Plan','Plan',4029,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4143 ) BEGIN 	INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted]) 	 VALUES  ( 4143,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','834 - Member Enrollment','834',4106,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4144 ) BEGIN 	INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted]) 	 VALUES  ( 4144,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),1  ,'','270 - Member Eligibility Inquiry Response','270_271',4106,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4145 ) BEGIN 	INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted]) 	 VALUES  ( 4145,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),2  ,'','837 - Professional Claim','837P',4106,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4146 ) BEGIN 	INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted]) 	 VALUES  ( 4146,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),3  ,'','837 - Institutional Claim','837I',4106,8 ,0) END
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4147 ) BEGIN 	INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted]) 	 VALUES  ( 4147,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),4  ,'','835 - Remittance Advice','835',4106,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4148 ) BEGIN 	INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted]) 	 VALUES  ( 4148,'','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),5  ,'','278 - Authorization','278',4106,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4149 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4149,'configurations/service-group','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),0  ,'','Service Groups','Service Groups',4031,8 ,0) END 
GO
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4150 ) BEGIN INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID]  ,[CreatedDate]  ,[DisplayOrder]  ,[Icon]  ,[MenuName]  ,[MenuShortName]  ,[ParentMenuID]  ,[SiteID] ,[IsDeleted])  VALUES  ( 4150,'masters/drg-group-list','AB130CE8-8373-4B55-AD3D-2B3D16F67EC1',GETDATE(),10  ,'','DRG Group','DRG Group',4002,8 ,0) END 
GO 
/******************************************************************************
* CREATED DATE: 20/12/2017  
* CREATED AUTHOR: Akash Patel
* Description : Add Master Location menu.
* Affected Tables : [Menu]
******************************************************************************/
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4152 ) 
BEGIN
INSERT INTO [dbo].[Menu](Id,[AngularTemplateUrl],[CreatedByID],[CreatedDate],[DisplayOrder],[Icon],[MenuName],[MenuShortName],[ParentMenuID],[SiteID],[IsDeleted]) 
VALUES (4152,'masters/location/list','7A6947F0-C348-44ED-AD29-7339743B01F6',GETDATE(),11,'','Location','Location',4002,8,0)
END 
GO

IF( NOT EXISTS (SELECT  '*' FROM Menu WHERE ID = 4153))
BEGIN
INSERT INTO dbo.Menu (ID, AngularTemplateUrl, CreatedByID, CreatedDate, DisplayOrder, Icon, IsAdd, IsDelete, IsDeleted, IsEdit, IsPrint, IsRead, IsShowInMenu, MenuName, MenuShortName, MenuTypeID, MvcAction, MvcArea, MvcController, ParentMenuID, Reason, SiteID, ToolTip, UpdatedByID, UpdatedDate, ColorCode, Status)
VALUES (4153, 'interface/clearinghouse/claim-status-list', '7A6947F0-C348-44ED-AD29-7339743B01F6', '2017-07-25 05:23:57.053', 7, '', NULL, NULL, 0, NULL, NULL, NULL, 1, '276 - Claim Status', '276', NULL, NULL, NULL, NULL, 4106, NULL, 8, NULL, NULL, NULL, NULL, NULL)
END
GO

/******************************************************************************
* CREATED DATE: 05/03/2018  
* CREATED AUTHOR: Rupesh Mandal
* Description : Add Organization menu.
* Affected Tables : [Menu]
******************************************************************************/
IF NOT EXISTS(SELECT 1 FROM [Menu] WHERE ID = 4154 ) 
BEGIN
INSERT INTO dbo.Menu (ID, AngularTemplateUrl, CreatedByID, CreatedDate, DisplayOrder, Icon, IsAdd, IsDelete, IsDeleted, IsEdit, IsPrint, IsRead, IsShowInMenu, MenuName, MenuShortName, MenuTypeID, MvcAction, MvcArea, MvcController, ParentMenuID, Reason, SiteID, ToolTip, UpdatedByID, UpdatedDate, ColorCode, Status)
VALUES (4154, 'configurations/organization-view', '7A6947F0-C348-44ED-AD29-7339743B01F6', '2017-03-05 05:23:57.053', 11, '', NULL, NULL, 0, NULL, NULL, NULL, 1, 'Organization', 'Organization', NULL, NULL, NULL, NULL, 4029, NULL, 8, NULL, NULL, NULL, NULL, 'COMPLETED')
END 
GO