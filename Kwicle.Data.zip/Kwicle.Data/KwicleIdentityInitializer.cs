﻿using Kwicle.Core;
using Kwicle.Core.Entities;
using Kwicle.Data.Contracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Kwicle.Data
{

    public class KwicleIdentityInitializer : IDatabaseInitializer
    {
        private readonly KwicleCoreContext _context;
        private readonly IAccountManager _accountManager;
        private readonly ILogger _logger;

        public KwicleIdentityInitializer(KwicleCoreContext context, IAccountManager accountManager, ILogger<KwicleIdentityInitializer> logger)
        {
            _accountManager = accountManager;
            _context = context;
            _logger = logger;
        }

        public async Task SeedAsync()
        {
            await _context.Database.MigrateAsync().ConfigureAwait(false);

            if (!await _context.Users.AnyAsync())
            {
                _logger.LogInformation("Generating inbuilt accounts");

                const string adminRoleName = "administrator";
                const string userRoleName = "user";

                await EnsureRoleAsync(adminRoleName, "Default administrator", ApplicationPermissions.GetAllPermissionValues());
                await EnsureRoleAsync(userRoleName, "Default user", new string[] { });

                await CreateUserAsync("VicParmar", "Passw0rd9*", "Inbuilt Administrator", "Vic@aaneel.com", "+919901279999", new[] { adminRoleName });
                await CreateUserAsync("admin", "Passw0rd9*", "Inbuilt Administrator", "Vic1@aaneel.com", "+919901279999", new[] { adminRoleName });
                await CreateUserAsync("user", "Passw0rd9*", "Inbuilt Standard User", "Vic2@aaneel.com", "+919901279999", new[] { userRoleName });
                await CreateUserAsync("upendrapatel", "Welcome011*", "Upendra Patel", "upen@aaneel.com", "+18134951508", new[] { adminRoleName });
                await CreateUserAsync("bhavinchitaliya", "Welcome012*", "Bhavin Chitaliya", "Bhavin@aaneel.com", "+919898431919", new[] { adminRoleName });
                await CreateUserAsync("trishhoffmann", "Welcome013*", "Trish Hoffmann", "Trish.Hoffmann@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("debbietersigni", "Welcome014*", "Debbie Tersigni", "Debbie.Tersigni@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("leelachristopher", "Welcome015*", "Leela Christopher", "Leela.Christopher@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("mohitjoshi", "Welcome022*", "Mohit Joshi", "Mohit.Joshi@aaneel.com", "+919427749080", new[] { adminRoleName });
                await CreateUserAsync("nishantthakkar", "Welcome021*", "Nishant Thakkar", "Nishant.Thakkar@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("dipeshprajapati", "Welcome023*", "Dipesh Prajapati", "Dipesh.Prajapati@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("rushiupadhyay", "Welcome024*", "Rushi Upadhyay", "Rushi.Upadhyay@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("rinkeshmistry", "Welcome025*", "Rinkesh Mistry", "Rinkesh.Mistry@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("tejparikh", "Welcome026*", "Tej Parikh", "Tej.Parikh@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("akashpatel", "Welcome027*", "Akash Patel", "Akash.Patel@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("nirmalbhagwani", "Welcome028*", "Nirmal Bhagwani", "Nirmal.Bhagwani@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("dhruvalthakkar", "Welcome029*", "Dhruval Thakkar", "Dhruval.thakkar@aaneel.com", "", new[] { adminRoleName });
                await CreateUserAsync("aadhi", "dsfw2121@@AA", "Adithya Valsaraj", "adithya.valsaraj.@aaneel.com", "+919743444543", new[] { adminRoleName });
                await CreateUserAsync("Shiraj", "Welcome031*", "Shiraj Momin", "shiraj.momin@aaneel.com", "+919558818530", new[] { adminRoleName });

                _logger.LogInformation("Inbuilt account generation completed");
            }                
        }

        private async Task EnsureRoleAsync(string roleName, string description, string[] claims)
        {
            if ((await _accountManager.GetRoleByNameAsync(roleName)) == null)
            {
                KwicleRole kwicleRole = new KwicleRole(roleName, description);

                var result = await _accountManager.CreateRoleAsync(kwicleRole, claims);

                if (!result.Item1)
                    throw new Exception($"Seeding \"{description}\" role failed. Errors: {string.Join(Environment.NewLine, result.Item2)}");
            }
        }
        private async Task<KwicleUser> CreateUserAsync(string userName, string password, string fullName, string email, string phoneNumber, string[] roles)
        {
            KwicleUser kwicleUser = new KwicleUser
            {
                UserName = userName,
                FullName = fullName,
                Email = email,
                PhoneNumber = phoneNumber,
                EmailConfirmed = true,
                IsEnabled = true
            };

            var result = await _accountManager.CreateUserAsync(kwicleUser, roles, password);

            if (!result.Item1)
                throw new Exception($"Seeding \"{userName}\" user failed. Errors: {string.Join(Environment.NewLine, result.Item2)}");


            return kwicleUser;
        }

    }
}
