﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kwicle.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Text.RegularExpressions;

namespace Kwicle.Data
{

    public class KwicleDbInitializer : IDatabaseInitializer
    {
        private readonly KwicleContext _ctx;
        //private KwicleCoreContext _coreCtx;
        //private static string Source = "Health Plan System";
        private static readonly string CreatedBy = "Nishant Thakkar";
        private static readonly string RecStatusChangeComment = "Active";
        private static readonly DateTime TermDate = DateTime.MaxValue;
        //private static Guid CreatedByID = new Guid("7A6947F0-C348-44ED-AD29-7339743B01F6");
        //private static DateTime CreatedDate = DateTime.UtcNow;
        //private static int SiteID = 8;
        public KwicleDbInitializer(KwicleContext ctx)
        {
            _ctx = ctx;
            //_coreCtx = coreCtx;
        }

        public async Task SeedAsync()
        {
            //if (!_ctx.Clinics.Any())
            //{
            //    // Add Data
            //    _ctx.AddRange(_sample);

            //    await _ctx.SaveChangesAsync();
            //}
            //if (!_ctx.CodeTypes.Any())
            //{

            //    _ctx.AddRange(_codeTypes);
            //    await _ctx.SaveChangesAsync();

            //    //_ctx.Database.ExecuteSqlCommand("SET IDENTITY_INSERT[dbo].[CodeType] OFF");
            //    //_ctx.Database.ExecuteSqlCommand("SET IDENTITY_INSERT[dbo].[CommonCode] OFF");
            //    //_ctx.SaveChanges();
            //}
            //if (!_ctx.Products.Any())
            //{
            //    _ctx.AddRange(_products);
            //    await _ctx.SaveChangesAsync();
            //}
            if (!_ctx.Sponsors.Any())
            {
                _ctx.AddRange(_sponsors);
                await _ctx.SaveChangesAsync();
            }
            if (!_ctx.Categories.Any())
            {
                _ctx.AddRange(_categories);
                await _ctx.SaveChangesAsync();
            }
            if (!_ctx.Organizations.Any())
            {
                _ctx.AddRange(_organizations);
                await _ctx.SaveChangesAsync();
            }
            //if (!_coreCtx.Menus.Any(x=>x.SiteID == SiteID))
            //{
            //    _coreCtx.AddRange(_menus);
            //    await _coreCtx.SaveChangesAsync();
            //}
            //else
            //{
            //    var deletedData = _coreCtx.Menus.Where(x => x.SiteID == SiteID);
            //    _coreCtx.Menus.RemoveRange(deletedData);
            //    _coreCtx.SaveChanges();
            //    _coreCtx.AddRange(_menus);
            //    await _coreCtx.SaveChangesAsync();

            //}

            // Execute Sql Files Core/Tran DB
            //bool EnableSqlScript = false;

            //if (EnableSqlScript)
            //{
            //    string CodeBase = Assembly.GetEntryAssembly().CodeBase;
            //    UriBuilder uri = new UriBuilder(CodeBase);
            //    string path = Uri.UnescapeDataString(uri.Path);
            //    var baseDir = Path.GetDirectoryName(path) + "\\CoreSQLScript";
            //    await ExecuteSqlFileAsync(baseDir, _coreCtx);

            //    baseDir = Path.GetDirectoryName(path) + "\\SQlScript";
            //    await ExecuteSqlFileAsync(baseDir, _ctx);
            //}

        }


        public async Task ExecuteSqlFileAsync(string baseDir, DbContext context)
        {
            foreach (var dir in Directory.GetDirectories(baseDir).ToList().OrderBy(p => p))
            {
                //Parallel.ForEach(Directory.GetFiles(dir), (file) =>
                foreach (var file in Directory.GetFiles(dir))
                {
                    var script = Regex.Split(File.ReadAllText(file), @"^\s*GO\s*$",
                           RegexOptions.Multiline | RegexOptions.IgnoreCase);
                    foreach (var query in script.Where(q => !string.IsNullOrEmpty(q)))
                    {
                        await context.Database.ExecuteSqlRawAsync(query);
                    }
                }
                await ExecuteSqlFileAsync(dir, context);
            }
        }

    //    readonly List<Clinic> _sample = new List<Clinic>
    //{
    //  new Clinic()
    //  {
    //    Name = "Clinic 1",
    //    UID = "CLN2017",
    //    Description = "This is the first Clinic",
    //     CreatedBy = CreatedBy,
    //     RecordStatusChangeComment=RecStatusChangeComment,
    //    //OldLocation = new OldLocation()
    //    //{
    //    //  Address1 = "123 Main Street",
    //    //  CityTown = "Atlanta",
    //    //  StateProvince = "GA",
    //    //  PostalCode = "30303",
    //    //  Country = "USA",
    //    //  CreatedBy = CreatedBy,
    //    //  RecordStatusChangeComment=RecStatusChangeComment
    //    //},
    //    Providers = new List<OldProvider>
    //    {
    //      new OldProvider()
    //      {
    //        Name = "DR. LAURA TURTZO",
    //        Description = "I'm a Provider",
    //        NPI = "1245319599",
    //        PhoneNumber = "9901279999",
    //        HeadShotUrl = "",
    //         CreatedBy = CreatedBy,
    //      RecordStatusChangeComment=RecStatusChangeComment,
    //        Procedures = new List<Procedure>()
    //        {
    //          new Procedure()
    //          {
    //            Name =  "Procedure 1",
    //            Description = "Procedure 1",
    //            CPTCode = "Throat",
    //            Level = "500",
    //            Prerequisites = "Clean Room",
    //            Room = "123",
    //            StartingTime = DateTime.Parse("14:30"),
    //             CreatedBy = CreatedBy,
    //      RecordStatusChangeComment=RecStatusChangeComment
    //          },
    //          new Procedure()
    //          {
    //            Name =  "Procedure 2",
    //            Description = "Procedure 2",
    //            CPTCode = "Dental",
    //            Level = "100",
    //            Prerequisites = "Toothbrush",
    //            Room = "124",
    //            StartingTime = DateTime.Parse("13:00"),
    //             CreatedBy = CreatedBy,
    //      RecordStatusChangeComment=RecStatusChangeComment
    //          },
    //        }
    //      },
    //      new OldProvider()
    //      {
    //        Name = "JASON M",
    //        Description = "I'm a Provider",
    //        NPI = "1912968298",
    //        PhoneNumber = "9901279999",
    //        HeadShotUrl = "",
    //         CreatedBy = CreatedBy,
    //      RecordStatusChangeComment=RecStatusChangeComment,
    //        Procedures = new List<Procedure>()
    //        {
    //          new Procedure()
    //          {
    //            Name =  "Games",
    //            Description = "NFS",
    //            CPTCode = "Games",
    //            Level = "100",
    //            Room = "234",
    //            StartingTime = DateTime.Parse("10:30"),
    //             CreatedBy = CreatedBy,
    //      RecordStatusChangeComment=RecStatusChangeComment
    //          }
    //        }
    //      }
    //    }
    //  }
    //};

        //List<CodeType> _codeTypes = new List<CodeType>
        //{
        //    new CodeType()
        //    {
        //        CodeTypeID = 1, Code="QLT", CreatedBy = "Nishant Thakkar" , CreatedDate = DateTime.UtcNow , EffectiveDate = DateTime.UtcNow ,
        //        RecordStatusChangeComment=RecStatusChangeComment,IsFreezed = 0, LongDescription = "Describes unit for measure of quantity limit" , ShortName = "Quantity Limit Type",TermDate = TermDate,
        //        CommonCodes = new List<CommonCode>
        //        {
        //            new CommonCode() {CommonCodeID = 1001,  CharValue = "$" , LongDescription = "Dollars", Code= "Dollars" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 1, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 1, RecordStatusChangeComment=RecStatusChangeComment ,ShortName= "Dollars", TermDate = TermDate,CodeTypeID =1 },
        //            new CommonCode() {  CommonCodeID = 1002,CharValue = "Per" , LongDescription = "Per", Code= "Per" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 2, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 2 , RecordStatusChangeComment=RecStatusChangeComment,ShortName= "Per", TermDate = TermDate,CodeTypeID =1},
        //            new CommonCode() {CommonCodeID = 1003,  CharValue = "PF" , LongDescription = "Per Foot", Code= "Per Foot" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 3, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 3 , RecordStatusChangeComment=RecStatusChangeComment,ShortName= "Per Foot", TermDate = TermDate,CodeTypeID =1},
        //            new CommonCode() { CommonCodeID = 1004, CharValue = "PK" , LongDescription = "Per Kafo", Code= "Per Kafo" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 4, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 4, RecordStatusChangeComment=RecStatusChangeComment ,ShortName= "Per Kafo", TermDate = TermDate,CodeTypeID =1},
        //            new CommonCode() { CommonCodeID = 1005, CharValue = "PO" , LongDescription = "Per Othosis", Code= "Per Othosis" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 5, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 5 , RecordStatusChangeComment=RecStatusChangeComment ,ShortName= "Per Othosis", TermDate = TermDate,CodeTypeID =1}
        //        }
        //    },
        //     new CodeType()
        //    {
        //        CodeTypeID = 2, Code="DLT", CreatedBy = "Nishant Thakkar" , CreatedDate = DateTime.UtcNow , EffectiveDate = DateTime.UtcNow ,
        //        RecordStatusChangeComment=RecStatusChangeComment,IsFreezed = 0, LongDescription = "Describes unit for measure of duration limit" , ShortName = "Duration Limit Type",TermDate = TermDate,
        //        CommonCodes = new List<CommonCode>
        //        {
        //            new CommonCode() {CommonCodeID = 2001,  CharValue = "Y" , LongDescription = "Year(s)", Code= "Years" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 1, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 1 , RecordStatusChangeComment=RecStatusChangeComment,ShortName= "Years" , TermDate = TermDate,CodeTypeID =2},
        //            new CommonCode() { CommonCodeID = 2002, CharValue = "LT" , LongDescription = "Life Time", Code= "Life Time" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 2, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 2 , RecordStatusChangeComment=RecStatusChangeComment,ShortName= "Life Time" , TermDate = TermDate,CodeTypeID =2},
        //            new CommonCode() {CommonCodeID = 2003,  CharValue = "ME" , LongDescription = "Medical Event", Code= "Medical Event" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 3, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 3 , RecordStatusChangeComment=RecStatusChangeComment,ShortName= "Medical Event" , TermDate = TermDate,CodeTypeID =2}
        //        }
        //    },
        //      new CodeType()
        //    {
        //        CodeTypeID = 3, Code="MLT", CreatedBy = "Nishant Thakkar" , CreatedDate = DateTime.UtcNow , EffectiveDate = DateTime.UtcNow ,
        //        RecordStatusChangeComment=RecStatusChangeComment,IsFreezed = 0, LongDescription ="Describes unit for measure of max limit" , ShortName = "Max Limit Type",TermDate = TermDate,
        //        CommonCodes = new List<CommonCode>
        //        {
        //            new CommonCode() {CommonCodeID = 3001,  CharValue = "Y" , LongDescription = "Years", Code= "Years" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 1, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 1 , RecordStatusChangeComment=RecStatusChangeComment, ShortName= "Years" , TermDate = TermDate,CodeTypeID =3},
        //            new CommonCode() { CommonCodeID = 3002, CharValue = "LT" , LongDescription = "Life Time", Code= "Life Time" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 2, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 2 , RecordStatusChangeComment=RecStatusChangeComment, ShortName= "Life Time", TermDate = TermDate,CodeTypeID =3},
        //            new CommonCode() { CommonCodeID = 3003, CharValue = "D" , LongDescription = "Days", Code= "Days" , CreatedBy = "Nishant Thakkar" ,
        //                CreatedDate = DateTime.UtcNow , DisplayOrder = 3, EffectiveDate =  DateTime.UtcNow ,  NumericValue = 3 , RecordStatusChangeComment=RecStatusChangeComment, ShortName= "Days", TermDate = TermDate,CodeTypeID =3}
        //        }
        //    }

        //};

        //List<Product> _products = new List<Product>
        //{
        //    {
        //        new Product() {  CreatedBy = CreatedBy ,CreatedDate = DateTime.UtcNow ,  ProductCode = "MR" , ProductName = "Medicare" , RecordStatusChangeComment=RecStatusChangeComment }

        //    },
        //    {
        //        new Product() {  CreatedBy = CreatedBy ,CreatedDate = DateTime.UtcNow ,   ProductCode = "MD" , ProductName = "Medicaid" , RecordStatusChangeComment=RecStatusChangeComment }

        //    },
        //    {
        //        new Product() {  CreatedBy = CreatedBy ,CreatedDate = DateTime.UtcNow ,  ProductCode = "CM" , ProductName = "Commercial", RecordStatusChangeComment=RecStatusChangeComment  }

        //    }
        //};

        readonly List<Sponsor> _sponsors = new List<Sponsor>
        {
            {
                new Sponsor() {  CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow ,   SponsorCode = "CMS" , SponsorName = "CMS" , RecordStatusChangeComment=RecStatusChangeComment }

            },
            {
                new Sponsor() {  CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow ,   SponsorCode = "WC" , SponsorName = "Wellcare" , RecordStatusChangeComment=RecStatusChangeComment }

            },
            {
                new Sponsor() {  CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow ,   SponsorCode = "AN" , SponsorName = "AaNeel Technology", RecordStatusChangeComment=RecStatusChangeComment  }

            }
        };

        readonly List<Category> _categories = new List<Category>
        {
            {
                new Category() {  CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow ,   CategoryCode = "HMO" , CategoryName = "HMO" , RecordStatusChangeComment=RecStatusChangeComment }

            },
            {
                new Category() {  CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow , CategoryCode = "PPO" , CategoryName = "PPO" , RecordStatusChangeComment=RecStatusChangeComment }

            }
        };

        readonly List<Organization> _organizations = new List<Organization>
        {
            {
                new Organization() { CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow , EffectiveDate = DateTime.UtcNow ,  OrganizationCode = "HPSAN" , OrganizationName = "HPS AaNeel" ,
                                    CaidContractNumber = "+919913741784" , CareContractNumber = "+919998362090" , ContactName = "Upen Patel", ShortName="Upen", Fax="+919558899631", MailingAddress1="410 Devarc Complex" ,
                                    MailingAddress2 = "S.G. Highway", MailingCity="Ahmedabad" , MailingState="Gujarat", MailingZip="380015", NICNumber="R002G", NPI="1002354", OrganizationTypeID = 1, ParentOrganizationID =0,
                                    Phone="079758364" , PhysicalAddress1="410 Devarc Complex",PhysicalAddress2 = "S.G. Highway", PhysicalCity="Ahmedabad" , PhysicalState="Gujarat", PhysicalZip="380015", StructureTypeID = 1,
                                    SubmitterCode = "BS001" , TIN="GFX2003" , TTY = "NPX30599", Website="www.aaneel.com", RecordStatusChangeComment=RecStatusChangeComment, TermDate = TermDate, TimeZoneLocation = "US"
                                 }

            },
            {
                new Organization() {  CreatedBy = CreatedBy , CreatedDate = DateTime.UtcNow , EffectiveDate = DateTime.UtcNow ,  OrganizationCode = "HPSANIT" , OrganizationName = "HPS AaNeel IT" ,
                                    CaidContractNumber = "+919913741784" , CareContractNumber = "+919998362090" , ContactName = "Upen Patel", ShortName="Upen", Fax="+919558899631", MailingAddress1="410 Devarc Complex" ,
                                    MailingAddress2 = "S.G. Highway", MailingCity="Ahmedabad" , MailingState="Gujarat", MailingZip="380015", NICNumber="R002G", NPI="1002354", OrganizationTypeID = 1, ParentOrganizationID =1,
                                    Phone="079758364" , PhysicalAddress1="410 Devarc Complex",PhysicalAddress2 = "S.G. Highway", PhysicalCity="Ahmedabad" , PhysicalState="Gujarat", PhysicalZip="380015", StructureTypeID = 1,
                                    SubmitterCode = "BS001" , TIN="GFX2003" , TTY = "NPX30599", Website="www.aaneel.com", RecordStatusChangeComment=RecStatusChangeComment, TermDate = TermDate, TimeZoneLocation = "US"
                                 }
            },
        };

        //List<Menu> _menus = new List<Menu>
        //{
        //    //Menu 1
        //    {new Menu() { ID = 4001, MenuName = "Administration" , MenuShortName = "Administration" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = null, CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4002, MenuName = "Masters" , MenuShortName = "Masters" ,ParentMenuID = 4001, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4003, MenuName = "Tables and Codes" , MenuShortName = "Tables and Codes" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4004, MenuName = "CPT, HCPC, HIPPS, Mods" , MenuShortName = "CPT, HCPC, HIPPS, Mods" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4005, MenuName = "ICD9 and ICD10" , MenuShortName = "ICD9 and ICD10" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" ,CreatedDate = CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4006, MenuName = "Revenue" , MenuShortName = "Revenue" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4007, MenuName = "DRG" , MenuShortName = "DRG" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4008, MenuName = "APR-DRG" , MenuShortName = "APR-DRG" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "", CreatedDate =  CreatedDate, CreatedByID = CreatedByID }},
        //    {new Menu() { ID = 4009, MenuName = "Place of Service" , MenuShortName = "Place of Service" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4010, MenuName = "NDC" , MenuShortName = "NDC" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4011, MenuName = "HCC" , MenuShortName = "HCC" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 8 , IsDelete = false , AngularTemplateUrl = "", CreatedDate =  CreatedDate , CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4012, MenuName = "Zip Codes" , MenuShortName = "Zip Codes" ,ParentMenuID = 4002, Icon = "", SiteID = SiteID , DisplayOrder = 9 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate , CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4013, MenuName = "Supporting Tables" , MenuShortName = "Supporting Tables" ,ParentMenuID = 4001, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4014, MenuName = "Age Categories" , MenuShortName = "Age Categories" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4015, MenuName = "Anesthesia Region Rates" , MenuShortName = "Anesthesia Region Rates" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4016, MenuName = "Timely Filing" , MenuShortName = "Timely Filing" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4017, MenuName = "Fee Schedule" , MenuShortName = "Fee Schedule" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4018, MenuName = "UCR Fee Schedule" , MenuShortName = "UCR Fee Schedule" ,ParentMenuID = 4017, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4019, MenuName = "Fee Schedule Limits" , MenuShortName = "Fee Schedule Limits" ,ParentMenuID = 4017, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "authenticated/fee-schedule", CreatedDate =  CreatedDate , CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4020, MenuName = "RBRVS" , MenuShortName = "RBRVS" ,ParentMenuID = 4017, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4021, MenuName = "GPCI" , MenuShortName = "GPCI" ,ParentMenuID = 4017, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4022, MenuName = "Locality" , MenuShortName = "Locality" ,ParentMenuID = 4017, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4023, MenuName = "Interest/Quick Pay" , MenuShortName = "Interest/Quick Pay" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4024, MenuName = "Modifier Discount Group" , MenuShortName = "Modifier Discount Group" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4025, MenuName = "Capitation" , MenuShortName = "Capitation" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4026, MenuName = "EDI - Trading Partner" , MenuShortName = "EDI - Trading Partner" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "", CreatedDate =  CreatedDate , CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4027, MenuName = "Regions" , MenuShortName = "Regions" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 8 , IsDelete = false , AngularTemplateUrl = "", CreatedDate =  CreatedDate , CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4028, MenuName = "Anesthesia Conversion Factor" , MenuShortName = "Anesthesia Conversion" ,ParentMenuID = 4013, Icon = "", SiteID = SiteID , DisplayOrder = 9 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},


        //    {new Menu() { ID = 4029, MenuName = "Configuration" , MenuShortName = "Configuration" ,ParentMenuID = 4001, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4030, MenuName = "Organization" , MenuShortName = "Organization" ,ParentMenuID = 4029, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "authenticated/lob-list" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4031, MenuName = "Service & Auth Groups" , MenuShortName = "Service & Auth Groups" ,ParentMenuID = 4029, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4032, MenuName = "Contracts" , MenuShortName = "Contracts" ,ParentMenuID = 4029, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4033, MenuName = "Benefits" , MenuShortName = "Benefits" ,ParentMenuID = 4029, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4034, MenuName = "GL Accounts" , MenuShortName = "GL Accounts" ,ParentMenuID = 4029, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4035, MenuName = "Security" , MenuShortName = "Security" ,ParentMenuID = 4001, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4036, MenuName = "Environments" , MenuShortName = "Environments" ,ParentMenuID = 4035, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4037, MenuName = "Databases" , MenuShortName = "Databases" ,ParentMenuID = 4035, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4038, MenuName = "Users" , MenuShortName = "Users" ,ParentMenuID = 4035, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4039, MenuName = "Roles" , MenuShortName = "Roles" ,ParentMenuID = 4035, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //menu 2 
        //    {new Menu() { ID = 4040, MenuName = "Operation" , MenuShortName = "Operation" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = null, CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4041, MenuName = "Provider" , MenuShortName = "Provider" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4042, MenuName = "IPA" , MenuShortName = "IPA" ,ParentMenuID = 4041, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4043, MenuName = "Group" , MenuShortName = "Group" ,ParentMenuID = 4041, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4044, MenuName = "Provider" , MenuShortName = "Provider" ,ParentMenuID = 4041, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4045, MenuName = "Member" , MenuShortName = "Member" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4046, MenuName = "Member" , MenuShortName = "Member" ,ParentMenuID = 4045, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4047, MenuName = "COB" , MenuShortName = "COB" ,ParentMenuID = 4045, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4048, MenuName = "CMS Processing AaNeel" , MenuShortName = "CMS Processing AaNeel" ,ParentMenuID = 4045, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4049, MenuName = "CRM-AaNeel" , MenuShortName = "CRM-AaNeel" ,ParentMenuID = 4045, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4050, MenuName = "Customer Service" , MenuShortName = "Customer Service" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4051, MenuName = "Customer Service" , MenuShortName = "Customer Service" ,ParentMenuID = 4050, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4052, MenuName = "Claims" , MenuShortName = "Claims" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4053, MenuName = "Claims" , MenuShortName = "Claims" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4054, MenuName = "HCFA - Professional Claims" , MenuShortName = "HCFA - Professional Claims" ,ParentMenuID = 4053, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4055, MenuName = "UB - Institutional Claims" , MenuShortName = "UB - Institutional Claims" ,ParentMenuID = 4053, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4056, MenuName = "Dental" , MenuShortName = "Dental" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4057, MenuName = "Lab" , MenuShortName = "Lab" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4058, MenuName = "Pharmacy" , MenuShortName = "Pharmacy" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4059, MenuName = "Refunds" , MenuShortName = "Refunds" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4060, MenuName = "Recovery" , MenuShortName = "Recovery" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4061, MenuName = "Mass Adjudication" , MenuShortName = "Mass Adjudication" ,ParentMenuID = 4052, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4062, MenuName = "Appeals & Grievances" , MenuShortName = "Appeals & Grievances" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4063, MenuName = "Appeals & Grievances" , MenuShortName = "Appeals & Grievances" ,ParentMenuID = 4062, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4064, MenuName = "Scheduler" , MenuShortName = "Scheduler" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4065, MenuName = "Work Queue" , MenuShortName = "Work Queue" ,ParentMenuID = 4064, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4066, MenuName = "Job Queue" , MenuShortName = "Job Queue" ,ParentMenuID = 4064, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4067, MenuName = "Communication" , MenuShortName = "Communication" ,ParentMenuID = 4040, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4068, MenuName = "Phone" , MenuShortName = "Phone" ,ParentMenuID = 4067, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4069, MenuName = "Mailing" , MenuShortName = "Mailing" ,ParentMenuID = 4067, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4070, MenuName = "Letters" , MenuShortName = "Letters" ,ParentMenuID = 4067, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4071, MenuName = "Fax" , MenuShortName = "Fax" ,ParentMenuID = 4067, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4072, MenuName = "Email" , MenuShortName = "Email" ,ParentMenuID = 4067, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4073, MenuName = "Document Management" , MenuShortName = "Document Management" ,ParentMenuID = 4067, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 3
        //    {new Menu() { ID = 4074, MenuName = "Medical Management" , MenuShortName = "Medical Management" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4075, MenuName = "Auth Template Configuration" , MenuShortName = "Auth Template" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4076, MenuName = "Referral & Auth" , MenuShortName = "Referral & Auth" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4077, MenuName = "Quality Management" , MenuShortName = "Quality Management" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4078, MenuName = "Disease Management" , MenuShortName = "Disease Management" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4079, MenuName = "Care Management" , MenuShortName = "Care Management" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4080, MenuName = "MRA" , MenuShortName = "MRA" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4081, MenuName = "HRA" , MenuShortName = "HRA" ,ParentMenuID = 4074, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 4
        //    {new Menu() { ID = 4082, MenuName = "Finanace" , MenuShortName = "Finanace" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4083, MenuName = "Accounts" , MenuShortName = "Accounts" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4084, MenuName = "Checkwrite" , MenuShortName = "Checkwrite" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4085, MenuName = "Enter & Search Liens" , MenuShortName = "Enter & Search Liens" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4086, MenuName = "Enter & Search Incetives, Payment Advances, Manual Checks" , MenuShortName = "Enter & Search" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4087, MenuName = "Check History" , MenuShortName = "Check History" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4088, MenuName = "Premium Billing" , MenuShortName = "Premium Billing" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4089, MenuName = "Inbound Premium" , MenuShortName = "Inbound Premium" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4090, MenuName = "Medical Economics" , MenuShortName = "Medical Economics" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4091, MenuName = "Service Fund" , MenuShortName = "Service Fund" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 8 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4092, MenuName = "1099" , MenuShortName = "1099" ,ParentMenuID = 4082, Icon = "", SiteID = SiteID , DisplayOrder = 9 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 5
        //    {new Menu() { ID = 4093, MenuName = "Compliance" , MenuShortName = "Compliance" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4094, MenuName = "CTM" , MenuShortName = "CTM" ,ParentMenuID = 4093, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 6
        //    {new Menu() { ID = 4095, MenuName = "Sales & Marketing" , MenuShortName = "Sales & Marketing" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4096, MenuName = "Campaigns" , MenuShortName = "Campaigns" ,ParentMenuID = 4095, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4097, MenuName = "Seminars" , MenuShortName = "Seminars" ,ParentMenuID = 4095, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4098, MenuName = "Agents" , MenuShortName = "Agents" ,ParentMenuID = 4095, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4099, MenuName = "Commission Structure" , MenuShortName = "Commission Structure" ,ParentMenuID = 4095, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4100, MenuName = "Commission Payments" , MenuShortName = "Commission Payments" ,ParentMenuID = 4095, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 7
        //    {new Menu() { ID = 4101, MenuName = "Reporting" , MenuShortName = "Reporting" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4102, MenuName = "Reporting" , MenuShortName = "Reporting" ,ParentMenuID = 4101, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 8
        //    {new Menu() { ID = 4103, MenuName = "Interfaces" , MenuShortName = "Interfaces" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4104, MenuName = "CMS" , MenuShortName = "CMS" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4105, MenuName = "AHCA" , MenuShortName = "AHCA" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4106, MenuName = "Clearning House" , MenuShortName = "Clearning House" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4107, MenuName = "APC Pricer" , MenuShortName = "APC Pricer" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4108, MenuName = "McKesson Claim Check" , MenuShortName = "McKesson Claim Check" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4109, MenuName = "MicroDyn" , MenuShortName = "MicroDyn" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4110, MenuName = "Millimen/Interqual" , MenuShortName = "Millimen/Interqual" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4111, MenuName = "Emdeon Fulfillment" , MenuShortName = "Emdeon Fulfillment" ,ParentMenuID = 4103, Icon = "", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //menu 9
        //    {new Menu() { ID = 4112, MenuName = "Provider Portal" , MenuShortName = "Provider Portal" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 8 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4113, MenuName = "Bulletin Board" , MenuShortName = "Bulletin Board" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4114, MenuName = "Hospital Census" , MenuShortName = "Hospital Census" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4115, MenuName = "Service Fund" , MenuShortName = "Service Fund" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4116, MenuName = "MRA Portal" , MenuShortName = "MRA Portal" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4117, MenuName = "HEDIS Portal" , MenuShortName = "HEDIS Portal" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4118, MenuName = "Auth/Referrals" , MenuShortName = "Auth/Referrals" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4119, MenuName = "Eligibility Status" , MenuShortName = "Eligibility Status" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4120, MenuName = "Claim Status Check" , MenuShortName = "Claim Status Check" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4121, MenuName = "Communication" , MenuShortName = "Communication" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 8 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4122, MenuName = "Membership List" , MenuShortName = "Membership List" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 9 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4123, MenuName = "Documents" , MenuShortName = "Documents" ,ParentMenuID = 4112, Icon = "", SiteID = SiteID , DisplayOrder = 10 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //menu 10
        //    {new Menu() { ID = 4124, MenuName = "Member Portal" , MenuShortName = "Member Portal" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 9 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4125, MenuName = "Bulletin Board" , MenuShortName = "Bulletin Board" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4126, MenuName = "Communication" , MenuShortName = "Communication" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4127, MenuName = "EOB's" , MenuShortName = "EOB's" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 2 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4128, MenuName = "ID Card" , MenuShortName = "ID Card" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 3 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4129, MenuName = "EOC" , MenuShortName = "EOC" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 4 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4130, MenuName = "Medical Records" , MenuShortName = "Medical Records" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 5 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4131, MenuName = "PCP Change Request" , MenuShortName = "PCP Change Request" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 6 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4132, MenuName = "Claims History" , MenuShortName = "Claims History" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 7 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4133, MenuName = "HEDIS Alerts" , MenuShortName = "HEDIS Alerts" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 8 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4134, MenuName = "Member Education" , MenuShortName = "Member Education" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 9 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4135, MenuName = "Bill Pay - pay premium" , MenuShortName = "Bill Pay - pay premium" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 10 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4136, MenuName = "Member Grievance" , MenuShortName = "Member Grievance" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 11 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4137, MenuName = "Provider Search/Directory" , MenuShortName = "Provider Search/Directory" ,ParentMenuID = 4124, Icon = "", SiteID = SiteID , DisplayOrder = 12 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    //Menu 11
        //    {new Menu() { ID = 4138, MenuName = "Help" , MenuShortName = "Help" ,ParentMenuID = 0, Icon = "glyphicons-user-key", SiteID = SiteID , DisplayOrder = 10 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //    {new Menu() { ID = 4139, MenuName = "Support" , MenuShortName = "Support - Search Screen" ,ParentMenuID = 4138, Icon = "", SiteID = SiteID , DisplayOrder = 0 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},
        //    {new Menu() { ID = 4140, MenuName = "Documentation" , MenuShortName = "Documentation" ,ParentMenuID = 4138, Icon = "", SiteID = SiteID , DisplayOrder = 1 , IsDelete = false , AngularTemplateUrl = "" , CreatedDate =  CreatedDate, CreatedByID = CreatedByID}},

        //};
    }
}
