export class LetterCorrespondance {
    letterCorrespondanceId: number;
    letterTypeId: number | null;
    letterType: string | null;
    memberId: number | null;
    letterGenerationDate: string | null;
    letterMailDate: string | null;
    responseDueDate: string | null;
    updatedDate: string | null;
    updatedBy: string;
    createdDate: string | null;
    createdBy: string;
    source: string;
    mbi: string | null;
}