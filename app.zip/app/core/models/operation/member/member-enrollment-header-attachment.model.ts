import { BaseModel } from "@app/core/models";
import { OtherDocument } from "./otherdocument.model";

export class MemberEnrollmentHeaderAttachmentModel extends BaseModel {
    memberEnrollmentHeaderAttachmentId: number;
    memberEnrollmentHeaderId: number;
    fileName: string;    
    enrollmentHeaderAttachment: File;
    fileLocation: string;    
    effectiveDate: Date;
    termDate: Date | null;    
    mbiNumber:string;
    containerName:string;
}

export class MemberEnrollmentHeaderAttachmentAndNoteModel{

    public MemberEnrollmentHeaderAttachmentAndNoteModel(){
        this.memberEnrollmentHeaderAttachmentModel = [];
        this.note = "";
    }

    memberEnrollmentHeaderAttachmentModel: OtherDocument[];
    note: string;
    mbiNumber:string;
    attachmentTypeId: number | null;
    attachmentTypeName: string | null;
    isReadOnly: boolean;
   
}
