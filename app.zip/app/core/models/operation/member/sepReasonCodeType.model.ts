import { BaseModel } from "../../common/base.model";

export class SEPReasonCodeTypeModel extends BaseModel{
    sepReasonCodeId: number;
    question: string;
    electionTypeCodeId: number;
    electionTypeCode: string;
    reasonCode: string;
    dateToBeEntered: number;
    oecSepReasonCodeMapping: string;
}