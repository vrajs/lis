export class SalesModel{
    enrollmentSource: number;
    enrollmentMechanism: number;
    salesAgentId: number;
    salesAgentName: string;
    saleDate: Date;
}