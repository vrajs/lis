import { OtherDocument } from './otherdocument.model';

export class DocumentList {
  constructor(
    public DocumentList: OtherDocument[],
  ) { }
}