export class TRRFalloutList {
    trrDetailLayoutID: number;
    mbi: string;
    transactionDate: string;
    fileName: string;
    transactionReplyCode: string;
    transactionReplyCodeDescription: string;
    falloutReason: string;
    trrFalloutStatus: number;
    memberId: number;
    transactionCode: string;
    pbpId:number;
}