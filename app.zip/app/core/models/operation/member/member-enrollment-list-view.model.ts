import { MemberEnrollmentList } from "./member-enrollment-list.model";

export class MemberEnrollmentListViewModel {
    memberEnrollmentList: MemberEnrollmentList[];
    totalCount: number;
}