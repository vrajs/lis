export class PlaceHolderReplaceViewModel {
    clientMemberId: string;
    primaryRxId: string;
    primaryRxGroup: string;
    primaryRxBIN: string;
    primaryRxPCN: string;
    firstName: string;
    middleInitial: string;
    lastName: string;
    contractDescription: string;
    pBPDescription: string;
    effectiveDate: string;
    partCPremiumAmount: number;
    partDPremiumAmount: number;
    lowIncomePartD: number;
    lowIncomeCoPay: number;
    ttyHoursOfOperation: string;
    ttyNumber: string;
}