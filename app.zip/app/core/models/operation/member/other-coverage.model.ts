export class OtherCoverageModel{
    enrolledInStateMedicaid: number;
    medicaidNumber: number;
    medicaidLevelForSNP: number;
    planSpecificChronicCondition: number;
    providerOfficeNameForVerification: string;
    providerOfficeAddress: string;
    providerOfficeCity: string;
    providerOfficeState: string;
    providerOfficeZip: string;
    providerOfficeContactPhone: number;
    longTermcare: string;
    longTermName: string;
    longTermAddress: string;
    longTermPhone: number;
    secondaryDrugBIN: number;
    secondaryDrugPCN: number;
    employerGroupNumber: number;
    employerGroupName: string;
    otherPrescriptionDrugCoverage: string;
    nameOfOtherCoverage: string;
    idForThisCoverage: number;
    groupNumberForThisCoverage: number;
}