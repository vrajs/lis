import { OECFileProcessModel } from "./oecfile-process-model.model";
import { OECLayoutListModel } from "./oeclayout-list-model.model";

export class OECLayoutFileDataModel {
    oecLayouts: OECLayoutListModel;
    oecFileProcessModel: OECFileProcessModel;
}
