export class OtherDocument {
  DocumentId: number;
  MemberID: number;
  DocumentName: string;
  DocumentContent: string;
  ContentType: string;
  IsDeleted: number;
  UpdatedDate: Date;
  UpdatedBy: string;
  CreatedDate: Date;
  CreatedBy: string;
  AttachmentType: string;
  FolderName: string;
}