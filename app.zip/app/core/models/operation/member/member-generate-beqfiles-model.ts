export class MemberGenerateBEQFilesModel {
    MemberTransactionDetailIds:number[]=[];
    PipelineName:string="";

    //ParameterName:string="";

}
