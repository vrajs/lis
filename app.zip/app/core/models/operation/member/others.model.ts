export class OthersModel{
    notes: string;
    attachmentTypeId: number | null;
    confirmationNumber: string;
}