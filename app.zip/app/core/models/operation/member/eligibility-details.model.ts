export class EligibilityDetailsModel{
    medicarePartAEffDate: Date;
    medicarePartBEffDate: Date;
    medicarePartDEffDate: Date;
    esrdFlag: boolean;
    employedStatus: boolean;
    spouseEmployedStatus: boolean;
    lisLevel: number;
}