import { BaseModel } from "../../common/base.model";

export class FileSubCategoryModel extends BaseModel{
    fileSubCategoryId: number;
    fileCategoryId: number;
    subCategoryName: string;
}