
export class ClaimNotesModel {
   
    public claimNotesId: number;
    public claimHeaderId: number;
    public memberId: number;
    public shortDesc: string;
    public longDesc: string;
    public noteDate: Date;
    public effectiveDate: Date;
    public termDate: Date;
    public addedSource: string;
    public userInitials: string;

    constructor() {        
        this.addedSource = '';
    }
}
