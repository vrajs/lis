﻿
export class ClaimUBCodesModel 
 {
                
    public claimUbCodesId: number ;
    
    public claimHeaderId: number ;
    
    public typeId: number ;

    public ubCode: string ;

    public description: string ;
    
    public fromDate: Date ;
    
    public toDate: Date ;
    
    public amount: number ; 
}