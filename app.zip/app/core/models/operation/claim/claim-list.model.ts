export class ClaimListModel {
    public claimHeaderID: number;
    public claimNumber: string;
    public claimStatusCode: string;
    public formType: string;
    public dosFrom: Date;
    public dosTo: Date;
    public receivedDate: Date;
    public formTypeID: number;
    public priorAuthNumber: string;
    public billedAmount: number;
    public paidAmount: number;
    public datePaid: Date;
    public checkNumber: number;
    public denyPendCode: string;
    public memberID: number;
    public memberCode: string;
    public memberName: string;
    public providerID: number;
    public providerCode: string;
    public providerName: string;
    public vendorName: string;
    public claimStatusID: number;
    public claimStatusCategory: string;
    public recordStatus: number;
}
