import { BaseModel } from '../../common/base.model';

export class ClaimReferenceModel extends BaseModel {
    claimReferenceId: number;
    claimHeaderId: number;
    memberId: number;
    controlTypeId: number;
    codeTypeId: number;
    codeValue: string;
    effectiveDate: Date;
    termDate?: Date;
    addedSource: string;

    constructor() {
        super();
        this.addedSource = '';
    }
}
