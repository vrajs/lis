﻿import { BaseModel } from "@app/core/models/common";

export class ClaimAuditModel extends BaseModel {
    claimAuditId: number;
    claimHeaderId: number;
    action?: number;
    userInitials?: string;
}