export class RefundLetter {
    public refundRequestClaimID: number;
    public refundRequestID: number;
    public vendorName: string;
    public address1: string;
    public address2: string;
    public city: string;
    public state: string;
    public zip: string;
    public memberName: string;
    public memberID: string;
    public claimNumber: string;
    public patientAccountNumber: string;
    public paidAmount: string;
    public paidDate: string;
    public requestedAmount: string;
    public refundReason: string;
    public attention: string;
    public requestDate: string;
    constructor() {
    this.refundRequestClaimID=0;
    this.refundRequestID=0;
    this.vendorName="N/A";
    this.address1="N/A";
    this.address2="N/A";
    this.city="N/A";
    this.state="N/A";
    this.zip="N/A";
    this.memberName="N/A";
    this.memberID="N/A";
    this.claimNumber="N/A";
    this.patientAccountNumber="N/A";
    this.paidAmount="N/A";
    this.paidDate="N/A";
    this.requestedAmount="N/A";
    this.refundReason="N/A";
    }
}
