export class RefundReceivedModel {
    refundReceivedId: number;
    refundRequestId: number;
    receivedDate: Date;
    receivedAmount: number;
    checkNo: number;
    checkDate: Date;
    //isPosted: number;
    postingTypeId?: number;
    //recoupmentAmount: number;
    stringCheckNo: string;
    constructor() {
        this.refundReceivedId = 0;
        this.stringCheckNo = "";
    }
}
