export class IPAModel {
    constructor() {}
    ipaid: number;    
    ipaCode: string;    
    ipaName: string;
    npi: string;
    contactName: string;    
    phone: string;    
    fax: string;    
    primaryEmail: string;    
    secondaryEmail: string;    
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}