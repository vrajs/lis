export class ProviderSpecialtyModel {
    providerSpecialtyId: number;
    providerId: number;
    specialtyId: number;
    isPrimarySpecialty: boolean = false;
    effectiveDate: Date;
    termDate: Date;
}