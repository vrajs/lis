import { BaseModel } from "../../common/base.model";
import { IPAModel } from "./ipa.model";

export class ProviderIPAModel extends BaseModel {    
    providerIPAId: number;    
    providerId: number;    
    ipaId: number;    
    effectiveDate: Date;    
    termDate: Date;
    ipa: IPAModel;

    constructor() {
        super();
        this.providerIPAId = 0;
    }
}
