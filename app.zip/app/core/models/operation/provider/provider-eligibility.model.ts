import { BaseModel } from "@app/core/models"

export class ProviderEligibility extends BaseModel {
    providerEligibilityId: number;
    providerId: number;
    providerEligibilityCode: string;
    effectiveDate: Date;
    termDate: Date;
    termReasonId:number;
    constructor() {
        super();
        this.providerEligibilityId = 0;
        this.providerEligibilityCode = '';
    }
}
