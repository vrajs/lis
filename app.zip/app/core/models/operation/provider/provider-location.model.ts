import { LocationModel } from "../../administration/masters/location.model";
import { BaseModel } from "../../common/base.model";
import { ProviderViewModel } from "./provider.model";


export class ProviderLocationModel extends BaseModel {
    providerLocationId: number;
    providerId: number;
    groupId?: number | null;
    locationId: number;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
    location?: LocationModel | null | undefined;
    provider?: ProviderViewModel | null | undefined;
}


export class ProviderLocationTerminateModel {
    groupId: number;
    locationId?: number | null;
    recordstatus: number
    recordStatusChangeComment: string;
    termDate: Date;
}
