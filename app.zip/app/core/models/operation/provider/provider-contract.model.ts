import { BaseModel } from "../../common/base.model";

export class ProviderContractModel {
    providerContractId: number;
    providerId: number;
    providerName: string;
    //groupId?: number | null;
    //groupProviderName: string;
    contractHeaderId: number;
    contractHeaderName: string;
    providerStatusId: number | null;
    providerStatusName: string;
    isCapitated: boolean;
    modifierDiscountGroupId?: number | null;
    modifierDiscountGroupName: string;
    feeScheduleHeaderId: number | null;
    feeScheduleHeaderCode: string;
    networkId: number | null;
    networkName: string;
    isExcludeFromSequestration: boolean;
    effectiveDate: Date;
    termDate: Date | null | undefined;

    lobIds: any[];
    lobNames: string;
    providerContractLob: Array<ProviderContractLobModel>;
    interestQuickPayIds: any[];
    interestQuickPayNames: string;
    providerContractInterest: Array<ProviderContractInterestModel>;
    timelyFilingIds: any[];
    timelyFilingNames: string;
    providerContractTimelyFiling: Array<ProviderContractTimelyFilingModel>;

    constructor() {
        this.lobIds = [];
        this.interestQuickPayIds = [];
        this.timelyFilingIds = [];
        this.providerContractLob = [];
        this.providerContractTimelyFiling = [];
        this.providerContractInterest = [];
    }
}

export class ProviderContractLobModel extends BaseModel {
    providerContractLOBId: number;
    providerContractId: number;
    lobId: number;
}

export class ProviderContractInterestModel extends BaseModel {
    providerContractInterestId: number;
    providerContractId: number;
    interestQuickPayId: number;
}

export class ProviderContractTimelyFilingModel extends BaseModel {
    providerContractTimelyFilingId: number;
    providerContractId: number;
    timelyFilingId: number;
}
