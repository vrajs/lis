export class BlobInformationModel {
    fileName:string;
    metadataJson : string;
    uri:string;
    containerName: string
}