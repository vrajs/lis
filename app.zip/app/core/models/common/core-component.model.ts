import { AppConstant, Utils } from "@app/common/app-global";
import { environment } from "@environments/environment";

export class CoreComponentModel {
    constructor() { }

    get enviourment(): any {
        return environment;
    }

    get utils(): any {
        return Utils;
    }

    get appConstant(): any{
        return AppConstant;
    }
}