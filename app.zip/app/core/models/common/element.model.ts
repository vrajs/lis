export class ElementModel {
    elementId: number;
    loop: string;
    loopGroup: string;
    segment: string;
    segmentSequence: number;
    segmentoccurrenceSeq: number;
    elementDescription: string;
    mappedElementDescription: string;
    elementPosition: number;
    subElementPosition: number;
    elementValue: string;
    elementUsage: string;
    elementMinLength: number;
    elementMaxLength: number;
    elementDataType: string;
    elementValueType: string;
    elementValueSourceTable: string;
    ediFormat: string;
    recordStatus: number;
    createdBy: string;
    createdDate: Date;
    updatedBy: string;
    updatedDate: Date;
    mappedType: string;
    childElementId: number;
    comments: string;
    sourceField: string;
}

