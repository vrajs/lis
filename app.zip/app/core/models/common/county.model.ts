export class CountyModel{
    county: string | null;
    recordStatus: string | null;
}