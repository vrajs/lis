import { HttpParams } from "@angular/common/http";
import { Type } from "@angular/core";
import { SafeHtml } from "@angular/platform-browser";
import { HpsGridCellSelection, HpsGridDataSourceType, HpsGridDisplayDensity, HpsGridFieldType, HpsGridFilterMode, HpsGridPagingMode, HpsGridRowSelection, HTTRequestType } from "@app/common/app-global";
import { NoopFilteringStrategy, NoopSortingStrategy } from "@infragistics/igniteui-angular";
import { Observable } from "rxjs";

export class HpsIgxGridOption {
    public dataSource: HpsGridDataSource;
    public columns: Array<HpsGridColumn>;
    public globalOption: HpsGridGlobalOption;
    public paging: HpsGridPaging;
    public soring: HpsGridSorting
}

export class HpsGridColumn {
    public field: string;
    public displayName: string;
    public enableSorting?: boolean;
    public headerTemplate?: string;
    public templateComponent?: Type<any>;
    public hidden: boolean;
    public width?: string;
    public fieldType: HpsGridFieldType;
    public dateFormat?: string;
    public trustedTemplate?: SafeHtml;
    public sortable: boolean;
    public filterable: boolean;
    // public multipleFields?:Array<MultiColumnSortClass>;
    public enableMultiColumnSort?: boolean = false;
    public headerTemplateComponent?: Type<any>;
    public isActionEnable?: boolean = false;
    public defaultText?: string = "";
    public enableTemplateHeaderMultiCoulmnSort?: boolean = false;
    public customeFunction?: any;
    public isTemplate?: boolean = false;
    public visibleIndex?: number;
    public format?: string;
    public editable?: boolean = false;
    public hasSummary?: boolean = false;
    public summaries?: any;
}



export class HpsGridDataSource {
    public dataSourceType: HpsGridDataSourceType;
    public dataSource: Function;
    public requestType?: HTTRequestType;
    public params?: Observable<HttpParams>;
}

export class HpsGridGlobalOption {

    // public noopFilterStrategy = NoopFilteringStrategy.instance();
    // public noopSortStrategy = NoopSortingStrategy.instance();

    constructor() {
        this.primaryKey = 'id';
        this.displayDensity = HpsGridDisplayDensity.Cosy;
        this.allowFiltering = true;
        this.autoGenerate = false;
        this.hideRowSelectors = true;
        this.cellSelection = HpsGridCellSelection.None;
        this.filterMode = HpsGridFilterMode.ExcelStyleFilter;
        this.allowAdvancedFiltering = false;
        this.rowSelection = HpsGridRowSelection.Single;
        this.pagingMode = HpsGridPagingMode.Local;
        this.filterStrategy = null;
        this.sortStrategy = null;
        this.rowEditable = false;
        this.rowDraggable = false;
    }

    public primaryKey: string;
    public displayDensity: string;
    public allowFiltering: boolean;
    public autoGenerate: boolean;
    public hideRowSelectors: boolean;
    public cellSelection: string;
    public rowSelection: string;
    public filterMode: string;
    public allowAdvancedFiltering: boolean;
    public rowEditable?: boolean;
    public pagingMode?: number;
    public filterStrategy?: NoopFilteringStrategy | null;
    public sortStrategy?: NoopSortingStrategy | null;
    public rowDraggable?: boolean;
}

export class HpsGridSorting {
    public enable: boolean;
    public defultSortColumn?: string;
    public defultSortDirection?: string;
}

export class HpsGridPaging {
    public enable: boolean;
    public defaultPageSize?: number;
    public pageSizes?: number[];
}