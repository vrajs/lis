export class GridFilter {
    skip: number;
    take: number;
}