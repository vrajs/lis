export class OData<T> {

    constructor(oDataModel: any){
        this.totalCount = oDataModel.odataCount;
        this.dataList = oDataModel.value;
    }

    public totalCount: number;
    public dataList: T[];
}