import { BaseModel } from "./base.model";

export class CodeTypeModel extends BaseModel{
    code: string;
    codeTypeId: number;
    effectiveDate: string;
    longDescription: string;
    shortName: string;
    termDate: string;
    createdBy: string;
    rowVersion: string;
    recordStatus: number;
    recordStatusChangeComment: string;

}