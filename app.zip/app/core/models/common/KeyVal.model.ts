export class KeyValModel {
    key: any;
    value: any;
}