export class TerminateModel {
    id: number;
    name: string;
    termReason: string;
    termDate: Date;
    showTermMessage: boolean;
}