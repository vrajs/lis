import { BaseModel } from "@app/core/models/common/base.model";

export class CommonCodeModel extends BaseModel {
    public commonCodeId: number;
    public addedSource: string | '';
    public charValue: string | undefined; 
    public code: string | undefined; 
    public codeTypeId: number | undefined;
    public codeType: string | undefined;
    public displayOrder: number | undefined;
    public effectiveDate: Date | undefined;
    public isFreezed: number | undefined;
    public loadComment: string | undefined;
    public longDescription: string | undefined;
    public numericValue: number | undefined;
    public otherValue: string | undefined;
    public shortName: string;
    public termDate: Date | undefined;
    public controlTypeId: number | undefined;
    public isDisable: boolean | undefined;
    public defaultValue: number | string;

    constructor() {
        super();
        this.commonCodeId = 0;
        this.charValue = "";
        this.longDescription = "";
    }
}
export class MemberStatus {
    MemberStatusID: number;
    MemberStatus: string;
  }
  
 
