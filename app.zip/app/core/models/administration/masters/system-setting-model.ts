import { BaseModel } from "@app/core/models"

export class SystemSettingModel extends BaseModel {
      public id: number
      public settingCode: string;
      public description: string;
      
      public numericValue:  number;
      public stringValue:  string;
      public bitValue:  boolean;
      public dateValue: Date;
      public timeValue: string;
      public isOneTimeOnly: boolean;
      constructor() {
            super();
        }
    
}
