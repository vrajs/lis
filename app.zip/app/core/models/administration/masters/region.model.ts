import { BaseModel } from "../../common/base.model";

export class RegionModel extends BaseModel {
    public regionId: number;
    public typeId: number;
    public productTypeName: string;
    public state: string;
    public stateFullName: string;
    public code: string;
    public name: string;
    public effectiveDate: Date;
    public termDate?: Date | null | undefined;
    public productTypeId: number;
    public countyList: string[] | null | undefined;
    public cityList: string[] | null | undefined;
    public county: string;
    public city: string;

    constructor() {
        super();
        this.regionId = 0;
    }
}
