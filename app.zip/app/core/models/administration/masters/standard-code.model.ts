import { AppConstant } from '@app/common/app-global';
import { BaseModel } from '@app/core/models'

export class StandardCodeModel extends BaseModel {
    public standardCodeId: number;
    public code: string;
    public clinicalCodeTypeId: number;
    public shortDescription: string;
    public longDescription: string;
    public homeGrown: string;
    public effectiveDate: Date;
    public termDate: Date | null;
    public formattedEffectiveDate: string | null;
    public formattedTermDate: string | null;
    constructor() {
        super();
        this.homeGrown = "N";
        this.standardCodeId = 0;
    }
}

export class CPTCodeModel extends StandardCodeModel {
    public gender: string;
    public cptCodeId: number;

    constructor() {
        super();
        this.cptCodeId = 0;
        this.gender = AppConstant.defaultGender;
    }
}

export class ICDCodeModel extends StandardCodeModel {
    public icdCodeId: number;
    constructor() {
        super();
        this.icdCodeId = 0;
    }
}

export class RevenueCodeModel extends StandardCodeModel {
    public revenueCodeId: number;
    constructor() {
        super();
        this.revenueCodeId = 0;
    }
}

export class POSCodeModel extends StandardCodeModel {
    public posCodeId: number;
    public facilityNonFacility: string;
    constructor() {
        super();
        this.posCodeId = 0;
    //    this.facilityNonFacility = "F";
    }
}

export class NDCCodeModel extends StandardCodeModel {
    public ndcCodeId: number;
    public dosageForm: string;
    public route: string;
    public strength: string;
    public unit: string;
    public ndcType: string;
    constructor() {
        super();
        this.ndcCodeId = 0;
    }
}

export class BillTypeCodeModel extends StandardCodeModel {
    public billTypeCodeId: number;
    constructor() {
        super();
        this.billTypeCodeId = 0;
    }
}

export class DRGCodeModel extends StandardCodeModel {
    public drgCodeId: number;
    public drgType: string;
    public majorCategory: string;
    constructor() {
        super();
        this.drgCodeId = 0;
    }
}

export class HCCCodeModel extends StandardCodeModel {
    public hccCodeId: number;
    constructor() {
        super();
        this.hccCodeId = 0;
    }
}
