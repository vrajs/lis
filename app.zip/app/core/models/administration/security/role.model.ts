import { RoleTypeClaimModel } from "@app/core/models";

export class RoleModel {
    id: string | null;
    name: string;
    description: string;
    userCount: number;
    isFreezed: number;
    roleTypeID: number;
    roleType: string;
    permissions: RoleTypeClaimModel[];
}
