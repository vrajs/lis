export class ClientUserModel {
    id: number;
    userId: string;
    clientId: number;
    clientName: string;
    userName: string;
    startDate: Date | string;
    endTime: Date | string | null;
    acceptedCode: string | null;
    rejectedCode: string | null;
    isDeleted: boolean;
    isActive: boolean;
    code: string; 
    isAccepted: boolean;
    isRegisterdUser: boolean;
    createdById: string;
    createdBy: string;
    createdDate: Date | string;
    updatedById: string;
    updatedBy: string;
    updatedDate: string;
}