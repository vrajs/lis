export class UserPermissionModel {
    public roleTypeClaimsID: number;
    public value: string;    
    public name: string;
    public roleTypeID: string;
    public roleTypeName: string;
    public description: string;
}