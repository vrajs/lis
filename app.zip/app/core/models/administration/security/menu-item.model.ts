export interface MenuItem {
    claimValue: string;
    id: string;
    title: string;
    icon: string;
    route: string;
    type: string;
    submenu: Array<MenuItem>;

}
