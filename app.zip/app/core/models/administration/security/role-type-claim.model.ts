export class RoleTypeClaimModel {
    public roleTypeClaimsID: number;
    public roleTypeID: string;
    public claimValue: string;
    public name: string;        
    public description: string;
    public moduleID?: number;
    public menuID?: number;

    public roleTypeName: string;
    public moduleName: string;
    public menuName: string;
}
