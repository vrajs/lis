export interface IconFiles{
    imageFile: string,
    alt: string,
    link: string
}