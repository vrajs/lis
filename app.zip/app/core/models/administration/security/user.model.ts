export class UserModel {
    // Note: Using only optional constructor properties without backing store disables typescript's type checking for the type
    constructor(id?: string, userName?: string, fullName?: string, email?: string, jobTitle?: string, phoneNumber?: string, roles?: string[], image?: string, displayName?: string) {

        this.id = id;
        this.userName = userName;
        this.fullName = fullName;
        this.email = email;
        this.jobTitle = jobTitle;
        this.phoneNumber = phoneNumber;
        this.roles = roles;
        this.isEnabled = true;
        this.image = image;;
        this.displayName = displayName;
    }


    get friendlyName(): string {
        let name = this.fullName || this.userName;

        if (this.jobTitle)
            name = this.jobTitle + " " + name;

        return name;
    }


    public id: string;
    public userName: string;
    public fullName: string;
    public displayName: string;
    public email: string;
    public jobTitle: string;
    public phoneNumber: string;
    public isEnabled: boolean;
    public isLockedOut: boolean;
    public isActiveDirectoryUser: boolean;
    public roles: string[];

    public dataPreferenceByID: number;
    public dataPreferenceIDs: number[];

    //extra columns    
    public dob?: Date;    
    public gender: string;    
    public address1: string;    
    public address2: string;    
    public city: string;    
    public state: string;    
    public county: string;    
    public country: string;    
    public zip: string;    
    public ssn: string;    
    public race: string;    
    public ethnicity: string;
    public image: string = "assets/images/avatars/brian-hughes.jpg";
    public clientName: string;
    acceptedCode: string | null;        
    rejectedCode: string | null;        
    public createdById: string;
    public recordStatusChangeComment: string = "";
}
