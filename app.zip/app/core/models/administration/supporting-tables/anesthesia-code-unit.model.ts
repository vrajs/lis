export class AnesthesiaCodeUnitModel {
    public anesthesiaCodeUnitId: number;    
    public cptCode: string;
    public baseUnit: number;
    public productId: number;
    public productName: string;
    public clinicalCodeTypeIds: string;
    public effectiveDate: Date;
    public termDate?: Date | undefined | null;
}
