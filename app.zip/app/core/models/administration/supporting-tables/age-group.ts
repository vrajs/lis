export class AgeGroupModel 
 {
ageGroupId:number;
typeId: number;
ageGroupType: string;
code:string;
ageFrom: number;
ageTo: number;
effectiveDate: string;
termDate: string | null;
}
