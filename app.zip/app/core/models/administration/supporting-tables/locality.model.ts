export class LocalityModel {    
    public localityId: number;    
    public carrier: string;    
    public localityCode: string;    
    public county: string;    
    public state: string;    
    public area: string;    
    public effectiveDate: Date;
    public termDate?: Date | undefined | null;
}
