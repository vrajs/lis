export class RBRVSCodeModel{
    public rbrvsCodeId: number;    
    public typeName: string;
    public typeNumber: number;    
    public code: string;
    public isIncludePricing: boolean;
    public isProviderException: boolean;    
    public shortDescription: string;    
    public longDescription: string;
}
