import { BaseModel } from "../../common/base.model";

export class MemberCapitationModel extends BaseModel {
    public membershipCapitationId: number;
    public capitationHeaderId: number;
    public startMembership: number;
    public endMembership: number;
    public rate: number;
    public effectiveDate: Date;
    public termDate: Date;
}