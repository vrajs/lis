export class RequestParam {
    operation: string;
    Tid: number;
    FileTypeName: string;
    TPName: string;
}
export class DataconfigModel {
    dataFileConfigurationId: number;
    fileNamingConventionId: number;
    tranTypeId: number;
    isStandardFile: boolean;
    fileTypeId: number;
    effectiveDate: Date;
    termDate: Date;
    tradingPartnerId: number;
    isa15UsageIndicator: string;
    versionIdentifierCode: string;
    isa06SenderId: string;
    isa08ReceiverId: string;
}

export class TradingPartnerListModel {
    tradingPartnerId: number;
    tradingPartnerName: string;
    tradingPartnerCode: string;
    contactPersonName: string;
    effectiveDate: Date;
    termDate: Date;
    dataconfigList: DataconfigModel[];
}

export class TradingPartnerModel {
    public tradingPartnerId: number;
    public tradingPartnerTypeId: number;
    //public SubCompanyId: number;
    public tradingPartnerCode: string;
    public tradingPartnerName: string;
    public contactPersonName: string;
    public address1: string;
    public address2: string;
    public city: string;
    public state: string;
    public zip: string;
    public phone: string;
    public fax: string;
    public effectiveDate: Date;
    public termDate: Date;
    public recordStatus: number;
    public isFreezed: number;
    public recordStatusChangeComment: string;
    public createdBy: string;
    public createdDate: Date;
    public updatedBy: string;
    public updatedDate: Date;
}

export class FileNamingConventionModel {
    public dataFileConfigurationId: number;
    public fileNamingConventionId: number;
    public prefix: string;
    public dateTimeFormat: string;
    public randomNumber: string;
    public tpName: boolean;
    public fileType: boolean;
    public fileExtension: string;
    public nameSeparator: number;
    public fileNamingSequenceModel: FileNamingSequenceModel[];   
}
export class FileNamingSequenceModel {
    public fileNamingSequenceId?: number;
    public fileNamingConventionId?: number;
    public columnName: string;
    public sequenceNumber: number;
}
export class FileNamingSequenceModelMap {   
    public Prefix: number;
    public DateTimeFormat: number;
    public RandomNumber: number;
    public FileExtension: number;
    public NameSeparator: number;
    public FileType: number;
    public TPname: number;  
}
export class chkboxFileNamingSequenceModel {
    public isDefault: boolean;
    public isPrefix: boolean;
    public isDateTimeFormat: boolean;
    public isRandomNumber: boolean;
    public isFileExtension: boolean;
    public isNameSeparator: boolean;   
}

export class classEx {
    static getNamesAndValues<T extends number>(e: any) {
        return classEx.getNames(e).map(n => ({ key: n, value: e[n] as T }));
    }

    static getNames(e: any) {
        return classEx.getObjValues(e).filter(v => typeof v === "string") as string[];
    }

    static getValues<T extends number>(e: any) {
        return classEx.getObjValues(e).filter(v => typeof v === "number") as T[];
    }

    private static getObjValues(e: any): (number | string)[] {
        return Object.keys(e).map(k => e[k]);
    }
}
