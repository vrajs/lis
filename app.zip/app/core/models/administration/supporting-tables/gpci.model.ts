export class GPCIModel {
    public gpciid: number;    
    public carrier: string;    
    public localityCode: string;    
    public localityName: string;    
    public work: number;    
    public pe: number;    
    public mp: number;    
    public effectiveDate: Date;
    public termDate?: Date | undefined | null;
}
