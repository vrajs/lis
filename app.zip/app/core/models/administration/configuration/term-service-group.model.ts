import { BaseModel } from '@app/core/models';

export class TermServiceGroupModel extends BaseModel {
    termServiceGroupId: number;
    termHeaderId: number;
    clinicalCodeGroup: string;
    clinicalCodeGroupDetail: string;
    clinicalCodeGroupDetailId?: number;
    clinicalCodeGroupId?: number;
    clinicalCodeSubGroup: string;
    clinicalCodeSubGroupId?: number;
    isExclude: boolean = false;
    effectiveDate: Date;
    termDate?: Date | null | undefined; 
}
