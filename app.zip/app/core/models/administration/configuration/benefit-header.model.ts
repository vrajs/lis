import { BaseModel, BenefitProviderSpecialtyModel } from '@app/core/models';

export class BenefitHeaderModel extends BaseModel {
    benefitHeaderId: number;   
    benefitCode: string;
    benefitName: string;
    benefitLongDescription?: string | null | undefined;
    remitReason?: string | null | undefined;
    eobReason?: string | null | undefined;
    claimTypeId?: number | null | undefined;
    providerStatusId?: number | null | undefined;
    providerTypeId?: number | null | undefined;
    ageFrom: number;
    ageTo: number;
    gender: string;
    networkId?: number | null | undefined;
    serviceTypeCodeId?: number | null | undefined;
    isAuthRequired: boolean = false;
    isManualReview: boolean = false;
    isEmergency: boolean = false;
    isMemberPcp: boolean = false;
    isPcp: boolean = false;
    isCoinsurance: boolean = false;
    isCopay: boolean = false;
    isVisitLimit: boolean = false;
    isDeductible: boolean = false;
    isMaxOop: boolean = false;    
    effectiveDate: Date;
    termDate : Date | null | undefined;
    benefitProviderSpecialties: Array<BenefitProviderSpecialtyModel>;
    benefitProviderSpecialtyIds: number[];

    benefitCategoryId: number;
    benefitCategoryName: string;
    termReason: string;

    constructor() {
        super();
        this.benefitProviderSpecialties = [];
    }
}

export class BenefitHeaderHealthPlanTermModel {
    benefitHeaderId: number[];
    healthPlanId: number[];
    termReason: string;
    termDate: Date;
    recordStatus: number;

    constructor() {
        this.benefitHeaderId = [];
        this.healthPlanId = [];
    }
}

export class BenefitHeaderDialogModel{
    public benefitHeaderModel: BenefitHeaderModel;
}

export class TerminateBenefit {
    id: number;
    termReason: string;
    termDate: Date;
}

