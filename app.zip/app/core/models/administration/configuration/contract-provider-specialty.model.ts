import { BaseModel } from '@app/core/models';

export class ContractCliamTypeModel extends BaseModel{
    claimTypeId: number;
    contract:string;
    contractClaimTypeId: number;
    contractId:number;
}