export class RuleHeaderClaimAddressModel {

    public ruleHeaderClaimAddressId: number;
    public ruleHeaderId: number;
    public name: string;
    public address1: string;
    public address2: string;
    public city: string;
    public state: string;
    public county: string;
    public country: string;
    public zip: string;
    public phone: string;
    public fax: string;
    public email: string;
    public effectiveDate: Date;
    public termDate?: Date;

    constructor() {
        this.ruleHeaderClaimAddressId = 0;
        this.ruleHeaderId = 0;
        this.name = "";
        this.address1 = "";
        this.address2 = "";
        this.city = "";
        this.state = "";
        this.zip = "";
        this.phone = "";
        this.fax = "";
        this.email = "";
    }
}
