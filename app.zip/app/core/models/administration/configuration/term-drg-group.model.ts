import { BaseModel } from "../../common/base.model";

export class TermDrgGroupModel extends BaseModel{
    drgGroupDetails: number[];
    drgGroupHeaderId: number;
    drgGroupName: string;
    effectiveDate: Date;
    termDate: Date;
    termPayments: number[]
}