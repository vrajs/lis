import { BaseModel } from '@app/core/models';

export class BenefitProviderSpecialtyModel extends BaseModel{
    benefitProviderSpecialtyId: number;
    benefitHeaderId: number;
    specialtyId: number;
    specialtyName: string;
}