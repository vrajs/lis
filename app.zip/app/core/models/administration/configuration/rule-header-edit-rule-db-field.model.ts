import { DBFieldAllowedOperatorModel } from "./db-field-allowed-operator.model";

export class RuleHeaderEditRuleDBFieldModel {
    public dbFieldId: number;
    public controlTypeId: number;
    public fieldDisplayName: string;
    public claimApplyLevel: number;
    public isLovs: boolean;
    public isMultiSelectOptions: boolean;
    public customLovs: string;
    public allowedOperator: string;
    public allowedOperators: DBFieldAllowedOperatorModel[];
}
