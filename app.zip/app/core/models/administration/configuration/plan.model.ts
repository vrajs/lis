export class GetPlanModel {
    healthPlanId: number;
    planCode: string;
    planName: string;
    lob: string;
    pbpCode: string;
    productType: string;
    state: string;
    county: string;
    company: string;
    subCompany: string;
    effectiveDate: Date;
    termDate: Date;
    approvalDate: Date;
    approvalStatus: string;
    recordStatus: boolean;
    lobId: number;
    subCompanyRecordStatus: boolean;
    companyRecordStatus: boolean;
}

export class Plan {
    healthPlanID: number;
    companyID: number;
    subCompanyID: number;
    lobID: number;
    productTypeID: number;
    pbpCode: string;
    planCode: string;
    planName: string;
    planDescription: string;
    state: string;
    county: string;
    approvalDate: Date | null;
    approvalStatusID: number | string;
    effectiveDate: Date;
    termDate: Date | null;
    createdBy: string;
    createdDate: Date;
    updatedBy: string;
    updatedDate: Date | null;
    isFreezed: number;
    recordStatus: number;
    recordStatusChangeComment: string;
    counties: string[];
    constructor() {
        this.createdBy = '';
        this.healthPlanID = 0;
        this.recordStatus = 0;
        this.recordStatusChangeComment = '';
        this.state = '';
        this.county = '';
        this.pbpCode = '';
        this.planDescription = '';
    }
}

export class PlanViewModel {

    company: string;
    subCompany: string;
    lob: string;
    productType: string;
    pbpCode: string;
    planCode: string;
    planName: string;
    state: string;
    county: string;
    effectiveDate: Date;
    termDate: Date;
    approvalDate: Date;
    approvalStatus: string;
    constructor() {

    }

}