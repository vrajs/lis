import { BaseModel } from "../../common/base.model";

export class CapitationModel extends BaseModel{
    capitationCode: string;
    capitationDescription: string;
    capitationHeaderId: number;
    capitationName: string;
    capitationType: string;
    effectiveDate: Date;
    termDate?: Date;
}