export class RuleHeaderFeeScheduleModel {
    public ruleHeaderFeeScheduleId: number;
    public ruleHeaderId: number;
    public claimTypeId: number;
    public contractId: number;
    public contractDescription: string;
    public providerTypeId: number;
    public effectiveDate: Date;
    public termDate?: Date;
}
