import { BaseModel } from "../../common/base.model";
import { ContractCliamTypeModel } from "./contract-provider-specialty.model";

export class ContractHeaderModel extends BaseModel{
    anesConversionFactor:string;
    anesConversionFactorId: number;
    capitationCode: string;
    capitationId: number;
    contractCode: string;
    contractDescription: string;
    contractHeaderId: number;
    contractName: string;
    contractClaimType: Array<ContractCliamTypeModel>;
    contractClaimTypeId:number[];
    effectiveDate: Date;
    termDate?: Date;
    contractId: number;
    providerContract:[];
    ruleHeaderFeeSchedules: [];
    termHeader: [];

    constructor() {
        super();
        this.contractClaimType = [];
    }
}


export class TerminateContractModel {
    id: number;
    termReason: string;
    termDate: Date;
}