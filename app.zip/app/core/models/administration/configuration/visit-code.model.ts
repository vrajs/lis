import { BaseModel } from '@app/core/models'

export class VisitCodeModel extends BaseModel {
    visitCodeId: number;
    code: string;
    description: string;
    visitTypeId: number;
    visitType: string;
    maxUnits?: number | null | undefined;
    timePeriodId: number;
    timePeriod: string;
    benMaxUnit?: number | null | undefined;
    beneMaxTimePeriodId?: string | null | undefined;
    beneMaxTimePeriod: string;
    isServiceOutsideUs: boolean = false;
    maxAmount?: number | null | undefined;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}