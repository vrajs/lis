export class RuleHeaderTimelyFilingModel {
    public ruleHeaderTimelyFilingId: number;
    public ruleHeaderId: number;
    public timelyFilingId: number;
    public timelyFilingDesc: string;
    public effectiveDate: Date;
    public termDate?: Date;
}
