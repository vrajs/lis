import { KeyValModel } from "../../common/KeyVal.model";

export class RuleHeaderEditRuleCriteriaModel {
    public ruleHeaderEditRuleId: number;
    public dbFieldId: number;
    public controlTypeId: number;
    public fieldName: string;
    public operator: string;
    public isMultiSelectOptions: boolean;
    public values: any;
    public igcomCriteriaValuesOptions: any;
    public igcomCriteriaOperatorOptions: any;
    public igcomCriteriaFieldOptions: any;
    public igcomValues: KeyValModel[];
    constructor() {
        this.ruleHeaderEditRuleId = 0;
        this.controlTypeId = -1;
        this.igcomValues = [];
    }
}
