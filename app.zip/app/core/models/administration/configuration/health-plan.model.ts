import { BaseModel } from '@app/core/models';

export class HealthPlanModel extends BaseModel {
    approvalDate: Date;
    approvalStatusId: number;
    companyId: number;
    counties: any;
    county: string;
    createdBy: string;
    effectiveDate: Date;
    healthPlanId: number;
    lobId: number;
    pbpCode: string;
    planCode: string;
    planDescription: string;
    planName: string;
    productTypeId: number;
    recordStatus: number;
    recordStatusChangeComment: string;
    state: string;
    subCompanyId: number;
    termDate: Date;
}