import { KeyValModel } from "../../common/KeyVal.model";

export class ConfigureBenefitProrityForClaimViewModel {
    healthPlanID: number;
    listBenefit: KeyValModel[];
}