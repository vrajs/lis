import { BaseModel } from "../../common/base.model";

export class BenefitHeaderHealthPlan extends BaseModel {
    benefitHeaderHealthPlanId: number;
    benefitHeaderId: number;
    healthPlanId: number;
    effectiveDate: Date;
    termDate: Date;
    claimHitPriority: number;
}