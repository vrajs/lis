import { HostListener } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { FuseConfigService } from '@fuse/services/config/config.service';
import { Layout } from 'app/layout/layout.types';

// Types
export type Scheme = 'auto' | 'dark' | 'light';
export type Screens = { [key: string]: string };
export type Theme = 'theme-default' | string;
export type Themes = { id: string; name: string }[];
export type Density = 'cosy' | 'compact' | 'comfortable';

/**
 * AppConfig interface. Update this interface to strictly type your config
 * object.
 */
export class AppConfig {
    layout: Layout;
    scheme: Scheme;
    screens: Screens;
    theme: Theme;
    themes: Themes;
    density: Density;
}

/**
 * Default configuration for the entire application. This object is used by
 * FuseConfigService to set the default configuration.
 *
 * If you need to store global configuration for your app, you can use this
 * object to set the defaults. To access, update and reset the config, use
 * FuseConfigService and its methods.
 *
 * "Screens" are carried over to the BreakpointObserver for accessing them within
 * components, and they are required.
 *
 * "Themes" are required for Tailwind to generate themes.
 */
export const appConfig: AppConfig = {
    layout: 'dense',
    scheme: 'light',
    theme: 'theme-default',
    density: 'compact',
    screens: {
        sm: '600px',
        md: '960px',
        lg: '1280px',
        xl: '1440px',
    },
    themes: [
        {
            id: 'theme-default',
            name: 'Default',
        },
        {
            id: 'theme-brand',
            name: 'Brand',
        },
        {
            id: 'theme-teal',
            name: 'Teal',
        },
        {
            id: 'theme-rose',
            name: 'Rose',
        },
        {
            id: 'theme-purple',
            name: 'Purple',
        },
        {
            id: 'theme-amber',
            name: 'Amber',
        },
        {
            id: 'theme-orange',
            name: 'Orange',
        },
        {
            id: 'theme-fuchsia',
            name: 'Fuchsia',
        },
        {
            id: 'theme-barberry',
            name: 'Barberry',
        },
    ],
};

export function designConfig(): AppConfig {
    var design: AppConfig = null;
    var themeSchemeAndLayout = localStorage.getItem('themeSchemeAndLayout');
    var setDesign: AppConfig = JSON.parse(themeSchemeAndLayout);

    if (!Utils.isBlank(setDesign)) {
        design = {
            layout: setDesign.layout,
            scheme: setDesign.scheme,
            theme: setDesign.theme,
            density: setDesign.density,
            screens: {
                sm: '600px',
                md: '960px',
                lg: '1280px',
                xl: '1440px',
            },
            themes: [
                {
                    id: 'theme-default',
                    name: 'Default',
                },
                {
                    id: 'theme-brand',
                    name: 'Brand',
                },
                {
                    id: 'theme-teal',
                    name: 'Teal',
                },
                {
                    id: 'theme-rose',
                    name: 'Rose',
                },
                {
                    id: 'theme-purple',
                    name: 'Purple',
                },
                {
                    id: 'theme-amber',
                    name: 'Amber',
                },
                {
                    id: 'theme-orange',
                    name: 'Orange',
                },
                {
                    id: 'theme-fuchsia',
                    name: 'Fuchsia',
                },
                {
                    id: 'theme-barberry',
                    name: 'Barberry',
                },
            ],
        };
    } else {
        design = {
            layout: 'dense',
            scheme: 'light',
            theme: 'theme-default',
            density: 'compact',
            screens: {
                sm: '600px',
                md: '960px',
                lg: '1280px',
                xl: '1440px',
            },
            themes: [
                {
                    id: 'theme-default',
                    name: 'Default',
                },
                {
                    id: 'theme-brand',
                    name: 'Brand',
                },
                {
                    id: 'theme-teal',
                    name: 'Teal',
                },
                {
                    id: 'theme-rose',
                    name: 'Rose',
                },
                {
                    id: 'theme-purple',
                    name: 'Purple',
                },
                {
                    id: 'theme-amber',
                    name: 'Amber',
                },
                {
                    id: 'theme-orange',
                    name: 'Orange',
                },
                {
                    id: 'theme-fuchsia',
                    name: 'Fuchsia',
                },
                {
                    id: 'theme-barberry',
                    name: 'Barberry',
                },
            ],
        };
    }

    return design;
}

export function disDensity() {
    var newDensity = designConfig().density;
    return newDensity;
}
