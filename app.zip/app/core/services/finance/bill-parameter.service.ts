import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BillParameterModel } from '@app/core/models/finance';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable()
export class BillParameterService {

    apiBaseUrl: string = '/api/BillParameter';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<BillParameterModel[]> {
        return this.httpClient.get<BillParameterModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}`);
    }

    getById(BillParameterID: number): Observable<BillParameterModel> {
        return this.httpClient.get<BillParameterModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${BillParameterID}`);
    }

    create(BillParameterModel: BillParameterModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, BillParameterModel);
    }

    update(BillParameterModel: BillParameterModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, BillParameterModel);
    }

    delete(BillParameterModelID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${BillParameterModelID}`);
    }
}
