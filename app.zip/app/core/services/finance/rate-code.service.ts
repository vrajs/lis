import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RateCodeModel } from '@app/core/models/finance';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable()
export class RateCodeService {

    apiBaseUrl: string = '/api/RateCode';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<RateCodeModel[]> {
        return this.httpClient.get<RateCodeModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}`);
    }

    getById(RateCodeID: number): Observable<RateCodeModel> {
        return this.httpClient.get<RateCodeModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${RateCodeID}`);
    }

    create(RateCodeModel: RateCodeModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, RateCodeModel);
    }

    update(RateCodeModel: RateCodeModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, RateCodeModel);
    }

    delete(RateCodeModelID: number) {
        return this.httpClient.delete(`${environment}${this.apiBaseUrl}/${RateCodeModelID}`);
    }
}
