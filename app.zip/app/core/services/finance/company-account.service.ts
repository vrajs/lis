import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { CompanyAccountModel } from '@app/core/models';

@Injectable()
export class CompanyAccountService {

  constructor(private httpClient: HttpClient) {
  }

  /**
   * Purpose: Method is use to get account list
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get account list
   */
  get(): Observable<CompanyAccountModel[]> {
    return this.httpClient.get<CompanyAccountModel[]>(`${environment.serviceApiUrl}/api/AccountDetailCompanyStructure`);
  }

  /**
   * Purpose: Method is use to get account list by id
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get account list by id
   */
  getById(accountDetailCompanyStructureID: number): Observable<CompanyAccountModel> {
    return this.httpClient.get<CompanyAccountModel>(`${environment.serviceApiUrl}/api/AccountDetailCompanyStructure/${accountDetailCompanyStructureID}`);
  }

  /**
   * Purpose: Method is use to insert account record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - insert account record
   */
  create(companyAccountModel: CompanyAccountModel): Observable<Number> {
    return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/AccountDetailCompanyStructure`, companyAccountModel);
  }

  /**
   * Purpose: Method is use to update account record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - update account record
   */
   update(companyAccountModel: CompanyAccountModel): Observable<Number> {
    return this.httpClient.put<number>(`${environment.serviceApiUrl}/api/AccountDetailCompanyStructure`, companyAccountModel);
  }

  /**
   * Purpose: Method is use to delete account record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - delete account record
   */
  delete(accountDetailCompanyStructureID: number): Observable<Number> {
      return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/AccountDetailCompanyStructure/${accountDetailCompanyStructureID}`);
  }
}
