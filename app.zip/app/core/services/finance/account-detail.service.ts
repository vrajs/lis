import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { AccountDetailModel } from '@app/core/models';

@Injectable()
export class AccountDetailService {
    
  constructor(private httpClient: HttpClient) {
  }

  /**
   * Purpose: Method is use to get account list
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get account list
   */
  get(): Observable<AccountDetailModel[]> {
    return this.httpClient.get<AccountDetailModel[]>(`${environment.serviceApiUrl}/api/AccountDetail`);
  }

  /**
   * Purpose: Method is use to get account list by id
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get account list by id
   */
  getById(accountDetailID: number): Observable<AccountDetailModel> {
    return this.httpClient.get<AccountDetailModel>(`${environment.serviceApiUrl}/api/AccountDetail/${accountDetailID}`);
  }

  /**
   * Purpose: Method is use to insert update account record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - insert update account record
   */
  create(accountDetailModel: AccountDetailModel): Observable<Number> {
    return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/AccountDetail`, accountDetailModel);
  }

  /**
   * Purpose: Method is use to update account record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - update account record
   */
   update(accountDetailModel: AccountDetailModel): Observable<Number> {
    return this.httpClient.put<number>(`${environment.serviceApiUrl}/api/AccountDetail`, accountDetailModel);
  }

  /**
   * Purpose: Method is use to delete account record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - delete account record
   */
  delete(accountDetailCompanyStructureID: number): Observable<Number> {
      return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/AccountDetail/${accountDetailCompanyStructureID}`);
  }
}

