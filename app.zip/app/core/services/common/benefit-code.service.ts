//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-functions';
import { BenefitCodesModel, OData } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

//#region Service Namespace
import { ODataBuilderService } from './odata-builder.service';
//#endregion

@Injectable()

export class BenefitCodeService {

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    /**
  * Purpose: Method is use to get benefit codes list
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit codes list
  */
     getBenefitCodeList(benefitCodeUrl: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<BenefitCodesModel>> {
      let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/BenefitCodes`, filteringArgs, sortingArgs, index, perPage) + benefitCodeUrl;
      return this.httpClient.get<OData<BenefitCodesModel>>(dynamicUrl).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return new OData<BenefitCodesModel>(res);
        })
      );
    }

  /**
  * Purpose: Method is use to get benefit code
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit codes
  */
  get(): Observable<BenefitCodesModel[]> {
    return this.httpClient.get<BenefitCodesModel[]>(`${environment.serviceApiUrl}/api/BenefitCode`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel[];
      })
    );
  }

 /**
   * Purpose: Method is use to get benefit code by id
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit code by id
   */
  getById(benefitCodeId: number): Observable<BenefitCodesModel> {
    return this.httpClient.get<BenefitCodesModel>(`${environment.serviceApiUrl}/api/BenefitCode/${benefitCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel;
      })
    );
  }

  /**
   * Purpose: Method is use to get benefit code by benefit header id
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit code by benefit header id
   */
  getByBenefitHeaderId(benefitHeaderId: number): Observable<BenefitCodesModel> {
    return this.httpClient.get<BenefitCodesModel>(`${environment.serviceApiUrl}/api/BenefitCode/GetBenefitCodeByBenefitHeaderId/${benefitHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel;
      })
    );
  }

  /**
   * Purpose: Method is use to get clinical code type by id
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get clinical code type by id
   */
  getByClinicalCodeTypeId(BenefitHeaderId: number, ClinicalCodeTypeId: number): Observable<BenefitCodesModel> {
    return this.httpClient.get<BenefitCodesModel>(`${environment.serviceApiUrl}/api/BenefitCode/GetBenefitCodeByClinicalCodeTypeId/${BenefitHeaderId}/${ClinicalCodeTypeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel;
      })
    );
  }

   /**
   * Purpose: Method is use to create benefit codes
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create benefit codes
   */
  create(model: BenefitCodesModel): Observable<BenefitCodesModel> {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/BenefitCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel;
      })
    );
  }

   /**
   * Purpose: Method is use to update benefit codes
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update benefit codes
   */
  update(model: BenefitCodesModel): Observable<BenefitCodesModel> {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/BenefitCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel;
      })
    );
  }

   /**
   * Purpose: Method is use to delete benefit codes
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete benefit codes
   */
  delete(benefitCodeId: number) {
    return this.httpClient.delete<BenefitCodesModel>(`${environment.serviceApiUrl}/api/BenefitCode/${benefitCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCodesModel;
      })
    );
  }
}
