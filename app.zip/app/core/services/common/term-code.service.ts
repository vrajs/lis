//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-functions';
import { environment } from '@environments/environment';
//#endregion

//#region Service Namespace
import { ODataBuilderService } from './odata-builder.service';
import { TermCodesModel } from '@app/core/models/administration/configuration/term-codes.model';
import { OData } from '@app/core/models';
//#endregion

@Injectable()

export class TermCodeService {

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    /**
  * Purpose: Method is use to get benefit codes list
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit codes list
  */
     getTermCodeList(termCodeUrl: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<TermCodesModel>> {
      let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/TermCodes`, filteringArgs, sortingArgs, index, perPage) + termCodeUrl;
      return this.httpClient.get<OData<TermCodesModel>>(dynamicUrl).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return new OData<TermCodesModel>(res);
        })
      );
    }

  /**
  * Purpose: Method is use to get benefit code
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit codes
  */
  get(): Observable<TermCodesModel[]> {
    return this.httpClient.get<TermCodesModel[]>(`${environment.serviceApiUrl}/api/TermCode`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel[];
      })
    );
  }

 /**
   * Purpose: Method is use to get benefit code by id
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit code by id
   */
  getById(termCodeId: number): Observable<TermCodesModel> {
    return this.httpClient.get<TermCodesModel>(`${environment.serviceApiUrl}/api/TermCode/${termCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel;
      })
    );
  }

  /**
   * Purpose: Method is use to get benefit code by benefit header id
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit code by benefit header id
   */
  getByBenefitHeaderId(benefitHeaderId: number): Observable<TermCodesModel> {
    return this.httpClient.get<TermCodesModel>(`${environment.serviceApiUrl}/api/TermCode/GetTermCodeByBenefitHeaderId/${benefitHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel;
      })
    );
  }

  /**
   * Purpose: Method is use to get clinical code type by id
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get clinical code type by id
   */
  getByClinicalCodeTypeId(BenefitHeaderId: number, ClinicalCodeTypeId: number): Observable<TermCodesModel> {
    return this.httpClient.get<TermCodesModel>(`${environment.serviceApiUrl}/api/TermCode/GetTermCodeByClinicalCodeTypeId/${BenefitHeaderId}/${ClinicalCodeTypeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel;
      })
    );
  }

   /**
   * Purpose: Method is use to create benefit codes
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create benefit codes
   */
  create(model: TermCodesModel): Observable<TermCodesModel> {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/TermCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel;
      })
    );
  }

   /**
   * Purpose: Method is use to update benefit codes
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update benefit codes
   */
  update(model: TermCodesModel): Observable<TermCodesModel> {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/TermCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel;
      })
    );
  }

   /**
   * Purpose: Method is use to delete benefit codes
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete benefit codes
   */
  delete(termCodeId: number) {
    return this.httpClient.delete<TermCodesModel>(`${environment.serviceApiUrl}/api/TermCode/${termCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermCodesModel;
      })
    );
  }
}
