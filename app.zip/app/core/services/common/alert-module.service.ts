import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-global";
import { AlertCodeModel, AlertModuleViewModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "./odata-builder.service";


@Injectable()
export class AlertModuleService {

    apiBaseUrl: string = '/api/Alert';

    constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) {
    }

    get(): Observable<AlertModuleViewModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as AlertModuleViewModel[];
            })
        )
    }

    getWithAdvanceFilter(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<AlertModuleViewModel>> {
        let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true)
        return this.httpClient.get<OData<AlertModuleViewModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<AlertModuleViewModel>(res);
            })
        );
    }

    getById(AlertModuleID: number): Observable<AlertModuleViewModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${AlertModuleID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as AlertModuleViewModel;
            })
        )
    }

    createOrUpdate(alertModule: AlertModuleViewModel): Observable<Number> {
        if (alertModule.alertModuleId === 0) {
            return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, alertModule).pipe(
                map((res) => Number(res))
            )
        }
        else {
            return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, alertModule).pipe(
                map((res) => Number(res))
            )
        }
    }

    delete(AlertModuleID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${AlertModuleID}`).pipe(
            map((res) => Number(res))
        )
    }

    getMemberAlerts(familyCode: string): Observable<Array<AlertModuleViewModel>> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetMemberAlerts/${familyCode}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as Array<AlertModuleViewModel>;
            })
        )
    }

    getAlertCode(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<AlertCodeModel>> {
        let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/AlertCode/`, filteringArgs, sortingArgs, 0, 100)
        return this.httpClient.get<OData<AlertCodeModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<AlertCodeModel>(res);
            })
        );
    }


}
