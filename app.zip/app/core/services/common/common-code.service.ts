//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-global';
import { ClinicalCodeCheckModel, CommonCodeConfigurationModel, CommonCodeModel, KeyValModel, MultipleValueRequestModel, OData } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

//#region Service Namespace
import { ODataBuilderService } from '@app/core/services';
import { OtherDocument } from '@app/core/models/operation/member/otherdocument.model';
//#endregion

@Injectable()
export class CommonCodeService {

    public commonCodeModelData: Observable<CommonCodeModel[]>;
    public _commonCodeModelData: BehaviorSubject<CommonCodeModel[]>;
    
    constructor(private httpClient: HttpClient,
        private oDatabuilderSrvice: ODataBuilderService) {
        this._commonCodeModelData = new BehaviorSubject([]);
        this.commonCodeModelData = this._commonCodeModelData.asObservable();
    }

    /**
   * Purpose: Method is use to get all standard code data
   * @author Gaurav Vaghela # on 28-APR-2022 - get standard code data
   */
    getCommonStandardCodeList(codeUrl: string, dynamicQueryUrl: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): any {
        let dynamicUrl = `${environment.serviceApiUrl}/${codeUrl}`;
        let buildQuery = this.oDatabuilderSrvice.buildDataUrl(dynamicUrl, filteringArgs, sortingArgs, index, perPage) + dynamicQueryUrl;
        return this.httpClient.get(buildQuery).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        )
    }

    /**
   * Purpose: Method is use to get code type Ids
   * @author Gaurav Vaghela # on 28-APR-2022 - get code type Ids
   */
    getByCodeTypeIds(request: MultipleValueRequestModel): Observable<CommonCodeModel[]> {
        return this.httpClient.get<CommonCodeModel[]>(`${environment.serviceApiUrl}/api/CommonCode/GetCodeByTypeIds?jsonObject=${JSON.stringify(request)}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel[];
            })
        );
    }

    /**
   * Purpose: Method is use to get code configuration
   * @author Gaurav Vaghela # on 28-APR-2022 - get code configuration
   */
    getCommonCodeConfigurationByCodeTypeId(PageId: string, CodeTypeId: number): Observable<CommonCodeConfigurationModel[]> {
        return this.httpClient.get<CommonCodeConfigurationModel[]>(`${environment.serviceApiUrl}/api/CommonCode/GetCommonCodeConfigurationByCodeTypeId/${PageId}/${CodeTypeId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeConfigurationModel[];
            })
        );
    }


    /**
   * Purpose: Method is use to get code type
   * @author Gaurav Vaghela # on 28-APR-2022 - get code type
   */
    getByCodeTypeId(CodeTypeId: number, FetchingTypeId: number = 0): Observable<KeyValModel[]> {
        return this.httpClient.get<KeyValModel[]>(`${environment.serviceApiUrl}/api/CommonCode/${CodeTypeId}/${FetchingTypeId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as KeyValModel[];
            })
        );
    }

    /**
   * Purpose: Method is use to get common code
   * @author Gaurav Vaghela # on 28-APR-2022 - get common code
   */
    get(): Observable<CommonCodeModel[]> {
        return this.httpClient.get<CommonCodeModel[]>(`${environment.serviceApiUrl}/api/CommonCode`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel[];
            })
        );
    }

    /**
   * Purpose: Method is use to get common code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get common code by id
   */
    getById(commonCodeID: number): Observable<CommonCodeModel> {
        return this.httpClient.get<CommonCodeModel>(`${environment.serviceApiUrl}/api/CommonCode/${commonCodeID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel;
            })
        );
    }

    /**
   * Purpose: Method is use to create common code
   * @author Gaurav Vaghela # on 28-APR-2022 - create common code
   */
    create(commonCode: CommonCodeModel): Observable<CommonCodeModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}/api/CommonCode`, commonCode).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel;
            })
        );
    }

    /**
  * Purpose: Method is use to update common code
  * @author Gaurav Vaghela # on 28-APR-2022 - create update code
  */
    update(commonCode: CommonCodeModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}/api/CommonCode`, commonCode).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel;
            })
        );
    }

    /**
  * Purpose: Method is use to get display order
  * @author Gaurav Vaghela # on 28-APR-2022 - create display order
  */
    getMaxDisplayOrderByCodeTypeId(codeTypeID: number): Observable<number> {
        return this.httpClient.get<number>(`${environment.serviceApiUrl}/api/CommonCode/GetMaxDisplayOrderByCodeTypeId/${codeTypeID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as number;
            })
        );
    }

    /**
   * Purpose: Method is use to get manage order
   * @author Gaurav Vaghela # on 24-May-2022 - manage display order
   */
    manageDisplayOrder(dataList: KeyValModel[]) {
        return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/CommonCode/ManageDisplayOrder`, dataList).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as number;
            })
        );
    }

    /**
       * Purpose: Method is use to get all common code data
       * @author Shivam Modi # on 28-May-2022 - get common code data
       */
    getCommonCodeList(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<CommonCodeModel>> {
        let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/GetCommonCodeList`, filteringArgs, sortingArgs, index, perPage)
        return this.httpClient.get<OData<CommonCodeModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<CommonCodeModel>(res);
            })
        );
    }

    /**
       * Purpose: Method is use to get list of codetype data
       * @author Shivam Modi # on 28-APR-2022 - get list of codetype data
       */
    getCodeTypeList(url: string): Observable<any> {
        return this.httpClient.get<any>(`${environment.serviceApiUrl}/${url}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }

    /**
   * Purpose: Method is use to Check Common ClinicalCode
   * @author Gaurav Vaghela # on 28-APR-2022 - get code configuration
   */
    checkCommonClinicalCode(clinicalCodeId: number, inputValue: string): Observable<any> {
        return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/CommonClinicalCode/CheckCommonClinicalCode/${clinicalCodeId}/${inputValue}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }

    /**
      * Purpose: Method is use to get grid data for code-type 
      * @author Tisa Jodhani # on 2-June-2022 - get code-type data
      */
    getCodeTypeGridData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<CommonCodeModel>> {
        let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/GetCodeTypes`, filteringArgs, sortingArgs, index, perPage)
        return this.httpClient.get<OData<CommonCodeModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<CommonCodeModel>(res);
            })
        );
    }

    getCommonCodeByCodeTypeId(codeTypeId: number): Observable<CommonCodeModel[]> {
        return this.httpClient.get<CommonCodeModel[]>(`${environment.serviceApiUrl}/api/CommonCode/GetCommonCodeByCodeTypeId/${codeTypeId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel[];
            })
        );
    }
   
    /**
     * Purpose: Method is use to get all common code data
     * @author Adit Shah # on 05-August-2022 - get common code data by code type
     */
    getCommonCodeListByCodeType(codeTypeId?: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<CommonCodeModel>> {
        let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/GetCommonCodeList?CodeTypeID=${codeTypeId}&`, filteringArgs, sortingArgs, index, perPage)
        return this.httpClient.get<OData<CommonCodeModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<CommonCodeModel>(res);
            })
        );
    }
    /**
    * Purpose: Method is use to get all common code data
    * @author Kiran Panchal # on 23-August-2022 - Check exists code used in another places or not
    */
    checkExistsCommonClinicalCodeUsed(clinicalcodetypeid: number, code: string, effectivedate: any, termdate: any): Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/CommonClinicalCode/CheckExistsCommonClinicalCodeUsed?ClinicalCodeTypeID=${clinicalcodetypeid}&Code=${code}&EffectiveDate=${effectivedate}&TermDate=${termdate}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }
    /**
    * Purpose: Method is use to get all common code data
    * @author Kiran Panchal # on 23-August-2022 - Delete code
    */
    delete(Id: number, ClinicalCodeTypeID: number): Observable<number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}/api/CommonClinicalCode/${Id}/${ClinicalCodeTypeID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as number;
            }));
    }
}
