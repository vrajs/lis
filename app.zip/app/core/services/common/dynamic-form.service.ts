import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { CityModel, CountyModel, KeyValModel, OData, ProviderViewModel, ZipCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { IForOfState } from '@infragistics/igniteui-angular';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from './odata-builder.service';

@Injectable()
export class DynamicFormService {

  constructor(private httpClient: HttpClient, private oDataService: ODataBuilderService) { }

  /**
   * Purpose: Method is use to get dynamic data from db in Key value pair
   * @author Gaurav Vaghela # on 16-May-2022 - get dynamic data
   */
  getKeyValDropdownData(url: string): Observable<KeyValModel[]> {
    return this.httpClient.get<KeyValModel[]>(`${environment.serviceApiUrl}/${url}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as KeyValModel[];
      })
    );
  }

  /**
   * Purpose: Method is use to get cities list
   * @author Gaurav Vaghela # on 16-May-2022 - get cities value
   */
  getCities(virtulizationState?: IForOfState, searchText?: string, containProperty?: string): Observable<OData<CityModel>> {
    let url = `${environment.serviceApiUrl}/odata/Cities`;
    let buildQuery = this.oDataService.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
    return this.httpClient.get<OData<CityModel>>(buildQuery).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<CityModel>(res);
      })
    );
  }

  /**
   * Purpose: Method is use to get counties list
   * @author Gaurav Vaghela # on 16-May-2022 - get counties value
   */
  getCounties(virtulizationState?: IForOfState, searchText?: string, containProperty?: string):  Observable<OData<CountyModel>> {
    let url = `${environment.serviceApiUrl}/odata/Counties`;
    let buildQuery = this.oDataService.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
    return this.httpClient.get<OData<CountyModel>>(buildQuery).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<CountyModel>(res);
      })
    );
  }

  /**
   * Purpose: Method is use to get counties list
   * @author Adit Shah # on 27-July-2022 - get zipcode value
   */
  getZipcodes(virtulizationState?: IForOfState, searchText?: string, containProperty?: string):  Observable<OData<ZipCodeModel>> {
    let url = `${environment.serviceApiUrl}/odata/zipcodes`;
    let buildQuery = this.oDataService.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
    return this.httpClient.get<OData<ZipCodeModel>>(buildQuery).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ZipCodeModel>(res);
      })
    );
  }

  /**
   * Purpose: Method is use to get PCP list
   * @author Dupendra Pawar # on 02-Sep-2022 - get PCP value
   */
   getPCP(virtulizationState?: IForOfState, searchText?: any, containProperty?: string):  Observable<OData<ProviderViewModel>> {
    let url = `${environment.serviceApiUrl}/odata/ClaimReferringPhysicians`;
    let buildQuery = this.oDataService.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
    return this.httpClient.get<OData<ProviderViewModel>>(buildQuery).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ProviderViewModel>(res);
      })
    );
  }

  // private buildUrl(dataState: any, searchText?: string): string {
  //     let qS = '?';
  //     let requiredChunkSize: number;
  //     if (dataState) {
  //         const skip = dataState.startIndex;

  //         requiredChunkSize = dataState.chunkSize === 0 ?
  //             // Set initial chunk size, the best value is igxForContainerSize divided on igxForItemSize
  //             10 : dataState.chunkSize;
  //         qS += `$skip=${skip}&$top=${requiredChunkSize}&$count=true`;

  //         if (searchText) {
  //             qS += `&$filter=contains(City, '` + searchText + `')`;
  //         }
  //     }
  //     return `${environment.serviceApiUrl}/odata/Cities${qS}`;
  // }

}
