import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ValidityCheck } from "@app/common/app-enum";
import { Utils } from "@app/common/app-functions";
import { ClinicalCodeGroupDetailModel, MinCodeMaxCodeValidityModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "./odata-builder.service";

@Injectable()
export class ClinicalCodeService {
    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }



    getClinicalCodeGroupDetailsData(clinicalCodeSubGroupId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClinicalCodeGroupDetailModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClinicalCodeGroupDetails`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClinicalCodeGroupDetailModel>>(`${dynamicUrl}&ClinicalCodeSubGroupID=${clinicalCodeSubGroupId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClinicalCodeGroupDetailModel>(res);
            })
        );
    }

    checkCommonClinicalCode(ClinicalCodeTypeID: number, Code: string) {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/CommonClinicalCode/CheckCommonClinicalCode/${ClinicalCodeTypeID}/${Code}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }

    checkValidityOfCode(ClinicalCodeTypeID: number, MinCode: string, MaxCode: string, ValidationDate: string, validityCheck: ValidityCheck) {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/CommonClinicalCode/CheckCodeValidity?ClinicalCodeTypeID=${ClinicalCodeTypeID}&MinCode=${MinCode}&MaxCode=${MaxCode}&ValidationDate=${ValidationDate}&ValidityMode=${validityCheck}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as MinCodeMaxCodeValidityModel;
            })
        );
    }

    checkcommonclinicalcodeEffective(clinicalcodetypeid: number, code: string, effectivedate: any, termdate: any): Observable<boolean> {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/CommonClinicalCode/CheckCommonClinicalCodeEffective?ClinicalCodeTypeID=${clinicalcodetypeid}&Code=${code}&EffectiveDate=${effectivedate}&TermDate=${termdate}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as boolean;
            })
        );
    }

    getModifierCodes() {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/CPT/GetModifierCodes`);
    }
    getPOSCodes() {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/POSCode`);
    }
    checkCode(ClinicalCodeTypeID: string, Code: string) {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/CommonClinicalCode/CheckCode/${ClinicalCodeTypeID}/${Code}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        )
    }
}
