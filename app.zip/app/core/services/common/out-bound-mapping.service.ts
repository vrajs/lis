import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { DbColumnInfoModel, ElementModel, KeyValModel, OData } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from './odata-builder.service';

@Injectable()
export class OutBoundMappingService {

    public apiBaseUrl: string = '/api/OutBoundMapping/';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    public getModuleName(): KeyValModel[] {
        return [
            { "key": "834", "value": "834_5010" },
            { "key": "270", "value": "270_5010" },
            { "key": "271", "value": "271_5010" },
            { "key": "277", "value": "277_5010" },
            { "key": "276", "value": "276_5010" },
            { "key": "278", "value": "278RO_5010" },
            { "key": "835", "value": "835_5010" },
            { "key": "837I", "value": "837I_5010" },
            { "key": "837P", "value": "837_5010" }];
    }

    getOutBoundMappingData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ElementModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetOutboundMappingConfiguration`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ElementModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ElementModel>(res);
            })
        );
    }

    getMappingSourceData(elementId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<any>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetMappingSource`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<any>>(`${dynamicUrl}&$orderby=ElementValue asc&$filter=ElementID eq ${elementId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<any>(res);
            })
        );
    }

    public getViewSchemaInfo(): Observable<DbColumnInfoModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}GetViewSchema`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as DbColumnInfoModel[];
            })
        )
    }

    public getTableSchemaInfo(): Observable<DbColumnInfoModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}GetTableSchema`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as DbColumnInfoModel[];
            })
        )
    }

    public getEdiMappingConfiguration(): Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}GetOutboundMappingConfiguration`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        )
    }

    public addUpdateMapping(data) {
        if (data.outboundMappingconfigurationId === 0)
            return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, data).pipe(
                map(res => {
                    res = Utils.camelizeKeys(res);
                    return res as any;
                })
            )
        else
            return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, data).pipe(
                map(res => {
                    res = Utils.camelizeKeys(res);
                    return res as any;
                })
            );
    }

    public updateElement(data) {
        return this.httpClient.put(`${environment.serviceApiUrl}/api/Element`, data).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        )
    }
}
