//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { ClinicalCodeGroupDetailModel, ClinicalCodeGroupModel, ClinicalCodeSubGroupModel, KeyValModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class ServiceGroupService {

  constructor(private httpClient: HttpClient) { }  
  
   /**
  * Purpose: Method is use to get clinical code group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get clinical code group
  */
  getClinicalCodeGroup(): Observable<KeyValModel[]> {
    return this.httpClient.get<KeyValModel[]>(`${environment.serviceApiUrl}/api/ClinicalCodeGroup/GetClinicalCodeGroup`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as KeyValModel[];
      })
    );
  }

   /**
  * Purpose: Method is use to create clinical code group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create clinical code group
  */
  createClinicalCodeGroup(model: ClinicalCodeGroupModel): Observable<any> {
    return this.httpClient.post<ClinicalCodeGroupModel>(`${environment.serviceApiUrl}/api/ClinicalCodeGroup`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );    
  }

  /**
  * Purpose: Method is use to get clinical sub code group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  get clinical sub code group
  */
  getClinicalCodeSubGroup(clinicalCodeGroupId: number) {
    return this.httpClient.get<KeyValModel[]>(`${environment.serviceApiUrl}/api/ClinicalCodeSubGroup/GetClinicalCodeSubGroup/${clinicalCodeGroupId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as KeyValModel[];
      })
    );   
  }

  /**
  * Purpose: Method is use to create clinical sub code group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create clinical sub code group
  */   
  createClinicalCodeSubGroup(model: ClinicalCodeSubGroupModel) {
    return this.httpClient.post<ClinicalCodeGroupModel>(`${environment.serviceApiUrl}/api/ClinicalCodeSubGroup`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );        
  }
  
 /**
  * Purpose: Method is use to get clinical sub code group details
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  get clinical sub code group details
  */ 
  getClinicalCodeGroupDetail(clinicalCodeSubGroupId: number): Observable<ClinicalCodeGroupDetailModel[]> {
    return this.httpClient.get<ClinicalCodeGroupDetailModel[]>(`${environment.serviceApiUrl}/api/ClinicalCodeGroupDetail/${clinicalCodeSubGroupId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ClinicalCodeGroupDetailModel[];
      })
    );    
  }

 /**
  * Purpose: Method is use to get clinical sub code group details 
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  get clinical sub code group details
  */ 
  getClinicalCodeGroupDetailKeyVal(clinicalCodeSubGroupId: number): Observable<KeyValModel[]>  {
    return this.httpClient.get<KeyValModel[]>(`${environment.serviceApiUrl}/api/ClinicalCodeGroupDetail/GetClinicalCodeGroupDetailKeyVal/${clinicalCodeSubGroupId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as KeyValModel[];
      })
    );       
  }

   /**
  * Purpose: Method is use to get clinical code group details
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  get clinical code group details
  */ 
  getByIdClinicalCodeGroupDetail(id: number): Observable<ClinicalCodeGroupDetailModel> {
    return this.httpClient.get<ClinicalCodeGroupDetailModel>(`${environment.serviceApiUrl}/api/ClinicalCodeGroupDetail/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ClinicalCodeGroupDetailModel;
      })
    );       
  }

   /**
  * Purpose: Method is use to create clinical code group details
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  get clinical code group details
  */ 
  createClinicalCodeGroupDetail(model: ClinicalCodeGroupDetailModel) {
    return this.httpClient.post<ClinicalCodeGroupModel>(`${environment.serviceApiUrl}/api/ClinicalCodeGroupDetail`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ClinicalCodeGroupModel;
      })
    );       
  }

   /**
  * Purpose: Method is use to update clinical code group details
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  update clinical code group details
  */ 
  UpdateClinicalCodeGroupDetail(model: ClinicalCodeGroupDetailModel) {
    return this.httpClient.put<ClinicalCodeGroupModel>(`${environment.serviceApiUrl}/api/ClinicalCodeGroupDetail`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ClinicalCodeGroupModel;
      })
    );       
  }
  
   /**
  * Purpose: Method is use to gdeleteet clinical code group details
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 -  delete clinical code group details
  */ 
  deleteClinicalCodeGroupDetail(id: number) {
    return this.httpClient.delete<ClinicalCodeGroupModel>(`${environment.serviceApiUrl}/api/ClinicalCodeGroupDetail/DeleteClinicalCodeGroupDetail/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ClinicalCodeGroupModel;
      })
    );     
  }

}
