import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { CommonCodeModel } from "@app/core/models";
import { CommonCodeDisplayConfigurationModel } from "@app/core/models/common/common-code-display-configuration.model";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class CommonCodeDisplayConfigurationService {

    apiBaseUrl: string = '/api/CommonCodeDisplayConfiguration';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<CommonCodeDisplayConfigurationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeDisplayConfigurationModel[];
            })
        )
    }

    getById(commonCodeDisplayConfigurationID: number): Observable<CommonCodeDisplayConfigurationModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${commonCodeDisplayConfigurationID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeDisplayConfigurationModel;
            })
        )
    }

    create(commonCodeDisplayConfiguration: CommonCodeDisplayConfigurationModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, commonCodeDisplayConfiguration);
    }

    update(commonCodeDisplayConfiguration: CommonCodeDisplayConfigurationModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, commonCodeDisplayConfiguration);
    }

    delete(commonCodeDisplayConfigurationID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${commonCodeDisplayConfigurationID}`);
    }

    getCommonCodesByPageId(pageId: any): Observable<CommonCodeModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetCommonCodesByPageID/${pageId}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as CommonCodeModel[];
            })
        )
    }
}
