import { Injectable } from '@angular/core';
import { AppConstant, FILTER_OPERATION, Utils } from '@app/common/app-global';
import { FilteringExpressionsTree, FilteringLogic, IForOfState, SortingDirection } from '@infragistics/igniteui-angular';

@Injectable()
export class ODataBuilderService {

    constructor() { }

    EMPTY_STRING = '';
    NULL_VALUE = null;
    ALL_VALUE = 'all';
    TRUE_VALUE = true;
    FALSE_VALUE = false;

    public buildDataUrl(dynamicUrl: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number, virtualizationArgs?: IForOfState, IsForAdvanceFilter: boolean = false): string {
        let baseQueryString = IsForAdvanceFilter == false ? `${dynamicUrl}?$count=true` : `${dynamicUrl}&$count=true`;
        if(!Utils.isBlank(index) && !Utils.isBlank(perPage)){
            baseQueryString = `${baseQueryString}&$skip=${index}&$top=${perPage}`
        }
        let scrollingQuery = this.EMPTY_STRING;
        let orderQuery = this.EMPTY_STRING;
        let filterQuery = this.EMPTY_STRING;
        let query = this.EMPTY_STRING;
        let filter = this.EMPTY_STRING;

        if (!Utils.isBlank(sortingArgs)) {
            if (Array.isArray(sortingArgs) && sortingArgs.length > 1) {
                sortingArgs.forEach((ele,index) => {
                    // orderQuery =  index == 0  ? `$orderby=${this._buildSortExpression(ele)}` : `& ${this._buildSortExpression(ele)}`
                    orderQuery = orderQuery + `${index == 0 ? `$orderby=${this._buildSortExpression(ele)}` : `, ${this._buildSortExpression(ele)}`}`;
                })
            } else {
                orderQuery = `$orderby=${this._buildSortExpression(sortingArgs)}`
            }
        }

        if (filteringArgs && filteringArgs.length > 0) {
            filteringArgs.forEach((columnFilter) => {
                if (filter !== this.EMPTY_STRING) {
                    filter += ` ${FilteringLogic[columnFilter.operator].toLowerCase()} `;
                }

                filter += this._buildAdvancedFilterExpression(
                    columnFilter.filteringOperands,
                    columnFilter.operator);
            });

            filterQuery = `$filter=${filter}`;
        }

        if (virtualizationArgs) {
            scrollingQuery = this._buildScrollExpression(virtualizationArgs);
        }

        query += (orderQuery !== this.EMPTY_STRING) ? `&${orderQuery}` : this.EMPTY_STRING;
        query += (filterQuery !== this.EMPTY_STRING) ? `&${filterQuery}` : this.EMPTY_STRING;
        query += (scrollingQuery !== this.EMPTY_STRING) ? `&${scrollingQuery}` : this.EMPTY_STRING;

        baseQueryString += query;

        return baseQueryString;
    }

    private _buildAdvancedFilterExpression(operands, operator): string {
        let filterExpression = this.EMPTY_STRING;
        operands.forEach((operand, index) => {
            if (operand instanceof FilteringExpressionsTree) {
                if (index > 0) {
                    filterExpression += ` ${FilteringLogic[operator].toLowerCase()} `;
                }
                filterExpression += this._buildAdvancedFilterExpression(
                    operand.filteringOperands,
                    operand.operator
                );
                return filterExpression;
            }

            const value = operand.searchVal;
            const isNumberValue = (typeof (value) === 'number') ? true : false;
            const filterValue = (isNumberValue) ? value : `'${value}'`;
            const fieldName = operand.fieldName;
            let filterString;

            if (filterExpression !== this.EMPTY_STRING) {
                filterExpression += ` ${FilteringLogic[operator].toLowerCase()} `;
            }

            switch (operand.condition.name) {
                case 'contains': {
                    filterString = `${FILTER_OPERATION.CONTAINS}(${fieldName}, ${filterValue})`;
                    break;
                }
                case 'startsWith': {
                    filterString = `${FILTER_OPERATION.STARTS_WITH}(${fieldName},${filterValue})`;
                    break;
                }
                case 'endsWith': {
                    filterString = `${FILTER_OPERATION.ENDS_WITH}(${fieldName},${filterValue})`;
                    break;
                }
                case 'equals': {
                    filterString = `${fieldName} ${FILTER_OPERATION.EQUALS} ${filterValue} `;
                    break;
                }
                case 'doesNotEqual': {
                    filterString = `${fieldName} ${FILTER_OPERATION.DOES_NOT_EQUAL} ${filterValue} `;
                    break;
                }
                case 'doesNotContain': {
                    filterString = `${FILTER_OPERATION.DOES_NOT_CONTAIN}(${fieldName},${filterValue})`;
                    break;
                }
                case 'greaterThan': {
                    filterString = `${fieldName} ${FILTER_OPERATION.GREATER_THAN}  ${filterValue} `;
                    break;
                }
                case 'after': {
                    filterString = `${fieldName} ${FILTER_OPERATION.GREATER_THAN}  ${isNumberValue ? filterValue : Utils.formateDatewithformat(filterValue,'YYYY-MM-DD')} `;
                    break;
                }
                case 'greaterThanOrEqualTo': {
                    filterString = `${fieldName} ${FILTER_OPERATION.GREATER_THAN_EQUAL} ${filterValue} `;
                    break;
                }
                case 'lessThan': {
                    filterString = `${fieldName} ${FILTER_OPERATION.LESS_THAN}  ${filterValue} `;
                    break;
                }
                case 'before': {
                    filterString = `${fieldName} ${FILTER_OPERATION.LESS_THAN} ${isNumberValue ? filterValue : Utils.formateDatewithformat(filterValue,'YYYY-MM-DD')} `;
                    break;
                }
                case 'lessThanOrEqualTo': {
                    filterString = `${fieldName} ${FILTER_OPERATION.LESS_THAN_EQUAL} ${filterValue} `;
                    break;
                }
                case 'empty': {
                    filterString = `length(${fieldName}) ${FILTER_OPERATION.EQUALS} 0`;
                    break;
                }
                case 'notEmpty': {
                    filterString = `length(${fieldName}) ${FILTER_OPERATION.GREATER_THAN} 0`;
                    break;
                }
                case 'null': {
                    filterString = `${fieldName} ${FILTER_OPERATION.EQUALS} ${this.NULL_VALUE}`;
                    break;
                }
                case 'notNull': {
                    filterString = `${fieldName} ${FILTER_OPERATION.DOES_NOT_EQUAL} ${this.NULL_VALUE}`;
                    break;
                }
                case 'all': {
                    filterString = `${fieldName} ${FILTER_OPERATION.EQUALS} ${this.ALL_VALUE}`;
                    break;
                }
                case 'true': {
                    filterString = `${fieldName} ${FILTER_OPERATION.EQUALS} ${this.TRUE_VALUE}`;
                    break;
                }
                case 'false': {
                    filterString = `${fieldName} ${FILTER_OPERATION.EQUALS} ${this.FALSE_VALUE}`;
                    break;
                }
                case 'in': {
                    filterString = `${FILTER_OPERATION.CONTAINS}(${fieldName}, ${filterValue})`;
                    break;
                }
            }

            filterExpression += filterString;
        });

        return filterExpression;
    }

    private _buildSortExpression(sortingArgs): string {
        let sortingDirection: string;
        switch (sortingArgs.dir) {
            case SortingDirection.None: {
                sortingDirection = this.EMPTY_STRING;
                break;
            }
            default: {
                sortingDirection = SortingDirection[sortingArgs.dir].toLowerCase();
                break;
            }
        }

        return `${sortingArgs.fieldName} ${sortingDirection}`;
    }

    private _buildScrollExpression(virtualizationArgs: IForOfState): string {
        let requiredChunkSize: number;
        const skip = virtualizationArgs.startIndex;
        requiredChunkSize = virtualizationArgs.chunkSize === 0 ? 15 : virtualizationArgs.chunkSize;
        const top = requiredChunkSize;

        return `$skip=${skip}&$top=${top}`;
    }

    public buildDataUrlForScroll(dynamicUrl: string, virtualizationArgs: IForOfState, searchText?: any, containProperty?: string): string {
        var qS: string = '';
        if (!Utils.isBlank(virtualizationArgs)) {
            qS = '?';
            let requiredChunkSize: number;
            const skip = virtualizationArgs.startIndex;
            requiredChunkSize = virtualizationArgs.chunkSize === 0 ? AppConstant.defaultChukSize : virtualizationArgs.chunkSize;
            qS += `$skip=${skip}&$top=${requiredChunkSize}&$count=true`;

            if (!Utils.isBlank(searchText) && (typeof (searchText) !== 'number')) {
                qS += `&$filter=contains(${containProperty}, '` + searchText + `')`;
            } else if (!Utils.isBlank(searchText) && (typeof (searchText) === 'number')) {
                qS += `&$filter=${containProperty} ${FILTER_OPERATION.GREATER_THAN_EQUAL}  ${searchText}`;
            }
        } else {
            qS += `?$count=true`;
        }
        return `${dynamicUrl}${qS}`;
    }


}
