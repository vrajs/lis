import { Injectable } from '@angular/core';
import { AlertMessageType } from '@app/common/app-enum';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class NotificationService {

  constructor(private toastr: ToastrService) { }

  public showMessage(type: AlertMessageType, message?: string, title?: string) {

    if (type === AlertMessageType.Success) {
      this.toastr.success(message, title);
    }
    else if (type === AlertMessageType.Info) {
      this.toastr.info(message, title);
    }
    else if (type === AlertMessageType.Warning) {
      this.toastr.warning(message, title);
    }
    else if (type === AlertMessageType.Error) {
      this.toastr.error(message, title);
    }
  }

}
