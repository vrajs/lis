import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { KeyValModel, OData, RegionModel, RegionZipCodeModel, ZipCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { ODataBuilderService } from '@app/core/services';
import { ISortingExpression } from '@infragistics/igniteui-angular';

@Injectable()

export class ZipCodeService {

  public zipCodeList: Observable<ZipCodeModel[]>;
  public _zipCodeList: BehaviorSubject<ZipCodeModel[]>;

  constructor(private httpClient: HttpClient,
    private oDatabuilderSrvice: ODataBuilderService) {
    this._zipCodeList = new BehaviorSubject([]);
    this.zipCodeList = this._zipCodeList.asObservable();
  }

  get(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ZipCodeModel>> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/zipcodes`, filteringArgs, sortingArgs, index, perPage)
    return this.httpClient.get<OData<ZipCodeModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ZipCodeModel>(res);
      })
    );
  }

  getById(zipCodeCodeID: number): Observable<ZipCodeModel> {
    return this.httpClient.get<ZipCodeModel>(`${environment.serviceApiUrl}/api/zipcode/${zipCodeCodeID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ZipCodeModel;
      })
    );
  }

  getByTypeAndId(zipCodeCodeID: number, codeTypeID: number): Observable<ZipCodeModel> {

    return this.httpClient.get<ZipCodeModel>(`${environment.serviceApiUrl}/api/zipcode/${zipCodeCodeID}/${codeTypeID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ZipCodeModel;
      })
    );
  }

  create(model: ZipCodeModel): Observable<ZipCodeModel> {
    return this.httpClient.post<ZipCodeModel>(`${environment.serviceApiUrl}/api/zipcode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ZipCodeModel;
      })
    );
  }

  update(model: ZipCodeModel): Observable<ZipCodeModel> {
    return this.httpClient.put<ZipCodeModel>(`${environment.serviceApiUrl}/api/zipcode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ZipCodeModel;
      })
    );
  }

  delete(zipCodeCodeID: number, codeTypeID: number) {

    return this.httpClient.delete<ZipCodeModel>(`${environment.serviceApiUrl}/api/zipcode/${zipCodeCodeID}/${codeTypeID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ZipCodeModel;
      })
    );
  }

  getRegionZipCodeList(zipCodeId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RegionZipCodeModel>> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/RegionZipCodes`, filteringArgs, sortingArgs, index, perPage);
    return this.httpClient.get<OData<RegionZipCodeModel>>(`${dynamicUrl}&ZipCodeId=${zipCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<RegionZipCodeModel>(res);
      })
    );
  }

  getProductTypes(): Observable<KeyValModel[]> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrlForScroll(`${environment.serviceApiUrl}/odata/ProductTypes`,null);
    return this.httpClient.get<KeyValModel[]>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as KeyValModel[];
      })
    );
  }

  getRegions(productTypeId: number): Observable<OData<RegionModel>> {    
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrlForScroll(`${environment.serviceApiUrl}/odata/Regions`,null);    
    return this.httpClient.get<OData<RegionModel>>(`${dynamicUrl}&productTypeId=${productTypeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<RegionModel>(res);
      })
    );
  }

  getZipCodesWithoutOdata(searchValue: string): Observable<ZipCodeModel> {    
    let recParams = new HttpParams();
    recParams = recParams.append('searchValue', searchValue.toString());
    return this.httpClient.get<ZipCodeModel>(`${environment.serviceApiUrl}/api/ZipCode/GetZipCodeBySearchValue/${searchValue}`, {params: recParams}).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ZipCodeModel;
      })
    );
  }

}
