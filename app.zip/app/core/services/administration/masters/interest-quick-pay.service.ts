import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-global";
import { InterestQuickPayModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../..";


@Injectable()
export class InterestQuickPayService {

    apiBaseUrl: string = '/api/InterestQuickPay';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getInterestQuickPayData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<InterestQuickPayModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/InterestQuickPays`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<InterestQuickPayModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<InterestQuickPayModel>(res);
            })
        );
    }

    get(): Observable<InterestQuickPayModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as InterestQuickPayModel[];
            })
        );
    }

    getById(interestQuickPayID: number): Observable<InterestQuickPayModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${interestQuickPayID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as InterestQuickPayModel;
            })
        )
    }

    create(interestQuickPay: InterestQuickPayModel): Observable<InterestQuickPayModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, interestQuickPay).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as InterestQuickPayModel;
            })
        );
    }

    update(interestQuickPay: InterestQuickPayModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, interestQuickPay);
    }

    delete(interestQuickPayID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${interestQuickPayID}`);
    }
}
