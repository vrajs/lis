import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { FeeScheduleDetailModel, FeeScheduleHeaderModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";


@Injectable()
export class UCRFeeScheduleService {

    apiBaseUrlFeeScheduleHeader: string = '/api/FeeScheduleHeader';
    apiBaseUrlFeeScheduleDetail: string = '/api/FeeScheduleDetail';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    //FeeSchedule Header


    getUCRFeeSchedulHeaderData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<FeeScheduleHeaderModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/FeeScheduleHeaders`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<FeeScheduleHeaderModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<FeeScheduleHeaderModel>(res);
            })
        );
    }

    get(): Observable<FeeScheduleHeaderModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleHeader}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleHeaderModel[];
            })
        )
    }

    getByIdFeeScheduleHeader(feeScheduleHeaderID: number): Observable<FeeScheduleHeaderModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleHeader}/${feeScheduleHeaderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleHeaderModel;
            })
        )
    }

    createFeeScheduleHeader(feeScheduleHeader: FeeScheduleHeaderModel): Observable<FeeScheduleHeaderModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleHeader}`, feeScheduleHeader).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleHeaderModel;
            })
        );
    }

    updateFeeScheduleHeader(feeScheduleHeader: FeeScheduleHeaderModel): Observable<FeeScheduleHeaderModel> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleHeader}`, feeScheduleHeader).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleHeaderModel;
            })
        );
    }


    deleteFeeScheduleHeader(feeScheduleHeaderID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleHeader}/${feeScheduleHeaderID}`);
    }

    copyFeeSchedule(feeScheduleHeader: FeeScheduleHeaderModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleHeader}/CopyFeeSchedule/`, feeScheduleHeader);
    }

    //Fee Schedule Detail 

    getUCRFeeSchedulDetailData(feeScheduleHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<FeeScheduleDetailModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/FeeScheduleDetails`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<FeeScheduleDetailModel>>(`${dynamicUrl}&FeeScheduleHeaderID=${feeScheduleHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<FeeScheduleDetailModel>(res);
            })
        );
    }

    createFeeScheduleDetail(model: FeeScheduleDetailModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleDetail}`,model);
    }

    updateFeeScheduleDetail(feeScheduleDetail: FeeScheduleDetailModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleDetail}`, feeScheduleDetail);
    }

    getByIdFeeScheduleDetail(feeScheduleDetailID: number): Observable<FeeScheduleDetailModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleDetail}/${feeScheduleDetailID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleDetailModel;
            })
        )
    }

    deleteFeeScheduleDetail(feeScheduleDetailID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrlFeeScheduleDetail}/${feeScheduleDetailID}`);
    }
}
