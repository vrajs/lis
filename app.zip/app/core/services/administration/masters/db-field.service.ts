//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';

//#endregion

//#region Model Namespace
import { KeyValModel } from '@app/core/models';
import { Utils } from '@app/common/app-functions';
//#endregion

@Injectable()

export class DBFieldService {

    //#region Property
    private apiBaseUrl: string = '/api/DBField';
    //#endregion

    //#region Constructor
    constructor(private httpClient: HttpClient) { }
    //#endregion

    //#region Methods
    public getValues(dbFieldID: number): Observable<KeyValModel[]> {

        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetValues/${dbFieldID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as KeyValModel[];
            })
        );
    }
    //#endregion
}
