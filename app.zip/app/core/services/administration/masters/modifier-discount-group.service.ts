import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { KeyValModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ModifierDiscountGroupService {

    apiBaseUrl: string = '/api/ModifierDiscountGroup';

    constructor(private httpClient: HttpClient) { }

    getModifierDiscountGroupKeyVal(): Observable<KeyValModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetModifierDiscountGroupKeyVal`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as KeyValModel[];
            })
        )
    }
}
