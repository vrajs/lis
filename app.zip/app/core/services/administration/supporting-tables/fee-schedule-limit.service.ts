import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { FeeScheduleLimitModel, OData } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';
@Injectable()
export class FeeScheduleLimitService {

    apiBaseUrl: string = '/api/FeeScheduleLimit';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getFeeScheduleLimitData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<FeeScheduleLimitModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/FeeScheduleLimits`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<FeeScheduleLimitModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<FeeScheduleLimitModel>(res);
            })
        );
    }

    get(): Observable<FeeScheduleLimitModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleLimitModel[];
            })
        );
    }

    delete(Id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`);
    }

    getById(Id: number): Observable<FeeScheduleLimitModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleLimitModel;
            })
        );
    }

    // Here use json.stringify beacuse post method support json string.
    create(feeSchedule: FeeScheduleLimitModel): Observable<FeeScheduleLimitModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, feeSchedule).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as FeeScheduleLimitModel;
            })
        );
    }

    // Here use json.stringify beacuse put method support json string.
    update(feeSchedule: FeeScheduleLimitModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, feeSchedule);
    }
}
