import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { KeyValModel, OData, RegionModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class RegionService {

    apiBaseUrl: string = '/api/Region';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getRegionsData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RegionModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/Regions`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RegionModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RegionModel>(res);
            })
        );
    }

    getProductTypes(): Observable<KeyValModel[]> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrlForScroll(`${environment.serviceApiUrl}/odata/ProductTypes`,null);
        return this.httpClient.get<KeyValModel[]>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return res as KeyValModel[];
          })
        );
      }
    

    get(): Observable<RegionModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RegionModel[];
            })
        )
    }

    getById(regionID: number): Observable<RegionModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${regionID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RegionModel;
            })
        );

    }

    create(region: RegionModel): Observable<RegionModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, region).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RegionModel;
            })
        )
    }

    update(region: RegionModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, region);
    }

    delete(regionID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${regionID}`);
    }
}
