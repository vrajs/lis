import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { POSCodeModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()

export class POSCodeService {
    private apiBaseUrl: string = "/api/POSCode";

    constructor(private httpClient: HttpClient) {

    }

    getPOSCode(): Observable<POSCodeModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as POSCodeModel[];
            })
        )

    }
}