import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { KeyValModel, OData, RBRVSCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RBRVSCodeService {

    apiBaseUrl: string = '/api/RBRVSCode';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getRBRVSCodeData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RBRVSCodeModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/RBRVSCodes`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RBRVSCodeModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RBRVSCodeModel>(res);
            })
        );
    }

    get(): Observable<RBRVSCodeModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as RBRVSCodeModel[];
            })
        );
    }

    getById(rbrvsCodeID: number): Observable<RBRVSCodeModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${rbrvsCodeID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as RBRVSCodeModel;
            })
        );
    }

    create(rbrvsCode: RBRVSCodeModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, rbrvsCode).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as RBRVSCodeModel;
            })
        );
    }

    update(rbrvsCode: RBRVSCodeModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, rbrvsCode);
    }

    delete(rbrvsCodeID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${rbrvsCodeID}`);
    }

    getByTypeNumber(typeNumber: number): Observable<KeyValModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetByTypeNumber/${typeNumber}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as KeyValModel;
            })
        );
    }
}
