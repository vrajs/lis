import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { LocalityModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class LocalityService {

    apiBaseUrl: string = '/api/Locality';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getLocalityData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<LocalityModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/Localities`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<LocalityModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<LocalityModel>(res);
            })
        );
    }

    get(): Observable<LocalityModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as LocalityModel[];
            })
        );
    }

    getById(localityID: number): Observable<LocalityModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${localityID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as LocalityModel;
            })
        );
    }

    create(locality: LocalityModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, locality).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as LocalityModel;
            })
        )
    }

    update(locality: LocalityModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, locality);
    }

    delete(localityID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${localityID}`);
    }
}
