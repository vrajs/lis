import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { AgeGroupModel } from '@app/core/models';
import { map, Observable } from 'rxjs';
import { Utils } from '@app/common/app-global';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { OData } from '@app/core/models';

@Injectable()
export class AgeGroupService {

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

  getAgeGroupData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<AgeGroupModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/AgeGroups`, filteringArgs, sortingArgs, index, perPage);
    return this.httpClient.get<OData<AgeGroupModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<AgeGroupModel>(res);
      })
    );
  }
  get(): Observable<AgeGroupModel[]> {
    return this.httpClient.get<AgeGroupModel[]>(`${environment.serviceApiUrl}/api/AgeGroup`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as AgeGroupModel[];
      })
    )
  }
  getById(ageGroupId: number): Observable<AgeGroupModel> {
    return this.httpClient.get<AgeGroupModel>(`${environment.serviceApiUrl}/api/AgeGroup/${ageGroupId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as AgeGroupModel;
      })
    )
  }

  create(model: AgeGroupModel): Observable<AgeGroupModel> {
    return this.httpClient.post<AgeGroupModel>(`${environment.serviceApiUrl}/api/AgeGroup`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as AgeGroupModel;
      })
    )
  }

  update(model: AgeGroupModel): Observable<AgeGroupModel> {
    return this.httpClient.put<AgeGroupModel>(`${environment.serviceApiUrl}/api/AgeGroup`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as AgeGroupModel;
      })
    )
  }

  delete(ageGroupId: number) {
    return this.httpClient.delete<AgeGroupModel>(`${environment.serviceApiUrl}/api/AgeGroup/${ageGroupId}`);
  }
}
