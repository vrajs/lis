import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { PlanCapitationModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class PlanCapitationService {
    apiBaseUrl: string = '/api/PlanCapitation';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<PlanCapitationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as PlanCapitationModel[];
            })
        )
    }

    delete(Id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`);
    }

    getById(Id: number): Observable<PlanCapitationModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as PlanCapitationModel;
            })
        );
    }

    // Here use json.stringify beacuse post method support json string.
    create(capitation: PlanCapitationModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, capitation);
    }

    // Here use json.stringify beacuse put method support json string.
    update(capitation: PlanCapitationModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, capitation);
    }

    getByCapitation(capitationHeaderID: number) {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/PlanCapitation/${capitationHeaderID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as PlanCapitationModel[];
            })
        );
    }
}