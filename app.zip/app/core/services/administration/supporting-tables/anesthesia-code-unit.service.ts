import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { AnesthesiaCodeUnitModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class AnesthesiaCodeUnitService {

    apiBaseUrl: string = '/api/AnesthesiaCodeUnit';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getAnesthesiaCodeUnitData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<AnesthesiaCodeUnitModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/AnesthesiaCodeUnits`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<AnesthesiaCodeUnitModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<AnesthesiaCodeUnitModel>(res);
            })
        );
    }


    get(): Observable<AnesthesiaCodeUnitModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesthesiaCodeUnitModel[];
            })
        );
    }

    getById(anesthesiaCodeUnitID: number): Observable<AnesthesiaCodeUnitModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${anesthesiaCodeUnitID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesthesiaCodeUnitModel;
            })
        );
    }

    create(anesthesiaCodeUnit: AnesthesiaCodeUnitModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, anesthesiaCodeUnit).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as AnesthesiaCodeUnitModel;
            })
        );
    }

    update(anesthesiaCodeUnit: AnesthesiaCodeUnitModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, anesthesiaCodeUnit);
    }

    delete(anesthesiaCodeUnitID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${anesthesiaCodeUnitID}`);
    }
}
