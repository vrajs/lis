import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ModifierDiscountModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class ModifierDiscountService {

    apiBaseUrl: string = '/api/ModifierDiscount';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getModifierDiscountData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ModifierDiscountModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ModifierDiscounts`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ModifierDiscountModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ModifierDiscountModel>(res);
            })
        );
    }

    get(): Observable<ModifierDiscountModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ModifierDiscountModel[];
            })
        );
    }

    getById(modifierDiscountID: number): Observable<ModifierDiscountModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${modifierDiscountID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ModifierDiscountModel
            })
        );
    }

    create(modifierDiscount: ModifierDiscountModel): Observable<ModifierDiscountModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, modifierDiscount).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ModifierDiscountModel;
            })
        )
    }

    update(modifierDiscount: ModifierDiscountModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, modifierDiscount);
    }

    delete(modifierDiscountID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${modifierDiscountID}`);
    }
}
