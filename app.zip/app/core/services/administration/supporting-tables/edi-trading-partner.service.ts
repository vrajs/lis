import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { OData, TradingPartnerListModel, TradingPartnerModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";


@Injectable()
export class EDITradingPartnerService {
    apiBaseUrl: string = '/api/tradingpartner/';
    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }


    getEDITradingPartnerData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<TradingPartnerListModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/TradingPartners`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<TradingPartnerListModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<TradingPartnerListModel>(res);
            })
        );
    }

    public GetTradingPartnerList(strurl: string): Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}${strurl}`).pipe(
            map(res => {
                Utils.camelizeKeys(res);
                return res;
            })
        )
    }

    public GetddlTradingPartnerList(strurl: string): Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}${strurl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }

    public GetDataConfigByTId(strurl: string): Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}${strurl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }

    public SaveTradingPartnerDetails(objdata: any) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as TradingPartnerModel;
            })
        )
    }

    public UpdateTradingPartnerDetails(objdata: any) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }

    public GetTradingPartnerByTId(TID: number): Observable<TradingPartnerModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}GetTradingPartnerByTId/${TID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as TradingPartnerModel;
            })
        )
    }


    //DataFile Configuration

    public SaveDataFilConfigurationDetails(objdata: any) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }

}
