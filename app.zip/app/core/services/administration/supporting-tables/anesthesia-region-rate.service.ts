import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { AnesthesiaRegionRateModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../..";

@Injectable()
export class AnesthesiaRegionRateService {

    apiBaseUrl: string = '/api/AnesthesiaRegionRate';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }


    getAnesthesiaRegionRateData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<AnesthesiaRegionRateModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/AnesthesiaRegionRates`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<AnesthesiaRegionRateModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<AnesthesiaRegionRateModel>(res);
            })
        );
    }

    get(): Observable<AnesthesiaRegionRateModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesthesiaRegionRateModel[];
            })
        );
    }

    getById(anesthesiaRegionRateID: number): Observable<AnesthesiaRegionRateModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${anesthesiaRegionRateID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesthesiaRegionRateModel;
            })
        );
    }

    create(anesthesiaRegionRate: AnesthesiaRegionRateModel): Observable<AnesthesiaRegionRateModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, anesthesiaRegionRate).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as AnesthesiaRegionRateModel;
            })
        )
    }

    update(anesthesiaRegionRate: AnesthesiaRegionRateModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, anesthesiaRegionRate);
    }

    delete(anesthesiaRegionRateID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${anesthesiaRegionRateID}`);
    }
}
