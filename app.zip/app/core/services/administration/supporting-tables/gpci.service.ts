import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { GPCIModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class GPCIService {

    apiBaseUrl: string = '/api/GPCI';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getGPCIData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<GPCIModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GPCIs`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<GPCIModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<GPCIModel>(res);
            })
        );
    }

    get(): Observable<GPCIModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as GPCIModel[];
            })
        );
    }

    getById(gpciID: number): Observable<GPCIModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${gpciID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as GPCIModel;
            })
        );
    }

    create(gpci: GPCIModel): Observable<GPCIModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, gpci).pipe(
            map(res =>{
                res = Utils.camelizeKeys(res);
                return res as GPCIModel;
            })
        );
    }

    update(gpci: GPCIModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, gpci);
    }

    delete(gpciID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${gpciID}`);
    }
}
