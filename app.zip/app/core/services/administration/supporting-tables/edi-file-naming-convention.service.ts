import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { FileNamingConventionModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { rest } from 'lodash';
import { map, Observable } from 'rxjs';

@Injectable()
export class EDIFileNamingConventionService {

    apiBaseUrl: string = '/api/FileNamingConvention/';
    constructor(private httpClient: HttpClient) {
    }

    public SaveDetails(objdata: FileNamingConventionModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as FileNamingConventionModel;
            })
        )
    }

    public UpdateDetails(objdata: any) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res =>{
                res = Utils.camelizeKeys(res);
                return res as FileNamingConventionModel;
            })
        )
    }

    public getDetails(ID: any): Observable<FileNamingConventionModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}${ID}`).pipe(
            map(res =>{
                res = Utils.camelizeKeys(res);
                return res as FileNamingConventionModel;
            })
        )
    }

    public DeleteDetails(id: number, Did: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}${id}/${Did}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }
}
