import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class EDIDataConfigurationService {
    apiBaseUrl: string = '/api/DataConfiguration/';
    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getEDIConfigData(tidNumber: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<any>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/DataConfigurations`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<any>>(`${dynamicUrl}&TradingPartnerId=${tidNumber}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<any>(res);
            })
        );
    }


    public SaveDataConfigurationDetails(objdata: any) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }
    public UpdateDataConfigurationDetails(objdata: any) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, objdata).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }

    public DeleteDataConfigurationDetails(id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}${id}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        )
    }



}
