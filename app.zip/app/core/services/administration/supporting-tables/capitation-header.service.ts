import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { CapitationHeaderModel, OData, PlanCapitationModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../..";

@Injectable()
export class CapitationHeaderservice {
    apiBaseUrl: string = '/api/CapitationHeader';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getCapitationHeaderData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<CapitationHeaderModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetCapitations`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<CapitationHeaderModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<CapitationHeaderModel>(res);
            })
        );
    }

    get(): Observable<CapitationHeaderModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as CapitationHeaderModel[];
            })
        );
    }

    delete(Id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`);
    }

    getById(Id: number): Observable<CapitationHeaderModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as CapitationHeaderModel;
            })
        );
    }

    // Here use json.stringify beacuse post method support json string.
    create(capitation: CapitationHeaderModel): Observable<CapitationHeaderModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, capitation).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as CapitationHeaderModel;
            })
        )
    }

    // Here use json.stringify beacuse put method support json string.
    update(capitation: CapitationHeaderModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, capitation);
    }

    getPlanRateCapitation(capitationHeaderID: number) {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/PlanCapitation/${capitationHeaderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as PlanCapitationModel[];
            })
        );
    }
}
