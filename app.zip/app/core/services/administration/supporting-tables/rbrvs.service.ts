import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData, RBRVSModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RBRVSService {

    apiBaseUrl: string = '/api/RBRVS';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getRBRVSData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RBRVSModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/RBRVSList`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RBRVSModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RBRVSModel>(res);
            })
        );
    }

    get(): Observable<RBRVSModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as RBRVSModel[];
            })
        );
    }

    getById(rbrvsid: number): Observable<RBRVSModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${rbrvsid}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RBRVSModel;
            })
        );
    }

    create(rbrvs: RBRVSModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, rbrvs).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RBRVSModel;
            })
        );
    }

    update(rbrvs: RBRVSModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, rbrvs);
    }

    // createOrUpdate(rbrvs: RBRVSModel) {
    //     if (rbrvs.rbrvsid === 0) {
    //         return this.httpClient.post(this.apiBaseUrl, JSON.stringify(rbrvs));
    //     }
    //     else {
    //         return this.httpClient.put(this.apiBaseUrl, JSON.stringify(rbrvs));
    //     }
    // }

    delete(rbrvsid: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${rbrvsid}`);
    }
}
