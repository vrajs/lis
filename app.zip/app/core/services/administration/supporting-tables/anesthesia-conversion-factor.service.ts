import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { AnesConversionFactorModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class AnesConversionFactorService {

    apiBaseUrl: string = '/api/AnesConversionFactor';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getAnesthesiaConversionFactorData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<AnesConversionFactorModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/AnesConversionFactors`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<AnesConversionFactorModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<AnesConversionFactorModel>(res);
            })
        );
    }

    get(): Observable<AnesConversionFactorModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetAnesConversionFactors`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesConversionFactorModel[];
            })
        )
    }

    getById(anesConversionFactorID: number): Observable<AnesConversionFactorModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${anesConversionFactorID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesConversionFactorModel;
            })

        )
    }

    getAnesConversionFactorByPOSCode(poscode: string): Observable<AnesConversionFactorModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetAnesConversionFactorByPOSCode?POSCode=${poscode}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as AnesConversionFactorModel[];
            })
        )
    }

    create(anesConversionFactor: AnesConversionFactorModel): Observable<AnesConversionFactorModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, anesConversionFactor).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as AnesConversionFactorModel;
            })
        );
    }

    update(anesConversionFactor: AnesConversionFactorModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, anesConversionFactor);
    }

    delete(anesConversionFactorID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${anesConversionFactorID}`);
    }
}
