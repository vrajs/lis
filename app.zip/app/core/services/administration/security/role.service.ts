//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-global';
import { RoleModel, RoleTypeClaimModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()
export class RoleService {

  constructor(private httpClient: HttpClient) { }

  /**
   * Purpose: Method is use for get role list
   * @author Gaurav Vaghela # on 21-APR-2022 - Get method
   */
  getRoleList(): Observable<RoleModel[]> {
    return this.httpClient.get<RoleModel[]>(`${environment.identityApiUrl}/api/account/GetRoles`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RoleModel[];
      })
    );    
  }

  /**
   * Purpose: Method is use for get roles by id
   * @author Gaurav Vaghela # on 21-APR-2022 - Get method
   */
  getByID(id: string): Observable<RoleModel> {
    return this.httpClient.get<RoleModel>(`${environment.identityApiUrl}/api/account/roles/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RoleModel;
      })
    );       
  }

  /**
   * Purpose: Method is use to create role
   * @author Gaurav Vaghela # on 21-APR-2022 - post method
   */
  createRole(model: RoleModel): Observable<RoleModel[]>{
    return this.httpClient.post<RoleModel[]>(`${environment.identityApiUrl}/api/account/roles`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RoleModel[];
      })
    );
  }

  /**
   * Purpose: Method is use to update role
   * @author Gaurav Vaghela # on 21-APR-2022 - Put method
   */
  updateRole(model: RoleModel): Observable<RoleModel[]>{
    return this.httpClient.put<RoleModel[]>(`${environment.identityApiUrl}/api/account/roles/${model.id}`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RoleModel[];
      })
    );
  }
  
  /**
   * Purpose: Method is use to get permission list
   * @author Gaurav Vaghela # on 21-APR-2022 - Get method
   */
  getPermissiontList(): Observable<RoleTypeClaimModel[]> {
    return this.httpClient.get<RoleTypeClaimModel[]>(`${environment.identityApiUrl}/api/RoleTypeClaims/GetRoleTypeClaims`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RoleTypeClaimModel[];
      })
    );      
  }

  /**
   * Purpose: Method is use to delete role
   * @author Gaurav Vaghela # on 21-APR-2022 - Delete method
   */
  deleteRole(id: string): Observable<RoleModel> {
    return this.httpClient.delete<RoleModel>(`${environment.identityApiUrl}/api/account/roles/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RoleModel;
      })
    );
  }

}
