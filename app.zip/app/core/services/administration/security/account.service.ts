import { Injectable } from '@angular/core';
import { AuthService } from '@app/core/services';
import { PermissionValues, UserModel } from '@app/core/models';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';

@Injectable()
export class AccountService {

    private readonly _usersUrl: string = "api/account/users";
    private readonly _currentUserUrl: string = "api/account/users/me";   
  
  constructor(private httpClient: HttpClient, private authService: AuthService) {
  }

  getUser(userId?: string): Observable<UserModel> {    
    let endpointUrl = userId ? environment.identityApiUrl + '/' + this._usersUrl + `/${userId}` : environment.identityApiUrl + '/' + this._currentUserUrl;

    return this.httpClient.get<UserModel>(`${endpointUrl}`).pipe(
      map(res => {
        return res as UserModel;
      })
    )      
  }  

  userHasPermission(permissionValue: PermissionValues): boolean {
      return this.permissions.some(p => p === permissionValue);
  }

  get permissions(): PermissionValues[] {
      return this.authService.userPermissions;
  }

  get currentUser() {
      return this.authService.currentUser;
  }
}
