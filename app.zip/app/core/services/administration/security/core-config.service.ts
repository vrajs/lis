import { Injectable } from '@angular/core';
import { CoreConfigSettings, IconFiles } from '@app/core/models';

@Injectable()
export class CoreConfigService {

  constructor() { }

  showLanguageSelector = true;
    showUserControls = true;
    showStatusBar = true;
    showStatusBarBreakpoint = 0;
    socialIcons = new Array<IconFiles>();

    configure(settings: CoreConfigSettings) : void {
        Object.assign(this, settings);
    }

}
