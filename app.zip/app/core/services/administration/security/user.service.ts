//#region System Namespace
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-functions';
import { UserModel, UserDataAuthorizationModel, UserEditModel, ClientUserModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()
export class UserService {

  constructor(private httpClient: HttpClient) { }

   /**
   * Purpose: Method is use for get user list
   * @author Gaurav Vaghela # on 21-APR-2022 - Get method
   */
    getUserList(model: ClientUserModel): Observable<UserModel[]> {
      return this.httpClient.post<UserModel[]>(`${environment.identityApiUrl}/api/account/users/`, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res as UserModel[];
        })
      );
    }

   /**
   * Purpose: Method is use for get user by id
   * @author Gaurav Vaghela # on 21-APR-2022 - Get method
   */  
  getByID(id: string): Observable<UserEditModel> {
    return this.httpClient.get<UserEditModel>(`${environment.identityApiUrl}/api/account/users/${id}`).pipe(
      map(res =>
        {        
        res = Utils.camelizeKeys(res);
        return res as UserEditModel;
      })
    );      
  }

  /**
   * Purpose: Method is use to link user with current client.
   * @author Gaurav Vaghela #O9-392 on 09-SEP-2022 - Link User
   */  
  linkUser(model: UserEditModel): Observable<UserModel> {  
      return this.httpClient.post<UserModel>(`${environment.identityApiUrl}/api/account/LinkUser`, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res;
        })
      );
    }   

     /**
   * Purpose: Method is use to accept and reject user registration request by admin.
   * @author Gaurav Vaghela #O9-392 on 09-SEP-2022 - Link User
   */ 
    AcceptRejectRequest(model: ClientUserModel): Observable<UserModel> {  
      return this.httpClient.post<UserModel>(`${environment.identityApiUrl}/api/user/AcceptRejectRequest`, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res;
        })
      );
    }  
  
   /**
   * Purpose: Method is use for get user by id
   * @author Gaurav Vaghela # on 21-APR-2022 - Get method
   */  
    getByUserName(userName: string): Observable<UserEditModel> {
      return this.httpClient.get<UserEditModel>(`${environment.identityApiUrl}/api/account/users/username/${userName}`).pipe(
        map(res =>
          {        
          res = Utils.camelizeKeys(res);
          return res as UserEditModel;
        })
      );      
    }

   /**
   * Purpose: Method is use to create user
   * @author Gaurav Vaghela # on 21-APR-2022 - Post method
   */
  createUser(model: UserModel): Observable<HttpResponse<UserModel>>{    
    if (model.id === "0") {
      delete model.id;
      return this.httpClient.post<UserModel>(`${environment.identityApiUrl}/api/account`, model, { observe: 'response' });
    } 
  }
  
   /**
   * Purpose: Method is use to update user
   * @author Gaurav Vaghela # on 21-APR-2022 - put method
   */
  updateUser(model: UserModel): Observable<string>{
    return this.httpClient.put<string>(`${environment.identityApiUrl}/api/account`, model).pipe(
      map(res => {
        return res as string;
      })
    );
  }
  
   /**
   * Purpose: Method is use to add data authorization of user
   * @author Gaurav Vaghela # on 21-APR-2022 - Post method
   */
  addUserDataAuthorization(model: UserDataAuthorizationModel): Observable<string>{
    return this.httpClient.post(`${environment.serviceApiUrl}/api/UserDataAuthorization`, model).pipe(
      map(res => {
        return res as string;
      })
    );
  }
  
   /**
   * Purpose: Method is use to update user profile
   * @author Gaurav Vaghela # on 21-APR-2022 - Post method
   */
  updateProfile(model: UserModel) {
    return this.httpClient.post(`${environment.identityApiUrl}/api/account/UpdateUserProfile`, model);
  }
  
   /**
   * Purpose: Method is use for enable-disable user
   * @author Gaurav Vaghela # on 21-APR-2022 - Put method
   */
    activeInActiveClientUserMapping(model: ClientUserModel) {
      return this.httpClient.post(`${environment.identityApiUrl}/api/user/ActiveInactiveClientUserMapping`, model);
    }

  /**
   * Purpose: Method is use to create new password for user
   * @author Gaurav Vaghela # on 21-APR-2022 - Post method
   */
  createPasswordEmail(model: UserModel): Observable<string> {
    return this.httpClient.post<string>(`${environment.identityApiUrl}/api/account/CreatePasswordEmail`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as string;
      })
    );
  }

  /**
   * Purpose: Method is use for forgot password for user
   * @author Gaurav Vaghela # on 21-APR-2022 - Post method
   */
  forgotOrResetPasswordEmail(model: UserEditModel): Observable<string> {
    return this.httpClient.post(`${environment.identityApiUrl}/api/account/ForgotOrResetPasswordEmail`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as string;
      })
    );
  }

  /**
   * Purpose: Method is use for reset password for user
   * @author Gaurav Vaghela # on 21-APR-2022 - Put method
   */
  resetPassword(model: UserModel) {
    return this.httpClient.put(`${environment.identityApiUrl}/api/account/ResetPassword`, model);
  }

  /**
   * Purpose: Method is use for change password for user
   * @author Gaurav Vaghela # on 21-APR-2022 - Put method
   */
  changePassword(model: UserModel) {
    return this.httpClient.put(`${environment.identityApiUrl}/api/account/ChangePassword`, model);
  }

}
