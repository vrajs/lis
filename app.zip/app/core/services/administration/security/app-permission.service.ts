import { Injectable } from '@angular/core';
import { Permission } from '@app/core/models';
import { AccountService } from '@app/core/services';

@Injectable()
export class AppPermissionService {

  constructor(private accountService: AccountService) { }


  get permission_to_view_users_account_details() {
    return this.accountService.userHasPermission(Permission.permission_to_view_users_account_details);
}

get permission_to_create_update_users_account_details() {
    return this.accountService.userHasPermission(Permission.permission_to_create_update_users_account_details);
}

get permission_to_view_available_roles() {
    return this.accountService.userHasPermission(Permission.permission_to_view_available_roles);
}

get permission_to_create_update_roles() {
    return this.accountService.userHasPermission(Permission.permission_to_create_update_roles);
}

get permission_to_view_professional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_view_professional_claims);
}

get permission_to_add_professional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_add_professional_claims);
}

get permission_to_update_professional_claims(): boolean {
    return this.accountService.userHasPermission(Permission.permission_to_update_professional_claims);
}

get permission_to_delete_professional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_professional_claims);
}

get permission_to_access_alternate_feeschedule_in_professional_claim() {
    return this.accountService.userHasPermission(Permission.permission_to_access_alternate_feeschedule_in_professional_claim);
}

get permission_to_manual_override_professional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_manual_override_professional_claims);
}

get permission_to_update_professional_claim_edits() {
    return this.accountService.userHasPermission(Permission.permission_to_update_professional_claim_edits);
}

get permission_to_update_professional_claim_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_update_professional_claim_notes);
}

get permission_to_view_institutional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_view_institutional_claims);
}

get permission_to_add_institutional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_add_institutional_claims);
}

get permission_to_update_institutional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_update_institutional_claims);
}

get permission_to_delete_institutional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_institutional_claims);
}

get permission_to_access_alternate_feeschedule_in_institutional_claim() {
    return this.accountService.userHasPermission(Permission.permission_to_access_alternate_feeschedule_in_institutional_claim);
}

get permission_to_manual_override_institutional_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_manual_override_institutional_claims);
}

get permission_to_update_institutional_claim_edits() {
    return this.accountService.userHasPermission(Permission.permission_to_update_institutional_claim_edits);
}

get permission_to_update_institutional_claim_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_update_institutional_claim_notes);
}

get permission_to_view_dental_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_view_dental_claims);
}

get permission_to_add_dental_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_add_dental_claims);
}

get permission_to_update_dental_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_update_dental_claims);
}

get permission_to_delete_dental_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_dental_claims);
}

get permission_to_access_alternate_feeschedule_in_dental_claim() {
    return this.accountService.userHasPermission(Permission.permission_to_access_alternate_feeschedule_in_dental_claim);
}

get permission_to_manual_override_dental_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_manual_override_dental_claims);
}

get permission_to_update_dental_claime_dits() {
    return this.accountService.userHasPermission(Permission.permission_to_update_dental_claime_dits);
}

get permission_to_update_dental_claim_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_update_dental_claim_notes);
}

get permission_to_view_lab_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_view_lab_claims);
}

get permission_to_add_lab_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_add_lab_claims);
}

get permission_to_update_lab_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_update_lab_claims);
}

get permission_to_delete_lab_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_lab_claims);
}

get permission_to_access_alternate_feeschedule_in_lab_claim() {
    return this.accountService.userHasPermission(Permission.permission_to_access_alternate_feeschedule_in_lab_claim);
}

get permission_to_manual_override_lab_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_manual_override_lab_claims);
}

get permission_to_update_lab_claime_dits() {
    return this.accountService.userHasPermission(Permission.permission_to_update_lab_claime_dits);
}

get permission_to_update_lab_claim_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_update_lab_claim_notes);
}

get permission_to_view_pharmacy_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_view_pharmacy_claims);
}

get permission_to_add_pharmacy_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_add_pharmacy_claims);
}

get permission_to_update_pharmacy_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_update_pharmacy_claims);
}

get permission_to_delete_pharmacy_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_pharmacy_claims);
}

get permission_to_access_alternate_feeschedule_in_pharmacy_claim() {
    return this.accountService.userHasPermission(Permission.permission_to_access_alternate_feeschedule_in_pharmacy_claim);
}

get permission_to_manual_override_pharmacy_claims() {
    return this.accountService.userHasPermission(Permission.permission_to_manual_override_pharmacy_claims);
}

get permission_to_update_pharmacy_claime_dits() {
    return this.accountService.userHasPermission(Permission.permission_to_update_pharmacy_claime_dits);
}

get permission_to_update_pharmacy_claim_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_update_pharmacy_claim_notes);
}

get permission_to_view_claim_refund() {
    return this.accountService.userHasPermission(Permission.permission_to_view_claim_refund);
}

get permission_to_add_claim_refund() {
    return this.accountService.userHasPermission(Permission.permission_to_add_claim_refund);
}

get permission_to_update_claim_refund() {
    return this.accountService.userHasPermission(Permission.permission_to_update_claim_refund);
}

get permission_to_delete_claim_refund() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_claim_refund);
}

get all_permission_for_claims_mass_adjudication() {
    return this.accountService.userHasPermission(Permission.all_permission_for_claims_mass_adjudication);
}

get permission_to_view_member() {
    return this.accountService.userHasPermission(Permission.permission_to_view_member);
}

get permission_to_add_member() {
    return this.accountService.userHasPermission(Permission.permission_to_add_member);
}

get permission_to_update_member() {
    return this.accountService.userHasPermission(Permission.permission_to_update_member);
}

get permission_to_delete_member() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_member);
}

get permission_to_view_member_billing() {
    return this.accountService.userHasPermission(Permission.permission_to_view_member_billing);
}

get permission_to_add_member_billing() {
    return this.accountService.userHasPermission(Permission.permission_to_add_member_billing);
}

get permission_to_update_member_billing() {
    return this.accountService.userHasPermission(Permission.permission_to_update_member_billing);
}

get permission_to_delete_member_billing() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_member_billing);
}

get permission_to_view_member_billing_paymentmethod() {
    return this.accountService.userHasPermission(Permission.permission_to_view_member_billing_paymentmethod);
}

get permission_to_add_member_billing_paymentmethod() {
    return this.accountService.userHasPermission(Permission.permission_to_add_member_billing_paymentmethod);
}

get permission_to_update_member_billing_paymentmethod() {
    return this.accountService.userHasPermission(Permission.permission_to_update_member_billing_paymentmethod);
}

get permission_to_delete_member_billing_paymentmethod() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_member_billing_paymentmethod);
}

get permission_to_access_member_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_access_member_notes);
}

get permission_to_view_provider() {
    return this.accountService.userHasPermission(Permission.permission_to_view_provider);
}

get permission_to_add_provider() {
    return this.accountService.userHasPermission(Permission.permission_to_add_provider);
}

get permission_to_update_provider() {
    return this.accountService.userHasPermission(Permission.permission_to_update_provider);
}

get permission_to_delete_provider() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_provider);
}

get permission_to_access_provider_notes() {
    return this.accountService.userHasPermission(Permission.permission_to_access_provider_notes);
}

get permission_to_view_ipa() {
    return this.accountService.userHasPermission(Permission.permission_to_view_ipa);
}

get permission_to_add_ipa() {
    return this.accountService.userHasPermission(Permission.permission_to_add_ipa);
}

get permission_to_update_ipa() {
    return this.accountService.userHasPermission(Permission.permission_to_update_ipa);
}

get permission_to_delete_ipa() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_ipa);
}

get permission_to_view_group() {
    return this.accountService.userHasPermission(Permission.permission_to_view_group);
}

get permission_to_add_group() {
    return this.accountService.userHasPermission(Permission.permission_to_add_group);
}

get permission_to_update_group() {
    return this.accountService.userHasPermission(Permission.permission_to_update_group);
}

get permission_to_delete_group() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_group);
}

get permission_to_view_lob() {
    return this.accountService.userHasPermission(Permission.permission_to_view_lob);
}

get permission_to_add_update_lob() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_lob);
}

get permission_to_delete_lob() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_lob);
}

get permission_to_view_service_groups() {
    return this.accountService.userHasPermission(Permission.permission_to_view_service_groups);
}

get permission_to_add_update_service_groups() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_service_groups);
}

get permission_to_delete_service_groups() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_service_groups);
}

get permission_to_view_contracts() {
    return this.accountService.userHasPermission(Permission.permission_to_view_contracts);
}

get permission_to_add_update_contracts() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_contracts);
}

get permission_to_delete_contracts() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_contracts);
}

get permission_to_view_benefits() {
    return this.accountService.userHasPermission(Permission.permission_to_view_benefits);
}

get permission_to_add_update_benefits() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_benefits);
}

get permission_to_delete_benefits() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_benefits);
}

get permission_to_view_plan_benefit_package() {
    return this.accountService.userHasPermission(Permission.permission_to_view_plan_benefit_package);
}

get permission_to_add_update_plan_benefit_package() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_plan_benefit_package);
}

get permission_to_delete_plan_benefit_package() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_plan_benefit_package);
}

get permission_to_view_organizational_structure() {
    return this.accountService.userHasPermission(Permission.permission_to_view_organizational_structure);
}

get permission_to_add_update_organizational_structure() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_organizational_structure);
}

get permission_to_delete_organizational_structure() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_organizational_structure);
}

get permission_to_view_feeschedule_limits() {
    return this.accountService.userHasPermission(Permission.permission_to_view_feeschedule_limits);
}

get permission_to_add_update_feeschedule_limits() {
    return this.accountService.userHasPermission(Permission.permission_to_add_update_feeschedule_limits);
}

get permission_to_delete_feeschedule_limits() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_feeschedule_limits);
}

get permission_to_view_UCRFeeSchedule() {
    return this.accountService.userHasPermission(Permission.permission_to_view_UCRFeeSchedule);
}

get permission_to_add_UCRFeeSchedule() {
    return this.accountService.userHasPermission(Permission.permission_to_add_UCRFeeSchedule);
}

get permission_to_update_UCRFeeSchedule() {
    return this.accountService.userHasPermission(Permission.permission_to_update_UCRFeeSchedule);
}

get permission_to_delete_UCRFeeSchedule() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_UCRFeeSchedule);
}

get permission_to_copy_UCRFeeSchedule() {
    return this.accountService.userHasPermission(Permission.permission_to_copy_UCRFeeSchedule);
}

get permission_to_view_RBRVSCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_RBRVSCode);
}

get permission_to_add_RBRVSCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_RBRVSCode);
}

get permission_to_update_RBRVSCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_RBRVSCode);
}

get permission_to_delete_RBRVSCode() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_RBRVSCode);
}

get permission_to_view_RBRVS() {
    return this.accountService.userHasPermission(Permission.permission_to_view_RBRVS);
}

get permission_to_add_RBRVS() {
    return this.accountService.userHasPermission(Permission.permission_to_add_RBRVS);
}

get permission_to_update_RBRVS() {
    return this.accountService.userHasPermission(Permission.permission_to_update_RBRVS);
}

get permission_to_delete_RBRVS() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_RBRVS);
}

get permission_to_view_GPCI() {
    return this.accountService.userHasPermission(Permission.permission_to_view_GPCI);
}

get permission_to_add_GPCI() {
    return this.accountService.userHasPermission(Permission.permission_to_add_GPCI);
}

get permission_to_update_GPCI() {
    return this.accountService.userHasPermission(Permission.permission_to_update_GPCI);
}

get permission_to_delete_GPCI() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_GPCI);
}

get permission_to_view_Locality() {
    return this.accountService.userHasPermission(Permission.permission_to_view_Locality);
}

get permission_to_add_Locality() {
    return this.accountService.userHasPermission(Permission.permission_to_add_Locality);
}

get permission_to_update_Locality() {
    return this.accountService.userHasPermission(Permission.permission_to_update_Locality);
}

get permission_to_delete_Locality() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_Locality);
}


get permission_to_view_AgeCategoies() {
    return this.accountService.userHasPermission(Permission.permission_to_view_AgeCategoies);
}

get permission_to_manage_AgeCatergoies() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_AgeCatergoies);
}

get permission_to_delete_AgeCategories() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_AgeCategories);
}

get permission_to_view_AnesthesiaRegionRates() {
    return this.accountService.userHasPermission(Permission.permission_to_view_AnesthesiaRegionRates);
}

get permission_to_manage_AnesthesiaRegionRates() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_AnesthesiaRegionRates);
}

get permission_to_delete_AnesthesiaRegionRates() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_AnesthesiaRegionRates);
}

get permission_to_view_TimelyFiling() {
    return this.accountService.userHasPermission(Permission.permission_to_view_TimelyFiling);
}

get permission_to_manage_TimelyFiling() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_TimelyFiling);
}

get permission_to_delete_TimelyFiling() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_TimelyFiling);
}

get permission_to_view_InterestQuickPay() {
    return this.accountService.userHasPermission(Permission.permission_to_view_InterestQuickPay);
}

get permission_to_manage_InterestQuickPay() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_InterestQuickPay);
}

get permission_to_delete_InterestQuickPay() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_InterestQuickPay);
}

get permission_to_view_ModifierDiscountGroup() {
    return this.accountService.userHasPermission(Permission.permission_to_view_ModifierDiscountGroup);
}

get permission_to_manage_ModifierDiscountGroup() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_ModifierDiscountGroup);
}

get permission_to_delete_ModifierDiscountGroup() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_ModifierDiscountGroup);
}

get permission_to_view_Capitation() {
    return this.accountService.userHasPermission(Permission.permission_to_view_Capitation);
}

get permission_to_manage_Capitation() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_Capitation);
}

get permission_to_delete_Capitation() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_Capitation);
}

get permission_to_view_EDITradingPartner() {
    return this.accountService.userHasPermission(Permission.permission_to_view_EDITradingPartner);
}

get permission_to_manage_EDITradingPartner() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_EDITradingPartner);
}

get permission_to_delete_EDITradingPartner() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_EDITradingPartner);
}

get permission_to_view_Regions() {
    return this.accountService.userHasPermission(Permission.permission_to_view_Regions);
}

get permission_to_manage_Regions() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_Regions);
}

get permission_to_delete_Regions() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_Regions);
}

get permission_to_view_AnesthesiaConversionFactor() {
    return this.accountService.userHasPermission(Permission.permission_to_view_AnesthesiaConversionFactor);
}

get permission_to_manage_AnesthesiaConversionFactor() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_AnesthesiaConversionFactor);
}

get permission_to_delete_AnesthesiaConversionFactor() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_AnesthesiaConversionFactor);
}

get permission_to_view_AnesthesiaCodeUnit() {
    return this.accountService.userHasPermission(Permission.permission_to_view_AnesthesiaCodeUnit);
}

get permission_to_manage_AnesthesiaCodeUnit() {
    return this.accountService.userHasPermission(Permission.permission_to_manage_AnesthesiaCodeUnit);
}

get permission_to_delete_AnesthesiaCodeUnit() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_AnesthesiaCodeUnit);
}

get permission_to_view_CPTCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_CPTCode);
}

get permission_to_add_CPTCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_CPTCode);
}

get permission_to_update_CPTCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_CPTCode);
}

get permission_to_view_ICDCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_ICDCode);
}

get permission_to_add_ICDCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_ICDCode);
} 

get permission_to_update_ICDCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_ICDCode);
}

get permission_to_view_RevenueCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_RevenueCode);
}

get permission_to_add_RevenueCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_RevenueCode);
}

get permission_to_update_RevenueCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_RevenueCode);
}

get permission_to_view_DRGCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_DRGCode);
}

get permission_to_add_DRGCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_DRGCode);
}

get permission_to_update_DRGCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_DRGCode);
}

get permission_to_view_PlaceOfService() {
    return this.accountService.userHasPermission(Permission.permission_to_view_PlaceOfService);
}

get permission_to_add_PlaceOfService() {
    return this.accountService.userHasPermission(Permission.permission_to_add_PlaceOfService);
}

get permission_to_update_PlaceOfService() {
    return this.accountService.userHasPermission(Permission.permission_to_update_PlaceOfService);
}

get permission_to_view_NDCCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_NDCCode);
}

get permission_to_add_NDCCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_NDCCode);
}

get permission_to_update_NDCCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_NDCCode);
}

get permission_to_view_HCCCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_HCCCode);
}

get permission_to_add_HCCCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_HCCCode);
}

get permission_to_update_HCCCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_HCCCode);
}

get permission_to_view_ZipCodes() {
    return this.accountService.userHasPermission(Permission.permission_to_view_ZipCodes);
}

get permission_to_add_ZipCodes() {
    return this.accountService.userHasPermission(Permission.permission_to_add_ZipCodes);
}

get permission_to_update_ZipCodes() {
    return this.accountService.userHasPermission(Permission.permission_to_update_ZipCodes);
}

get permission_to_view_HomeGrownCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_HomeGrownCode);
}

get permission_to_add_HomeGrownCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_HomeGrownCode);
}

get permission_to_update_HomeGrownCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_HomeGrownCode);
}

get permission_to_delete_HomeGrownCode() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_HomeGrownCode);
}

get permission_to_view_CustomerSetting() {
    return this.accountService.userHasPermission(Permission.permission_to_view_CustomerSetting);
}

get permission_to_add_CustomerSetting() {
    return this.accountService.userHasPermission(Permission.permission_to_add_CustomerSetting);
}

get permission_to_update_CustomerSetting() {
    return this.accountService.userHasPermission(Permission.permission_to_update_CustomerSetting);
}

get permission_to_view_CodeType() {
    return this.accountService.userHasPermission(Permission.permission_to_view_CodeType);
}

get permission_to_view_CommonCode() {
    return this.accountService.userHasPermission(Permission.permission_to_view_CommonCode);
}

get permission_to_add_CommonCode() {
    return this.accountService.userHasPermission(Permission.permission_to_add_CommonCode);
}

get permission_to_update_CommonCode() {
    return this.accountService.userHasPermission(Permission.permission_to_update_CommonCode);
}

get permission_to_view_CommonCodeDisplayConfiguration() {
    return this.accountService.userHasPermission(Permission.permission_to_view_CommonCodeDisplayConfiguration);
}

get permission_to_add_CommonCodeDisplayConfiguration() {
    return this.accountService.userHasPermission(Permission.permission_to_add_CommonCodeDisplayConfiguration);
}

get permission_to_view_copay_coinsurance() {
    return this.accountService.userHasPermission(Permission.permission_to_view_copay_coinsurance);
}
get permission_to_add_copay_coinsurance() {
    return this.accountService.userHasPermission(Permission.permission_to_add_copay_coinsurance);
}
get permission_to_update_copay_coinsurance() {
    return this.accountService.userHasPermission(Permission.permission_to_update_copay_coinsurance);
}
get permission_to_delete_copay_coinsurance() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_copay_coinsurance);
}
get permission_to_view_location() {
    return this.accountService.userHasPermission(Permission.permission_to_view_location);
}
get permission_to_add_location() {
    return this.accountService.userHasPermission(Permission.permission_to_add_location);
}
get permission_to_update_location() {
    return this.accountService.userHasPermission(Permission.permission_to_update_location);
}
get permission_to_delete_location() {
    return this.accountService.userHasPermission(Permission.permission_to_delete_location);
}

}
