import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MenuItem } from '@app/core/models';
import { environment } from '@environments/environment';
import { FuseNavigationItem } from '@fuse/components/navigation';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private httpClient: HttpClient) { }

  get(): Observable<FuseNavigationItem[]>{
    return this.httpClient.get<FuseNavigationItem[]>(`${environment.serviceApiUrl}/api/Menu/GetMenu`).pipe(
      map(res => res as FuseNavigationItem[])
    );
  }
}
