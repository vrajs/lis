import { Injectable } from '@angular/core';
import { AppConstant } from '@app/common/app-constants';
import { Utils } from '@app/common/app-global';
import { LocalStoreManagerService } from '@app/core/services';

@Injectable({
    providedIn: 'root'
})
export class ConfigurationService {

  public static readonly appVersion: string = "1.0.0";

    public baseUrl: string = Utils.baseUrl().replace(/\/$/, '');
    public fallbackBaseUrl: string = "http://www.aaneel.com/kwicle";
    public loginUrl: string = "/Login";

    //***Specify default configurations here***
    public static readonly defaultLanguage: string = "en";
    public static readonly defaultHomeUrl: string = "/";
    //***End of defaults***  

    private _language: string = null;
    private _homeUrl: string = null;

    constructor(private localStorage: LocalStoreManagerService) {
        this.loadLocalChanges();
    }

    private loadLocalChanges() {

        if (this.localStorage.exists(AppConstant.LANGUAGE)) {
            this._language = this.localStorage.getDataObject<string>(AppConstant.LANGUAGE);
           // this.translationService.changeLanguage(this._language);
        }
        else {
            this.resetLanguage();
        }

        if (this.localStorage.exists(AppConstant.HOME_URL))
            this._homeUrl = this.localStorage.getDataObject<string>(AppConstant.HOME_URL);

    }

    private saveToLocalStore(data: any, key: string) {
        setTimeout(() => this.localStorage.savePermanentData(data, key));
    }

    public import(jsonValue: string) {

        this.clearLocalChanges();

        if (!jsonValue)
            return;

        //let importValue: UserConfiguration = Utilities.JSonTryParse(jsonValue);

        // if (importValue.language != null)
        //     this.language = importValue.language;

        // if (importValue.homeUrl != null)
        //     this.homeUrl = importValue.homeUrl;
    }

    public export(changesOnly = true): string {

        // let exportValue: UserConfiguration =
        //     {
        //         language: changesOnly ? this._language : this.language,
        //         homeUrl: changesOnly ? this._homeUrl : this.homeUrl
        //     };

        // return JSON.stringify(exportValue);
        return '';
    }

    public clearLocalChanges() {
        this._language = null;
        this._homeUrl = null;

        this.localStorage.deleteData(AppConstant.LANGUAGE);
        this.localStorage.deleteData(AppConstant.HOME_URL);

        this.resetLanguage();
    }

    private resetLanguage() {
        // let language = this.translationService.useBrowserLanguage();

        // if (language) {
        //     this._language = language;
        // }
        // else {
        //     this._language = this.translationService.changeLanguage()
        // }
    }

    set language(value: string) {
        this._language = value;
        this.saveToLocalStore(value, AppConstant.LANGUAGE);
        //this.translationService.changeLanguage(value);
    }
    get language() {
        if (this._language != null)
            return this._language;

        return ConfigurationService.defaultLanguage;
    }


    set homeUrl(value: string) {
        this._homeUrl = value;
        this.saveToLocalStore(value, AppConstant.HOME_URL);
    }
    get homeUrl() {
        if (this._homeUrl != null)
            return this._homeUrl;

        return ConfigurationService.defaultHomeUrl;
    }
}
