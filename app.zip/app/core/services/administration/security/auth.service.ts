//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Log, User, UserManager, UserManagerSettings, WebStorageStateStore } from 'oidc-client';
import { BehaviorSubject, map, Observable, Subject } from 'rxjs';
//#region

//#region Global Namespace
import { AppConstant } from '@app/common/app-constants';
import { AlertMessageType } from '@app/common/app-enum';
import { Utils } from '@app/common/app-functions';
import { ClientUserModel, PermissionValues, UserModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

//#region Service Namespace
import { ConfigurationService, LocalStoreManagerService, NotificationService } from '@app/core/services';
//#endregion

@Injectable({
    providedIn: 'root',
})
export class AuthService {

    //#region for Property Declaration
    public get homeUrl() {
        return this.configurations.homeUrl;
    }
    public logoutRedirectUrl: string;
    public reLoginDelegate: () => void;
    private previousIsLoggedInCheck = false;
    private _loginStatus = new Subject<boolean>();
    public _currentUserInfo = new BehaviorSubject<UserModel>(null);
    private userManager: UserManager;
    //#endregion

    constructor(
        private router: Router,
        private configurations: ConfigurationService,
        private localStorage: LocalStoreManagerService,
        private httpClient: HttpClient,
        private notificationService: NotificationService
    ) {

        this.initializeLoginStatus();
        this.userManager = new UserManager(getClientSettings());

        this.userManager.events.addAccessTokenExpired(() => {
            //call after token expired.
        });

        this.userManager.events.addAccessTokenExpiring(() => {
            if (Utils.isBlank(this.userManager)) {
                this.userManager = new UserManager(getClientSettings());
            }
            this.userManager
                .signinSilent()
                .then(function (user) { })
                .catch((error) => {
                    if (!Utils.isBlank(error) && error.message == AppConstant.identityNetworkError) {
                        this.notificationService.showMessage(AlertMessageType.Error, AppConstant.identityUnavailable);
                        this.removeLocalStore();
                    }
                });
        });

        this.userManager.events.addUserLoaded((args) => {
            this.userManager.getUser().then((user) => {
                this.processLoginResponse(user);
            });
        });

        this.userManager.events.addSilentRenewError(function (error) {
        });

        this.userManager.events.addUserSessionChanged(function () {
            //Session changes events
        });   

        this.userManager.events.addUserSignedOut(() => {
            this.userManager = new UserManager(getClientSettings());
            this.removeUserFromServer();
            this.redirectLogoutUser();
        });

        // Log.logger = console;
        // Log.level = Log.DEBUG;
    }

    /**
   * Purpose: Method is deciding login status
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    private initializeLoginStatus() {
        this.localStorage.getInitEvent().subscribe(() => {
            this.reevaluateLoginStatus();
        });
    }

    /**
   * Purpose: Method is use for verify code by identity server.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    public async signingSilentCallback(): Promise<void> {
        await this.userManager.signoutRedirectCallback();
    }

    /**
   * Purpose: Method is use for login user have client access or not.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    isUserHaveClientAccess(
        model: ClientUserModel
    ): Observable<ClientUserModel> {
        return this.httpClient
            .post<ClientUserModel>(
                `${environment.identityApiUrl}/api/user/GetClientUserMapping`,
                model
            )
            .pipe(
                map((res) => {
                    return res as ClientUserModel;
                })
            );
    }

    /**
   * Purpose: Method is use to give client access to users.
   * @author Gaurav Vaghela # on 0-SEP-2022
   */
    ClientUserAccess(
        model: ClientUserModel
    ): Observable<ClientUserModel> {
        return this.httpClient
            .post<ClientUserModel>(
                `${environment.identityApiUrl}/api/user/ClientUserAccess`,
                model
            )
            .pipe(
                map((res) => {
                    return res as ClientUserModel;
                })
            );
    }

    /**
   * Purpose: Method is use to remove user information from server and local.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    removeUserFromServer(): void {
        this.userManager.clearStaleState();
        this.userManager.removeUser();
        this.userManager.revokeAccessToken();
        this.removeLocalStore();
    }

    /**
   * Purpose: Method is use to remove user information from local storage.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    removeLocalStore(): void {
        this.localStorage.clearAllStorage();
        this.configurations.clearLocalChanges();
    }

    /**
   * Purpose: Method is use to store redirect url.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    storeRedirectUrl(url: string): void {
        this.localStorage.saveSessionData(url, AppConstant.REDIRECT_LOGIN_URL);
    }

    /**
   * Purpose: Method is use to redirect login user.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    redirectLoginUser() {
        let loginRedirectUrl = this.localStorage.getData(AppConstant.REDIRECT_LOGIN_URL);
        let redirect = loginRedirectUrl && loginRedirectUrl != ConfigurationService.defaultHomeUrl ? loginRedirectUrl : ConfigurationService.defaultHomeUrl;
        this.localStorage.deleteData(AppConstant.REDIRECT_LOGIN_URL);
        this.router.navigateByUrl(redirect);
    }

    /**
   * Purpose: Method is use to logout user.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    async redirectLogoutUser() {
        this.router.navigateByUrl('/login');
    }

    /**
   * Purpose: Method is use to login user.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    async login() {
        if (this.isLoggedIn) this.logout();

        return await this.userManager.signinRedirect();
    }

    /**
   * Purpose: Method is use to process user object which received from idetity server.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    public async processLoginResponse(user: any) {
        let response = null;

        if (Utils.isBlank(user)) {
            response = await this.userManager.signinRedirectCallback();
        } else {
            response = user;
        }

        if (!Utils.isBlank(response)) {
            let response_token = response;

            let accessToken = response_token.access_token;
            let idToken = response_token.id_token;

            if (accessToken == null)
                throw new Error('Received accessToken was empty');

            let refreshToken: string = response_token.refresh_token;
            let expiresIn: number = response_token.expires_in;

            let tokenExpiryDate = new Date();
            tokenExpiryDate.setSeconds(
                tokenExpiryDate.getSeconds() + expiresIn
            );            

            let decodedIdToken = Utils.decodeToken(response_token.access_token);

            let fullExpiryTime = decodedIdToken.exp;

            let permissions: PermissionValues[] = Array.isArray(
                decodedIdToken.permission
            )
                ? decodedIdToken.permission
                : [decodedIdToken.permission];

            if (!this.isLoggedIn)
                this.configurations.import(decodedIdToken.configuration);

            let user = new UserModel(
                decodedIdToken.sub,
                decodedIdToken.name,
                decodedIdToken.fullname,
                decodedIdToken.email,
                decodedIdToken.jobTitle,
                decodedIdToken.phone,
                Array.isArray(decodedIdToken.role)
                    ? decodedIdToken.role
                    : [decodedIdToken.role],
                '',
                decodedIdToken.displayName
            );
            user.isEnabled = true;

            this.saveUserDetails(
                user,
                permissions,
                accessToken,
                refreshToken,
                fullExpiryTime,
                true,
                idToken
            );

            this._currentUserInfo.next(user);

            this.reevaluateLoginStatus(user);

            return user;
        }
    }


    /**
   * Purpose: Method is use to store user object which received from idetity server.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    private saveUserDetails(
        user: UserModel,
        permissions: PermissionValues[],
        accessToken: string,
        refreshToken: string,
        expiresIn: Date,
        rememberMe: boolean,
        idToken: string
    ) {
        if (rememberMe) {
            this.localStorage.savePermanentData(
                accessToken,
                AppConstant.ACCESS_TOKEN
            );
            this.localStorage.savePermanentData(
                refreshToken,
                AppConstant.REFRESH_TOKEN
            );
            this.localStorage.savePermanentData(
                expiresIn,
                AppConstant.TOKEN_EXPIRES_IN
            );
            this.localStorage.savePermanentData(
                permissions,
                AppConstant.USER_PERMISSIONS
            );
            this.localStorage.savePermanentData(user, AppConstant.CURRENT_USER);
            this.localStorage.savePermanentData(idToken, AppConstant.ID_TOKEN);
        } else {
            this.localStorage.saveSyncedSessionData(
                accessToken,
                AppConstant.ACCESS_TOKEN
            );
            this.localStorage.saveSyncedSessionData(
                refreshToken,
                AppConstant.REFRESH_TOKEN
            );
            this.localStorage.saveSyncedSessionData(
                expiresIn,
                AppConstant.TOKEN_EXPIRES_IN
            );
            this.localStorage.saveSyncedSessionData(
                permissions,
                AppConstant.USER_PERMISSIONS
            );
            this.localStorage.saveSyncedSessionData(
                user,
                AppConstant.CURRENT_USER
            );
            this.localStorage.savePermanentData(idToken, AppConstant.ID_TOKEN);
        }

        this.localStorage.savePermanentData(
            rememberMe,
            AppConstant.REMEMBER_ME
        );
    }

    get currentUserInfo$(): Observable<UserModel> {
        return this._currentUserInfo.asObservable();
    }

    /**
   * Purpose: Method is use to save user have access of current client.
   * @author Gaurav Vaghela # on 08-SEP-2022
   */
    saveClientAccess(flag: boolean): void {
        this.localStorage.savePermanentData(flag, AppConstant.IS_CLIENTACCESS);
    }

    /**
  * Purpose: Method is use to logout user.
  * @author Gaurav Vaghela # on 08-SEP-2022
  */
    async logout(): Promise<void> {
        let id_Token = this.localStorage.getData(AppConstant.ID_TOKEN);
        await this.userManager
            .signoutRedirect({ id_token_hint: id_Token })
            .then((user) => { });
        var themeSchemeAndLayout = this.localStorage.localStorageGetItem(
            'themeSchemeAndLayout'
        );
        this.localStorage.clearAllStorage();
        this.configurations.clearLocalChanges();
        this.reevaluateLoginStatus();
        this.localStorage.localStorageSetItem(
            'themeSchemeAndLayout',
            themeSchemeAndLayout
        );
    }

    /**
  * Purpose: Method is use to revoluate login status of user.
  * @author Gaurav Vaghela # on 08-SEP-2022
  */
    private reevaluateLoginStatus(currentUser?: UserModel) {
        let user =
            currentUser ||
            this.localStorage.getDataObject<UserModel>(
                AppConstant.CURRENT_USER
            );
        let isLoggedIn = user != null;

        if (this.previousIsLoggedInCheck != isLoggedIn) {
            setTimeout(() => {
                this._loginStatus.next(isLoggedIn);
            });
        }

        this.previousIsLoggedInCheck = isLoggedIn;
    }

    /**
  * Purpose: Method is use to get user login status.
  * @author Gaurav Vaghela # on 08-SEP-2022
  */
    getLoginStatusEvent(): Observable<boolean> {
        return this._loginStatus.asObservable();
    }

    get currentUser(): UserModel {
        let user = this.localStorage.getDataObject<UserModel>(
            AppConstant.CURRENT_USER
        );
        this.reevaluateLoginStatus(user);

        return user;
    }

    get userPermissions(): PermissionValues[] {
        return (
            this.localStorage.getDataObject<PermissionValues[]>(
                AppConstant.USER_PERMISSIONS
            ) || []
        );
    }

    get accessToken(): string {
        this.reevaluateLoginStatus();
        return this.localStorage.getData(AppConstant.ACCESS_TOKEN);
    }

    get accessTokenExpiryFullTime() {
        return this.localStorage.getDataObject<Date>(
            AppConstant.TOKEN_EXPIRES_IN,
            true
        );
    }

    get isSessionExpired(): boolean {
        return !(
            this.accessTokenExpiryFullTime.valueOf() >
            Math.floor(new Date().getTime() / 1000)
        );
    }

    get isLoggedIn(): boolean {
        return this.currentUser != null;
    }

    get currentDate(): Date {
        return new Date();
    }

    get isClientAccess(): boolean {
        return this.localStorage.getDataObject<boolean>(
            AppConstant.IS_CLIENTACCESS
        );
    }
}

/**
* Purpose: Method is use to get Identity Server configuration environment wise.
* @author Gaurav Vaghela # on 08-SEP-2022
*/
export function getClientSettings(): UserManagerSettings {
    return {
        authority: environment.IdentityClientConfig.authority,
        client_id: environment.IdentityClientConfig.client_id,
        client_secret: environment.IdentityClientConfig.client_secret,
        redirect_uri: environment.IdentityClientConfig.redirect_uri,
        post_logout_redirect_uri:
            environment.IdentityClientConfig.post_logout_redirect_uri,
        response_type: environment.IdentityClientConfig.response_type,
        scope: environment.IdentityClientConfig.scope,
        loadUserInfo: environment.IdentityClientConfig.loadUserInfo,
        automaticSilentRenew:
            environment.IdentityClientConfig.automaticSilentRenew,
        silent_redirect_uri:
            environment.IdentityClientConfig.silent_redirect_uri,
        accessTokenExpiringNotificationTime:
            environment.IdentityClientConfig
                .accessTokenExpiringNotificationTime,
        revokeAccessTokenOnSignout:
            environment.IdentityClientConfig.revokeAccessTokenOnSignout,
        filterProtocolClaims:
            environment.IdentityClientConfig.filterProtocolClaims,
        includeIdTokenInSilentRenew:
            environment.IdentityClientConfig.includeIdTokenInSilentRenew,
        monitorSession: environment.IdentityClientConfig.monitorSession,
        userStore: new WebStorageStateStore({ store: window.localStorage }),
    };
}
