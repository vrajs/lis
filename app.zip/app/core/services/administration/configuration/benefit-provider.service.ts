//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { BenefitProviderModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class BenefitProviderService {

  constructor(private httpClient: HttpClient) { }

  /**
  * Purpose: Method is use to get benefit provider
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get benefit provider
  */
  get(): Observable<BenefitProviderModel[]> {
    return this.httpClient.get<BenefitProviderModel[]>(`${environment.serviceApiUrl}/api/BenefitProvider`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel[]
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit provider by id
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create benefit provider by id
  */
  getById(benefitCodeId: number): Observable<BenefitProviderModel> {
    return this.httpClient.get<BenefitProviderModel>(`${environment.serviceApiUrl}/api/BenefitProvider/${benefitCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit provider by benefit header id
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get benefit provider by benefit provider id
  */
  getByBenefitHeaderId(benefitHeaderId: number): Observable<BenefitProviderModel[]> {
    return this.httpClient.get<BenefitProviderModel[]>(`${environment.serviceApiUrl}/api/BenefitProvider/GetBenefitProviderByBenefitHeaderId/${benefitHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel[]
      })
    );
  }

  /**
  * Purpose: Method is use to create benefit provider
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create benefit provider
  */
  create(model: BenefitProviderModel): Observable<BenefitProviderModel> {
    return this.httpClient.post<BenefitProviderModel>(`${environment.serviceApiUrl}/api/BenefitHeader`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update benefit provider
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - update benefit provider
  */
  update(model: BenefitProviderModel): Observable<BenefitProviderModel> {
    return this.httpClient.put<BenefitProviderModel>(`${environment.serviceApiUrl}/api/BenefitHeader`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel;
      })
    );
  }

  /**
 * Purpose: Method is use to delete benefit provider
 * @author Gaurav Vaghela #O9-53 on 28-May-2022 - delete benefit provider
 */
  delete(benefitProviderId: number): Observable<BenefitProviderModel> {
    return this.httpClient.delete<BenefitProviderModel>(`${environment.serviceApiUrl}/api/BenefitProvider/${benefitProviderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel
      })
    );
  }

  /**
    * Purpose: Method is use to check provider data
    * @author Dupendra Pawar #O9-53 on 08-Jun-2022 - check provider data
  */
  checkProviderData(identifierTypeId: number, identifierCode: boolean): Observable<boolean> {
    return this.httpClient.get<boolean>(`${environment.serviceApiUrl}/api/Provider/CheckProviderData/${identifierTypeId}/${identifierCode}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as boolean;
      })
    );
  }

  /**
    * Purpose: Method is use to save  benefit provider data
    * @author Dupendra Pawar #O9-53 on 08-Jun-2022 - save  benefit provider data
  */
  saveBenefitProviderData(benefitProviderData: BenefitProviderModel): Observable<BenefitProviderModel> {
    return this.httpClient.post<BenefitProviderModel>(`${environment.serviceApiUrl}/api/BenefitProvider`, benefitProviderData).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel;
      })
    );
  }

  /**
    * Purpose: Method is use to update  benefit provider data
    * @author Dupendra Pawar #O9-53 on 08-Jun-2022 - update  benefit provider data
  */
   updateBenefitProviderData(benefitProviderData: BenefitProviderModel): Observable<BenefitProviderModel> {
    return this.httpClient.put<BenefitProviderModel>(`${environment.serviceApiUrl}/api/BenefitProvider`, benefitProviderData).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderModel;
      })
    );
  }

}
