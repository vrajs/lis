//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-global';
import { environment } from '@environments/environment';
//#endregion

//#region Service Namespace
import { ODataBuilderService } from '@app/core/services';
import { OData } from '@app/core/models';
import { TermHeaderModel, TerminateTermModel } from '@app/core/models/administration/configuration/term-header.model';
import { HasTermConfigurationDataModel } from '@app/core/models/administration/configuration/has-term-configuration-data.model';
//#endregion

@Injectable()
export class TermHeaderService {

  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) { }

  /**
 * Purpose: Method is use to get term header list
 * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get term header list
 */
  getTermHeaderList(contractId: number, filterStatus?: number): Observable<OData<TermHeaderModel>> {
    // let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/Terms?ContractId=${contractId}&filterStatus=${filterStatus}`);
    // console.log(dynamicUrl);
    if (filterStatus == null) {
      return this.httpClient.get<OData<TermHeaderModel>>(`${environment.serviceApiUrl}/odata/Terms?ContractId=${contractId}`).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return new OData<TermHeaderModel>(res);
        })
      );
    } else {
      return this.httpClient.get<OData<TermHeaderModel>>(`${environment.serviceApiUrl}/odata/Terms?ContractId=${contractId}&filterStatus=${filterStatus}`).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return new OData<TermHeaderModel>(res);
        })
      );
    }

  }

  // getAddTermHeaderList(contractId: number, sortingArgs?: any, index?: number, perPage?: number,filterStatus?: number,filteringArgs?: any ): Observable<OData<TermHeaderModel>> {
  //   let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/Terms`,filteringArgs, sortingArgs, index, perPage)+`?ContractId=${contractId}&filterStatus=${filterStatus}`;
  //   console.log(dynamicUrl);
  //   return this.httpClient.get<OData<TermHeaderModel>>(dynamicUrl).pipe(
  //     map(res => {
  //       res = Utils.camelizeKeys(res);
  //       return new OData<TermHeaderModel>(res);
  //     })
  //   );
  // }

  /**
  * Purpose: Method is use to get Term header view
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get Term header view
  */
  getView(id: number) {
    return this.httpClient.get<TermHeaderModel>(`${environment.serviceApiUrl}/api/TermHeader/getView/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermHeaderModel
      })
    );
  }

  /**
  * Purpose: Method is use to get Term header by id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get Term header by id
  */
  getById(id: number): Observable<TermHeaderModel> {
    return this.httpClient.get<TermHeaderModel>(`${environment.serviceApiUrl}/api/TermHeader/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermHeaderModel
      })
    );
  }

  /**
  * Purpose: Method is use to create Term header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create Term header
  */
  createTermHeader(termHeader: TermHeaderModel): Observable<TermHeaderModel> {
    return this.httpClient.post<TermHeaderModel>(`${environment.serviceApiUrl}/api/TermHeader`, termHeader).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermHeaderModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update Term header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update Term header
  */
  updateTermHeader(model: TermHeaderModel): Observable<TermHeaderModel> {
    return this.httpClient.put<TermHeaderModel>(`${environment.serviceApiUrl}/api/TermHeader`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermHeaderModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete Term header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete Term header
  */
  delete(id: number): Observable<number> {
    return this.httpClient.delete(`${environment.serviceApiUrl}/api/TermHeader/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as number;
      }));
  }

  /**
* Purpose: Method is use to terminate benefit header
* @author Gaurav Vaghela #O9-53 on 23-May-2022 - terminate benefit header
*/
  terminateTerm(model: TerminateTermModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/TermHeader/TerminateTerm/`
      + model.id, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res;
        }));
  }

  /**
  * Purpose: Method is use to copy Term header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - copy Term header
  */
  copyTerm(model: any) {
    return this.httpClient.post<any>(`${environment.serviceApiUrl}/api/TermHeader/CopyTerm`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  /**
  * Purpose: Method is use to get provider specialities
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get provider specialities
  */
  copyAllTerms(model: any) {
    return this.httpClient.post<any>(`${environment.serviceApiUrl}/api/TermHeader/CopyAllTerms`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  /**
  * Purpose: Method is use to check term have configuration
  * @author Shivam Modi on 23-May-2022 - check term have configuration
  */
  checkTermConfigurationHasData(termHeaderId: number): Observable<HasTermConfigurationDataModel> {
    return this.httpClient.get<HasTermConfigurationDataModel>(`${environment.serviceApiUrl}/api/TermHeader/CheckTermConfigurationHasData/${termHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HasTermConfigurationDataModel
      })
    );
  }

}
