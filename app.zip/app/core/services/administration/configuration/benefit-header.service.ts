//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-global';
import { BenefitHeaderModel, BenefitModel, BenefitProviderSpecialtyModel, ConfigureBenefitProrityForClaimViewModel, HasBenefitConfigurationDataModel, OData, TerminateModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

//#region Service Namespace
import { ODataBuilderService } from '@app/core/services';
//#endregion

@Injectable()
export class BenefitHeaderService {

  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) { }

  /**
 * Purpose: Method is use to get benefit header list
 * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit header list
 */
  getBenefitHeaderList(filterStatus: number, planId?: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<BenefitModel>> {
    let isInclude: boolean = false;
    if (!Utils.isBlank(planId)) {
      isInclude = true;
    }
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/BenefitHeaders`, filteringArgs, sortingArgs, index, perPage) + `&filterStatus=${filterStatus}&healthPlanId=${planId}&isInclude=${isInclude}`;
    return this.httpClient.get<OData<BenefitModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<BenefitModel>(res);
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit header view
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit header view
  */
  getView(id: number) {
    return this.httpClient.get<BenefitHeaderModel>(`${environment.serviceApiUrl}/api/BenefitHeader/getView/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitHeaderModel
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit header by id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit header by id
  */
  getById(id: number): Observable<BenefitHeaderModel> {
    return this.httpClient.get<BenefitHeaderModel>(`${environment.serviceApiUrl}/api/BenefitHeader/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitHeaderModel
      })
    );
  }

  /**
  * Purpose: Method is use to create benefit header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create benefit header
  */
  createBenefitHeader(benefitHeader: BenefitHeaderModel): Observable<BenefitHeaderModel> {
    return this.httpClient.post<BenefitHeaderModel>(`${environment.serviceApiUrl}/api/BenefitHeader`, benefitHeader).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitHeaderModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update benefit header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update benefit header
  */
  updateBenefitHeader(model: BenefitHeaderModel): Observable<BenefitHeaderModel> {
    return this.httpClient.put<BenefitHeaderModel>(`${environment.serviceApiUrl}/api/BenefitHeader`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitHeaderModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete benefit header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete benefit header
  */
  delete(id: number): Observable<number> {
    return this.httpClient.delete(`${environment.serviceApiUrl}/api/BenefitHeader/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as number;
      }));
  }

  /**
  * Purpose: Method is use to copy benefit header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - copy benefit header
  */
  copyBenefit(model: BenefitHeaderModel, copayCoinsuranceId: number) {
    return this.httpClient.post<BenefitHeaderModel>(`${environment.serviceApiUrl}/api/BenefitHeader/CopyBenefit/${copayCoinsuranceId}`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitHeaderModel;
      })
    );
  }

  /**
  * Purpose: Method is use to get provider specialities
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get provider specialities
  */
  getBenefitProviderSpecialties(benefitHeaderID: number): Observable<BenefitProviderSpecialtyModel[]> {
    return this.httpClient.get<BenefitProviderSpecialtyModel[]>(`${environment.serviceApiUrl}/api/BenefitProviderSpecialty/GetByBenefitHeaderID/${benefitHeaderID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitProviderSpecialtyModel[];
      })
    );
  }

  /**
 * Purpose: Method is use to check benefit have configuration
 * @author Gaurav Vaghela #O9-53 on 23-May-2022 - check benefit have configuration
 */
  checkBenefitConfigurationHasData(benefitHeaderId: number): Observable<HasBenefitConfigurationDataModel> {
    return this.httpClient.get<HasBenefitConfigurationDataModel>(`${environment.serviceApiUrl}/api/BenefitHeader/checkBenefitConfigurationHasData/${benefitHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HasBenefitConfigurationDataModel
      })
    );
  }

  /**
 * Purpose: Method is use to terminate benefit header
 * @author Gaurav Vaghela #O9-53 on 23-May-2022 - terminate benefit header
 */
  terminateBenefit(model: TerminateModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/BenefitHeader/TerminateBenefit`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      }));
  }

}
