//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-functions';
import { CopayCoinsuranceModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class CopayCoinsuranceService {
  constructor(private httpClient: HttpClient) { }

  /**
  * Purpose: Method is use to get copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get copay coinsurance
  */
  get(): Observable<CopayCoinsuranceModel[]> {
    return this.httpClient.get<CopayCoinsuranceModel[]>(`${environment.serviceApiUrl}/api/CopayCoinsurance`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CopayCoinsuranceModel[];
      })
    );
  }

  /**
  * Purpose: Method is use to get copay coinsurance by id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get copay coinsurance by id
  */
  getById(copayCoinsuranceId: number): Observable<CopayCoinsuranceModel> {
    return this.httpClient.get<CopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/CopayCoinsurance/${copayCoinsuranceId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CopayCoinsuranceModel;
      })
    );
  }

  /**
  * Purpose: Method is use to create copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create copay coinsurance
  */
  create(model: CopayCoinsuranceModel): Observable<CopayCoinsuranceModel> {
    return this.httpClient.post<CopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/CopayCoinsurance`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CopayCoinsuranceModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update copay coinsurance
  */
  update(model: CopayCoinsuranceModel): Observable<CopayCoinsuranceModel> {
    return this.httpClient.put<CopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/CopayCoinsurance`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CopayCoinsuranceModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create delete coinsurance
  */
  delete(copayCoinsuranceId: number): Observable<CopayCoinsuranceModel> {
    return this.httpClient.delete<CopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/CopayCoinsurance/${copayCoinsuranceId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CopayCoinsuranceModel;
      })
    );
  }

}
