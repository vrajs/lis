import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { ContractModel, OData } from '@app/core/models';
import { ContactCopyModel } from '@app/core/models/administration/configuration/contract-copy.model';
import { ContractHeaderModel, TerminateContractModel } from '@app/core/models/administration/configuration/contract-header.model';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()

export class ContractHeaderService {

  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) { }

  /**
   * Purpose: Method is use to get benefit copay coinsurance
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay coinsurance
   */

  getContractHeaderList(filterStatus: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ContractModel>> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/GetContracts`, filteringArgs, sortingArgs, index, perPage) + `&filterStatus=${filterStatus}`;
    return this.httpClient.get<OData<ContractModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ContractModel>(res);
      })
    );
  }

  /**
* Purpose: Method is use to create benefit header
* @author Gaurav Vaghela #O9-53 on 23-May-2022 - create benefit header
*/
  createContractHeader(contractHeader: ContractHeaderModel): Observable<any> {
    return this.httpClient.post<any>(`${environment.serviceApiUrl}/api/Contract`, contractHeader).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit header by id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit header by id
  */
  getById(id: number): Observable<ContractHeaderModel> {
    return this.httpClient.get<ContractHeaderModel>(`${environment.serviceApiUrl}/api/Contract/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ContractHeaderModel
      })
    );
  }

  /**
   * Purpose: Method is use to update benefit header
   * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update benefit header
   */
  updateContractHeader(model: ContractHeaderModel): Observable<ContractHeaderModel> {
    return this.httpClient.put<ContractHeaderModel>(`${environment.serviceApiUrl}/api/Contract`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ContractHeaderModel;
      })
    );
  }


  /**
* Purpose: Method is use to delete benefit header
* @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete benefit header
*/
  delete(id: number): Observable<number> {
    return this.httpClient.delete(`${environment.serviceApiUrl}/api/Contract/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as number;
      }));
  }

  /**
* Purpose: Method is use to terminate benefit header
* @author Gaurav Vaghela #O9-53 on 23-May-2022 - terminate benefit header
*/
  terminateContract(model: TerminateContractModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/Contract/TerminateContract/`
      + model.id, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res;
        }));
  }

/**
  * Purpose: Method is use to copy Term header
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - copy Term header
  */
 copyContract(model: ContactCopyModel) {
  return this.httpClient.post<ContactCopyModel>(`${environment.serviceApiUrl}/api/Contract/CopyContract`, model).pipe(
    map(res => {
      res = Utils.camelizeKeys(res);
      return res as ContactCopyModel;
    })
  );
}

  /**
 * Purpose: Method is use to get provider specialities
 * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get provider specialities
 */
  getContractViewById(contractId: number): Observable<ContractModel> {
    return this.httpClient.get<ContractModel>(`${environment.serviceApiUrl}/api/Contract/GetContractViewById/${contractId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ContractModel;
      })
    );
  }

  getClaimTypeList(url: string): Observable<any> {
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/${url}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  getCapitationList(url: string): Observable<any> {
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/${url}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }
}