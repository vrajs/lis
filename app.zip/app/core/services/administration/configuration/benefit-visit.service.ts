//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { BenefitVisitModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class BenefitVisitService {
  
  constructor(private httpClient: HttpClient) { }

   /**
  * Purpose: Method is use to get benefit vist 
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get benefit vist
  */
  getById(id: number): Observable<BenefitVisitModel> {
    return this.httpClient.get<BenefitVisitModel>(`${environment.serviceApiUrl}/api/BenefitVisit/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitVisitModel
      })
    );
  }

  /**
  * Purpose: Method is use to create benefit vist 
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create benefit vist
  */
  create(model: BenefitVisitModel): Observable<BenefitVisitModel> {
    return this.httpClient.post<BenefitVisitModel>(`${environment.serviceApiUrl}/api/BenefitVisit`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitVisitModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update benefit vist 
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - update benefit vist
  */
  update(model: BenefitVisitModel): Observable<BenefitVisitModel> {
    return this.httpClient.put<BenefitVisitModel>(`${environment.serviceApiUrl}/api/BenefitVisit`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitVisitModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete benefit vist 
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - delete benefit vist
  */
  delete(id: number): Observable<BenefitVisitModel> {
    return this.httpClient.delete<BenefitVisitModel>(`${environment.serviceApiUrl}/api/BenefitVisit/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitVisitModel
      })
    );
  }
}
