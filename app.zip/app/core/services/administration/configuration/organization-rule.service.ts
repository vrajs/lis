import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { KeyValModel, OData, OrganizationRuleModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { ODataBuilderService } from '@app/core/services';
import { ISortingExpression } from '@infragistics/igniteui-angular';

@Injectable()

export class OrganizationRuleService {

  public organizationList: Observable<OrganizationRuleModel[]>;
  public _organizationList: BehaviorSubject<OrganizationRuleModel[]>;

  constructor(private httpClient: HttpClient,
    private oDatabuilderSrvice: ODataBuilderService) {
    this._organizationList = new BehaviorSubject([]);
    this.organizationList = this._organizationList.asObservable();
  }

  get(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<OrganizationRuleModel>> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaders`, filteringArgs, sortingArgs, index, perPage)
    return this.httpClient.get<OData<OrganizationRuleModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<OrganizationRuleModel>(res);
      })
    );
  }

  getById(ruleHeaderID: number): Observable<OrganizationRuleModel> {
    return this.httpClient.get<OrganizationRuleModel>(`${environment.serviceApiUrl}/api/RuleHeader/${ruleHeaderID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        console.log(res);
        return res as OrganizationRuleModel;
      })
    );
  }


  create(model: OrganizationRuleModel): Observable<number> {
    return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/RuleHeader`, model);
  }

  update(model: OrganizationRuleModel): Observable<number> {
    return this.httpClient.put<number>(`${environment.serviceApiUrl}/api/RuleHeader`, model);
  }

  delete(organizationID: number): Observable<Number> {
    return this.httpClient.delete<number>(`${environment.serviceApiUrl}/api/RuleHeader/${organizationID}`);
  }
}
