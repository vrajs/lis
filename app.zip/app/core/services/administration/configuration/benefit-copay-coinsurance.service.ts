//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-functions';
import { BenefitCopayCoinsuranceModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class BenefitCopayCoinsuranceService {

  constructor(private httpClient: HttpClient) { }

 /**
  * Purpose: Method is use to get benefit copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay coinsurance
  */
  get(): Observable<BenefitCopayCoinsuranceModel[]> {
    return this.httpClient.get<BenefitCopayCoinsuranceModel[]>(`${environment.serviceApiUrl}/api/BenefitCopayCoinsurance`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayCoinsuranceModel[];
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit copay coinsurance by id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay coinsurance by id
  */
  getById(BenefitCopayCoinsuranceModelID: number): Observable<BenefitCopayCoinsuranceModel> {
    return this.httpClient.get<BenefitCopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/BenefitCopayCoinsurance/${BenefitCopayCoinsuranceModelID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayCoinsuranceModel;
      })
    );
  }

  /**
  * Purpose: Method is use to get benefit copay coinsurance by benefit headerId
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay coinsurance by benefit headerId
  */
  GetBenefitCopayCoinsuranceByBenefitHeaderId(BenefitHeaderId: number): Observable<BenefitCopayCoinsuranceModel> {
    return this.httpClient.get<BenefitCopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/BenefitCopayCoinsurance/GetBenefitCopayCoinsuranceByBenefitHeaderId/${BenefitHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayCoinsuranceModel;
      })
    );    
  }

 /**
  * Purpose: Method is use to create benefit copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create benefit copay coinsurance
  */  
  create(model: BenefitCopayCoinsuranceModel): Observable<BenefitCopayCoinsuranceModel> {
    return this.httpClient.post<BenefitCopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/BenefitCopayCoinsurance`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayCoinsuranceModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update benefit copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update benefit copay coinsurance
  */  
  update(model: BenefitCopayCoinsuranceModel): Observable<BenefitCopayCoinsuranceModel> {
    return this.httpClient.put<BenefitCopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/BenefitCopayCoinsurance`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayCoinsuranceModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete benefit copay coinsurance
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete benefit copay coinsurance
  */  
  delete(BenefitCopayCoinsuranceModelModelID: number): Observable<BenefitCopayCoinsuranceModel> {
    return this.httpClient.delete<BenefitCopayCoinsuranceModel>(`${environment.serviceApiUrl}/api/BenefitCopayCoinsurance/${BenefitCopayCoinsuranceModelModelID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayCoinsuranceModel;
      })
    );
  }
}
