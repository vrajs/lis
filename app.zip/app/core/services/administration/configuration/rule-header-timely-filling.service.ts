import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData, RuleHeaderTimelyFilingModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RuleHeaderTimelyFilingService {

    apiBaseUrl: string = '/api/RuleHeaderTimelyFiling';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRuleHeaderTimelyFillingData(ruleHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RuleHeaderTimelyFilingModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaderTimelyFilings`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RuleHeaderTimelyFilingModel>>(`${dynamicUrl}&$orderby=RuleHeaderTimelyFilingID asc&RuleHeaderID=${ruleHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RuleHeaderTimelyFilingModel>(res);
            })
        );
    }

    getById(ruleHeaderID: number): Observable<RuleHeaderTimelyFilingModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RuleHeaderTimelyFilingModel;
            })
        );
    }

    create(ruleHeaderTimelyFiling: RuleHeaderTimelyFilingModel): Observable<Number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderTimelyFiling).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    update(ruleHeaderTimelyFiling: RuleHeaderTimelyFilingModel): Observable<Number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderTimelyFiling).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    delete(ruleHeaderTimelyFilingID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderTimelyFilingID}`).pipe(
            map((response) => {
                return response as Number;
            })
        )
    }
}
