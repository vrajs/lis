//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { BenefitServiceGroupModel, OData } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

//#region Services Namsespace
import { ODataBuilderService } from "@app/core/services";3
//#endregion

@Injectable()

export class BenefitServiceGroupService {  

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

   /**
  * Purpose: Method is use to get benefit services group list
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get benefit services group list
  */
  getBenefitServiceGroupList(url: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<BenefitServiceGroupModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/BenefitServiceGroups`, filteringArgs, sortingArgs, index, perPage) + url;
    return this.httpClient.get<OData<BenefitServiceGroupModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<BenefitServiceGroupModel>(res);
      })
    );
  }

   /**
  * Purpose: Method is use to get benefit services group by id
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get benefit services group by id
  */
  getById(id: number): Observable<BenefitServiceGroupModel> {
    return this.httpClient.get<BenefitServiceGroupModel>(`${environment.serviceApiUrl}/api/BenefitServiceGroups/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitServiceGroupModel;
      })
    );
  }

   /**
  * Purpose: Method is use to create benefit services group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create benefit services group
  */
  create(model: BenefitServiceGroupModel): Observable<BenefitServiceGroupModel> {
    return this.httpClient.post<BenefitServiceGroupModel>(`${environment.serviceApiUrl}/api/BenefitServiceGroups`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitServiceGroupModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update benefit services group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - update benefit services group
  */
  update(model: BenefitServiceGroupModel): Observable<BenefitServiceGroupModel> {
    return this.httpClient.put<BenefitServiceGroupModel>(`${environment.serviceApiUrl}/api/BenefitServiceGroups`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitServiceGroupModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete benefit services group
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - delete benefit services group
  */
  delete(id: number): Observable<BenefitServiceGroupModel> {
    return this.httpClient.delete<BenefitServiceGroupModel>(`${environment.serviceApiUrl}/api/BenefitServiceGroups/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitServiceGroupModel;
      })
    );
  }
}
