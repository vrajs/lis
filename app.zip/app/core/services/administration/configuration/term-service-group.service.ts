//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

//#region Services Namsespace
import { ODataBuilderService } from "@app/core/services";
import { TermServiceGroupModel } from '@app/core/models/administration/configuration/term-service-group.model';

//#endregion

@Injectable()

export class TermServiceGroupService {

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

  /**
 * Purpose: Method is use to get term services group list
 * @author Shivam Modi  28-May-2022 - get term services group list
 */
  // getTermServiceGroupList(url: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<TermServiceGroupModel>> {
  //   let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/TermServiceGroups`, filteringArgs, sortingArgs, index, perPage) + url;
  //   return this.httpClient.get<OData<TermServiceGroupModel>>(dynamicUrl).pipe(
  //     map(res => {
  //       res = Utils.camelizeKeys(res);
  //       return new OData<TermServiceGroupModel>(res);
  //     })
  //   );
  // }
  getTermServiceGroupList(id: number): any {
    return this.httpClient.get(`${environment.serviceApiUrl}/api/TermServiceGroup/GetTermServiceGroupByTermHeaderId/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  /**
 * Purpose: Method is use to get term services group by id
 * @author Shivam Modi  28-May-2022 - get term services group by id
 */
  getById(id: number): Observable<TermServiceGroupModel> {
    return this.httpClient.get<TermServiceGroupModel>(`${environment.serviceApiUrl}/api/TermServiceGroup/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermServiceGroupModel;
      })
    );
  }

  /**
 * Purpose: Method is use to create term services group
 * @author Shivam Modi  28-May-2022 - create term services group
 */
  create(model: TermServiceGroupModel): Observable<TermServiceGroupModel> {
    return this.httpClient.post<TermServiceGroupModel>(`${environment.serviceApiUrl}/api/TermServiceGroup`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermServiceGroupModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update term services group
  * @author Shivam Modi  28-May-2022 - update term services group
  */
  update(model: TermServiceGroupModel): Observable<TermServiceGroupModel> {
    return this.httpClient.put<TermServiceGroupModel>(`${environment.serviceApiUrl}/api/TermServiceGroup`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermServiceGroupModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete term services group
  * @author Shivam Modi  28-May-2022 - delete term services group
  */
  delete(id: number): Observable<TermServiceGroupModel> {
    return this.httpClient.delete<TermServiceGroupModel>(`${environment.serviceApiUrl}/api/TermServiceGroup/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermServiceGroupModel;
      })
    );
  }
}
