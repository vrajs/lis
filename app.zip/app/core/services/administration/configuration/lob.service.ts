import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-global';
import { LobModel, OData } from '@app/core/models';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class LobService {

  constructor(private httpClient: HttpClient , private oDatabuilderService: ODataBuilderService) { }
  
getLobList(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<LobModel>>{
  let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/Lobs` , filteringArgs , sortingArgs,index,perPage);
  return this.httpClient.get<OData<LobModel>>(dynamicUrl).pipe(
    map((res=>{
      res= Utils.camelizeKeys(res);
      return new OData<LobModel>(res);
    }))
  )
}

  get(): Observable<LobModel[]> {
    return this.httpClient.get<LobModel[]>(`${environment.serviceApiUrl} /api/Lob`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as LobModel[]
      })
    );
  }
 
  getById(lobId: number):Observable<LobModel>{
    return this.httpClient.get<LobModel>(`${environment.serviceApiUrl}/api/Lob/${lobId}`).pipe(
      map(res=> {
        res= Utils.camelizeKeys(res);
        return res as LobModel;
      })
    )
  }

  create(model : LobModel) : Observable<LobModel>{
    return this.httpClient.post<LobModel>(`${environment.serviceApiUrl}/api/Lob`,model).pipe(
      map((res) =>{
        res= Utils.camelizeKeys(res);
        return res as LobModel;
      })
    )
  }

  update(model : LobModel) : Observable<LobModel>{
    return this.httpClient.put<LobModel>(`${environment.serviceApiUrl}/api/Lob`,model).pipe(
      map((res) =>{
        res= Utils.camelizeKeys(res);
        return res as LobModel;
      })
    )
  }

  delete(lobId: number):Observable<number>{
    return this.httpClient.delete(`${environment.serviceApiUrl}/api/Lob/${lobId}`).pipe(
      map((res) =>{
        res = Utils.camelizeKeys(res);
        return res as number;
      })
    )
  }
}
