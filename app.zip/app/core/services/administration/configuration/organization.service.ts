import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OrganizationModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable()

export class OrganizationService {

  constructor(private httpClient: HttpClient) {
  }

  /**
   * Purpose: Method is use to get OrganizationModel list
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get OrganizationModel list
   */
  get(): Observable<OrganizationModel[]> {
    return this.httpClient.get<OrganizationModel[]>(`${environment.serviceApiUrl}/api/Organization/GetHierarchyOrganizations`);
  }

  /**
   * Purpose: Method is use to get OrganizationModel list by id
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get OrganizationModel list by id
   */
  getById(organizationID: number): Observable<OrganizationModel> {
    return this.httpClient.get<OrganizationModel>(`${environment.serviceApiUrl}/api/Organization/${organizationID}`);
  }

  /**
   * Purpose: Method is use to get OrganizationModel list by id
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get OrganizationModel list by id
   */
  getOrganizationDetailsByID(organizationID: number): Observable<OrganizationModel> {
    return this.httpClient.get<OrganizationModel>(`${environment.serviceApiUrl}/api/Organization/OrganizationDetailsGet/${organizationID}`);
  }

  /**
   * Purpose: Method is use to insert OrganizationModel record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - insert OrganizationModel record
   */
  create(organizations: OrganizationModel): Observable<Number> {
    return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/Organization`, organizations);
  }

  /**
   * Purpose: Method is use to update OrganizationModel record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - update OrganizationModel record
   */
   update(organizations: OrganizationModel): Observable<Number> {
    return this.httpClient.put<number>(`${environment.serviceApiUrl}/api/Organization`, organizations);
  }

  /**
   * Purpose: Method is use to delete OrganizationModel record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - delete OrganizationModel record
   */
  delete(organizationID: number): Observable<Number> {
      return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/Organization/${organizationID}`);
  }
}
