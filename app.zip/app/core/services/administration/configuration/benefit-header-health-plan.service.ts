import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { BenefitHeaderHealthPlan, BenefitHeaderHealthPlanTermModel, ConfigureBenefitProrityForClaimViewModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { Observable, map } from "rxjs";

@Injectable()

export class BenefitHeaderHealthPlanService {

    constructor(private httpClient: HttpClient) {

    }


    /**
     * Purpose: Method is use to Terminate Benefit in Plan benefit
     * @author Dupendra Pawar # on 31-May-2022 - Put method
    */
    removeOrTermPlanBenefits(terminateModel: BenefitHeaderHealthPlanTermModel): Observable<any> {
        return this.httpClient.put<any>(`${environment.serviceApiUrl}/api/BenefitHeaderHealthPlan/RemoveOrTermPlanBenefits`, terminateModel).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }

    /**
     * Purpose: Method is use to add Benefit in Plan benefit
     * @author Dupendra Pawar # on 31-May-2022 - Put method
    */
    addBenefitsToPackage(benefitHeaderHealthPlanModel: BenefitHeaderHealthPlan[]): Observable<any> {
        return this.httpClient.post<any>(`${environment.serviceApiUrl}/api/BenefitHeaderHealthPlan`, benefitHeaderHealthPlanModel).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as any;
            })
        );
    }

    /**
     * Purpose: Method is use to change plan benefit priority
     * @author Dupendra Pawar #O9-52 on 30-May-2022 - change plan benefit priority
    */
    ConfigureBenefitProrityForClaim(model: ConfigureBenefitProrityForClaimViewModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}/api/BenefitHeaderHealthPlan/ConfigureBenefitProrityForClaim`, model).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            }));
    }

    /**
     * Purpose: Method is use to delete benefit in package summary
     * @author Dupendra Pawar #O9-52 on 30-May-2022 - delete benefit header
    */
    healthPlanBenefitDelete(healthPlanId: number, benefitHeaderId: number): Observable<number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}/api/BenefitHeaderHealthPlan/HealthPlan/${healthPlanId}/BenefitHeader/${benefitHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as number;
            }));
    }

}