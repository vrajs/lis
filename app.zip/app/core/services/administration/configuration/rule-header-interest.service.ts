import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { RuleHeaderInterestModel } from '@app/core/models/administration/configuration/rule-header-interest.model';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RuleHeaderInterestService {

    apiBaseUrl: string = '/api/RuleHeaderInterest';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRuleHeaderInterestData(ruleHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RuleHeaderInterestModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaderInterests`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RuleHeaderInterestModel>>(`${dynamicUrl}&$orderby=RuleHeaderInterestId asc&RuleHeaderID=${ruleHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RuleHeaderInterestModel>(res);
            })
        );
    }

    getById(ruleHeaderID: number): Observable<RuleHeaderInterestModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RuleHeaderInterestModel;
            })
        );
    }

    create(ruleHeaderInterest: RuleHeaderInterestModel): Observable<Number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderInterest).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    update(ruleHeaderInterest: RuleHeaderInterestModel): Observable<Number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderInterest).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    delete(ruleHeaderInterestID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderInterestID}`).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }
}
