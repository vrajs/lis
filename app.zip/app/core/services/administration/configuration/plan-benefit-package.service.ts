import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { BenefitHeaderHealthPlanTermModel, CopyPlanModel, GetPlanModel, HealthPlanModel, OData, TerminateModel } from "@app/core/models";
import { CheckPlanConfigurationHasDataModel } from "@app/core/models/administration/configuration/check-plan-configuration-has-data.model";
import { environment } from "@environments/environment";
import { Observable, BehaviorSubject, map, Subject } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class PlanBenefitPackageService {
  showHideBenefitGrid$: Observable<boolean>;
  refreshBenefitGrid$: Observable<boolean>;
  private showHideBenefitGridSubject = new Subject<boolean>();
  private refreshBenefitGridSubject = new Subject<boolean>();

  updateBenefitPlanGrid$: Observable<any>;
  private updateBenefitPlanGridSubject = new Subject<any>();

  updateAttachPlanToBenefitGrid$: Observable<any>;
  private updateAttachPlanToBenefitGridSubject = new Subject<any>();

  constructor(private httpClient: HttpClient,
    private oDatabuilderSrvice: ODataBuilderService) {
    this.showHideBenefitGrid$ = this.showHideBenefitGridSubject.asObservable();
    this.refreshBenefitGrid$ = this.refreshBenefitGridSubject.asObservable();
    this.updateBenefitPlanGrid$ = this.updateBenefitPlanGridSubject.asObservable();
    this.updateAttachPlanToBenefitGrid$ = this.updateAttachPlanToBenefitGridSubject.asObservable();

  }

  showHideBenefitGrid(data) {
    this.showHideBenefitGridSubject.next(data);
  }

  refreshBenefitGrid(data) {
    this.refreshBenefitGridSubject.next(data);
  }

  updateBenefitPlanGrid(data) {
    this.updateBenefitPlanGridSubject.next(data);
  }

  updateAttachPlanToBenefitGrid(data) {
    this.updateAttachPlanToBenefitGridSubject.next(data);
  }

  /**
 * Purpose: Method is use to get all standard code data
 * @author Gaurav Vaghela # on 28-APR-2022 - get standard code data
 */
  getPlanBenefitPackageList(filterStatus: number, benefitHeaderId?: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<GetPlanModel>> {
    let isInclude: boolean = false;
    if (!Utils.isBlank(benefitHeaderId)) {
      isInclude = true;
    }
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/Plans`, filteringArgs, sortingArgs, index, perPage) + `&filterStatus=${filterStatus}&benefitHeaderId=${benefitHeaderId}&isInclude=${isInclude}`;
    return this.httpClient.get<OData<GetPlanModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<GetPlanModel>(res);
      })
    )
  }

  /**
   * Purpose: Method is use get Plan
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  getPlanReadonly(ipaid: number): Observable<GetPlanModel> {
    return this.httpClient.get<GetPlanModel>(`${environment.serviceApiUrl}/api/Plan/GetReadonly/${ipaid}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as GetPlanModel;
      })
    );
  }

  /**
   * Purpose: Method is use to save Health plan
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  savePlan(healthPlan: HealthPlanModel): Observable<GetPlanModel> {
    return this.httpClient.post<GetPlanModel>(`${environment.serviceApiUrl}/api/Plan`, healthPlan).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as GetPlanModel;
      })
    );
  }

  /**
   * Purpose: Method is use to save Health plan
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  updatePlan(healthPlan: HealthPlanModel): Observable<GetPlanModel> {
    return this.httpClient.put<GetPlanModel>(`${environment.serviceApiUrl}/api/Plan`, healthPlan).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as GetPlanModel;
      })
    );
  }

  /**
   * Purpose: Method is use get Planby id
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  getHealthPlanById(healthPlanID: number): Observable<HealthPlanModel> {
    return this.httpClient.get<HealthPlanModel>(`${environment.serviceApiUrl}/api/Plan/${healthPlanID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HealthPlanModel;
      })
    );
  }

  /**
   * Purpose: Method is use Delete Plan
   * @author Dupendra Pawar # on 06-May-2022 - Delete method
  */
  deletePlan(healthPlanId: number): Observable<GetPlanModel> {
    return this.httpClient.delete<GetPlanModel>(`${environment.serviceApiUrl}/api/Plan/${healthPlanId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as GetPlanModel;
      })
    );
  }

  /**
   * Purpose: Method is use to Terminate Plan
   * @author Dupendra Pawar # on 06-May-2022 - Put method
  */
  terminatePlan(terminateModel: TerminateModel): Observable<TerminateModel> {
    return this.httpClient.put<TerminateModel>(`${environment.serviceApiUrl}/api/Plan/TerminatePlan`, terminateModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TerminateModel;
      })
    );
  }

  /**
   * Purpose: Method is use to save Health plan
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  saveCopyPlan(copyPlan: CopyPlanModel): Observable<number> {
    return this.httpClient.patch<number>(`${environment.serviceApiUrl}/api/Plan/CopyHealthPlan`, copyPlan).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as number;
      })
    );
  }

  /**
   * Purpose: Method is use check health plan configuration has data
   * @author Dupendra Pawar # on 01-June-2022 - Get method
  */
  CheckPlanConfigurationHasData(healthPlanId: number): Observable<CheckPlanConfigurationHasDataModel> {
    return this.httpClient.get<CheckPlanConfigurationHasDataModel>(`${environment.serviceApiUrl}/api/Plan/CheckPlanConfigurationHasData/${healthPlanId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CheckPlanConfigurationHasDataModel;
      })
    );
  }


}