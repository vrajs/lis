import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, Subject } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { FileTemplateModel } from '@app/core/models/administration/configuration/file-template.model';
import { FileTemplateListView } from '@app/core/models/operation/member/file-template-list-view.model';
import { FileTemplateSearch } from '@app/core/models/operation/member/file-template-search.model';
import { environment } from '@environments/environment';
import { FileSubCategoryModel } from '@app/core/models';

@Injectable({
  providedIn: 'root'
})
export class FileTemplateService {
  searchMember$: Observable<any>;
  searchMemberSubject = new Subject<any>();
  constructor(private httpClient: HttpClient) {
    this.searchMember$ = this.searchMemberSubject.asObservable();
  }

  searchMember(data) {
    this.searchMemberSubject.next(data);
  }

  GetFileTemplateTypes(): Observable<FileTemplateModel[]> {
    return this.httpClient.get<FileTemplateModel[]>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileTemplateTypes`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileTemplateModel[];
      })
    );
  }

  GetFileTemplateDetails(searchModel: FileTemplateSearch): Observable<FileTemplateListView> {
    let searchModelString = JSON.stringify(searchModel);
    return this.httpClient.get<FileTemplateListView>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileTemplateDetails?searchModelString=${searchModelString}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileTemplateListView;
      })
    );
  }
  GetFileData(fileCode: string, dataFileToProcessDetailsID: number): Observable<any> {
    // let searchModelString = JSON.stringify(searchModel);
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileData?fileCode=${fileCode}&dataFileToProcessDetailsID=${dataFileToProcessDetailsID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  /**
  * Purpose : To get CMS File type dropdown list
  * @author Tisa jodhani #O9-340 on 31 August, 2022 : Filetype Dropdown List
  */
  GetCMSFileList(): Observable<FileSubCategoryModel[]> {
    return this.httpClient.get<FileSubCategoryModel[]>(`${environment.serviceApiUrl}/api/FileTemplateType/GetCMSFileTypes`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileSubCategoryModel[];
      })
    );
  }
}
