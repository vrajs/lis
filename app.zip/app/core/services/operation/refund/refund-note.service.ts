import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefundNoteModel } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { Observable, pipe, map } from 'rxjs';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';
import { Utils } from "@app/common/app-functions";

@Injectable()
export class RefundNoteService {

    apiBaseUrl: string = '/api/RefundNote';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    get(): Observable<RefundNoteModel[]> {
        return this.httpClient.get<RefundNoteModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}`);
    }

    create(model: RefundNoteModel): Observable<RefundNoteModel> {
        return this.httpClient.post<RefundNoteModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
    }

    update(model: RefundNoteModel): Observable<RefundNoteModel> {
        return this.httpClient.put<RefundNoteModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
    }

    createOrUpdate(model: RefundNoteModel): Observable<RefundNoteModel> {
        if (model.refundNoteId === 0) {
            return this.httpClient.post<RefundNoteModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
        }
        else {
            return this.httpClient.put<RefundNoteModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
        }
    }

    delete(refundNoteID: number): Observable<number> {
        return this.httpClient.delete<number>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${refundNoteID}`);
    }

    getRefundNotes(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RefundNoteModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<RefundNoteModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<RefundNoteModel>(res);
          })
        );
    }
}
