import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefundPostingModel } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { Observable, pipe, map } from 'rxjs';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';
import { Utils } from "@app/common/app-functions";

@Injectable()
export class RefundPostingService {

    apiBaseUrl: string = '/api/RefundPosting';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    get(): Observable<RefundPostingModel[]> {
        return this.httpClient.get<RefundPostingModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}`);
    }

    create(model: RefundPostingModel): Observable<RefundPostingModel> {
        return this.httpClient.post<RefundPostingModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
    }

    update(model: RefundPostingModel): Observable<RefundPostingModel> {
        return this.httpClient.put<RefundPostingModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
    }

    createOrUpdate(model: RefundPostingModel): Observable<RefundPostingModel> {
        if (model.refundPostingId === 0) {
            return this.httpClient.post<RefundPostingModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
        }
        else {
            return this.httpClient.put<RefundPostingModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model);
        }
    }

    delete(refundPostingID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${refundPostingID}`);
    }

    getRefundPostingData(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RefundPostingModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<RefundPostingModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<RefundPostingModel>(res);
          })
        );
    }
}
