import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefundReceivedModel } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';

@Injectable()
export class RefundReceivedService {

    apiBaseUrl: string = '/api/RefundReceived';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    get(): Observable<RefundReceivedModel[]> {
        return this.httpClient.get<RefundReceivedModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}`);
    }

    getById(refundReceivedID: number): Observable<RefundReceivedModel> {
        return this.httpClient.get<RefundReceivedModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${refundReceivedID}`);
    }

    getAllRefundReceived(refundRequestID: number): Observable<RefundReceivedModel[]> {
        return this.httpClient.get<RefundReceivedModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetAllRefundReceived/${refundRequestID}`);
    }

    createOrUpdate(refundReceived: RefundReceivedModel): Observable<Number> {
        if (refundReceived.refundReceivedId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/RefundReceived`, refundReceived);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/RefundReceived`, refundReceived);
        }
    }

    delete(refundReceivedID: number): Observable<number> {
        return this.httpClient.delete<number>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${refundReceivedID}`);
    }

    getRefundReceived(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RefundReceivedModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<RefundReceivedModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<RefundReceivedModel>(res);
          })
        );
    }
}
