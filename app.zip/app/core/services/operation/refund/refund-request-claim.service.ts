import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefundRequestClaimModel } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable()
export class RefundRequestClaimService {
    apiBaseUrl: string = '/api/RefundRequestClaim';

    constructor(private httpClient: HttpClient) {
    }

    getAllClaims(refundRequestID: number): Observable<RefundRequestClaimModel[]> {
        return this.httpClient.get<RefundRequestClaimModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetAllClaims/${refundRequestID}`);
    }
}
