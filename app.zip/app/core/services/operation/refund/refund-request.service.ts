import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { RefundRequestModel } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RefundRequestService {
    apiBaseUrl: string = '/api/RefundRequest';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRefundListData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<any>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/RefundList`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<any>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<any>(res);
            })
        );
    }

    getById(refundRequestID: number): Observable<RefundRequestModel> {
        return this.httpClient.get<RefundRequestModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${refundRequestID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res;
            })
        );;
    }

    createOrUpdate(model: RefundRequestModel): Observable<RefundRequestModel> {
        if (Number(model.refundRequestId) === 0) {
            return this.httpClient.post<RefundRequestModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model).pipe(
                map(res => {
                    res = Utils.camelizeKeys(res);
                    return res;
                })
            );
        }
        else {
            return this.httpClient.put<RefundRequestModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model).pipe(
                map(res => {
                    res = Utils.camelizeKeys(res);
                    return res;
                })
            );;
        }
    }

    delete(refundRequestID: number): Observable<number> {
        return this.httpClient.delete<number>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${refundRequestID}`);
    }
}
