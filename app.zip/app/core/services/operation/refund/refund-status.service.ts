import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefundStatusModel } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable()

export class RefundStatusService {
    apiBaseUrl: string = '/api/RefundStatus';

    constructor(private httpClient: HttpClient) { }

    getAllStatus(): Observable<RefundStatusModel[]> {
        return this.httpClient.get<RefundStatusModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetAllStatus`);
    }
}
