import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RefundLetter } from '@app/core/models/operation/refund';
import { environment } from '@environments/environment';
import { Observable, pipe, map } from 'rxjs';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';
import { Utils } from "@app/common/app-functions";

@Injectable()
export class RefundLetterService {
    apiBaseUrl: string = '/api/RefundLetter';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRefundLetter(refundRequestID: number, refundRequestClaimID: number): Observable<RefundLetter[]> {
        return this.httpClient.get<RefundLetter[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}/Letter?RefundRequestID=${refundRequestID}&RefundRequestClaimID=${refundRequestClaimID}`);
    }

    getRefundLetterHistory(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<any>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<any>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<any>(res);
          })
        );
    }

}
