import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-global";
import { ProviderCodeModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderCodeService {

    apiBaseUrl: string = '/api/ProviderCode';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<ProviderCodeModel[]> {

        return this.httpClient.get<ProviderCodeModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderCodeModel[];
            })
        );
    }

    getById(providerCodeId: number): Observable<ProviderCodeModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${providerCodeId}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderCodeModel;
            })
        )
    }

    getByProviderId(ProviderID: number, CodeTypeID?: number): Observable<ProviderCodeModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderCodeByProviderId/${ProviderID}/${CodeTypeID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderCodeModel[];
            })
        );
    }

    create(ProviderCode: ProviderCodeModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderCode);
    }

    update(ProviderCode: ProviderCodeModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderCode);
    }

    delete(ProviderCodeID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderCodeID}`);
    }
}