import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderEligibility } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";


@Injectable()
export class ProviderEligibilityService {
    apiBaseUrl: string = '/api/ProviderEligibility';
    constructor(private httpClient: HttpClient) {
    }

    get(providerID: number) {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetByProvider/${providerID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderEligibility[];
            })
        )
    }

    getHistory(providerID: number, providerEligigbilityID: number) {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetByProvider/${providerID}/${providerEligigbilityID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderEligibility[]
            })
        );
    }

    getById(id: number): Observable<ProviderEligibility> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${id}`).pipe(
            map((response) => {
                response = Utils.camelizeKeys(response);
                return response as ProviderEligibility;
            })
        )
    }

    createOrUpdate(providerEligibility: ProviderEligibility) {
        if (providerEligibility.providerEligibilityId === 0) {
            return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerEligibility);
        }
        else {
            return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerEligibility);
        }
    }

    delete(id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${id}`);
    }
    getMaxProvEligId(providerId:number):Observable<number>
    {
        
return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetMaxProvEligId/${providerId}`).pipe(
    map((res) => {
        
        res = Utils.camelizeKeys(res);
        return res as number
    })
);
    }
}
