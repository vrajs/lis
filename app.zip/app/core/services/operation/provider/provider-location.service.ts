import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderLocationModel, ProviderLocationTerminateModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { Observable, map } from "rxjs";

@Injectable()
export class ProviderLocationService {

    apiBaseUrl: string = '/api/ProviderLocation';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<ProviderLocationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderLocationModel[];
            })
        );
    }

    getById(ProviderLocationID: number): Observable<ProviderLocationModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderLocationID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderLocationModel;
            })
        );
    }

    getByProviderId(ProviderID: number): Observable<ProviderLocationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderLocationByProviderId/${ProviderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderLocationModel[];
            })
        )
    }

    getByLocationId(LocationID: number): Observable<ProviderLocationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderLocationByLocationId/${LocationID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderLocationModel[];
            })
        )
    }

    create(ProviderLocation: ProviderLocationModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderLocation);
    }

    createGroupProviderLocation(ProviderLocation: ProviderLocationModel[]) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}/AddGroupProviderLocation/`, ProviderLocation);
    }

    update(ProviderLocation: ProviderLocationModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderLocation);
    }

    delete(ProviderLocationID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderLocationID}`);
    }
    getGroupProviderLocationByGroupId(GroupID: number, GroupLocationID?: number): Observable<ProviderLocationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetGroupProviderLocationByGroupID/${GroupID}/${GroupLocationID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderLocationModel[];
            })
        )
    }
    deleteOrTermGroupProviderLocation(ProviderLocationTerminateModel: ProviderLocationTerminateModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}/DeleteOrTermGroupProviderLocation`, ProviderLocationTerminateModel);
    }
}
