import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { OData } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '@app/core/services';
import { FacilityLookupModel } from '@app/core/models/common';

@Injectable()
export class FacilityService {

  constructor(private httpClient: HttpClient,
    private oDatabuilderService: ODataBuilderService) {
  }

  getFacilityLookup(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<FacilityLookupModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
    return this.httpClient.get<OData<FacilityLookupModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<FacilityLookupModel>(res);
      })
    );
  }
}
