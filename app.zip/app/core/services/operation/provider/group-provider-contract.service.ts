import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { GroupProviderContract, GroupProviderContractTerminateModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class GroupProviderContractService {

    apiBaseUrl: string = '/api/GroupProviderContract';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<GroupProviderContract[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as GroupProviderContract[];
            })
        );
    }

    getById(GroupProviderContractID: number): Observable<GroupProviderContract> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${GroupProviderContractID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as GroupProviderContract;
            })
        )
    }

    getGroupProviderContract(GroupID: number, ProviderContractID?: number): Observable<GroupProviderContract[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetGroupProviderContract/${GroupID}/${ProviderContractID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as GroupProviderContract[];
            })
        )
    }

    create(GroupProviderContractList: GroupProviderContract[]) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, GroupProviderContractList);
    }

    update(GroupProviderContract: GroupProviderContract) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, GroupProviderContract);
    }

    delete(GroupProviderContractID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${GroupProviderContractID}`);
    }

    terminate(groupProviderContractTerminateModel: GroupProviderContractTerminateModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}/Terminate`, groupProviderContractTerminateModel);
    }

}
