import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { IPALOBModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { Observable, map } from "rxjs";

@Injectable()

export class IPALobService {

    apiBaseUrl: string = '/api/IPALOB';

    constructor(private httpClient: HttpClient) { }

    /**
     * Purpose: Method is use for update IPA list
     * @author Dupendra Pawar # on 06-May-2022 - Get method
    */
    ipaLobGet(ipaid: number): Observable<IPALOBModel> {
        return this.httpClient.get<IPALOBModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetIpaLobByIPAID/${ipaid}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as IPALOBModel;
            })
        );
    }

    get(): Observable<IPALOBModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as IPALOBModel[];
            })
        );
    }

    getById(ProviderRelationID: number): Observable<IPALOBModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderRelationID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as IPALOBModel;
            })
        );
    }

    getByIPAId(ipaID: number): Observable<IPALOBModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetIpaLobByIPAID/${ipaID}`).pipe(
            map(res =>{
                res = Utils.camelizeKeys(res);
                return res as IPALOBModel[]
            })
        );
    }

    create(ipaLob: IPALOBModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ipaLob);
    }

    update(ipaLob: IPALOBModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ipaLob);
    }

    delete(ipalobid: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ipalobid}`);
    }

}