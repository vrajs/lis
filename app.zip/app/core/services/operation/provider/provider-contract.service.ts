import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderContractModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderContractService {

    apiBaseUrl: string = '/api/ProviderContract';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<ProviderContractModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderContractModel[];
            })
        )
    }

    getById(ProviderContractID: number): Observable<ProviderContractModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderContractID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderContractModel;
            })
        )
    }

    getByProviderId(ProviderID: number): Observable<ProviderContractModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderContractByProviderId/${ProviderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderContractModel[];
            })
        )
    }

    getProviderContractDropDownByProviderID(ProviderID: number): Observable<ProviderContractModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderContractDropDownByProviderID/${ProviderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderContractModel[];
            })
        )
    }

    create(ProviderContract: ProviderContractModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderContract);
    }

    update(ProviderContract: ProviderContractModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderContract);
    }

    delete(ProviderContractID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderContractID}`);
    }

}
