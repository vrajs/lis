import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderRelationModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderRelationService {

    apiBaseUrl: string = '/api/ProviderRelation';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<ProviderRelationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderRelationModel[];
            })
        )
    }

    getById(ProviderRelationID: number): Observable<ProviderRelationModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderRelationID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderRelationModel;
            })
        );
    }

    getByParentProviderId(parentProviderID: number): Observable<ProviderRelationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderRelationByParentProviderId/${parentProviderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderRelationModel[];
            })
        );
    }

    //getByLocationId(ProviderID: number): Observable<ProviderRelation[]> {
    //    return this._interceptedHttp.get(this.apiBaseUrl + '/GetProviderLocationByLocationId/' + ProviderID).map((res: Response) => <ProviderRelation[]>res.json())
    //}

    create(ProviderRelation: ProviderRelationModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`,ProviderRelation);
    }

    update(ProviderRelation: ProviderRelationModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`,ProviderRelation);
    }

    delete(ProviderRelationID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderRelationID}`);
    }
}
