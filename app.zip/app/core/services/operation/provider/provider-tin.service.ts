import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderTINModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderTINService {

    apiBaseUrl: string = '/api/ProviderTIN';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<ProviderTINModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderTINModel[];
            })
        )
    }

    getById(ProviderTINID: number): Observable<ProviderTINModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderTINID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderTINModel;
            })
        )
    }

    getByProviderId(ProviderID: number): Observable<ProviderTINModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderTINByProviderId/${ProviderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderTINModel[];
            })
        );
    }

    getByProviderIdTINTypeId(ProviderID: number, TINTypeId: number): Observable<ProviderTINModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderTINByProviderIdTINTypeID/${ProviderID}/${TINTypeId}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderTINModel[];
            })
        )
    }

    create(ProviderTIN: ProviderTINModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderTIN);
    }

    update(ProviderTIN: ProviderTINModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ProviderTIN);
    }

    delete(ProviderTINID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderTINID}`);
    }
}
