import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { IPAModel, OData } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../..";

@Injectable()
export class IPAService {
  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) { }

  /**
   * Purpose: Method is use for get IPA list
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  getIPAList(): Observable<IPAModel[]> {
    return this.httpClient.get<IPAModel[]>(`${environment.serviceApiUrl}/api/IPA`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as IPAModel[];
      })
    );
  }

  /**
   * Purpose: Method is use for add IPA
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  addIPA(data: IPAModel): Observable<IPAModel> {
    return this.httpClient.post<IPAModel>(`${environment.serviceApiUrl}/api/IPA`, data).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as IPAModel;
      })
    );
  }

  /**
   * Purpose: Method is use for update IPA list
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  updateIPA(data: IPAModel): Observable<IPAModel> {
    return this.httpClient.put<IPAModel>(`${environment.serviceApiUrl}/api/IPA`, data).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as IPAModel;
      })
    );
  }

  /**
   * Purpose: Method is use for update IPA list
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
  getIPAbyId(ipaid: number): Observable<IPAModel> {
    return this.httpClient.get<IPAModel>(`${environment.serviceApiUrl}/api/IPA/${ipaid}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as IPAModel;
      })
    );
  }

  /**
   * Purpose: Method is use to delete IPA
   * @author Dupendra Pawar # on 06-May-2022 - Delete method
  */
  deleteIPA(id: string): Observable<IPAModel> {
    return this.httpClient.delete<IPAModel>(`${environment.serviceApiUrl}/api/IPA/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as IPAModel;
      })
    );
  }

  getWithAdvanceFilter(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<IPAModel>> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true)
    return this.httpClient.get<OData<IPAModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<IPAModel>(res);
      })
    );
  }
}