import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderNoteModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderNoteService {
    apiBaseUrl: string = '/api/ProviderNote';

    constructor(private httpClient: HttpClient) {
    }

    get() {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderNoteModel;
            })
        );
    }

    getByProvider(providerID: number) {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetByProvider/${providerID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderNoteModel[];
            })
        )
    }

    getById(id: number): Observable<ProviderNoteModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${id}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderNoteModel;
            })
        )
    }

    createOrUpdate(providerNote: ProviderNoteModel) {
        if (providerNote.providerNoteId === 0) {
            return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerNote);
        }
        else {
            return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerNote);
        }
    }

    delete(id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${id}`);
    }
}
