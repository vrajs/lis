import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { KeyValModel, LocationModel, OData, TerminateLocationModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { Observable, map } from "rxjs";
import { ODataBuilderService } from "../../common/odata-builder.service";

@Injectable()
export class LocationService {

    apiBaseUrl: string = '/api/Location';

    constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) { }

    get(): Observable<LocationModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as LocationModel[];
            })
        );
    }

    getOdataList(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<LocationModel>> {
        let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/Locations`, filteringArgs, sortingArgs, index, perPage)
        return this.httpClient.get<OData<LocationModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<LocationModel>(res);
          })
        );
      }

    delete(Id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`);
    }

    getById(Id: number): Observable<LocationModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${Id}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as LocationModel;
            })
        );
    }

    // Here use json.stringify beacuse post method support json string.
    create(location: LocationModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, location);
    }

    // Here use json.stringify beacuse put method support json string.
    update(location: LocationModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, location);
    }

    getKeyVal() {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetKeyVal`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as KeyValModel[];
            })
        )
    }

    terminate(terminate: TerminateLocationModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}/Terminate`, terminate);
    }
}
