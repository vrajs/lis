import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderIPAModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderIPAService {

    apiBaseUrl: string = '/api/ProviderIPA';

    constructor(private htppClinet: HttpClient) { }

    get(): Observable<ProviderIPAModel[]> {
        return this.htppClinet.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderIPAModel[];
            })
        );
    }

    getById(providerIPAID: number): Observable<ProviderIPAModel> {
        return this.htppClinet.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${providerIPAID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderIPAModel;
            })
        );
    }

    getByProviderId(providerID: number): Observable<ProviderIPAModel[]> {
        return this.htppClinet.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/getByProviderId/${providerID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderIPAModel[];
            })
        );
    }

    getByIPAId(ipaid: number): Observable<ProviderIPAModel[]> {
        return this.htppClinet.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/getByIPAId/${ipaid}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderIPAModel[];
            })
        );
    }

    create(providerIPA: ProviderIPAModel) {
        return this.htppClinet.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerIPA);
    }

    update(providerIPA: ProviderIPAModel) {
        return this.htppClinet.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerIPA);
    }

    delete(providerIPAID: number) {
        return this.htppClinet.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${providerIPAID}`);
    }
}
