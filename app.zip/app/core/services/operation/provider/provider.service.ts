import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { GroupProviderContract, HasGroupConfigurationData, HasProviderConfigurationData, KeyValModel, OData, ProviderLocationModel, ProviderModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { ODataBuilderService } from '@app/core/services';
import { ProviderLookupModel } from '@app/core/models/common';
import { FacilityLookupModel } from '@app/core/models/common/facility-lookup.model';
import { MemberLookupModel } from '@app/core/models/common';

@Injectable()

export class ProviderService {

  public providerList: Observable<ProviderModel[]>;
  public _providerList: BehaviorSubject<ProviderModel[]>;

  constructor(private httpClient: HttpClient,
    private oDatabuilderService: ODataBuilderService) {
    this._providerList = new BehaviorSubject([]);
    this.providerList = this._providerList.asObservable();
  }

  get(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ProviderModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/Provider`, filteringArgs, sortingArgs, index, perPage)
    return this.httpClient.get<OData<ProviderModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ProviderModel>(res);
      })
    );
  }

  getWithAdvanceFilter(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ProviderModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true)
    return this.httpClient.get<OData<ProviderModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ProviderModel>(res);
      })
    );
  }

  getById(providerID: number): Observable<ProviderModel> {
    return this.httpClient.get<ProviderModel>(`${environment.serviceApiUrl}/api/Provider/${providerID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ProviderModel;
      })
    );
  }

  getView(id: number): Observable<ProviderModel> {
    return this.httpClient.get<ProviderModel>(`${environment.serviceApiUrl}/api/Provider/getView/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ProviderModel;
      })
    );
  }

  create(model: ProviderModel): Observable<ProviderModel> {
    return this.httpClient.post<ProviderModel>(`${environment.serviceApiUrl}/api/Provider`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ProviderModel;
      })
    );
  }

  update(model: ProviderModel): Observable<ProviderModel> {
    return this.httpClient.put<ProviderModel>(`${environment.serviceApiUrl}/api/Provider`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ProviderModel;
      })
    );
  }

  getDataFromNPPES(number: string): Observable<ProviderModel> {
    return this.httpClient.get<ProviderModel>(`${environment.serviceApiUrl}/api/Provider/GetDataFromNPPES/?number=${number}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        console.log(res);
        return res as ProviderModel;
      })
    );
  }

  delete(id: number): Observable<number> {
    return this.httpClient.delete<number>(`${environment.serviceApiUrl}/api/Provider/${id}`).pipe(
      map(res => {
        return res as number;
      })
    );
  }

  checkProviderConfigurationHasData(providerID: number): Observable<HasProviderConfigurationData> {
    return this.httpClient.get<HasProviderConfigurationData>(`${environment.serviceApiUrl}/api/Provider/checkProviderConfigurationHasData/${providerID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        console.log(res);
        return res as HasProviderConfigurationData;
      })
    );
  }

  createGroupFromProvider(providerID: number) {
    return this.httpClient.get(`${environment.serviceApiUrl}/api/Provider/CreateGroupFromProvider/${providerID}`).pipe(
      map(res => res as any)
    )
  }

  getProviderLocation(providerID: number) {
    return this.httpClient.get(`${environment.serviceApiUrl}/api/Provider/GetProviderLocation/${providerID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ProviderLocationModel[];
      })
    )
  }

  getProviderContract(providerID: number) {
    return this.httpClient.get(`${environment.serviceApiUrl}/api/Provider/GetProviderContract/${providerID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as GroupProviderContract[];
      })
    )
  }

  checkGroupConfigurationHasData(providerID: number): Observable<HasGroupConfigurationData> {
    return this.httpClient.get(`${environment.serviceApiUrl}/api/Provider/checkGroupConfigurationHasData/${providerID}`).pipe(
      map((res) => {
        res = Utils.camelizeKeys(res);
        return res as HasGroupConfigurationData;
      })
    );
  }
  
  getClaimProvider(searchText: string, claimDOSFrom: string, claimDOSTo: string): Observable<Array<ProviderLookupModel>> {
      return this.httpClient.get<ProviderLookupModel[]>(`${environment.serviceApiUrl}/api/Provider/GetClaimProvider?SearchText=${searchText}&ClaimDOSFrom=${claimDOSFrom}&ClaimDOSTo=${claimDOSTo}`);
  }

  getClaimFacility(searchText: string, claimDOSFrom: string, claimDOSTo: string): Observable<Array<FacilityLookupModel>> {
    return this.httpClient.get<FacilityLookupModel[]>(`${environment.serviceApiUrl}/api/Provider/GetClaimFacility?SearchText=${searchText}&ClaimDOSFrom=${claimDOSFrom}&ClaimDOSTo=${claimDOSTo}`);
  }

  getProviderLookup(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ProviderLookupModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
    return this.httpClient.get<OData<ProviderLookupModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ProviderLookupModel>(res);
      })
    );
  }
}
