import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { ProviderEFTModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderEFTService {

    apiBaseUrl: string = '/api/ProviderEFT';

    constructor(private httpClient: HttpClient) { }

    get(): Observable<ProviderEFTModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as ProviderEFTModel[];
            })
        );
    }

    getById(BenefitCodeID: number): Observable<ProviderEFTModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${BenefitCodeID}`).pipe(
            map((res) =>{
                res = Utils.camelizeKeys(res);
                return res as ProviderEFTModel;
            })
        )
    }

    getByProviderId(ProviderID: number): Observable<ProviderEFTModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderEFTByProviderId/${ProviderID}`).pipe(
            map((res) =>{
                res = Utils.camelizeKeys(res);
                return res as ProviderEFTModel[];
            })
        )
    }

    getByProviderIdAccountTypeId(ProviderID: number, AccountTypeID: number): Observable<ProviderEFTModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetProviderEFTByProviderIdAccountTypeID/${ProviderID}/${AccountTypeID}`).pipe(
            map((res) =>{
                res = Utils.camelizeKeys(res);
                return res as ProviderEFTModel[];
            })
        );
    }

    create(ProviderEFT: ProviderEFTModel) {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`,ProviderEFT);
    }

    update(ProviderEFT: ProviderEFTModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`,ProviderEFT);
    }

    delete(ProviderTINID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ProviderTINID}`);
    }
}
