import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-global";
import { ProviderSpecialtyModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()
export class ProviderSpecialtyService {
    apiBaseUrl: string = '/api/ProviderSpecialty';
    constructor(private httpClient: HttpClient) {
    }

    get() {
        return this.httpClient.get<ProviderSpecialtyModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderSpecialtyModel;
            })
        );
    }

    getByProvider(providerID: number) {
        return this.httpClient.get<ProviderSpecialtyModel[]>(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetByProvider/${providerID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderSpecialtyModel[];
            })
        );
    }

    getById(id: number): Observable<ProviderSpecialtyModel> {
        return this.httpClient.get<ProviderSpecialtyModel>(`${environment.serviceApiUrl}${this.apiBaseUrl}/${id}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as ProviderSpecialtyModel;
            })
        );
    }

    createOrUpdate(providerSpecialty: ProviderSpecialtyModel) {
        if (providerSpecialty.providerSpecialtyId === 0) {
            return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, providerSpecialty);
        }
        else {
            return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`,providerSpecialty);
        }
    }

    delete(id: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${id}`);
    }

    checkIfExistIsPrimary(providerID: number, providerSpecialtyID) {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/CheckIfExistIsPrimary/${providerID}/${providerSpecialtyID}`).pipe(
            map((res) => res as boolean)
        )
    }
}