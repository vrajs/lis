import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { ClaimEOBEOPUserModel } from '@app/core/models/operation/claim';
import { Utils } from '@app/common/app-functions';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { OData } from '@app/core/models';

@Injectable()
export class ClaimEOBEOPService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getClaimEOBEOPData(claimHeaderId: number,eobeopTypeId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimEOBEOPUserModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClaimEOBEOP`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClaimEOBEOPUserModel>>(`${dynamicUrl}&ClaimHeaderID=${claimHeaderId}&EOBEOPTypeID=${eobeopTypeId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimEOBEOPUserModel>(res);
            })
        );
    }

    get(): Observable<ClaimEOBEOPUserModel[]> {
        return this.httpClient.get<ClaimEOBEOPUserModel[]>(`${environment.serviceApiUrl}/api/ClaimEOBEOP`);
    }

    getById(ClaimEOBEOPID: number): Observable<ClaimEOBEOPUserModel> {
        return this.httpClient.get<ClaimEOBEOPUserModel>(`${environment.serviceApiUrl}/api/ClaimEOBEOP/${ClaimEOBEOPID}`);
    }

    createOrUpdate(ClaimEOBEOP: ClaimEOBEOPUserModel): Observable<Number> {
        if (ClaimEOBEOP.claimEobEopId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimEOBEOP`, ClaimEOBEOP);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimEOBEOP`, ClaimEOBEOP);
        }
    }

    delete(ClaimEOBEOPID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimEOBEOP/${ClaimEOBEOPID}`);
    }
}
