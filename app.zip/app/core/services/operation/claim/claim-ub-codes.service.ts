import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-functions';
import { StringFilterType } from "@app/common/app-enum";
import { ClaimUBCodesModel } from '@app/core/models/operation/claim';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';

@Injectable()
export class ClaimUBCodesService {

    constructor(private httpClient: HttpClient,
        private oDatabuilderService: ODataBuilderService) {
    }

    getUBcodeDesc(Clinicalcode: Array<number>, code: string) {
        return this.httpClient.get(`${environment.serviceApiUrl}/odata/RevenueUBCodes?$count=true&$filter=${Utils.getOdataStringForStringFilterType(StringFilterType.Equals, "Code", code)}&ClinicalCodeTypeID=${Clinicalcode.join(",").toString()}`);
    }

    get(): Observable<ClaimUBCodesModel[]> {
        return this.httpClient.get<ClaimUBCodesModel[]>(`${environment.serviceApiUrl}/api/ClaimUBCodes`);
    }

    getById(claimUBCodesID: number): Observable<ClaimUBCodesModel> {
        return this.httpClient.get<ClaimUBCodesModel>(`${environment.serviceApiUrl}/api/ClaimUBCodes/${claimUBCodesID}`);
    }

    createOrUpdate(claimUBCodes: ClaimUBCodesModel): Observable<Number> {
        if (claimUBCodes.claimUbCodesId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimUBCodes`, claimUBCodes);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimUBCodes`, claimUBCodes);
        }
    }

    delete(claimUBCodesID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimUBCodes/${claimUBCodesID}`);
    }

    getClaimUBcodes(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimUBCodesModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<ClaimUBCodesModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<ClaimUBCodesModel>(res);
          })
        );
    }
}
