import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-functions';
import { ClaimReferenceModel } from '@app/core/models/operation/claim';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';

@Injectable()
export class ClaimReferenceService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    get(): Observable<ClaimReferenceModel[]> {
        return this.httpClient.get<ClaimReferenceModel[]>(`${environment.serviceApiUrl}/api/ClaimReference`);
    }

    getById(claimReferenceID: number): Observable<ClaimReferenceModel> {
        return this.httpClient.get<ClaimReferenceModel>(`${environment.serviceApiUrl}/api/ClaimReference/${claimReferenceID}`);
    }

    createOrUpdate(claimReference: ClaimReferenceModel): Observable<Number> {
        if (claimReference.claimReferenceId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimReference`, claimReference);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimReference`, claimReference);
        }
    }

    delete(claimReferenceID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimReference/${claimReferenceID}`);
    }

    getClaimReference(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimReferenceModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<ClaimReferenceModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<ClaimReferenceModel>(res);
          })
        );
    }
}
