import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';
import { ClaimOtherPhysicianModel } from '@app/core/models/operation/claim';

@Injectable()
export class ClaimOtherPhysicianService {

    constructor(private httpClient: HttpClient,
        private oDatabuilderService: ODataBuilderService) {
    }

    get(): Observable<ClaimOtherPhysicianModel[]> {
        return this.httpClient.get<ClaimOtherPhysicianModel[]>(`${environment.serviceApiUrl}/api/ClaimOtherPhysician`);
    }

    getById(claimUBCodesID: number): Observable<ClaimOtherPhysicianModel> {
        return this.httpClient.get<ClaimOtherPhysicianModel>(`${environment.serviceApiUrl}/api/ClaimOtherPhysician/${claimUBCodesID}`);
    }

    createOrUpdate(claimOtherPhysician: ClaimOtherPhysicianModel): Observable<Number> {
        if (claimOtherPhysician.claimOtherPhysicianId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimOtherPhysician`,claimOtherPhysician);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimOtherPhysician`, claimOtherPhysician);
        }
    }

    delete(claimOtherPhysicianID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimOtherPhysician/${claimOtherPhysicianID}`);
    }

    getClaimOtherPhysicians(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimOtherPhysicianModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<ClaimOtherPhysicianModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<ClaimOtherPhysicianModel>(res);
          })
        );
      }
}
