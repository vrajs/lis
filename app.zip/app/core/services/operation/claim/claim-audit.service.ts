//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//# Project Namespace
import { environment } from '@environments/environment';
//#endregion

//# Model Namespace
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '../../common/odata-builder.service';
//#endregion

@Injectable()

export class ClaimAuditService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    //#region Public Methods
    getClaimAuditData(claimHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<any>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClaimAudit`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<any>>(`${dynamicUrl}&ClaimHeaderID=${claimHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<any>(res);
            })
        );
    }
    //#endregion
}

