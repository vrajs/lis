import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { ClaimEditsModel } from '@app/core/models/operation/claim';
import { Utils } from '@app/common/app-functions';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { OData } from '@app/core/models';

@Injectable()
export class  ClaimEditsService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getClaimEditsData(claimHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimEditsModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClaimEdits`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClaimEditsModel>>(`${dynamicUrl}&ClaimHeaderID=${claimHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimEditsModel>(res);
            })
        );
    }

    get(): Observable< ClaimEditsModel[]> {
        return this.httpClient.get<ClaimEditsModel[]>(`${environment.serviceApiUrl}/api/ClaimEdits`);
    }

    getById( ClaimEditsID: number): Observable< ClaimEditsModel> {
        return this.httpClient.get<ClaimEditsModel>(`${environment.serviceApiUrl}/api/ClaimEdits/${ClaimEditsID}`);
    }

    createOrUpdate(ClaimEdits: ClaimEditsModel): Observable<Number> {
        if (ClaimEdits.claimEditsId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimEdits`, ClaimEdits);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimEdits`, ClaimEdits);
        }
    }

    delete(ClaimEditsID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimEdits/${ClaimEditsID}`);
    }
}
