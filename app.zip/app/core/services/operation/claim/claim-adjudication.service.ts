//#region System Namespace
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
//#endregion

//# Project Namespace
import { environment } from '@environments/environment';
//#endregion

//# Model Namespace
import { AdjudicationResultModel } from '@app/core/models/operation/claim';
import { Utils } from '@app/common/app-functions';
//#endregion

@Injectable()

export class ClaimAdjudicationService {

    constructor(private httpClient: HttpClient) {}

    //#region Public Methods
    adjudicateClaim(claimNumber: string): Observable<AdjudicationResultModel> {
        return this.httpClient.post<AdjudicationResultModel>(`${environment.claimAdjudicationApiUrl}/api/ClaimAdjudication`, claimNumber);
    }
    //#endregion
}

