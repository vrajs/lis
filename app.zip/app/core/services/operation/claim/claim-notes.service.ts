import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { ClaimNotesModel } from '@app/core/models/operation/claim';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';

@Injectable()
export class ClaimNotesService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    get(): Observable<ClaimNotesModel[]> {
        return this.httpClient.get<ClaimNotesModel[]>(`${environment.serviceApiUrl}/api/ClaimNotes`);
    }

    getById(ClaimNotesID: number): Observable<ClaimNotesModel> {
        return this.httpClient.get<ClaimNotesModel>(`${environment.serviceApiUrl}/api/ClaimNotes/${ClaimNotesID}`);
    }

    create(claimNotes: ClaimNotesModel): Observable<Number> {
        return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimNotes`, claimNotes);
    }

    getClaimNotes(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimNotesModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<ClaimNotesModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<ClaimNotesModel>(res);
          })
        );
    }
}
