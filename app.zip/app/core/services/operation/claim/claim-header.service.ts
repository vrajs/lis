import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { ClaimHeaderModel, ClaimListModel, ClaimLoockupModel } from '@app/core/models/operation/claim';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { IForOfState } from '@infragistics/igniteui-angular';

@Injectable()
export class ClaimHeaderService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    get() {
        return this.httpClient.get(`${environment.serviceApiUrl}/api/ClaimHeader`);
    }

    getClaimHeaderData(dynamicUrl): Observable<OData<ClaimListModel>> {
        // let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClinicalCodeGroupDetails`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClaimListModel>>(`${dynamicUrl}&$orderby=ClaimHeaderID asc`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimListModel>(res);
            })
        );
    }

    getClaimHeaderByOdata(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimListModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClaimList`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClaimListModel>>(`${dynamicUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimListModel>(res);
            })
        );
    }
    getClaimLookupListByOdata(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimLoockupModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClaimLoockup`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClaimLoockupModel>>(`${dynamicUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimLoockupModel>(res);
            })
        );
    }

    getClaimLookup(virtulizationState?: IForOfState, searchText?: string, containProperty?: string): Observable<OData<ClaimLoockupModel>> {
        let url = `${environment.serviceApiUrl}/odata/ClaimLoockup`;
        let buildQuery = this.oDatabuilderService.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
        return this.httpClient.get<OData<ClaimLoockupModel>>(buildQuery).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimLoockupModel>(res);
            })
        );
    }


    getBillTypeCodes(): Observable<any[]> {
        return this.httpClient.get<any[]>(`${environment.serviceApiUrl}/odata/BillTypeCodes?$count=true&$orderby=Code asc`).pipe(map((res: any) => {
            res = Utils.camelizeKeys(res);
            return res.value as any[];
        }));
    }
    getMemberAlertInfo(ID: number): Observable<any[]> {
        return this.httpClient.get<any[]>(`${environment.serviceApiUrl}/odata/Alert?$count=true&$orderby=AlertModuleID asc&AlertDataID=${ID}`).pipe(map((res: any) => {
            res = Utils.camelizeKeys(res);
            return res.value as any[];
        }));
    }

    getClaimByClaimNumber(claimNumber: string): Observable<any> {
        return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/ClaimHeader/GetClaimByClaimNumber/${claimNumber}`).pipe(map(res => {
            res = Utils.camelizeKeys(res);
            return res;
        }));;
    }

    createOrUpdate(entity: ClaimHeaderModel): Observable<ClaimHeaderModel> {
        if (entity.claimHeaderId === 0) {
            return this.httpClient.post<ClaimHeaderModel>(`${environment.serviceApiUrl}/api/ClaimHeader`, entity);
        }
        else {
            return this.httpClient.put<ClaimHeaderModel>(`${environment.serviceApiUrl}/api/ClaimHeader`, entity);
        }
    }

    delete(claimHeaderID: number, claimDeleteReason: string): Observable<number> {
        return this.httpClient.delete<number>(`${environment.serviceApiUrl}/api/ClaimHeader/${claimHeaderID}/${claimDeleteReason}`);
    }

    generateClaimNumber(receivedDate: Date, claimSourceID: number): Observable<string> {
        return this.httpClient.get<string>(`${environment.serviceApiUrl}/api/ClaimHeader/GenerateClaimNumber?ReceivedDate=${receivedDate}&ClaimSourceID=${claimSourceID}`).pipe(map(res => {
            res = Utils.camelizeKeys(res);
            return res;
        }));;
    }

    getClaimForRefund(claimNumber: string): Observable<ClaimLoockupModel> {
        return this.httpClient.get<ClaimLoockupModel>(`${environment.serviceApiUrl}/api/ClaimHeader/GetClaimForRefund/${claimNumber}`).pipe(map(res => {
            res = Utils.camelizeKeys(res);
            return res;
        }));
    }

    checkClaimHasRequireInfoForAdjudication(claimHeaderID: number): Observable<boolean> {
        return this.httpClient.get<boolean>(`${environment.serviceApiUrl}/api/ClaimHeader/CheckClaimHasRequireInfoForAdjudication/${claimHeaderID}`);
    }
}
