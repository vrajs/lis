import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-functions';
import { OData } from '@app/core/models/common';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { ClaimProcessingStepsModel } from '@app/core/models/operation/claim';

@Injectable({
  providedIn: 'root'
})
export class ClaimProcessingStepsService {

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

  getClaimProcessingSteps(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimProcessingStepsModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
    return this.httpClient.get<OData<ClaimProcessingStepsModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<ClaimProcessingStepsModel>(res);
      })
    );
  }
}
