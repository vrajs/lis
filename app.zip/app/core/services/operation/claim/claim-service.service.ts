import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-functions';
import { StringFilterType } from "@app/common/app-enum";
import { ClaimServiceViewModel, ServiceTermContractFeeScheduleModel, DollarsCalculationModel } from '@app/core/models/operation/claim';
import { KeyValModel, OData } from '@app/core/models/common';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { IForOfState } from '@infragistics/igniteui-angular';

@Injectable()
export class ClaimService {

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getClaimServiceData(claimHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimServiceViewModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/ClaimService`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<ClaimServiceViewModel>>(`${dynamicUrl}&ClaimHeaderID=${claimHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<ClaimServiceViewModel>(res);
            })
        );
    }

    getRenderingProviderNPI(virtulizationState?: IForOfState, searchText?: string, containProperty?: string): Observable<OData<any>> {
        let url = `${environment.serviceApiUrl}/odata/ClaimProviderNPI`;
        let buildQuery = this.oDatabuilderService.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
        return this.httpClient.get<OData<any>>(buildQuery).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<any>(res);
            })
        );
    }

    getNDCCodes() {
        return this.httpClient.get<any>(`${environment.serviceApiUrl}/odata/NDCData?$count=true`).pipe(map(res => {
            res = Utils.camelizeKeys(res);
            return res;
        }));
    }

    // getRenderingProviderNPI() {
    //     return this.httpClient.get<any>(`${environment.serviceApiUrl}/odata/ClaimProviderNPI?$count=true&$filter=${Utils.getOdataStringForStringFilterType(StringFilterType.NotEqual, "NPI", "")}`);
    // }

    getAnesthesiaUnit(code: string, lOBID: number, dosFrom: any, dosTo: any): Observable<number> {
        return this.httpClient.get<number>(`${environment.serviceApiUrl}/api/ClaimService/GetAnesthesiaUnit?Code=${code}&lOBID=${lOBID}&DosFrom=${dosFrom}&DosTo=${dosTo}`);
    }

    getAnesthesiaCalculatedAmount(claimHeaderID: number, unit: number, dosFrom: any, dosTo: any): Observable<number> {
        return this.httpClient.get<number>(`${environment.serviceApiUrl}/api/ClaimService/GetAnesthesiaCalculatedAmount?ClaimHeaderID=${claimHeaderID}&Unit=${unit}&DosFrom=${dosFrom}&DosTo=${dosTo}`);
    }
    getDiagnosisDesc(code: string) {
        return this.httpClient.get<any>(`${environment.serviceApiUrl}/odata/ICDCodes?$count=true&$filter=${Utils.getOdataStringForStringFilterType(StringFilterType.Equals, "Code", code)}`);
    }

    getDollarAmt(DollarsCalculation: DollarsCalculationModel) {
        return this.httpClient.post<any>(`${environment.serviceApiUrl}/api/ClaimService/GetDollarValues`, DollarsCalculation);
    }

    getServiceContract(lOBID: number, DosFrom: any, DosTo: any): Observable<KeyValModel[]> {
        return this.httpClient.get<KeyValModel[]>(`${environment.serviceApiUrl}/api/ClaimService/GetServiceContract?lOBID=${lOBID}&DosFrom=${DosFrom}&DosTo=${DosTo}`);
    }

    getClaimBenefits(MemberEligibilityID: number, MemberAge: number, FormTypeID: number, Code: KeyValModel[], DosFrom: any, DosTo: any): Observable<KeyValModel[]> {
        return this.httpClient.post<KeyValModel[]>(`${environment.serviceApiUrl}/api/ClaimService/GetClaimBenefits?MemberEligibilityID=${MemberEligibilityID}&MemberAge=${MemberAge}&FormTypeID=${FormTypeID}&DosFrom=${DosFrom}&DosTo=${DosTo}`, Code);
    }

    getServiceTermContract(ClaimHeaderID: number, MemberGender: string, MemberAge: number, ServiceLineID: number, ContractID: number, Code: KeyValModel[], DosFrom: any, DosTo: any): Observable<ServiceTermContractFeeScheduleModel> {
        return this.httpClient.post<ServiceTermContractFeeScheduleModel>(`${environment.serviceApiUrl}/api/ClaimService/GetServiceTermContract?ClaimHeaderID=${ClaimHeaderID}&MemberGender=${MemberGender}&MemberAge=${MemberAge}&ServiceLineID=${ServiceLineID}&ContractID=${ContractID}&DosFrom${DosFrom}&DosTo=${DosTo}`, Code);
    }

    getServiceFeeSchedule(ContractID: number, Code: KeyValModel[], DosFrom: any, DosTo: any): Observable<any> {
        return this.httpClient.post<any>(`${environment.serviceApiUrl}/api/ClaimService/GetServiceFeeSchedule?ContractID=${ContractID}&DosFrom=${DosFrom}&DosTo=${DosTo}`, Code);
    }

    get(): Observable<ClaimServiceViewModel[]> {
        return this.httpClient.get<ClaimServiceViewModel[]>(`${environment.serviceApiUrl}/api/ClaimService`);
    }

    getById(ClaimServiceID: number): Observable<ClaimServiceViewModel> {
        return this.httpClient.get<ClaimServiceViewModel>(`${environment.serviceApiUrl}/api/ClaimService/${ClaimServiceID}`);
    }

    createOrUpdate(ClaimService: ClaimServiceViewModel): Observable<Number> {
        if (ClaimService.claimServiceId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimService`, ClaimService);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimService`, ClaimService);
        }
    }

    delete(ClaimServiceID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimService/${ClaimServiceID}`);
    }
}
