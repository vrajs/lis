import { Injectable } from '@angular/core';
import { Observable, pipe, map } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { StringFilterType } from "@app/common/app-enum";
import { Utils } from "@app/common/app-functions";
import { environment } from '@environments/environment';
import { ClaimDiagnosisModel } from '@app/core/models/operation/claim';
import { OData } from '@app/core/models';
import { ODataBuilderService } from '@app/core/services';

@Injectable()
export class ClaimDiagnosisService {

    constructor(private httpClient: HttpClient,
        private oDatabuilderService: ODataBuilderService) {
    }

    getDiagnosisDesc(code: string):Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}/odata/ICDCodes?$count=true&$filter=${Utils.getOdataStringForStringFilterType(StringFilterType.Equals, "Code", code)}`);
    }

    getDiagnosisProcDesc(code: string):Observable<any> {
        return this.httpClient.get(`${environment.serviceApiUrl}/odata/CPTAndHCPCCodes?$count=true&$filter=${Utils.getOdataStringForStringFilterType(StringFilterType.Equals, "Code", code)}`);
    }

    get(): Observable<ClaimDiagnosisModel[]> {
        return this.httpClient.get<ClaimDiagnosisModel[]>(`${environment.serviceApiUrl}/api/ClaimDiagnosis`);
    }

    getById(claimDiagnosisID: number): Observable<ClaimDiagnosisModel> {
        return this.httpClient.get<ClaimDiagnosisModel>(`${environment.serviceApiUrl}/api/ClaimDiagnosis/${claimDiagnosisID}`);
    }

    createOrUpdate(claimDiagnosis: ClaimDiagnosisModel): Observable<Number> {
        if (claimDiagnosis.claimDiagnosisId === 0) {
            return this.httpClient.post<Number>(`${environment.serviceApiUrl}/api/ClaimDiagnosis`, claimDiagnosis);
        }
        else {
            return this.httpClient.put<Number>(`${environment.serviceApiUrl}/api/ClaimDiagnosis`, claimDiagnosis);
        }
    }

    delete(ClaimDiagnosisID: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/ClaimDiagnosis/${ClaimDiagnosisID}`);
    }

    getClaimDiagnosis(claimHeaderID: number): Observable<ClaimDiagnosisModel[]> {
        return this.httpClient.get<ClaimDiagnosisModel[]>(`${environment.serviceApiUrl}/api/ClaimDiagnosis/GetClaimDiagnosis/${claimHeaderID}`);
    }

    getClaimDiagnosisData(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<ClaimDiagnosisModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
        return this.httpClient.get<OData<ClaimDiagnosisModel>>(dynamicUrl).pipe(
          map(res => {
            res = Utils.camelizeKeys(res);
            return new OData<ClaimDiagnosisModel>(res);
          })
        );
    }
}
