//#region System Namespace
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Utils } from '@app/common/app-functions';
import { ActivatedRoute } from '@angular/router';
//#endregion

//#region Models Namespace
import { KeyValModel } from "@app/core/models/common/KeyVal.model";
import { ClaimSearchNevigationModel } from "@app/core/models/operation/claim";
//#endregion

//#region Common Namespace
import { MemoryCashingConstant } from "@app/common/app-enum";
//#endregion

//#region Service Namespace
import { LocalStoreManagerService } from '@app/core/services/administration/security/local-store-manager.service';

//#endregion

@Injectable()

export class ClaimSearchNevigationService {

    //#region Property
    public nevigationModel: ClaimSearchNevigationModel = new ClaimSearchNevigationModel();
    //#endregion

    //#region Constructor
    constructor(private httpClient: HttpClient, private localStoreManager: LocalStoreManagerService, private activeRoute: ActivatedRoute) {
        if (this.activeRoute.snapshot["_routerState"].url.toString().indexOf("claims/details") > -1) {
            this.nevigationModel = this.localStoreManager.getDataObject<ClaimSearchNevigationModel>(MemoryCashingConstant.SERCHED_CLAIM_LIST_NEVIGATION.toString());
        }

        if (Utils.isBlank(this.nevigationModel)) {
            this.nevigationModel = new ClaimSearchNevigationModel();
        }
    }
    //#endregion

    //#region Methods
    fetchClaims() {
        let pSkip = (this.nevigationModel.skip == 0) ? 0 : this.nevigationModel.skip - 2;
        let pTop = this.nevigationModel.top + 4;
        let apiURL=`${this.nevigationModel.dataSourceURL}&$skip=${pSkip}&$top=${pTop}`;
        if(!Utils.isBlank(this.nevigationModel.orderby)){
            apiURL=apiURL+`&$orderby=${this.nevigationModel.orderby}`;
        }
        this.httpClient.get(apiURL).subscribe((res:any) => {
            this.nevigationModel.totalCount = res["@odata.count"];
            this.nevigationModel.totalClaims = [];
            for (let i = 0; i < res.value.length; i++) {
                this.nevigationModel.totalClaims.push(<KeyValModel>{ key: res.value[i].FormTypeID, value: res.value[i].ClaimNumber });
            }
            let currentIndex = this.nevigationModel.totalClaims.findIndex(e => e.value == this.nevigationModel.currentClaimNumber);
            if (currentIndex == 0) {
                this.nevigationModel.isDisablePreviousButton = true;
            }

            this.localStoreManager.savePermanentData(this.nevigationModel, MemoryCashingConstant.SERCHED_CLAIM_LIST_NEVIGATION.toString());
        });
    }
    nextClaim(): KeyValModel {
        let currentIndex = this.nevigationModel.totalClaims.findIndex(e => e.value == this.nevigationModel.currentClaimNumber);
        currentIndex++;
        this.nevigationModel.currentClaimNumber = this.nevigationModel.totalClaims[currentIndex].value;
        if ((this.nevigationModel.skip == 0 ? (currentIndex + 2) : currentIndex) == this.nevigationModel.top + 2) {
            this.nevigationModel.skip = this.nevigationModel.skip + this.nevigationModel.top;
            this.fetchClaims();
        }
        this.nevigationModel.isDisablePreviousButton = false;
        if (this.nevigationModel.totalCount <= (this.nevigationModel.skip + this.nevigationModel.top)) {
            if (currentIndex + 1 == this.nevigationModel.totalClaims.length) {
                this.nevigationModel.isDisableNextButton = true;
            }
        }
        this.localStoreManager.savePermanentData(this.nevigationModel, MemoryCashingConstant.SERCHED_CLAIM_LIST_NEVIGATION.toString());
        return this.nevigationModel.totalClaims[currentIndex];
    }
    previousClaim(): KeyValModel {
        let currentIndex = this.nevigationModel.totalClaims.findIndex(e => e.value == this.nevigationModel.currentClaimNumber);
        currentIndex--;
        this.nevigationModel.currentClaimNumber = this.nevigationModel.totalClaims[currentIndex].value;
        this.nevigationModel.isDisableNextButton = false;
        if (this.nevigationModel.skip != 0 && (currentIndex - 2) == 0) {
            this.nevigationModel.skip = this.nevigationModel.skip - this.nevigationModel.top;
            this.fetchClaims();

        }
        if (this.nevigationModel.skip == 0 && currentIndex == 0) {
            this.nevigationModel.isDisablePreviousButton = true;
        }
        this.localStoreManager.savePermanentData(this.nevigationModel, MemoryCashingConstant.SERCHED_CLAIM_LIST_NEVIGATION.toString());
        return this.nevigationModel.totalClaims[currentIndex];
    }
    //#endregion
}
