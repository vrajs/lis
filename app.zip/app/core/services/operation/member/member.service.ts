import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { KeyValModel, OData, MemberModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { BehaviorSubject, map, Observable } from 'rxjs';
//import { ODataBuilderService } from '@app/core/services';
import { ISortingExpression } from '@infragistics/igniteui-angular';
import { MemberLookupModel } from '@app/core/models/common';
import { ODataBuilderService } from '@app/core/services/common/odata-builder.service';
//import { ODataBuilderService } from '@app/core/services';

@Injectable()

export class MemberService {

  public memberList: Observable<MemberModel[]>;
  public _memberList: BehaviorSubject<MemberModel[]>;

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    this._memberList = new BehaviorSubject([]);
    this.memberList = this._memberList.asObservable();
  }

  get(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<MemberModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/Members`, filteringArgs, sortingArgs, index, perPage)
    return this.httpClient.get<OData<MemberModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<MemberModel>(res);
      })
    );
  }

  getById(ruleHeaderID: number): Observable<MemberModel> {
    return this.httpClient.get<MemberModel>(`${environment.serviceApiUrl}/api/RuleHeader/${ruleHeaderID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        console.log(res);
        return res as MemberModel;
      })
    );
  }


  create(model: MemberModel): Observable<MemberModel> {
    return this.httpClient.post<MemberModel>(`${environment.serviceApiUrl}/api/Member`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberModel;
      })
    );
  }

  update(model: MemberModel): Observable<MemberModel> {
    return this.httpClient.put<MemberModel>(`${environment.serviceApiUrl}/api/RuleHeader`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberModel;
      })
    );
  }

//   delete(zipCodeCodeID: number, codeTypeID: number) {

//     return this.httpClient.delete<ZipCodeModel>(`${environment.serviceApiUrl}/api/zipcode/${zipCodeCodeID}/${codeTypeID}`).pipe(
//       map(res => {
//         res = Utils.camelizeKeys(res);
//         return res as ZipCodeModel;
//       })
//     );
//   }

getClaimMember(searchText: string, claimDOSFrom: string, claimDOSTo: string): Observable<Array<MemberLookupModel>> {
  return this.httpClient.get<MemberLookupModel[]>(`${environment.serviceApiUrl}/api/Member/GetClaimMember?SearchText=${searchText}&ClaimDOSFrom=${claimDOSFrom}&ClaimDOSTo=${claimDOSTo}`);
}

  getMemberLookup(dynamicURLWithParams: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<MemberLookupModel>> {
    let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/${dynamicURLWithParams}`, filteringArgs, sortingArgs, index, perPage, null, true);
    return this.httpClient.get<OData<MemberLookupModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<MemberLookupModel>(res);
      })
    );
  }
}
