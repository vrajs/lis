import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { LetterCorrespondance } from '@app/core/models/operation/member/correspondance.model';
import { TransactionDetailsModel } from '@app/core/models/operation/member/transaction-Details.model';
import { environment } from '@environments/environment';
import { map, Observable, Subject } from 'rxjs';

@Injectable()

export class MemberTransactionDetailService {

  public subjectData = new Subject<string>();

  constructor(private httpClient: HttpClient) { }

  getTransactionDetails(memberId:number): Observable<TransactionDetailsModel[]> {
    return this.httpClient.get<TransactionDetailsModel[]>(`${environment.serviceApiUrl}/api/MemberTransaction/GetTransactionByMemberId/${memberId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TransactionDetailsModel[];
      })
    );
  }
  getCorrespondanceDetails(memberId:number): Observable<LetterCorrespondance[]> {
    return this.httpClient.get<LetterCorrespondance[]>(`${environment.serviceApiUrl}/api/MemberTransaction/GetCorrespondanceByMemberId/${memberId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as LetterCorrespondance[];
      })
    );
  }
  getAllLetterCorrespondance(): Observable<LetterCorrespondance[]> {
    return this.httpClient.get<LetterCorrespondance[]>(`${environment.serviceApiUrl}/api/MemberTransaction/GetAllLetterCorrespondance`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as LetterCorrespondance[];
      })
    );
  }

  getTransactionById(transactionId:number): Observable<TransactionDetailsModel> {
    return this.httpClient.get<TransactionDetailsModel>(`${environment.serviceApiUrl}/api/MemberTransaction/${transactionId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TransactionDetailsModel;
      })
    );
  }

  createTransactionDetails(model: TransactionDetailsModel): Observable<TransactionDetailsModel> {
    return this.httpClient.post<TransactionDetailsModel>(`${environment.serviceApiUrl}/api/MemberTransaction/`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TransactionDetailsModel;
      })
    );
  }

  updateTransactionDetails(model: TransactionDetailsModel): Observable<TransactionDetailsModel> {
    return this.httpClient.put<TransactionDetailsModel>(`${environment.serviceApiUrl}/api/MemberTransaction/`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TransactionDetailsModel;
      })
    );
  }

}
