import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import {ViewBEQDetailsModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';

@Injectable()

export class MemberBEQService {

  constructor(private httpClient: HttpClient) { }


  getBEQResponseData(beqRequestDetailLayoutId: number): Observable<ViewBEQDetailsModel> {
    return this.httpClient.get<ViewBEQDetailsModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetBEQRequestByDetailLayoutID/${beqRequestDetailLayoutId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ViewBEQDetailsModel
      })
    );
  }

getMemberBEQList(memberId: number): Observable<ViewBEQDetailsModel[]>{
    return this.httpClient.get<ViewBEQDetailsModel[]>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetMemberBEQByMemberId/${memberId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ViewBEQDetailsModel[]
      })
    );
  }
}
