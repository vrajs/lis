import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { TRRDetailLayoutModel, VwTRRDetailLayoutListModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { Observable, map } from 'rxjs';

@Injectable()
export class MemberTRRService {

  constructor(private httpClient: HttpClient) { }

/**
* Purpose of method: to bind the grid of member TRR
* @author Tisa Jodhani on 17-June-2022 - to bind grid
*/
  getMemberTRRList(memberId: number): Observable<VwTRRDetailLayoutListModel[]>{
    return this.httpClient.get<VwTRRDetailLayoutListModel[]>(`${environment.serviceApiUrl}/api/TRRDetailLayout/GetTRRDetailLayoutByMemberId/${memberId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VwTRRDetailLayoutListModel[]
      })
    );
  }

/**
* Purpose of method: to bind data for TRR list
* @author Tisa Jodhani on 17-June-2022 - to bind data field
*/
getTRRListData(trrDetailLayoutId: number): Observable<TRRDetailLayoutModel> {
    return this.httpClient.get<TRRDetailLayoutModel>(`${environment.serviceApiUrl}/api/TRRDetailLayout/${trrDetailLayoutId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TRRDetailLayoutModel
      })
    );
  }
}
