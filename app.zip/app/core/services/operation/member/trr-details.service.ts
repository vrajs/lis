import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { TransactionDetailsModel } from '@app/core/models/operation/member/transaction-Details.model';
import { environment } from '@environments/environment';
import { map, Observable, Subject } from 'rxjs';

@Injectable()

export class TRRDetailLayoutService {

  public subjectData = new Subject<string>();

  constructor(private httpClient: HttpClient) { }

  getTRRDetails(memberId:string): Observable<TransactionDetailsModel[]> {
    return this.httpClient.get<TransactionDetailsModel[]>(`${environment.serviceApiUrl}/api/TRRDetailLayout/GetTRRDetailLayoutByMemberId/${memberId}`).pipe(
      map((res) => {
        res = Utils.camelizeKeys(res);
        return res as TransactionDetailsModel[];
      })
    );
  }
}
