import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { MemberSpanViewModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';

@Injectable()
export class MemberSpanService {

  constructor(private httpClient: HttpClient) { }

  getSpanList(memberId:number): Observable<MemberSpanViewModel[]> {
    return this.httpClient.get<MemberSpanViewModel[]>(`${environment.serviceApiUrl}/api/MemberSpan/GetMemberSpanByMemberId/${memberId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberSpanViewModel[];
      })
    );
  }

  getSpanListById(memberSpanId:number):Observable<MemberSpanViewModel>{
    return this.httpClient.get<MemberSpanViewModel>(`${environment.serviceApiUrl}/api/MemberSpan/${memberSpanId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberSpanViewModel;
      })
    );
  }

  createSpan(model: MemberSpanViewModel): Observable<MemberSpanViewModel> {
    return this.httpClient.post<MemberSpanViewModel>(`${environment.serviceApiUrl}/api/MemberSpan`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberSpanViewModel;
      })
    );
  }

  updateSpan(model: MemberSpanViewModel): Observable<MemberSpanViewModel> {
      return this.httpClient.put<MemberSpanViewModel>(`${environment.serviceApiUrl}/api/MemberSpan`, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res as MemberSpanViewModel;
        })
      );
    }
  
}
