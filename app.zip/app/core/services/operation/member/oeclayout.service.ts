import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable,Subject } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { OECLayoutListModel } from '@app/core/models/operation/member/oeclayout-list-model.model';
import { environment } from '@environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OECLayoutService {

  constructor(private httpClient: HttpClient) { }

  GetAllOECLayoutByDataFileToProcessDetailsID(dataFileToProcessDetailsID : number): Observable<OECLayoutListModel[]> {
    return this.httpClient.get<OECLayoutListModel[]>(`${environment.serviceApiUrl}/api/OECLayout/GetAllOECLayoutById?DataFileToProcessDetailsID=${dataFileToProcessDetailsID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as OECLayoutListModel[];
      })
    );
  }
}
