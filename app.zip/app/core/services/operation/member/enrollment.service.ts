import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { MemberRuleModel } from '@app/core/models/common/member-rule.model';
import { AuditHistory } from '@app/core/models/operation/member/audit-history.model';
import { AuditHistoryFilterModel } from '@app/core/models/operation/member/audit-historyFilter.model';
import { MemberAndPlanInfoModel } from '@app/core/models/operation/member/member-and-plan-information.model';
import { PlaceHolderReplaceViewModel } from '@app/core/models/operation/member/placeHolder.model';
import { SEPReasonCodeTypeModel } from '@app/core/models/operation/member/sepReasonCodeType.model';
import { environment } from '@environments/environment';
import { map, Observable, Subject } from 'rxjs';

@Injectable()

export class MemberEnrollmentService {
  private dob: Date;
  private mbi: string;
  private memberTransacData: any;
  private transElData: any;

  public subjectData = new Subject<string>();

  constructor(private httpClient: HttpClient) { }


  getDobData(): Date {
    return this.dob;
  }

  setDobData(dobDate: Date) {
    this.dob = dobDate;
  }
  
  getMBIData(): string {
    return this.mbi;
  }

  setMBIData(mbiData: string) {
    this.mbi = mbiData;
  }

  getMemberTransaData(): any {
    return this.memberTransacData;
  }

  setMemberTransaData(memberTransData: any) {
    this.memberTransacData = memberTransData;
  }

  getTransactionElData(): any {
    return this.transElData;
  }

  setTransactionElData(transactionData: any) {
    return this.transElData = transactionData;
  }


  public sharedData(data: any) {
    this.subjectData.next(data);
  }

  serchValueZipCode(searchValue: string) {
    return this.httpClient.get(`${environment.serviceApiUrl}/api/ZipCode/GetZipCodeBySearchValue/${searchValue}`,).pipe(
      map(res => {
        return res
      })
    )
  }

  getByIdMemberEnrollmentHeader(selectedMemberEnrollmentHeaderId: number): Observable<MemberAndPlanInfoModel> {
    return this.httpClient.get<MemberAndPlanInfoModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/GetMemberEnrollmentHeaderById?MemberEnrollmentHeaderID=${selectedMemberEnrollmentHeaderId}`,).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberAndPlanInfoModel;
      })
    );
  }
  getMemberAuditHistory(memberId: number): Observable<AuditHistory> {
    return this.httpClient.get<AuditHistory>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/GetMemberAuditHistory?memberId=${memberId}`,).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as AuditHistory;
      })
    );
  }

  createMemberEnrollmentHeader(model: MemberAndPlanInfoModel): Observable<MemberAndPlanInfoModel> {
    return this.httpClient.post<MemberAndPlanInfoModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberAndPlanInfoModel;
      })
    );
  }
  getAuditHistory(model: AuditHistoryFilterModel): Observable<AuditHistory[]> {
    return this.httpClient.post<AuditHistory[]>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/GetAuditHistory`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as AuditHistory[];
      })
    );
  }


  updateMemberEnrollmentHeader(model: MemberAndPlanInfoModel): Observable<MemberAndPlanInfoModel> {
    return this.httpClient.put<MemberAndPlanInfoModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/UpdateMemberEmrollmentHeader/`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberAndPlanInfoModel;
      })
    );
  }

  GetSepReasonCodeById(electionTypeCodeId: Number): Observable<SEPReasonCodeTypeModel[]> {
    return this.httpClient.get<SEPReasonCodeTypeModel[]>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/GetSepReasonCodeById?ElectionTypeCodeId=${electionTypeCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as SEPReasonCodeTypeModel[];
      })
    );
  }

  GetRuleById(ruleId: String): Observable<MemberRuleModel[]> {
    return this.httpClient.get<MemberRuleModel[]>(`${environment.serviceApiUrl}/api/MemberRule/GetMemberRuleById?sepReasonCodeId=${ruleId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberRuleModel[];
      })
    );
  }
}