import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable,Subject } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { FileTemplateModel } from '@app/core/models/administration/configuration/file-template.model';
import { DataFileToProcessDetailListModel } from '@app/core/models/operation/member/data-file-to-process-detail-list-model.model';
import { FileTemplateSearch } from '@app/core/models/operation/member/file-template-search.model';
import { environment } from '@environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DataFileToProcessDetailsService {
  searchMember$: Observable<any>;
  searchMemberSubject = new Subject<any>();
  constructor(private httpClient: HttpClient) {
    this.searchMember$ = this.searchMemberSubject.asObservable();
   }

  searchMember(data) {
    this.searchMemberSubject.next(data);
  }

  getDataFileToProcessDetails(): Observable<DataFileToProcessDetailListModel[]> {
    return this.httpClient.get<DataFileToProcessDetailListModel[]>(`${environment.serviceApiUrl}/api/DataFileToProcessDetails/GetDataFileToProcessDetails`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as DataFileToProcessDetailListModel[];
      })
    );
  }
}
