
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, Subject } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { FileTemplateModel } from '@app/core/models/administration/configuration/file-template.model';
import { OECFileProcessModel } from '@app/core/models/operation/member/oecfile-process-model.model';
import { OECLayoutListModel } from '@app/core/models/operation/member/oeclayout-list-model.model';
import { environment } from '@environments/environment';
import { OECLayoutFileDataModel } from '@app/core/models/operation/member/oeclayout-file-data-model.model';
import { DocumentList } from '@app/core/models/operation/member/DocumentList.model';
import { OtherDocument } from '@app/core/models/operation/member/otherdocument.model';
import { OtherNote } from '@app/core/models/operation/member/Notes.model';

@Injectable({
    providedIn: 'root'
})
export class OtherDocumentService {
    searchMember$: Observable<any>;
    searchMemberSubject = new Subject<any>();
    currentViewedDocument: OtherDocument;
    mbi: any;
    constructor(private httpClient: HttpClient) {
        this.searchMember$ = this.searchMemberSubject.asObservable();
    }

    searchMember(data) {
        this.searchMemberSubject.next(data);
    }

    //   OECFileUpload(formData): Observable<OECFileProcessModel> {
    //     return this.httpClient.post(`${environment.serviceApiUrl}/api/OECFile/OECFileUpload`, formData)
    //     .pipe(
    //       map(res => {
    //         res = Utils.camelizeKeys(res);
    //         return res as OECFileProcessModel;
    //       })
    //     );
    //   } 
    UploadDocument(DocumentList: DocumentList) {
        return this.httpClient.post(`${environment.serviceApiUrl}/api/OtherFiles/DocumentUpload/`, DocumentList);
    }
    ViewDocument(id: number): any {
        return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/OtherFiles/ViewDocument/${id}`);
    }
    deleteDocument(documentId: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/OtherFiles/DeleteDoument/${documentId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as Number;
            })
        );
    }

    deleteNote(noteId: number): Observable<Number> {
        return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/OtherNotes/DeleteNote/${noteId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as Number;
            })
        );
    }
    getNotesByMember(memberId: number): Observable<OtherNote> {
        return this.httpClient.get<OtherNote>(`${environment.serviceApiUrl}/api/OtherNotes/GetMemberNotesList/${memberId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as OtherNote;
            })
        );
    }
    setMbi(mbi: any) {
        this.mbi = mbi;
    }
    getMbi() {
        return this.mbi;
    }
    InsertNote(OtherNote: OtherNote) {
        return this.httpClient.post(`${environment.serviceApiUrl}/api/OtherNotes/InsertNote/`, OtherNote);
    }
    OtherFileUpload(formData: FormData): Observable<OECFileProcessModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}/api/OtherFiles/OtherAttachmentUpload/`, formData)
            .pipe(
                map(res => {
                    res = Utils.camelizeKeys(res);
                    return res as OECFileProcessModel;
                })
            );
    }
}