import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { TRRFalloutsListViewModel } from '@app/core/models/operation/member/trr-fallouts-list-view-model';
import { TRRFalloutsSearchModel, TRRFalloutsUpdateModel } from '@app/core/models/operation/member/trr-fallouts-search-model';
import { environment } from '@environments/environment';
import { map, Observable, Subject } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()

export class TRRFalloutsService {
  searchTRRFallouts$: Observable<any>;
  private searchTRRFalloutsSubject = new Subject<any>();
  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) {
    this.searchTRRFallouts$ = this.searchTRRFalloutsSubject.asObservable();
  }

  searchTRRFallouts(data) {
    this.searchTRRFalloutsSubject.next(data);
  }

  getTRRFalloutsOData(searchModel: TRRFalloutsSearchModel): Observable<TRRFalloutsListViewModel> {
    let searchModelString = JSON.stringify(searchModel);

    return this.httpClient.post<TRRFalloutsListViewModel>(`${environment.serviceApiUrl}/api/TRRSearch/GetTRRSearch`,searchModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TRRFalloutsListViewModel;
      })
    );
  }


  updateTRRFallouts(updateModel: TRRFalloutsUpdateModel): Observable<boolean> {
    return this.httpClient.post<boolean>(`${environment.serviceApiUrl}/api/TRRSearch/UpdateTRRFalloutStatus`,updateModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as boolean;
      })
    );
  }

}