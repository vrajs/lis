import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { BlobInformationModel, MemberBEQRequestModel, MemberBEQResponseModel, MemberEnrollmentHeaderAttachmentModel, MemberEnrollmentHeaderModel, MemberEnrollmentList, MemberEnrollmentListViewModel, MemberEnrollmentSearchModel, MemberModel, MemberPreEnrollmentAttachment, SaveMemberPreEnrollment } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable, Subject } from 'rxjs';
import { ODataBuilderService } from '@app/core/services';
import { mode } from 'crypto-js';

@Injectable()

export class PreEnrollmentService {
  searchMemberEnrollemnt$: Observable<any>;
  private searchMemberSubject = new Subject<any>();
  MemberId: number;
  PbpId: number | null;
  ContractId: number | null;
  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) {
    this.searchMemberEnrollemnt$ = this.searchMemberSubject.asObservable();
  }

  searchMemberEnrollemnt(data) {
    this.searchMemberSubject.next(data);
  }

  getMemberEnrollmentOData(searchModel: MemberEnrollmentSearchModel): Observable<MemberEnrollmentListViewModel> {
    let searchModelString = JSON.stringify(searchModel);

    return this.httpClient.get<MemberEnrollmentListViewModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader/GetMemberEnrollmentHeader?searchModelString=${searchModelString}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberEnrollmentListViewModel;
      })
    );
  }

  getMemberEnrollment(searchModel: MemberEnrollmentSearchModel): Observable<MemberEnrollmentList[]> {
    let searchModelString = JSON.stringify(searchModel);

    return this.httpClient.post<MemberEnrollmentList[]>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetMemberEnrollmentBEQFiles`, searchModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);

        return res as MemberEnrollmentList[];
      })
    );
  }


  getMemberMarxEnrollment(searchModel: MemberEnrollmentSearchModel): Observable<MemberEnrollmentList[]> {
    let searchModelString = JSON.stringify(searchModel);

    return this.httpClient.post<MemberEnrollmentList[]>(`${environment.serviceApiUrl}/api/MemberEnrollmentMarx/GetMemberEnrollmentMarxFiles`, searchModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);

        return res as MemberEnrollmentList[];
      })
    );
  }




  getPreEnrollmentHeaderByMBI(MBI: string): Observable<any> {
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetMemberPreEnrollmentByMBI?MBI=` + MBI).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberModel;
      })
    );
  }

  /**
   * Purpose of Method is to send BEQ request to CMS
   * @author Tisa Jodhani #O9-98 on 20 June,2022 - BEQ Request
   */
  getCMSResponse(model: MemberBEQRequestModel): Observable<MemberEnrollmentHeaderModel> {
    //ashish 26-07-2022
    return this.httpClient.post<MemberEnrollmentHeaderModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetBEQResponse`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberEnrollmentHeaderModel;
      })
    );
  }
  getCMSResponseWorkArround(model: MemberBEQRequestModel): Observable<string> {
    //ashish 26-07-2022
    return this.httpClient.post<string>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetBEQResponseWorkArround`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as string;
      })
    );
  }

  /**
  * Purpose of Method is to save member information
  * @author Tisa Jodhani  on  - Save member information
  */
  saveFinalValue(model: SaveMemberPreEnrollment): Observable<number> {
    return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/InsertMemberPreEnrollmentFinal`, model).pipe(
      map(res => {

        return res;
      })
    );
  }


  create(model: MemberBEQResponseModel): Observable<number> {
    const formData = new FormData();

    for (const prop in model) {
      if (!model.hasOwnProperty(prop)) { continue; }
      formData.append(prop, model[prop]);
    }

    for (let i = 0; i < model.enrollmentHeaderAttachment.length; i++) {
      formData.append('enrollmentHeaderAttachment ' + i, model.enrollmentHeaderAttachment[i]);
    }


    return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/MemberEnrollmentHeader`, model).pipe(
      map(res => {
        //res = Utils.camelizeKeys(res);
        return res;
      })
    )
  }

  SaveMemberValue(model: MemberBEQResponseModel): Observable<MemberBEQResponseModel> {

    const formData = new FormData();

    for (const prop in model) {
      if (!model.hasOwnProperty(prop)) { continue; }
      formData.append(prop, model[prop]);
    }

    for (let i = 0; i < model.enrollmentHeaderAttachment.length; i++) {
      formData.append('enrollmentHeaderAttachment ' + i, model.enrollmentHeaderAttachment[i]);
    }

    return this.httpClient.post<MemberBEQResponseModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/InsertMemberPreEnrollment`, formData).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberBEQResponseModel;
      })
    );
  }

  generateBeqFiles(model: any): Observable<string> {

    return this.httpClient.post<string>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GenerateBeqFiles`, model).pipe(
      map(res => {
        //    res = Utils.camelizeKeys(res);
        return res;
      })
    )

  }
  generateMarxFiles(model: any): Observable<string> {

    return this.httpClient.post<string>(`${environment.serviceApiUrl}/api/MemberEnrollmentMarx/GenerateMarxFiles`, model).pipe(
      map(res => {
        //    res = Utils.camelizeKeys(res);
        return res;
      })
    )

  }
  checkStatus(strRunId: string): Observable<string> {
    return this.httpClient.get<string>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/CheckStatus?strRunId=` + strRunId).pipe(
      map(res => {

        return res;
      }));
  }
  checkMarxStatus(strRunId: string, strPipelineName: string): Observable<string> {
    return this.httpClient.get<string>(`${environment.serviceApiUrl}/api/MemberEnrollmentMarx/CheckMarxStatus?strRunId=` + strRunId + `&PipelineName=` + strPipelineName).pipe(
      map(res => {

        return res;
      }));
  }

  getPipelineName(tranTypeId: number): Observable<string> {
    return this.httpClient.get<string>(`${environment.serviceApiUrl}/api/MemberEnrollmentMarx/GetPipelineName?tranTypeId=` + tranTypeId).pipe(
      map(res => {
        return res;
      }));
  }

  getMemberPreEnrollmentByMemberId(memberId: number): Observable<MemberBEQResponseModel> {
    return this.httpClient.get<MemberBEQResponseModel>(`${environment.serviceApiUrl}/api/MemberEnrollmentBEQ/GetMemberPreEnrollmentByMemberID/${memberId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as MemberBEQResponseModel;
      })
    );
  }


  getContainerName(model: MemberPreEnrollmentAttachment) :Observable<string>{
    return this.httpClient.post<string>(`${environment.serviceApiUrl}/api/MemberPreEnrollmentAttachment/GetContainer` , model).pipe(
      map(res => {
        return res as string;
      })
    )
    }

    getAttachmentListbyMemberId(memberId :number) :Observable<MemberPreEnrollmentAttachment>{
      return this.httpClient.get<MemberPreEnrollmentAttachment>(`${environment.serviceApiUrl}/api/MemberPreEnrollmentAttachment/GetAttachmentList/${memberId}`).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res as MemberPreEnrollmentAttachment;
        })
      );
    }
    getAttachmentListbyMember(memberId :number) :Observable<MemberPreEnrollmentAttachment>{
      return this.httpClient.get<MemberPreEnrollmentAttachment>(`${environment.serviceApiUrl}/api/MemberPreEnrollmentAttachment/GetMemberAttachmentList/${memberId}`).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res as MemberPreEnrollmentAttachment;
        })
      );
    }

    getBlobUri(model : BlobInformationModel) : Observable<string>{
      return this.httpClient.post<string>(`${environment.serviceApiUrl}/api/MemberPreEnrollmentAttachment/GetBlob`, model).pipe(
        map(res=> {
          res =Utils.camelizeKeys(res);
          return res as string;
        })
      );
    }

    // getBlobUri(model : BlobInformationModel) : Observable<BlobInformationModel>{
    //   return this.httpClient.get<BlobInformationModel>(`${environment.storageRouterURL}/api/GetBlob?code=${environment.blobAuthKey}&blobName=${model.fileName}&containerName=${model.containerName}`).pipe(
    //     map(res=> {
    //       res =Utils.camelizeKeys(res);
    //       return res as BlobInformationModel;
    //     })
    //   );
    // }


    //http://localhost:7071/api/GetBlob?blobName=123test/image-20220817-055602_e051e43b-4aac-4c25-a15a-d1e21b526d87.png&containerName=oxalis
}