
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable,Subject } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { FileTemplateModel } from '@app/core/models/administration/configuration/file-template.model';
import { OECFileProcessModel } from '@app/core/models/operation/member/oecfile-process-model.model';
import { OECLayoutListModel } from '@app/core/models/operation/member/oeclayout-list-model.model';
import { environment } from '@environments/environment';
import { OECLayoutFileDataModel } from '@app/core/models/operation/member/oeclayout-file-data-model.model';

@Injectable({
  providedIn: 'root'
})
export class OecFileService {
  searchMember$: Observable<any>;
  searchMemberSubject = new Subject<any>();
  constructor(private httpClient: HttpClient) {
    this.searchMember$ = this.searchMemberSubject.asObservable();
   }

  searchMember(data) {
    this.searchMemberSubject.next(data);
  }

  GetFileTemplateTypes(): Observable<FileTemplateModel[]> {
    return this.httpClient.get<FileTemplateModel[]>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileTemplateTypes`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileTemplateModel[];
      })
    );
  }

  OECFileUpload(formData): Observable<OECFileProcessModel> {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/OECFile/OECFileUpload`, formData)
    .pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as OECFileProcessModel;
      })
    );
  } 

  OECFileProcessCheckStatus(OECFileProcessModel): Observable<OECLayoutFileDataModel> {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/OECFile/OECFileProcessCheckStatus`, OECFileProcessModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as OECLayoutFileDataModel;
      })
    );
  }

  OECActualLoadData(OECFileProcessModel): Observable<OECLayoutFileDataModel> {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/OECFile/OECActualLoadData`, OECFileProcessModel).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as OECLayoutFileDataModel;
      })
    );
  }  
}

